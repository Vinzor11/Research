<?php
/**
 * Enhanced OAuth Callback Handler
 * Now stores tokens in database for persistence
 */

require 'db.php';
require 'config.php';
require 'TokenManager.php';
session_start();

$config = getOAuthConfig($conn);
$error = "";

// Check for errors from OAuth provider
if (isset($_GET['error'])) {
    $error = "OAuth error: " . htmlspecialchars($_GET['error']);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

// Post-logout redirect: provider sent user back to redirect_uri after end-session (no code, no state).
// Do not require state/code; just clear session and send to login with success message.
if (!isset($_GET['code'])) {
    session_unset();
    session_destroy();
    header("Location: login.php?message=" . urlencode("You have been logged out successfully from all systems"));
    exit;
}

// Verify state parameter (login flow only)
if (!isset($_GET['state']) || !isset($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
    $error = "Invalid state parameter. Possible CSRF attack.";
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$code = $_GET['code'];

// Exchange authorization code for access token
$tokenData = [
    'grant_type' => 'authorization_code',
    'client_id' => $config['client_id'],
    'client_secret' => $config['client_secret'],
    'code' => $code,
    'redirect_uri' => $config['redirect_uri'],
];

$ch = curl_init($config['token_url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded',
    'Accept: application/json'
]);

$tokenResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    $error = "Failed to exchange authorization code for token. HTTP Code: " . $httpCode;
    errorLog("OAuth Token Error", ['response' => substr($tokenResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$tokenResult = json_decode($tokenResponse, true);

if (!isset($tokenResult['access_token'])) {
    $error = "Access token not received.";
    errorLog("OAuth Token Response Missing Token", ['response' => $tokenResponse]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$accessToken = $tokenResult['access_token'];
$refreshToken = $tokenResult['refresh_token'] ?? null;
$expiresIn = $tokenResult['expires_in'] ?? (defined('TOKEN_DEFAULT_LIFETIME') ? TOKEN_DEFAULT_LIFETIME : 3600);

// Get user info from OAuth provider
$ch = curl_init($config['userinfo_url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Accept: application/json'
]);

$userInfoResponse = curl_exec($ch);
$userInfoHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($userInfoHttpCode === 403) {
    $error = "Access denied: Your account is not authorized to access this system. Please contact your HR administrator to request access.";
    errorLog("OAuth UserInfo 403 Access Denied", ['response' => substr($userInfoResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

if ($userInfoHttpCode !== 200) {
    $error = "Failed to get user information. HTTP Code: " . $userInfoHttpCode;
    errorLog("OAuth UserInfo Error", ['response' => substr($userInfoResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$userInfo = json_decode($userInfoResponse, true);

// Log full userinfo response for debugging (truncated for security)
debugLog("OAuth UserInfo Response", [
    'http_code' => $userInfoHttpCode,
    'response_keys' => array_keys($userInfo),
    'response_preview' => substr($userInfoResponse, 0, 500) // First 500 chars for debugging
]);

// ============================================
// ACCESS CHECK - POSITION OR UNIT
// ============================================

$userPosition = $userInfo['position'] ?? null;
// Handle unit in different formats: string, object with 'name', or in department field
$userUnit = null;
if (isset($userInfo['unit'])) {
    if (is_string($userInfo['unit'])) {
        $userUnit = $userInfo['unit'];
    } elseif (is_array($userInfo['unit']) && isset($userInfo['unit']['name'])) {
        $userUnit = $userInfo['unit']['name'];
    } elseif (is_array($userInfo['unit']) && isset($userInfo['unit']['title'])) {
        $userUnit = $userInfo['unit']['title'];
    }
}
// Fallback to department if unit is not available
if (empty($userUnit) && isset($userInfo['department'])) {
    if (is_string($userInfo['department'])) {
        $userUnit = $userInfo['department'];
    } elseif (is_array($userInfo['department']) && isset($userInfo['department']['name'])) {
        $userUnit = $userInfo['department']['name'];
    } elseif (is_array($userInfo['department']) && isset($userInfo['department']['title'])) {
        $userUnit = $userInfo['department']['title'];
    }
}
$employeeId = $userInfo['employee_id'] ?? $userInfo['id'] ?? $userInfo['sub'] ?? null;

// If unit is still missing, try to fetch from HR API using employee ID
if (empty($userUnit) && !empty($employeeId) && !empty($accessToken)) {
    debugLog("Unit not found in userinfo, attempting to fetch from HR API", ['employee_id' => $employeeId]);
    
    try {
        // Make direct API call to get employee details (use provider URL from config)
        $baseUrl = rtrim($config['provider_url'] ?? '', '/');
        if (empty($baseUrl)) $baseUrl = rtrim(HR_API_BASE_URL, '/');
        $apiUrl = $baseUrl . '/api/employees/' . urlencode($employeeId);
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Accept: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, API_TIMEOUT);
        
        $employeeResponse = curl_exec($ch);
        $employeeHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($employeeHttpCode === 200) {
            $employeeData = json_decode($employeeResponse, true);
            
            // Handle response wrapped in 'data' key
            if (isset($employeeData['data'])) {
                $employeeData = $employeeData['data'];
            }
            
            // Extract unit from employee data
            if (isset($employeeData['unit'])) {
                if (is_string($employeeData['unit'])) {
                    $userUnit = $employeeData['unit'];
                } elseif (is_array($employeeData['unit']) && isset($employeeData['unit']['name'])) {
                    $userUnit = $employeeData['unit']['name'];
                } elseif (is_array($employeeData['unit']) && isset($employeeData['unit']['title'])) {
                    $userUnit = $employeeData['unit']['title'];
                }
            }
            
            // Fallback to department from employee data
            if (empty($userUnit) && isset($employeeData['department'])) {
                if (is_string($employeeData['department'])) {
                    $userUnit = $employeeData['department'];
                } elseif (is_array($employeeData['department']) && isset($employeeData['department']['name'])) {
                    $userUnit = $employeeData['department']['name'];
                } elseif (is_array($employeeData['department']) && isset($employeeData['department']['title'])) {
                    $userUnit = $employeeData['department']['title'];
                }
            }
            
            debugLog("Unit fetched from HR API", ['unit' => $userUnit ?? 'STILL NOT FOUND', 'http_code' => $employeeHttpCode]);
        } else {
            debugLog("HR API employee fetch failed", ['http_code' => $employeeHttpCode, 'response' => substr($employeeResponse, 0, 200)]);
        }
    } catch (Exception $e) {
        errorLog("Failed to fetch unit from HR API", ['error' => $e->getMessage(), 'employee_id' => $employeeId]);
    }
}

debugLog("OAuth Callback - Access Check", [
    'position' => $userPosition ?? 'NOT SET',
    'unit' => $userUnit ?? 'NOT SET',
    'unit_raw' => $userInfo['unit'] ?? 'NOT SET',
    'department' => $userInfo['department'] ?? 'NOT SET',
    'employee_id' => $employeeId ?? 'NOT SET',
    'all_userinfo_keys' => array_keys($userInfo)
]);

// Determine role and access — HR client_role is source of truth when present (per SSO guide)
$userRole = null;
$coordinator_type = null;
$accessGranted = false;
$clientRole = $userInfo['client_role'] ?? null;

// Prefer client_role from HR (OAuth client role for this system)
// HR "admin" → admin; HR "user" → coordinator (grant coordinator role)
if (!empty($clientRole)) {
    $accessGranted = true;
    $clientRole = strtolower(trim($clientRole));
    if ($clientRole === 'admin') {
        $userRole = 'admin';
    } else {
        $userRole = 'coordinator'; // HR "user" role → grant coordinator role
    }
    debugLog("Access and role from client_role (HR source of truth)", [
        'client_role' => $clientRole,
        'user_role' => $userRole
    ]);
}

// Fallback: position/unit/coordinator_assignments when client_role not present
if (!$accessGranted && !empty($userPosition)) {
    $normalizedPosition = trim(strtolower($userPosition));
    
    if ($normalizedPosition === 'director' || $normalizedPosition === 'assistant director') {
        $userRole = 'admin';
        $accessGranted = true;
        debugLog("Access GRANTED via position (admin role)", [
            'position' => $userPosition,
            'role' => $userRole
        ]);
    }
}

// Check coordinator assignments if not admin
if (!$accessGranted && !empty($employeeId)) {
    // Check if employee is assigned as coordinator
    $checkCoordinator = $conn->prepare("
        SELECT coordinator_type 
        FROM coordinator_assignments 
        WHERE employee_id = ? AND status = 'active'
        LIMIT 1
    ");
    $checkCoordinator->bind_param("s", $employeeId);
    $checkCoordinator->execute();
    $coordinatorResult = $checkCoordinator->get_result()->fetch_assoc();
    $checkCoordinator->close();
    
    if ($coordinatorResult) {
        $userRole = 'coordinator';
        $coordinator_type = $coordinatorResult['coordinator_type'];
        $accessGranted = true;
        debugLog("Access GRANTED via coordinator assignment", [
            'employee_id' => $employeeId,
            'coordinator_type' => $coordinator_type
        ]);
    }
}

// If not granted via position or coordinator assignment, check unit
if (!$accessGranted) {
    $normalizedUnit = $userUnit ? trim(strtolower($userUnit)) : null;
    
    // Allowed units (check both the configured value and Research and Development Services Office)
    $allowedValues = [
        trim(strtolower(ALLOWED_DEPARTMENT)),
        'research and development services office',
        'research office',
        'research and development office',
        'rdso' // Common abbreviation
    ];
    
    // Check if unit matches any allowed value
    $unitMatches = $normalizedUnit && in_array($normalizedUnit, $allowedValues);
    
    if ($unitMatches) {
        $accessGranted = true;
        $userRole = $userRole ?? 'coordinator'; // default to coordinator when client_role missing (per guide: default to "user")
        debugLog("Access GRANTED via unit", ['unit' => $userUnit, 'role' => $userRole]);
    } else {
        // Check if unit is empty - if user is already a coordinator in DB, allow access
        if (empty($userUnit)) {
            // Double-check if user exists in database as coordinator/admin (might have been manually added)
            if (!empty($employeeId)) {
                $checkExistingUser = $conn->prepare("
                    SELECT id, user_role, coordinator_type 
                    FROM users 
                    WHERE username = ? OR email = ? 
                    LIMIT 1
                ");
                $email = $userInfo['email'] ?? '';
                $checkExistingUser->bind_param("ss", $email, $email);
                $checkExistingUser->execute();
                $existingUser = $checkExistingUser->get_result()->fetch_assoc();
                $checkExistingUser->close();
                
                if ($existingUser && in_array($existingUser['user_role'] ?? '', ['admin', 'coordinator'])) {
                    // User exists as admin/coordinator, grant access
                    $accessGranted = true;
                    $userRole = $existingUser['user_role'];
                    $coordinator_type = $existingUser['coordinator_type'];
                    debugLog("Access GRANTED - Existing user in database", [
                        'user_id' => $existingUser['id'],
                        'role' => $userRole
                    ]);
                } else {
                    $error = "Access denied: Unit information not available. Please contact your administrator to be assigned as a coordinator or ensure your HR profile includes unit information.";
                    errorLog("OAuth Access Denied - No Unit", [
                        'user' => $userInfo['email'] ?? 'Unknown',
                        'employee_id' => $employeeId,
                        'userinfo_keys' => array_keys($userInfo)
                    ]);
                    header("Location: login.php?error=" . urlencode($error));
                    exit;
                }
            } else {
                $error = "Access denied: Unit information not available. Please contact your administrator to be assigned as a coordinator or ensure your HR profile includes unit information.";
                errorLog("OAuth Access Denied - No Unit and No Employee ID", [
                    'user' => $userInfo['email'] ?? 'Unknown',
                    'userinfo_keys' => array_keys($userInfo)
                ]);
                header("Location: login.php?error=" . urlencode($error));
                exit;
            }
        } else {
            $error = "Access denied: This system is restricted to " . ALLOWED_DEPARTMENT . 
                     " personnel, Directors, or assigned Coordinators. Your unit: " . htmlspecialchars($userUnit) . 
                     ", position: " . htmlspecialchars($userPosition ?? 'N/A');
            errorLog("OAuth Access Denied - Wrong Unit/Position", [
                'user' => $userInfo['email'] ?? 'Unknown',
                'unit' => $userUnit,
                'position' => $userPosition,
                'employee_id' => $employeeId ?? 'N/A'
            ]);
            header("Location: login.php?error=" . urlencode($error));
            exit;
        }
    }
}

// ============================================
// CREATE/UPDATE USER
// ============================================

$identifier = $userInfo['email'] ?? $userInfo['employee_id'] ?? $userInfo['sub'] ?? null;

if (!$identifier) {
    $error = "Unable to identify user from OAuth provider.";
    errorLog("OAuth UserInfo Missing Identifier", ['userinfo' => $userInfoResponse]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$username = $userInfo['email'] ?? $userInfo['employee_id'] ?? $identifier;
$email = $userInfo['email'] ?? null;
// Get employee ID (used earlier in coordinator check, but ensure it's available here too)
$employeeId = $userInfo['employee_id'] ?? $userInfo['id'] ?? null;

// Check if email and user_role columns exist
$checkEmailColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'email'");
$hasEmailColumn = $checkEmailColumn->num_rows > 0;

// Check for user_role column (preferred), fallback to legacy 'role' column if needed
$checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'");
$hasRoleColumn = $checkRoleColumn->num_rows > 0;

if (!$hasRoleColumn) {
    // Legacy support: Try 'role' column name as fallback (for old databases)
    $checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
    $hasRoleColumn = $checkRoleColumn->num_rows > 0;
    $roleColumnName = 'role';
    // Log warning about legacy column usage
    errorLog("Using legacy 'role' column - consider migrating to 'user_role'");
} else {
    $roleColumnName = 'user_role';
}

$checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
$hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;

// Check if position/designation column exists
$checkPositionColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'position'");
$hasPositionColumn = $checkPositionColumn->num_rows > 0;
if (!$hasPositionColumn) {
    // Try alternative column names
    $checkDesignationColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'designation'");
    $hasPositionColumn = $checkDesignationColumn->num_rows > 0;
    $positionColumnName = $hasPositionColumn ? 'designation' : null;
} else {
    $positionColumnName = 'position';
}

// Check if employee_id column exists
$checkEmployeeIdColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'");
$hasEmployeeIdColumn = $checkEmployeeIdColumn->num_rows > 0;

// OAuth SSO columns (per SSO Integration Guide: sync client_role and store oauth_sub on every login)
$checkOauthSubColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'oauth_sub'");
$hasOauthSubColumn = $checkOauthSubColumn->num_rows > 0;
$checkOauthClientRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'oauth_client_role'");
$hasOauthClientRoleColumn = $checkOauthClientRoleColumn->num_rows > 0;
$checkLastOauthLoginColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'last_oauth_login_at'");
$hasLastOauthLoginColumn = $checkLastOauthLoginColumn->num_rows > 0;

// Build SELECT query with all needed columns
$selectFields = ['id', 'username'];
if ($hasEmailColumn) {
    $selectFields[] = 'email';
}
if ($hasRoleColumn) {
    $selectFields[] = $roleColumnName;
}
if ($hasCoordTypeColumn) {
    $selectFields[] = 'coordinator_type';
}
if ($hasPositionColumn && $positionColumnName) {
    $selectFields[] = $positionColumnName;
}
if ($hasEmployeeIdColumn) {
    $selectFields[] = 'employee_id';
}
if ($hasOauthSubColumn) {
    $selectFields[] = 'oauth_sub';
}
if ($hasOauthClientRoleColumn) {
    $selectFields[] = 'oauth_client_role';
}

$selectSql = "SELECT " . implode(', ', $selectFields) . " FROM users WHERE " . 
             ($hasEmailColumn ? "(username = ? OR email = ?)" : "username = ?") . " LIMIT 1";

$stmt = $conn->prepare($selectSql);
if ($hasEmailColumn) {
    $stmt->bind_param("ss", $username, $email);
} else {
    $stmt->bind_param("s", $username);
}

$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if ($user) {
    // User exists - update user information from OAuth provider
    $userId = $user['id'];
    
    // Build update fields for any changed information from OAuth provider
    $updateFields = [];
    $updateParams = [];
    $updateTypes = '';
    
    // Update email if it exists in userinfo and is different
    if ($hasEmailColumn && !empty($email) && $email !== ($user['email'] ?? '')) {
        $updateFields[] = "email = ?";
        $updateParams[] = $email;
        $updateTypes .= 's';
        debugLog("Email will be updated", [
            'old' => $user['email'] ?? 'NULL',
            'new' => $email
        ]);
    }
    
    // Update username if employee_id is available and different
    // (Only if username is currently an email and we have employee_id)
    if (!empty($employeeId) && $username !== $user['username']) {
        // Check if current username is an email format
        if (filter_var($user['username'], FILTER_VALIDATE_EMAIL) && !filter_var($employeeId, FILTER_VALIDATE_EMAIL)) {
            // Update username to employee_id if it was previously an email
            $updateFields[] = "username = ?";
            $updateParams[] = $username;
            $updateTypes .= 's';
            debugLog("Username will be updated", [
                'old' => $user['username'],
                'new' => $username
            ]);
        }
    }
    
    // Sync role on every SSO login (per SSO Integration Guide — HR is source of truth)
    if ($hasRoleColumn && $userRole !== null) {
        $updateFields[] = "$roleColumnName = ?";
        $updateParams[] = $userRole;
        $updateTypes .= 's';
        debugLog("Role synced from SSO", [
            'old' => $user[$roleColumnName] ?? 'NULL',
            'new' => $userRole
        ]);
    }
    
    // Update coordinator_type if it's set and different
    if (isset($coordinator_type)) {
        $checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
        $hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;
        
        if ($hasCoordTypeColumn) {
            $currentCoordType = $user['coordinator_type'] ?? null;
            if ($currentCoordType !== $coordinator_type) {
                $updateFields[] = "coordinator_type = ?";
                $updateParams[] = $coordinator_type;
                $updateTypes .= 's';
                debugLog("Coordinator type will be updated", [
                    'old' => $currentCoordType ?? 'NULL',
                    'new' => $coordinator_type
                ]);
            }
        }
    }
    
    // Update position/designation if it exists in userinfo and is different
    if ($hasPositionColumn && $positionColumnName && !empty($userPosition)) {
        $currentPosition = $user[$positionColumnName] ?? null;
        if ($currentPosition !== $userPosition) {
            $updateFields[] = "$positionColumnName = ?";
            $updateParams[] = $userPosition;
            $updateTypes .= 's';
            debugLog("Position/designation will be updated", [
                'old' => $currentPosition ?? 'NULL',
                'new' => $userPosition
            ]);
        }
    }
    
    // Update employee_id if it exists and is different
    if ($hasEmployeeIdColumn && !empty($employeeId)) {
        $currentEmployeeId = $user['employee_id'] ?? null;
        if ($currentEmployeeId !== $employeeId) {
            $updateFields[] = "employee_id = ?";
            $updateParams[] = $employeeId;
            $updateTypes .= 's';
            debugLog("Employee ID will be updated", [
                'old' => $currentEmployeeId ?? 'NULL',
                'new' => $employeeId
            ]);
        }
    }
    
    // Sync OAuth fields on every SSO login (per SSO Integration Guide — HR is source of truth)
    $oauthSub = $userInfo['sub'] ?? null;
    $clientRoleRaw = $userInfo['client_role'] ?? null;
    if ($hasOauthSubColumn && $oauthSub !== null) {
        $updateFields[] = "oauth_sub = ?";
        $updateParams[] = is_string($oauthSub) ? $oauthSub : (string)$oauthSub;
        $updateTypes .= 's';
    }
    if ($hasOauthClientRoleColumn) {
        $updateFields[] = "oauth_client_role = ?";
        $updateParams[] = $clientRoleRaw !== null ? trim((string)$clientRoleRaw) : null;
        $updateTypes .= 's';
    }
    if ($hasLastOauthLoginColumn) {
        $updateFields[] = "last_oauth_login_at = ?";
        $updateParams[] = date('Y-m-d H:i:s');
        $updateTypes .= 's';
    }
    
    // Execute update if there are any changes
    if (!empty($updateFields)) {
        $updateParams[] = $userId;
        $updateTypes .= 'i';
        
        $updateSql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param($updateTypes, ...$updateParams);
        $updateStmt->execute();
        $updateStmt->close();
        
        debugLog("User information updated from OAuth provider", [
            'id' => $userId, 
            'username' => $user['username'],
            'updated_fields' => $updateFields,
            'role' => $userRole,
            'coordinator_type' => $coordinator_type ?? null
        ]);
    } else {
        debugLog("User found - no updates needed", [
            'id' => $userId, 
            'username' => $user['username']
        ]);
    }
    
} else {
    // Create new user
    $randomPassword = bin2hex(random_bytes(32));
    
    debugLog("Creating new user", [
        'username' => $username, 
        'role' => $userRole,
        'coordinator_type' => $coordinator_type ?? null
    ]);
    
    // Check if coordinator_type column exists
    $checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
    $hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;
    
    // Build INSERT statement based on available columns
    $columns = ['username', 'password'];
    $values = [$username, password_hash($randomPassword, PASSWORD_DEFAULT)];
    $types = 'ss';
    
    if ($hasEmailColumn) {
        $columns[] = 'email';
        $values[] = $email;
        $types .= 's';
    }
    
    if ($hasRoleColumn && $userRole) {
        $columns[] = $roleColumnName;
        $values[] = $userRole;
        $types .= 's';
    }
    
    if ($hasCoordTypeColumn && isset($coordinator_type)) {
        $columns[] = 'coordinator_type';
        $values[] = $coordinator_type;
        $types .= 's';
    }
    
    // Add position/designation if column exists and value is available
    if ($hasPositionColumn && $positionColumnName && !empty($userPosition)) {
        $columns[] = $positionColumnName;
        $values[] = $userPosition;
        $types .= 's';
    }
    
    // Add employee_id if column exists and value is available
    if ($hasEmployeeIdColumn && !empty($employeeId)) {
        $columns[] = 'employee_id';
        $values[] = $employeeId;
        $types .= 's';
    }
    
    // OAuth SSO fields (per SSO Integration Guide)
    if ($hasOauthSubColumn && isset($userInfo['sub'])) {
        $columns[] = 'oauth_sub';
        $values[] = is_string($userInfo['sub']) ? $userInfo['sub'] : (string)$userInfo['sub'];
        $types .= 's';
    }
    if ($hasOauthClientRoleColumn && isset($userInfo['client_role'])) {
        $columns[] = 'oauth_client_role';
        $values[] = trim((string)$userInfo['client_role']);
        $types .= 's';
    }
    if ($hasLastOauthLoginColumn) {
        $columns[] = 'last_oauth_login_at';
        $values[] = date('Y-m-d H:i:s');
        $types .= 's';
    }
    
    $placeholders = str_repeat('?,', count($columns) - 1) . '?';
    $sql = "INSERT INTO users (" . implode(', ', $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$values);
    
    $stmt->execute();
    $userId = $conn->insert_id;
    $stmt->close();
}

// ============================================
// STORE TOKENS USING TokenManager
// ============================================

try {
    $tokenManager = new TokenManager($conn, $userId);
    $tokenManager->storeToken($accessToken, $refreshToken, $expiresIn);
    
    debugLog("Tokens stored successfully", ['user_id' => $userId]);
    
} catch (Exception $e) {
    errorLog("Failed to store tokens", ['error' => $e->getMessage()]);
    // Continue anyway - session token will still work for this session
}

// ============================================
// SET SESSION
// ============================================

$_SESSION['user_id'] = $userId;
$_SESSION['username'] = $username;
if ($userRole) {
    $_SESSION['user_role'] = $userRole;
}
if (isset($coordinator_type)) {
    $_SESSION['coordinator_type'] = $coordinator_type;
}
$_SESSION['auth_method'] = 'sso';
$_SESSION['hr_system_url'] = $config['provider_url'];
$_SESSION['hr_access_token'] = $accessToken;
$_SESSION['hr_token_expires_at'] = date('Y-m-d H:i:s', time() + $expiresIn);
$_SESSION['hr_employee_id'] = $employeeId;

// Store parent unit info from userinfo (if available)
$_SESSION['unit_parent_id'] = $userInfo['unit_parent_id'] ?? null;
$_SESSION['unit_parent'] = $userInfo['unit_parent'] ?? null;
$_SESSION['unit_parent_code'] = $userInfo['unit_parent_code'] ?? null;

debugLog("Session established", [
    'user_id' => $userId,
    'username' => $username,
    'role' => $userRole,
    'coordinator_type' => $coordinator_type ?? null,
    'unit' => $userUnit,
    'position' => $userPosition,
    'employee_id' => $employeeId
]);

// Clear OAuth state
unset($_SESSION['oauth_state']);

// Log activity if ActivityLogger exists
if (file_exists('ActivityLogger.php')) {
    try {
        require_once 'ActivityLogger.php';
        $logger = new ActivityLogger($conn, $userId);
        $logger->logLogin($username);
    } catch (Exception $e) {
        debugLog("ActivityLogger error: " . $e->getMessage());
    }
}

// Redirect to home page
header("Location: index.php");
exit;