<?php
/**
 * Enhanced OAuth Callback Handler
 * Now stores tokens in database for persistence
 */

require 'db.php';
require 'config.php';
require 'TokenManager.php';
session_start();

$config = getOAuthConfig($conn);
$error = "";

// Check for errors from OAuth provider
if (isset($_GET['error'])) {
    $error = "OAuth error: " . htmlspecialchars($_GET['error']);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

// Post-logout redirect: provider sent user back to redirect_uri after end-session (no code, no state).
// Do not require state/code; just clear session and send to login with success message.
if (!isset($_GET['code'])) {
    session_unset();
    session_destroy();
    header("Location: login.php?message=" . urlencode("You have been logged out successfully from all systems"));
    exit;
}

// Verify state parameter (login flow only)
if (!isset($_GET['state']) || !isset($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
    $error = "Invalid state parameter. Possible CSRF attack.";
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$code = $_GET['code'];

// Exchange authorization code for access token
$tokenData = [
    'grant_type' => 'authorization_code',
    'client_id' => $config['client_id'],
    'client_secret' => $config['client_secret'],
    'code' => $code,
    'redirect_uri' => $config['redirect_uri'],
];

$ch = curl_init($config['token_url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded',
    'Accept: application/json'
]);

$tokenResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    $error = "Failed to exchange authorization code for token. HTTP Code: " . $httpCode;
    errorLog("OAuth Token Error", ['response' => substr($tokenResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$tokenResult = json_decode($tokenResponse, true);

if (!isset($tokenResult['access_token'])) {
    $error = "Access token not received.";
    errorLog("OAuth Token Response Missing Token", ['response' => $tokenResponse]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$accessToken = $tokenResult['access_token'];
$refreshToken = $tokenResult['refresh_token'] ?? null;
$expiresIn = $tokenResult['expires_in'] ?? (defined('TOKEN_DEFAULT_LIFETIME') ? TOKEN_DEFAULT_LIFETIME : 3600);

// Get user info from OAuth provider
$ch = curl_init($config['userinfo_url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'Accept: application/json'
]);

$userInfoResponse = curl_exec($ch);
$userInfoHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($userInfoHttpCode === 403) {
    $error = "Access denied: Your account is not authorized to access this system. Please contact your HR administrator to request access.";
    errorLog("OAuth UserInfo 403 Access Denied", ['response' => substr($userInfoResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

if ($userInfoHttpCode !== 200) {
    $error = "Failed to get user information. HTTP Code: " . $userInfoHttpCode;
    errorLog("OAuth UserInfo Error", ['response' => substr($userInfoResponse, 0, 200)]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

$userInfo = json_decode($userInfoResponse, true);

// Log full userinfo response for debugging (truncated for security)
debugLog("OAuth UserInfo Response", [
    'http_code' => $userInfoHttpCode,
    'response_keys' => array_keys($userInfo),
    'response_preview' => substr($userInfoResponse, 0, 500) // First 500 chars for debugging
]);

// ============================================
// ACCESS CHECK - POSITION OR UNIT
// ============================================

$userPosition = $userInfo['position'] ?? null;
// Handle unit in different formats: string, object with 'name', or in department field
$userUnit = null;
if (isset($userInfo['unit'])) {
    if (is_string($userInfo['unit'])) {
        $userUnit = $userInfo['unit'];
    } elseif (is_array($userInfo['unit']) && isset($userInfo['unit']['name'])) {
        $userUnit = $userInfo['unit']['name'];
    } elseif (is_array($userInfo['unit']) && isset($userInfo['unit']['title'])) {
        $userUnit = $userInfo['unit']['title'];
    }
}
// Fallback to department if unit is not available
if (empty($userUnit) && isset($userInfo['department'])) {
    if (is_string($userInfo['department'])) {
        $userUnit = $userInfo['department'];
    } elseif (is_array($userInfo['department']) && isset($userInfo['department']['name'])) {
        $userUnit = $userInfo['department']['name'];
    } elseif (is_array($userInfo['department']) && isset($userInfo['department']['title'])) {
        $userUnit = $userInfo['department']['title'];
    }
}
$employeeId = $userInfo['employee_id'] ?? $userInfo['id'] ?? $userInfo['sub'] ?? null;

// If unit is still missing, try to fetch from HR API using employee ID
if (empty($userUnit) && !empty($employeeId) && !empty($accessToken)) {
    debugLog("Unit not found in userinfo, attempting to fetch from HR API", ['employee_id' => $employeeId]);
    
    try {
        // Make direct API call to get employee details (use provider URL from config)
        $baseUrl = rtrim($config['provider_url'] ?? '', '/');
        if (empty($baseUrl)) $baseUrl = rtrim(HR_API_BASE_URL, '/');
        $apiUrl = $baseUrl . '/api/employees/' . urlencode($employeeId);
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Accept: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, API_TIMEOUT);
        
        $employeeResponse = curl_exec($ch);
        $employeeHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($employeeHttpCode === 200) {
            $employeeData = json_decode($employeeResponse, true);
            
            // Handle response wrapped in 'data' key
            if (isset($employeeData['data'])) {
                $employeeData = $employeeData['data'];
            }
            
            // Extract unit from employee data
            if (isset($employeeData['unit'])) {
                if (is_string($employeeData['unit'])) {
                    $userUnit = $employeeData['unit'];
                } elseif (is_array($employeeData['unit']) && isset($employeeData['unit']['name'])) {
                    $userUnit = $employeeData['unit']['name'];
                } elseif (is_array($employeeData['unit']) && isset($employeeData['unit']['title'])) {
                    $userUnit = $employeeData['unit']['title'];
                }
            }
            
            // Fallback to department from employee data
            if (empty($userUnit) && isset($employeeData['department'])) {
                if (is_string($employeeData['department'])) {
                    $userUnit = $employeeData['department'];
                } elseif (is_array($employeeData['department']) && isset($employeeData['department']['name'])) {
                    $userUnit = $employeeData['department']['name'];
                } elseif (is_array($employeeData['department']) && isset($employeeData['department']['title'])) {
                    $userUnit = $employeeData['department']['title'];
                }
            }
            
            // Also extract parent_unit from employee data if unit is a program
            if (isset($employeeData['unit']) && is_array($employeeData['unit'])) {
                $unitType = $employeeData['unit']['unit_type'] ?? null;
                if ($unitType === 'program' && isset($employeeData['unit']['parent_unit'])) {
                    if (is_string($employeeData['unit']['parent_unit'])) {
                        $userInfo['unit_parent'] = $employeeData['unit']['parent_unit'];
                    } elseif (is_array($employeeData['unit']['parent_unit']) && isset($employeeData['unit']['parent_unit']['name'])) {
                        $userInfo['unit_parent'] = $employeeData['unit']['parent_unit']['name'];
                    } elseif (is_array($employeeData['unit']['parent_unit']) && isset($employeeData['unit']['parent_unit']['title'])) {
                        $userInfo['unit_parent'] = $employeeData['unit']['parent_unit']['title'];
                    }
                }
            }
            
            debugLog("Unit fetched from HR API", ['unit' => $userUnit ?? 'STILL NOT FOUND', 'http_code' => $employeeHttpCode]);
        } else {
            debugLog("HR API employee fetch failed", ['http_code' => $employeeHttpCode, 'response' => substr($employeeResponse, 0, 200)]);
        }
    } catch (Exception $e) {
        errorLog("Failed to fetch unit from HR API", ['error' => $e->getMessage(), 'employee_id' => $employeeId]);
    }
}

// Extract parent_unit for storage in database
// Priority: 1. unit_parent from userinfo, 2. If unit is a program, get its parent_unit, 3. unit as fallback
$parentUnitForDB = null;

// First, try unit_parent from userinfo
if (isset($userInfo['unit_parent']) && !empty($userInfo['unit_parent'])) {
    $parentUnitForDB = is_string($userInfo['unit_parent']) ? $userInfo['unit_parent'] : ($userInfo['unit_parent']['name'] ?? $userInfo['unit_parent']['title'] ?? null);
}

// If unit_parent not available, check if unit is a program and get its parent
if (empty($parentUnitForDB) && isset($userInfo['unit']) && is_array($userInfo['unit'])) {
    $unitType = $userInfo['unit']['unit_type'] ?? null;
    
    // If unit is a program, get its parent unit
    if ($unitType === 'program') {
        if (isset($userInfo['unit']['parent_unit'])) {
            if (is_string($userInfo['unit']['parent_unit'])) {
                $parentUnitForDB = $userInfo['unit']['parent_unit'];
            } elseif (is_array($userInfo['unit']['parent_unit']) && isset($userInfo['unit']['parent_unit']['name'])) {
                $parentUnitForDB = $userInfo['unit']['parent_unit']['name'];
            } elseif (is_array($userInfo['unit']['parent_unit']) && isset($userInfo['unit']['parent_unit']['title'])) {
                $parentUnitForDB = $userInfo['unit']['parent_unit']['title'];
            }
        }
    }
}

// If still no parent_unit, use unit as fallback
if (empty($parentUnitForDB) && !empty($userUnit)) {
    $parentUnitForDB = $userUnit;
}

debugLog("Parent Unit for DB Storage", [
    'parent_unit' => $parentUnitForDB ?? 'NULL',
    'unit' => $userUnit ?? 'NULL',
    'unit_type' => $userInfo['unit']['unit_type'] ?? 'NOT SET',
    'unit_parent_from_userinfo' => $userInfo['unit_parent'] ?? 'NOT SET'
]);

debugLog("OAuth Callback - Access Check", [
    'position' => $userPosition ?? 'NOT SET',
    'unit' => $userUnit ?? 'NOT SET',
    'unit_raw' => $userInfo['unit'] ?? 'NOT SET',
    'department' => $userInfo['department'] ?? 'NOT SET',
    'employee_id' => $employeeId ?? 'NOT SET',
    'all_userinfo_keys' => array_keys($userInfo)
]);

// Determine role and access — HR client_role is source of truth when present (per SSO guide)
$userRole = null;
$coordinator_type = null;
$accessGranted = false;
$clientRole = $userInfo['client_role'] ?? null;

// Prefer client_role from HR (OAuth client role for this system)
// HR "admin" → admin
// HR "user" + position "Research Coordinator" → coordinator
// HR "user" + position NOT "Research Coordinator" → researcher
if (!empty($clientRole)) {
    $accessGranted = true;
    $clientRole = strtolower(trim($clientRole));
    if ($clientRole === 'admin') {
        $userRole = 'admin';
    } elseif ($clientRole === 'user') {
        // Check if position is Research Coordinator
        $normalizedPosition = $userPosition ? trim(strtolower($userPosition)) : '';
        if ($normalizedPosition === 'research coordinator') {
            $userRole = 'coordinator';
        } else {
            $userRole = 'researcher';
        }
    } else {
        // For any other client_role value, default to researcher
        $userRole = 'researcher';
    }
    debugLog("Access and role from client_role (HR source of truth)", [
        'client_role' => $clientRole,
        'position' => $userPosition ?? 'NOT SET',
        'user_role' => $userRole
    ]);
}

// Fallback: position/unit/coordinator_assignments when client_role not present
if (!$accessGranted && !empty($userPosition)) {
    $normalizedPosition = trim(strtolower($userPosition));
    
    if ($normalizedPosition === 'director' || $normalizedPosition === 'assistant director') {
        $userRole = 'admin';
        $accessGranted = true;
        debugLog("Access GRANTED via position (admin role)", [
            'position' => $userPosition,
            'role' => $userRole
        ]);
    }
}

// Check coordinator assignments if not admin
if (!$accessGranted && !empty($employeeId)) {
    // Check if employee is assigned as coordinator
    $checkCoordinator = $conn->prepare("
        SELECT coordinator_type 
        FROM coordinator_assignments 
        WHERE employee_id = ? AND status = 'active'
        LIMIT 1
    ");
    $checkCoordinator->bind_param("s", $employeeId);
    $checkCoordinator->execute();
    $coordinatorResult = $checkCoordinator->get_result()->fetch_assoc();
    $checkCoordinator->close();
    
    if ($coordinatorResult) {
        $userRole = 'coordinator';
        $coordinator_type = $coordinatorResult['coordinator_type'];
        $accessGranted = true;
        debugLog("Access GRANTED via coordinator assignment", [
            'employee_id' => $employeeId,
            'coordinator_type' => $coordinator_type
        ]);
    }
}

// If not granted via position or coordinator assignment, check unit
if (!$accessGranted) {
    $normalizedUnit = $userUnit ? trim(strtolower($userUnit)) : null;
    
    // Allowed units (check both the configured value and Research and Development Services Office)
    $allowedValues = [
        trim(strtolower(ALLOWED_DEPARTMENT)),
        'research and development services office',
        'research office',
        'research and development office',
        'rdso' // Common abbreviation
    ];
    
    // Check if unit matches any allowed value
    $unitMatches = $normalizedUnit && in_array($normalizedUnit, $allowedValues);
    
    if ($unitMatches) {
        $accessGranted = true;
        $userRole = $userRole ?? 'coordinator'; // default to coordinator when client_role missing (per guide: default to "user")
        debugLog("Access GRANTED via unit", ['unit' => $userUnit, 'role' => $userRole]);
    } else {
        // Check if unit is empty - if user is already a coordinator in DB, allow access
        if (empty($userUnit)) {
            // Double-check if user exists in database as coordinator/admin (might have been manually added)
            if (!empty($employeeId)) {
                $checkExistingUser = $conn->prepare("
                    SELECT id, user_role, coordinator_type 
                    FROM users 
                    WHERE username = ? OR email = ? 
                    LIMIT 1
                ");
                $email = $userInfo['email'] ?? '';
                $checkExistingUser->bind_param("ss", $email, $email);
                $checkExistingUser->execute();
                $existingUser = $checkExistingUser->get_result()->fetch_assoc();
                $checkExistingUser->close();
                
                if ($existingUser && in_array($existingUser['user_role'] ?? '', ['admin', 'coordinator'])) {
                    // User exists as admin/coordinator, grant access
                    $accessGranted = true;
                    $userRole = $existingUser['user_role'];
                    $coordinator_type = $existingUser['coordinator_type'];
                    debugLog("Access GRANTED - Existing user in database", [
                        'user_id' => $existingUser['id'],
                        'role' => $userRole
                    ]);
                } else {
                    $error = "Access denied: Unit information not available. Please contact your administrator to be assigned as a coordinator or ensure your HR profile includes unit information.";
                    errorLog("OAuth Access Denied - No Unit", [
                        'user' => $userInfo['email'] ?? 'Unknown',
                        'employee_id' => $employeeId,
                        'userinfo_keys' => array_keys($userInfo)
                    ]);
                    header("Location: login.php?error=" . urlencode($error));
                    exit;
                }
            } else {
                $error = "Access denied: Unit information not available. Please contact your administrator to be assigned as a coordinator or ensure your HR profile includes unit information.";
                errorLog("OAuth Access Denied - No Unit and No Employee ID", [
                    'user' => $userInfo['email'] ?? 'Unknown',
                    'userinfo_keys' => array_keys($userInfo)
                ]);
                header("Location: login.php?error=" . urlencode($error));
                exit;
            }
        } else {
            $error = "Access denied: This system is restricted to " . ALLOWED_DEPARTMENT . 
                     " personnel, Directors, or assigned Coordinators. Your unit: " . htmlspecialchars($userUnit) . 
                     ", position: " . htmlspecialchars($userPosition ?? 'N/A');
            errorLog("OAuth Access Denied - Wrong Unit/Position", [
                'user' => $userInfo['email'] ?? 'Unknown',
                'unit' => $userUnit,
                'position' => $userPosition,
                'employee_id' => $employeeId ?? 'N/A'
            ]);
            header("Location: login.php?error=" . urlencode($error));
            exit;
        }
    }
}

// ============================================
// CREATE/UPDATE USER
// ============================================

$identifier = $userInfo['email'] ?? $userInfo['employee_id'] ?? $userInfo['sub'] ?? null;

if (!$identifier) {
    $error = "Unable to identify user from OAuth provider.";
    errorLog("OAuth UserInfo Missing Identifier", ['userinfo' => $userInfoResponse]);
    header("Location: login.php?error=" . urlencode($error));
    exit;
}

// Get username from 'name' field in userinfo (name = username)
$username = null;
if (isset($userInfo['name'])) {
    if (is_string($userInfo['name'])) {
        $username = $userInfo['name'];
    } elseif (is_array($userInfo['name'])) {
        // If name is an array, try to get full_name or construct from parts
        $username = $userInfo['name']['full_name'] ?? $userInfo['name']['first_name'] ?? null;
    }
}
// Fallback to email or employee_id if name not available
if (empty($username)) {
    $username = $userInfo['email'] ?? $userInfo['employee_id'] ?? $identifier;
}

$email = $userInfo['email'] ?? null;
// Get employee ID (used earlier in coordinator check, but ensure it's available here too)
$employeeId = $userInfo['employee_id'] ?? $userInfo['id'] ?? null;

// Extract fullname from userInfo - combine first_name, middle_name, and last_name
// Check both root level and name array for these fields
$fullname = null;
$firstName = trim($userInfo['first_name'] ?? $userInfo['name']['first_name'] ?? '');
$middleName = trim($userInfo['middle_name'] ?? $userInfo['name']['middle_name'] ?? '');
// Try both 'surname' and 'last_name' as different APIs might use different keys
$lastName = trim($userInfo['last_name'] ?? $userInfo['name']['last_name'] ?? $userInfo['surname'] ?? $userInfo['name']['surname'] ?? '');

// Build fullname: "First Middle Last" or "First Last" if middle is empty
$nameParts = array_filter([$firstName, $middleName, $lastName]);
$fullname = !empty($nameParts) ? implode(' ', $nameParts) : null;

// Check if email and user_role columns exist
$checkEmailColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'email'");
$hasEmailColumn = $checkEmailColumn->num_rows > 0;

// Check if fullname column exists
$checkFullnameColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'fullname'");
$hasFullnameColumn = $checkFullnameColumn->num_rows > 0;

// Check for user_role column (preferred), fallback to legacy 'role' column if needed
$checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'");
$hasRoleColumn = $checkRoleColumn->num_rows > 0;

if (!$hasRoleColumn) {
    // Legacy support: Try 'role' column name as fallback (for old databases)
    $checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
    $hasRoleColumn = $checkRoleColumn->num_rows > 0;
    $roleColumnName = 'role';
    // Log warning about legacy column usage
    errorLog("Using legacy 'role' column - consider migrating to 'user_role'");
} else {
    $roleColumnName = 'user_role';
}

$checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
$hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;

// Check if position/designation column exists
$checkPositionColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'position'");
$hasPositionColumn = $checkPositionColumn->num_rows > 0;
if (!$hasPositionColumn) {
    // Try alternative column names
    $checkDesignationColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'designation'");
    $hasPositionColumn = $checkDesignationColumn->num_rows > 0;
    $positionColumnName = $hasPositionColumn ? 'designation' : null;
} else {
    $positionColumnName = 'position';
}

// Check if employee_id column exists
$checkEmployeeIdColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'");
$hasEmployeeIdColumn = $checkEmployeeIdColumn->num_rows > 0;

// Check if parent_unit column exists
$checkParentUnitColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'parent_unit'");
$hasParentUnitColumn = $checkParentUnitColumn->num_rows > 0;

// OAuth SSO columns (per SSO Integration Guide: sync client_role and store oauth_sub on every login)
$checkOauthSubColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'oauth_sub'");
$hasOauthSubColumn = $checkOauthSubColumn->num_rows > 0;
$checkOauthClientRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'oauth_client_role'");
$hasOauthClientRoleColumn = $checkOauthClientRoleColumn->num_rows > 0;
$checkLastOauthLoginColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'last_oauth_login_at'");
$hasLastOauthLoginColumn = $checkLastOauthLoginColumn->num_rows > 0;

// Build SELECT query with all needed columns
$selectFields = ['id', 'username'];
if ($hasEmailColumn) {
    $selectFields[] = 'email';
}
if ($hasFullnameColumn) {
    $selectFields[] = 'fullname';
}
if ($hasRoleColumn) {
    $selectFields[] = $roleColumnName;
}
if ($hasCoordTypeColumn) {
    $selectFields[] = 'coordinator_type';
}
if ($hasPositionColumn && $positionColumnName) {
    $selectFields[] = $positionColumnName;
}
if ($hasEmployeeIdColumn) {
    $selectFields[] = 'employee_id';
}
if ($hasParentUnitColumn) {
    $selectFields[] = 'parent_unit';
}
if ($hasOauthSubColumn) {
    $selectFields[] = 'oauth_sub';
}
if ($hasOauthClientRoleColumn) {
    $selectFields[] = 'oauth_client_role';
}

// Priority: 1. employee_id (most reliable), 2. email, 3. username, 4. oauth_sub
$user = null;
$userId = null;

// First, try to find user by employee_id (most reliable identifier)
if ($hasEmployeeIdColumn && !empty($employeeId)) {
    $selectSql = "SELECT " . implode(', ', $selectFields) . " FROM users WHERE employee_id = ? LIMIT 1";
    $stmt = $conn->prepare($selectSql);
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        debugLog("User found by employee_id", ['employee_id' => $employeeId, 'user_id' => $user['id']]);
    }
}

// If not found by employee_id, try email
if (!$user && $hasEmailColumn && !empty($email)) {
    $selectSql = "SELECT " . implode(', ', $selectFields) . " FROM users WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($selectSql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        debugLog("User found by email", ['email' => $email, 'user_id' => $user['id']]);
    }
}

// If not found by email, try username
if (!$user) {
    $selectSql = "SELECT " . implode(', ', $selectFields) . " FROM users WHERE username = ? LIMIT 1";
    $stmt = $conn->prepare($selectSql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        debugLog("User found by username", ['username' => $username, 'user_id' => $user['id']]);
    }
}

// If not found by username, try oauth_sub
if (!$user && $hasOauthSubColumn && isset($userInfo['sub'])) {
    $oauthSub = is_string($userInfo['sub']) ? $userInfo['sub'] : (string)$userInfo['sub'];
    $selectSql = "SELECT " . implode(', ', $selectFields) . " FROM users WHERE oauth_sub = ? LIMIT 1";
    $stmt = $conn->prepare($selectSql);
    $stmt->bind_param("s", $oauthSub);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        debugLog("User found by oauth_sub", ['oauth_sub' => $oauthSub, 'user_id' => $user['id']]);
    }
}

if ($user) {
    // User exists - update ALL user information from OAuth provider on every login
    $userId = $user['id'];
    
    // Build update fields - ALWAYS update all available columns (HR is source of truth)
    $updateFields = [];
    $updateParams = [];
    $updateTypes = '';
    
    // Check if employee_id exists in database - if so, compare values and update only if different
    $needsUpdate = false;
    if ($hasEmployeeIdColumn && !empty($employeeId) && !empty($user['employee_id'])) {
        // Employee ID exists - compare all values and update only if different
        $needsUpdate = true;
        debugLog("Employee ID exists in database - comparing values for updates", [
            'employee_id' => $employeeId,
            'current_username' => $user['username'] ?? 'NULL',
            'new_username' => $username ?? 'NULL',
            'current_email' => $user['email'] ?? 'NULL',
            'new_email' => $email ?? 'NULL',
            'current_fullname' => $user['fullname'] ?? 'NULL',
            'new_fullname' => $fullname ?? 'NULL'
        ]);
    } else {
        // No employee_id match or new user - always update
        $needsUpdate = true;
        debugLog("No employee_id match or new user - will update all fields");
    }
    
    // Always update email if column exists and email is available (and different if employee_id exists)
    if ($hasEmailColumn && !empty($email)) {
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user['email'] ?? '') !== $email) {
            $updateFields[] = "email = ?";
            $updateParams[] = $email;
            $updateTypes .= 's';
            debugLog("Email synced from SSO", [
                'old' => $user['email'] ?? 'NULL',
                'new' => $email
            ]);
        }
    }
    
    // Always update fullname if column exists and fullname is available (and different if employee_id exists)
    if ($hasFullnameColumn && !empty($fullname)) {
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user['fullname'] ?? '') !== $fullname) {
            $updateFields[] = "fullname = ?";
            $updateParams[] = $fullname;
            $updateTypes .= 's';
            debugLog("Fullname synced from SSO", [
                'old' => $user['fullname'] ?? 'NULL',
                'new' => $fullname
            ]);
        }
    }
    
    // Always update username from 'name' field in userinfo
    if (!empty($username)) {
        // Only update if different from current value
        if (($user['username'] ?? '') !== $username) {
            $updateFields[] = "username = ?";
            $updateParams[] = $username;
            $updateTypes .= 's';
            debugLog("Username synced from SSO", [
                'old' => $user['username'] ?? 'NULL',
                'new' => $username
            ]);
        }
    }
    
    // Sync role on every SSO login (HR is source of truth) - update only if different when employee_id exists
    if ($hasRoleColumn && $userRole !== null) {
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user[$roleColumnName] ?? '') !== $userRole) {
            $updateFields[] = "$roleColumnName = ?";
            $updateParams[] = $userRole;
            $updateTypes .= 's';
            debugLog("Role synced from SSO", [
                'old' => $user[$roleColumnName] ?? 'NULL',
                'new' => $userRole
            ]);
        }
    }
    
    // Sync coordinator_type if it's set - update only if different when employee_id exists
    if (isset($coordinator_type)) {
        $checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
        $hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;
        
        if ($hasCoordTypeColumn) {
            if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user['coordinator_type'] ?? null) !== $coordinator_type) {
                $updateFields[] = "coordinator_type = ?";
                $updateParams[] = $coordinator_type;
                $updateTypes .= 's';
                debugLog("Coordinator type synced from SSO", [
                    'old' => $user['coordinator_type'] ?? 'NULL',
                    'new' => $coordinator_type
                ]);
            }
        }
    }
    
    // Sync position/designation if it exists in userinfo - update only if different when employee_id exists
    if ($hasPositionColumn && $positionColumnName && !empty($userPosition)) {
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user[$positionColumnName] ?? '') !== $userPosition) {
            $updateFields[] = "$positionColumnName = ?";
            $updateParams[] = $userPosition;
            $updateTypes .= 's';
            debugLog("Position/designation synced from SSO", [
                'old' => $user[$positionColumnName] ?? 'NULL',
                'new' => $userPosition
            ]);
        }
    }
    
    // Sync employee_id if it exists - update only if different
    if ($hasEmployeeIdColumn && !empty($employeeId)) {
        if (($user['employee_id'] ?? '') !== $employeeId) {
            $updateFields[] = "employee_id = ?";
            $updateParams[] = $employeeId;
            $updateTypes .= 's';
            debugLog("Employee ID synced from SSO", [
                'old' => $user['employee_id'] ?? 'NULL',
                'new' => $employeeId
            ]);
        }
    }
    
    // Sync parent_unit - update only if different when employee_id exists
    if ($hasParentUnitColumn && !empty($parentUnitForDB)) {
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user['parent_unit'] ?? '') !== $parentUnitForDB) {
            $updateFields[] = "parent_unit = ?";
            $updateParams[] = $parentUnitForDB;
            $updateTypes .= 's';
            debugLog("Parent unit synced from SSO", [
                'old' => $user['parent_unit'] ?? 'NULL',
                'new' => $parentUnitForDB
            ]);
        }
    }
    
    // Sync OAuth fields on every SSO login (HR is source of truth) - always update oauth_sub and last_oauth_login_at
    $oauthSub = $userInfo['sub'] ?? null;
    $clientRoleRaw = $userInfo['client_role'] ?? null;
    if ($hasOauthSubColumn && $oauthSub !== null) {
        $oauthSubStr = is_string($oauthSub) ? $oauthSub : (string)$oauthSub;
        // Always update oauth_sub if different
        if (($user['oauth_sub'] ?? '') !== $oauthSubStr) {
            $updateFields[] = "oauth_sub = ?";
            $updateParams[] = $oauthSubStr;
            $updateTypes .= 's';
            debugLog("OAuth sub synced from SSO", [
                'old' => $user['oauth_sub'] ?? 'NULL',
                'new' => $oauthSubStr
            ]);
        }
    }
    if ($hasOauthClientRoleColumn) {
        $clientRoleValue = $clientRoleRaw !== null ? trim((string)$clientRoleRaw) : null;
        // Update only if different when employee_id exists
        if (!$hasEmployeeIdColumn || empty($user['employee_id']) || ($user['oauth_client_role'] ?? null) !== $clientRoleValue) {
            $updateFields[] = "oauth_client_role = ?";
            $updateParams[] = $clientRoleValue;
            $updateTypes .= 's';
            debugLog("OAuth client role synced from SSO", [
                'old' => $user['oauth_client_role'] ?? 'NULL',
                'new' => $clientRoleValue
            ]);
        }
    }
    // Always update last_oauth_login_at on every login
    if ($hasLastOauthLoginColumn) {
        $updateFields[] = "last_oauth_login_at = ?";
        $updateParams[] = date('Y-m-d H:i:s');
        $updateTypes .= 's';
        debugLog("Last OAuth login timestamp updated");
    }
    
    // Always execute update on every login - sync all columns from HR (source of truth)
    if (!empty($updateFields)) {
        // Use employee_id in WHERE clause if available (most reliable), otherwise use user id
        if ($hasEmployeeIdColumn && !empty($employeeId)) {
            $updateParams[] = $employeeId;
            $updateTypes .= 's';
            $updateSql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE employee_id = ?";
            debugLog("Updating user by employee_id", ['employee_id' => $employeeId]);
        } else {
            $updateParams[] = $userId;
            $updateTypes .= 'i';
            $updateSql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
            debugLog("Updating user by id", ['user_id' => $userId]);
        }
        
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param($updateTypes, ...$updateParams);
        $updateStmt->execute();
        $updateStmt->close();
        
        debugLog("User information synced from OAuth provider (all columns updated)", [
            'user_id' => $userId,
            'employee_id' => $employeeId ?? 'N/A',
            'username' => $user['username'],
            'fields_updated' => count($updateFields),
            'role' => $userRole,
            'coordinator_type' => $coordinator_type ?? null
        ]);
    } else {
        debugLog("No update fields to sync (all columns may already be up to date)", ['user_id' => $userId]);
    }
    
} else {
    // Create new user
    $randomPassword = bin2hex(random_bytes(32));
    
    debugLog("Creating new user", [
        'username' => $username, 
        'role' => $userRole,
        'coordinator_type' => $coordinator_type ?? null
    ]);
    
    // Check if coordinator_type column exists
    $checkCoordTypeColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
    $hasCoordTypeColumn = $checkCoordTypeColumn->num_rows > 0;
    
    // Build INSERT statement based on available columns
    $columns = ['username', 'password'];
    $values = [$username, password_hash($randomPassword, PASSWORD_DEFAULT)];
    $types = 'ss';
    
    if ($hasEmailColumn) {
        $columns[] = 'email';
        $values[] = $email;
        $types .= 's';
    }
    
    if ($hasFullnameColumn && !empty($fullname)) {
        $columns[] = 'fullname';
        $values[] = $fullname;
        $types .= 's';
    }
    
    if ($hasRoleColumn && $userRole) {
        $columns[] = $roleColumnName;
        $values[] = $userRole;
        $types .= 's';
    }
    
    if ($hasCoordTypeColumn && isset($coordinator_type)) {
        $columns[] = 'coordinator_type';
        $values[] = $coordinator_type;
        $types .= 's';
    }
    
    // Add position/designation if column exists and value is available
    if ($hasPositionColumn && $positionColumnName && !empty($userPosition)) {
        $columns[] = $positionColumnName;
        $values[] = $userPosition;
        $types .= 's';
    }
    
    // Add employee_id if column exists and value is available
    if ($hasEmployeeIdColumn && !empty($employeeId)) {
        $columns[] = 'employee_id';
        $values[] = $employeeId;
        $types .= 's';
    }
    
    // Add parent_unit if column exists and value is available
    if ($hasParentUnitColumn && !empty($parentUnitForDB)) {
        $columns[] = 'parent_unit';
        $values[] = $parentUnitForDB;
        $types .= 's';
    }
    
    // OAuth SSO fields (per SSO Integration Guide)
    if ($hasOauthSubColumn && isset($userInfo['sub'])) {
        $columns[] = 'oauth_sub';
        $values[] = is_string($userInfo['sub']) ? $userInfo['sub'] : (string)$userInfo['sub'];
        $types .= 's';
    }
    if ($hasOauthClientRoleColumn && isset($userInfo['client_role'])) {
        $columns[] = 'oauth_client_role';
        $values[] = trim((string)$userInfo['client_role']);
        $types .= 's';
    }
    if ($hasLastOauthLoginColumn) {
        $columns[] = 'last_oauth_login_at';
        $values[] = date('Y-m-d H:i:s');
        $types .= 's';
    }
    
    $placeholders = str_repeat('?,', count($columns) - 1) . '?';
    $sql = "INSERT INTO users (" . implode(', ', $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$values);
    
    $stmt->execute();
    $userId = $conn->insert_id;
    $stmt->close();
}

// ============================================
// STORE TOKENS USING TokenManager
// ============================================

try {
    $tokenManager = new TokenManager($conn, $userId);
    $tokenManager->storeToken($accessToken, $refreshToken, $expiresIn);
    
    debugLog("Tokens stored successfully", ['user_id' => $userId]);
    
} catch (Exception $e) {
    errorLog("Failed to store tokens", ['error' => $e->getMessage()]);
    // Continue anyway - session token will still work for this session
}

// ============================================
// SET SESSION
// ============================================

$_SESSION['user_id'] = $userId;
$_SESSION['username'] = $username;
$_SESSION['fullname'] = $fullname;
if ($userRole) {
    $_SESSION['user_role'] = $userRole;
}
if (isset($coordinator_type)) {
    $_SESSION['coordinator_type'] = $coordinator_type;
}
$_SESSION['auth_method'] = 'sso';
$_SESSION['hr_system_url'] = $config['provider_url'];
$_SESSION['hr_access_token'] = $accessToken;
$_SESSION['hr_token_expires_at'] = date('Y-m-d H:i:s', time() + $expiresIn);
$_SESSION['hr_employee_id'] = $employeeId;

// Store unit info from userinfo (if available)
$_SESSION['unit'] = $userUnit ?? null;
$_SESSION['unit_name'] = $userUnit ?? null; // Alias for compatibility

// Store parent unit info from userinfo (if available)
$_SESSION['unit_parent_id'] = $userInfo['unit_parent_id'] ?? null;
$_SESSION['unit_parent'] = $userInfo['unit_parent'] ?? null;
$_SESSION['unit_parent_code'] = $userInfo['unit_parent_code'] ?? null;

debugLog("Session established", [
    'user_id' => $userId,
    'username' => $username,
    'role' => $userRole,
    'coordinator_type' => $coordinator_type ?? null,
    'unit' => $userUnit,
    'position' => $userPosition,
    'employee_id' => $employeeId
]);

// Clear OAuth state
unset($_SESSION['oauth_state']);

// Log activity if ActivityLogger exists
if (file_exists('ActivityLogger.php')) {
    try {
        require_once 'ActivityLogger.php';
        $logger = new ActivityLogger($conn, $userId);
        $logger->logLogin($username);
    } catch (Exception $e) {
        debugLog("ActivityLogger error: " . $e->getMessage());
    }
}

// Check if user is an imported researcher and redirect to their profile
$checkImported = $conn->query("SELECT imported, employee_id FROM users WHERE id = $userId LIMIT 1");
if ($checkImported && $checkImported->num_rows > 0) {
    $userData = $checkImported->fetch_assoc();
    debugLog("Checking imported status", [
        'user_id' => $userId,
        'imported' => $userData['imported'] ?? 'NULL',
        'employee_id' => $userData['employee_id'] ?? 'NULL'
    ]);
    
    if (!empty($userData['imported']) && $userData['imported'] == 1) {
        // User is an imported researcher - find their faculty_researcher record
        // Try by user_id first, then fallback to employee_id
        $facultyId = null;
        
        // Method 1: Check by user_id
        $facultyStmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
        $facultyStmt->bind_param("i", $userId);
        $facultyStmt->execute();
        $facultyResult = $facultyStmt->get_result();
        
        if ($facultyResult && $facultyResult->num_rows > 0) {
            $facultyData = $facultyResult->fetch_assoc();
            $facultyId = $facultyData['id'];
            debugLog("Found faculty by user_id", ['faculty_id' => $facultyId]);
        }
        $facultyStmt->close();
        
        // Method 2: Fallback - check by employee_id if user_id didn't work
        if (!$facultyId && !empty($userData['employee_id'])) {
            $facultyStmt2 = $conn->prepare("SELECT id FROM faculty_researchers WHERE hr_employee_id = ? LIMIT 1");
            $facultyStmt2->bind_param("s", $userData['employee_id']);
            $facultyStmt2->execute();
            $facultyResult2 = $facultyStmt2->get_result();
            
            if ($facultyResult2 && $facultyResult2->num_rows > 0) {
                $facultyData2 = $facultyResult2->fetch_assoc();
                $facultyId = $facultyData2['id'];
                debugLog("Found faculty by employee_id", ['faculty_id' => $facultyId, 'employee_id' => $userData['employee_id']]);
                
                // Update the faculty_researcher record to link user_id
                $updateStmt = $conn->prepare("UPDATE faculty_researchers SET user_id = ? WHERE id = ?");
                $updateStmt->bind_param("ii", $userId, $facultyId);
                $updateStmt->execute();
                $updateStmt->close();
                debugLog("Linked user_id to faculty_researcher", ['user_id' => $userId, 'faculty_id' => $facultyId]);
            }
            $facultyStmt2->close();
        }
        
        if ($facultyId) {
            debugLog("Redirecting imported researcher to profile", [
                'user_id' => $userId,
                'employee_id' => $userData['employee_id'] ?? 'N/A',
                'faculty_id' => $facultyId,
                'redirect_url' => 'facultyresearcherprofile.php?id=' . $facultyId
            ]);
            
            // Ensure no output before redirect
            if (ob_get_level()) {
                ob_end_clean();
            }
            
            // Redirect to faculty researcher profile
            header("Location: facultyresearcherprofile.php?id=" . $facultyId);
            exit;
        } else {
            debugLog("Imported researcher found but no faculty record linked", [
                'user_id' => $userId,
                'employee_id' => $userData['employee_id'] ?? 'N/A',
                'searched_by_user_id' => true,
                'searched_by_employee_id' => !empty($userData['employee_id'])
            ]);
        }
    }
}

// Redirect to home page
header("Location: index.php");
exit;