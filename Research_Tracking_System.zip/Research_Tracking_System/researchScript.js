// researchScript.js - Enhanced Chart configurations for Research Dashboard

// Chart.js Global Configuration
Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.padding = 15;

// Color Palette
const colors = {
    faculty: 'rgba(6, 78, 26, 0.8)',
    facultyBorder: 'rgb(6, 78, 26)',
    student: 'rgba(139, 92, 246, 0.8)',
    studentBorder: 'rgb(139, 92, 246)',
    ongoing: 'rgba(245, 158, 11, 0.85)',
    completed: 'rgba(16, 185, 129, 0.85)',
    published: 'rgba(37, 99, 235, 0.85)',
    pending: 'rgba(156, 163, 175, 0.85)',
    accepted: 'rgba(16, 185, 129, 0.85)',
    needs_revision: 'rgba(245, 158, 11, 0.85)',
    rejected: 'rgba(239, 68, 68, 0.85)',
    gradient: [
        'rgba(6, 78, 26, 0.9)',
        'rgba(11, 106, 36, 0.9)',
        'rgba(46, 139, 87, 0.9)',
        'rgba(60, 179, 113, 0.9)',
        'rgba(102, 205, 170, 0.9)',
        'rgba(143, 188, 143, 0.9)',
        'rgba(144, 238, 144, 0.9)',
        'rgba(152, 251, 152, 0.9)'
    ]
};

// Animation Configuration
const animationConfig = {
    duration: 1500,
    easing: 'easeInOutQuart',
    delay: (context) => {
        let delay = 0;
        if (context.type === 'data' && context.mode === 'default') {
            delay = context.dataIndex * 100;
        }
        return delay;
    }
};

// Common tooltip configuration
const tooltipConfig = {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    padding: 12,
    titleFont: { size: 14, weight: 'bold' },
    bodyFont: { size: 13 },
    cornerRadius: 8
};

// Faculty Research Outputs Status Chart
function createFacultyOutputsChart(data) {
    const ctx = document.getElementById('facultyOutputsChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Review', 'Accepted', 'Needs Revision', 'Rejected'],
            datasets: [{
                data: [data.pending, data.accepted, data.needs_revision, data.rejected],
                backgroundColor: [colors.pending, colors.accepted, colors.needs_revision, colors.rejected],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Student Research Outputs Status Chart
function createStudentOutputsChart(data) {
    const ctx = document.getElementById('studentOutputsChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Review', 'Accepted', 'Needs Revision', 'Rejected'],
            datasets: [{
                data: [data.pending, data.accepted, data.needs_revision, data.rejected],
                backgroundColor: [colors.pending, colors.accepted, colors.needs_revision, colors.rejected],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Funding Distribution Chart
function createFundingChart(data) {
    const ctx = document.getElementById('fundingChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Institution Fund', 'Government Fund', 'Private Fund', 'Foreign Fund', 'Other Sources'],
            datasets: [{
                data: [data.institution, data.government, data.private, data.foreign, data.other],
                backgroundColor: colors.gradient,
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 15, font: { size: 12, weight: '600' } }
                },
                tooltip: {
                    ...tooltipConfig,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) label += ': ';
                            label += '₱' + context.parsed.toLocaleString('en-US', {
                                minimumFractionDigits: 2, 
                                maximumFractionDigits: 2
                            });
                            return label;
                        }
                    }
                }
            }
        }
    });
}

// Research Category Distribution Chart
function createCategoryChart(labels, data) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Number of Projects',
                data: data,
                backgroundColor: colors.gradient,
                borderWidth: 0,
                borderRadius: 8,
                barThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: { display: false },
                tooltip: tooltipConfig
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                x: {
                    ticks: { font: { size: 12, weight: '600' } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Global chart instance
let trendChartInstance = null;
let currentTimeRange = '30days';

// Enhanced Trend Chart with Interactive Features
function createEnhancedTrendChart(labels, facultyData, studentData, facultyOutputsData, studentOutputsData, showFaculty, showStudent) {
    const ctx = document.getElementById('trendChart');
    if (!ctx) {
        console.error('Trend chart canvas not found');
        return;
    }
    
    // Destroy existing chart
    if (trendChartInstance) {
        trendChartInstance.destroy();
        trendChartInstance = null;
    }
    
    const datasets = [];
    
    if (showFaculty) {
        datasets.push({
            label: 'Faculty Research',
            data: facultyData,
            borderColor: 'rgb(6, 78, 26)',
            backgroundColor: 'rgba(6, 78, 26, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(6, 78, 26)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Faculty Outputs',
            data: facultyOutputsData,
            borderColor: 'rgb(16, 185, 129)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(16, 185, 129)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    if (showStudent) {
        datasets.push({
            label: 'Student Research',
            data: studentData,
            borderColor: 'rgb(139, 92, 246)',
            backgroundColor: 'rgba(139, 92, 246, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(139, 92, 246)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Student Outputs',
            data: studentOutputsData,
            borderColor: 'rgb(245, 158, 11)',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(245, 158, 11)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    trendChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 1500, easing: 'easeInOutQuart' },
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        stepSize: 1, 
                        font: { size: 13, weight: '600' },
                        callback: function(value) {
                            return Number.isInteger(value) ? value : '';
                        }
                    },
                    title: { 
                        display: true, 
                        text: 'Number of Research Items', 
                        font: { size: 14, weight: 'bold' } 
                    },
                    grid: { color: 'rgba(0, 0, 0, 0.06)' }
                },
                x: {
                    ticks: { font: { size: 12, weight: '600' } },
                    title: { 
                        display: true, 
                        text: 'Time Period', 
                        font: { size: 14, weight: 'bold' } 
                    },
                    grid: { display: false }
                }
            }
        }
    });
}

// Load trend data via AJAX
function loadTrendData(timeRange) {
    const chartContainer = document.querySelector('#trendChart');
    if (!chartContainer) return;
    
    const parentContainer = chartContainer.parentElement;
    const loadingElement = document.querySelector('.chart-loading');
    
    // Show loading state
    parentContainer.classList.add('loading');
    if (loadingElement) loadingElement.classList.add('active');
    
    // Update active button
    document.querySelectorAll('.time-filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    const activeBtn = document.querySelector(`[data-range="${timeRange}"]`);
    if (activeBtn) activeBtn.classList.add('active');
    
    fetch(`get_trend_data.php?range=${timeRange}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }
            return response.text();
        })
        .then(text => {
            console.log('Raw response (first 200 chars):', text.substring(0, 200));
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('JSON Parse Error:', e);
                console.error('Full response:', text);
                throw new Error('Invalid JSON from server');
            }
            
            // Update statistics
            updateStatistics(data.statistics);
            
            // Update chart
            const showFaculty = data.faculty.some(val => val > 0) || data.facultyOutputs.some(val => val > 0);
            const showStudent = data.student.some(val => val > 0) || data.studentOutputs.some(val => val > 0);
            
            createEnhancedTrendChart(
                data.labels,
                data.faculty,
                data.student,
                data.facultyOutputs,
                data.studentOutputs,
                showFaculty,
                showStudent
            );
            
            // Hide loading state
            parentContainer.classList.remove('loading');
            if (loadingElement) loadingElement.classList.remove('active');
        })
        .catch(error => {
            console.error('Error loading trend data:', error);
            parentContainer.classList.remove('loading');
            if (loadingElement) loadingElement.classList.remove('active');
            
            const statsContainer = document.querySelector('.trend-statistics');
            if (statsContainer) {
                statsContainer.innerHTML = `
                    <div class="trend-stat-item" style="grid-column: 1/-1; background: #fee2e2; color: #991b1b;">
                        <div class="trend-stat-icon"><i class="fa fa-exclamation-triangle"></i></div>
                        <div class="trend-stat-label">Failed to load data. Check browser console.</div>
                    </div>
                `;
            }
        });
}

// Update statistics display
function updateStatistics(stats) {
    const statsContainer = document.querySelector('.trend-statistics');
    if (!statsContainer) return;
    
    let html = '';
    
    if (stats.faculty && (stats.faculty.total > 0 || stats.faculty.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-chalkboard-teacher"></i></div>
                <div class="trend-stat-value">${stats.faculty.total}</div>
                <div class="trend-stat-label">Faculty Projects</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.faculty.pending}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.faculty.accepted}</div>
                <div class="trend-stat-label">Accepted</div>
            </div>
        `;
    }
    
    if (stats.student && (stats.student.total > 0 || stats.student.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-user-graduate"></i></div>
                <div class="trend-stat-value">${stats.student.total}</div>
                <div class="trend-stat-label">Student Research</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.student.pending}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.student.accepted}</div>
                <div class="trend-stat-label">Accepted</div>
            </div>
        `;
    }
    
    if (html === '') {
        html = '<div class="trend-stat-item"><div class="trend-stat-label">No data for this time range</div></div>';
    }
    
    statsContainer.innerHTML = html;
}

// Overall Status Chart
function createOverallStatusChart(ongoing, completed, published) {
    const ctx = document.getElementById('overallStatusChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['On-going', 'Completed', 'Published'],
            datasets: [{
                data: [ongoing, completed, published],
                backgroundColor: [colors.ongoing, colors.completed, colors.published],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Faculty Status Chart
function createFacultyStatusChart(ongoing, completed, published) {
    const ctx = document.getElementById('facultyStatusChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['On-going', 'Completed', 'Published'],
            datasets: [{
                data: [ongoing, completed, published],
                backgroundColor: [colors.ongoing, colors.completed, colors.published],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Student Status Chart
function createStudentStatusChart(ongoing, completed, published) {
    const ctx = document.getElementById('studentStatusChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['On-going', 'Completed', 'Published'],
            datasets: [{
                data: [ongoing, completed, published],
                backgroundColor: [colors.ongoing, colors.completed, colors.published],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Faculty by Department Chart
function createFacultyDeptChart(labels, data) {
    const ctx = document.getElementById('facultyDeptChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Faculty Count',
                data: data,
                backgroundColor: colors.faculty,
                borderRadius: 8,
                barThickness: 30
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: { display: false },
                tooltip: tooltipConfig
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                y: {
                    ticks: { font: { size: 11, weight: '600' } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Students by Department Chart
function createStudentDeptChart(labels, data) {
    const ctx = document.getElementById('studentDeptChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Student Count',
                data: data,
                backgroundColor: colors.student,
                borderRadius: 8,
                barThickness: 30
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: { display: false },
                tooltip: tooltipConfig
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                y: {
                    ticks: { font: { size: 11, weight: '600' } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Export chart
function exportTrendChart() {
    if (trendChartInstance) {
        const url = trendChartInstance.toBase64Image();
        const link = document.createElement('a');
        link.download = `research-trends-${currentTimeRange}-${new Date().toISOString().split('T')[0]}.png`;
        link.href = url;
        link.click();
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing Research Dashboard...');
    
    // Time filter buttons
    document.querySelectorAll('.time-filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            currentTimeRange = this.getAttribute('data-range');
            loadTrendData(currentTimeRange);
        });
    });
    
    // Load trend chart
    if (document.getElementById('trendChart')) {
        loadTrendData(currentTimeRange);
    }
    
    // Initialize other charts
    if (typeof window.dashboardData === 'undefined') {
        console.error('❌ window.dashboardData not found');
        return;
    }
    
    const data = window.dashboardData;
    
    if (data.showFaculty && data.facultyOutputsStats) {
        const total = Object.values(data.facultyOutputsStats).reduce((a, b) => a + b, 0);
        if (total > 0) createFacultyOutputsChart(data.facultyOutputsStats);
    }
    
    if (data.showStudent && data.studentOutputsStats) {
        const total = Object.values(data.studentOutputsStats).reduce((a, b) => a + b, 0);
        if (total > 0) createStudentOutputsChart(data.studentOutputsStats);
    }
    
    if (data.showFaculty && data.fundingTotal > 0) {
        createFundingChart(data.fundingAllocated);
    }
    
    if (data.showFaculty && data.researchCategories?.length > 0) {
        const labels = data.researchCategories.map(i => i.classification);
        const counts = data.researchCategories.map(i => i.count);
        createCategoryChart(labels, counts);
    }
    
    if (data.userRole === 'admin') {
        createOverallStatusChart(data.totalOngoing, data.totalCompleted, data.totalPublished);
    }
    
    if (data.showFaculty && data.facultyStats) {
        createFacultyStatusChart(data.facultyStats.ongoing, data.facultyStats.completed, data.facultyStats.published);
    }
    
    if (data.showStudent && data.studentStats) {
        createStudentStatusChart(data.studentStats.ongoing, data.studentStats.completed, data.studentStats.published);
    }
    
    if (data.showFaculty && data.facultyByDept?.length > 0) {
        const labels = data.facultyByDept.map(i => i.department);
        const counts = data.facultyByDept.map(i => i.count);
        createFacultyDeptChart(labels, counts);
    }
    
    if (data.showStudent && data.studentByDept?.length > 0) {
        const labels = data.studentByDept.map(i => i.department);
        const counts = data.studentByDept.map(i => i.count);
        createStudentDeptChart(labels, counts);
    }
    
    console.log('✅ Dashboard initialized');
});
