-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2026 at 12:03 PM
-- Server version: 11.7.2-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `research_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` enum('create','update','delete','view','export','login','logout') NOT NULL,
  `table_affected` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

-- --------------------------------------------------------

--
-- Table structure for table `coordinator_assignments`
--

CREATE TABLE `coordinator_assignments` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `coordinator_type` enum('faculty','student') NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coordinator_assignments`
--

INSERT INTO `coordinator_assignments` (`id`, `employee_id`, `coordinator_type`, `assigned_by`, `assigned_at`, `updated_at`, `status`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `faculty_education`
--

CREATE TABLE `faculty_education` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `degree_program` varchar(255) DEFAULT NULL,
  `college_university` varchar(255) DEFAULT NULL,
  `has_thesis` enum('Yes','No') DEFAULT 'No',
  `year_graduated` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_projects`
--

CREATE TABLE `faculty_projects` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `project_status` enum('on-going','completed','published') DEFAULT 'on-going',
  `classification` varchar(100) DEFAULT NULL,
  `funding_source` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `parent_project_id` int(11) DEFAULT NULL,
  `is_project_leader` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_projects`
--

INSERT INTO `faculty_projects` (`id`, `faculty_id`, `title`, `project_status`, `classification`, `funding_source`, `nature_of_involvement`, `start_date`, `end_date`, `parent_project_id`, `is_project_leader`, `created_at`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_costs`
--

CREATE TABLE `faculty_project_costs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_project_costs`
--

INSERT INTO `faculty_project_costs` (`id`, `project_id`, `item_of_expenditure`, `institution_fund`, `government_fund`, `government_fund_source`, `private_fund`, `private_fund_source`, `foreign_fund`, `foreign_fund_source`, `other_sources`, `other_sources_name`, `created_at`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_team`
--

CREATE TABLE `faculty_project_team` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` varchar(50) DEFAULT NULL,
  `highest_attainment` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_researchers`
--

CREATE TABLE `faculty_researchers` (
  `id` int(11) NOT NULL,
  `hr_employee_id` varchar(50) DEFAULT NULL,
  `faculty_number` varchar(50) DEFAULT NULL,
  `last_name` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` enum('Full-Time','Part-Time') DEFAULT 'Full-Time',
  `home_unit` varchar(150) DEFAULT NULL,
  `department` varchar(150) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `user_id` int(11) DEFAULT NULL COMMENT 'References users.id for imported researchers',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_synced_at` datetime DEFAULT NULL,
  `is_synced` tinyint(1) DEFAULT 0,
  `sync_status` enum('synced','needs-sync','not-synced','n/a') DEFAULT 'not-synced' COMMENT 'n/a when employee deleted or not in same unit',
  `hr_data_json` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_researchers`
--

INSERT INTO `faculty_researchers` (`id`, `hr_employee_id`, `faculty_number`, `last_name`, `first_name`, `middle_name`, `home_address`, `telephone`, `fax`, `email`, `faculty_rank`, `employment_status`, `home_unit`, `department`, `profile_pic`, `created_by`, `user_id`, `created_at`, `last_synced_at`, `is_synced`, `sync_status`, `hr_data_json`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `faculty_research_outputs`
--

CREATE TABLE `faculty_research_outputs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL,
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hr_sync_history`
--

CREATE TABLE `hr_sync_history` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `action_type` enum('import','update') NOT NULL,
  `hr_employee_id` varchar(100) DEFAULT NULL,
  `synced_by` int(11) NOT NULL,
  `synced_at` timestamp NULL DEFAULT current_timestamp(),
  `data_snapshot` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_settings`
--

CREATE TABLE `oauth_settings` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `is_secret` tinyint(1) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oauth_settings`
--

INSERT INTO `oauth_settings` (`id`, `key`, `value`, `is_secret`, `updated_at`) VALUES
(1, 'provider_url', 'https://hr-production-eaf1.up.railway.app', 0, '2026-02-03 10:28:05'),
(2, 'client_id', '019c18b6-934c-73e8-8b73-e44d2186b391', 0, '2026-02-03 10:28:05'),
(3, 'client_secret', 'FdKZe0cLwxTL8IAwBUkr81yMOgsPiHF7OzsqUiL6', 1, '2026-02-03 10:28:05'),
(4, 'redirect_uri', 'https://erp-rms.42web.io/oauth_callback.php', 0, '2026-02-03 11:03:06');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_tokens`
--

CREATE TABLE `oauth_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_token` text NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `token_type` varchar(50) DEFAULT 'Bearer',
  `expires_at` datetime NOT NULL,
  `scope` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oauth_tokens`
--

INSERT INTO `oauth_tokens` (`id`, `user_id`, `access_token`, `refresh_token`, `token_type`, `expires_at`, `scope`, `created_at`, `updated_at`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `research_outputs`
--

CREATE TABLE `research_outputs` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `project_leader` varchar(150) DEFAULT NULL,
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `status` enum('on-going','completed','published') DEFAULT 'on-going',
  `parent_project_id` int(11) DEFAULT NULL COMMENT 'References parent research',
  `is_project_leader` tinyint(1) DEFAULT 1 COMMENT '1 = leader, 0 = member',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_researchers`
--

CREATE TABLE `student_researchers` (
  `id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `research_adviser` varchar(150) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_costs`
--

CREATE TABLE `student_research_costs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_outputs`
--

CREATE TABLE `student_research_outputs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL COMMENT 'References student_researchers.id',
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_team`
--

CREATE TABLE `student_research_team` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL COMMENT 'e.g., Co-Researcher, Research Assistant',
  `department` varchar(150) DEFAULT NULL,
  `contribution` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `synced_research_coordinators`
--

CREATE TABLE `synced_research_coordinators` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `full_name` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `position_name` varchar(255) DEFAULT '',
  `unit_name` varchar(255) DEFAULT '',
  `sector_name` varchar(255) DEFAULT '',
  `synced_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `synced_research_coordinators`
--

INSERT INTO `synced_research_coordinators` (`id`, `employee_id`, `full_name`, `email`, `position_name`, `unit_name`, `sector_name`, `synced_at`) VALUES

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fullname` varchar(155) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `oauth_sub` varchar(255) DEFAULT NULL,
  `oauth_client_role` varchar(20) DEFAULT NULL,
  `last_oauth_login_at` timestamp NULL DEFAULT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `coordinator_type` enum('student','faculty') DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `employee_id` varchar(100) DEFAULT NULL,
  `parent_unit` varchar(255) DEFAULT NULL,
  `imported` tinyint(1) DEFAULT 0 COMMENT '1 if imported as researcher, 0 otherwise',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `fullname`, `email`, `password`, `oauth_sub`, `oauth_client_role`, `last_oauth_login_at`, `user_role`, `coordinator_type`, `position`, `employee_id`, `parent_unit`, `imported`, `created_at`) VALUES
(0, 'admin', '', NULL, '$2y$10$2xo.BpK7V3Frh9BehejFpOZ/9JHPAPsN5vsIwdOGPdWSimsQSv5G6', NULL, NULL, NULL, 'admin', NULL, NULL, NULL, NULL, 0, '2026-02-01 04:50:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_table_affected` (`table_affected`);

--
-- Indexes for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_employee_coordinator` (`employee_id`,`coordinator_type`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_coordinator_type` (`coordinator_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `fk_coordinator_assigned_by` (`assigned_by`);

--
-- Indexes for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_faculty_education` (`faculty_id`);

--
-- Indexes for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_faculty_projects` (`faculty_id`);

--
-- Indexes for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_costs` (`project_id`);

--
-- Indexes for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_team` (`project_id`);

--
-- Indexes for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faculty_number` (`faculty_number`),
  ADD UNIQUE KEY `unique_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_is_synced` (`is_synced`),
  ADD KEY `idx_last_synced` (`last_synced_at`);

--
-- Indexes for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_latest` (`project_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_faculty_output_uploader` (`uploaded_by`),
  ADD KEY `fk_faculty_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_faculty_output_parent` (`parent_output_id`);

--
-- Indexes for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_faculty` (`faculty_id`),
  ADD KEY `idx_synced_at` (`synced_at`);

--
-- Indexes for table `oauth_settings`
--
ALTER TABLE `oauth_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_token` (`user_id`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_student_research` (`student_id`);

--
-- Indexes for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_student_created_by` (`created_by`);

--
-- Indexes for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_costs` (`research_id`);

--
-- Indexes for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_latest` (`research_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_student_output_uploader` (`uploaded_by`),
  ADD KEY `fk_student_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_student_output_parent` (`parent_output_id`);

--
-- Indexes for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_id` (`research_id`);

--
-- Indexes for table `synced_research_coordinators`
--
ALTER TABLE `synced_research_coordinators`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_employee_id` (`employee_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_users_oauth_sub` (`oauth_sub`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_parent_unit` (`parent_unit`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=579;

--
-- AUTO_INCREMENT for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `faculty_education`
--
ALTER TABLE `faculty_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `oauth_settings`
--
ALTER TABLE `oauth_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `research_outputs`
--
ALTER TABLE `research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_researchers`
--
ALTER TABLE `student_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_team`
--
ALTER TABLE `student_research_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `synced_research_coordinators`
--
ALTER TABLE `synced_research_coordinators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD CONSTRAINT `fk_coordinator_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD CONSTRAINT `fk_faculty_education` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD CONSTRAINT `fk_faculty_projects` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD CONSTRAINT `fk_project_costs` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD CONSTRAINT `fk_project_team` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD CONSTRAINT `fk_faculty_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD CONSTRAINT `fk_faculty_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `faculty_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_faculty_output_project` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_faculty_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_faculty_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `faculty_researchers` (`id`);

--
-- Constraints for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD CONSTRAINT `hr_sync_history_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD CONSTRAINT `oauth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD CONSTRAINT `fk_parent_research` FOREIGN KEY (`parent_project_id`) REFERENCES `research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_research` FOREIGN KEY (`student_id`) REFERENCES `student_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD CONSTRAINT `fk_student_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD CONSTRAINT `fk_research_costs` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD CONSTRAINT `fk_student_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `student_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_output_research` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_student_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_student_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `student_researchers` (`id`);

--
-- Constraints for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD CONSTRAINT `fk_research_team` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;