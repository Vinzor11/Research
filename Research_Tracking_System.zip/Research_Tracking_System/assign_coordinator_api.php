<?php
/**
 * Coordinator Assignment API
 * Handles assigning and removing coordinators
 */

session_start();
require 'db.php';
require 'config.php';

header('Content-Type: application/json');

/**
 * Update users.coordinator_type for the user with the given employee_id.
 * @param mysqli $conn
 * @param string $employeeId
 * @param string|null $coordinatorType 'faculty', 'student', or null to clear
 */
function updateUserCoordinatorType($conn, $employeeId, $coordinatorType) {
    $hasEmployeeId = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'")->num_rows > 0;
    $hasCoordType = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'")->num_rows > 0;
    if (!$hasEmployeeId || !$hasCoordType) return;
    $normalizedId = normalizeEmployeeId($employeeId);
    if ($coordinatorType === null) {
        $stmt = $conn->prepare("UPDATE users SET coordinator_type = NULL WHERE employee_id = ?");
        $stmt->bind_param("s", $normalizedId);
    } else {
        $stmt = $conn->prepare("UPDATE users SET coordinator_type = ? WHERE employee_id = ?");
        $stmt->bind_param("ss", $coordinatorType, $normalizedId);
    }
    $stmt->execute();
    $stmt->close();
}

// Admin only access
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? null) !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
$action = $_POST['action'] ?? '';
$employeeId = $_POST['employee_id'] ?? '';
$coordinatorType = $_POST['coordinator_type'] ?? '';

if (empty($action) || empty($employeeId) || empty($coordinatorType)) {
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}

if (!in_array($coordinatorType, ['faculty', 'student'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid coordinator type']);
    exit;
}

// Validate that the user exists in the users table
if (empty($userId)) {
    echo json_encode(['success' => false, 'error' => 'User session invalid']);
    exit;
}

// Ensure userId is an integer
$userId = (int)$userId;
if ($userId <= 0) {
    errorLog("Coordinator Assignment - Invalid user ID", ['user_id' => $_SESSION['user_id'] ?? 'not set']);
    echo json_encode(['success' => false, 'error' => 'Invalid user session. Please log in again.']);
    exit;
}

// Verify user exists in database
$userCheck = $conn->prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1");
$userCheck->bind_param("i", $userId);
$userCheck->execute();
$userResult = $userCheck->get_result()->fetch_assoc();
$userCheck->close();

if (!$userResult) {
    errorLog("Coordinator Assignment - User ID not found in database", [
        'user_id' => $userId,
        'session_user_id' => $_SESSION['user_id'] ?? 'not set'
    ]);
    echo json_encode(['success' => false, 'error' => 'User account not found. Please log out and log in again.']);
    exit;
}

debugLog("Coordinator Assignment - User verified", [
    'user_id' => $userId,
    'username' => $userResult['username'] ?? 'N/A',
    'action' => $action,
    'employee_id' => $employeeId,
    'coordinator_type' => $coordinatorType
]);

try {
    if ($action === 'assign') {
        // Check if already assigned
        $checkStmt = $conn->prepare("
            SELECT id FROM coordinator_assignments 
            WHERE employee_id = ? AND coordinator_type = ? AND status = 'active'
        ");
        $checkStmt->bind_param("ss", $employeeId, $coordinatorType);
        $checkStmt->execute();
        $existing = $checkStmt->get_result()->fetch_assoc();
        $checkStmt->close();
        
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'Coordinator already assigned']);
            exit;
        }
        
        // Insert new assignment
        // First, try to update existing inactive assignment if it exists
        $updateStmt = $conn->prepare("
            UPDATE coordinator_assignments 
            SET status = 'active', 
                assigned_by = ?, 
                assigned_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE employee_id = ? AND coordinator_type = ? AND status = 'inactive'
        ");
        $updateStmt->bind_param("iss", $userId, $employeeId, $coordinatorType);
        $updateStmt->execute();
        $affectedRows = $updateStmt->affected_rows;
        $updateStmt->close();
        
        if ($affectedRows > 0) {
            // Successfully reactivated existing assignment
            updateUserCoordinatorType($conn, $employeeId, $coordinatorType);
            echo json_encode(['success' => true, 'message' => 'Coordinator assigned successfully']);
        } else {
            // Insert new assignment
            $stmt = $conn->prepare("
                INSERT INTO coordinator_assignments (employee_id, coordinator_type, assigned_by, status)
                VALUES (?, ?, ?, 'active')
            ");
            $stmt->bind_param("ssi", $employeeId, $coordinatorType, $userId);
            
            if (!$stmt->execute()) {
                $errorMsg = $stmt->error;
                $stmt->close();
                
                // Check if it's a foreign key constraint error
                if (strpos($errorMsg, 'foreign key constraint') !== false) {
                    errorLog("Coordinator Assignment - Foreign Key Error", [
                        'user_id' => $userId,
                        'employee_id' => $employeeId,
                        'error' => $errorMsg
                    ]);
                    echo json_encode([
                        'success' => false, 
                        'error' => 'Database error: User account not found. Please log out and log in again.'
                    ]);
                } else {
                    throw new Exception($errorMsg);
                }
            } else {
                $stmt->close();
                updateUserCoordinatorType($conn, $employeeId, $coordinatorType);
                echo json_encode(['success' => true, 'message' => 'Coordinator assigned successfully']);
            }
        }
        
    } elseif ($action === 'remove') {
        // Deactivate assignment
        $stmt = $conn->prepare("
            UPDATE coordinator_assignments 
            SET status = 'inactive'
            WHERE employee_id = ? AND coordinator_type = ?
        ");
        $stmt->bind_param("ss", $employeeId, $coordinatorType);
        $stmt->execute();
        $stmt->close();
        
        // If user still has another active coordinator type, keep it; else clear
        $check = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id = ? AND status = 'active' LIMIT 1");
        $check->bind_param("s", $employeeId);
        $check->execute();
        $row = $check->get_result()->fetch_assoc();
        $check->close();
        $newType = $row ? $row['coordinator_type'] : null;
        updateUserCoordinatorType($conn, $employeeId, $newType);
        
        echo json_encode(['success' => true, 'message' => 'Coordinator removed successfully']);
        
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    errorLog("Coordinator Assignment Error", ['error' => $e->getMessage()]);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
