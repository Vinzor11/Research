<?php
// Suppress errors to prevent breaking JSON output
error_reporting(0);
ini_set('display_errors', 0);

session_start();

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

require 'db.php';

// Validate database connection
if (!$conn || $conn->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$timeRange = $_GET['range'] ?? '30days';
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$currentUserId = $_SESSION['user_id'];

$showFaculty = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'faculty');
$showStudent = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'student');

// Build WHERE clauses based on role
$facultyWhereClause = '';
$studentWhereClause = '';

if ($userRole === 'coordinator') {
    // Coordinators only see data they created
    $facultyWhereClause = " AND fr.created_by = " . intval($currentUserId);
    $studentWhereClause = " AND sr.created_by = " . intval($currentUserId);
}
// Admin sees everything (no WHERE clause needed)

// Determine date range and grouping
$dateCondition = '';
$dateFormat = '';
$labels = [];

switch ($timeRange) {
    case '24hours':
        $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
        $dateFormat = '%Y-%m-%d %H:00:00';
        // Generate hourly labels for last 24 hours
        for ($i = 23; $i >= 0; $i--) {
            $labels[] = date('H:00', strtotime("-$i hours"));
        }
        break;
    
    case '7days':
        $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        $dateFormat = '%Y-%m-%d';
        // Generate daily labels for last 7 days
        for ($i = 6; $i >= 0; $i--) {
            $labels[] = date('M d', strtotime("-$i days"));
        }
        break;
    
    case '30days':
    default:
        $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $dateFormat = '%Y-%m-%d';
        // Generate daily labels for last 30 days
        for ($i = 29; $i >= 0; $i--) {
            $labels[] = date('M d', strtotime("-$i days"));
        }
        break;
}

$response = [
    'labels' => $labels,
    'faculty' => [],
    'student' => [],
    'facultyOutputs' => [],
    'studentOutputs' => [],
    'statistics' => [
        'faculty' => ['total' => 0, 'pending' => 0, 'accepted' => 0],
        'student' => ['total' => 0, 'pending' => 0, 'accepted' => 0]
    ]
];

// Initialize data arrays with zeros
foreach ($labels as $label) {
    $response['faculty'][] = 0;
    $response['student'][] = 0;
    $response['facultyOutputs'][] = 0;
    $response['studentOutputs'][] = 0;
}

// Fetch Faculty Data (with role-based filtering)
if ($showFaculty) {
    // Projects trend - JOIN with faculty_researchers to filter by created_by
    $sql = "SELECT DATE_FORMAT(fp.created_at, '$dateFormat') as period, COUNT(*) as count 
            FROM faculty_projects fp
            INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
            WHERE fp.$dateCondition 
            $facultyWhereClause
            GROUP BY period 
            ORDER BY period";
    
    $result = $conn->query($sql);
    if ($result) {
        $facultyData = [];
        while ($row = $result->fetch_assoc()) {
            $facultyData[$row['period']] = (int)$row['count'];
        }
        
        // Research outputs trend - JOIN through projects to faculty_researchers
        $outputDateCondition = str_replace('created_at', 'upload_date', $dateCondition);
        $outputDateCondition = str_replace('fp.', 'fro.', $outputDateCondition);
        
        $sql = "SELECT DATE_FORMAT(fro.upload_date, '$dateFormat') as period, COUNT(*) as count 
                FROM faculty_research_outputs fro
                INNER JOIN faculty_projects fp ON fro.project_id = fp.id
                INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
                WHERE fro.$outputDateCondition
                $facultyWhereClause
                GROUP BY period 
                ORDER BY period";
        
        $result = $conn->query($sql);
        $facultyOutputsData = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $facultyOutputsData[$row['period']] = (int)$row['count'];
            }
        }
        
        // Map data to labels
        foreach ($labels as $index => $label) {
            $periodKey = '';
            if ($timeRange === '24hours') {
                $periodKey = date('Y-m-d H:00:00', strtotime("today " . $label));
            } else {
                // Fix: Parse the date correctly for daily ranges
                $currentYear = date('Y');
                $dateStr = $label . ' ' . $currentYear;
                $timestamp = strtotime($dateStr);
                if ($timestamp !== false) {
                    $periodKey = date('Y-m-d', $timestamp);
                }
            }
            
            if ($periodKey && isset($facultyData[$periodKey])) {
                $response['faculty'][$index] = $facultyData[$periodKey];
            }
            if ($periodKey && isset($facultyOutputsData[$periodKey])) {
                $response['facultyOutputs'][$index] = $facultyOutputsData[$periodKey];
            }
        }
        
        // Statistics - with role-based filtering
        $statDateCondition = str_replace('fp.', '', $dateCondition);
        $sql = "SELECT COUNT(*) as total 
                FROM faculty_projects fp
                INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
                WHERE fp.$statDateCondition 
                $facultyWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['faculty']['total'] = (int)($row['total'] ?? 0);
        }
        
        $statOutputDateCondition = str_replace('created_at', 'upload_date', $statDateCondition);
        $sql = "SELECT COUNT(*) as count 
                FROM faculty_research_outputs fro
                INNER JOIN faculty_projects fp ON fro.project_id = fp.id
                INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
                WHERE fro.output_status='pending' 
                AND fro.$statOutputDateCondition 
                $facultyWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['faculty']['pending'] = (int)($row['count'] ?? 0);
        }
        
        $sql = "SELECT COUNT(*) as count 
                FROM faculty_research_outputs fro
                INNER JOIN faculty_projects fp ON fro.project_id = fp.id
                INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
                WHERE fro.output_status='accepted' 
                AND fro.$statOutputDateCondition 
                $facultyWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['faculty']['accepted'] = (int)($row['count'] ?? 0);
        }
    }
}

// Fetch Student Data (with role-based filtering)
if ($showStudent) {
    // Research trend - JOIN with student_researchers to filter by created_by
    $sql = "SELECT DATE_FORMAT(ro.created_at, '$dateFormat') as period, COUNT(*) as count 
            FROM research_outputs ro
            INNER JOIN student_researchers sr ON ro.student_id = sr.id
            WHERE ro.$dateCondition 
            $studentWhereClause
            GROUP BY period 
            ORDER BY period";
    
    $result = $conn->query($sql);
    if ($result) {
        $studentData = [];
        while ($row = $result->fetch_assoc()) {
            $studentData[$row['period']] = (int)$row['count'];
        }
        
        // Research outputs trend - JOIN through research_outputs to student_researchers
        $outputDateCondition = str_replace('created_at', 'upload_date', $dateCondition);
        $outputDateCondition = str_replace('ro.', 'sro.', $outputDateCondition);
        
        $sql = "SELECT DATE_FORMAT(sro.upload_date, '$dateFormat') as period, COUNT(*) as count 
                FROM student_research_outputs sro
                INNER JOIN research_outputs ro ON sro.research_id = ro.id
                INNER JOIN student_researchers sr ON ro.student_id = sr.id
                WHERE sro.$outputDateCondition
                $studentWhereClause
                GROUP BY period 
                ORDER BY period";
        
        $result = $conn->query($sql);
        $studentOutputsData = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $studentOutputsData[$row['period']] = (int)$row['count'];
            }
        }
        
        // Map data to labels
        foreach ($labels as $index => $label) {
            $periodKey = '';
            if ($timeRange === '24hours') {
                $periodKey = date('Y-m-d H:00:00', strtotime("today " . $label));
            } else {
                // Fix: Parse the date correctly for daily ranges
                $currentYear = date('Y');
                $dateStr = $label . ' ' . $currentYear;
                $timestamp = strtotime($dateStr);
                if ($timestamp !== false) {
                    $periodKey = date('Y-m-d', $timestamp);
                }
            }
            
            if ($periodKey && isset($studentData[$periodKey])) {
                $response['student'][$index] = $studentData[$periodKey];
            }
            if ($periodKey && isset($studentOutputsData[$periodKey])) {
                $response['studentOutputs'][$index] = $studentOutputsData[$periodKey];
            }
        }
        
        // Statistics - with role-based filtering
        $statDateCondition = str_replace('ro.', '', $dateCondition);
        $sql = "SELECT COUNT(*) as total 
                FROM research_outputs ro
                INNER JOIN student_researchers sr ON ro.student_id = sr.id
                WHERE ro.$statDateCondition 
                $studentWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['student']['total'] = (int)($row['total'] ?? 0);
        }
        
        $statOutputDateCondition = str_replace('created_at', 'upload_date', $statDateCondition);
        $sql = "SELECT COUNT(*) as count 
                FROM student_research_outputs sro
                INNER JOIN research_outputs ro ON sro.research_id = ro.id
                INNER JOIN student_researchers sr ON ro.student_id = sr.id
                WHERE sro.output_status='pending' 
                AND sro.$statOutputDateCondition 
                $studentWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['student']['pending'] = (int)($row['count'] ?? 0);
        }
        
        $sql = "SELECT COUNT(*) as count 
                FROM student_research_outputs sro
                INNER JOIN research_outputs ro ON sro.research_id = ro.id
                INNER JOIN student_researchers sr ON ro.student_id = sr.id
                WHERE sro.output_status='accepted' 
                AND sro.$statOutputDateCondition 
                $studentWhereClause";
        $result = $conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            $response['statistics']['student']['accepted'] = (int)($row['count'] ?? 0);
        }
    }
}

// Close database connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>
