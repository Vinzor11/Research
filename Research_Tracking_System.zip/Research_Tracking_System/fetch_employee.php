<?php
/**
 * Employee Fetch Endpoint - ON-DEMAND QUERIES ONLY
 * Handles: search, get by ID, import, sync
 */

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

require 'db.php';
require 'config.php';
require 'hr_api_helper.php';

$userRole = $_SESSION['user_role'] ?? null;
$userId = $_SESSION['user_id'];

if (!in_array($userRole, ['admin', 'coordinator'])) {
    echo json_encode(['success' => false, 'error' => 'Access denied']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    $hrAPI = new HRSystemAPI($conn, $userId);
    
    switch ($action) {
        case 'search':
            $query = trim($_GET['q'] ?? '');
            $page = (int)($_GET['page'] ?? 1);
            $perPage = 20;
            
            if (empty($query) || strlen($query) < 2) {
                echo json_encode([
                    'success' => true,
                    'data' => [],
                    'total' => 0,
                    'message' => 'Enter at least 2 characters to search'
                ]);
                exit;
            }
            
            // Coordinator: restrict search to employees in same parent unit (RESEARCH_OFFICE_API_GUIDE)
            if ($userRole === 'coordinator') {
                $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                if (!empty($unitEmployees)) {
                    $queryLower = mb_strtolower($query);
                    $filtered = [];
                    foreach ($unitEmployees as $emp) {
                        $name = $emp['name'] ?? [];
                        $contact = $emp['contact'] ?? [];
                        $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                        $email = $contact['email'] ?? '';
                        if (strpos(mb_strtolower($fullName), $queryLower) !== false ||
                            strpos(mb_strtolower($email), $queryLower) !== false) {
                            $filtered[] = $emp;
                        }
                    }
                    $total = count($filtered);
                    $offset = ($page - 1) * $perPage;
                    $paged = array_slice($filtered, $offset, $perPage);
                    $employees = [];
                    foreach ($paged as $emp) {
                        $name = $emp['name'] ?? [];
                        $contact = $emp['contact'] ?? [];
                        $department = $emp['department'] ?? $emp['unit'] ?? [];
                        $position = $emp['position'] ?? [];
                        $employees[] = [
                            'id' => $emp['id'],
                            'employee_id' => $emp['id'],
                            'full_name' => $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? '')),
                            'first_name' => $name['first_name'] ?? '',
                            'last_name' => $name['surname'] ?? '',
                            'middle_name' => $name['middle_name'] ?? '',
                            'email' => $contact['email'] ?? '',
                            'department' => is_array($department) ? ($department['name'] ?? 'N/A') : 'N/A',
                            'position' => $position['name'] ?? 'N/A'
                        ];
                    }
                    echo json_encode([
                        'success' => true,
                        'data' => $employees,
                        'total' => $total,
                        'current_page' => $page,
                        'last_page' => max(1, (int)ceil($total / $perPage))
                    ]);
                    exit;
                }
            }
            
            // Admin or fallback: use general search
            $result = $hrAPI->searchEmployees($query, $page, $perPage);
            
            if (isset($result['error'])) {
                echo json_encode(['success' => false, 'error' => $result['error']]);
                exit;
            }
            
            $employees = [];
            foreach ($result['data'] as $emp) {
                $name = $emp['name'] ?? [];
                $contact = $emp['contact'] ?? [];
                $department = $emp['department'] ?? $emp['unit'] ?? [];
                $position = $emp['position'] ?? [];
                
                $employees[] = [
                    'id' => $emp['id'],
                    'employee_id' => $emp['id'],
                    'full_name' => $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? '')),
                    'first_name' => $name['first_name'] ?? '',
                    'last_name' => $name['surname'] ?? '',
                    'middle_name' => $name['middle_name'] ?? '',
                    'email' => $contact['email'] ?? '',
                    'department' => is_array($department) ? ($department['name'] ?? 'N/A') : 'N/A',
                    'position' => $position['name'] ?? 'N/A'
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $employees,
                'total' => $result['total'],
                'current_page' => $result['current_page'],
                'last_page' => $result['last_page']
            ]);
            break;
        
        case 'sectors':
            $search = trim($_GET['search'] ?? '');
            $result = $hrAPI->getSectors($search ?: null);
            echo json_encode([
                'success' => true,
                'data' => $result['data'] ?? []
            ]);
            break;
        
        case 'units':
            $sectorId = !empty($_GET['sector_id']) ? (int)$_GET['sector_id'] : null;
            $unitType = trim($_GET['unit_type'] ?? '') ?: null;
            $search = trim($_GET['search'] ?? '') ?: null;
            $result = $hrAPI->getUnits($sectorId, $unitType, $search);
            echo json_encode([
                'success' => true,
                'data' => $result['data'] ?? []
            ]);
            break;
        
        case 'current-employee':
            $employee = $hrAPI->getCurrentEmployee();
            if ($employee) {
                echo json_encode(['success' => true, 'data' => $employee]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Current employee not found']);
            }
            break;
        
        case 'get':
            $employeeId = trim($_GET['id'] ?? '');
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Employee ID required']);
                exit;
            }
            
            $employee = $hrAPI->getEmployeeById($employeeId);
            
            if (empty($employee)) {
                echo json_encode([
                    'success' => false, 
                    'error' => "Employee '$employeeId' not found in HR System"
                ]);
                exit;
            }
            
            $mappedData = $hrAPI->mapEmployeeData($employee);
            
            if (empty($mappedData)) {
                echo json_encode([
                    'success' => false, 
                    'error' => 'Failed to process employee data'
                ]);
                exit;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $mappedData,
                'raw' => $employee
            ]);
            break;
        
        case 'import':
            $employeeId = trim($_POST['employee_id'] ?? $_GET['employee_id'] ?? $_GET['id'] ?? '');
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Employee ID required']);
                exit;
            }
            
            $hrEmployeeId = $conn->real_escape_string($employeeId);
            $existing = $conn->query("SELECT id, CONCAT(first_name, ' ', last_name) as name, sync_status, created_by
                                      FROM faculty_researchers 
                                      WHERE hr_employee_id = '$hrEmployeeId' 
                                      LIMIT 1");
            
            $isReimport = false;
            if ($existing && $existing->num_rows > 0) {
                $existingData = $existing->fetch_assoc();
                
                // Allow re-import if sync_status is 'n/a' (employee was moved away but is back now)
                if (!empty($existingData['sync_status']) && $existingData['sync_status'] === 'n/a') {
                    // Employee exists but has n/a status - allow re-import to reactivate
                    // The syncEmployee function will update the existing record
                    $isReimport = true;
                    debugLog("Re-importing employee with n/a status", [
                        'faculty_id' => $existingData['id'],
                        'hr_employee_id' => $hrEmployeeId
                    ]);
                } else {
                    // Employee is already imported and active
                    echo json_encode([
                        'success' => false,
                        'error' => 'This employee is already imported',
                        'existing_id' => $existingData['id'],
                        'existing_name' => $existingData['name']
                    ]);
                    exit;
                }
            }
            
            // Coordinator: verify employee is in same parent unit (RESEARCH_OFFICE_API_GUIDE)
            if ($userRole === 'coordinator') {
                $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                $allowedIds = [];
                foreach ($unitEmployees as $emp) {
                    $allowedIds[] = normalizeEmployeeId($emp['id'] ?? '');
                }
                $normalizedEmployeeId = normalizeEmployeeId($employeeId);
                if (!in_array($normalizedEmployeeId, $allowedIds)) {
                    if (empty($unitEmployees)) {
                        echo json_encode([
                            'success' => false,
                            'error' => 'Unable to verify unit employees. You can only import employees from your unit.'
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'error' => 'You can only import employees from your unit. This employee is not in your assigned unit.'
                        ]);
                    }
                    exit;
                }
            }
            
            $result = $hrAPI->syncEmployee($employeeId, $userId);
            
            if ($result['success']) {
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $facultyName = ($result['data']['first_name'] ?? '') . ' ' . ($result['data']['last_name'] ?? '');
                    if ($isReimport) {
                        $logger->logUpdate('faculty_researchers', $result['faculty_id'], 
                            "Re-imported from HR (reactivated): $facultyName (HR ID: $employeeId)");
                    } else {
                        $logger->logCreate('faculty_researchers', $result['faculty_id'], 
                            "Imported from HR: $facultyName (HR ID: $employeeId)");
                    }
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => $isReimport ? 'Employee re-imported and reactivated successfully' : 'Employee imported successfully',
                    'faculty_id' => $result['faculty_id'],
                    'is_reimport' => $isReimport,
                    'redirect' => 'facultyresearcherprofile.php?id=' . $result['faculty_id']
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to import employee'
                ]);
            }
            break;
        
        case 'sync':
            $facultyId = (int)($_POST['faculty_id'] ?? 0);
            
            if (empty($facultyId)) {
                echo json_encode(['success' => false, 'error' => 'Faculty ID required']);
                exit;
            }
            
            $faculty = $conn->query("SELECT hr_employee_id, CONCAT(first_name, ' ', last_name) as name 
                                     FROM faculty_researchers 
                                     WHERE id = $facultyId 
                                     LIMIT 1")->fetch_assoc();
            
            if (empty($faculty)) {
                echo json_encode(['success' => false, 'error' => 'Faculty not found']);
                exit;
            }
            
            if (empty($faculty['hr_employee_id'])) {
                echo json_encode([
                    'success' => false, 
                    'error' => 'This faculty was not imported from HR and cannot be synced'
                ]);
                exit;
            }
            
            // For coordinators: Check if employee still belongs to their parent unit
            if ($userRole === 'coordinator') {
                $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                $allowedIds = [];
                foreach ($unitEmployees as $emp) {
                    $allowedIds[] = normalizeEmployeeId($emp['id'] ?? '');
                }
                
                $normalizedEmployeeId = normalizeEmployeeId($faculty['hr_employee_id']);
                if (!in_array($normalizedEmployeeId, $allowedIds)) {
                    // Employee no longer belongs to coordinator's parent unit
                    // Set sync_status to 'n/a' and return message
                    $conn->query("
                        UPDATE faculty_researchers 
                        SET sync_status = 'n/a' 
                        WHERE id = $facultyId
                    ");
                    
                    if (file_exists('ActivityLogger.php')) {
                        require 'ActivityLogger.php';
                        $logger = new ActivityLogger($conn, $userId);
                        $logger->logUpdate('faculty_researchers', $facultyId, 
                            "Sync status set to N/A: {$faculty['name']} no longer in coordinator's unit");
                    }
                    
                    echo json_encode([
                        'success' => false,
                        'error' => 'This researcher no longer belongs to your parent unit. Sync status has been set to N/A.',
                        'sync_status_updated' => true
                    ]);
                    exit;
                } else {
                    // Employee is back in the unit - reset sync_status if it was 'n/a'
                    $currentStatus = $conn->query("SELECT sync_status FROM faculty_researchers WHERE id = $facultyId")->fetch_assoc()['sync_status'] ?? '';
                    if ($currentStatus === 'n/a') {
                        // Reset to appropriate status - will be set to 'synced' after successful sync
                        debugLog("Employee back in coordinator's unit, resetting sync_status", [
                            'faculty_id' => $facultyId,
                            'hr_employee_id' => $faculty['hr_employee_id']
                        ]);
                    }
                }
            }
            
            // Check if employee still exists in HR
            $hrEmployee = $hrAPI->getEmployeeById($faculty['hr_employee_id']);
            if (empty($hrEmployee) || empty($hrEmployee['id'])) {
                // Employee not found in HR - set sync_status to 'n/a'
                $conn->query("
                    UPDATE faculty_researchers 
                    SET sync_status = 'n/a' 
                    WHERE id = $facultyId
                ");
                
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('faculty_researchers', $facultyId, 
                        "Sync status set to N/A: {$faculty['name']} not found in HR system");
                }
                
                echo json_encode([
                    'success' => false,
                    'error' => 'Employee not found in HR system. Sync status has been set to N/A.',
                    'sync_status_updated' => true
                ]);
                exit;
            }
            
            $result = $hrAPI->syncEmployee($faculty['hr_employee_id'], $userId);
            
            if ($result['success']) {
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('faculty_researchers', $facultyId, 
                        "Synced with HR: {$faculty['name']}");
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Employee data synced successfully',
                    'updated_at' => date('M d, Y h:i A')
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to sync employee'
                ]);
            }
            break;
        
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
    
} catch (Exception $e) {
    error_log("fetch_employee.php exception: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}