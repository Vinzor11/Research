<?php
session_start();

// STRICT ADMIN-ONLY ACCESS CHECK
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    if (isset($_SESSION['user_id'])) {
        header("Location: research.php");
    } else {
        header("Location: login.php");
    }
    exit;
}

require 'db.php';
require 'ActivityLogger.php';

$logger = new ActivityLogger($conn, $_SESSION['user_id']);
$logger->logView('users', null, 'Accessed user management page');

// FIXED: Changed all 'role' to 'user_role'
$users = [];
$result = $conn->query("SELECT id, username, user_role, coordinator_type, created_at FROM users ORDER BY created_at DESC");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

// FIXED: Changed all 'role' to 'user_role' in statistics queries
$totalUsers = count($users);
$adminCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'admin'")->fetch_assoc()['c'];
$coordinatorCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'coordinator'")->fetch_assoc()['c'];
$facultyCoordCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'coordinator' AND coordinator_type = 'faculty'")->fetch_assoc()['c'];
$studentCoordCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'coordinator' AND coordinator_type = 'student'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="usersStyle.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <a href="users.php" class="active"><i class="fa fa-users-cog"></i> User Management</a>
        <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
        <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
    <div class="header">
        <div class="header-title">
            <div class="header-title-icon">
                <i class="fa-solid fa-users-cog"></i>
            </div>
            <div class="header-title-text">
                <h1>User Management</h1>
                <p>View system users and access control</p>
            </div>
        </div>
        <div class="user-info">
            <div class="user-avatar">
                <?= strtoupper(substr($_SESSION['fullname'] ?? $_SESSION['username'] ?? 'A', 0, 1)) ?>
            </div>
            <span><strong><?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User') ?></strong></span>
            <span class="role-badge">Admin</span>
        </div>
    </div>

    <div class="content">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $totalUsers ?></div>
                        <div class="label">Total Users</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);">
                        <i class="fa fa-users"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $adminCount ?></div>
                        <div class="label">Administrators</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--accent) 0%, #34d399 100%);">
                        <i class="fa fa-shield-halved"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $facultyCoordCount ?></div>
                        <div class="label">Faculty Coord</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning) 0%, #fbbf24 100%);">
                        <i class="fa fa-chalkboard-user"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $studentCoordCount ?></div>
                        <div class="label">Student Coord</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--purple) 0%, #a78bfa 100%);">
                        <i class="fa fa-user-graduate"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-title">
                    <i class="fa fa-list"></i>
                    All System Users
                </div>
            </div>
            <div class="table-container">
                <?php if (empty($users)): ?>
                    <div class="empty-state">
                        <i class="fa fa-users-slash"></i>
                        <p>No users found in the system</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Role</th>
                                <th>Coordinator Type</th>
                                <th>Created Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="user-cell">
                                            <div class="user-avatar-small">
                                                <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                            </div>
                                            <div class="user-details">
                                                <div class="username"><?= htmlspecialchars($user['username']) ?></div>
                                                <div class="user-id">ID: <?= $user['id'] ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <!-- FIXED: Changed $user['role'] to $user['user_role'] -->
                                        <span class="badge badge-<?= $user['user_role'] ?>">
                                            <i class="fa fa-<?= $user['user_role'] === 'admin' ? 'shield-halved' : 'user-tie' ?>"></i>
                                            <?= ucfirst($user['user_role']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <!-- FIXED: Changed $user['role'] to $user['user_role'] -->
                                        <?php if ($user['user_role'] === 'coordinator'): ?>
                                            <?php if ($user['coordinator_type']): ?>
                                                <span class="badge badge-<?= $user['coordinator_type'] ?>">
                                                    <i class="fa fa-<?= $user['coordinator_type'] === 'faculty' ? 'chalkboard-user' : 'user-graduate' ?>"></i>
                                                    <?= ucfirst($user['coordinator_type']) ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color: var(--gray-400);">Not Set</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: var(--gray-400);">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('M d, Y - g:i A', strtotime($user['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>