<?php
session_start();
require 'db.php';
require 'ActivityLogger.php';

// ============================================
// ACCESS CONTROL: Admin and Faculty Coordinator Only
// ============================================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userRole = $_SESSION['user_role'] ?? null;
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

// Only allow admin or faculty coordinator
if (!($userRole === 'admin' || ($userRole === 'coordinator' && $coordinatorType === 'faculty'))) {
    header("Location: research.php");
    exit;
}

// Initialize activity logger
$logger = new ActivityLogger($conn, $_SESSION['user_id']);

// Get project_id from URL
if (!isset($_GET['project_id']) || !is_numeric($_GET['project_id'])) {
    header("Location: facultyresearcher.php");
    exit;
}

$project_id = (int)$_GET['project_id'];

// Fetch project details with access control check
$projectStmt = $conn->prepare("SELECT fp.*, CONCAT(fr.first_name, ' ', fr.last_name) as faculty_name, 
    fr.id as faculty_id, fr.created_by 
    FROM faculty_projects fp 
    JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
    WHERE fp.id = ?");
$projectStmt->bind_param("i", $project_id);
$projectStmt->execute();
$project = $projectStmt->get_result()->fetch_assoc();

if (!$project) {
    die("Project not found.");
}

// NEW: Check if coordinator has access to this faculty researcher
if ($userRole === 'coordinator') {
    if ($project['created_by'] != $userId) {
        die("<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Access Denied</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
                .access-denied { 
                    max-width: 500px; 
                    margin: 100px auto; 
                    background: white; 
                    padding: 40px; 
                    border-radius: 8px; 
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .access-denied h2 { color: #dc3545; margin-bottom: 20px; }
                .access-denied i { font-size: 48px; margin-bottom: 20px; color: #dc3545; }
                .access-denied p { color: #666; margin-bottom: 30px; }
                .btn-back { 
                    display: inline-block; 
                    padding: 12px 24px; 
                    background: #007bff; 
                    color: white; 
                    text-decoration: none; 
                    border-radius: 4px;
                    transition: background 0.3s;
                }
                .btn-back:hover { background: #0056b3; }
            </style>
        </head>
        <body>
            <div class='access-denied'>
                <i class='fa fa-ban'></i>
                <h2>Access Denied</h2>
                <p>You can only view research outputs for faculty researchers that you created.</p>
                <a href='facultyresearcher.php' class='btn-back'>
                    <i class='fa fa-arrow-left'></i> Back to Faculty List
                </a>
            </div>
        </body>
        </html>");
    }
}

// Create research outputs table if not exists
try {
    $conn->query("
        CREATE TABLE IF NOT EXISTS faculty_research_outputs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            project_id INT NOT NULL,
            output_title VARCHAR(500) NOT NULL,
            output_type VARCHAR(100),
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_size INT,
            output_status ENUM('pending', 'accepted', 'needs_revision', 'rejected') DEFAULT 'pending',
            version INT DEFAULT 1,
            is_latest_version TINYINT(1) DEFAULT 1,
            uploaded_by INT NOT NULL,
            upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            reviewer_id INT,
            review_date DATETIME,
            review_comments TEXT,
            parent_output_id INT DEFAULT NULL,
            FOREIGN KEY (project_id) REFERENCES faculty_projects(id) ON DELETE CASCADE,
            FOREIGN KEY (uploaded_by) REFERENCES faculty_researchers(id),
            FOREIGN KEY (reviewer_id) REFERENCES users(id),
            FOREIGN KEY (parent_output_id) REFERENCES faculty_research_outputs(id) ON DELETE SET NULL,
            INDEX idx_project_latest (project_id, is_latest_version),
            INDEX idx_status (output_status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (Exception $e) {
    // Table already exists
}

// Handle AJAX operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // NEW: Verify access for all POST operations
    if ($userRole === 'coordinator') {
        $checkStmt = $conn->prepare("SELECT fr.created_by FROM faculty_projects fp 
            JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
            WHERE fp.id = ?");
        $checkStmt->bind_param("i", $project_id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result()->fetch_assoc();
        
        if (!$checkResult || $checkResult['created_by'] != $userId) {
            while (ob_get_level()) ob_end_clean();
            ob_start();
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "error" => "Access denied: You can only manage outputs for your own faculty researchers"]);
            exit;
        }
    }
    
    // Clear any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    header('Content-Type: application/json');
    
    try {
        // ============================================
        // UPLOAD RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'upload_output') {
            $output_title = trim($_POST['output_title'] ?? '');
            $output_type = trim($_POST['output_type'] ?? '');
            $parent_output_id = !empty($_POST['parent_output_id']) ? (int)$_POST['parent_output_id'] : null;
            
            // Enhanced error logging
            error_log("Upload attempt - POST data: " . print_r($_POST, true));
            error_log("Upload attempt - FILES data: " . print_r($_FILES, true));
            
            if (empty($output_title)) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Output title is required"]);
                exit;
            }
            
            // Check if file was uploaded
            if (!isset($_FILES['output_file'])) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "No file was uploaded. Please check form encoding."]);
                exit;
            }
            
            $file = $_FILES['output_file'];
            
            // Check for upload errors
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $error_messages = [
                    UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive in php.ini',
                    UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive in HTML form',
                    UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                    UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
                ];
                $error_msg = $error_messages[$file['error']] ?? 'Unknown upload error';
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Upload error: $error_msg"]);
                exit;
            }
            
            $file_size = $file['size'];
            $file_tmp = $file['tmp_name'];
            $original_filename = $file['name'];
            $file_ext = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
            
            // Allowed file types
            $allowed_ext = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'zip', 'rar'];
            if (!in_array($file_ext, $allowed_ext)) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Invalid file type. Allowed: PDF, DOC, DOCX, PPT, PPTX, ZIP, RAR"]);
                exit;
            }
            
            // Max file size: 50MB
            if ($file_size > 50 * 1024 * 1024) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "File size exceeds 50MB limit"]);
                exit;
            }
            
            // Create upload directory if it doesn't exist
            $upload_dir = __DIR__ . '/uploads/research_outputs/';
            
            // Check if directory exists
            if (!is_dir($upload_dir)) {
                // Try to create with recursive option
                if (!@mkdir($upload_dir, 0777, true)) {
                    // If mkdir fails, provide detailed error
                    $error_msg = "Failed to create upload directory: $upload_dir";
                    if (!is_writable(dirname($upload_dir))) {
                        $error_msg .= " - Parent directory is not writable. Please create 'uploads' folder manually and set permissions to 755.";
                    }
                    ob_end_clean();
                    echo json_encode(["success" => false, "error" => $error_msg]);
                    exit;
                }
                // Set permissions after creation
                @chmod($upload_dir, 0777);
            }
            
            // Verify directory is writable
            if (!is_writable($upload_dir)) {
                ob_end_clean();
                echo json_encode([
                    "success" => false, 
                    "error" => "Upload directory exists but is not writable. Please run: chmod 755 " . $upload_dir
                ]);
                exit;
            }
            
            // Generate unique filename (use relative path for storage)
            $new_filename = 'output_' . $project_id . '_' . time() . '_' . uniqid() . '.' . $file_ext;
            $file_path = $upload_dir . $new_filename;
            $relative_path = 'uploads/research_outputs/' . $new_filename; // Store relative path in DB
            
            if (!move_uploaded_file($file_tmp, $file_path)) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Failed to move uploaded file. Check directory permissions."]);
                exit;
            }
            
            $conn->begin_transaction();
            
            try {
                // Determine version number
                $version = 1;
                if ($parent_output_id) {
                    // This is a revision - mark old version as not latest
                    $updateStmt = $conn->prepare("UPDATE faculty_research_outputs SET is_latest_version = 0 WHERE id = ?");
                    $updateStmt->bind_param("i", $parent_output_id);
                    $updateStmt->execute();
                    
                    // Get version from parent
                    $parentStmt = $conn->prepare("SELECT version FROM faculty_research_outputs WHERE id = ?");
                    $parentStmt->bind_param("i", $parent_output_id);
                    $parentStmt->execute();
                    $parentResult = $parentStmt->get_result();
                    if ($parent = $parentResult->fetch_assoc()) {
                        $version = $parent['version'] + 1;
                    }
                }
                
                // Insert new output
                $stmt = $conn->prepare("INSERT INTO faculty_research_outputs 
                    (project_id, output_title, output_type, file_name, file_path, file_size, 
                     output_status, version, is_latest_version, uploaded_by, parent_output_id)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, 1, ?, ?)");
                
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                
                $stmt->bind_param("issssiiii",
                    $project_id,           // i - integer
                    $output_title,         // s - string
                    $output_type,          // s - string
                    $original_filename,    // s - string
                    $relative_path,        // s - string
                    $file_size,            // i - integer
                    $version,              // i - integer
                    $project['faculty_id'],// i - integer
                    $parent_output_id      // i - integer (nullable)
                );
                
                if (!$stmt->execute()) {
                    throw new Exception("Execute failed: " . $stmt->error);
                }
                
                $output_id = $conn->insert_id;
                
                // Log activity
                $versionText = $version > 1 ? " (Version $version - Revision)" : " (Version 1)";
                $logger->logCreate('faculty_research_outputs', $output_id, "Uploaded research output: '$output_title'$versionText for project '{$project['title']}' - Status: Pending Review");
                
                $conn->commit();
                ob_end_clean();
                echo json_encode([
                    "success" => true, 
                    "message" => "Research output uploaded successfully!",
                    "version" => $version
                ]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                // Delete uploaded file if database insert fails
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Database error: " . $e->getMessage()]);
                exit;
            }
        }
        
        // ============================================
        // REVIEW RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'review_output') {
            $output_id = (int)$_POST['output_id'];
            $new_status = $_POST['status'];
            $review_comments = trim($_POST['review_comments']);
            $reviewer_id = $_SESSION['user_id'];
            
            $allowed_statuses = ['accepted', 'needs_revision', 'rejected'];
            if (!in_array($new_status, $allowed_statuses)) {
                echo json_encode(["success" => false, "error" => "Invalid status"]);
                exit;
            }
            
            // Get output info for notification
            $outputInfo = $conn->query("
                SELECT fro.*, fp.title as project_title
                FROM faculty_research_outputs fro
                JOIN faculty_projects fp ON fro.project_id = fp.id
                WHERE fro.id = $output_id
            ")->fetch_assoc();
            
            if (!$outputInfo) {
                echo json_encode(["success" => false, "error" => "Output not found"]);
                exit;
            }
            
            $stmt = $conn->prepare("UPDATE faculty_research_outputs 
                SET output_status = ?, reviewer_id = ?, review_date = NOW(), review_comments = ?
                WHERE id = ?");
            $stmt->bind_param("sisi", $new_status, $reviewer_id, $review_comments, $output_id);
            $stmt->execute();
            
            // Log activity with notification
            $status_text = ucwords(str_replace('_', ' ', $new_status));
            $notification_msg = "Research output '{$outputInfo['output_title']}' (v{$outputInfo['version']}) for project '{$outputInfo['project_title']}' has been $status_text";
            if ($review_comments) {
                $notification_msg .= " | Review comments: $review_comments";
            }
            
            $logger->logUpdate('faculty_research_outputs', $output_id, $notification_msg);
            
            echo json_encode([
                "success" => true, 
                "message" => "Review submitted successfully. Notification has been logged.",
                "status" => $new_status
            ]);
            exit;
        }
        
        // ============================================
        // DELETE RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'delete_output') {
            $output_id = (int)$_POST['output_id'];
            
            // Get file info before deleting
            $outputInfo = $conn->query("SELECT * FROM faculty_research_outputs WHERE id = $output_id")->fetch_assoc();
            
            if ($outputInfo) {
                // Delete file from server
                $full_path = __DIR__ . '/' . $outputInfo['file_path'];
                if (file_exists($full_path)) {
                    unlink($full_path);
                }
                
                // Delete from database
                $conn->query("DELETE FROM faculty_research_outputs WHERE id = $output_id");
                
                // Log activity
                $logger->logDelete('faculty_research_outputs', $output_id, "Deleted research output: '{$outputInfo['output_title']}' (v{$outputInfo['version']})");
                
                echo json_encode(["success" => true]);
            } else {
                echo json_encode(["success" => false, "error" => "Output not found"]);
            }
            exit;
        }
        
    } catch (Exception $e) {
        ob_end_clean();
        error_log("Upload exception: " . $e->getMessage());
        echo json_encode(["success" => false, "error" => "Exception: " . $e->getMessage()]);
        exit;
    } catch (Error $e) {
        ob_end_clean();
        error_log("Upload fatal error: " . $e->getMessage());
        echo json_encode(["success" => false, "error" => "Fatal error: " . $e->getMessage()]);
        exit;
    }
    
    ob_end_clean();
    echo json_encode(["success" => false, "error" => "Unknown action"]);
    exit;
}

// Fetch research outputs (latest versions only)
$outputs = $conn->query("
    SELECT fro.*, u.username as reviewer_name,
           CONCAT(fr.first_name, ' ', fr.last_name) as uploader_name
    FROM faculty_research_outputs fro
    LEFT JOIN users u ON fro.reviewer_id = u.id
    LEFT JOIN faculty_researchers fr ON fro.uploaded_by = fr.id
    WHERE fro.project_id = $project_id AND fro.is_latest_version = 1
    ORDER BY fro.upload_date DESC
")->fetch_all(MYSQLI_ASSOC);

// Count outputs by status
$stats = [
    'total' => count($outputs),
    'pending' => 0,
    'accepted' => 0,
    'needs_revision' => 0,
    'rejected' => 0
];

foreach ($outputs as $output) {
    $stats[$output['output_status']]++;
}

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get PHP upload limits for display
$upload_max = ini_get('upload_max_filesize');
$post_max = ini_get('post_max_size');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Research Outputs - <?= s($project['title']) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="faculty_research_outputs_style.css">
</head>
<body>

<div class="container">
    <a href="facultyresearcherprofile.php?id=<?= $project['faculty_id'] ?>" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Faculty Profile
    </a>

    <div class="page-header">
        <div class="page-title">
            <i class="fa fa-file-alt"></i> Research Outputs
        </div>
        <div class="page-subtitle">
            <span><i class="fa fa-project-diagram"></i> <strong>Project:</strong> <?= s($project['title']) ?></span>
            <span><i class="fa fa-user"></i> <strong>Faculty:</strong> <?= s($project['faculty_name']) ?></span>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?= $stats['total'] ?></div>
            <div class="stat-label">Total Outputs</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['pending'] ?></div>
            <div class="stat-label">Pending Review</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['accepted'] ?></div>
            <div class="stat-label">Accepted</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['needs_revision'] ?></div>
            <div class="stat-label">Needs Revision</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $stats['rejected'] ?></div>
            <div class="stat-label">Rejected</div>
        </div>
    </div>

    <div class="actions-bar">
        <h3 style="color: var(--primary); font-size: 18px;">
            <i class="fa fa-list"></i> Research Outputs List
        </h3>
        <button class="btn btn-primary" onclick="openUploadModal()">
            <i class="fa fa-upload"></i> Upload Research Output
        </button>
    </div>

    <div class="outputs-container">
        <?php if (empty($outputs)): ?>
            <div class="no-data">
                <i class="fa fa-inbox"></i>
                <p style="font-size: 18px; font-weight: 600; margin-bottom: 10px;">No research outputs uploaded yet.</p>
                <p style="font-size: 14px;">Click "Upload Research Output" to get started.</p>
            </div>
        <?php else: foreach ($outputs as $output): 
            $statusClass = 'status-' . $output['output_status'];
            $statusIcon = [
                'pending' => 'clock',
                'accepted' => 'check-circle',
                'needs_revision' => 'exclamation-triangle',
                'rejected' => 'times-circle'
            ][$output['output_status']];
            $statusText = ucwords(str_replace('_', ' ', $output['output_status']));
        ?>
            <div class="output-card">
                <div class="output-header">
                    <div class="output-title">
                        <?= s($output['output_title']) ?>
                    </div>
                    <span class="status-badge <?= $statusClass ?>">
                        <i class="fa fa-<?= $statusIcon ?>"></i>
                        <?= $statusText ?>
                    </span>
                </div>

                <div class="output-meta">
                    <div class="meta-item">
                        <i class="fa fa-tag"></i>
                        <span><strong>Type:</strong> <?= s($output['output_type']) ?: 'Not specified' ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fa fa-code-branch"></i>
                        <span><strong>Version:</strong> <?= $output['version'] ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fa fa-calendar"></i>
                        <span><strong>Uploaded:</strong> <?= date('M d, Y', strtotime($output['upload_date'])) ?></span>
                    </div>
                    <div class="meta-item">
                        <i class="fa fa-user"></i>
                        <span><strong>By:</strong> <?= s($output['uploader_name']) ?></span>
                    </div>
                </div>

                <div class="file-info">
                    <i class="fa fa-paperclip" style="font-size: 24px; color: var(--primary);"></i>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: var(--dark);"><?= s($output['file_name']) ?></div>
                        <div style="color: var(--gray); font-size: 12px;"><?= number_format($output['file_size'] / 1024, 2) ?> KB</div>
                    </div>
                </div>

                <div class="output-actions">
                    <button class="btn btn-secondary btn-sm" onclick="downloadOutput('<?= s($output['file_path']) ?>', '<?= s($output['file_name']) ?>')">
                        <i class="fa fa-download"></i> Download
                    </button>
                    
                    <?php if ($output['output_status'] == 'pending' || $output['output_status'] == 'needs_revision'): ?>
                        <button class="btn btn-warning btn-sm" onclick="openReviewModal(<?= $output['id'] ?>, '<?= addslashes(s($output['output_title'])) ?>')">
                            <i class="fa fa-gavel"></i> Review
                        </button>
                    <?php endif; ?>
                    
                    <?php if ($output['output_status'] == 'needs_revision'): ?>
                        <button class="btn btn-primary btn-sm" onclick="openUploadModal(<?= $output['id'] ?>)">
                            <i class="fa fa-redo"></i> Upload Revision
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn btn-secondary btn-sm" onclick="viewVersionHistory(<?= $output['id'] ?>)">
                        <i class="fa fa-history"></i> Version History
                    </button>
                    
                    <button class="btn btn-danger btn-sm" onclick="deleteOutput(<?= $output['id'] ?>)">
                        <i class="fa fa-trash"></i> Delete
                    </button>
                </div>

                <?php if ($output['reviewer_id']): ?>
                    <div class="review-section <?= $output['output_status'] ?>">
                        <h4><i class="fa fa-clipboard-check"></i> Review Information</h4>
                        <div style="font-size: 13px; margin-top: 10px; line-height: 1.8;">
                            <div><strong><i class="fa fa-user"></i> Reviewed by:</strong> <?= s($output['reviewer_name']) ?></div>
                            <div><strong><i class="fa fa-calendar"></i> Review Date:</strong> <?= date('M d, Y h:i A', strtotime($output['review_date'])) ?></div>
                        </div>
                        <?php if ($output['review_comments']): ?>
                            <div class="review-comments">
                                <strong><i class="fa fa-comment"></i> Review Comments:</strong>
                                <p style="margin: 8px 0 0 0;"><?= nl2br(s($output['review_comments'])) ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<!-- UPLOAD OUTPUT MODAL -->
<div id="uploadModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-upload"></i> <span id="uploadModalTitle">Upload Research Output</span></h3>
            <span class="close" onclick="closeModal('uploadModal')">&times;</span>
        </div>
        <form id="uploadForm" enctype="multipart/form-data">
            <input type="hidden" name="action" value="upload_output">
            <input type="hidden" name="project_id" value="<?= $project_id ?>">
            <input type="hidden" name="parent_output_id" id="parent_output_id">
            
            <div class="info-box">
                <p><i class="fa fa-info-circle"></i> <strong>Server Upload Limits:</strong> upload_max_filesize = <?= $upload_max ?>, post_max_size = <?= $post_max ?>. If you experience issues, files may exceed these limits.</p>
            </div>
            
            <div class="form-group">
                <label>Output Title <span style="color: var(--danger);">*</span></label>
                <input type="text" name="output_title" id="output_title" required 
                       placeholder="e.g., Final Research Paper, Thesis Defense Presentation">
            </div>
            
            <div class="form-group">
                <label>Output Type</label>
                <select name="output_type">
                    <option value="">Select type...</option>
                    <option value="Research Paper">Research Paper</option>
                    <option value="Thesis">Thesis</option>
                    <option value="Dissertation">Dissertation</option>
                    <option value="Presentation">Presentation</option>
                    <option value="Report">Report</option>
                    <option value="Publication">Publication</option>
                    <option value="Dataset">Dataset</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Upload File <span style="color: var(--danger);">*</span></label>
                <input type="file" name="output_file" id="output_file" required 
                       accept=".pdf,.doc,.docx,.ppt,.pptx,.zip,.rar"
                       onchange="displayFileInfo(this)">
                <small>
                    <strong>Allowed formats:</strong> PDF, DOC, DOCX, PPT, PPTX, ZIP, RAR<br>
                    <strong>Maximum size:</strong> 50MB<br>
                    <span id="fileInfo" style="color: var(--primary); font-weight: 600;"></span>
                </small>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal('uploadModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary" id="uploadBtn">
                    <i class="fa fa-upload"></i> Upload
                </button>
            </div>
        </form>
    </div>
</div>

<!-- REVIEW OUTPUT MODAL -->
<div id="reviewModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-gavel"></i> Review Research Output</h3>
            <span class="close" onclick="closeModal('reviewModal')">&times;</span>
        </div>
        <form id="reviewForm">
            <input type="hidden" name="action" value="review_output">
            <input type="hidden" name="output_id" id="review_output_id">
            
            <div class="info-box">
                <p><strong>Output Title:</strong> <span id="review_output_title"></span></p>
            </div>
            
            <div class="form-group">
                <label>Review Status <span style="color: var(--danger);">*</span></label>
                <select name="status" required>
                    <option value="">Select status...</option>
                    <option value="accepted">✓ Accept</option>
                    <option value="needs_revision">⚠ Needs Revision</option>
                    <option value="rejected">✗ Reject</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Review Comments</label>
                <textarea name="review_comments" rows="5" 
                          placeholder="Enter feedback, suggestions, or reasons for rejection/revision..."></textarea>
                <small>Comments will be sent as a notification to the faculty member via ActivityLogger</small>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal('reviewModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-check"></i> Submit Review
                </button>
            </div>
        </form>
    </div>
</div>

<!-- VERSION HISTORY MODAL -->
<div id="versionHistoryModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h3><i class="fa fa-history"></i> Version History</h3>
            <span class="close" onclick="closeModal('versionHistoryModal')">&times;</span>
        </div>
        <div id="versionHistoryContent">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>

<script src="faculty_research_outputs_script.js"></script>

</body>
</html>
