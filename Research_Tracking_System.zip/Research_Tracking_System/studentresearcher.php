<?php
/**
 * ============================================================================
 * Student Researcher Management Page
 * ============================================================================
 * FIXED: Added coordinator type check to prevent faculty coordinators from accessing
 * ============================================================================
 */

session_start();

// STEP 1: Basic authentication check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';

// Access control
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

/**
 * ============================================================================
 * CRITICAL FIX: Add coordinator type check
 * ============================================================================
 * This was MISSING in your original code!
 * Faculty coordinators should NOT access student researcher page
 */
if ($userRole === 'coordinator' && $coordinatorType !== 'student') {
    header("Location: research.php");
    exit;
}

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Delete functionality
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delId = (int) $_GET['delete'];
    
    // Check permissions: admin can delete any, coordinators only their own
    $checkQuery = "SELECT id, created_by, CONCAT(last_name, ', ', first_name) as name 
                   FROM student_researchers WHERE id = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("i", $delId);
    $checkStmt->execute();
    $studentInfo = $checkStmt->get_result()->fetch_assoc();
    
    if (!$studentInfo) {
        die("Student not found");
    }
    
    // Authorization check
    if ($userRole !== 'admin' && $studentInfo['created_by'] != $userId) {
        die("Unauthorized: You can only delete student researchers you created");
    }
    
    $studentName = $studentInfo['name'];
    
    $stmt = $conn->prepare("DELETE FROM student_researchers WHERE id = ?");
    $stmt->bind_param("i", $delId);
    $stmt->execute();
    
    // Optional: Log the deletion
    // logActivity($conn, $userId, 'delete', 'student_researchers', $delId, "Deleted student researcher: $studentName");
    
    header("Location: studentresearcher.php");
    exit;
}

// Build WHERE clause based on user role
$whereConditions = [];
$params = [];
$types = "";

// Role-based filtering
if ($userRole !== 'admin') {
    // Coordinators only see their own students
    $whereConditions[] = "sr.created_by = ?";
    $params[] = $userId;
    $types .= "i";
}

// Search filtering
if ($search !== '') {
    $searchCondition = "(sr.student_number LIKE ? OR sr.last_name LIKE ? OR sr.first_name LIKE ? OR sr.middle_name LIKE ? OR sr.course_year_section LIKE ? OR sr.department LIKE ?)";
    $whereConditions[] = $searchCondition;
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like, $like, $like]);
    $types .= "ssssss";
}

// Get statistics with role-based filtering
$statsWhere = "";
$statsParams = [];
$statsTypes = "";

if ($userRole !== 'admin') {
    $statsWhere = " WHERE created_by = ?";
    $statsParams = [$userId];
    $statsTypes = "i";
}

// Total students
$totalQuery = "SELECT COUNT(*) as c FROM student_researchers" . $statsWhere;
$stmt = $conn->prepare($totalQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$totalStudents = $stmt->get_result()->fetch_assoc()['c'];

// Total research outputs (only for user's students)
$totalResearchQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                       INNER JOIN student_researchers sr ON ro.student_id = sr.id" . $statsWhere;
$stmt = $conn->prepare($totalResearchQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$totalResearch = $stmt->get_result()->fetch_assoc()['c'];

// On-going research
$ongoingQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                 INNER JOIN student_researchers sr ON ro.student_id = sr.id 
                 WHERE ro.status='on-going'" . ($statsWhere ? " AND sr.created_by = ?" : "");
$stmt = $conn->prepare($ongoingQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$ongoingResearch = $stmt->get_result()->fetch_assoc()['c'];

// Completed research
$completedQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                   INNER JOIN student_researchers sr ON ro.student_id = sr.id 
                   WHERE ro.status='completed'" . ($statsWhere ? " AND sr.created_by = ?" : "");
$stmt = $conn->prepare($completedQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$completedResearch = $stmt->get_result()->fetch_assoc()['c'];

// Fetch list with research count
$query = "SELECT 
    sr.id, 
    sr.student_number, 
    sr.last_name, 
    sr.first_name, 
    sr.middle_name, 
    sr.course_year_section, 
    sr.department,
    sr.created_by,
    COUNT(ro.id) as research_count
FROM student_researchers sr
LEFT JOIN research_outputs ro ON sr.id = ro.student_id";

if (!empty($whereConditions)) {
    $query .= " WHERE " . implode(" AND ", $whereConditions);
}

$query .= " GROUP BY sr.id ORDER BY sr.id DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Researchers</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.css">
<link rel="stylesheet" href="studentresearcherstyle.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="studentresearcher.php" class="active"><i class="fa fa-user-graduate"></i> Students</a>
        <?php if (file_exists('activity_logs.php')): ?>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
    <div class="header">
        <div class="header-title">
            <i class="fa-solid fa-user-graduate"></i>
            <span>Student Researchers <?= $userRole !== 'admin' ? '(My Students)' : '(All Students)' ?></span>
        </div>
        <form class="header-search" method="GET">
            <input type="text" name="search" placeholder="Search by ID, Name, Course, Department..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>
    </div>

    <div class="content">
        <!-- Statistics Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalStudents ?></div>
                        <div class="label"><?= $userRole !== 'admin' ? 'My' : 'Total' ?> Student Researchers</div>
                    </div>
                    <div class="icon"><i class="fa fa-users"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalResearch ?></div>
                        <div class="label"><?= $userRole !== 'admin' ? 'My' : 'Total' ?> Research Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-flask"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $ongoingResearch ?></div>
                        <div class="label">On-going Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-spinner"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $completedResearch ?></div>
                        <div class="label">Completed Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
        </div>

        <div class="toolbar">
            <div></div>
            <a class="add-btn" href="studentresearcherform.php">
                <i class="fa fa-plus"></i> Add New Student Researcher
            </a>
        </div>

        <div class="table-wrapper">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student Number</th>
                            <th>Name</th>
                            <th>Course & Year</th>
                            <th>Department</th>
                            <th>Outputs</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($students)): ?>
                            <tr>
                                <td colspan="7">
                                    <div class="no-data">
                                        <i class="fa fa-inbox"></i>
                                        <p>No student records found.</p>
                                        <?php if ($userRole !== 'admin'): ?>
                                            <p style="font-size: 0.9em; color: #666;">You can only see students you've added to the system.</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php else: foreach($students as $s): 
                            $fullname = $s['last_name'] . ', ' . $s['first_name'] . ($s['middle_name'] ? ' '.$s['middle_name'] : '');
                            $canDelete = ($userRole === 'admin') || ($s['created_by'] == $userId);
                        ?>
                        <tr>
                            <td><?= $s['id'] ?></td>
                            <td><strong><?= htmlspecialchars($s['student_number']) ?></strong></td>
                            <td style="text-align:left; padding-left:16px;"><?= htmlspecialchars($fullname) ?></td>
                            <td><?= htmlspecialchars($s['course_year_section']) ?></td>
                            <td><?= htmlspecialchars($s['department']) ?></td>
                            <td>
                                <span class="badge">
                                    <i class="fa fa-file-alt"></i>
                                    <?= $s['research_count'] ?> Outputs
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-view" onclick="viewProfile(<?= $s['id'] ?>)">
                                        <i class="fa fa-eye"></i> View
                                    </button>
                                    <?php if ($canDelete): ?>
                                        <button class="btn-delete" onclick="confirmDelete(<?= $s['id'] ?>, '<?= htmlspecialchars($fullname, ENT_QUOTES) ?>')">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="studentresearcherscript.js"></script>

</body>
</html>
