-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql100.infinityfree.com
-- Generation Time: Jan 25, 2026 at 10:20 PM
-- Server version: 11.4.9-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_40636335_erp_rms`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` enum('create','update','delete','view','export','login','logout') NOT NULL,
  `table_affected` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action_type`, `table_affected`, `record_id`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-09 10:37:57'),
(2, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-09 10:38:04'),
(3, 1, 'view', 'users', NULL, 'Accessed user management page', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-09 10:38:07'),
(4, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-09 10:39:19'),
(5, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-09 11:30:19'),
(6, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-09 11:35:06'),
(7, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-09 11:40:36'),
(8, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-09 12:18:49'),
(9, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-09 13:04:09'),
(10, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-09 15:10:58'),
(11, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:20:52'),
(12, 3, 'create', 'faculty_research_outputs', 1, 'Uploaded research output: \'sdfs\' (Version 1) for project \'sdfsdf\' - Status: Pending Review', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:23:29'),
(13, 3, 'update', 'faculty_research_outputs', 1, 'Research output \'sdfs\' (v1) for project \'sdfsdf\' has been Needs Revision | Review comments: sdfds', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:23:40'),
(14, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:23:54'),
(15, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:24:07'),
(16, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:24:16'),
(17, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:24:41'),
(18, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:28:48'),
(19, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:30:26'),
(20, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:33:59'),
(21, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:34:56'),
(22, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:35:02'),
(23, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.164', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 03:35:22'),
(24, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 04:36:58'),
(25, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:04:35'),
(26, 1, 'view', 'users', NULL, 'Accessed user management page', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:04:41'),
(27, 1, 'view', 'users', NULL, 'Accessed user management page', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:04:56'),
(28, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:04:58'),
(29, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:05:01'),
(30, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 05:05:12'),
(31, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 05:06:46'),
(32, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 05:06:50'),
(33, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 05:07:22'),
(34, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 05:13:27'),
(35, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 05:19:30'),
(36, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.207', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-10 06:27:38'),
(37, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 10:29:59'),
(38, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '158.62.56.35', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-10 10:30:21'),
(39, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '180.190.136.231', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-10 14:04:07'),
(40, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '180.190.136.231', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-10 14:04:27'),
(41, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '180.190.136.231', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '2025-12-10 14:04:42'),
(42, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-10 15:17:29'),
(43, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-10 15:23:36'),
(44, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-10 15:23:40'),
(45, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-10 15:23:59'),
(46, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.41', 'Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0', '2025-12-11 03:04:42'),
(47, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-11 06:37:28'),
(48, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-11 08:56:31'),
(49, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-11 09:28:32'),
(50, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-11 13:56:06'),
(51, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-11 13:56:09'),
(52, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-11 14:02:02'),
(53, 1, 'create', 'faculty_research_outputs', 2, 'Uploaded research output: \'dhdjsm\' (Version 1) for project \'eujesk\' - Status: Pending Review', '112.198.232.41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2025-12-11 14:05:24'),
(54, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '58.69.65.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-12 07:36:31'),
(55, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '58.69.65.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-12 07:52:59'),
(56, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '58.69.65.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-12 07:55:09'),
(57, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '58.69.65.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-12 07:59:27'),
(58, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-12 23:53:19'),
(59, 4, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.142', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '2026-01-08 05:32:00'),
(60, 4, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.142', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-08 05:32:09'),
(61, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.142', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-08 05:34:29'),
(62, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-14 07:29:23'),
(63, 2, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.52.37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-14 13:22:25'),
(64, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:10:43'),
(65, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:11:06'),
(66, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:11:29'),
(67, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:12:00'),
(68, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:12:20'),
(69, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 03:12:28'),
(70, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 07:48:47'),
(71, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 07:49:16'),
(72, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 07:49:33'),
(73, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 07:59:40'),
(74, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 08:06:14'),
(75, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 08:07:40'),
(76, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 08:14:30'),
(77, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 10:13:33'),
(78, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 10:15:03'),
(79, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 11:31:10'),
(80, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 11:31:19'),
(81, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 12:22:24'),
(82, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 12:23:06'),
(83, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-15 12:23:22'),
(84, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 00:12:40'),
(85, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-16 00:54:03'),
(86, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '158.62.56.123', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-16 01:08:44'),
(87, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '158.62.56.123', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-16 01:09:11'),
(88, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-16 01:20:48'),
(89, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 01:27:21'),
(90, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 01:28:19'),
(91, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 03:27:18'),
(92, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 03:48:40'),
(93, 3, 'create', 'faculty_researchers', 3, 'Imported faculty from HR System: Jyl Derwin Martires (HR ID: xd123)', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 04:03:37'),
(94, 3, 'update', 'faculty_researchers', 3, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 04:03:53'),
(95, 3, 'update', 'faculty_researchers', 3, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 04:06:28'),
(96, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 05:05:13'),
(97, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 05:05:33'),
(98, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 05:06:33'),
(99, 3, 'create', 'faculty_researchers', 4, 'Imported faculty from HR System: Francine Vista (HR ID: EMP0001)', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 05:25:42'),
(100, 3, 'create', 'faculty_researchers', 5, 'Imported faculty from HR System: Sample Martires (HR ID: 1234)', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 05:27:07'),
(101, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:45:01'),
(102, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:45:39'),
(103, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:47:54'),
(104, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:48:01'),
(105, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:50:30'),
(106, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:51:53'),
(107, 3, 'create', 'faculty_researchers', 6, 'Imported faculty from HR System: Jyl Derwin Martires (HR ID: EMP0003)', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 06:53:24'),
(108, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:08:54'),
(109, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:11:04'),
(110, 3, 'create', 'faculty_research_outputs', 3, 'Uploaded research output: \'test\' (Version 1) for project \'Simulation of Integrated Systems in ESSU\' - Status: Pending Review', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:17:51'),
(111, 3, 'update', 'faculty_research_outputs', 3, 'Research output \'test\' (v1) for project \'Simulation of Integrated Systems in ESSU\' has been Needs Revision | Review comments: test', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:18:12'),
(112, 3, 'create', 'faculty_research_outputs', 4, 'Uploaded research output: \'test2\' (Version 2 - Revision) for project \'Simulation of Integrated Systems in ESSU\' - Status: Pending Review', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:18:37'),
(113, 3, 'update', 'faculty_research_outputs', 4, 'Research output \'test2\' (v2) for project \'Simulation of Integrated Systems in ESSU\' has been Accepted', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:18:48'),
(114, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:19:07'),
(115, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:19:14'),
(116, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.227.18', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-16 07:19:54'),
(117, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 03:17:06'),
(118, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 03:20:08'),
(119, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 03:20:19'),
(120, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 03:20:22'),
(121, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 03:20:33'),
(122, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:44:14'),
(123, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '120.28.185.88', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-18 06:44:42'),
(124, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '120.28.185.88', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-18 06:45:43'),
(125, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '120.28.185.88', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-18 06:47:52'),
(126, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:48:31'),
(127, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:49:50'),
(128, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:50:06'),
(129, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:50:58'),
(130, 1, 'view', 'users', NULL, 'Accessed user management page', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:51:17'),
(131, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:51:21'),
(132, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:51:36'),
(133, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.232.204', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 06:51:50'),
(134, 5, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 08:26:49'),
(135, 5, 'logout', NULL, NULL, 'User \'francevista@gmail.com\' logged out', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 08:27:00'),
(136, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 08:38:14'),
(137, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 08:39:46'),
(138, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Linux; Android 13; RMX3511 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/143.0.7499.192 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/544.0.0.17.379;]', '2026-01-18 08:46:35'),
(139, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.60', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-18 11:56:14'),
(140, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-19 04:52:41'),
(141, 3, 'update', 'faculty_researchers', 6, 'Synced faculty data from HR System: Jyl Derwin Martires', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-19 04:56:28'),
(142, 3, 'update', 'faculty_researchers', 6, 'Synced faculty data from HR System: Jyl Derwin Martires', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-19 04:56:30'),
(143, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-19 04:59:44'),
(144, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-19 04:59:50'),
(145, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-20 03:55:53'),
(146, 1, 'login', NULL, NULL, 'User \'arvinnegrillo1114@gmail.com\' logged in successfully', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 07:20:58'),
(147, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 07:21:02'),
(148, 1, 'create', 'faculty_research_outputs', 5, 'Uploaded research output: \'test\' (Version 1) for project \'test\' - Status: Pending Review', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 07:28:49'),
(149, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 07:29:21'),
(150, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 07:29:40'),
(151, 1, 'update', 'system', NULL, 'System updates installed: 7 updates, 0 errors', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:20:43'),
(152, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:21:05'),
(153, 1, 'update', 'faculty_researchers', 3, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:30:31'),
(154, 1, 'update', 'faculty_researchers', 4, 'Synced faculty data from HR System: Francine Vista', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:30:53'),
(155, 1, 'update', 'faculty_researchers', 5, 'Synced faculty data from HR System: Sample Martires', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:30:59'),
(156, 1, 'update', 'faculty_researchers', 6, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-20 09:31:05'),
(157, 1, 'login', NULL, NULL, 'User \'arvinnegrillo1114@gmail.com\' logged in successfully', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 00:51:49'),
(158, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 00:51:54'),
(159, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 00:52:07'),
(160, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 00:52:12'),
(161, 1, 'update', 'faculty_researchers', 3, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 01:57:09'),
(162, 1, 'delete', 'faculty_researchers', 2, 'Deleted faculty researcher: Test, test and all related records (projects, team, costs, outputs, education)', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:50:02'),
(163, 1, 'delete', 'faculty_researchers', 1, 'Deleted faculty researcher: askdjsa, ashjd and all related records (projects, team, costs, outputs, education)', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:52:51'),
(164, 1, 'create', 'faculty_research_outputs', 6, 'Uploaded research output: \'asdasda\' (Version 1) for project \'zxczxczcz\' - Status: Pending Review', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:54:26'),
(165, 1, 'update', 'faculty_research_outputs', 6, 'Research output \'asdasda\' (v1) for project \'zxczxczcz\' has been Needs Revision', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:54:36'),
(166, 1, 'create', 'faculty_research_outputs', 7, 'Uploaded research output: \'asdsadasdasdasd\' (Version 2 - Revision) for project \'zxczxczcz\' - Status: Pending Review', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:54:54'),
(167, 1, 'update', 'faculty_research_outputs', 7, 'Research output \'asdsadasdasdasd\' (v2) for project \'zxczxczcz\' has been Accepted', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:55:04'),
(168, 1, 'create', 'faculty_research_outputs', 8, 'Uploaded research output: \'fgdfgdfgdfg\' (Version 1) for project \'zxczxczcz\' - Status: Pending Review', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:55:24'),
(169, 1, 'delete', 'faculty_research_outputs', 7, 'Deleted research output: \'asdsadasdasdasd\' (v2)', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:55:43'),
(170, 1, 'update', 'faculty_researchers', 6, 'Synced faculty data from HR System: Jyl Derwin Martires', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:56:27'),
(171, 1, 'delete', 'faculty_researchers', 3, 'Deleted faculty researcher: Martires, Jyl Derwin and all related records (projects, team, costs, outputs, education)', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:56:49'),
(172, 1, 'create', 'faculty_researchers', 7, 'Imported faculty from HR System: Jyl Derwin Martires (HR ID: xd123)', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:57:15'),
(173, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:57:31'),
(174, 1, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '112.198.226.67', 'Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0', '2026-01-21 02:57:58'),
(175, 5, 'login', NULL, NULL, 'User \'francevista@gmail.com\' logged in successfully', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:44:28'),
(176, 5, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:44:32'),
(177, 5, 'logout', NULL, NULL, 'User \'francevista@gmail.com\' logged out', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:44:55'),
(178, 3, 'login', NULL, NULL, 'User \'drei@gmail.com\' logged in successfully', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:45:59'),
(179, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:46:01'),
(180, 3, 'create', 'faculty_researchers', 8, 'Imported faculty from HR System: Jyl Derwin Martires (HR ID: asdasda)', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:47:42'),
(181, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '49.147.126.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-23 12:48:29'),
(182, 1, 'login', NULL, NULL, 'User \'arvinnegrillo1114@gmail.com\' logged in successfully', '112.198.225.66', 'Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-01-25 10:38:59'),
(183, 1, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '112.198.225.66', 'Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-01-25 10:39:04'),
(184, 3, 'login', NULL, NULL, 'User \'drei@gmail.com\' logged in successfully', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-25 11:40:39'),
(185, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-25 11:40:42'),
(186, 3, 'update', 'faculty_researchers', 8, 'Synced faculty data from HR System: Jyl Derwin Martires', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-25 11:42:22'),
(187, 3, 'view', 'activity_logs', NULL, 'Accessed activity logs page', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-25 11:42:52'),
(188, 3, 'logout', NULL, NULL, 'User \'drei@gmail.com\' logged out', '158.62.56.123', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-25 11:45:21'),
(189, 3, 'login', NULL, NULL, 'User \'drei@gmail.com\' logged in successfully', '120.28.185.121', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-25 12:50:16'),
(190, 3, 'login', NULL, NULL, 'User \'drei@gmail.com\' logged in successfully', '120.28.185.121', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-25 13:29:05'),
(191, 3, 'view', 'research_outputs', NULL, 'Accessed research management dashboard', '120.28.185.121', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2026-01-25 13:29:10');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_education`
--

CREATE TABLE `faculty_education` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `degree_program` varchar(255) DEFAULT NULL,
  `college_university` varchar(255) DEFAULT NULL,
  `has_thesis` enum('Yes','No') DEFAULT 'No',
  `year_graduated` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_projects`
--

CREATE TABLE `faculty_projects` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `project_status` enum('on-going','completed','published') DEFAULT 'on-going',
  `classification` varchar(100) DEFAULT NULL,
  `funding_source` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `parent_project_id` int(11) DEFAULT NULL,
  `is_project_leader` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_projects`
--

INSERT INTO `faculty_projects` (`id`, `faculty_id`, `title`, `project_status`, `classification`, `funding_source`, `nature_of_involvement`, `start_date`, `end_date`, `parent_project_id`, `is_project_leader`, `created_at`) VALUES
(4, 6, 'kjfsdkfj', 'on-going', '', 'DOST', 'Assistant Researcher', '2026-01-05', '2026-03-06', NULL, 1, '2026-01-16 06:54:12'),
(5, 4, 'Simulation of Integrated Systems in ESSU', 'on-going', 'Applied', 'DOST', 'Co-Researcher', '2025-01-23', '2026-03-06', 3, 0, '2026-01-16 06:59:57'),
(6, 6, 'test', 'on-going', 'Basic', 'DOST', 'Lead Researcher', '2025-06-11', '2026-01-30', NULL, 1, '2026-01-20 07:28:21'),
(7, 6, 'zxczxczcz', 'published', 'Applied', 'DOST', 'Researcher', '2025-06-09', '2026-01-29', NULL, 1, '2026-01-21 02:53:33'),
(8, 4, 'zxczxczcz', 'published', 'Applied', 'DOST', 'Co-Researcher', '2025-06-09', '2026-01-29', 7, 0, '2026-01-21 02:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_costs`
--

CREATE TABLE `faculty_project_costs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_project_costs`
--

INSERT INTO `faculty_project_costs` (`id`, `project_id`, `item_of_expenditure`, `institution_fund`, `government_fund`, `government_fund_source`, `private_fund`, `private_fund_source`, `foreign_fund`, `foreign_fund_source`, `other_sources`, `other_sources_name`, `created_at`) VALUES
(3, 5, '243234', '2342.00', '234.00', '', '234.00', '', '234.00', '', '234.00', '', '2026-01-16 06:59:57');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_team`
--

CREATE TABLE `faculty_project_team` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` varchar(50) DEFAULT NULL,
  `highest_attainment` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_project_team`
--

INSERT INTO `faculty_project_team` (`id`, `project_id`, `name`, `faculty_rank`, `employment_status`, `highest_attainment`, `nature_of_involvement`, `created_at`) VALUES
(2, 7, 'Vista, Francine Ladera', 'Infirmary Doctor', '', 'Not specified', 'Co-Researcher', '2026-01-21 02:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_researchers`
--

CREATE TABLE `faculty_researchers` (
  `id` int(11) NOT NULL,
  `hr_employee_id` varchar(50) DEFAULT NULL,
  `faculty_number` varchar(50) DEFAULT NULL,
  `last_name` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` enum('Full-Time','Part-Time') DEFAULT 'Full-Time',
  `home_unit` varchar(150) DEFAULT NULL,
  `department` varchar(150) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_synced_at` datetime DEFAULT NULL,
  `is_synced` tinyint(1) DEFAULT 0,
  `hr_data_json` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_researchers`
--

INSERT INTO `faculty_researchers` (`id`, `hr_employee_id`, `faculty_number`, `last_name`, `first_name`, `middle_name`, `home_address`, `telephone`, `fax`, `email`, `faculty_rank`, `employment_status`, `home_unit`, `department`, `profile_pic`, `created_by`, `created_at`, `last_synced_at`, `is_synced`, `hr_data_json`) VALUES
(4, 'EMP0001', 'EMP0001', 'Vista', 'Francine', 'Ladera', '333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar', '09564062855', '', 'jymartires@gmail.com', 'Infirmary Doctor', '', '', 'Infirmary Office', NULL, 3, '2026-01-16 05:25:42', '2026-01-20 04:30:53', 1, '{\"id\":\"EMP0001\",\"is_deleted\":false,\"deleted_at\":null,\"name\":{\"surname\":\"Vista\",\"first_name\":\"Francine\",\"middle_name\":\"Ladera\",\"name_extension\":null,\"full_name\":\"Francine Ladera Vista\"},\"contact\":{\"email\":\"jymartires@gmail.com\",\"mobile\":\"09564062855\",\"telephone\":\"09564062855\"},\"employment\":{\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"date_hired\":\"2025-12-01\",\"date_regularized\":\"2025-12-02\"},\"department\":{\"id\":7,\"code\":\"INF-OFF\",\"name\":\"Infirmary Office\",\"type\":\"administrative\",\"faculty_id\":null},\"position\":{\"id\":23,\"code\":\"INF-DOC\",\"name\":\"Infirmary Doctor\"},\"personal\":{\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Married\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null},\"address\":{\"residential\":{\"house_no\":\"333\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"},\"permanent\":{\"house_no\":\"33\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"}},\"government_ids\":{\"gsis\":\"12345678901\",\"pagibig\":\"9876-5432-1098\",\"philhealth\":\"12-345678901-2\",\"sss\":\"34-5678912-3\",\"tin\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null},\"special_categories\":{\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"indigenous_group\":null}}'),
(6, 'EMP0003', 'EMP0003', 'Martires', 'Jyl Derwin', 'Sabungan', '333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar', '09564062855', '', 'jymartires@gmail.com', 'Infirmary Doctor', '', '', 'Infirmary Office', NULL, 3, '2026-01-16 06:53:24', '2026-01-20 21:56:27', 1, '{\"id\":\"EMP0003\",\"is_deleted\":false,\"deleted_at\":null,\"name\":{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"full_name\":\"Jyl Derwin Sabungan Martires\"},\"contact\":{\"email\":\"jymartires@gmail.com\",\"mobile\":\"09564062855\",\"telephone\":\"09564062855\"},\"employment\":{\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"date_hired\":\"2025-12-02\",\"date_regularized\":\"2025-12-03\"},\"department\":{\"id\":7,\"code\":\"INF-OFF\",\"name\":\"Infirmary Office\",\"type\":\"administrative\",\"faculty_id\":null},\"position\":{\"id\":23,\"code\":\"INF-DOC\",\"name\":\"Infirmary Doctor\"},\"personal\":{\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null},\"address\":{\"residential\":{\"house_no\":\"333\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"},\"permanent\":{\"house_no\":\"33\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"}},\"government_ids\":{\"gsis\":\"12345678901\",\"pagibig\":\"9876-5432-1098\",\"philhealth\":\"12-345678901-2\",\"sss\":\"34-5678912-3\",\"tin\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null},\"special_categories\":{\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"indigenous_group\":null}}'),
(7, 'XD123', 'XD123', 'Martires', 'Jyl Derwin', 'Sabungan', '333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar', '09564062855', '', 'jymartires@gmail.com', 'Maintenace Head', '', '', 'Maintenance Office', NULL, 1, '2026-01-21 02:57:15', '2026-01-20 21:57:15', 1, '{\"id\":\"xd123\",\"is_deleted\":false,\"deleted_at\":null,\"name\":{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"full_name\":\"Jyl Derwin Sabungan Martires\"},\"contact\":{\"email\":\"jymartires@gmail.com\",\"mobile\":\"09564062855\",\"telephone\":\"09564062855\"},\"employment\":{\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"date_hired\":\"2025-12-01\",\"date_regularized\":\"2025-12-02\"},\"department\":{\"id\":6,\"code\":\"MTNC-OFF\",\"name\":\"Maintenance Office\",\"type\":\"administrative\",\"faculty_id\":null},\"position\":{\"id\":22,\"code\":\"MTNC-HEAD\",\"name\":\"Maintenace Head\"},\"personal\":{\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null},\"address\":{\"residential\":{\"house_no\":\"333\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"},\"permanent\":{\"house_no\":\"33\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"}},\"government_ids\":{\"gsis\":\"12345678901\",\"pagibig\":\"9876-5432-1098\",\"philhealth\":\"12-345678901-2\",\"sss\":\"34-5678912-3\",\"tin\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null},\"special_categories\":{\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"indigenous_group\":null}}'),
(8, 'ASDASDA', 'ASDASDA', 'Martires', 'Jyl Derwin', 'Sabungan', '333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar', '09564062855', '', 'jymartires@gmail.com', 'Supply Officer', '', '', 'Supply Office', NULL, 3, '2026-01-23 12:47:42', '2026-01-25 06:42:22', 1, '{\"id\":\"asdasda\",\"is_deleted\":false,\"deleted_at\":null,\"name\":{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"full_name\":\"Jyl Derwin Sabungan Martires\"},\"contact\":{\"email\":\"jymartires@gmail.com\",\"mobile\":\"09564062855\",\"telephone\":\"09564062855\"},\"employment\":{\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"date_hired\":\"2025-12-01\",\"date_regularized\":\"2025-12-02\"},\"department\":{\"id\":5,\"code\":\"SPP-OFF\",\"name\":\"Supply Office\",\"type\":\"administrative\",\"faculty_id\":null},\"position\":{\"id\":21,\"code\":\"SPP-OFCR\",\"name\":\"Supply Officer\"},\"personal\":{\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Married\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null},\"address\":{\"residential\":{\"house_no\":\"333\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"},\"permanent\":{\"house_no\":\"33\",\"street\":\"Real Street\",\"subdivision\":\"Santos Village\",\"barangay\":\"Songco\",\"city\":\"Borongan City\",\"province\":\"Eastern Samar\",\"zip_code\":\"6800\"}},\"government_ids\":{\"gsis\":\"12345678901\",\"pagibig\":\"9876-5432-1098\",\"philhealth\":\"12-345678901-2\",\"sss\":\"34-5678912-3\",\"tin\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null},\"special_categories\":{\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"indigenous_group\":null}}');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_research_outputs`
--

CREATE TABLE `faculty_research_outputs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL,
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_research_outputs`
--

INSERT INTO `faculty_research_outputs` (`id`, `project_id`, `output_title`, `output_type`, `file_name`, `file_path`, `file_size`, `output_status`, `version`, `is_latest_version`, `uploaded_by`, `upload_date`, `reviewer_id`, `review_date`, `review_comments`, `parent_output_id`) VALUES
(5, 6, 'test', 'Dissertation', 't.zip', 'uploads/research_outputs/output_6_1768894129_696f2eb160f37.zip', 941, 'pending', 1, 1, 6, '2026-01-19 23:28:49', NULL, NULL, NULL, NULL),
(6, 7, 'asdasda', 'Presentation', 't.zip', 'uploads/research_outputs/output_7_1768964066_69703fe23e8d1.zip', 941, 'needs_revision', 1, 0, 6, '2026-01-20 18:54:26', 1, '2026-01-20 18:54:36', '', NULL),
(8, 7, 'fgdfgdfgdfg', 'Dissertation', 't.zip', 'uploads/research_outputs/output_7_1768964124_6970401cbe504.zip', 941, 'pending', 1, 1, 6, '2026-01-20 18:55:24', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hr_sync_history`
--

CREATE TABLE `hr_sync_history` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `action_type` enum('import','update') NOT NULL,
  `hr_employee_id` varchar(100) DEFAULT NULL,
  `synced_by` int(11) NOT NULL,
  `synced_at` timestamp NULL DEFAULT current_timestamp(),
  `data_snapshot` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hr_sync_history`
--

INSERT INTO `hr_sync_history` (`id`, `faculty_id`, `action_type`, `hr_employee_id`, `synced_by`, `synced_at`, `data_snapshot`) VALUES
(2, 4, 'update', 'EMP0001', 1, '2026-01-20 09:30:53', '{\"hr_employee_id\":\"EMP0001\",\"faculty_number\":\"EMP0001\",\"last_name\":\"Vista\",\"first_name\":\"Francine\",\"middle_name\":\"Ladera\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Infirmary Doctor\",\"employment_status\":\"Regular\",\"department\":\"Infirmary Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-20 04:30:53\",\"hr_data_json\":\"{\\\"id\\\":\\\"EMP0001\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Vista\\\",\\\"first_name\\\":\\\"Francine\\\",\\\"middle_name\\\":\\\"Ladera\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Francine Ladera Vista\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-01\\\",\\\"date_regularized\\\":\\\"2025-12-02\\\"},\\\"department\\\":{\\\"id\\\":7,\\\"code\\\":\\\"INF-OFF\\\",\\\"name\\\":\\\"Infirmary Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":23,\\\"code\\\":\\\"INF-DOC\\\",\\\"name\\\":\\\"Infirmary Doctor\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Female\\\",\\\"civil_status\\\":\\\"Married\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\"}'),
(4, 6, 'update', 'EMP0003', 1, '2026-01-20 09:31:05', '{\"hr_employee_id\":\"EMP0003\",\"faculty_number\":\"EMP0003\",\"last_name\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Infirmary Doctor\",\"employment_status\":\"Regular\",\"department\":\"Infirmary Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-20 04:31:05\",\"hr_data_json\":\"{\\\"id\\\":\\\"EMP0003\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Martires\\\",\\\"first_name\\\":\\\"Jyl Derwin\\\",\\\"middle_name\\\":\\\"Sabungan\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Jyl Derwin Sabungan Martires\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-02\\\",\\\"date_regularized\\\":\\\"2025-12-03\\\"},\\\"department\\\":{\\\"id\\\":7,\\\"code\\\":\\\"INF-OFF\\\",\\\"name\\\":\\\"Infirmary Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":23,\\\"code\\\":\\\"INF-DOC\\\",\\\"name\\\":\\\"Infirmary Doctor\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Male\\\",\\\"civil_status\\\":\\\"Single\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\"}'),
(6, 6, 'update', 'EMP0003', 1, '2026-01-21 02:56:27', '{\"hr_employee_id\":\"EMP0003\",\"faculty_number\":\"EMP0003\",\"last_name\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Infirmary Doctor\",\"employment_status\":\"Regular\",\"department\":\"Infirmary Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-20 21:56:27\",\"hr_data_json\":\"{\\\"id\\\":\\\"EMP0003\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Martires\\\",\\\"first_name\\\":\\\"Jyl Derwin\\\",\\\"middle_name\\\":\\\"Sabungan\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Jyl Derwin Sabungan Martires\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-02\\\",\\\"date_regularized\\\":\\\"2025-12-03\\\"},\\\"department\\\":{\\\"id\\\":7,\\\"code\\\":\\\"INF-OFF\\\",\\\"name\\\":\\\"Infirmary Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":23,\\\"code\\\":\\\"INF-DOC\\\",\\\"name\\\":\\\"Infirmary Doctor\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Male\\\",\\\"civil_status\\\":\\\"Single\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\"}'),
(7, 7, 'import', 'XD123', 1, '2026-01-21 02:57:15', '{\"hr_employee_id\":\"XD123\",\"faculty_number\":\"XD123\",\"last_name\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Maintenace Head\",\"employment_status\":\"Regular\",\"department\":\"Maintenance Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-20 21:57:15\",\"hr_data_json\":\"{\\\"id\\\":\\\"xd123\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Martires\\\",\\\"first_name\\\":\\\"Jyl Derwin\\\",\\\"middle_name\\\":\\\"Sabungan\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Jyl Derwin Sabungan Martires\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-01\\\",\\\"date_regularized\\\":\\\"2025-12-02\\\"},\\\"department\\\":{\\\"id\\\":6,\\\"code\\\":\\\"MTNC-OFF\\\",\\\"name\\\":\\\"Maintenance Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":22,\\\"code\\\":\\\"MTNC-HEAD\\\",\\\"name\\\":\\\"Maintenace Head\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Male\\\",\\\"civil_status\\\":\\\"Single\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\",\"created_by\":1}'),
(8, 8, 'import', 'ASDASDA', 3, '2026-01-23 12:47:42', '{\"hr_employee_id\":\"ASDASDA\",\"faculty_number\":\"ASDASDA\",\"last_name\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Supply Officer\",\"employment_status\":\"Regular\",\"department\":\"Supply Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-23 07:47:42\",\"hr_data_json\":\"{\\\"id\\\":\\\"asdasda\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Martires\\\",\\\"first_name\\\":\\\"Jyl Derwin\\\",\\\"middle_name\\\":\\\"Sabungan\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Jyl Derwin Sabungan Martires\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-01\\\",\\\"date_regularized\\\":\\\"2025-12-02\\\"},\\\"department\\\":{\\\"id\\\":5,\\\"code\\\":\\\"SPP-OFF\\\",\\\"name\\\":\\\"Supply Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":21,\\\"code\\\":\\\"SPP-OFCR\\\",\\\"name\\\":\\\"Supply Officer\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Female\\\",\\\"civil_status\\\":\\\"Married\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\",\"created_by\":3}'),
(9, 8, 'update', 'ASDASDA', 3, '2026-01-25 11:42:22', '{\"hr_employee_id\":\"ASDASDA\",\"faculty_number\":\"ASDASDA\",\"last_name\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"email\":\"jymartires@gmail.com\",\"telephone\":\"09564062855\",\"fax\":\"\",\"faculty_rank\":\"Supply Officer\",\"employment_status\":\"Regular\",\"department\":\"Supply Office\",\"home_unit\":\"\",\"home_address\":\"333, Real Street, Santos Village, Songco, Borongan City, Eastern Samar\",\"is_synced\":1,\"last_synced_at\":\"2026-01-25 06:42:22\",\"hr_data_json\":\"{\\\"id\\\":\\\"asdasda\\\",\\\"is_deleted\\\":false,\\\"deleted_at\\\":null,\\\"name\\\":{\\\"surname\\\":\\\"Martires\\\",\\\"first_name\\\":\\\"Jyl Derwin\\\",\\\"middle_name\\\":\\\"Sabungan\\\",\\\"name_extension\\\":null,\\\"full_name\\\":\\\"Jyl Derwin Sabungan Martires\\\"},\\\"contact\\\":{\\\"email\\\":\\\"jymartires@gmail.com\\\",\\\"mobile\\\":\\\"09564062855\\\",\\\"telephone\\\":\\\"09564062855\\\"},\\\"employment\\\":{\\\"status\\\":\\\"active\\\",\\\"employment_status\\\":\\\"Regular\\\",\\\"employee_type\\\":\\\"Non-Teaching\\\",\\\"date_hired\\\":\\\"2025-12-01\\\",\\\"date_regularized\\\":\\\"2025-12-02\\\"},\\\"department\\\":{\\\"id\\\":5,\\\"code\\\":\\\"SPP-OFF\\\",\\\"name\\\":\\\"Supply Office\\\",\\\"type\\\":\\\"administrative\\\",\\\"faculty_id\\\":null},\\\"position\\\":{\\\"id\\\":21,\\\"code\\\":\\\"SPP-OFCR\\\",\\\"name\\\":\\\"Supply Officer\\\"},\\\"personal\\\":{\\\"birth_date\\\":\\\"2004-07-22\\\",\\\"birth_place\\\":\\\"Catarman, Northern Samar\\\",\\\"sex\\\":\\\"Female\\\",\\\"civil_status\\\":\\\"Married\\\",\\\"citizenship\\\":\\\"Filipino\\\",\\\"dual_citizenship\\\":false,\\\"citizenship_type\\\":null},\\\"address\\\":{\\\"residential\\\":{\\\"house_no\\\":\\\"333\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"},\\\"permanent\\\":{\\\"house_no\\\":\\\"33\\\",\\\"street\\\":\\\"Real Street\\\",\\\"subdivision\\\":\\\"Santos Village\\\",\\\"barangay\\\":\\\"Songco\\\",\\\"city\\\":\\\"Borongan City\\\",\\\"province\\\":\\\"Eastern Samar\\\",\\\"zip_code\\\":\\\"6800\\\"}},\\\"government_ids\\\":{\\\"gsis\\\":\\\"12345678901\\\",\\\"pagibig\\\":\\\"9876-5432-1098\\\",\\\"philhealth\\\":\\\"12-345678901-2\\\",\\\"sss\\\":\\\"34-5678912-3\\\",\\\"tin\\\":\\\"987-654-321\\\",\\\"agency_employee_no\\\":\\\"2023-001245\\\",\\\"government_issued_id\\\":\\\"2134234\\\",\\\"id_number\\\":\\\"2342455\\\",\\\"id_date_issued\\\":\\\"2024-09-15\\\",\\\"id_place_of_issue\\\":null},\\\"special_categories\\\":{\\\"pwd_id_no\\\":null,\\\"solo_parent_id_no\\\":null,\\\"indigenous_group\\\":null}}\"}');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_tokens`
--

CREATE TABLE `oauth_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_token` text NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `token_type` varchar(50) DEFAULT 'Bearer',
  `expires_at` datetime NOT NULL,
  `scope` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oauth_tokens`
--

INSERT INTO `oauth_tokens` (`id`, `user_id`, `access_token`, `refresh_token`, `token_type`, `expires_at`, `scope`, `created_at`, `updated_at`) VALUES
(1, 1, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIwMTliMDJhYS1mYWU3LTcyYTktOWVlYS1iODBjZTAxOGQyNmIiLCJqdGkiOiJiNTI4MGFkNjRkNjBlMmU5M2RkMWE1MDg1NDZmODBiY2Q0OTFlZGQwZmIxN2U0ODAwZGYxOGE4MGQ3YWJiNTg5YjQ3M2MzZTUzZGI1MTQ1NCIsImlhdCI6MTc2OTMzNzUzNy45Mzg0MTcsIm5iZiI6MTc2OTMzNzUzNy45Mzg0MiwiZXhwIjoxNzY5MzQxMTM3LjkzMjU3NCwic3ViIjoiNCIsInNjb3BlcyI6WyJvcGVuaWQiLCJwcm9maWxlIiwiZW1haWwiXX0.sej6cgejnxe_-Rdow1X7yzOkc0x1CXmC5pEHuSlwezhF4IMHSBXcEloj_Xvh4sZZeP1C6Esust_hJ2oh_06zwTbjSm_hVF2u-nsp7pbv4zhF7ss8c0NWhbuqm7mqKPQvyIErl0tYfrN-V48uL3d5_7WuyQnBWgjs6-boiCA396PWammcf5Be7_38fj78p4NSCWZ46s0XEkh_RYzqG1dOiQUHcU4IUCYFno7FzxZ-d1gbv2dfIVNGZXBaxZt2mStCbCnE-l9R_tMdmuNSBDM8aqd0e2eSsk8Dm_nNpBrrwnpLLCxDE84iXQP1UX_18D3aEhDj_QYOMiDkEYRrq3poywM4d1-3ussGV-U63do9KA5Wv52H85aYMjdIYbKq7PROu8xh8YfHiBPeOPKyQLMprKqjmZFbtJcTNvJuD4kuYX42RsEx4ux6WmWwg61IGPC8_8GcY9qs_adByP_CtTDbof90g0Nz5SQK84a53-CjZsubSbCiUf_gA3l143RAcV3YizwqVjvnG4rYPtCaAzfj8_xL0ZgQ9O7kMMc6sjydOKUQXOkgoGW8tOWgTRmTG5Pkyy4EHk69PDWYy3UFqtgC8HkNY95GS2wY1SCh_lO9Dks8oVYX_O6umnHXVNtX9WF0AspOtkM8g_aKCk0b64TYDdrkJIuBvAU3jNPUgVj_cs0', 'def5020082eea83cd37daf8be8f9dc16733bae504bd3c28ee4684a1d3e83585be59b476d3bf4eddcde410e4cdb700b67f1a4bd9799ae609d5d9294ce661e4d164dd0ccde834292d4b0a55473e7dd2ce970d57c8051a751efaf1d8a057b8097694425ddbc0816ddc67fe9e419ffec2b77b4e7ff2686bbf95236bfe36b5d3f32724f2bc7127274fa3df450c48a89520a707d6b77436d367ce0e8bb8adc657192a89b9342b41a6c51db59e1e6c4e7c5d940b8cce97fd18628309ce44aae8ffd6759445b204337fab550ac5d2c2c3f48d2082850353529408a7be88a05b9161765c0e64843b81138ddacc768a692e053da3f57c702067cf8d0e7c49c1b7b85048a2cb2f995b73afb009d18a84856dff583af901e4a5a3dae5c99b1e301729d4dd6ef8125ead2441f80c23f57d1a7f748de20ba6af7940c551c70d9536bffb7b5619944b08723612514cf1b6f6afb1db1cf7516cc71835012bf097c56bcf8f1eaba8555db31e3608706c82d3134f2183bd315b240ad26ff1fb69970fe928cb6bcb451f823f37e880a5f32852770133b2680b608262889c53272dc8777bd91c7690885', 'Bearer', '2026-01-25 06:38:59', 'openid profile email', '2026-01-20 07:20:58', '2026-01-25 10:38:59'),
(7, 5, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIwMTliMDJhYS1mYWU3LTcyYTktOWVlYS1iODBjZTAxOGQyNmIiLCJqdGkiOiIwMjc0MWIwZjFiODdlOTllODIwNzdmMzY4Y2Y1Mjg4NTk2NzViOGU4ZTAwZWE1NmU1ZWViOTQzMGFmYzkyMjExYzI4MmUzMDQ5OGQ2NTEyOCIsImlhdCI6MTc2OTE3MjI2Ny4zMDA1MjEsIm5iZiI6MTc2OTE3MjI2Ny4zMDA1MjQsImV4cCI6MTc2OTE3NTg2Ny4xNjk3NDcsInN1YiI6IjciLCJzY29wZXMiOlsib3BlbmlkIiwicHJvZmlsZSIsImVtYWlsIl19.RUSkBozRibRUSg4gz0IvHeThMXSEnsPV9AATvi-hypmVjaPI0mEmwJkXw5IH4PMN733DPQPaeFY110BKauWuw1jmgINkfyHI4TyTHIqF-p3cwhl--FTjIQgGp-fvuJGT3a6VZ8FE6tuMb3mtF8nOjMPRDtd9F7tmKdQQWBfAk71MEH9_lPZxiH_nhGv5tpgeeSEljsLEOVgrz3ANEHslvNZBrO7OtprMqpxeEP-Z6x-11c05v-_Yu6GXElbRuXHiMSv_o2iKTAkzKSzQ9frm80ldlDp4x0dPkCXTZ5fsxPJcARI2Gf6AynorfXn2-iPWfaaufVPhhVF47SYvPvkgaIO81fzN4MrBEK-R74172KG6ZVQoSQkGGZiOGjLxCK7ZL8OOmZGUgi41F-jTXjC6mFlT3xhOdjMVAS4839qwIQC5K_bPp4zpa7vvNxal-hyfWb-2rQW-TZiyVTtJpUzxKKkAdZGXZCcHaIyGgyAAPdKszQb908Ve8d6upHmTjcTX2l36iXmERRAU8w5ypOHvUd8MgGeA7r74noDo-oZ3cp-BDDQ4Pclb9-AbI8tYeSc8IITi9ZVQO-74WK4Isu-hul4RU7l1LtuunHzqz7OdJhLL7Uxd7zEGLLYvbAnzPzPsR8hP1u4N3q30ry5mxGGNFyDtZjxF7SjBVFbC6oxnkco', 'def50200c23d9eab27a699568bf2c6e2a3f4ec57efccef7a31e315038b8f77bcb2fa0e7a93c50ef329e9da35ff452a8e27b13eea004eb8242b12e316d297a034514ef3f6294d502435a49ba7c57cab42698ceb6a1dfb9bafba6dbe4445d34a7d7b61c2e7fe8a750932be44028279019f9764556be42522428c364af0c9c54bef00b38d9f1932153c1f3050ab51ab9458e45ffc2563035e48109b2f7d283127cb2634cecd09cddba4ab0e54f29b40154fb6061d2ccf7c8a90eb105fadf7f4371e7f89388d09578b49aafdf1130198e0eada8ce9fb847de13c779cce5c2ad3e30b2d9e5759de654ff8c559126adbc9963f2648442dbf6611c6b7c564b1a26cf25c26434b2d5559a440a6179dde8baa03d90e6a7b5cea743af2c58d9fb86e04c5dfc1573d628252caa98ae51ad500801007f74369cb56ed1a1a641573d76fae1c1b2d9670f4a9575c1ff200b20a09c934e1c68a4c687142d788b1d79b260fbe927b58667bc53a9be72ac795cc14e243e178bd34ada24aa219cff4307bbbad3b0d58a64a8ef4aa60ca47fe2b483562aeedb4be01c69191858410392e835d72a89cde', 'Bearer', '2026-01-23 08:44:28', 'openid profile email', '2026-01-23 12:44:28', '2026-01-23 12:44:28'),
(8, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIwMTliMDJhYS1mYWU3LTcyYTktOWVlYS1iODBjZTAxOGQyNmIiLCJqdGkiOiJlZjQ2YjlkM2E4ZmQyNGUwNDhjMmMxYmQwODBmYTM5NDgxMDY3ZGQ4M2YyODdhMDM4NDM5OGE5NTRmMTgxMDY2OTJlMTdhMzA4OTVhMTJiNiIsImlhdCI6MTc2OTM0Nzc0NC41MjY3NjIsIm5iZiI6MTc2OTM0Nzc0NC41MjY3NjcsImV4cCI6MTc2OTM1MTM0NC41MTM0NjIsInN1YiI6IjIiLCJzY29wZXMiOlsib3BlbmlkIiwicHJvZmlsZSIsImVtYWlsIl19.2JSAMRyPb5c_JbMbnVRjmy4ARZME65BIldqtPe7NdJetbUgcJvCmczJMy6SdTab-SXgKdhVI9tE4D-J-O0S3QL0bLopEj26lizm26eTL3SLosc3938TIFgyBmpSElxQjaGLBpPhqIpmt1ON_rUucYvayghUMItewZR1AwwU2SvJAhDf6UdzVmKK3cO6TVSvjNjP009XLQtqIvuwJdxA5ta28r__5xNo1vaI9gTtkI2_KwDl_ZuEIpEBx9bmKG6ztKMxfL8IEE8U9kN9B54S4_kuLLbnxE0FQs4tEh__ZySfXBnDOyK2gV30VujywWI7ee5VuNyO7s-ZDZeAvBoFl9nwaCGma3t-xkd5iCkvsLpwnNYM8t4jwxnDFoCLfvXd8MNIznbrdPcVl4uflQzJKja5k0-8Q7_oDEkxjZrIBvodwsevenYDPOGERf-_he-hi8CqNUydDK7wfYbFOgNF2R1lEN5vx093-ysb4sKJBW1EUHXVAKarKcEkD1UJbXj7Oc9FrGTpQ50r6OXuRV1Lr-0LkyTe1pHwDIMSGGLrZ_Z5vlSjed9K0Lb6zYpBiLSwr_pw32fDLQexhLsyiOXLz2Js7wD09XdnR-1nA0JDoxsPD6h5-8z415JkBKxI2GbNRBStkit0t1ev7aEnuWAwOFZJxMRfh3vWsNn_s5frwB3g', 'def50200fee6af769cd14f8113844d98033d9fc1b333ce11f8be4dc9fb77b19469212abe57bb1136a87126ffb2a52d8b488466da00ff028f2941b931371bb68e74fac09a934b68eee5fc9539b4ab48073462342735f78effe205a975a141901860eec88c7e4a43d7beaa5559c62db858c580045e40c1d4f80243d8e013abd654123fc820cbd6e639d8e24c9d7601c39ca393f45b9fe7c0ec1c20311d899e860084d45a8bd289584935ef7672e559573f4ec401bbc4c3872eb02f771aad34792c2d1f151e05b1a8c795e3c3384c26f2853ee996fb0e8273c0de624d7354715cad069a7a1df18c2df3efa44980362c5b644ba2595e54670e6c63f6de1fa126699b0f5b39edf9a964ae9f00fe281ffcbdb46f74f85bb826d017e8d308ebe79dc921f1899bdf90fd0cb4d645921747494099b3326703eeaa5463c7b3f27ac2303afa9cb47bc9be4098a70f46ca8f9e3f78afefb0edef738fcac747520fcde3ee5b18db18f55bcd97a7a10ba3656079f35482db362283d3b6acde56ce535246311261e71d7b7051d24c41f28af41f97d9fd0f2268b8afcb542778fbd5869147e06469', 'Bearer', '2026-01-25 09:29:05', 'openid profile email', '2026-01-23 12:45:59', '2026-01-25 13:29:05');

-- --------------------------------------------------------

--
-- Table structure for table `coordinator_assignments`
--

CREATE TABLE `coordinator_assignments` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `coordinator_type` enum('faculty','student') NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `research_outputs`
--

CREATE TABLE `research_outputs` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `project_leader` varchar(150) DEFAULT NULL,
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `status` enum('on-going','completed','published') DEFAULT 'on-going',
  `parent_project_id` int(11) DEFAULT NULL COMMENT 'References parent research',
  `is_project_leader` tinyint(1) DEFAULT 1 COMMENT '1 = leader, 0 = member',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_researchers`
--

CREATE TABLE `student_researchers` (
  `id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `research_adviser` varchar(150) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_costs`
--

CREATE TABLE `student_research_costs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_outputs`
--

CREATE TABLE `student_research_outputs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL COMMENT 'References student_researchers.id',
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_team`
--

CREATE TABLE `student_research_team` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL COMMENT 'e.g., Co-Researcher, Research Assistant',
  `department` varchar(150) DEFAULT NULL,
  `contribution` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `coordinator_type` enum('student','faculty') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `user_role`, `coordinator_type`, `created_at`) VALUES
(1, 'arvinnegrillo1114@gmail.com', NULL, '$2y$10$6w7sZfRz9cYsCONNXdwcBezEbuZhGweQ.o9kY6GgRWeVaZE690f.W', 'admin', NULL, '2025-12-09 10:35:06'),
(2, 'khlc@gmail.com', NULL, '$2y$10$flQTLa6fYHvchNX4gu0z6e56chaQCkvvQFdx2RaEvgMb8nRDrhsIS', 'coordinator', 'student', '2025-12-09 10:39:14'),
(3, 'drei@gmail.com', NULL, '$2y$10$xtTIkr3MlYhHy9vZ0QMRb.sDivGQ/kyKlR3G2nmCQCz1uAkNaIjoe', 'coordinator', 'faculty', '2025-12-09 11:30:06'),
(4, 'nerves@gmail.com', NULL, '$2y$10$rbJILUNe58NIK/6/4mGIjeAuspGh5t1l56.am1CDyqc/jE6HiN6CS', 'coordinator', 'faculty', '2026-01-08 05:31:55'),
(5, 'francevista@gmail.com', 'francevista@gmail.com', '$2y$10$6cQjXx.rKGdUCsJzDqjciebxCanMSv10a2eJ63PpTN8xUPr8Ty.NK', 'coordinator', 'student', '2026-01-18 08:26:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_table_affected` (`table_affected`);

--
-- Indexes for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_faculty_education` (`faculty_id`);

--
-- Indexes for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_faculty_projects` (`faculty_id`);

--
-- Indexes for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_costs` (`project_id`);

--
-- Indexes for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_team` (`project_id`);

--
-- Indexes for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faculty_number` (`faculty_number`),
  ADD UNIQUE KEY `unique_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_is_synced` (`is_synced`),
  ADD KEY `idx_last_synced` (`last_synced_at`);

--
-- Indexes for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_latest` (`project_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_faculty_output_uploader` (`uploaded_by`),
  ADD KEY `fk_faculty_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_faculty_output_parent` (`parent_output_id`);

--
-- Indexes for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_faculty` (`faculty_id`),
  ADD KEY `idx_synced_at` (`synced_at`);

--
-- Indexes for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_employee_coordinator` (`employee_id`,`coordinator_type`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_coordinator_type` (`coordinator_type`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_token` (`user_id`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_student_research` (`student_id`);

--
-- Indexes for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_student_created_by` (`created_by`);

--
-- Indexes for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_costs` (`research_id`);

--
-- Indexes for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_latest` (`research_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_student_output_uploader` (`uploaded_by`),
  ADD KEY `fk_student_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_student_output_parent` (`parent_output_id`);

--
-- Indexes for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_id` (`research_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;

--
-- AUTO_INCREMENT for table `faculty_education`
--
ALTER TABLE `faculty_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `research_outputs`
--
ALTER TABLE `research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_researchers`
--
ALTER TABLE `student_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_team`
--
ALTER TABLE `student_research_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD CONSTRAINT `fk_faculty_education` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD CONSTRAINT `fk_faculty_projects` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD CONSTRAINT `fk_project_costs` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD CONSTRAINT `fk_project_team` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD CONSTRAINT `fk_faculty_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD CONSTRAINT `fk_faculty_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `faculty_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_faculty_output_project` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_faculty_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_faculty_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `faculty_researchers` (`id`);

--
-- Constraints for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD CONSTRAINT `hr_sync_history_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD CONSTRAINT `fk_coordinator_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD CONSTRAINT `oauth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD CONSTRAINT `fk_parent_research` FOREIGN KEY (`parent_project_id`) REFERENCES `research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_research` FOREIGN KEY (`student_id`) REFERENCES `student_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD CONSTRAINT `fk_student_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD CONSTRAINT `fk_research_costs` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD CONSTRAINT `fk_student_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `student_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_output_research` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_student_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_student_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `student_researchers` (`id`);

--
-- Constraints for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD CONSTRAINT `fk_research_team` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
