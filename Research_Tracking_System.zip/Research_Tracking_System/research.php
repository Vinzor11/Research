<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';

// Try to load ActivityLogger (optional)
if (file_exists('ActivityLogger.php')) {
    require 'ActivityLogger.php';
    try {
        $logger = new ActivityLogger($conn, $_SESSION['user_id']);
        $logger->logView('research_outputs', null, 'Accessed research management dashboard');
    } catch (Exception $e) {
        error_log("ActivityLogger error: " . $e->getMessage());
    }
}

// Access control
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$currentUserId = $_SESSION['user_id'];

// Redirect researchers to their profile page
if ($userRole === 'researcher') {
    // Check if user is an imported researcher and redirect to their profile
    $checkImported = $conn->query("SELECT imported, employee_id FROM users WHERE id = $currentUserId LIMIT 1");
    if ($checkImported && $checkImported->num_rows > 0) {
        $userData = $checkImported->fetch_assoc();
        if (!empty($userData['imported']) && $userData['imported'] == 1) {
            // User is an imported researcher - find their faculty_researcher record
            $facultyId = null;
            
            // Method 1: Check by user_id
            $facultyStmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
            $facultyStmt->bind_param("i", $currentUserId);
            $facultyStmt->execute();
            $facultyResult = $facultyStmt->get_result();
            
            if ($facultyResult && $facultyResult->num_rows > 0) {
                $facultyData = $facultyResult->fetch_assoc();
                $facultyId = $facultyData['id'];
            }
            $facultyStmt->close();
            
            // Method 2: Fallback - check by employee_id if user_id didn't work
            if (!$facultyId && !empty($userData['employee_id'])) {
                $facultyStmt2 = $conn->prepare("SELECT id FROM faculty_researchers WHERE hr_employee_id = ? LIMIT 1");
                $facultyStmt2->bind_param("s", $userData['employee_id']);
                $facultyStmt2->execute();
                $facultyResult2 = $facultyStmt2->get_result();
                
                if ($facultyResult2 && $facultyResult2->num_rows > 0) {
                    $facultyData2 = $facultyResult2->fetch_assoc();
                    $facultyId = $facultyData2['id'];
                }
                $facultyStmt2->close();
            }
            
            if ($facultyId) {
                // Redirect to faculty researcher profile
                header("Location: facultyresearcherprofile.php?id=" . $facultyId);
                exit;
            }
        }
    }
}

// Check for researcher role and find Faculty Research Coordinators in their parent unit
$researcherMessage = null;
$facultyCoordinators = [];
$adminInfo = null;

if ($userRole === 'researcher') {
    // Get researcher's parent unit from database (stored on login)
    $researcherParentUnitName = null;
    $checkParentUnitColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'parent_unit'");
    $hasParentUnitColumn = $checkParentUnitColumn->num_rows > 0;
    
    if ($hasParentUnitColumn) {
        $stmt = $conn->prepare("SELECT parent_unit FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $currentUserId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $researcherParentUnitName = $row['parent_unit'];
        }
        $stmt->close();
    }
    
    // Fallback to session if not in database
    if (empty($researcherParentUnitName)) {
        $researcherParentUnitName = $_SESSION['unit_parent'] ?? $_SESSION['unit'] ?? $_SESSION['unit_name'] ?? null;
    }
    
    // Final fallback - if still not available, use a generic message
    if (empty($researcherParentUnitName)) {
        $researcherParentUnitName = 'your parent unit';
    }
    
    // Get all admin information except local admin account (username = 'admin')
    $adminQuery = $conn->query("SELECT id, username, fullname, email FROM users WHERE user_role = 'admin' AND username != 'admin' ORDER BY id");
    $adminInfo = [];
    if ($adminQuery) {
        while ($adminRow = $adminQuery->fetch_assoc()) {
            $adminInfo[] = $adminRow;
        }
    }
    
    // Get Faculty Research Coordinators with matching parent_unit from database
    // This is much simpler - just query by parent_unit match
    $facultyCoordinators = [];
    if ($hasParentUnitColumn && !empty($researcherParentUnitName) && $researcherParentUnitName !== 'your parent unit') {
        $coordinatorQuery = $conn->prepare("
            SELECT ca.employee_id, u.id as user_id, u.username, u.email, u.fullname, u.parent_unit
            FROM coordinator_assignments ca
            INNER JOIN users u ON ca.employee_id = u.employee_id
            WHERE ca.coordinator_type = 'faculty' 
            AND ca.status = 'active'
            AND u.user_role = 'coordinator'
            AND u.coordinator_type = 'faculty'
            AND u.parent_unit = ?
        ");
        
        if ($coordinatorQuery) {
            $coordinatorQuery->bind_param("s", $researcherParentUnitName);
            $coordinatorQuery->execute();
            $coordinatorResult = $coordinatorQuery->get_result();
            
            while ($coord = $coordinatorResult->fetch_assoc()) {
                $facultyCoordinators[] = [
                    'name' => !empty($coord['fullname']) ? $coord['fullname'] : $coord['username'],
                    'email' => $coord['email'] ?? '',
                    'username' => $coord['username']
                ];
            }
            
            $coordinatorQuery->close();
        }
    }
    
    // Set message based on findings
    if (!empty($facultyCoordinators)) {
        // Coordinator found - show contact message
        $coordinatorNames = array_map(function($c) {
            return htmlspecialchars($c['name']);
        }, $facultyCoordinators);
        $coordinatorList = implode(', ', $coordinatorNames);
        $coordinatorEmails = array_filter(array_map(function($c) {
            return !empty($c['email']) ? htmlspecialchars($c['email']) : null;
        }, $facultyCoordinators));
        
        $researcherMessage = [
            'type' => 'coordinator_found',
            'coordinators' => $facultyCoordinators,
            'coordinator_list' => $coordinatorList,
            'coordinator_emails' => $coordinatorEmails,
            'parent_unit' => $researcherParentUnitName
        ];
    } else {
        // No coordinator found - show admin contact message
        $researcherMessage = [
            'type' => 'no_coordinator',
            'admins' => $adminInfo,
            'parent_unit' => $researcherParentUnitName
        ];
    }
}

// Coordinators with a type: redirect to their dashboard (so the warning only shows when they have no type)
if ($userRole === 'coordinator' && !empty($coordinatorType)) {
    if ($coordinatorType === 'faculty') {
        header('Location: facultyresearcher.php');
        exit;
    }
    if ($coordinatorType === 'student') {
        header('Location: studentresearcher.php');
        exit;
    }
}

// Optional: refresh coordinator_type from DB for coordinators (e.g. admin just assigned a type)
if ($userRole === 'coordinator' && empty($coordinatorType)) {
    $checkColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
    if ($checkColumn && $checkColumn->num_rows > 0) {
        $stmt = $conn->prepare("SELECT coordinator_type FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $currentUserId);
        $stmt->execute();
        $stmt->bind_result($dbCoordType);
        if ($stmt->fetch() && !empty($dbCoordType)) {
            $_SESSION['coordinator_type'] = $dbCoordType;
            $coordinatorType = $dbCoordType;
            $stmt->close();
            if ($coordinatorType === 'faculty') {
                header('Location: facultyresearcher.php');
                exit;
            }
            if ($coordinatorType === 'student') {
                header('Location: studentresearcher.php');
                exit;
            }
        }
        $stmt->close();
    }
}

// Determine what data to show based on role
$showFaculty = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'faculty');
$showStudent = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'student');

// Build WHERE clauses based on role
$facultyWhereClause = '';
$studentWhereClause = '';

if ($userRole === 'coordinator') {
    // Coordinators only see data they created
    $facultyWhereClause = " AND fr.created_by = " . intval($currentUserId);
    $studentWhereClause = " AND sr.created_by = " . intval($currentUserId);
}
// Admin sees everything (no WHERE clause needed)

// Initialize statistics
$stats = [
    'faculty' => ['total' => 0, 'totalOutputs' => 0, 'ongoing' => 0, 'completed' => 0, 'published' => 0],
    'student' => ['total' => 0, 'totalOutputs' => 0, 'ongoing' => 0, 'completed' => 0, 'published' => 0]
];

// Get Faculty Statistics (if allowed)
if ($showFaculty) {
    // Total faculty researchers created by this user (or all if admin)
    $query = "SELECT COUNT(*) as c FROM faculty_researchers fr WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['total'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Total faculty projects (only for researchers created by this user)
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['totalOutputs'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Ongoing projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE (fp.project_status='on-going' OR fp.project_status='ongoing') 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['ongoing'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Completed projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE fp.project_status='completed' 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['completed'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Published projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE fp.project_status='published' 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['published'] = $result ? $result->fetch_assoc()['c'] : 0;
}

// Get Student Statistics (if allowed)
if ($showStudent) {
    // Total student researchers created by this user (or all if admin)
    $query = "SELECT COUNT(*) as c FROM student_researchers sr WHERE 1=1 $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['total'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Total research outputs (only for students created by this user)
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE 1=1 $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['totalOutputs'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Ongoing research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='on-going' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['ongoing'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Completed research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='completed' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['completed'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Published research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='published' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['published'] = $result ? $result->fetch_assoc()['c'] : 0;
}

// Combined stats for admin
$totalOngoing = $stats['faculty']['ongoing'] + $stats['student']['ongoing'];
$totalCompleted = $stats['faculty']['completed'] + $stats['student']['completed'];
$totalPublished = $stats['faculty']['published'] + $stats['student']['published'];
$totalRegistered = $stats['faculty']['total'] + $stats['student']['total'];

// Get Research Outputs Status (Faculty)
$facultyOutputsStats = ['pending' => 0, 'accepted' => 0, 'needs_revision' => 0, 'rejected' => 0];
if ($showFaculty) {
    $query = "SELECT fro.output_status, COUNT(*) as count 
              FROM faculty_research_outputs fro
              INNER JOIN faculty_projects fp ON fro.project_id = fp.id
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE fro.is_latest_version = 1 
              $facultyWhereClause
              GROUP BY fro.output_status";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            if (isset($facultyOutputsStats[$row['output_status']])) {
                $facultyOutputsStats[$row['output_status']] = $row['count'];
            }
        }
    }
}

// Get Research Outputs Status (Student)
$studentOutputsStats = ['pending' => 0, 'accepted' => 0, 'needs_revision' => 0, 'rejected' => 0];
if ($showStudent) {
    $query = "SELECT sro.output_status, COUNT(*) as count 
              FROM student_research_outputs sro
              INNER JOIN research_outputs ro ON sro.research_id = ro.id
              INNER JOIN student_researchers sr ON ro.student_id = sr.id
              WHERE sro.is_latest_version = 1 
              $studentWhereClause
              GROUP BY sro.output_status";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            if (isset($studentOutputsStats[$row['output_status']])) {
                $studentOutputsStats[$row['output_status']] = $row['count'];
            }
        }
    }
}

// Get Funding Data (Faculty Only)
$fundingAllocated = ['institution' => 0, 'government' => 0, 'private' => 0, 'foreign' => 0, 'other' => 0];
$fundingTotal = 0;
if ($showFaculty) {
    $query = "SELECT 
                SUM(fpc.institution_fund) as institution,
                SUM(fpc.government_fund) as government,
                SUM(fpc.private_fund) as `private`,
                SUM(fpc.foreign_fund) as `foreign`,
                SUM(fpc.other_sources) as other
              FROM faculty_project_costs fpc
              INNER JOIN faculty_projects fp ON fpc.project_id = fp.id
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        $fundingAllocated['institution'] = (float)($row['institution'] ?? 0);
        $fundingAllocated['government'] = (float)($row['government'] ?? 0);
        $fundingAllocated['private'] = (float)($row['private'] ?? 0);
        $fundingAllocated['foreign'] = (float)($row['foreign'] ?? 0);
        $fundingAllocated['other'] = (float)($row['other'] ?? 0);
        $fundingTotal = array_sum($fundingAllocated);
    }
}

// Department-wise data
$facultyByDept = [];
$studentByDept = [];

if ($showFaculty) {
    $query = "SELECT fr.department, COUNT(*) as count 
              FROM faculty_researchers fr 
              WHERE fr.department IS NOT NULL AND fr.department != '' 
              $facultyWhereClause
              GROUP BY fr.department 
              ORDER BY count DESC 
              LIMIT 8";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $facultyByDept[] = $row;
    }
}

if ($showStudent) {
    $query = "SELECT sr.department, COUNT(*) as count 
              FROM student_researchers sr 
              WHERE sr.department IS NOT NULL AND sr.department != '' 
              $studentWhereClause
              GROUP BY sr.department 
              ORDER BY count DESC 
              LIMIT 8";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $studentByDept[] = $row;
    }
}

// Research Category Distribution (Classification)
$researchCategories = [];
if ($showFaculty) {
    $query = "SELECT fp.classification, COUNT(*) as count 
              FROM faculty_projects fp
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE fp.classification IS NOT NULL AND fp.classification != '' 
              $facultyWhereClause
              GROUP BY fp.classification 
              ORDER BY count DESC";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $researchCategories[] = $row;
        }
    }
}

// Recent researchers (only those created by this user if coordinator)
$recentResearchers = [];
if ($showFaculty) {
    $query = "SELECT 'faculty' as type, fr.id, CONCAT(fr.first_name, ' ', fr.last_name) as name, 
              fr.department, fr.created_at 
              FROM faculty_researchers fr 
              WHERE 1=1 $facultyWhereClause
              ORDER BY fr.created_at DESC 
              LIMIT 5";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $recentResearchers[] = $row;
    }
}
if ($showStudent) {
    $query = "SELECT 'student' as type, sr.id, CONCAT(sr.first_name, ' ', sr.last_name) as name, 
              sr.department, sr.created_at 
              FROM student_researchers sr 
              WHERE 1=1 $studentWhereClause
              ORDER BY sr.created_at DESC 
              LIMIT 5";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $recentResearchers[] = $row;
    }
}
usort($recentResearchers, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
$recentResearchers = array_slice($recentResearchers, 0, 8);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Research Dashboard - ESSU</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="researchStyle.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>

<!-- Pass PHP data to JavaScript -->
<script>
window.dashboardData = {
    showFaculty: <?= $showFaculty ? 'true' : 'false' ?>,
    showStudent: <?= $showStudent ? 'true' : 'false' ?>,
    facultyOutputsStats: <?= json_encode($facultyOutputsStats) ?>,
    studentOutputsStats: <?= json_encode($studentOutputsStats) ?>,
    fundingAllocated: <?= json_encode($fundingAllocated) ?>,
    fundingTotal: <?= $fundingTotal ?>,
    researchCategories: <?= json_encode($researchCategories) ?>,
    totalOngoing: <?= $totalOngoing ?>,
    totalCompleted: <?= $totalCompleted ?>,
    totalPublished: <?= $totalPublished ?>,
    facultyStats: <?= json_encode($stats['faculty']) ?>,
    studentStats: <?= json_encode($stats['student']) ?>,
    facultyByDept: <?= json_encode($facultyByDept) ?>,
    studentByDept: <?= json_encode($studentByDept) ?>,
    userRole: '<?= $userRole ?>'
};
</script>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php" class="active"><i class="fa fa-dashboard"></i> Dashboard</a>
        <?php if ($showFaculty): ?>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php endif; ?>
        <?php if ($showStudent): ?>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <?php endif; ?>
        <?php if ($userRole === 'admin'): ?>
            <a href="users.php"><i class="fa fa-users-cog"></i> User Management</a>
            <?php if (file_exists('oauth_settings.php')): ?>
                <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($userRole === 'admin' && file_exists('activity_logs.php')): ?>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
    <div class="header">
        <div class="header-title">
            <i class="fa-solid fa-chart-line"></i>
            <span>Research Dashboard</span>
        </div>
        <div class="header-right">
            <div class="user-info">
                <i class="fa fa-user-circle"></i>
                <span><strong><?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User') ?></strong></span>
                <span class="role-badge">
                    <?php 
                    if ($userRole === 'admin') echo 'Admin';
                    elseif ($coordinatorType === 'faculty') echo 'Faculty Coordinator';
                    elseif ($coordinatorType === 'student') echo 'Student Coordinator';
                    elseif ($userRole === 'researcher') echo 'Researcher';
                    ?>
                </span>
            </div>
        </div>
    </div>

    <div class="content">
        <!-- Quick Actions -->
        <div class="quick-actions">
            <?php if ($userRole === 'admin'): ?>
                <a href="assign_coordinators.php" class="action-btn-link">
                    <i class="fa fa-user-cog"></i> Assign Coordinator Type
                </a>
            <?php endif; ?>
            <?php if ($showFaculty): ?>
                <a href="facultyresearcher.php" class="action-btn-link">
                    <i class="fa fa-chalkboard-teacher"></i> Manage Faculty
                </a>
            <?php endif; ?>
            <?php if ($showStudent): ?>
                <a href="studentresearcher.php" class="action-btn-link">
                    <i class="fa fa-user-graduate"></i> Manage Students
                </a>
            <?php endif; ?>
        </div>

        <!-- Coordinator without type: ask to contact admin -->
        <?php if ($userRole === 'coordinator' && empty($coordinatorType)): ?>
        <div class="coordinator-type-alert" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(217, 119, 6, 0.3); display: flex; align-items: center; gap: 12px;">
            <i class="fa fa-exclamation-triangle" style="font-size: 22px; flex-shrink: 0;"></i>
            <span><strong>Action required:</strong> You are set as a coordinator but do not have a coordinator type yet. Please contact the administrator to assign you a coordinator type (Faculty or Student) so you can access the full dashboard.</span>
        </div>
        <?php endif; ?>
        
        <!-- Researcher: Coordinator found message -->
        <?php if ($researcherMessage && $researcherMessage['type'] === 'coordinator_found'): ?>
        <div class="researcher-alert" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 20px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <i class="fa fa-info-circle" style="font-size: 24px; flex-shrink: 0; align-self: flex-start; margin-top: 0;"></i>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 600;">Access to Researcher Dashboard</h3>
                    <p style="margin: 0 0 15px 0; line-height: 1.6;">
                        To access more features or the full researcher dashboard, please contact your Faculty Research Coordinator<?= count($researcherMessage['coordinators']) > 1 ? 's' : '' ?>:
                    </p>
                    <div style="background: rgba(255, 255, 255, 0.15); padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa fa-user-tie" style="flex-shrink: 0;"></i> <span>Faculty Research Coordinator<?= count($researcherMessage['coordinators']) > 1 ? 's' : '' ?>:</span>
                        </div>
                        <?php foreach ($researcherMessage['coordinators'] as $coord): ?>
                        <div style="margin-bottom: 8px; padding-left: 20px;">
                            <strong><?= htmlspecialchars($coord['name']) ?></strong>
                            <?php if (!empty($coord['email'])): ?>
                                <br style="margin-top: 4px;"><span style="display: inline-flex; align-items: center; gap: 6px;"><i class="fa fa-envelope" style="flex-shrink: 0;"></i> <a href="mailto:<?= htmlspecialchars($coord['email']) ?>" style="color: #93c5fd; text-decoration: none;"><?= htmlspecialchars($coord['email']) ?></a></span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <p style="margin: 0; font-size: 14px; opacity: 0.9; display: flex; align-items: center; gap: 8px;">
                        <i class="fa fa-building" style="flex-shrink: 0;"></i> <span>Unit: <strong><?= htmlspecialchars($researcherMessage['parent_unit']) ?></strong></span>
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Researcher: No coordinator found message -->
        <?php if ($researcherMessage && $researcherMessage['type'] === 'no_coordinator'): ?>
        <div class="researcher-alert" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 20px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(217, 119, 6, 0.3);">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <i class="fa fa-exclamation-triangle" style="font-size: 24px; flex-shrink: 0; align-self: flex-start; margin-top: 0;"></i>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 600;">No Faculty Research Coordinator Available</h3>
                    <p style="margin: 0 0 15px 0; line-height: 1.6;">
                        There are currently no Faculty Research Coordinators assigned in <strong><?= htmlspecialchars($researcherMessage['parent_unit']) ?></strong>.
                    </p>
                    <?php if ($researcherMessage['parent_unit'] === 'your parent unit'): ?>
                    <p style="margin: 0 0 15px 0; font-size: 14px; opacity: 0.9; font-style: italic; display: flex; align-items: center; gap: 8px;">
                        <i class="fa fa-info-circle" style="flex-shrink: 0;"></i> <span>Note: Parent unit information is not available. Please contact the administrator to verify your unit assignment.</span>
                    </p>
                    <?php endif; ?>
                    <?php if (!empty($researcherMessage['admins'])): ?>
                    <div style="background: rgba(255, 255, 255, 0.15); padding: 15px; border-radius: 8px;">
                        <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa fa-user-shield" style="flex-shrink: 0;"></i> <span>Please contact the Administrator<?= count($researcherMessage['admins']) > 1 ? 's' : '' ?>:</span>
                        </div>
                        <?php foreach ($researcherMessage['admins'] as $admin): ?>
                        <div style="padding-left: 20px; margin-bottom: 10px;">
                            <strong>
                                <?php 
                                $displayName = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : htmlspecialchars($admin['username']);
                                echo $displayName;
                                ?>
                            </strong>
                            <?php if (!empty($admin['email'])): ?>
                                <br style="margin-top: 4px;"><span style="display: inline-flex; align-items: center; gap: 6px;"><i class="fa fa-envelope" style="flex-shrink: 0;"></i> <a href="mailto:<?= htmlspecialchars($admin['email']) ?>" style="color: #fef3c7; text-decoration: none;"><?= htmlspecialchars($admin['email']) ?></a></span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p style="margin: 15px 0 0 0; font-size: 14px; opacity: 0.9;">
                        Please contact the system administrator for assistance.
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Data Scope Indicator (for coordinators with type) -->
        <?php if ($userRole === 'coordinator' && !empty($coordinatorType)): ?>
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);">
            <i class="fa fa-info-circle"></i> 
            <strong>Note:</strong> You are viewing only the data you have created. 
            <?php if ($coordinatorType === 'faculty'): ?>
                This includes faculty researchers and your research outputs that you registered.
            <?php elseif ($coordinatorType === 'student'): ?>
                This includes student researchers and your research outputs that you registered.
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Overall Statistics (Admin only) -->
        <?php if ($userRole === 'admin'): ?>
            <div class="section-title">
                <i class="fa fa-chart-pie"></i>
                Overall Research Statistics
            </div>
            <div class="stats-grid">
                <div class="stat-card" style="--delay: 0; --card-color: #f59e0b; --card-color-fade: rgba(245, 158, 11, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $totalOngoing ?></div>
                            <div class="label">On-going Research</div>
                            <div class="subtitle">Combined total</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);"><i class="fa fa-spinner fa-spin"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 1; --card-color: #10b981; --card-color-fade: rgba(16, 185, 129, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $totalCompleted ?></div>
                            <div class="label">Completed Research</div>
                            <div class="subtitle">Combined total</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%);"><i class="fa fa-check-circle"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 2; --card-color: #2563eb; --card-color-fade: rgba(37, 99, 235, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $totalPublished ?></div>
                            <div class="label">Published Outputs</div>
                            <div class="subtitle">Combined total</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);"><i class="fa fa-book"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 3; --card-color: #8b5cf6; --card-color-fade: rgba(139, 92, 246, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $totalRegistered ?></div>
                            <div class="label">Total Researchers</div>
                            <div class="subtitle">Faculty + Students</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%);"><i class="fa fa-users"></i></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Faculty Statistics (Coordinators only) -->
        <?php if ($showFaculty && $userRole !== 'admin'): ?>
            <div class="section-title">
                <i class="fa fa-chalkboard-teacher"></i>
                Faculty Research Overview
                <?php if ($userRole === 'coordinator'): ?>
                    <span style="font-size: 14px; font-weight: normal; color: rgba(255,255,255,0.8);"> (Your Data)</span>
                <?php endif; ?>
            </div>
            <div class="stats-grid">
                <div class="stat-card" style="--delay: 0; --card-color: #064e1a; --card-color-fade: rgba(6, 78, 26, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['faculty']['total'] ?></div>
                            <div class="label">Faculty Researchers</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);"><i class="fa fa-users"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 1; --card-color: #2563eb; --card-color-fade: rgba(37, 99, 235, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['faculty']['totalOutputs'] ?></div>
                            <div class="label">Research Projects</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);"><i class="fa fa-flask"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 2; --card-color: #f59e0b; --card-color-fade: rgba(245, 158, 11, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['faculty']['ongoing'] ?></div>
                            <div class="label">On-going</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);"><i class="fa fa-spinner fa-spin"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 3; --card-color: #10b981; --card-color-fade: rgba(16, 185, 129, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['faculty']['completed'] ?></div>
                            <div class="label">Completed</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%);"><i class="fa fa-check-circle"></i></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Student Statistics (Coordinators only) -->
        <?php if ($showStudent && $userRole !== 'admin'): ?>
            <div class="section-title">
                <i class="fa fa-user-graduate"></i>
                Student Research Overview
                <?php if ($userRole === 'coordinator'): ?>
                    <span style="font-size: 14px; font-weight: normal; color: rgba(255,255,255,0.8);"> (Your Data)</span>
                <?php endif; ?>
            </div>
            <div class="stats-grid">
                <div class="stat-card" style="--delay: 0; --card-color: #8b5cf6; --card-color-fade: rgba(139, 92, 246, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['student']['total'] ?></div>
                            <div class="label">Student Researchers</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%);"><i class="fa fa-users"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 1; --card-color: #2563eb; --card-color-fade: rgba(37, 99, 235, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['student']['totalOutputs'] ?></div>
                            <div class="label">Research Outputs</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);"><i class="fa fa-flask"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 2; --card-color: #f59e0b; --card-color-fade: rgba(245, 158, 11, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['student']['ongoing'] ?></div>
                            <div class="label">On-going</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);"><i class="fa fa-spinner fa-spin"></i></div>
                    </div>
                </div>
                <div class="stat-card" style="--delay: 3; --card-color: #10b981; --card-color-fade: rgba(16, 185, 129, 0.2);">
                    <div class="stat-card-header">
                        <div>
                            <div class="number"><?= $stats['student']['completed'] ?></div>
                            <div class="label">Completed</div>
                        </div>
                        <div class="icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%);"><i class="fa fa-check-circle"></i></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Charts Section -->
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-chart-bar"></i>
            Analytics & Insights
        </div>
        
        <div class="charts-grid">
            <!-- Faculty Research Outputs Status -->
            <?php if ($showFaculty && (array_sum($facultyOutputsStats) > 0)): ?>
            <div class="chart-card" style="--delay: 0;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-file-alt"></i>
                        Faculty Research Outputs Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyOutputsChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Student Research Outputs Status -->
            <?php if ($showStudent && (array_sum($studentOutputsStats) > 0)): ?>
            <div class="chart-card" style="--delay: 1;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-file-alt"></i>
                        Student Research Outputs Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentOutputsChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Funding Distribution -->
            <?php if ($showFaculty && $fundingTotal > 0): ?>
            <div class="chart-card" style="--delay: 2;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-money-bill-wave"></i>
                        Funding Distribution (₱<?= number_format($fundingTotal, 2) ?>)
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="fundingChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Research Category Distribution -->
            <?php if ($showFaculty && !empty($researchCategories)): ?>
            <div class="chart-card" style="--delay: 3;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-layer-group"></i>
                        Research Category Distribution
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- ENHANCED INTERACTIVE TREND CHART -->
            <?php if ($showFaculty || $showStudent): ?>
            <div class="chart-card full-width enhanced" style="--delay: 4;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-line-chart"></i>
                        Interactive Research Output Trends
                    </div>
                    <button class="chart-export-btn" onclick="exportTrendChart()">
                        <i class="fa fa-download"></i> Export
                    </button>
                </div>
                
                <!-- Time Range Filters -->
                <div class="time-range-filters">
                    <button class="time-filter-btn" data-range="24hours">
                        <i class="fa fa-clock"></i> Last 24 Hours
                    </button>
                    <button class="time-filter-btn" data-range="7days">
                        <i class="fa fa-calendar-week"></i> Last 7 Days
                    </button>
                    <button class="time-filter-btn active" data-range="30days">
                        <i class="fa fa-calendar-alt"></i> Last 30 Days
                    </button>
                </div>
                
                <!-- Statistics Summary -->
                <div class="trend-statistics">
                    <!-- Statistics will be dynamically populated -->
                </div>
                
                <!-- Loading Indicator -->
                <div class="chart-loading">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Loading data...</div>
                </div>
                
                <!-- Chart Container -->
                <div class="chart-container" style="height: 450px;">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Overall Status -->
            <?php if ($userRole === 'admin'): ?>
            <div class="chart-card" style="--delay: 5;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Overall Status Distribution
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="overallStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Faculty Status -->
            <?php if ($showFaculty): ?>
            <div class="chart-card" style="--delay: 6;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Faculty Research Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Student Status -->
            <?php if ($showStudent): ?>
            <div class="chart-card" style="--delay: 7;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Student Research Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Faculty by Department -->
            <?php if ($showFaculty && !empty($facultyByDept)): ?>
            <div class="chart-card" style="--delay: 8;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-building"></i>
                        Faculty by Department
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyDeptChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Students by Department -->
            <?php if ($showStudent && !empty($studentByDept)): ?>
            <div class="chart-card" style="--delay: 9;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-building"></i>
                        Students by Department
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentDeptChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Recent Researchers -->
        <?php if (!empty($recentResearchers)): ?>
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-clock"></i>
            Recently Added Researchers
        </div>
        <div class="activity-card">
            <div class="activity-list">
                <?php foreach ($recentResearchers as $researcher): ?>
                    <div class="activity-item">
                        <div class="activity-icon <?= $researcher['type'] ?>">
                            <i class="fa fa-<?= $researcher['type'] === 'faculty' ? 'chalkboard-teacher' : 'user-graduate' ?>"></i>
                        </div>
                        <div class="activity-details">
                            <div class="activity-name">
                                <?= htmlspecialchars($researcher['name']) ?>
                            </div>
                            <div class="activity-meta">
                                <i class="fa fa-building"></i>
                                <?= htmlspecialchars($researcher['department']) ?>
                                <span>•</span>
                                <i class="fa fa-clock"></i>
                                <?= date('M d, Y', strtotime($researcher['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="researchScript.js"></script>

</body>
</html>
