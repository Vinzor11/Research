/**
 * Faculty Researcher List Script - COMPLETE VERSION
 * Handles table interactions, HR System sync, and delete confirmation
 * All functions are globally accessible for onclick handlers
 */

console.log('✅ Faculty Researcher Script Loading...');

// ========================================
// DELETE CONFIRMATION FUNCTION (GLOBAL)
// ========================================

/**
 * Confirm delete with detailed warning
 * Shows exactly what will be deleted
 * MUST be global for onclick handlers
 */
window.confirmDelete = function(facultyId, facultyName) {
    const message = `⚠️ WARNING: This will permanently delete:

• Faculty: ${facultyName}
• All their research projects
• All research outputs
• All project team records
• All project costs
• All education records

This action CANNOT be undone!

Are you sure you want to proceed?`;

    if (confirm(message)) {
        console.log('🗑️ Deleting faculty ID:', facultyId);
        window.location.href = `facultyresearcher.php?delete=${facultyId}`;
    } else {
        console.log('❌ Delete cancelled by user');
    }
};

// ========================================
// HR SYSTEM SYNC FUNCTIONS (GLOBAL)
// ========================================

/**
 * Sync single faculty with HR System
 * MUST be global for onclick handlers
 */
window.syncFaculty = async function(facultyId) {
    if (!confirm('Sync this faculty data with HR System?\n\nThis will update their information with the latest data from HR.')) {
        console.log('❌ Sync cancelled by user');
        return;
    }
    
    const btn = event.target.closest('.btn-sync');
    if (!btn) {
        console.error('❌ Sync button not found');
        return;
    }
    
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'sync');
        formData.append('faculty_id', facultyId);
        
        console.log('🔄 Syncing faculty ID:', facultyId);
        
        const response = await fetch('fetch_employee.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('📊 Sync response:', data);
        
        if (data.success) {
            console.log('✅ Sync successful');
            showNotification('success', 'Faculty data synced successfully!');
            
            // Update UI immediately if possible
            if (data.updated_at) {
                updateSyncStatus(facultyId, data.updated_at);
            }
            
            // Reload page to show all updated data
            setTimeout(() => location.reload(), 1000);
        } else {
            throw new Error(data.error || 'Failed to sync faculty data');
        }
    } catch (error) {
        console.error('❌ Sync error:', error);
        showNotification('error', 'Failed to sync: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    }
};

/**
 * Bulk sync all faculty with HR System (optional - for future use)
 * MUST be global for onclick handlers
 */
window.bulkSyncFaculty = async function() {
    if (!confirm('Sync ALL faculty data with HR System?\n\nThis may take a while depending on how many faculty are synced.')) {
        return;
    }
    
    showNotification('info', 'Bulk sync feature coming soon!');
    console.log('ℹ️ Bulk sync requested but not yet implemented');
    
    // TODO: Implement bulk sync functionality
    // This would need to:
    // 1. Get all faculty with hr_employee_id
    // 2. Loop through and sync each one (with delay for rate limiting)
    // 3. Show progress indicator
    // 4. Handle rate limiting (60 requests per minute max)
};

// ========================================
// UI HELPER FUNCTIONS
// ========================================

/**
 * Show notification message
 * Types: success, error, warning, info
 */
function showNotification(type, message) {
    console.log(`📢 Notification [${type}]:`, message);
    
    // Remove existing notifications
    const existingNotif = document.querySelector('.notification-toast');
    if (existingNotif) {
        existingNotif.remove();
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification-toast notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fa ${icons[type] || icons.info}"></i>
        <span>${escapeHtml(message)}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Trigger animation
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

/**
 * Format timestamp to readable format
 */
function formatTimestamp(timestamp) {
    if (!timestamp) return 'Never';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (seconds < 60) return 'Just now';
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    if (days < 7) return `${days} day${days > 1 ? 's' : ''} ago`;
    
    return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric' 
    });
}

/**
 * Update sync status indicator in table row
 */
function updateSyncStatus(facultyId, timestamp) {
    // Find the row for this faculty
    const rows = document.querySelectorAll('tbody tr');
    let targetRow = null;
    
    rows.forEach(row => {
        const firstCell = row.querySelector('td');
        if (firstCell && firstCell.textContent.trim() == facultyId) {
            targetRow = row;
        }
    });
    
    if (!targetRow) {
        console.log('⚠️ Row not found for faculty ID:', facultyId);
        return;
    }
    
    // Update "Last Synced" timestamp
    const syncCell = targetRow.querySelector('.sync-timestamp');
    if (syncCell) {
        syncCell.textContent = formatTimestamp(timestamp);
        console.log('✅ Updated sync timestamp for faculty', facultyId);
    }
    
    // Update sync status indicator
    const statusCell = targetRow.querySelector('.sync-indicator');
    if (statusCell) {
        statusCell.className = 'sync-indicator sync-recent';
        statusCell.innerHTML = '🟢 Synced';
        console.log('✅ Updated sync status for faculty', facultyId);
    }
}

// ========================================
// INITIALIZE ON PAGE LOAD
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM Ready, initializing...');
    
    // Add notification styles if not already present
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification-toast {
                position: fixed;
                top: 20px;
                right: 20px;
                min-width: 300px;
                max-width: 500px;
                padding: 16px 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
                display: flex;
                align-items: center;
                gap: 12px;
                font-size: 14px;
                font-weight: 500;
                z-index: 10000;
                transform: translateX(400px);
                opacity: 0;
                transition: all 0.3s ease;
            }
            
            .notification-toast.show {
                transform: translateX(0);
                opacity: 1;
            }
            
            .notification-toast i {
                font-size: 20px;
                flex-shrink: 0;
            }
            
            .notification-success {
                border-left: 4px solid #10b981;
                color: #065f46;
            }
            
            .notification-success i {
                color: #10b981;
            }
            
            .notification-error {
                border-left: 4px solid #ef4444;
                color: #991b1b;
            }
            
            .notification-error i {
                color: #ef4444;
            }
            
            .notification-warning {
                border-left: 4px solid #f59e0b;
                color: #92400e;
            }
            
            .notification-warning i {
                color: #f59e0b;
            }
            
            .notification-info {
                border-left: 4px solid #3b82f6;
                color: #1e40af;
            }
            
            .notification-info i {
                color: #3b82f6;
            }
        `;
        document.head.appendChild(style);
        console.log('✅ Notification styles injected');
    }
    
    console.log('✅ Faculty Researcher List - HR System Integration Active');
    console.log('✅ All event listeners and styles loaded');
    
    // Verify global functions are available
    console.log('✅ confirmDelete available:', typeof window.confirmDelete === 'function');
    console.log('✅ syncFaculty available:', typeof window.syncFaculty === 'function');
    
    // Count elements for debugging
    const deleteButtons = document.querySelectorAll('.btn-delete').length;
    const syncButtons = document.querySelectorAll('.btn-sync').length;
    console.log(`📊 Found ${deleteButtons} delete buttons and ${syncButtons} sync buttons`);
});

// ========================================
// DEBUG HELPER (for development)
// ========================================

/**
 * Debug function to check script status
 * Run in console: debugFacultyList()
 */
window.debugFacultyList = function() {
    console.log('=== FACULTY LIST DEBUG INFO ===');
    console.log('Total faculty rows:', document.querySelectorAll('tbody tr').length);
    console.log('Sync buttons:', document.querySelectorAll('.btn-sync').length);
    console.log('Delete buttons:', document.querySelectorAll('.btn-delete').length);
    console.log('View buttons:', document.querySelectorAll('.btn-view').length);
    console.log('Notification styles loaded:', !!document.getElementById('notification-styles'));
    console.log('confirmDelete function:', typeof window.confirmDelete);
    console.log('syncFaculty function:', typeof window.syncFaculty);
    console.log('bulkSyncFaculty function:', typeof window.bulkSyncFaculty);
    console.log('================================');
};

console.log('✅ Faculty Researcher Script Initialized Successfully');
console.log('💡 Type debugFacultyList() in console for debug info');