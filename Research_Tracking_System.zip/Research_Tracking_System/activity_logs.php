<?php
/**
 * activity_logs.php
 * Enhanced Activity Logs Management System with Strict Access Control
 * Coordinators can only view their own activities and domain-specific logs
 * Admin has full system access
 */

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';
require 'ActivityLogger.php';

$logger = new ActivityLogger($conn, $_SESSION['user_id']);
$logger->logView('activity_logs', null, 'Accessed activity logs page');

// Get user role and coordinator type
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$currentUserId = $_SESSION['user_id'];

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 50;
$offset = ($page - 1) * $per_page;

// Filters
$action_filter = isset($_GET['action']) && $_GET['action'] !== '' ? $_GET['action'] : null;
$user_filter = isset($_GET['user']) && $_GET['user'] !== '' ? $_GET['user'] : null;
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// ENHANCED: Strict access control - Prevent coordinators from viewing other coordinators' logs
if ($userRole === 'coordinator') {
    // Force coordinators to only see their own user activities
    $user_filter = $currentUserId;
}

// Build query with enhanced role-based restrictions
$where_clauses = [];
$params = [];
$types = "";

// ENHANCED: Strict Role-based filtering
if ($userRole === 'coordinator' && $coordinatorType === 'student') {
    // Student coordinators: Only their OWN activities + student-related domain activities
    $where_clauses[] = "((al.user_id = ? AND al.table_affected IS NULL) OR 
                         (al.user_id = ? AND al.table_affected IN ('student_researchers', 'research_outputs', 'student_research_team', 'student_research_costs', 'student_research_outputs')))";
    $params[] = $currentUserId;
    $params[] = $currentUserId;
    $types .= "ii";
} elseif ($userRole === 'coordinator' && $coordinatorType === 'faculty') {
    // Faculty coordinators: Only their OWN activities + faculty-related domain activities
    $where_clauses[] = "((al.user_id = ? AND al.table_affected IS NULL) OR 
                         (al.user_id = ? AND al.table_affected IN ('faculty_researchers', 'faculty_projects', 'faculty_education', 'faculty_project_team', 'faculty_project_costs', 'faculty_research_outputs')))";
    $params[] = $currentUserId;
    $params[] = $currentUserId;
    $types .= "ii";
}
// Admin sees everything - no additional filter needed

if ($action_filter) {
    $where_clauses[] = "al.action_type = ?";
    $params[] = $action_filter;
    $types .= "s";
}

// ENHANCED: For coordinators, user_filter is already forced to their own ID
if ($user_filter && $userRole === 'admin') {
    $where_clauses[] = "al.user_id = ?";
    $params[] = $user_filter;
    $types .= "i";
} elseif ($user_filter && $userRole === 'coordinator') {
    // Already filtered above - this ensures coordinators can't bypass
    $where_clauses[] = "al.user_id = ?";
    $params[] = $currentUserId;
    $types .= "i";
}

if ($search) {
    $where_clauses[] = "(al.description LIKE ? OR al.table_affected LIKE ? OR u.username LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

if ($date_from) {
    $where_clauses[] = "DATE(al.created_at) >= ?";
    $params[] = $date_from;
    $types .= "s";
}

if ($date_to) {
    $where_clauses[] = "DATE(al.created_at) <= ?";
    $params[] = $date_to;
    $types .= "s";
}

$where_sql = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";

// Count total records
$count_query = "SELECT COUNT(*) as total FROM activity_logs al LEFT JOIN users u ON al.user_id = u.id $where_sql";
if (!empty($params)) {
    $stmt = $conn->prepare($count_query);
    if (!empty($types)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $total_records = $stmt->get_result()->fetch_assoc()['total'];
} else {
    $total_records = $conn->query($count_query)->fetch_assoc()['total'];
}

$total_pages = ceil($total_records / $per_page);

// Fetch activities
$query = "
    SELECT 
        al.id,
        al.user_id,
        u.username,
        u.user_role,
        u.coordinator_type,
        al.action_type,
        al.table_affected,
        al.record_id,
        al.description,
        al.ip_address,
        al.user_agent,
        al.created_at
    FROM activity_logs al
    LEFT JOIN users u ON al.user_id = u.id
    $where_sql
    ORDER BY al.created_at DESC
    LIMIT ? OFFSET ?
";

$types .= "ii";
$params[] = $per_page;
$params[] = $offset;

$stmt = $conn->prepare($query);
if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$activities = $result->fetch_all(MYSQLI_ASSOC);

// ENHANCED: Get users for filter dropdown with strict access control
if ($userRole === 'admin') {
    // Admin sees all users
    $users = $conn->query("SELECT id, username, user_role, coordinator_type FROM users ORDER BY username")->fetch_all(MYSQLI_ASSOC);
} else {
    // Coordinators ONLY see themselves - cannot view other users
    $stmt = $conn->prepare("SELECT id, username, user_role, coordinator_type FROM users WHERE id = ?");
    $stmt->bind_param("i", $currentUserId);
    $stmt->execute();
    $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ENHANCED: Get stats with strict role-based filtering
$stats_where = "";
$stats_params = [];

if ($userRole === 'coordinator' && $coordinatorType === 'student') {
    $stats_where = "WHERE ((user_id = ? AND table_affected IS NULL) OR 
                           (user_id = ? AND table_affected IN ('student_researchers', 'research_outputs', 'student_research_team', 'student_research_costs', 'student_research_outputs')))";
    $stats_params = [$currentUserId, $currentUserId];
} elseif ($userRole === 'coordinator' && $coordinatorType === 'faculty') {
    $stats_where = "WHERE ((user_id = ? AND table_affected IS NULL) OR 
                           (user_id = ? AND table_affected IN ('faculty_researchers', 'faculty_projects', 'faculty_education', 'faculty_project_team', 'faculty_project_costs', 'faculty_research_outputs')))";
    $stats_params = [$currentUserId, $currentUserId];
}

if (!empty($stats_params)) {
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM activity_logs $stats_where");
    $stmt->bind_param("ii", $stats_params[0], $stats_params[1]);
    $stmt->execute();
    $total_stat = $stmt->get_result()->fetch_assoc()['c'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM activity_logs $stats_where AND DATE(created_at) = CURDATE()");
    $stmt->bind_param("ii", $stats_params[0], $stats_params[1]);
    $stmt->execute();
    $today_stat = $stmt->get_result()->fetch_assoc()['c'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM activity_logs $stats_where AND YEARWEEK(created_at) = YEARWEEK(NOW())");
    $stmt->bind_param("ii", $stats_params[0], $stats_params[1]);
    $stmt->execute();
    $week_stat = $stmt->get_result()->fetch_assoc()['c'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM activity_logs $stats_where AND YEAR(created_at) = YEAR(NOW()) AND MONTH(created_at) = MONTH(NOW())");
    $stmt->bind_param("ii", $stats_params[0], $stats_params[1]);
    $stmt->execute();
    $month_stat = $stmt->get_result()->fetch_assoc()['c'];
    
    $stats = [
        'total' => $total_stat,
        'today' => $today_stat,
        'this_week' => $week_stat,
        'this_month' => $month_stat
    ];
} else {
    // Admin stats - all activities
    $stats = [
        'total' => $conn->query("SELECT COUNT(*) as c FROM activity_logs")->fetch_assoc()['c'],
        'today' => $conn->query("SELECT COUNT(*) as c FROM activity_logs WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['c'],
        'this_week' => $conn->query("SELECT COUNT(*) as c FROM activity_logs WHERE YEARWEEK(created_at) = YEARWEEK(NOW())")->fetch_assoc()['c'],
        'this_month' => $conn->query("SELECT COUNT(*) as c FROM activity_logs WHERE YEAR(created_at) = YEAR(NOW()) AND MONTH(created_at) = MONTH(NOW())")->fetch_assoc()['c']
    ];
}

// Action type colors and icons
function getActionDetails($action) {
    $details = [
        'create' => ['color' => '#10b981', 'icon' => 'fa-plus-circle', 'label' => 'Create'],
        'update' => ['color' => '#3b82f6', 'icon' => 'fa-edit', 'label' => 'Update'],
        'delete' => ['color' => '#ef4444', 'icon' => 'fa-trash', 'label' => 'Delete'],
        'view' => ['color' => '#6b7280', 'icon' => 'fa-eye', 'label' => 'View'],
        'export' => ['color' => '#f59e0b', 'icon' => 'fa-download', 'label' => 'Export'],
        'login' => ['color' => '#10b981', 'icon' => 'fa-sign-in-alt', 'label' => 'Login'],
        'logout' => ['color' => '#6b7280', 'icon' => 'fa-sign-out-alt', 'label' => 'Logout']
    ];
    return $details[$action] ?? ['color' => '#6b7280', 'icon' => 'fa-circle', 'label' => ucfirst($action)];
}

function getTableLabel($table) {
    $labels = [
        'student_researchers' => 'Student Researchers',
        'research_outputs' => 'Research Outputs',
        'student_research_team' => 'Student Team',
        'student_research_costs' => 'Student Research Costs',
        'student_research_outputs' => 'Student Research Files',
        'faculty_researchers' => 'Faculty Researchers',
        'faculty_projects' => 'Faculty Projects',
        'faculty_education' => 'Faculty Education',
        'faculty_project_team' => 'Faculty Team',
        'faculty_project_costs' => 'Project Costs',
        'faculty_research_outputs' => 'Faculty Research Files',
        'users' => 'Users',
        'activity_logs' => 'Activity Logs'
    ];
    return $labels[$table] ?? ucfirst(str_replace('_', ' ', $table ?? ''));
}

// ENHANCED: Get domain-specific activity breakdown for coordinators
$domain_stats = [];
if ($userRole === 'coordinator') {
    $domain_tables = [];
    if ($coordinatorType === 'student') {
        $domain_tables = ['student_researchers', 'research_outputs', 'student_research_team', 'student_research_costs', 'student_research_outputs'];
    } elseif ($coordinatorType === 'faculty') {
        $domain_tables = ['faculty_researchers', 'faculty_projects', 'faculty_education', 'faculty_project_team', 'faculty_project_costs', 'faculty_research_outputs'];
    }
    
    foreach ($domain_tables as $table) {
        $stmt = $conn->prepare("SELECT COUNT(*) as c FROM activity_logs WHERE user_id = ? AND table_affected = ?");
        $stmt->bind_param("is", $currentUserId, $table);
        $stmt->execute();
        $count = $stmt->get_result()->fetch_assoc()['c'];
        $domain_stats[$table] = $count;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs - Research Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #064e1a;
            --primary-dark: #043310;
            --primary-light: #0b6a24;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            display: flex;
            height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, var(--gray-50) 0%, #e0e7ff 100%);
            overflow: hidden;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-lg);
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 200px;
            background: radial-gradient(circle at 30% 20%, rgba(255,255,255,0.1) 0%, transparent 60%);
            pointer-events: none;
        }

        .sidebar-header {
            text-align: center;
            padding: 35px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            background: white;
            padding: 10px;
            margin-bottom: 15px;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));
        }

        .sidebar-header h3 {
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 0.3px;
            opacity: 0.95;
        }

        .sidebar-nav {
            flex: 1;
            padding: 25px 0;
            overflow-y: auto;
        }

        .sidebar a {
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 25px;
            margin: 4px 18px;
            border-radius: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-size: 15px;
            font-weight: 500;
            position: relative;
        }

        .sidebar a::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: white;
            transform: scaleY(0);
            transition: transform 0.3s ease;
        }

        .sidebar a i {
            width: 22px;
            text-align: center;
            font-size: 16px;
        }

        .sidebar a:hover {
            background: rgba(255,255,255,0.15);
            color: white;
            transform: translateX(5px);
        }

        .sidebar a:hover::before {
            transform: scaleY(1);
        }

        .sidebar a.active {
            background: rgba(255,255,255,0.2);
            color: white;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .sidebar a.active::before {
            transform: scaleY(1);
        }

        /* Main Content */
        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .header {
            background: white;
            padding: 25px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--gray-200);
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-title-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: var(--shadow);
        }

        .header-title-text h1 {
            font-size: 26px;
            font-weight: 700;
            color: var(--gray-800);
            letter-spacing: -0.5px;
        }

        .header-title-text p {
            font-size: 14px;
            color: var(--gray-500);
            margin-top: 2px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px;
            background: var(--gray-50);
            border-radius: 50px;
            border: 2px solid var(--gray-200);
        }

        .user-avatar {
            width: 38px;
            height: 38px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 16px;
            font-weight: 600;
        }

        .role-badge {
            padding: 6px 14px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .content {
            flex: 1;
            overflow-y: auto;
            padding: 35px 40px;
        }

        /* Access Control Notice */
        .access-notice {
            background: linear-gradient(135deg, var(--info) 0%, #60a5fa 100%);
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: var(--shadow);
        }

        .access-notice i {
            font-size: 20px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            opacity: 0.05;
            border-radius: 50%;
            transform: translate(30%, -30%);
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .stat-info .label {
            font-size: 13px;
            color: var(--gray-500);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .stat-info .number {
            font-size: 32px;
            font-weight: 800;
            color: var(--gray-800);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
            box-shadow: var(--shadow);
        }

        /* Domain Stats (for coordinators) */
        .domain-stats {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 25px;
            border: 1px solid var(--gray-200);
        }

        .domain-stats-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .domain-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .domain-stat-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            background: var(--gray-50);
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }

        .domain-stat-item .label {
            font-size: 13px;
            color: var(--gray-700);
            font-weight: 600;
        }

        .domain-stat-item .count {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary);
        }

        /* Filters */
        .filters-card {
            background: white;
            border-radius: 16px;
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 25px;
            border: 1px solid var(--gray-200);
        }

        .filters-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filters-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .filter-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 8px;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid var(--gray-200);
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: white;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: var(--primary);
        }

        .filter-group select:disabled,
        .filter-group input:disabled {
            background: var(--gray-100);
            cursor: not-allowed;
        }

        .filter-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            box-shadow: var(--shadow);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--gray-700);
        }

        .btn-secondary:hover {
            background: var(--gray-300);
        }

        /* Table */
        .table-card {
            background: white;
            border-radius: 16px;
            box-shadow: var(--shadow);
            overflow: hidden;
            border: 1px solid var(--gray-200);
        }

        .table-header {
            padding: 20px 25px;
            border-bottom: 2px solid var(--gray-100);
        }

        .table-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table-container {
            overflow-x: auto;
            max-height: 600px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1200px;
        }

        thead {
            background: var(--gray-50);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        th {
            padding: 16px 20px;
            text-align: left;
            font-weight: 700;
            color: var(--gray-700);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid var(--gray-200);
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
            font-size: 14px;
        }

        tbody tr {
            transition: all 0.2s ease;
        }

        tbody tr:hover {
            background: var(--gray-50);
        }

        .action-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .user-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .user-badge-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: 600;
        }

        .table-label {
            padding: 4px 10px;
            background: var(--gray-100);
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            color: var(--gray-700);
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-top: 25px;
            padding: 20px;
        }

        .pagination a,
        .pagination span {
            padding: 8px 14px;
            background: white;
            border: 2px solid var(--gray-200);
            color: var(--gray-700);
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .pagination a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateY(-2px);
        }

        .pagination .active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--gray-500);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--gray-100);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--gray-300);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--gray-500);
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="ESSU Logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <?php if ($userRole === 'admin' || $coordinatorType === 'faculty'): ?>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php endif; ?>
        <?php if ($userRole === 'admin' || $coordinatorType === 'student'): ?>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <?php endif; ?>
        <?php if ($userRole === 'admin'): ?>
            <a href="users.php"><i class="fa fa-users-cog"></i> User Management</a>
            <?php if (file_exists('oauth_settings.php')): ?>
                <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <?php endif; ?>
        <?php endif; ?>
        <a href="activity_logs.php" class="active"><i class="fa fa-history"></i> Activity Logs</a>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
    <div class="header">
        <div class="header-title">
            <div class="header-title-icon">
                <i class="fa-solid fa-history"></i>
            </div>
            <div class="header-title-text">
                <h1>Activity Logs</h1>
                <p>
                    <?php 
                    if ($userRole === 'admin') {
                        echo 'System-wide activity monitoring';
                    } elseif ($coordinatorType === 'faculty') {
                        echo 'Your faculty-related activities';
                    } else {
                        echo 'Your student-related activities';
                    }
                    ?>
                </p>
            </div>
        </div>
        <div class="user-info">
            <div class="user-avatar">
                <?= strtoupper(substr($_SESSION['username'] ?? 'A', 0, 1)) ?>
            </div>
            <span><strong><?= htmlspecialchars($_SESSION['username'] ?? 'User') ?></strong></span>
            <span class="role-badge">
                <?php 
                if ($userRole === 'admin') echo 'Admin';
                elseif ($coordinatorType === 'faculty') echo 'Faculty Coordinator';
                elseif ($coordinatorType === 'student') echo 'Student Coordinator';
                ?>
            </span>
        </div>
    </div>

    <div class="content">
        <!-- Access Control Notice for Coordinators -->
        <?php if ($userRole === 'coordinator'): ?>
        <div class="access-notice">
            <i class="fa fa-shield-alt"></i>
            <div>
                <strong>Access Restricted:</strong> You can only view your own activities and <?= $coordinatorType === 'student' ? 'student' : 'faculty' ?>-related records. 
                Other users' activities are not accessible for privacy and security reasons.
            </div>
        </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="label"><?= $userRole === 'admin' ? 'Total Activities' : 'Your Activities' ?></div>
                        <div class="number"><?= number_format($stats['total']) ?></div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);">
                        <i class="fa fa-list"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="label">Today</div>
                        <div class="number"><?= number_format($stats['today']) ?></div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--success) 0%, #34d399 100%);">
                        <i class="fa fa-calendar-day"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="label">This Week</div>
                        <div class="number"><?= number_format($stats['this_week']) ?></div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--info) 0%, #60a5fa 100%);">
                        <i class="fa fa-calendar-week"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="label">This Month</div>
                        <div class="number"><?= number_format($stats['this_month']) ?></div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning) 0%, #fbbf24 100%);">
                        <i class="fa fa-calendar-alt"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Domain-Specific Stats for Coordinators -->
        <?php if ($userRole === 'coordinator' && !empty($domain_stats)): ?>
        <div class="domain-stats">
            <div class="domain-stats-title">
                <i class="fa fa-chart-bar"></i>
                Activity Breakdown by Module
            </div>
            <div class="domain-stats-grid">
                <?php foreach ($domain_stats as $table => $count): ?>
                    <?php if ($count > 0): ?>
                    <div class="domain-stat-item">
                        <span class="label"><?= getTableLabel($table) ?></span>
                        <span class="count"><?= number_format($count) ?></span>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="filters-card">
            <div class="filters-title">
                <i class="fa fa-filter"></i>
                Filter Activity Logs
            </div>
            <form method="GET">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="q" placeholder="Search description..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="filter-group">
                        <label>Action Type</label>
                        <select name="action">
                            <option value="">All Actions</option>
                            <option value="create" <?= $action_filter === 'create' ? 'selected' : '' ?>>Create</option>
                            <option value="update" <?= $action_filter === 'update' ? 'selected' : '' ?>>Update</option>
                            <option value="delete" <?= $action_filter === 'delete' ? 'selected' : '' ?>>Delete</option>
                            <option value="view" <?= $action_filter === 'view' ? 'selected' : '' ?>>View</option>
                            <option value="export" <?= $action_filter === 'export' ? 'selected' : '' ?>>Export</option>
                            <option value="login" <?= $action_filter === 'login' ? 'selected' : '' ?>>Login</option>
                            <option value="logout" <?= $action_filter === 'logout' ? 'selected' : '' ?>>Logout</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>User <?= $userRole === 'coordinator' ? '(You Only)' : '' ?></label>
                        <select name="user" <?= $userRole === 'coordinator' ? 'disabled' : '' ?>>
                            <option value="">All Users</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= ($user_filter == $u['id'] || ($userRole === 'coordinator' && $u['id'] == $currentUserId)) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($u['username']) ?>
                                    <?php if ($userRole === 'admin'): ?>
                                        <?= $u['user_role'] === 'admin' ? 'Admin' : ucfirst($u['coordinator_type'] ?? '') . ' Coord' ?>
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($userRole === 'coordinator'): ?>
                        <input type="hidden" name="user" value="<?= $currentUserId ?>">
                        <?php endif; ?>
                    </div>
                    <div class="filter-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>">
                    </div>
                    <div class="filter-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>">
                    </div>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-search"></i> Apply Filters
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='activity_logs.php'">
                        <i class="fa fa-times"></i> Clear Filters
                    </button>
                </div>
            </form>
        </div>

        <!-- Activity Table -->
        <div class="table-card">
            <div class="table-header">
                <div class="table-title">
                    <i class="fa fa-table"></i>
                    Activity Records
                    <span style="color: var(--gray-500); font-weight: 400; font-size: 14px; margin-left: 10px;">
                        (<?= number_format($total_records) ?> total)
                    </span>
                </div>
            </div>
            <div class="table-container">
                <?php if (empty($activities)): ?>
                    <div class="empty-state">
                        <i class="fa fa-inbox"></i>
                        <p>No activity logs found</p>
                        <?php if ($userRole === 'coordinator'): ?>
                        <p style="font-size: 14px; margin-top: 10px;">Start working with <?= $coordinatorType ?> records to see your activities here.</p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Date & Time</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>Module</th>
                                <th>Description</th>
                                <th>Record ID</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($activities as $activity): 
                                $actionDetails = getActionDetails($activity['action_type']);
                            ?>
                            <tr>
                                <td style="white-space: nowrap;">
                                    <strong><?= date('M d, Y', strtotime($activity['created_at'])) ?></strong><br>
                                    <span style="color: var(--gray-500); font-size: 12px;">
                                        <?= date('h:i A', strtotime($activity['created_at'])) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="user-badge">
                                        <div class="user-badge-avatar">
                                            <?= strtoupper(substr($activity['username'] ?? 'U', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <strong><?= htmlspecialchars($activity['username'] ?? 'Unknown') ?></strong>
                                            <?php if ($activity['user_id'] == $currentUserId): ?>
                                                <span style="color: var(--success); font-size: 11px; margin-left: 4px;">(You)</span>
                                            <?php endif; ?>
                                            <br>
                                            <span style="color: var(--gray-500); font-size: 11px;">
                                                <?php 
                                                if ($activity['user_role'] === 'admin') {
                                                    echo 'Admin';
                                                } elseif ($activity['coordinator_type']) {
                                                    echo ucfirst($activity['coordinator_type']) . ' Coord';
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="action-badge" style="background: <?= $actionDetails['color'] ?>;">
                                        <i class="fa <?= $actionDetails['icon'] ?>"></i>
                                        <?= $actionDetails['label'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($activity['table_affected']): ?>
                                        <span class="table-label">
                                            <?= getTableLabel($activity['table_affected']) ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="max-width: 400px;">
                                    <?= htmlspecialchars($activity['description']) ?>
                                </td>
                                <td>
                                    <?php if ($activity['record_id']): ?>
                                        <code style="background: var(--gray-100); padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            #<?= $activity['record_id'] ?>
                                        </code>
                                    <?php else: ?>
                                        <span style="color: var(--gray-400);">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-family: monospace; font-size: 12px; color: var(--gray-500);">
                                    <?= htmlspecialchars($activity['ip_address'] ?? 'N/A') ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?><?= $action_filter ? '&action=' . urlencode($action_filter) : '' ?><?= $user_filter ? '&user=' . urlencode($user_filter) : '' ?><?= $search ? '&q=' . urlencode($search) : '' ?><?= $date_from ? '&date_from=' . urlencode($date_from) : '' ?><?= $date_to ? '&date_to=' . urlencode($date_to) : '' ?>">
                    <i class="fa fa-chevron-left"></i> Previous
                </a>
            <?php endif; ?>

            <?php 
            $start = max(1, $page - 2);
            $end = min($total_pages, $page + 2);
            
            if ($start > 1): ?>
                <a href="?page=1<?= $action_filter ? '&action=' . urlencode($action_filter) : '' ?><?= $user_filter ? '&user=' . urlencode($user_filter) : '' ?><?= $search ? '&q=' . urlencode($search) : '' ?><?= $date_from ? '&date_from=' . urlencode($date_from) : '' ?><?= $date_to ? '&date_to=' . urlencode($date_to) : '' ?>">1</a>
                <?php if ($start > 2): ?>
                    <span>...</span>
                <?php endif; ?>
            <?php endif; ?>

            <?php for ($i = $start; $i <= $end; $i++): ?>
                <a href="?page=<?= $i ?><?= $action_filter ? '&action=' . urlencode($action_filter) : '' ?><?= $user_filter ? '&user=' . urlencode($user_filter) : '' ?><?= $search ? '&q=' . urlencode($search) : '' ?><?= $date_from ? '&date_from=' . urlencode($date_from) : '' ?><?= $date_to ? '&date_to=' . urlencode($date_to) : '' ?>" 
                   class="<?= $i === $page ? 'active' : '' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($end < $total_pages): ?>
                <?php if ($end < $total_pages - 1): ?>
                    <span>...</span>
                <?php endif; ?>
                <a href="?page=<?= $total_pages ?><?= $action_filter ? '&action=' . urlencode($action_filter) : '' ?><?= $user_filter ? '&user=' . urlencode($user_filter) : '' ?><?= $search ? '&q=' . urlencode($search) : '' ?><?= $date_from ? '&date_from=' . urlencode($date_from) : '' ?><?= $date_to ? '&date_to=' . urlencode($date_to) : '' ?>"><?= $total_pages ?></a>
            <?php endif; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?= $page + 1 ?><?= $action_filter ? '&action=' . urlencode($action_filter) : '' ?><?= $user_filter ? '&user=' . urlencode($user_filter) : '' ?><?= $search ? '&q=' . urlencode($search) : '' ?><?= $date_from ? '&date_from=' . urlencode($date_from) : '' ?><?= $date_to ? '&date_to=' . urlencode($date_to) : '' ?>">
                    Next <i class="fa fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
