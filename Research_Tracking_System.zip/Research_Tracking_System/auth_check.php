<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

function require_role(array $roles = []) {
    if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], $roles, true)) {
        header("Location: index.php");
        exit;
    }
}

function require_coordinator_type($type) {
    if ($_SESSION['user_role'] !== 'coordinator' || $_SESSION['coordinator_type'] !== $type) {
        header("Location: index.php");
        exit;
    }
}

