<?php
/**
 * get_student_version_history.php
 * Retrieves all versions of a student research output for display in version history modal
 */
session_start();
require 'db.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "Unauthorized"]);
    exit;
}

$userRole = $_SESSION['user_role'] ?? null;
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

// Only allow admin or student coordinator
if (!($userRole === 'admin' || ($userRole === 'coordinator' && $coordinatorType === 'student'))) {
    echo json_encode(["success" => false, "error" => "Unauthorized access"]);
    exit;
}

header('Content-Type: application/json');

$output_id = isset($_GET['output_id']) ? (int)$_GET['output_id'] : 0;
$research_id = isset($_GET['research_id']) ? (int)$_GET['research_id'] : 0;

if (!$output_id || !$research_id) {
    echo json_encode(["success" => false, "error" => "Invalid parameters"]);
    exit;
}

try {
    // Get the parent output ID (the original upload)
    $parentCheck = $conn->query("
        SELECT parent_output_id 
        FROM student_research_outputs 
        WHERE id = $output_id
    ")->fetch_assoc();
    
    $parent_id = $parentCheck['parent_output_id'] ?? $output_id;
    
    // If this output is itself a parent (not a revision), use its ID
    if (!$parent_id) {
        $parent_id = $output_id;
    }
    
    // Fetch all versions: the original and all its revisions
    $query = "
        SELECT 
            sro.id,
            sro.output_title,
            sro.output_type,
            sro.file_name,
            sro.file_path,
            sro.file_size,
            sro.output_status,
            sro.version,
            sro.is_latest_version,
            sro.upload_date,
            sro.review_date,
            sro.review_comments,
            CONCAT(sr.first_name, ' ', sr.last_name) as uploader_name,
            u.username as reviewer_name
        FROM student_research_outputs sro
        LEFT JOIN student_researchers sr ON sro.uploaded_by = sr.id
        LEFT JOIN users u ON sro.reviewer_id = u.id
        WHERE (sro.id = $parent_id OR sro.parent_output_id = $parent_id)
        AND sro.research_id = $research_id
        ORDER BY sro.version DESC
    ";
    
    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $versions = [];
    while ($row = $result->fetch_assoc()) {
        $versions[] = $row;
    }
    
    echo json_encode([
        "success" => true,
        "versions" => $versions,
        "total_versions" => count($versions)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
?>
