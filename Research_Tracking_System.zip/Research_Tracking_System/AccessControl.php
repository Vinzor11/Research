<?php
/**
 * AccessControl.php
 * Centralized access control for faculty and student records
 * Prevents security issues from inconsistent access checking
 */

class AccessControl {
    private $conn;
    private $userId;
    private $userRole;
    private $coordinatorType;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->coordinatorType = $_SESSION['coordinator_type'] ?? null;
    }
    
    /**
     * Check if user can access faculty researcher
     */
    public function canAccessFaculty($facultyId) {
        if (!$this->userId) {
            return false;
        }
        
        // Admin can access all
        if ($this->userRole === 'admin') {
            return true;
        }
        
        // Faculty coordinator can only access their own records
        if ($this->userRole === 'coordinator' && $this->coordinatorType === 'faculty') {
            $stmt = $this->conn->prepare("
                SELECT created_by 
                FROM faculty_researchers 
                WHERE id = ?
            ");
            $stmt->bind_param("i", $facultyId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            return $result && $result['created_by'] == $this->userId;
        }
        
        // Student coordinators cannot access faculty
        return false;
    }
    
    /**
     * Check if user can access student researcher
     */
    public function canAccessStudent($studentId) {
        if (!$this->userId) {
            return false;
        }
        
        // Admin can access all
        if ($this->userRole === 'admin') {
            return true;
        }
        
        // Student coordinator can only access their own records
        if ($this->userRole === 'coordinator' && $this->coordinatorType === 'student') {
            $stmt = $this->conn->prepare("
                SELECT created_by 
                FROM student_researchers 
                WHERE id = ?
            ");
            $stmt->bind_param("i", $studentId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            return $result && $result['created_by'] == $this->userId;
        }
        
        // Faculty coordinators cannot access students
        return false;
    }
    
    /**
     * Check if user can access faculty project
     */
    public function canAccessFacultyProject($projectId) {
        if (!$this->userId) {
            return false;
        }
        
        // Get faculty_id from project
        $stmt = $this->conn->prepare("
            SELECT faculty_id 
            FROM faculty_projects 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        return $this->canAccessFaculty($result['faculty_id']);
    }
    
    /**
     * Check if user can access student research output
     */
    public function canAccessStudentResearch($researchId) {
        if (!$this->userId) {
            return false;
        }
        
        // Get student_id from research output
        $stmt = $this->conn->prepare("
            SELECT student_id 
            FROM research_outputs 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $researchId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        return $this->canAccessStudent($result['student_id']);
    }
    
    /**
     * Require faculty access or die
     */
    public function requireFacultyAccess($facultyId) {
        if (!$this->canAccessFaculty($facultyId)) {
            $this->denyAccess('You do not have permission to access this faculty researcher.');
        }
    }
    
    /**
     * Require student access or die
     */
    public function requireStudentAccess($studentId) {
        if (!$this->canAccessStudent($studentId)) {
            $this->denyAccess('You do not have permission to access this student researcher.');
        }
    }
    
    /**
     * Require faculty project access or die
     */
    public function requireFacultyProjectAccess($projectId) {
        if (!$this->canAccessFacultyProject($projectId)) {
            $this->denyAccess('You do not have permission to access this research project.');
        }
    }
    
    /**
     * Require student research access or die
     */
    public function requireStudentResearchAccess($researchId) {
        if (!$this->canAccessStudentResearch($researchId)) {
            $this->denyAccess('You do not have permission to access this research output.');
        }
    }
    
    /**
     * Check if user can manage faculty (import/create)
     */
    public function canManageFaculty() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->userRole === 'admin' || 
               ($this->userRole === 'coordinator' && $this->coordinatorType === 'faculty');
    }
    
    /**
     * Check if user can manage students (import/create)
     */
    public function canManageStudents() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->userRole === 'admin' || 
               ($this->userRole === 'coordinator' && $this->coordinatorType === 'student');
    }
    
    /**
     * Get SQL WHERE clause for faculty filtering
     */
    public function getFacultyWhereClause($tableAlias = 'fr') {
        if ($this->userRole === 'admin') {
            return '';
        }
        
        if ($this->userRole === 'coordinator' && $this->coordinatorType === 'faculty') {
            return " AND {$tableAlias}.created_by = " . intval($this->userId);
        }
        
        // No access - return impossible condition
        return " AND 1=0";
    }
    
    /**
     * Get SQL WHERE clause for student filtering
     */
    public function getStudentWhereClause($tableAlias = 'sr') {
        if ($this->userRole === 'admin') {
            return '';
        }
        
        if ($this->userRole === 'coordinator' && $this->coordinatorType === 'student') {
            return " AND {$tableAlias}.created_by = " . intval($this->userId);
        }
        
        // No access - return impossible condition
        return " AND 1=0";
    }
    
    /**
     * Display access denied page and exit
     */
    private function denyAccess($message = 'Access Denied') {
        http_response_code(403);
        
        // Check if this is an AJAX request
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => $message
            ]);
            exit;
        }
        
        // HTML response
        echo "<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Access Denied</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    background: linear-gradient(135deg, #f9fafb 0%, #e0e7ff 100%);
                    margin: 0; 
                    padding: 0; 
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                }
                .access-denied { 
                    max-width: 500px; 
                    background: white; 
                    padding: 40px; 
                    border-radius: 16px; 
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .access-denied i { 
                    font-size: 64px; 
                    margin-bottom: 20px; 
                    color: #ef4444;
                    display: block;
                }
                .access-denied h2 { 
                    color: #1f2937; 
                    margin-bottom: 15px;
                    font-size: 24px;
                }
                .access-denied p { 
                    color: #6b7280; 
                    margin-bottom: 30px;
                    line-height: 1.6;
                }
                .btn-back { 
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    padding: 12px 24px; 
                    background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);
                    color: white; 
                    text-decoration: none; 
                    border-radius: 8px;
                    transition: all 0.3s ease;
                    font-weight: 600;
                }
                .btn-back:hover { 
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(6, 78, 26, 0.3);
                }
            </style>
        </head>
        <body>
            <div class='access-denied'>
                <i class='fa fa-shield-alt'></i>
                <h2>Access Denied</h2>
                <p>" . htmlspecialchars($message) . "</p>
                <p style='font-size: 14px;'>You can only access records that you have created.</p>
                <a href='javascript:history.back()' class='btn-back'>
                    <i class='fa fa-arrow-left'></i> Go Back
                </a>
            </div>
        </body>
        </html>";
        exit;
    }
    
    /**
     * Get user information
     */
    public function getUserInfo() {
        return [
            'user_id' => $this->userId,
            'user_role' => $this->userRole,
            'coordinator_type' => $this->coordinatorType,
            'can_manage_faculty' => $this->canManageFaculty(),
            'can_manage_students' => $this->canManageStudents()
        ];
    }
}