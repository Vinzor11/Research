<?php
/**
 * TokenManager.php
 * Handles OAuth token storage, retrieval, and refresh
 * Solves the session persistence problem
 */

require_once 'config.php';

class TokenManager {
    private $conn;
    private $userId;
    
    public function __construct($dbConnection, $userId = null) {
        $this->conn = $dbConnection;
        $this->userId = $userId ?? $_SESSION['user_id'] ?? null;
        
        // Ensure token storage table exists
        $this->createTokenTableIfNotExists();
    }
    
    /**
     * Create token storage table if it doesn't exist
     */
    private function createTokenTableIfNotExists() {
        $sql = "CREATE TABLE IF NOT EXISTS oauth_tokens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            access_token TEXT NOT NULL,
            refresh_token TEXT,
            token_type VARCHAR(50) DEFAULT 'Bearer',
            expires_at DATETIME NOT NULL,
            scope TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_user_token (user_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        try {
            $this->conn->query($sql);
            debugLog("[TokenManager] Token table verified/created");
        } catch (Exception $e) {
            errorLog("[TokenManager] Failed to create token table: " . $e->getMessage());
        }
    }
    
    /**
     * Store token in database
     */
    public function storeToken($accessToken, $refreshToken = null, $expiresIn = null) {
        if (!$this->userId) {
            errorLog("[TokenManager] Cannot store token - no user ID");
            return false;
        }
        
        // Calculate expiry time
        $expiresIn = $expiresIn ?? TOKEN_DEFAULT_LIFETIME;
        $expiresAt = date('Y-m-d H:i:s', time() + $expiresIn);
        
        // Store or update token
        $stmt = $this->conn->prepare("
            INSERT INTO oauth_tokens (user_id, access_token, refresh_token, expires_at, scope)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                access_token = VALUES(access_token),
                refresh_token = VALUES(refresh_token),
                expires_at = VALUES(expires_at),
                scope = VALUES(scope),
                updated_at = CURRENT_TIMESTAMP
        ");
        
        $scope = OAUTH_SCOPES;
        $stmt->bind_param("issss", 
            $this->userId, 
            $accessToken, 
            $refreshToken, 
            $expiresAt,
            $scope
        );
        
        $result = $stmt->execute();
        
        if ($result) {
            debugLog("[TokenManager] Token stored successfully for user " . $this->userId);
            
            // Also store in session for immediate use
            $_SESSION['hr_access_token'] = $accessToken;
            $_SESSION['hr_token_expires_at'] = $expiresAt;
        } else {
            errorLog("[TokenManager] Failed to store token: " . $stmt->error);
        }
        
        $stmt->close();
        return $result;
    }
    
    /**
     * Get valid access token (refreshes if needed)
     */
    public function getValidToken() {
        if (!$this->userId) {
            errorLog("[TokenManager] Cannot get token - no user ID");
            return null;
        }
        
        // First check session for quick access
        if (isset($_SESSION['hr_access_token']) && 
            isset($_SESSION['hr_token_expires_at'])) {
            
            $expiresAt = strtotime($_SESSION['hr_token_expires_at']);
            
            // If token is still valid (with buffer), return it
            if (time() < ($expiresAt - TOKEN_EXPIRY_BUFFER)) {
                debugLog("[TokenManager] Returning token from session");
                return $_SESSION['hr_access_token'];
            }
        }
        
        // Get from database
        $stmt = $this->conn->prepare("
            SELECT access_token, refresh_token, expires_at 
            FROM oauth_tokens 
            WHERE user_id = ?
        ");
        
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            debugLog("[TokenManager] No token found in database for user " . $this->userId);
            return null;
        }
        
        $expiresAt = strtotime($result['expires_at']);
        
        // Check if token needs refresh
        if (time() >= ($expiresAt - TOKEN_EXPIRY_BUFFER)) {
            debugLog("[TokenManager] Token expired or expiring soon, attempting refresh");
            
            if (!empty($result['refresh_token'])) {
                return $this->refreshToken($result['refresh_token']);
            } else {
                errorLog("[TokenManager] Token expired and no refresh token available");
                return null;
            }
        }
        
        // Token is valid, store in session and return
        $_SESSION['hr_access_token'] = $result['access_token'];
        $_SESSION['hr_token_expires_at'] = $result['expires_at'];
        
        debugLog("[TokenManager] Returning valid token from database");
        return $result['access_token'];
    }
    
    /**
     * Refresh access token using refresh token
     */
    private function refreshToken($refreshToken) {
        debugLog("[TokenManager] Attempting to refresh token");
        
        $tokenData = [
            'grant_type' => 'refresh_token',
            'client_id' => OAUTH_CLIENT_ID,
            'client_secret' => OAUTH_CLIENT_SECRET,
            'refresh_token' => $refreshToken,
        ];
        
        $ch = curl_init(OAUTH_TOKEN_REFRESH_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            errorLog("[TokenManager] Token refresh failed - HTTP $httpCode", [
                'response' => substr($response, 0, 200)
            ]);
            return null;
        }
        
        $tokenResult = json_decode($response, true);
        
        if (!isset($tokenResult['access_token'])) {
            errorLog("[TokenManager] Token refresh response missing access_token");
            return null;
        }
        
        // Store new token
        $newRefreshToken = $tokenResult['refresh_token'] ?? $refreshToken;
        $expiresIn = $tokenResult['expires_in'] ?? TOKEN_DEFAULT_LIFETIME;
        
        $this->storeToken(
            $tokenResult['access_token'],
            $newRefreshToken,
            $expiresIn
        );
        
        debugLog("[TokenManager] Token refreshed successfully");
        return $tokenResult['access_token'];
    }
    
    /**
     * Delete token (on logout)
     */
    public function deleteToken() {
        if (!$this->userId) {
            return false;
        }
        
        $stmt = $this->conn->prepare("DELETE FROM oauth_tokens WHERE user_id = ?");
        $stmt->bind_param("i", $this->userId);
        $result = $stmt->execute();
        $stmt->close();
        
        // Clear from session
        unset($_SESSION['hr_access_token']);
        unset($_SESSION['hr_token_expires_at']);
        
        debugLog("[TokenManager] Token deleted for user " . $this->userId);
        return $result;
    }
    
    /**
     * Check if user has valid token
     */
    public function hasValidToken() {
        return $this->getValidToken() !== null;
    }
    
    /**
     * Get token expiry information
     */
    public function getTokenExpiry() {
        if (!$this->userId) {
            return null;
        }
        
        $stmt = $this->conn->prepare("
            SELECT expires_at 
            FROM oauth_tokens 
            WHERE user_id = ?
        ");
        
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return null;
        }
        
        $expiresAt = strtotime($result['expires_at']);
        $now = time();
        
        return [
            'expires_at' => $result['expires_at'],
            'expires_in_seconds' => max(0, $expiresAt - $now),
            'is_expired' => $expiresAt <= $now,
            'expires_soon' => $expiresAt <= ($now + TOKEN_EXPIRY_BUFFER)
        ];
    }
    
    /**
     * Clean up expired tokens (maintenance function)
     */
    public static function cleanupExpiredTokens($conn) {
        $sql = "DELETE FROM oauth_tokens WHERE expires_at < NOW()";
        $result = $conn->query($sql);
        
        if ($result) {
            $deletedCount = $conn->affected_rows;
            debugLog("[TokenManager] Cleaned up $deletedCount expired tokens");
            return $deletedCount;
        }
        
        return 0;
    }
}