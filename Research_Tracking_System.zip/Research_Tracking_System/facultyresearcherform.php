<?php
/**
 * Faculty Researcher Form - HR System Import - COMPLETE FIXED VERSION
 * Completely redesigned to fetch data from HR System
 */

session_start();
require 'db.php';
require 'config.php';

// Access control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin','coordinator'])) {
    header("Location: login.php");
    exit;
}

$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

if ($userRole === 'coordinator' && $coordinatorType !== 'faculty') {
    header("Location: research.php");
    exit;
}

// Check if HR Integration is available
if (!isHRIntegrationAvailable()) {
    die("HR System integration is not configured. Please contact administrator.");
}

// Check if we have access token
$token = getHRAccessToken();
if (!$token) {
    // Debug information
    error_log("=== HR TOKEN CHECK FAILED ===");
    error_log("Session ID: " . session_id());
    error_log("Session data: " . print_r($_SESSION, true));
    error_log("Token from session: " . ($token ? 'EXISTS' : 'NULL'));
    error_log("============================");
    
    die("
    <div style='font-family: Arial; max-width: 600px; margin: 100px auto; padding: 30px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
        <h2 style='color: #dc3545;'><i class='fa fa-exclamation-triangle'></i> HR System Access Token Not Available</h2>
        <p><strong>The HR System access token is not available in your session.</strong></p>
        <p>This usually happens because:</p>
        <ul>
            <li>You didn't login via SSO (Single Sign-On)</li>
            <li>Your session expired</li>
            <li>The access token wasn't stored during login</li>
        </ul>
        <h3>Solution:</h3>
        <ol>
            <li>Click the button below to logout</li>
            <li>Login again using <strong>\"Sign in with HR System (SSO)\"</strong></li>
            <li>After successful login, try importing faculty again</li>
        </ol>
        <a href='logout.php' style='display: inline-block; margin-top: 20px; padding: 12px 24px; background: #dc3545; color: white; text-decoration: none; border-radius: 5px;'>
            <i class='fa fa-sign-out-alt'></i> Logout and Login via SSO
        </a>
        <br><br>
        <small style='color: #666;'>
            <strong>Debug Info:</strong><br>
            Session Auth Method: " . ($_SESSION['auth_method'] ?? 'not set') . "<br>
            HR System URL: " . ($_SESSION['hr_system_url'] ?? 'not set') . "<br>
            Token Status: " . (isset($_SESSION['hr_access_token']) ? 'exists' : 'missing') . "
        </small>
    </div>
    ");
}

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get coordinator's unit and determine parent unit for auto-import
$coordinatorUnitId = null;
$parentUnitId = null;
$displayUnitName = 'your parent unit'; // Shown in UI; set when coordinator unit is loaded
$autoImportEmployees = [];
$importedEmployeeIds = [];
$debugInfo = [];

// For admins: fetch all employees and group by unit
$adminAllEmployees = [];
$adminUnitsList = []; // Array of units with their employees
if ($userRole === 'admin') {
    try {
        require 'hr_api_helper.php';
        $hrAPI = new HRSystemAPI($conn, $userId);
        
        // Fetch all active employees
        debugLog("Admin - Fetching all employees for unit grouping");
        $adminAllEmployees = $hrAPI->fetchAllEmployees('active');
        debugLog("Admin - Fetched " . count($adminAllEmployees) . " employees");
        
        // Group employees by college only (not programs)
        // For programs, group employees under their parent college
        $unitsMap = []; // key => college_name|college_id, value => array of employees
        foreach ($adminAllEmployees as $emp) {
            $empUnit = $emp['unit'] ?? null;
            if (!$empUnit) continue;
            
            $unitName = null;
            $unitId = null;
            $unitType = $empUnit['unit_type'] ?? null;
            $empUnitId = $empUnit['id'] ?? null;
            $empUnitName = $empUnit['name'] ?? null;
            
            // Determine college name and ID:
            // - If employee is in a program, use parent_unit (college)
            // - If employee is in a college, use the college directly
            // - If we can't determine parent, use the unit itself (more lenient)
            if ($unitType === 'program') {
                // Employee is in a program - get parent college
                if (!empty($empUnit['parent_unit']['name']) && !empty($empUnit['parent_unit']['id'])) {
                    $unitName = $empUnit['parent_unit']['name'];
                    $unitId = $empUnit['parent_unit']['id'];
                } elseif (!empty($empUnit['parent_unit_id'])) {
                    // Fallback: fetch parent unit from API
                    try {
                        $parentUnit = $hrAPI->getUnitById($empUnit['parent_unit_id']);
                        if ($parentUnit && !empty($parentUnit['name'])) {
                            $parentUnitType = $parentUnit['unit_type'] ?? null;
                            // Only use if it's a college, or if unit_type is null (assume college)
                            if ($parentUnitType === 'college' || $parentUnitType === null) {
                                $unitName = $parentUnit['name'];
                                $unitId = $parentUnit['id'] ?? $empUnit['parent_unit_id'];
                            } else {
                                // Parent is not a college, use the program itself as fallback
                                debugLog("Admin - Program parent is not a college, using program", [
                                    'program' => $empUnitName,
                                    'parent_type' => $parentUnitType,
                                    'parent_name' => $parentUnit['name'] ?? 'N/A'
                                ]);
                                $unitName = $empUnitName;
                                $unitId = $empUnitId;
                            }
                        } else {
                            // Can't fetch parent, use program itself
                            debugLog("Admin - Cannot fetch parent unit for program, using program", [
                                'program_id' => $empUnit['parent_unit_id'],
                                'program_name' => $empUnitName
                            ]);
                            $unitName = $empUnitName;
                            $unitId = $empUnitId;
                        }
                    } catch (Exception $e) {
                        // Can't fetch parent, use program itself
                        debugLog("Admin - Error fetching parent unit, using program: " . $e->getMessage(), [
                            'program_id' => $empUnit['parent_unit_id'],
                            'program_name' => $empUnitName
                        ]);
                        $unitName = $empUnitName;
                        $unitId = $empUnitId;
                    }
                } else {
                    // No parent unit info, use program itself
                    debugLog("Admin - Program has no parent unit info, using program", [
                        'program_id' => $empUnitId,
                        'program_name' => $empUnitName,
                        'unit_keys' => array_keys($empUnit)
                    ]);
                    $unitName = $empUnitName;
                    $unitId = $empUnitId;
                }
            } elseif ($unitType === 'college') {
                // Employee is directly in a college
                $unitName = $empUnitName;
                $unitId = $empUnitId;
            } else {
                // Unknown unit type - check if it has parent_unit to determine if it's a program
                if (!empty($empUnit['parent_unit']['name']) && !empty($empUnit['parent_unit']['id'])) {
                    // Has parent, treat as program and use parent
                    $unitName = $empUnit['parent_unit']['name'];
                    $unitId = $empUnit['parent_unit']['id'];
                } elseif (!empty($empUnit['parent_unit_id'])) {
                    // Has parent_unit_id but not parent_unit object, fetch from API
                    try {
                        $parentUnit = $hrAPI->getUnitById($empUnit['parent_unit_id']);
                        if ($parentUnit && !empty($parentUnit['name'])) {
                            $unitName = $parentUnit['name'];
                            $unitId = $parentUnit['id'] ?? $empUnit['parent_unit_id'];
                        } else {
                            // Can't determine parent, use unit itself
                            $unitName = $empUnitName;
                            $unitId = $empUnitId;
                        }
                    } catch (Exception $e) {
                        // Can't fetch parent, use unit itself
                        $unitName = $empUnitName;
                        $unitId = $empUnitId;
                    }
                } else {
                    // No parent info and unknown type, use unit itself
                    $unitName = $empUnitName;
                    $unitId = $empUnitId;
                }
            }
            
            if (empty($unitName) || empty($unitId)) continue;
            
            // Create unique key for the college
            $unitKey = $unitName . '|' . $unitId;
            
            if (!isset($unitsMap[$unitKey])) {
                $unitsMap[$unitKey] = [
                    'name' => $unitName,
                    'id' => $unitId,
                    'employees' => []
                ];
            }
            
            $unitsMap[$unitKey]['employees'][] = $emp;
        }
        
        debugLog("Admin - Grouping complete", [
            'total_employees' => count($adminAllEmployees),
            'units_found' => count($unitsMap)
        ]);
        
        // Convert to indexed array and sort by unit name
        $adminUnitsList = array_values($unitsMap);
        
        // Filter out "Research and Development Services Office" and similar variations
        $adminUnitsList = array_filter($adminUnitsList, function($unit) {
            $normalizedUnitName = strtolower(trim($unit['name']));
            $excludedUnits = [
                'research and development office',
                'research and development services office',
                'research office',
                'rdso'
            ];
            return !in_array($normalizedUnitName, $excludedUnits);
        });
        
        // Re-index array after filtering
        $adminUnitsList = array_values($adminUnitsList);
        
        // Sort by unit name
        usort($adminUnitsList, function($a, $b) {
            return strcmp($a['name'], $b['name']);
        });
        
        debugLog("Admin - Grouped into " . count($adminUnitsList) . " units (after filtering)");
        
    } catch (Exception $e) {
        errorLog("Admin - Error fetching employees: " . $e->getMessage());
        $debugInfo['admin_error'] = 'Error fetching employees: ' . $e->getMessage();
    }
}

// Get list of already imported employee IDs (exclude those with sync_status = 'n/a' so they can be re-imported)
try {
    $importedStmt = $conn->prepare("SELECT hr_employee_id FROM faculty_researchers WHERE hr_employee_id IS NOT NULL AND (sync_status IS NULL OR sync_status != 'n/a')");
    $importedStmt->execute();
    $importedResult = $importedStmt->get_result();
    while ($row = $importedResult->fetch_assoc()) {
        $importedEmployeeIds[] = normalizeEmployeeId($row['hr_employee_id']);
    }
    $importedStmt->close();
} catch (Exception $e) {
    errorLog("Error fetching imported employee IDs: " . $e->getMessage());
}

if ($userRole === 'coordinator' && $coordinatorType === 'faculty') {
    try {
        require 'hr_api_helper.php';
        $hrAPI = new HRSystemAPI($conn, $userId);
        
        // Get coordinator's employee ID from session
        // Get employee_id from database first (more reliable), fallback to session
        $coordinatorEmployeeId = null;
        $checkEmployeeIdColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'");
        $hasEmployeeIdColumn = $checkEmployeeIdColumn->num_rows > 0;
        
        if ($hasEmployeeIdColumn) {
            $stmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $coordinatorEmployeeId = $row['employee_id'];
            }
            $stmt->close();
        }
        
        // Fallback to session if not in database
        if (empty($coordinatorEmployeeId)) {
            $coordinatorEmployeeId = $_SESSION['hr_employee_id'] ?? null;
        }
        
        $debugInfo['employee_id_source'] = $hasEmployeeIdColumn && !empty($coordinatorEmployeeId) ? 'database' : 'session';
        $debugInfo['session_hr_employee_id'] = $_SESSION['hr_employee_id'] ?? 'not_set';
        $debugInfo['session_keys'] = array_keys($_SESSION);
        $debugInfo['session_unit_parent_id'] = $_SESSION['unit_parent_id'] ?? 'not_set';
        $debugInfo['session_unit_parent'] = $_SESSION['unit_parent'] ?? 'not_set';
        
        debugLog("Coordinator Auto-Import - Employee ID Check", [
            'hr_employee_id' => $coordinatorEmployeeId,
            'source' => $debugInfo['employee_id_source'],
            'user_id' => $userId,
            'user_role' => $userRole,
            'coordinator_type' => $coordinatorType
        ]);
        
        if (!$coordinatorEmployeeId) {
            $debugInfo['error'] = 'Employee ID not found. Please login via SSO to sync your employee information.';
            errorLog("Coordinator Auto-Import - Missing employee_id", [
                'user_id' => $userId,
                'has_employee_id_column' => $hasEmployeeIdColumn,
                'session_hr_employee_id' => $_SESSION['hr_employee_id'] ?? 'not_set'
            ]);
        } else {
            // Get coordinator's employee info from HR
            debugLog("Coordinator Auto-Import - Fetching employee info", ['employee_id' => $coordinatorEmployeeId]);
            
            try {
                $coordinatorInfo = null;
                try {
                    $coordinatorInfo = $hrAPI->getEmployeeById($coordinatorEmployeeId);
                } catch (Exception $apiException) {
                    $debugInfo['error'] = 'Error connecting to HR API: ' . $apiException->getMessage();
                    $debugInfo['error_details'] = 'Exception occurred while fetching employee info. This may indicate a network issue, authentication problem, or API endpoint error.';
                    errorLog("Coordinator Auto-Import - HR API Exception", [
                        'employee_id' => $coordinatorEmployeeId,
                        'error' => $apiException->getMessage(),
                        'trace' => $apiException->getTraceAsString()
                    ]);
                    
                    // Try to get more info about what went wrong
                    try {
                        $debugInfo['api_test'] = 'Attempting to verify API connection...';
                        $testEmployees = $hrAPI->fetchAllEmployees('active');
                        $debugInfo['api_test_result'] = count($testEmployees) > 0 ? 'API connection OK' : 'API connection failed';
                        $debugInfo['test_employees_count'] = count($testEmployees);
                    } catch (Exception $apiTestError) {
                        $debugInfo['api_test_result'] = 'API test failed: ' . $apiTestError->getMessage();
                        errorLog("Coordinator Auto-Import - API test exception", [
                            'error' => $apiTestError->getMessage()
                        ]);
                    }
                }
                
                if (!$coordinatorInfo || empty($coordinatorInfo['id'])) {
                    $debugInfo['error'] = 'Could not fetch coordinator info from HR API. The employee ID may not exist in the HR system or the API may be unavailable.';
                    $debugInfo['error_details'] = 'getEmployeeById returned null or empty. Check API logs for details.';
                    errorLog("Coordinator Auto-Import - Employee not found in HR", [
                        'employee_id' => $coordinatorEmployeeId,
                        'normalized_id' => function_exists('normalizeEmployeeId') ? normalizeEmployeeId($coordinatorEmployeeId) : $coordinatorEmployeeId,
                        'user_id' => $userId
                    ]);
                    
                    // Try to get more info about what went wrong
                    try {
                        $debugInfo['api_test'] = 'Attempting to verify API connection...';
                        $testEmployees = $hrAPI->fetchAllEmployees('active');
                        $debugInfo['api_test_result'] = count($testEmployees) > 0 ? 'API connection OK' : 'API connection failed';
                        $debugInfo['test_employees_count'] = count($testEmployees);
                    } catch (Exception $apiTestError) {
                        $debugInfo['api_test_result'] = 'API test failed: ' . $apiTestError->getMessage();
                        errorLog("Coordinator Auto-Import - API test exception", [
                            'error' => $apiTestError->getMessage(),
                            'trace' => $apiTestError->getTraceAsString()
                        ]);
                    }
                } elseif (!isset($coordinatorInfo['unit'])) {
                    $debugInfo['error'] = 'Coordinator info does not have unit information';
                    $debugInfo['coordinator_info_keys'] = array_keys($coordinatorInfo);
                    errorLog("Coordinator Auto-Import - No unit in employee info", [
                        'employee_id' => $coordinatorEmployeeId,
                        'keys' => array_keys($coordinatorInfo),
                        'coordinator_info' => $coordinatorInfo
                    ]);
                } else {
                $coordinatorUnit = $coordinatorInfo['unit'];
                $coordinatorUnitId = $coordinatorUnit['id'] ?? null;
                $unitType = $coordinatorUnit['unit_type'] ?? null;
                
                $debugInfo['unit_id'] = $coordinatorUnitId;
                $debugInfo['unit_name'] = $coordinatorUnit['name'] ?? 'N/A';
                $debugInfo['unit_type'] = $unitType;
                // Unit name to show in UI: for programs show parent (college), for colleges show unit name
                $displayUnitName = ($unitType === 'program' && !empty($coordinatorUnit['parent_unit']['name']))
                    ? $coordinatorUnit['parent_unit']['name']
                    : (($unitType === 'program' && !empty($_SESSION['unit_parent']))
                        ? $_SESSION['unit_parent']
                        : ($coordinatorUnit['name'] ?? 'N/A'));
                
                debugLog("Coordinator Unit Info", [
                    'unit_id' => $coordinatorUnitId,
                    'unit_name' => $coordinatorUnit['name'] ?? 'N/A',
                    'unit_type' => $unitType,
                    'unit_data' => $coordinatorUnit
                ]);
                
                // Try Research Office API first: GET /api/research/unit-employees (RESEARCH_OFFICE_API_GUIDE)
                // HR returns employees in coordinator's parent unit based on their SSO token
                $unitEmployeesFromAPI = $hrAPI->fetchAllUnitEmployees();
                if (!empty($unitEmployeesFromAPI)) {
                    $autoImportEmployees = $unitEmployeesFromAPI;
                    $debugInfo['employees_found'] = count($autoImportEmployees);
                    $debugInfo['source'] = 'research_unit_employees_api';
                    debugLog("Coordinator Auto-Import - Using Research Office API unit-employees", [
                        'count' => count($autoImportEmployees)
                    ]);
                } else {
                // Fallback: fetch all employees and filter by unit (when Research Office API not available)
                if ($unitType === 'program') {
                    // For programs: get parent unit ID from userinfo (stored in session) or from unit.parent_unit
                    // Priority: 1. Session unit_parent_id, 2. unit.parent_unit.id, 3. unit.parent_unit_id
                    $parentUnitId = null;
                    
                    // Check session first (from userinfo)
                    if (isset($_SESSION['unit_parent_id']) && !empty($_SESSION['unit_parent_id'])) {
                        $parentUnitId = $_SESSION['unit_parent_id'];
                        $debugInfo['parent_unit_id_source'] = 'from_session_userinfo';
                        debugLog("Coordinator Auto-Import - Using parent unit from session", ['parent_unit_id' => $parentUnitId]);
                    }
                    // Check unit.parent_unit (from userinfo designations)
                    elseif (isset($coordinatorUnit['parent_unit']['id'])) {
                        $parentUnitId = $coordinatorUnit['parent_unit']['id'];
                        $debugInfo['parent_unit_id_source'] = 'from_unit_parent_unit';
                        debugLog("Coordinator Auto-Import - Using parent unit from unit.parent_unit", ['parent_unit_id' => $parentUnitId]);
                    }
                    // Fallback to unit.parent_unit_id (if still in old format)
                    elseif (isset($coordinatorUnit['parent_unit_id'])) {
                        $parentUnitId = $coordinatorUnit['parent_unit_id'];
                        $debugInfo['parent_unit_id_source'] = 'from_unit_object';
                        debugLog("Coordinator Auto-Import - Using parent unit from unit.parent_unit_id", ['parent_unit_id' => $parentUnitId]);
                    }
                    
                    if (!$parentUnitId) {
                        $debugInfo['error'] = 'Parent unit ID not found. Check userinfo for unit_parent_id or unit.parent_unit.id';
                        errorLog("Coordinator Auto-Import - No parent_unit_id found", [
                            'unit_id' => $coordinatorUnitId,
                            'session_unit_parent_id' => $_SESSION['unit_parent_id'] ?? 'not_set',
                            'unit_parent_unit' => $coordinatorUnit['parent_unit'] ?? 'not_set'
                        ]);
                    }
                    
                    if ($parentUnitId) {
                        $debugInfo['parent_unit_id'] = $parentUnitId;
                        debugLog("Coordinator has program unit, parent_unit_id: $parentUnitId");
                        
                        // Fetch employees with the same parent unit (college)
                        // This includes: employees directly in the parent unit AND employees in other programs under the same parent
                        debugLog("Coordinator Auto-Import - Fetching employees by parent unit", ['parent_unit_id' => $parentUnitId]);
                        
                        // Fetch all employees and filter by parent unit
                        $allEmployees = $hrAPI->fetchAllEmployees('active');
                        $filteredEmployees = [];
                        
                        foreach ($allEmployees as $employee) {
                            $empUnit = $employee['unit'] ?? null;
                            if ($empUnit) {
                                $empUnitId = $empUnit['id'] ?? null;
                                $empUnitName = $empUnit['name'] ?? 'N/A';
                                $shouldInclude = false;
                                
                                // Normalize IDs for comparison (handle string/int mismatch)
                                $normalizedParentUnitId = (string)$parentUnitId;
                                $normalizedEmpUnitId = $empUnitId ? (string)$empUnitId : null;
                                
                                // Check 1: Employee's unit directly matches parent unit (college)
                                if ($normalizedEmpUnitId === $normalizedParentUnitId) {
                                    $shouldInclude = true;
                                    debugLog("✅ Employee matches parent unit directly", [
                                        'employee_id' => $employee['id'] ?? 'N/A',
                                        'unit_id' => $empUnitId,
                                        'unit_name' => $empUnitName,
                                        'parent_unit_id' => $parentUnitId
                                    ]);
                                }
                                // Check 2: Employee's unit has parent_unit_id matching parent unit (programs under college)
                                // Check unit.parent_unit.id first (from userinfo), then unit.parent_unit_id
                                // If not found, fetch unit details from API as fallback
                                if (!$shouldInclude) {
                                    $empParentUnitId = null;
                                    
                                    // Check unit.parent_unit.id (from userinfo designations)
                                    if (isset($empUnit['parent_unit']['id'])) {
                                        $empParentUnitId = $empUnit['parent_unit']['id'];
                                        debugLog("Found employee parent_unit.id", [
                                            'employee_id' => $employee['id'] ?? 'N/A',
                                            'unit_name' => $empUnitName,
                                            'parent_unit_id' => $empParentUnitId
                                        ]);
                                    }
                                    // Fallback to unit.parent_unit_id
                                    elseif (isset($empUnit['parent_unit_id'])) {
                                        $empParentUnitId = $empUnit['parent_unit_id'];
                                        debugLog("Found employee parent_unit_id", [
                                            'employee_id' => $employee['id'] ?? 'N/A',
                                            'unit_name' => $empUnitName,
                                            'parent_unit_id' => $empParentUnitId
                                        ]);
                                    }
                                    // Last resort: Fetch unit details from API if parent info is missing
                                    elseif (isset($empUnit['id']) && ($empUnit['unit_type'] ?? null) === 'program') {
                                        // Only fetch if it's a program (programs have parents, colleges don't)
                                        try {
                                            $empUnitDetails = $hrAPI->getUnitById($empUnit['id']);
                                            if ($empUnitDetails) {
                                                // Check unit.parent_unit.id from API response
                                                if (isset($empUnitDetails['parent_unit']['id'])) {
                                                    $empParentUnitId = $empUnitDetails['parent_unit']['id'];
                                                    debugLog("Found employee parent_unit.id via API", [
                                                        'employee_id' => $employee['id'] ?? 'N/A',
                                                        'unit_name' => $empUnitName,
                                                        'parent_unit_id' => $empParentUnitId
                                                    ]);
                                                }
                                                // Or check parent_unit_id directly
                                                elseif (isset($empUnitDetails['parent_unit_id'])) {
                                                    $empParentUnitId = $empUnitDetails['parent_unit_id'];
                                                    debugLog("Found employee parent_unit_id via API", [
                                                        'employee_id' => $employee['id'] ?? 'N/A',
                                                        'unit_name' => $empUnitName,
                                                        'parent_unit_id' => $empParentUnitId
                                                    ]);
                                                }
                                            }
                                        } catch (Exception $e) {
                                            debugLog("Failed to fetch unit details for employee", [
                                                'employee_id' => $employee['id'] ?? 'N/A',
                                                'unit_id' => $empUnit['id'],
                                                'error' => $e->getMessage()
                                            ]);
                                        }
                                    }
                                    
                                    if ($empParentUnitId) {
                                        $normalizedEmpParentId = (string)$empParentUnitId;
                                        if ($normalizedEmpParentId === $normalizedParentUnitId) {
                                            $shouldInclude = true;
                                            debugLog("✅ Employee in program under parent unit", [
                                                'employee_id' => $employee['id'] ?? 'N/A',
                                                'unit_id' => $empUnitId,
                                                'unit_name' => $empUnitName,
                                                'employee_parent_unit_id' => $empParentUnitId,
                                                'target_parent_unit_id' => $parentUnitId
                                            ]);
                                        } else {
                                            // Debug why it didn't match (for first few)
                                            if (count($filteredEmployees) < 5) {
                                                debugLog("❌ Employee parent unit mismatch", [
                                                    'employee_id' => $employee['id'] ?? 'N/A',
                                                    'unit_name' => $empUnitName,
                                                    'employee_parent_unit_id' => $empParentUnitId,
                                                    'normalized_emp_parent' => $normalizedEmpParentId,
                                                    'target_parent_unit_id' => $parentUnitId,
                                                    'normalized_target' => $normalizedParentUnitId
                                                ]);
                                            }
                                        }
                                    } else {
                                        // Debug missing parent unit info (for first few)
                                        if (count($filteredEmployees) < 5) {
                                            debugLog("⚠️ Employee unit missing parent info", [
                                                'employee_id' => $employee['id'] ?? 'N/A',
                                                'unit_id' => $empUnitId,
                                                'unit_name' => $empUnitName,
                                                'unit_type' => $empUnit['unit_type'] ?? 'not_set',
                                                'unit_keys' => array_keys($empUnit),
                                                'has_parent_unit' => isset($empUnit['parent_unit']),
                                                'has_parent_unit_id' => isset($empUnit['parent_unit_id'])
                                            ]);
                                        }
                                    }
                                }
                                
                                if ($shouldInclude) {
                                    $filteredEmployees[] = $employee;
                                }
                            }
                        }
                        
                        $autoImportEmployees = $filteredEmployees;
                        $debugInfo['employees_found'] = count($autoImportEmployees);
                        $debugInfo['total_employees_checked'] = count($allEmployees);
                        $debugInfo['parent_unit_id_used'] = $parentUnitId;
                        debugLog("Auto-import employees found from parent unit and its programs", [
                            'count' => count($autoImportEmployees),
                            'total_checked' => count($allEmployees),
                            'parent_unit_id' => $parentUnitId
                        ]);
                    } else {
                        $debugInfo['error'] = 'Coordinator unit is a program but parent_unit_id not found';
                        debugLog("Coordinator unit is a program but parent_unit_id not found");
                    }
                } elseif ($unitType === 'college') {
                    // For colleges: fetch employees directly from this college unit AND programs under it
                    debugLog("Coordinator has college unit, fetching employees from college and its programs", [
                        'unit_id' => $coordinatorUnitId,
                        'unit_name' => $coordinatorUnit['name'] ?? 'N/A'
                    ]);
                    
                    // Fetch all employees and filter by:
                    // 1. Employees with unit_id matching coordinator's unit (directly assigned to college)
                    // 2. Employees in programs with parent_unit_id matching coordinator's unit
                    $allEmployees = $hrAPI->fetchAllEmployees('active');
                    $filteredEmployees = [];
                    $matchCounts = ['direct' => 0, 'parent_match' => 0, 'via_details' => 0];
                    
                    debugLog("Total employees fetched from HR: " . count($allEmployees));
                    debugLog("Coordinator unit details", [
                        'coordinator_unit_id' => $coordinatorUnitId,
                        'coordinator_unit_name' => $coordinatorUnit['name'] ?? 'N/A',
                        'coordinator_unit_type' => $unitType
                    ]);
                    
                    foreach ($allEmployees as $employee) {
                        $empUnit = $employee['unit'] ?? null;
                        if ($empUnit) {
                            $empUnitId = $empUnit['id'] ?? null;
                            $empUnitName = $empUnit['name'] ?? 'N/A';
                            $shouldInclude = false;
                            $matchReason = '';
                            
                            // Normalize IDs for comparison (handle string/int mismatch)
                            $normalizedCoordinatorUnitId = (string)$coordinatorUnitId;
                            $normalizedEmpUnitId = $empUnitId ? (string)$empUnitId : null;
                            
                            // Check 1: Employee's unit directly matches coordinator's unit
                            if ($normalizedEmpUnitId === $normalizedCoordinatorUnitId) {
                                $shouldInclude = true;
                                $matchReason = 'direct_unit_match';
                                $matchCounts['direct']++;
                                debugLog("✅ Employee matches coordinator unit directly", [
                                    'employee_id' => $employee['id'] ?? 'N/A',
                                    'employee_name' => ($employee['name']['full_name'] ?? 'N/A'),
                                    'unit_id' => $empUnitId,
                                    'unit_name' => $empUnitName
                                ]);
                            }
                            // Check 2: Employee's unit has parent_unit_id matching coordinator's unit
                            // Check unit.parent_unit.id first (from userinfo), then unit.parent_unit_id
                            // If not found, fetch unit details from API as fallback
                            if (!$shouldInclude) {
                                $empParentUnitId = null;
                                
                                // Check unit.parent_unit.id (from userinfo designations)
                                if (isset($empUnit['parent_unit']['id'])) {
                                    $empParentUnitId = $empUnit['parent_unit']['id'];
                                    debugLog("Found employee parent_unit.id", [
                                        'employee_id' => $employee['id'] ?? 'N/A',
                                        'unit_name' => $empUnitName,
                                        'parent_unit_id' => $empParentUnitId
                                    ]);
                                }
                                // Fallback to unit.parent_unit_id
                                elseif (isset($empUnit['parent_unit_id'])) {
                                    $empParentUnitId = $empUnit['parent_unit_id'];
                                    debugLog("Found employee parent_unit_id", [
                                        'employee_id' => $employee['id'] ?? 'N/A',
                                        'unit_name' => $empUnitName,
                                        'parent_unit_id' => $empParentUnitId
                                    ]);
                                }
                                // Last resort: Fetch unit details from API if parent info is missing
                                elseif (isset($empUnit['id']) && $empUnit['unit_type'] === 'program') {
                                    // Only fetch if it's a program (programs have parents, colleges don't)
                                    try {
                                        $empUnitDetails = $hrAPI->getUnitById($empUnit['id']);
                                        if ($empUnitDetails) {
                                            // Check unit.parent_unit.id from API response
                                            if (isset($empUnitDetails['parent_unit']['id'])) {
                                                $empParentUnitId = $empUnitDetails['parent_unit']['id'];
                                                debugLog("Found employee parent_unit.id via API", [
                                                    'employee_id' => $employee['id'] ?? 'N/A',
                                                    'unit_name' => $empUnitName,
                                                    'parent_unit_id' => $empParentUnitId
                                                ]);
                                            }
                                            // Or check parent_unit_id directly
                                            elseif (isset($empUnitDetails['parent_unit_id'])) {
                                                $empParentUnitId = $empUnitDetails['parent_unit_id'];
                                                debugLog("Found employee parent_unit_id via API", [
                                                    'employee_id' => $employee['id'] ?? 'N/A',
                                                    'unit_name' => $empUnitName,
                                                    'parent_unit_id' => $empParentUnitId
                                                ]);
                                            }
                                        }
                                    } catch (Exception $e) {
                                        debugLog("Failed to fetch unit details for employee", [
                                            'employee_id' => $employee['id'] ?? 'N/A',
                                            'unit_id' => $empUnit['id'],
                                            'error' => $e->getMessage()
                                        ]);
                                    }
                                }
                                
                                if ($empParentUnitId) {
                                    $normalizedEmpParentId = (string)$empParentUnitId;
                                    if ($normalizedEmpParentId === $normalizedCoordinatorUnitId) {
                                        $shouldInclude = true;
                                        $matchReason = 'parent_unit_match';
                                        $matchCounts['parent_match']++;
                                        debugLog("✅ Employee in program under coordinator unit", [
                                            'employee_id' => $employee['id'] ?? 'N/A',
                                            'employee_name' => ($employee['name']['full_name'] ?? 'N/A'),
                                            'unit_id' => $empUnitId,
                                            'unit_name' => $empUnitName,
                                            'employee_parent_unit_id' => $empParentUnitId,
                                            'coordinator_unit_id' => $coordinatorUnitId
                                        ]);
                                    } else {
                                        // Debug mismatch (for first few)
                                        if (count($filteredEmployees) < 5) {
                                            debugLog("❌ Parent unit ID mismatch", [
                                                'employee_unit' => $empUnitName,
                                                'employee_parent_id' => $empParentUnitId,
                                                'normalized_emp_parent' => $normalizedEmpParentId,
                                                'coordinator_unit_id' => $coordinatorUnitId,
                                                'normalized_coord' => $normalizedCoordinatorUnitId
                                            ]);
                                        }
                                    }
                                } else {
                                    // Debug missing parent unit info (for first few)
                                    if (count($filteredEmployees) < 5) {
                                        debugLog("⚠️ Employee unit missing parent info", [
                                            'employee_id' => $employee['id'] ?? 'N/A',
                                            'unit_id' => $empUnitId,
                                            'unit_name' => $empUnitName,
                                            'unit_type' => $empUnit['unit_type'] ?? 'not_set',
                                            'unit_keys' => array_keys($empUnit),
                                            'has_parent_unit' => isset($empUnit['parent_unit']),
                                            'has_parent_unit_id' => isset($empUnit['parent_unit_id'])
                                        ]);
                                    }
                                }
                            }
                            
                            if ($shouldInclude) {
                                $filteredEmployees[] = $employee;
                            } else {
                                // Debug: Log why employee was excluded (for first few)
                                if (count($filteredEmployees) < 3) {
                                    debugLog("❌ Employee excluded", [
                                        'employee_id' => $employee['id'] ?? 'N/A',
                                        'unit_id' => $empUnitId,
                                        'unit_name' => $empUnitName,
                                        'unit_parent_id' => $empUnit['parent_unit_id'] ?? 'not_set',
                                        'coordinator_unit_id' => $coordinatorUnitId
                                    ]);
                                }
                            }
                        }
                    }
                    
                    $autoImportEmployees = $filteredEmployees;
                    $debugInfo['employees_found'] = count($autoImportEmployees);
                    $debugInfo['total_employees_checked'] = count($allEmployees);
                    $debugInfo['filter_method'] = 'by_college_unit_and_programs';
                    $debugInfo['match_breakdown'] = $matchCounts;
                    $debugInfo['coordinator_unit_id_used'] = $coordinatorUnitId;
                    debugLog("Auto-import employees found from college and programs", [
                        'count' => count($autoImportEmployees),
                        'total_checked' => count($allEmployees),
                        'breakdown' => $matchCounts,
                        'coordinator_unit_id' => $coordinatorUnitId,
                        'coordinator_unit_name' => $coordinatorUnit['name'] ?? 'N/A'
                    ]);
                } else {
                    $debugInfo['error'] = "Coordinator unit type '$unitType' is not supported. Supported types: 'program' or 'college'.";
                    debugLog("Coordinator unit type not supported", ['unit_type' => $unitType]);
                }
                
                // If no employees found, test API connection
                if (empty($autoImportEmployees)) {
                    $debugInfo['warning'] = 'No employees found. Testing API connection...';
                    debugLog("Coordinator Auto-Import - Testing: Fetching all employees");
                    $testEmployees = $hrAPI->fetchAllEmployees('active');
                    $debugInfo['test_all_employees_count'] = count($testEmployees);
                    debugLog("Coordinator Auto-Import - Test: Found " . count($testEmployees) . " total employees");
                }
                } // Close fallback block (when Research Office API not available)
                } // Close else block (coordinatorInfo exists)
            } catch (Exception $e) {
                $debugInfo['error'] = 'Exception while fetching coordinator info: ' . $e->getMessage();
                $debugInfo['exception_trace'] = $e->getTraceAsString();
                errorLog("Coordinator Auto-Import - Exception", [
                    'employee_id' => $coordinatorEmployeeId,
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
        }
    } catch (Exception $e) {
        $debugInfo['exception'] = $e->getMessage();
        $debugInfo['trace'] = $e->getTraceAsString();
        errorLog("Error fetching coordinator unit for auto-import: " . $e->getMessage(), [
            'trace' => $e->getTraceAsString()
        ]);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Import Faculty from HR System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
:root {
    --primary: #064e1a;
    --primary-light: #0b6a24;
    --success: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --info: #3b82f6;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-500: #6b7280;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, var(--gray-50) 0%, #e0e7ff 100%);
    padding: 20px;
    min-height: 100vh;
}

.container {
    max-width: 900px;
    margin: 0 auto;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
    margin-bottom: 20px;
    padding: 10px 15px;
    background: white;
    border-radius: 8px;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
}

.back-link:hover {
    transform: translateX(-5px);
    box-shadow: var(--shadow-lg);
}

.main-card {
    background: white;
    border-radius: 16px;
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.card-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
    color: white;
    padding: 30px;
}

.card-header h1 {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.card-header p {
    opacity: 0.9;
    font-size: 14px;
}

.card-body {
    padding: 40px;
}

.search-section {
    margin-bottom: 30px;
}

.search-box {
    position: relative;
}

.search-input {
    width: 100%;
    padding: 16px 50px 16px 20px;
    border: 2px solid var(--gray-200);
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.search-icon {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-500);
    font-size: 20px;
}

.search-help {
    margin-top: 8px;
    font-size: 13px;
    color: var(--gray-500);
}

.auto-import-section {
    margin-top: 20px;
}

.import-progress {
    margin-top: 20px;
    padding: 20px;
    background: var(--gray-50);
    border-radius: 8px;
}

.progress-bar {
    width: 100%;
    height: 24px;
    background: var(--gray-200);
    border-radius: 12px;
    overflow: hidden;
    margin-bottom: 10px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--success), #059669);
    transition: width 0.3s ease;
    border-radius: 12px;
}

.progress-text {
    text-align: center;
    font-size: 14px;
    color: var(--gray-700);
    font-weight: 500;
}

.employee-list-display {
    margin-top: 30px;
    margin-bottom: 20px;
}

.employee-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    max-height: 500px;
    overflow-y: auto;
    padding: 10px;
    background: var(--gray-50);
    border-radius: 8px;
}

.employee-card {
    background: white;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border-left: 4px solid var(--info);
    transition: all 0.3s ease;
}

.employee-card.importing {
    border-left-color: var(--warning);
    background: #fef3c7;
}

.employee-card.success {
    border-left-color: var(--success);
    background: #d1fae5;
}

.employee-card.error {
    border-left-color: var(--danger);
    background: #fee2e2;
}

.employee-card.selectable {
    cursor: pointer;
    transition: all 0.2s ease;
}

.employee-card.selectable:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.employee-card.selectable.selected {
    border-left-color: var(--primary);
    background: #eff6ff;
}

.employee-card.imported {
    opacity: 0.7;
    background: #f3f4f6;
    border-left-color: #10b981;
    cursor: not-allowed;
}

.employee-card.imported:hover {
    transform: none;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.employee-checkbox {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.employee-checkbox input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    margin-right: 8px;
}

.selection-controls {
    display: flex;
    align-items: center;
    gap: 10px;
}

.employee-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--gray-200);
}

.employee-number {
    font-weight: 600;
    color: var(--gray-500);
    font-size: 12px;
}

.employee-status {
    font-size: 12px;
    padding: 4px 8px;
    border-radius: 4px;
    background: var(--gray-200);
    color: var(--gray-700);
}

.employee-status.importing {
    background: #fef3c7;
    color: #92400e;
}

.employee-status.success {
    background: #d1fae5;
    color: #065f46;
}

.employee-status.error {
    background: #fee2e2;
    color: #991b1b;
}

.employee-card-body h4 {
    margin: 0 0 10px 0;
    color: var(--gray-800);
    font-size: 16px;
}

.employee-card-body p {
    margin: 5px 0;
    font-size: 13px;
    color: var(--gray-600);
}

.employee-id {
    font-family: monospace;
    background: var(--gray-100);
    padding: 4px 8px;
    border-radius: 4px;
    display: inline-block;
}

.loading {
    text-align: center;
    padding: 40px;
    color: var(--gray-500);
}

.loading i {
    font-size: 32px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.results-section {
    margin-top: 20px;
    display: none;
}

.results-section.show {
    display: block;
}

.results-header {
    font-size: 14px;
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.results-count {
    background: var(--primary);
    color: white;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 12px;
}

.employee-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    max-height: 300px;
    overflow-y: auto;
    padding-right: 8px;
}

.employee-card {
    background: var(--gray-50);
    border: 2px solid var(--gray-200);
    border-radius: 12px;
    padding: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
}

.employee-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(6, 78, 26, 0.03) 0%, rgba(11, 106, 36, 0.03) 100%);
    border-radius: 10px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.employee-card:hover {
    border-color: var(--primary);
    transform: translateY(-2px);
    box-shadow: var(--shadow);
}

.employee-card:hover::before {
    opacity: 1;
}

.employee-card.selected {
    border-color: var(--primary);
    background: linear-gradient(135deg, rgba(6, 78, 26, 0.08) 0%, rgba(11, 106, 36, 0.08) 100%);
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.employee-card.selected::before {
    opacity: 1;
}

.employee-info {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    position: relative;
    z-index: 1;
}

.employee-details h3 {
    font-size: 16px;
    font-weight: 700;
    color: var(--gray-800);
    margin-bottom: 6px;
}

.employee-meta {
    font-size: 13px;
    color: var(--gray-500);
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.employee-meta span {
    display: flex;
    align-items: center;
    gap: 4px;
}

.radio-indicator {
    width: 20px;
    height: 20px;
    border: 2px solid var(--gray-300);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.employee-card.selected .radio-indicator {
    border-color: var(--primary);
    background: var(--primary);
}

.radio-indicator::after {
    content: '';
    width: 8px;
    height: 8px;
    background: white;
    border-radius: 50%;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.employee-card.selected .radio-indicator::after {
    opacity: 1;
}

.preview-section {
    margin-top: 30px;
    display: none;
    padding: 25px;
    background: linear-gradient(135deg, var(--gray-50) 0%, #e0e7ff 100%);
    border-radius: 12px;
    border: 2px solid var(--info);
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.preview-section.show {
    display: block;
}

.preview-header {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
    font-weight: 700;
    color: var(--info);
    margin-bottom: 20px;
}

.preview-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.preview-item {
    background: white;
    padding: 12px;
    border-radius: 8px;
}

.preview-label {
    font-size: 11px;
    font-weight: 600;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
}

.preview-value {
    font-size: 14px;
    font-weight: 600;
    color: var(--gray-800);
}

.preview-full {
    grid-column: 1 / -1;
}

.form-actions {
    margin-top: 30px;
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}

.btn {
    padding: 12px 24px;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
    color: white;
    box-shadow: var(--shadow);
}

.btn-primary:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.btn-secondary {
    background: var(--gray-200);
    color: var(--gray-700);
}

.btn-secondary:hover {
    background: var(--gray-300);
}

.alert {
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.alert i {
    font-size: 20px;
}

.alert-info {
    background: #dbeafe;
    color: #1e40af;
    border-left: 4px solid var(--info);
}

.alert-success {
    background: #d1fae5;
    color: #065f46;
    border-left: 4px solid var(--success);
}

.alert-error {
    background: #fee2e2;
    color: #991b1b;
    border-left: 4px solid var(--danger);
}

.alert-warning {
    background: #fef3c7;
    color: #92400e;
    border-left: 4px solid var(--warning);
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--gray-500);
}

.empty-state i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
}

.empty-state h3 {
    font-size: 18px;
    margin-bottom: 8px;
}

.empty-state p {
    font-size: 14px;
}

.employee-list::-webkit-scrollbar {
    width: 8px;
}

.employee-list::-webkit-scrollbar-track {
    background: var(--gray-100);
    border-radius: 4px;
}

.employee-list::-webkit-scrollbar-thumb {
    background: var(--gray-300);
    border-radius: 4px;
}

.employee-list::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}
</style>
</head>
<body>

<div class="container">
    <?php if ($userRole !== 'coordinator'): ?>
    <a href="facultyresearcher.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Faculty List
    </a>
    <?php endif; ?>

    <div class="main-card">
        <div class="card-header">
            <h1>
                <i class="fa fa-cloud-download-alt"></i>
                <?php if ($userRole === 'coordinator'): ?>
                    Select Faculty from HR System
                <?php else: ?>
                    Import Faculty from HR System
                <?php endif; ?>
            </h1>
            <p>
                <?php if ($userRole === 'coordinator'): ?>
                    Select employees from <?= s($displayUnitName) ?> to import as faculty researchers
                <?php else: ?>
                    Search and import faculty researcher data directly from the HR System
                <?php endif; ?>
            </p>
        </div>

        <div class="card-body">
            <?php if ($userRole === 'coordinator'): ?>
                <?php
                // Hide employees who are already faculty researchers, and hide Research Coordinators (they manage, not import)
                $availableToImport = [];
                if (!empty($autoImportEmployees)) {
                    $availableToImport = array_values(array_filter($autoImportEmployees, function($emp) use ($importedEmployeeIds) {
                        $id = $emp['id'] ?? '';
                        if (in_array(normalizeEmployeeId($id), $importedEmployeeIds)) return false;
                        $positionName = trim($emp['position']['name'] ?? '');
                        if (stripos($positionName, 'Research Coordinator') !== false) return false;
                        return true;
                    }));
                }
                ?>
                <?php if (!empty($autoImportEmployees)): ?>
                <!-- Employee Selection Section for Coordinators -->
                <div class="auto-import-section">
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle"></i>
                        <div>
                            <strong>ERP Integration:</strong> Faculty data is fetched directly from the HR System.
                            <br><strong>Select Employees:</strong> Choose which employees from <?= s($displayUnitName) ?> to import. Employees already added as faculty researchers (with active sync status) are not shown. Employees with N/A status can be re-imported if they return to your unit.
                        </div>
                    </div>
                    <?php if (!empty($availableToImport)): ?>
                    <div class="alert alert-success">
                        <i class="fa fa-check-circle"></i>
                        <div>
                            <strong>Found <?= count($availableToImport) ?> employee(s) from <?= s($displayUnitName) ?> available to import.</strong>
                            <p>Select the employees you want to import.</p>
                        </div>
                    </div>
                    
                    <!-- Selection Controls -->
                    <div class="selection-controls" style="margin-bottom: 20px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                        <button type="button" class="btn btn-secondary" onclick="selectAllEmployees()" style="margin-right: 10px;">
                            <i class="fa fa-check-square"></i> Select All
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="deselectAllEmployees()" style="margin-right: 10px;">
                            <i class="fa fa-square"></i> Deselect All
                        </button>
                        <span id="selectedCount" style="font-weight: 600; color: var(--primary);">
                            0 selected
                        </span>
                    </div>
                    
                    <!-- Employee List Display -->
                    <div class="employee-list-display">
                        <h3 style="margin-bottom: 15px; color: var(--gray-700);">
                            <i class="fa fa-users"></i> Available Employees (<?= count($availableToImport) ?>)
                        </h3>
                        <div class="employee-grid">
                            <?php 
                            foreach ($availableToImport as $index => $emp): 
                                $empId = $emp['id'] ?? 'N/A';
                                $name = $emp['name'] ?? [];
                                $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                                if (empty($fullName)) $fullName = 'N/A';
                                $position = $emp['position']['name'] ?? 'N/A';
                                $unit = $emp['unit']['name'] ?? 'N/A';
                                $email = $emp['contact']['email'] ?? 'N/A';
                            ?>
                                <div class="employee-card selectable" data-employee-id="<?= s($empId) ?>">
                                    <div class="employee-card-header">
                                        <label class="employee-checkbox">
                                            <input type="checkbox" class="employee-select" value="<?= s($empId) ?>" data-employee-index="<?= $index ?>">
                                            <span class="checkmark"></span>
                                        </label>
                                        <span class="employee-number">#<?= $index + 1 ?></span>
                                    </div>
                                    <div class="employee-card-body">
                                        <h4><?= s($fullName) ?></h4>
                                        <p class="employee-id"><strong>ID:</strong> <?= s($empId) ?></p>
                                        <p><strong>Position:</strong> <?= s($position) ?></p>
                                        <p><strong>Unit:</strong> <?= s($unit) ?></p>
                                        <p><strong>Email:</strong> <?= s($email) ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-success">
                        <i class="fa fa-check-circle"></i>
                        <div>
                            <strong>All active employees from <?= s($displayUnitName) ?> have already been imported as faculty researchers.</strong>
                            <p>There are no additional employees available to import at this time.</p>
                            <p style="margin-top: 10px; font-size: 13px; opacity: 0.9;">
                                <i class="fa fa-info-circle"></i> Note: If a researcher was previously imported but is no longer in your unit (sync status N/A), they can be re-imported if they return to your unit. Use the search function to find and re-import them.
                            </p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Import Button -->
                    <div class="form-actions" style="margin-top: 30px;">
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='facultyresearcher.php'">
                            <i class="fa fa-arrow-left"></i> Back to Faculty List
                        </button>
                        <?php if (!empty($availableToImport)): ?>
                        <button type="button" class="btn btn-primary" id="importSelectedBtn" onclick="importSelectedEmployees()" disabled>
                            <i class="fa fa-download"></i> Import Selected (<span id="importCount">0</span>)
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Progress Display (hidden initially) -->
                    <?php if (!empty($availableToImport)): ?>
                    <div id="importProgress" class="import-progress" style="display: none; margin-top: 20px;">
                        <div class="progress-bar">
                            <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                        </div>
                        <p class="progress-text" id="progressText">Preparing to import...</p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <!-- No employees found for coordinator -->
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>No employees found for import.</strong>
                        <p>
                            <?php if (isset($debugInfo['error'])): ?>
                                <strong>Error:</strong> <?= s($debugInfo['error']) ?>
                                <?php if (isset($debugInfo['error_details'])): ?>
                                    <br><small style="opacity: 0.8;"><?= s($debugInfo['error_details']) ?></small>
                                <?php endif; ?>
                                
                                <?php if (strpos($debugInfo['error'], 'Could not fetch coordinator info') !== false): ?>
                                    <div style="margin-top: 15px; padding: 15px; background: #fef3c7; border-radius: 8px; text-align: left; max-width: 600px;">
                                        <p style="font-weight: 600; color: #92400e; margin-bottom: 8px;"><i class="fa fa-info-circle"></i> Troubleshooting:</p>
                                        <ul style="margin: 0; padding-left: 20px; color: #78350f; font-size: 14px; line-height: 1.6;">
                                            <li><strong>Employee ID mismatch?</strong> Your employee ID in the system may not match what's in the HR system. Try logging out and logging back in via SSO to sync your information.</li>
                                            <li><strong>Token expired?</strong> Your HR API token may have expired. Try logging out and logging back in via SSO.</li>
                                            <li><strong>HR API unavailable?</strong> The HR system may be temporarily unavailable. Please try again later or contact your administrator.</li>
                                            <?php if (isset($debugInfo['api_test_result'])): ?>
                                                <li><strong>API Test Result:</strong> <?= s($debugInfo['api_test_result']) ?>
                                                    <?php if (isset($debugInfo['test_employees_count'])): ?>
                                                        (Found <?= $debugInfo['test_employees_count'] ?> employees)
                                                    <?php endif; ?>
                                                </li>
                                            <?php endif; ?>
                                            <?php if (isset($debugInfo['employee_id_source'])): ?>
                                                <li><strong>Employee ID Source:</strong> <?= s($debugInfo['employee_id_source']) ?>
                                                    <?php if ($debugInfo['employee_id_source'] === 'session'): ?>
                                                        (Consider logging in via SSO to store it in the database)
                                                    <?php endif; ?>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            <?php elseif (isset($debugInfo['warning'])): ?>
                                <?= s($debugInfo['warning']) ?>
                            <?php else: ?>
                                No employees were found in your parent unit. Please contact the administrator if you believe this is an error.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            <?php else: ?>
            <!-- Admin Unit Selection Section -->
            <?php
            // Hide employees who are already faculty researchers (exclude those with sync_status = 'n/a' so they can be re-imported)
            $adminAvailableToImport = [];
            $selectedUnitIndex = isset($_GET['unit']) && $_GET['unit'] !== '' ? (int)$_GET['unit'] : null;
            
            if ($selectedUnitIndex !== null && isset($adminUnitsList[$selectedUnitIndex])) {
                $selectedUnit = $adminUnitsList[$selectedUnitIndex];
                $unitEmployees = $selectedUnit['employees'] ?? [];
                
                $adminAvailableToImport = array_values(array_filter($unitEmployees, function($emp) use ($importedEmployeeIds) {
                    $id = $emp['id'] ?? '';
                    // Only filter out already imported employees (don't hide Research Coordinators)
                    if (in_array(normalizeEmployeeId($id), $importedEmployeeIds)) return false;
                    return true;
                }));
            }
            ?>
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                <div>
                    <strong>ERP Integration:</strong> Faculty data is fetched directly from the HR System.
                    <br><strong>Select Unit:</strong> Choose a unit from the dropdown below to view and import employees from that unit. Employees already added as faculty researchers (with active sync status) are not shown. Employees with N/A status can be re-imported if they return to the unit.
                </div>
            </div>
            
            <!-- Unit Selection Dropdown -->
            <div class="search-section" style="margin-bottom: 30px;">
                <label for="unitSelect" style="display: block; font-weight: 600; margin-bottom: 10px; color: var(--gray-700);">
                    <i class="fa fa-building"></i> Select Unit:
                </label>
                <?php if (!empty($adminUnitsList)): ?>
                <select id="unitSelect" class="search-input" style="cursor: pointer; padding-right: 40px;">
                    <option value="">-- Select a unit to view employees --</option>
                    <?php foreach ($adminUnitsList as $index => $unit): ?>
                        <option value="<?= $index ?>" <?= $selectedUnitIndex === $index ? 'selected' : '' ?>>
                            <?= s($unit['name']) ?> (<?= count($unit['employees']) ?> employee<?= count($unit['employees']) !== 1 ? 's' : '' ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>No units found.</strong>
                        <?php if (isset($debugInfo['admin_error'])): ?>
                            <p><?= s($debugInfo['admin_error']) ?></p>
                        <?php else: ?>
                            <p>Unable to fetch employees from HR System. Please try again later or contact the administrator.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($selectedUnitIndex !== null && isset($adminUnitsList[$selectedUnitIndex])): ?>
                <?php if (!empty($adminAvailableToImport)): ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>Found <?= count($adminAvailableToImport) ?> employee(s) from <?= s($adminUnitsList[$selectedUnitIndex]['name']) ?> available to import.</strong>
                        <p>Select the employees you want to import.</p>
                    </div>
                </div>
                
                <!-- Selection Controls -->
                <div class="selection-controls" style="margin-bottom: 20px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                    <button type="button" class="btn btn-secondary" onclick="selectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-check-square"></i> Select All
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="deselectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-square"></i> Deselect All
                    </button>
                    <span id="selectedCount" style="font-weight: 600; color: var(--primary);">
                        0 selected
                    </span>
                </div>
                
                <!-- Employee List Display -->
                <div class="employee-list-display">
                    <h3 style="margin-bottom: 15px; color: var(--gray-700);">
                        <i class="fa fa-users"></i> Available Employees (<?= count($adminAvailableToImport) ?>)
                    </h3>
                    <div class="employee-grid">
                        <?php 
                        foreach ($adminAvailableToImport as $index => $emp): 
                            $empId = $emp['id'] ?? 'N/A';
                            $name = $emp['name'] ?? [];
                            $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                            if (empty($fullName)) $fullName = 'N/A';
                            $position = $emp['position']['name'] ?? 'N/A';
                            $unit = $emp['unit']['name'] ?? 'N/A';
                            $email = $emp['contact']['email'] ?? 'N/A';
                        ?>
                            <div class="employee-card selectable" data-employee-id="<?= s($empId) ?>">
                                <div class="employee-card-header">
                                    <label class="employee-checkbox">
                                        <input type="checkbox" class="employee-select" value="<?= s($empId) ?>" data-employee-index="<?= $index ?>">
                                        <span class="checkmark"></span>
                                    </label>
                                    <span class="employee-number">#<?= $index + 1 ?></span>
                                </div>
                                <div class="employee-card-body">
                                    <h4><?= s($fullName) ?></h4>
                                    <p class="employee-id"><strong>ID:</strong> <?= s($empId) ?></p>
                                    <p><strong>Position:</strong> <?= s($position) ?></p>
                                    <p><strong>Unit:</strong> <?= s($unit) ?></p>
                                    <p><strong>Email:</strong> <?= s($email) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Import Button -->
                <div class="form-actions" style="margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='facultyresearcher.php'">
                        <i class="fa fa-arrow-left"></i> Back to Faculty List
                    </button>
                    <button type="button" class="btn btn-primary" id="importSelectedBtn" onclick="importSelectedEmployees()" disabled>
                        <i class="fa fa-download"></i> Import Selected (<span id="importCount">0</span>)
                    </button>
                </div>
                
                <!-- Progress Display (hidden initially) -->
                <div id="importProgress" class="import-progress" style="display: none; margin-top: 20px;">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    </div>
                    <p class="progress-text" id="progressText">Preparing to import...</p>
                </div>
                <?php else: ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>All active employees from <?= s($adminUnitsList[$selectedUnitIndex]['name']) ?> have already been imported as faculty researchers.</strong>
                        <p>There are no additional employees available to import at this time.</p>
                        <p style="margin-top: 10px; font-size: 13px; opacity: 0.9;">
                            <i class="fa fa-info-circle"></i> Note: If a researcher was previously imported but is no longer in this unit (sync status N/A), they can be re-imported if they return to the unit. Select a different unit or use the search function to find and re-import them.
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            <?php elseif ($selectedUnitIndex !== null): ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>Invalid unit selected.</strong> Please select a unit from the dropdown.
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fa fa-building"></i>
                    <h3>Select a Unit</h3>
                    <p>Choose a unit from the dropdown above to view and import employees</p>
                </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="facultyresearcherformscript.js"></script>

<?php if ($userRole === 'admin' && $selectedUnitIndex !== null && !empty($adminAvailableToImport)): ?>
<script>
// Employee selection and import for admins
document.addEventListener('DOMContentLoaded', function() {
    const employeesData = <?= json_encode($adminAvailableToImport) ?>;
    const checkboxes = document.querySelectorAll('.employee-select');
    const selectedCountSpan = document.getElementById('selectedCount');
    const importCountSpan = document.getElementById('importCount');
    const importBtn = document.getElementById('importSelectedBtn');
    
    // Unit dropdown change handler
    const unitSelect = document.getElementById('unitSelect');
    if (unitSelect) {
        unitSelect.addEventListener('change', function() {
            const unitIndex = this.value;
            if (unitIndex) {
                window.location.href = 'facultyresearcherform.php?unit=' + unitIndex;
            } else {
                window.location.href = 'facultyresearcherform.php';
            }
        });
    }
    
    // Update selection count
    function updateSelectionCount() {
        const selected = document.querySelectorAll('.employee-select:checked:not(:disabled)');
        const count = selected.length;
        selectedCountSpan.textContent = count + ' selected';
        importCountSpan.textContent = count;
        importBtn.disabled = count === 0;
        
        // Update card visual state (only for enabled checkboxes)
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                const card = cb.closest('.employee-card');
                if (cb.checked) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            }
        });
    }
    
    // Add event listeners to checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectionCount);
        
        // Also toggle on card click (only if not disabled/imported)
        const card = checkbox.closest('.employee-card');
        if (!card.classList.contains('imported')) {
            card.addEventListener('click', function(e) {
                if (e.target.type !== 'checkbox' && !e.target.closest('.employee-checkbox') && !checkbox.disabled) {
                    checkbox.checked = !checkbox.checked;
                    updateSelectionCount();
                }
            });
        }
    });
    
    // Select all function (only selectable employees)
    window.selectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = true;
            }
        });
        updateSelectionCount();
    };
    
    // Deselect all function
    window.deselectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = false;
            }
        });
        updateSelectionCount();
    };
    
    // Import selected employees
    window.importSelectedEmployees = async function() {
        const selected = Array.from(document.querySelectorAll('.employee-select:checked'));
        if (selected.length === 0) {
            alert('Please select at least one employee to import.');
            return;
        }
        
        if (!confirm(`Import ${selected.length} selected employee(s)?`)) {
            return;
        }
        
        // Disable button and show progress
        importBtn.disabled = true;
        document.getElementById('importProgress').style.display = 'block';
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        let importedCount = 0;
        let failedCount = 0;
        const total = selected.length;
        
        // Import each selected employee
        for (let i = 0; i < selected.length; i++) {
            const checkbox = selected[i];
            const employeeId = checkbox.value;
            const employeeIndex = parseInt(checkbox.dataset.employeeIndex);
            const employee = employeesData[employeeIndex];
            const card = checkbox.closest('.employee-card');
            
            // Update card to show importing
            card.classList.add('importing');
            card.classList.remove('selected', 'success', 'error');
            
            try {
                const formData = new FormData();
                formData.append('action', 'import');
                formData.append('employee_id', employeeId);
                
                const response = await fetch('fetch_employee.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    importedCount++;
                    card.classList.remove('importing');
                    card.classList.add('success');
                    checkbox.disabled = true;
                } else {
                    failedCount++;
                    card.classList.remove('importing');
                    card.classList.add('error');
                    
                    if (data.existing_id) {
                        // Already imported - not really an error
                        card.classList.add('success');
                        checkbox.disabled = true;
                    }
                }
            } catch (error) {
                failedCount++;
                card.classList.remove('importing');
                card.classList.add('error');
            }
            
            // Update progress
            const processed = i + 1;
            const percentage = Math.round((processed / total) * 100);
            progressFill.style.width = percentage + '%';
            progressText.textContent = `Importing... ${processed}/${total} (${importedCount} imported, ${failedCount} failed)`;
            
            // Small delay to avoid rate limiting
            if (i < selected.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        }
        
        // Final update
        progressText.textContent = `Complete! ${importedCount} imported, ${failedCount} failed`;
        
        // Redirect after 2 seconds
        setTimeout(() => {
            window.location.href = 'facultyresearcher.php';
        }, 2000);
    };
    
    // Initial count update
    updateSelectionCount();
});
</script>
<?php elseif ($userRole === 'admin'): ?>
<script>
// Unit dropdown change handler for admin (when no unit selected yet)
document.addEventListener('DOMContentLoaded', function() {
    const unitSelect = document.getElementById('unitSelect');
    if (unitSelect) {
        unitSelect.addEventListener('change', function() {
            const unitIndex = this.value;
            if (unitIndex) {
                window.location.href = 'facultyresearcherform.php?unit=' + unitIndex;
            } else {
                window.location.href = 'facultyresearcherform.php';
            }
        });
    }
});
</script>
<?php endif; ?>

<?php if ($userRole === 'coordinator' && !empty($autoImportEmployees)): ?>
<script>
// Employee selection and import for coordinators
document.addEventListener('DOMContentLoaded', function() {
    const employeesData = <?= json_encode($autoImportEmployees) ?>;
    const checkboxes = document.querySelectorAll('.employee-select');
    const selectedCountSpan = document.getElementById('selectedCount');
    const importCountSpan = document.getElementById('importCount');
    const importBtn = document.getElementById('importSelectedBtn');
    
    // Update selection count
    function updateSelectionCount() {
        const selected = document.querySelectorAll('.employee-select:checked:not(:disabled)');
        const count = selected.length;
        selectedCountSpan.textContent = count + ' selected';
        importCountSpan.textContent = count;
        importBtn.disabled = count === 0;
        
        // Update card visual state (only for enabled checkboxes)
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                const card = cb.closest('.employee-card');
                if (cb.checked) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            }
        });
    }
    
    // Add event listeners to checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectionCount);
        
        // Also toggle on card click (only if not disabled/imported)
        const card = checkbox.closest('.employee-card');
        if (!card.classList.contains('imported')) {
            card.addEventListener('click', function(e) {
                if (e.target.type !== 'checkbox' && !e.target.closest('.employee-checkbox') && !checkbox.disabled) {
                    checkbox.checked = !checkbox.checked;
                    updateSelectionCount();
                }
            });
        }
    });
    
    // Select all function (only selectable employees)
    window.selectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = true;
            }
        });
        updateSelectionCount();
    };
    
    // Deselect all function
    window.deselectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = false;
            }
        });
        updateSelectionCount();
    };
    
    // Import selected employees
    window.importSelectedEmployees = async function() {
        const selected = Array.from(document.querySelectorAll('.employee-select:checked'));
        if (selected.length === 0) {
            alert('Please select at least one employee to import.');
            return;
        }
        
        if (!confirm(`Import ${selected.length} selected employee(s)?`)) {
            return;
        }
        
        // Disable button and show progress
        importBtn.disabled = true;
        document.getElementById('importProgress').style.display = 'block';
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        let importedCount = 0;
        let failedCount = 0;
        const total = selected.length;
        
        // Import each selected employee
        for (let i = 0; i < selected.length; i++) {
            const checkbox = selected[i];
            const employeeId = checkbox.value;
            const employeeIndex = parseInt(checkbox.dataset.employeeIndex);
            const employee = employeesData[employeeIndex];
            const card = checkbox.closest('.employee-card');
            
            // Update card to show importing
            card.classList.add('importing');
            card.classList.remove('selected', 'success', 'error');
            
            try {
                const formData = new FormData();
                formData.append('action', 'import');
                formData.append('employee_id', employeeId);
                
                const response = await fetch('fetch_employee.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    importedCount++;
                    card.classList.remove('importing');
                    card.classList.add('success');
                    checkbox.disabled = true;
                } else {
                    failedCount++;
                    card.classList.remove('importing');
                    card.classList.add('error');
                    
                    if (data.existing_id) {
                        // Already imported - not really an error
                        card.classList.add('success');
                        checkbox.disabled = true;
                    }
                }
            } catch (error) {
                failedCount++;
                card.classList.remove('importing');
                card.classList.add('error');
            }
            
            // Update progress
            const processed = i + 1;
            const percentage = Math.round((processed / total) * 100);
            progressFill.style.width = percentage + '%';
            progressText.textContent = `Importing... ${processed}/${total} (${importedCount} imported, ${failedCount} failed)`;
            
            // Small delay to avoid rate limiting
            if (i < selected.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        }
        
        // Final update
        progressText.textContent = `Complete! ${importedCount} imported, ${failedCount} failed`;
        
        // Redirect after 2 seconds
        setTimeout(() => {
            window.location.href = 'facultyresearcher.php';
        }, 2000);
    };
    
    // Initial count update
    updateSelectionCount();
});
</script>
<?php endif; ?>

</body>
</html>
</html>