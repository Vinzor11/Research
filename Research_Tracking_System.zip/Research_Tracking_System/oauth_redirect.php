<?php
require 'db.php';
require 'config.php';
session_start();

$config = getOAuthConfig($conn);
$enabled = !empty($config['enabled']) && !empty($config['client_id']) && !empty($config['client_secret']) && !empty($config['provider_url']) && !empty($config['redirect_uri']);
if (!$enabled) {
    header("Location: login.php?error=" . urlencode("SSO is not enabled or not properly configured. Please contact administrator."));
    exit;
}

$state = generateOAuthState();
$_SESSION['oauth_state'] = $state;

$params = [
    'client_id' => $config['client_id'],
    'redirect_uri' => $config['redirect_uri'],
    'response_type' => 'code',
    'scope' => $config['scopes'],
    'state' => $state,
];
$authUrl = $config['authorize_url'] . '?' . http_build_query($params);

header("Location: " . $authUrl);
exit;
