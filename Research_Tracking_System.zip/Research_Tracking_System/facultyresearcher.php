<?php
session_start();
require 'db.php';
require 'config.php';

// Access control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin','coordinator'])) {
    header("Location: login.php");
    exit;
}
$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

if ($userRole === 'coordinator' && $coordinatorType !== 'faculty') {
    header("Location: research.php");
    exit;
}

// ============================================
// DELETE HANDLER - FIXED VERSION WITH CORRECT TABLE NAMES
// ============================================
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    if ($userRole !== 'admin') {
        die("Unauthorized");
    }
    $delId = (int) $_GET['delete'];
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Get faculty name for logging
        $stmt = $conn->prepare("SELECT CONCAT(last_name, ', ', first_name) as name FROM faculty_researchers WHERE id = ?");
        $stmt->bind_param("i", $delId);
        $stmt->execute();
        $result = $stmt->get_result();
        $facultyInfo = $result->fetch_assoc();
        $facultyName = $facultyInfo['name'] ?? 'Unknown';
        $stmt->close();
        
        // Delete related records first (to avoid foreign key constraint errors)
        
        // 1. Delete faculty project team members (CORRECT TABLE NAME)
        $conn->query("DELETE fpt FROM faculty_project_team fpt 
                     INNER JOIN faculty_projects fp ON fpt.project_id = fp.id 
                     WHERE fp.faculty_id = $delId");
        
        // 2. Delete faculty project costs (CORRECT TABLE NAME)
        $conn->query("DELETE fpc FROM faculty_project_costs fpc 
                     INNER JOIN faculty_projects fp ON fpc.project_id = fp.id 
                     WHERE fp.faculty_id = $delId");
        
        // 3. Delete research outputs/publications
        $conn->query("DELETE fro FROM faculty_research_outputs fro
                     INNER JOIN faculty_projects fp ON fro.project_id = fp.id
                     WHERE fp.faculty_id = $delId");
        
        // 4. Delete projects
        $conn->query("DELETE FROM faculty_projects WHERE faculty_id = $delId");
        
        // 5. Delete education records
        $conn->query("DELETE FROM faculty_education WHERE faculty_id = $delId");
        
        // 6. Finally, delete the faculty researcher
        $stmt = $conn->prepare("DELETE FROM faculty_researchers WHERE id = ?");
        $stmt->bind_param("i", $delId);
        $stmt->execute();
        $stmt->close();
        
        // Commit transaction
        $conn->commit();
        
        // Log the deletion if ActivityLogger exists
        if (file_exists('ActivityLogger.php')) {
            require_once 'ActivityLogger.php';
            $logger = new ActivityLogger($conn, $_SESSION['user_id']);
            $logger->logDelete('faculty_researchers', $delId, 
                "Deleted faculty researcher: $facultyName and all related records (projects, team, costs, outputs, education)");
        }
        
        // Redirect with success message
        header("Location: facultyresearcher.php?deleted=1");
        exit;
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        error_log("Delete faculty error: " . $e->getMessage());
        die("Error deleting faculty: " . $e->getMessage());
    }
}

// Search
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

// Build WHERE clause for user access control
$accessControl = "";
$accessParams = [];
$accessTypes = "";

if ($userRole === 'coordinator') {
    // Coordinators only see their own faculty researchers
    $accessControl = " WHERE fr.created_by = ?";
    $accessParams[] = $userId;
    $accessTypes = "i";
}
// Admin sees all faculty researchers (no WHERE clause needed)

// Get statistics with user access control
if ($userRole === 'coordinator') {
    $totalFaculty = $conn->query("SELECT COUNT(*) as c FROM faculty_researchers WHERE created_by = $userId")->fetch_assoc()['c'];
    $totalProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects fp 
                                   INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
                                   WHERE fr.created_by = $userId")->fetch_assoc()['c'];
    $ongoingProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects fp 
                                     INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
                                     WHERE fr.created_by = $userId AND fp.project_status='on-going'")->fetch_assoc()['c'];
    $completedProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects fp 
                                       INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
                                       WHERE fr.created_by = $userId AND fp.project_status='completed'")->fetch_assoc()['c'];
    $syncedFaculty = $conn->query("SELECT COUNT(*) as c FROM faculty_researchers WHERE created_by = $userId AND is_synced = 1")->fetch_assoc()['c'];
} else {
    // Admin sees all statistics
    $totalFaculty = $conn->query("SELECT COUNT(*) as c FROM faculty_researchers")->fetch_assoc()['c'];
    $totalProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects")->fetch_assoc()['c'];
    $ongoingProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects WHERE project_status='on-going'")->fetch_assoc()['c'];
    $completedProjects = $conn->query("SELECT COUNT(*) as c FROM faculty_projects WHERE project_status='completed'")->fetch_assoc()['c'];
    $syncedFaculty = $conn->query("SELECT COUNT(*) as c FROM faculty_researchers WHERE is_synced = 1")->fetch_assoc()['c'];
}

// Fetch list with project count and user access control
$sql = "SELECT 
    fr.id, 
    fr.faculty_number, 
    fr.last_name, 
    fr.first_name, 
    fr.middle_name, 
    fr.faculty_rank, 
    fr.employment_status, 
    fr.department,
    fr.home_unit,
    fr.email,
    fr.telephone,
    fr.created_by,
    fr.hr_employee_id,
    fr.is_synced,
    fr.last_synced_at,
    fr.sync_status,
    COUNT(fp.id) as project_count
FROM faculty_researchers fr
LEFT JOIN faculty_projects fp ON fr.id = fp.faculty_id";

$params = [];
$types = "";

// Apply access control
if ($userRole === 'coordinator') {
    $sql .= " WHERE fr.created_by = ?";
    $params[] = $userId;
    $types = "i";
}

// Add search filter
if ($q !== '') {
    if ($userRole === 'coordinator') {
        $sql .= " AND (fr.faculty_number LIKE ? OR fr.last_name LIKE ? OR fr.first_name LIKE ? OR fr.faculty_rank LIKE ? OR fr.home_unit LIKE ? OR fr.email LIKE ? OR fr.hr_employee_id LIKE ?)";
    } else {
        $sql .= " WHERE fr.faculty_number LIKE ? OR fr.last_name LIKE ? OR fr.first_name LIKE ? OR fr.faculty_rank LIKE ? OR fr.home_unit LIKE ? OR fr.email LIKE ? OR fr.hr_employee_id LIKE ?";
    }
    $like = "%$q%";
    $params = array_merge($params, [$like,$like,$like,$like,$like,$like,$like]);
    $types .= str_repeat('s', 7);
}

$sql .= " GROUP BY fr.id ORDER BY fr.id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$faculties = $result->fetch_all(MYSQLI_ASSOC);

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faculty Researchers</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* Sync Status Indicators */
.sync-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

.sync-indicator.sync-recent {
    background: #d1fae5;
    color: #065f46;
}

.sync-indicator.sync-needs-sync {
    background: #fef3c7;
    color: #92400e;
}

.sync-indicator.sync-never {
    background: #fee2e2;
    color: #991b1b;
}

.sync-indicator.sync-n-a {
    background: #e5e7eb;
    color: #6b7280;
}

.btn-sync {
    padding: 8px 12px;
    background: #3b82f6;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.btn-sync:hover {
    background: #2563eb;
    transform: translateY(-1px);
}

.btn-sync:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.hr-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    background: #dbeafe;
    color: #1e40af;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 600;
}

.success-message {
    background: #d1fae5;
    color: #065f46;
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-left: 4px solid #10b981;
}
</style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="facultyresearcher.php" class="active"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php if (file_exists('activity_logs.php')): ?>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
    <div class="header">
        <div class="header-title">
            <i class="fa-solid fa-chalkboard-teacher"></i>
            <span>Faculty Researchers <?php if($userRole === 'coordinator') echo '(My Records)'; ?></span>
        </div>
        <div class="header-search">
            <form method="GET" style="display:flex; gap:8px; align-items:center;">
                <input type="text" name="q" placeholder="Search by ID, Name, Department, Rank..." value="<?= s($q) ?>">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
    </div>

    <div class="content">
        <!-- Success Message -->
        <?php if (isset($_GET['deleted'])): ?>
        <div class="success-message">
            <i class="fa fa-check-circle" style="font-size: 20px;"></i>
            <div>
                <strong>Faculty Deleted Successfully!</strong>
                <p style="margin: 0; font-size: 13px; opacity: 0.9;">The faculty researcher and all related records have been removed.</p>
            </div>
        </div>
        <?php endif; ?>
    
        <!-- HR Integration Notice -->
        <?php if (isHRIntegrationAvailable()): ?>
        <div style="background: linear-gradient(135deg, #dbeafe 0%, #e0e7ff 100%); color: #1e40af; padding: 15px 20px; border-radius: 12px; margin-bottom: 25px; display: flex; align-items: center; gap: 12px; border-left: 4px solid #3b82f6;">
            <i class="fa fa-cloud" style="font-size: 20px;"></i>
            <div>
                <strong>HR System Integration Active:</strong> You can now import faculty directly from the HR System. 
                <?= $syncedFaculty ?> of <?= $totalFaculty ?> faculty are synced with HR.
            </div>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalFaculty ?></div>
                        <div class="label"><?= $userRole === 'coordinator' ? 'My' : 'Total' ?> Faculty Researchers</div>
                    </div>
                    <div class="icon"><i class="fa fa-users"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalProjects ?></div>
                        <div class="label"><?= $userRole === 'coordinator' ? 'My' : 'Total' ?> Research Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-flask"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $ongoingProjects ?></div>
                        <div class="label">On-going Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-spinner"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $completedProjects ?></div>
                        <div class="label">Completed Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $syncedFaculty ?></div>
                        <div class="label">HR System Synced</div>
                    </div>
                    <div class="icon"><i class="fa fa-cloud"></i></div>
                </div>
            </div>
        </div>

        <div class="toolbar">
            <div></div>
            <a class="add-btn" href="facultyresearcherform.php">
                <i class="fa fa-cloud-download-alt"></i> Import from HR System
            </a>
        </div>

        <div class="table-wrapper">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Faculty No.</th>
                            <th>Name</th>
                            <th>Rank/Position</th>
                            <th>Employment</th>
                            <th>Unit</th>
                            <th>Contact</th>
                            <th>Outputs</th>
                            <th>Last Synced</th>
                            <th>Sync Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($faculties)): ?>
                            <tr>
                                <td colspan="11">
                                    <div class="no-data">
                                        <i class="fa fa-inbox"></i>
                                        <p>No faculty records found.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: foreach($faculties as $f): 
                            $fullname = $f['last_name'] . ', ' . $f['first_name'] . ($f['middle_name'] ? ' '.$f['middle_name'] : '');
                            
                            // Determine sync status - use sync_status column if set to 'n/a', otherwise use existing logic
                            $syncStatus = 'never';
                            if (!empty($f['sync_status']) && $f['sync_status'] === 'n/a') {
                                $syncStatus = 'n/a';
                            } elseif ($f['is_synced'] && $f['last_synced_at']) {
                                if (needsHRSync($f['last_synced_at'])) {
                                    $syncStatus = 'needs-sync';
                                } else {
                                    $syncStatus = 'recent';
                                }
                            }
                        ?>
                        <tr>
                            <td><?= $f['id'] ?></td>
                            <td>
                                <strong><?= s($f['faculty_number']) ?></strong>
                                <?php if ($f['is_synced']): ?>
                                    <br><span class="hr-badge"><i class="fa fa-cloud"></i> HR Synced</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:left; padding-left:16px;">
                                <?= s($fullname) ?>
                                <?php if (!empty($f['hr_employee_id'])): ?>
                                    <br><small style="color: #6b7280;"><i class="fa fa-id-card"></i> HR: <?= s($f['hr_employee_id']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= s($f['faculty_rank'] ?: 'N/A') ?>
                            </td>
                            <td>
                                <span class="badge" style="background: #e0e7ff; color: #3730a3;">
                                    <?= s($f['employment_status'] ?: 'N/A') ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($f['home_unit'])): ?>
                                    <span style="color: #059669; font-weight: 500;"><i class="fa fa-building"></i> <?= s($f['home_unit']) ?></span>
                                <?php else: ?>
                                    <span style="color: #9ca3af;">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($f['email'])): ?>
                                    <div style="font-size: 11px;">
                                        <i class="fa fa-envelope"></i> <?= s($f['email']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($f['telephone'])): ?>
                                    <div style="font-size: 11px; color: #6b7280;">
                                        <i class="fa fa-phone"></i> <?= s($f['telephone']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (empty($f['email']) && empty($f['telephone'])): ?>
                                    <span style="color: #9ca3af;">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge">
                                    <i class="fa fa-file-alt"></i>
                                    <?= $f['project_count'] ?> Outputs
                                </span>
                            </td>
                            <td class="sync-timestamp" style="font-size: 12px; color: #6b7280;">
                                <?php if ($f['is_synced']): ?>
                                    <?= timeAgo($f['last_synced_at']) ?>
                                <?php else: ?>
                                    <span style="color: var(--gray-400);">Never synced</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="sync-indicator sync-<?= $syncStatus ?>">
                                    <?php if ($syncStatus === 'recent'): ?>
                                        🟢 Synced
                                    <?php elseif ($syncStatus === 'needs-sync'): ?>
                                        🟡 Outdated
                                    <?php elseif ($syncStatus === 'n/a'): ?>
                                        ⚪ N/A
                                    <?php else: ?>
                                        🔴 Not synced
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-view" onclick="location.href='facultyresearcherprofile.php?id=<?= $f['id'] ?>'">
                                        <i class="fa fa-eye"></i> View
                                    </button>
                                    
                                    <?php if ($f['is_synced'] && $f['hr_employee_id'] && $syncStatus !== 'n/a'): ?>
                                        <button class="btn-sync" onclick="syncFaculty(<?= $f['id'] ?>)">
                                            <i class="fa fa-sync"></i> Sync
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// ========================================
// INLINE FUNCTIONS - GUARANTEED TO WORK
// ========================================

/**
 * Sync faculty with HR System
 */
window.syncFaculty = async function(facultyId) {
    if (!confirm('Sync this faculty data with HR System?\n\nThis will update their information with the latest data from HR.')) {
        return;
    }
    
    const btn = event.target.closest('.btn-sync');
    if (!btn) return;
    
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'sync');
        formData.append('faculty_id', facultyId);
        
        const response = await fetch('fetch_employee.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Faculty data synced successfully!');
            setTimeout(() => location.reload(), 500);
        } else {
            throw new Error(data.error || 'Failed to sync');
        }
    } catch (error) {
        alert('❌ Sync failed: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    }
};

console.log('✅ Faculty functions loaded:', typeof syncFaculty);
</script>

<!-- Optional: Keep external script for additional features -->
<script src="facultyresearcherscript.js"></script>

</body>
</html>