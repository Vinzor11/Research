<?php
/**
 * Create Coordinator Assignments Table
 * Run this once to create the table for storing coordinator assignments
 */

require 'db.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS coordinator_assignments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(100) NOT NULL,
        coordinator_type ENUM('faculty', 'student') NOT NULL,
        assigned_by INT NOT NULL,
        assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        status ENUM('active', 'inactive') DEFAULT 'active',
        UNIQUE KEY unique_employee_coordinator (employee_id, coordinator_type),
        INDEX idx_employee_id (employee_id),
        INDEX idx_coordinator_type (coordinator_type),
        INDEX idx_status (status),
        FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    $conn->query($sql);
    echo "✅ Coordinator assignments table created successfully!\n";
    
    // Check if email column exists in users table for coordinator_type
    $checkColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
    if ($checkColumn->num_rows == 0) {
        $conn->query("ALTER TABLE users ADD COLUMN coordinator_type ENUM('faculty', 'student', NULL) DEFAULT NULL AFTER user_role");
        echo "✅ Added coordinator_type column to users table\n";
    }
    
    // Check if user_role column exists
    $checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'");
    if ($checkRoleColumn->num_rows == 0) {
        // Try 'role' column
        $checkRole = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
        if ($checkRole->num_rows > 0) {
            $conn->query("ALTER TABLE users CHANGE role user_role ENUM('admin', 'coordinator', 'faculty', 'student') DEFAULT 'student'");
            echo "✅ Renamed role column to user_role\n";
        } else {
            $conn->query("ALTER TABLE users ADD COLUMN user_role ENUM('admin', 'coordinator', 'faculty', 'student') DEFAULT 'student' AFTER password");
            echo "✅ Added user_role column to users table\n";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}

$conn->close();
?>
