-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2026 at 04:57 PM
-- Server version: 11.7.2-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hr_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_ranks`
--

CREATE TABLE `academic_ranks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `level` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `academic_ranks`
--

INSERT INTO `academic_ranks` (`id`, `name`, `code`, `level`, `description`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Instructor I', 'INST_I', 1, NULL, 1, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(2, 'Instructor II', 'INST_II', 2, NULL, 1, 2, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(3, 'Instructor III', 'INST_III', 3, NULL, 1, 3, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(4, 'Assistant Professor I', 'ASST_PROF_I', 4, NULL, 1, 4, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(5, 'Assistant Professor II', 'ASST_PROF_II', 5, NULL, 1, 5, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(6, 'Assistant Professor III', 'ASST_PROF_III', 6, NULL, 1, 6, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(7, 'Assistant Professor IV', 'ASST_PROF_IV', 7, NULL, 1, 7, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(8, 'Associate Professor I', 'ASSOC_PROF_I', 8, NULL, 1, 8, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(9, 'Associate Professor II', 'ASSOC_PROF_II', 9, NULL, 1, 9, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(10, 'Associate Professor III', 'ASSOC_PROF_III', 10, NULL, 1, 10, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(11, 'Associate Professor IV', 'ASSOC_PROF_IV', 11, NULL, 1, 11, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(12, 'Associate Professor V', 'ASSOC_PROF_V', 12, NULL, 1, 12, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(13, 'Professor I', 'PROF_I', 13, NULL, 1, 13, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(14, 'Professor II', 'PROF_II', 14, NULL, 1, 14, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(15, 'Professor III', 'PROF_III', 15, NULL, 1, 15, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(16, 'Professor IV', 'PROF_IV', 16, NULL, 1, 16, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(17, 'Professor V', 'PROF_V', 17, NULL, 1, 17, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(18, 'Professor VI', 'PROF_VI', 18, NULL, 1, 18, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(19, 'University Professor', 'UNIV_PROF', 19, NULL, 1, 19, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `apply_training`
--

CREATE TABLE `apply_training` (
  `apply_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) DEFAULT NULL,
  `training_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sign_up_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `attendance` enum('Present','Absent','Excused') DEFAULT NULL,
  `certificate_path` text DEFAULT NULL,
  `status` enum('Signed Up','Approved','Completed','Cancelled','Rejected','No Show') NOT NULL DEFAULT 'Signed Up',
  `re_apply_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `request_submission_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `approval_comments`
--

CREATE TABLE `approval_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `approval_action_id` bigint(20) UNSIGNED DEFAULT NULL,
  `content` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'comment',
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `approval_delegations`
--

CREATE TABLE `approval_delegations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `delegator_id` bigint(20) UNSIGNED NOT NULL,
  `delegate_id` bigint(20) UNSIGNED NOT NULL,
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Actor who performed the action',
  `performed_by` varchar(255) DEFAULT NULL COMMENT 'Actor name at time of action; preserved when user is deleted',
  `action` varchar(50) NOT NULL COMMENT 'created, updated, deleted, viewed, approved, restored, etc.',
  `module` varchar(50) NOT NULL COMMENT 'employees, users, requests, payroll, settings, auth, etc.',
  `entity_type` varchar(100) NOT NULL COMMENT 'Employee, User, Request, Role, Permission, etc.',
  `entity_id` varchar(50) DEFAULT NULL,
  `description` text NOT NULL COMMENT 'Human-readable summary of the action',
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Previous state (JSON)' CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'New state (JSON)' CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL COMMENT 'Optional reference number for tracking',
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Full entity snapshot at time of action' CHECK (json_valid(`snapshot`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Immutable timestamp - logs are append-only'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `performed_by`, `action`, `module`, `entity_type`, `entity_id`, `description`, `old_values`, `new_values`, `ip_address`, `user_agent`, `reference_number`, `snapshot`, `created_at`) VALUES
(1, 1, 'Super Admin', 'updated', 'roles', 'Role', '1', 'Label:  > Administrator; Name: Super Admin > administrator; Description:  > system administrator', '{\"label\":null,\"name\":\"Super Admin\",\"description\":null}', '{\"label\":\"Administrator\",\"name\":\"administrator\",\"description\":\"system administrator\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'ROL-20260128-0ZHRR', '{\"id\":1,\"name\":\"administrator\",\"label\":\"Administrator\",\"description\":\"system administrator\",\"is_active\":true,\"guard_name\":\"web\",\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"permissions\":[{\"id\":1,\"module\":\"Audit Logs\",\"name\":\"view-audit-logs\",\"label\":\"View Audit Logs\",\"description\":\"Can view unified audit logs across all modules\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":1}},{\"id\":2,\"module\":\"Roles\",\"name\":\"access-roles-module\",\"label\":\"Access Roles Module\",\"description\":\"Can access roles module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":2}},{\"id\":3,\"module\":\"Permissions\",\"name\":\"access-permissions-module\",\"label\":\"Access Permissions Module\",\"description\":\"Can access permissions module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":3}},{\"id\":4,\"module\":\"Users\",\"name\":\"access-users-module\",\"label\":\"Access Users Module\",\"description\":\"Can access users module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":4}},{\"id\":5,\"module\":\"Employees\",\"name\":\"access-employees-module\",\"label\":\"Access Employees Module\",\"description\":\"Can access employee module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":5}},{\"id\":6,\"module\":\"Requests\",\"name\":\"access-request-types-module\",\"label\":\"Access Requests Module\",\"description\":\"Can configure HR request types and fulfillment workflows\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":6}},{\"id\":7,\"module\":\"Leaves\",\"name\":\"access-leave-calendar\",\"label\":\"Access Leave Calendar\",\"description\":\"Can view the leave calendar showing all employees\' leave requests\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":7}},{\"id\":8,\"module\":\"Leaves\",\"name\":\"manage-leave-balances\",\"label\":\"Manage Leave Balances\",\"description\":\"Can set initial balances, grant special leaves, and adjust employee leave credits\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":8}},{\"id\":9,\"module\":\"Roles\",\"name\":\"create-role\",\"label\":\"Create Role\",\"description\":\"Can create new roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":9}},{\"id\":10,\"module\":\"Roles\",\"name\":\"edit-role\",\"label\":\"Edit Role\",\"description\":\"Can modify existing roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":10}},{\"id\":11,\"module\":\"Roles\",\"name\":\"delete-role\",\"label\":\"Delete Role\",\"description\":\"Can remove roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":11}},{\"id\":12,\"module\":\"Roles\",\"name\":\"view-role\",\"label\":\"View Role\",\"description\":\"Can view role details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":12}},{\"id\":13,\"module\":\"Permissions\",\"name\":\"create-permission\",\"label\":\"Create Permission\",\"description\":\"Can create permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":13}},{\"id\":14,\"module\":\"Permissions\",\"name\":\"edit-permission\",\"label\":\"Edit Permission\",\"description\":\"Can modify permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":14}},{\"id\":15,\"module\":\"Permissions\",\"name\":\"delete-permission\",\"label\":\"Delete Permission\",\"description\":\"Can delete permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":15}},{\"id\":16,\"module\":\"Permissions\",\"name\":\"view-permission\",\"label\":\"View Permission\",\"description\":\"Can view permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":16}},{\"id\":17,\"module\":\"Users\",\"name\":\"create-user\",\"label\":\"Create User\",\"description\":\"Can create new users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":17}},{\"id\":18,\"module\":\"Users\",\"name\":\"edit-user\",\"label\":\"Edit User\",\"description\":\"Can modify user accounts\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":18}},{\"id\":19,\"module\":\"Users\",\"name\":\"delete-user\",\"label\":\"Delete User\",\"description\":\"Can delete users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":19}},{\"id\":20,\"module\":\"Users\",\"name\":\"view-user\",\"label\":\"View User\",\"description\":\"Can view user details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":20}},{\"id\":21,\"module\":\"Users\",\"name\":\"view-user-log\",\"label\":\"View User Log\",\"description\":\"Can view user logs\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":21}},{\"id\":22,\"module\":\"Users\",\"name\":\"view-user-activities\",\"label\":\"View User Activities\",\"description\":\"Can view user login\\/logout activities\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":22}},{\"id\":23,\"module\":\"Users\",\"name\":\"restore-user\",\"label\":\"Restore User\",\"description\":\"Can restore deactivated users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":23}},{\"id\":24,\"module\":\"Users\",\"name\":\"force-delete-user\",\"label\":\"Force Delete User\",\"description\":\"Can permanently delete users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":24}},{\"id\":25,\"module\":\"Employees\",\"name\":\"create-employee\",\"label\":\"Create Employee\",\"description\":\"Can create new employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":25}},{\"id\":26,\"module\":\"Employees\",\"name\":\"edit-employee\",\"label\":\"Edit Employee\",\"description\":\"Can edit employee records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":26}},{\"id\":27,\"module\":\"Employees\",\"name\":\"delete-employee\",\"label\":\"Delete Employee\",\"description\":\"Can delete employee records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":27}},{\"id\":28,\"module\":\"Employees\",\"name\":\"view-employee\",\"label\":\"View Employee\",\"description\":\"Can view employee details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":28}},{\"id\":29,\"module\":\"Employees\",\"name\":\"view-all-employees\",\"label\":\"View All Employees\",\"description\":\"Can view all employees without scope restrictions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":29}},{\"id\":30,\"module\":\"Employees\",\"name\":\"view-faculty-employees\",\"label\":\"View Faculty Employees\",\"description\":\"Can view employees in their faculty regardless of role\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":30}},{\"id\":31,\"module\":\"Employees\",\"name\":\"view-department-employees\",\"label\":\"View Department Employees\",\"description\":\"Can view employees in their department\\/office regardless of role\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":31}},{\"id\":32,\"module\":\"Employees\",\"name\":\"view-employee-log\",\"label\":\"View Employee Log\",\"description\":\"Can view employee logs\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":32}},{\"id\":33,\"module\":\"Employees\",\"name\":\"restore-employee\",\"label\":\"Restore Employee\",\"description\":\"Can restore deleted employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":33}},{\"id\":34,\"module\":\"Employees\",\"name\":\"force-delete-employee\",\"label\":\"Force Delete Employee\",\"description\":\"Can permanently delete employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":34}},{\"id\":35,\"module\":\"Organizational Structure\",\"name\":\"access-faculty\",\"label\":\"Access Faculty\",\"description\":\"Can access faculty module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":35}},{\"id\":36,\"module\":\"Organizational Structure\",\"name\":\"create-faculty\",\"label\":\"Create Faculty\",\"description\":\"Can create new faculties\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":36}},{\"id\":37,\"module\":\"Organizational Structure\",\"name\":\"edit-faculty\",\"label\":\"Edit Faculty\",\"description\":\"Can edit faculty records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":37}},{\"id\":38,\"module\":\"Organizational Structure\",\"name\":\"delete-faculty\",\"label\":\"Delete Faculty\",\"description\":\"Can delete faculties\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":38}},{\"id\":39,\"module\":\"Organizational Structure\",\"name\":\"view-faculty\",\"label\":\"View Faculty\",\"description\":\"Can view faculty details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":39}},{\"id\":40,\"module\":\"Organizational Structure\",\"name\":\"restore-faculty\",\"label\":\"Restore Faculty\",\"description\":\"Can restore deleted faculties\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":40}},{\"id\":41,\"module\":\"Organizational Structure\",\"name\":\"force-delete-faculty\",\"label\":\"Force Delete Faculty\",\"description\":\"Can permanently delete faculties\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":41}},{\"id\":42,\"module\":\"Organizational Structure\",\"name\":\"access-department\",\"label\":\"Access Department\",\"description\":\"Can access department module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":42}},{\"id\":43,\"module\":\"Organizational Structure\",\"name\":\"create-department\",\"label\":\"Create Department\",\"description\":\"Can create new departments\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":43}},{\"id\":44,\"module\":\"Organizational Structure\",\"name\":\"edit-department\",\"label\":\"Edit Department\",\"description\":\"Can edit department records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":44}},{\"id\":45,\"module\":\"Organizational Structure\",\"name\":\"delete-department\",\"label\":\"Delete Department\",\"description\":\"Can delete departments\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":45}},{\"id\":46,\"module\":\"Organizational Structure\",\"name\":\"view-department\",\"label\":\"View Department\",\"description\":\"Can view department details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":46}},{\"id\":47,\"module\":\"Organizational Structure\",\"name\":\"restore-department\",\"label\":\"Restore Department\",\"description\":\"Can restore deleted departments\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":47}},{\"id\":48,\"module\":\"Organizational Structure\",\"name\":\"force-delete-department\",\"label\":\"Force Delete Department\",\"description\":\"Can permanently delete departments\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":48}},{\"id\":49,\"module\":\"Organizational Structure\",\"name\":\"access-office\",\"label\":\"Access Office\",\"description\":\"Can access office module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":49}},{\"id\":50,\"module\":\"Organizational Structure\",\"name\":\"create-office\",\"label\":\"Create Office\",\"description\":\"Can create new offices\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":50}},{\"id\":51,\"module\":\"Organizational Structure\",\"name\":\"edit-office\",\"label\":\"Edit Office\",\"description\":\"Can edit office records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":51}},{\"id\":52,\"module\":\"Organizational Structure\",\"name\":\"delete-office\",\"label\":\"Delete Office\",\"description\":\"Can delete offices\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":52}},{\"id\":53,\"module\":\"Organizational Structure\",\"name\":\"view-office\",\"label\":\"View Office\",\"description\":\"Can view office details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":53}},{\"id\":54,\"module\":\"Organizational Structure\",\"name\":\"restore-office\",\"label\":\"Restore Office\",\"description\":\"Can restore deleted offices\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":54}},{\"id\":55,\"module\":\"Organizational Structure\",\"name\":\"force-delete-office\",\"label\":\"Force Delete Office\",\"description\":\"Can permanently delete offices\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":55}},{\"id\":56,\"module\":\"Organizational Structure\",\"name\":\"access-position\",\"label\":\"Access Position\",\"description\":\"Can access position module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":56}},{\"id\":57,\"module\":\"Organizational Structure\",\"name\":\"create-position\",\"label\":\"Create Position\",\"description\":\"Can create new positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":57}},{\"id\":58,\"module\":\"Organizational Structure\",\"name\":\"edit-position\",\"label\":\"Edit Position\",\"description\":\"Can edit position records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":58}},{\"id\":59,\"module\":\"Organizational Structure\",\"name\":\"delete-position\",\"label\":\"Delete Position\",\"description\":\"Can delete positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":59}},{\"id\":60,\"module\":\"Organizational Structure\",\"name\":\"view-position\",\"label\":\"View Position\",\"description\":\"Can view position details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":60}},{\"id\":61,\"module\":\"Organizational Structure\",\"name\":\"restore-position\",\"label\":\"Restore Position\",\"description\":\"Can restore deleted positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":61}},{\"id\":62,\"module\":\"Organizational Structure\",\"name\":\"force-delete-position\",\"label\":\"Force Delete Position\",\"description\":\"Can permanently delete positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":62}},{\"id\":63,\"module\":\"Organizational Structure\",\"name\":\"access-sector\",\"label\":\"Access Sector\",\"description\":\"Can access sector module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":63}},{\"id\":64,\"module\":\"Organizational Structure\",\"name\":\"create-sector\",\"label\":\"Create Sector\",\"description\":\"Can create new sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":64}},{\"id\":65,\"module\":\"Organizational Structure\",\"name\":\"edit-sector\",\"label\":\"Edit Sector\",\"description\":\"Can edit sector records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":65}},{\"id\":66,\"module\":\"Organizational Structure\",\"name\":\"delete-sector\",\"label\":\"Delete Sector\",\"description\":\"Can delete sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":66}},{\"id\":67,\"module\":\"Organizational Structure\",\"name\":\"view-sector\",\"label\":\"View Sector\",\"description\":\"Can view sector details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":67}},{\"id\":68,\"module\":\"Organizational Structure\",\"name\":\"restore-sector\",\"label\":\"Restore Sector\",\"description\":\"Can restore deleted sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":68}},{\"id\":69,\"module\":\"Organizational Structure\",\"name\":\"force-delete-sector\",\"label\":\"Force Delete Sector\",\"description\":\"Can permanently delete sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":69}},{\"id\":70,\"module\":\"Organizational Structure\",\"name\":\"access-unit\",\"label\":\"Access Unit\",\"description\":\"Can access unit module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":70}},{\"id\":71,\"module\":\"Organizational Structure\",\"name\":\"create-unit\",\"label\":\"Create Unit\",\"description\":\"Can create new units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":71}},{\"id\":72,\"module\":\"Organizational Structure\",\"name\":\"edit-unit\",\"label\":\"Edit Unit\",\"description\":\"Can edit unit records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":72}},{\"id\":73,\"module\":\"Organizational Structure\",\"name\":\"delete-unit\",\"label\":\"Delete Unit\",\"description\":\"Can delete units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":73}},{\"id\":74,\"module\":\"Organizational Structure\",\"name\":\"view-unit\",\"label\":\"View Unit\",\"description\":\"Can view unit details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":74}},{\"id\":75,\"module\":\"Organizational Structure\",\"name\":\"restore-unit\",\"label\":\"Restore Unit\",\"description\":\"Can restore deleted units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":75}},{\"id\":76,\"module\":\"Organizational Structure\",\"name\":\"force-delete-unit\",\"label\":\"Force Delete Unit\",\"description\":\"Can permanently delete units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":76}},{\"id\":77,\"module\":\"Organizational Structure\",\"name\":\"access-unit-position\",\"label\":\"Access Unit-Position Whitelist\",\"description\":\"Can access unit-position whitelist module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":77}},{\"id\":78,\"module\":\"Organizational Structure\",\"name\":\"create-unit-position\",\"label\":\"Create Unit-Position Whitelist\",\"description\":\"Can add positions to unit whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":78}},{\"id\":79,\"module\":\"Organizational Structure\",\"name\":\"edit-unit-position\",\"label\":\"Edit Unit-Position Whitelist\",\"description\":\"Can edit unit-position whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":79}},{\"id\":80,\"module\":\"Organizational Structure\",\"name\":\"delete-unit-position\",\"label\":\"Delete Unit-Position Whitelist\",\"description\":\"Can delete unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":80}},{\"id\":81,\"module\":\"Organizational Structure\",\"name\":\"view-unit-position\",\"label\":\"View Unit-Position Whitelist\",\"description\":\"Can view unit-position whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":81}},{\"id\":82,\"module\":\"Organizational Structure\",\"name\":\"restore-unit-position\",\"label\":\"Restore Unit-Position Whitelist\",\"description\":\"Can restore deleted unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":82}},{\"id\":83,\"module\":\"Organizational Structure\",\"name\":\"force-delete-unit-position\",\"label\":\"Force Delete Unit-Position Whitelist\",\"description\":\"Can permanently delete unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":83}},{\"id\":84,\"module\":\"Employees\",\"name\":\"promote-employee\",\"label\":\"Promote Employee\",\"description\":\"Can record employee promotions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":84}},{\"id\":85,\"module\":\"Employees\",\"name\":\"view-employee-promotions\",\"label\":\"View Employee Promotions\",\"description\":\"Can view employee promotion history\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":85}},{\"id\":86,\"module\":\"Employees\",\"name\":\"promote-grade\",\"label\":\"Promote Grade\\/Rank\",\"description\":\"Can promote employee grade\\/rank (upward progression)\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":86}},{\"id\":87,\"module\":\"Employees\",\"name\":\"correct-grade\",\"label\":\"Correct Grade\\/Rank\",\"description\":\"Can correct\\/adjust employee grade\\/rank (with reason)\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":87}},{\"id\":88,\"module\":\"Employees\",\"name\":\"view-grade-history\",\"label\":\"View Grade History\",\"description\":\"Can view employee grade\\/rank change history\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":88}},{\"id\":89,\"module\":\"Organizational Structure\",\"name\":\"view-organizational-log\",\"label\":\"View Organizational Log\",\"description\":\"Can view organizational logs\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":89}},{\"id\":90,\"module\":\"Trainings\",\"name\":\"access-trainings-module\",\"label\":\"Access Trainings Module\",\"description\":\"Can access trainings module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":90}},{\"id\":91,\"module\":\"Trainings\",\"name\":\"create-training\",\"label\":\"Create Training\",\"description\":\"Can create new trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":91}},{\"id\":92,\"module\":\"Trainings\",\"name\":\"edit-training\",\"label\":\"Edit Training\",\"description\":\"Can edit training records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":92}},{\"id\":93,\"module\":\"Trainings\",\"name\":\"delete-training\",\"label\":\"Delete Training\",\"description\":\"Can delete trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":93}},{\"id\":94,\"module\":\"Trainings\",\"name\":\"view-training\",\"label\":\"View Training\",\"description\":\"Can view training details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":94}},{\"id\":95,\"module\":\"Trainings\",\"name\":\"restore-training\",\"label\":\"Restore Training\",\"description\":\"Can restore deleted trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":95}},{\"id\":96,\"module\":\"Trainings\",\"name\":\"force-delete-training\",\"label\":\"Force Delete Training\",\"description\":\"Can permanently delete trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":96}},{\"id\":97,\"module\":\"Requests\",\"name\":\"create-request-type\",\"label\":\"Create Request Type\",\"description\":\"Can create new request types\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":97}},{\"id\":98,\"module\":\"Requests\",\"name\":\"edit-request-type\",\"label\":\"Edit Request Type\",\"description\":\"Can edit request type records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":98}},{\"id\":99,\"module\":\"Requests\",\"name\":\"delete-request-type\",\"label\":\"Delete Request Type\",\"description\":\"Can delete request types\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":99}},{\"id\":100,\"module\":\"Requests\",\"name\":\"view-request-type\",\"label\":\"View Request Type\",\"description\":\"Can view request type details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":100}}]}', '2026-01-27 16:14:53'),
(2, 1, 'Super Admin', 'created', 'employees', 'Employee', 'EMP0001', 'Created a New Employee: Jyl Derwin Sabungan Martires', NULL, '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0001\",\"updated_at\":\"2026-01-28\",\"created_at\":\"2026-01-28\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260128-81FXR', '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0001\",\"updated_at\":\"2026-01-28\",\"created_at\":\"2026-01-28\"}', '2026-01-27 16:32:58'),
(3, 1, 'Super Admin', 'updated', 'users', 'User', '1', 'Employee Id:  > EMP0001', '{\"employee_id\":null}', '{\"employee_id\":\"EMP0001\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'USR-20260128-2VNDP', '{\"id\":1,\"name\":\"Super Admin\",\"email\":\"arvinnegrillo4@gmail.com\",\"employee_id\":\"EMP0001\",\"email_verified_at\":null,\"two_factor_confirmed_at\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 03:54:10'),
(4, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '1', 'Created designation for employee EMP0001: Unit #18, Position #6', NULL, '{\"employee_id\":\"EMP0001\",\"unit_id\":18,\"position_id\":6,\"academic_rank_id\":15,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-28\",\"end_date\":\"2028-06-28\",\"remarks\":null,\"updated_at\":\"2026-01-28\",\"created_at\":\"2026-01-28\",\"id\":1,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"department_id\":null,\"position_id\":null,\"primary_designation_id\":1,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260128-MUJGP', '{\"employee_id\":\"EMP0001\",\"unit_id\":18,\"position_id\":6,\"academic_rank_id\":15,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-28\",\"end_date\":\"2028-06-28\",\"remarks\":null,\"updated_at\":\"2026-01-28\",\"created_at\":\"2026-01-28\",\"id\":1,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"department_id\":null,\"position_id\":null,\"primary_designation_id\":1,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}}', '2026-01-28 04:04:45'),
(5, 1, 'Super Admin', 'updated', 'organizational', 'Unit', '57', 'Updated unit: Accounting Offices', '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Offices\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'ORG-20260128-YH9TD', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Offices\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 05:20:48'),
(6, 1, 'Super Admin', 'updated', 'organizational', 'Unit', '57', 'Updated unit: Accounting Office', '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Offices\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'ORG-20260128-4JV3Q', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 05:22:06'),
(7, 1, 'Super Admin', 'updated', 'units', 'Unit', '57', 'Name: Accounting Office > Accounting Offices (Office ID: 57, AO)', '{\"name\":\"Accounting Office\"}', '{\"name\":\"Accounting Offices\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'UNIT-20260128-SW2JV', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Offices\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 07:11:46'),
(8, 1, 'Super Admin', 'updated', 'units', 'Unit', '57', 'Name: Accounting Offices > Accounting Office (Office ID: 57, AO)', '{\"name\":\"Accounting Offices\"}', '{\"name\":\"Accounting Office\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'UNIT-20260128-HOTHW', '{\"id\":57,\"sector_id\":\"2\",\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 07:12:08'),
(9, 1, 'Super Admin', 'soft-deleted', 'units', 'Unit', '57', 'Record was marked inactive and hidden from normal views. (Office: Accounting Office, AO)', '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'UNIT-20260128-3DNS0', '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 07:12:13'),
(10, 1, 'Super Admin', 'restored', 'units', 'Unit', '57', 'Record was restored and returned to active use. (Office: Accounting Office, AO)', NULL, '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":\"2026-01-28\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'UNIT-20260128-GCQTE', '{\"id\":57,\"sector_id\":2,\"unit_type\":\"office\",\"name\":\"Accounting Office\",\"code\":\"AO\",\"parent_unit_id\":null,\"description\":null,\"is_active\":true,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":\"2026-01-28\"}', '2026-01-28 07:12:36'),
(11, 1, 'Super Admin', 'updated', 'staff-grades', 'StaffGrade', '1', 'Name: Administrative Aide I > Administrative Aides I (Staff Grade ID: 1, ADMIN_AIDE_I)', '{\"name\":\"Administrative Aide I\"}', '{\"name\":\"Administrative Aides I\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'STGR-20260128-ZDDGN', '{\"id\":1,\"name\":\"Administrative Aides I\",\"code\":\"ADMIN_AIDE_I\",\"level\":1,\"description\":null,\"is_active\":true,\"sort_order\":1,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 07:13:09'),
(12, 1, 'Super Admin', 'updated', 'staff-grades', 'StaffGrade', '1', 'Name: Administrative Aides I > Administrative Aide I (Staff Grade ID: 1, ADMIN_AIDE_I)', '{\"name\":\"Administrative Aides I\"}', '{\"name\":\"Administrative Aide I\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'STGR-20260128-ISFTN', '{\"id\":1,\"name\":\"Administrative Aide I\",\"code\":\"ADMIN_AIDE_I\",\"level\":1,\"description\":null,\"is_active\":true,\"sort_order\":1,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-28 07:13:50'),
(13, 1, 'Super Admin', 'created', 'users', 'User', '2', 'Created a New User: jr', NULL, '{\"name\":\"jr\",\"email\":\"superadmin@example.com\",\"employee_id\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":2}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'USR-20260129-IU7OR', '{\"name\":\"jr\",\"email\":\"superadmin@example.com\",\"employee_id\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":2}', '2026-01-28 17:21:22');
INSERT INTO `audit_logs` (`id`, `user_id`, `performed_by`, `action`, `module`, `entity_type`, `entity_id`, `description`, `old_values`, `new_values`, `ip_address`, `user_agent`, `reference_number`, `snapshot`, `created_at`) VALUES
(14, 1, 'Super Admin', 'updated', 'roles', 'Role', '1', 'Permissions: Removed: View Employee Log', '{\"permissions\":{\"_change_type\":\"array_diff\",\"_added\":[],\"_removed\":[\"View Employee Log\"]}}', '{\"permissions\":{\"_change_type\":\"array_diff\",\"_added\":[],\"_removed\":[\"View Employee Log\"]}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'ROL-20260129-UMAXY', '{\"id\":1,\"name\":\"administrator\",\"label\":\"Administrator\",\"description\":\"system administrator\",\"is_active\":true,\"guard_name\":\"web\",\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"permissions\":[{\"id\":1,\"module\":\"Audit Logs\",\"name\":\"view-audit-logs\",\"label\":\"View Audit Logs\",\"description\":\"Can view unified audit logs across all modules\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":1}},{\"id\":2,\"module\":\"Roles\",\"name\":\"access-roles-module\",\"label\":\"Access Roles Module\",\"description\":\"Can access roles module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":2}},{\"id\":3,\"module\":\"Permissions\",\"name\":\"access-permissions-module\",\"label\":\"Access Permissions Module\",\"description\":\"Can access permissions module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":3}},{\"id\":4,\"module\":\"Users\",\"name\":\"access-users-module\",\"label\":\"Access Users Module\",\"description\":\"Can access users module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":4}},{\"id\":5,\"module\":\"Employees\",\"name\":\"access-employees-module\",\"label\":\"Access Employees Module\",\"description\":\"Can access employee module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":5}},{\"id\":6,\"module\":\"Requests\",\"name\":\"access-request-types-module\",\"label\":\"Access Requests Module\",\"description\":\"Can configure HR request types and fulfillment workflows\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":6}},{\"id\":7,\"module\":\"Leaves\",\"name\":\"access-leave-calendar\",\"label\":\"Access Leave Calendar\",\"description\":\"Can view the leave calendar showing all employees\' leave requests\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":7}},{\"id\":8,\"module\":\"Leaves\",\"name\":\"manage-leave-balances\",\"label\":\"Manage Leave Balances\",\"description\":\"Can set initial balances, grant special leaves, and adjust employee leave credits\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":8}},{\"id\":9,\"module\":\"Roles\",\"name\":\"create-role\",\"label\":\"Create Role\",\"description\":\"Can create new roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":9}},{\"id\":10,\"module\":\"Roles\",\"name\":\"edit-role\",\"label\":\"Edit Role\",\"description\":\"Can modify existing roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":10}},{\"id\":11,\"module\":\"Roles\",\"name\":\"delete-role\",\"label\":\"Delete Role\",\"description\":\"Can remove roles\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":11}},{\"id\":12,\"module\":\"Roles\",\"name\":\"view-role\",\"label\":\"View Role\",\"description\":\"Can view role details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":12}},{\"id\":13,\"module\":\"Permissions\",\"name\":\"create-permission\",\"label\":\"Create Permission\",\"description\":\"Can create permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":13}},{\"id\":14,\"module\":\"Permissions\",\"name\":\"edit-permission\",\"label\":\"Edit Permission\",\"description\":\"Can modify permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":14}},{\"id\":15,\"module\":\"Permissions\",\"name\":\"delete-permission\",\"label\":\"Delete Permission\",\"description\":\"Can delete permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":15}},{\"id\":16,\"module\":\"Permissions\",\"name\":\"view-permission\",\"label\":\"View Permission\",\"description\":\"Can view permissions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":16}},{\"id\":17,\"module\":\"Users\",\"name\":\"create-user\",\"label\":\"Create User\",\"description\":\"Can create new users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":17}},{\"id\":18,\"module\":\"Users\",\"name\":\"edit-user\",\"label\":\"Edit User\",\"description\":\"Can modify user accounts\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":18}},{\"id\":19,\"module\":\"Users\",\"name\":\"delete-user\",\"label\":\"Delete User\",\"description\":\"Can delete users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":19}},{\"id\":20,\"module\":\"Users\",\"name\":\"view-user\",\"label\":\"View User\",\"description\":\"Can view user details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":20}},{\"id\":21,\"module\":\"Users\",\"name\":\"view-user-log\",\"label\":\"View User Log\",\"description\":\"Can view user logs\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":21}},{\"id\":22,\"module\":\"Users\",\"name\":\"view-user-activities\",\"label\":\"View User Activities\",\"description\":\"Can view user login\\/logout activities\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":22}},{\"id\":23,\"module\":\"Users\",\"name\":\"restore-user\",\"label\":\"Restore User\",\"description\":\"Can restore deactivated users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":23}},{\"id\":24,\"module\":\"Users\",\"name\":\"force-delete-user\",\"label\":\"Force Delete User\",\"description\":\"Can permanently delete users\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":24}},{\"id\":25,\"module\":\"Employees\",\"name\":\"create-employee\",\"label\":\"Create Employee\",\"description\":\"Can create new employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":25}},{\"id\":26,\"module\":\"Employees\",\"name\":\"edit-employee\",\"label\":\"Edit Employee\",\"description\":\"Can edit employee records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":26}},{\"id\":27,\"module\":\"Employees\",\"name\":\"delete-employee\",\"label\":\"Delete Employee\",\"description\":\"Can delete employee records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":27}},{\"id\":28,\"module\":\"Employees\",\"name\":\"view-employee\",\"label\":\"View Employee\",\"description\":\"Can view employee details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":28}},{\"id\":29,\"module\":\"Employees\",\"name\":\"view-all-employees\",\"label\":\"View All Employees\",\"description\":\"Can view all employees without scope restrictions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":29}},{\"id\":30,\"module\":\"Employees\",\"name\":\"view-faculty-employees\",\"label\":\"View Faculty Employees\",\"description\":\"Can view employees in their faculty regardless of role\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":30}},{\"id\":31,\"module\":\"Employees\",\"name\":\"view-department-employees\",\"label\":\"View Department Employees\",\"description\":\"Can view employees in their department\\/office regardless of role\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":31}},{\"id\":33,\"module\":\"Employees\",\"name\":\"restore-employee\",\"label\":\"Restore Employee\",\"description\":\"Can restore deleted employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":33}},{\"id\":34,\"module\":\"Employees\",\"name\":\"force-delete-employee\",\"label\":\"Force Delete Employee\",\"description\":\"Can permanently delete employees\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":34}},{\"id\":56,\"module\":\"Organizational Structure\",\"name\":\"access-position\",\"label\":\"Access Position\",\"description\":\"Can access position module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":56}},{\"id\":57,\"module\":\"Organizational Structure\",\"name\":\"create-position\",\"label\":\"Create Position\",\"description\":\"Can create new positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":57}},{\"id\":58,\"module\":\"Organizational Structure\",\"name\":\"edit-position\",\"label\":\"Edit Position\",\"description\":\"Can edit position records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":58}},{\"id\":59,\"module\":\"Organizational Structure\",\"name\":\"delete-position\",\"label\":\"Delete Position\",\"description\":\"Can delete positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":59}},{\"id\":60,\"module\":\"Organizational Structure\",\"name\":\"view-position\",\"label\":\"View Position\",\"description\":\"Can view position details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":60}},{\"id\":61,\"module\":\"Organizational Structure\",\"name\":\"restore-position\",\"label\":\"Restore Position\",\"description\":\"Can restore deleted positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":61}},{\"id\":62,\"module\":\"Organizational Structure\",\"name\":\"force-delete-position\",\"label\":\"Force Delete Position\",\"description\":\"Can permanently delete positions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":62}},{\"id\":63,\"module\":\"Organizational Structure\",\"name\":\"access-sector\",\"label\":\"Access Sector\",\"description\":\"Can access sector module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":63}},{\"id\":64,\"module\":\"Organizational Structure\",\"name\":\"create-sector\",\"label\":\"Create Sector\",\"description\":\"Can create new sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":64}},{\"id\":65,\"module\":\"Organizational Structure\",\"name\":\"edit-sector\",\"label\":\"Edit Sector\",\"description\":\"Can edit sector records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":65}},{\"id\":66,\"module\":\"Organizational Structure\",\"name\":\"delete-sector\",\"label\":\"Delete Sector\",\"description\":\"Can delete sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":66}},{\"id\":67,\"module\":\"Organizational Structure\",\"name\":\"view-sector\",\"label\":\"View Sector\",\"description\":\"Can view sector details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":67}},{\"id\":68,\"module\":\"Organizational Structure\",\"name\":\"restore-sector\",\"label\":\"Restore Sector\",\"description\":\"Can restore deleted sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":68}},{\"id\":69,\"module\":\"Organizational Structure\",\"name\":\"force-delete-sector\",\"label\":\"Force Delete Sector\",\"description\":\"Can permanently delete sectors\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":69}},{\"id\":70,\"module\":\"Organizational Structure\",\"name\":\"access-unit\",\"label\":\"Access Unit\",\"description\":\"Can access unit module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":70}},{\"id\":71,\"module\":\"Organizational Structure\",\"name\":\"create-unit\",\"label\":\"Create Unit\",\"description\":\"Can create new units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":71}},{\"id\":72,\"module\":\"Organizational Structure\",\"name\":\"edit-unit\",\"label\":\"Edit Unit\",\"description\":\"Can edit unit records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":72}},{\"id\":73,\"module\":\"Organizational Structure\",\"name\":\"delete-unit\",\"label\":\"Delete Unit\",\"description\":\"Can delete units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":73}},{\"id\":74,\"module\":\"Organizational Structure\",\"name\":\"view-unit\",\"label\":\"View Unit\",\"description\":\"Can view unit details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":74}},{\"id\":75,\"module\":\"Organizational Structure\",\"name\":\"restore-unit\",\"label\":\"Restore Unit\",\"description\":\"Can restore deleted units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":75}},{\"id\":76,\"module\":\"Organizational Structure\",\"name\":\"force-delete-unit\",\"label\":\"Force Delete Unit\",\"description\":\"Can permanently delete units\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":76}},{\"id\":77,\"module\":\"Organizational Structure\",\"name\":\"access-unit-position\",\"label\":\"Access Unit-Position Whitelist\",\"description\":\"Can access unit-position whitelist module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":77}},{\"id\":78,\"module\":\"Organizational Structure\",\"name\":\"create-unit-position\",\"label\":\"Create Unit-Position Whitelist\",\"description\":\"Can add positions to unit whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":78}},{\"id\":79,\"module\":\"Organizational Structure\",\"name\":\"edit-unit-position\",\"label\":\"Edit Unit-Position Whitelist\",\"description\":\"Can edit unit-position whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":79}},{\"id\":80,\"module\":\"Organizational Structure\",\"name\":\"delete-unit-position\",\"label\":\"Delete Unit-Position Whitelist\",\"description\":\"Can delete unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":80}},{\"id\":81,\"module\":\"Organizational Structure\",\"name\":\"view-unit-position\",\"label\":\"View Unit-Position Whitelist\",\"description\":\"Can view unit-position whitelist\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":81}},{\"id\":82,\"module\":\"Organizational Structure\",\"name\":\"restore-unit-position\",\"label\":\"Restore Unit-Position Whitelist\",\"description\":\"Can restore deleted unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":82}},{\"id\":83,\"module\":\"Organizational Structure\",\"name\":\"force-delete-unit-position\",\"label\":\"Force Delete Unit-Position Whitelist\",\"description\":\"Can permanently delete unit-position whitelist entries\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":83}},{\"id\":84,\"module\":\"Employees\",\"name\":\"promote-employee\",\"label\":\"Promote Employee\",\"description\":\"Can record employee promotions\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":84}},{\"id\":85,\"module\":\"Employees\",\"name\":\"view-employee-promotions\",\"label\":\"View Employee Promotions\",\"description\":\"Can view employee promotion history\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":85}},{\"id\":86,\"module\":\"Employees\",\"name\":\"promote-grade\",\"label\":\"Promote Grade\\/Rank\",\"description\":\"Can promote employee grade\\/rank (upward progression)\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":86}},{\"id\":87,\"module\":\"Employees\",\"name\":\"correct-grade\",\"label\":\"Correct Grade\\/Rank\",\"description\":\"Can correct\\/adjust employee grade\\/rank (with reason)\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":87}},{\"id\":88,\"module\":\"Employees\",\"name\":\"view-grade-history\",\"label\":\"View Grade History\",\"description\":\"Can view employee grade\\/rank change history\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":88}},{\"id\":89,\"module\":\"Organizational Structure\",\"name\":\"view-organizational-log\",\"label\":\"View Organizational Log\",\"description\":\"Can view organizational logs\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":89}},{\"id\":90,\"module\":\"Trainings\",\"name\":\"access-trainings-module\",\"label\":\"Access Trainings Module\",\"description\":\"Can access trainings module\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":90}},{\"id\":91,\"module\":\"Trainings\",\"name\":\"create-training\",\"label\":\"Create Training\",\"description\":\"Can create new trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":91}},{\"id\":92,\"module\":\"Trainings\",\"name\":\"edit-training\",\"label\":\"Edit Training\",\"description\":\"Can edit training records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":92}},{\"id\":93,\"module\":\"Trainings\",\"name\":\"delete-training\",\"label\":\"Delete Training\",\"description\":\"Can delete trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":93}},{\"id\":94,\"module\":\"Trainings\",\"name\":\"view-training\",\"label\":\"View Training\",\"description\":\"Can view training details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":94}},{\"id\":95,\"module\":\"Trainings\",\"name\":\"restore-training\",\"label\":\"Restore Training\",\"description\":\"Can restore deleted trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":95}},{\"id\":96,\"module\":\"Trainings\",\"name\":\"force-delete-training\",\"label\":\"Force Delete Training\",\"description\":\"Can permanently delete trainings\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":96}},{\"id\":97,\"module\":\"Requests\",\"name\":\"create-request-type\",\"label\":\"Create Request Type\",\"description\":\"Can create new request types\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":97}},{\"id\":98,\"module\":\"Requests\",\"name\":\"edit-request-type\",\"label\":\"Edit Request Type\",\"description\":\"Can edit request type records\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":98}},{\"id\":99,\"module\":\"Requests\",\"name\":\"delete-request-type\",\"label\":\"Delete Request Type\",\"description\":\"Can delete request types\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":99}},{\"id\":100,\"module\":\"Requests\",\"name\":\"view-request-type\",\"label\":\"View Request Type\",\"description\":\"Can view request type details\",\"is_active\":1,\"guard_name\":\"web\",\"level\":0,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"pivot\":{\"role_id\":1,\"permission_id\":100}}]}', '2026-01-28 17:22:57'),
(15, 1, 'Super Admin', 'soft-deleted', 'employees', 'EmployeeDesignation', '1', 'Deleted designation for employee EMP0001', '{\"id\":1,\"employee_id\":\"EMP0001\",\"unit_id\":18,\"position_id\":6,\"academic_rank_id\":15,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-28\",\"end_date\":\"2028-06-28\",\"remarks\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-NMLXU', '{\"id\":1,\"employee_id\":\"EMP0001\",\"unit_id\":18,\"position_id\":6,\"academic_rank_id\":15,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-28\",\"end_date\":\"2028-06-28\",\"remarks\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-28\",\"deleted_at\":null}', '2026-01-29 03:01:14'),
(16, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '2', 'Created designation for employee EMP0001: Unit #147, Position #9', NULL, '{\"employee_id\":\"EMP0001\",\"unit_id\":147,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":2,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":2,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-55ICB', '{\"employee_id\":\"EMP0001\",\"unit_id\":147,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":2,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":2,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 03:01:46'),
(17, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '3', 'Created designation for employee EMP0001: Unit #36, Position #22', NULL, '{\"employee_id\":\"EMP0001\",\"unit_id\":36,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":false,\"start_date\":\"2026-01-29\",\"end_date\":null,\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":3,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":2,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-0AQYN', '{\"employee_id\":\"EMP0001\",\"unit_id\":36,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":false,\"start_date\":\"2026-01-29\",\"end_date\":null,\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":3,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":2,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 03:04:49'),
(18, 1, 'Super Admin', 'created', 'trainings', 'Training', '1', 'Created a New Training: asdasd', NULL, '{\"requires_approval\":false,\"training_title\":\"asdasd\",\"date_from\":\"2026-02-03\",\"date_to\":\"2026-03-04\",\"hours\":\"4.00\",\"facilitator\":\"Arvin Negrillo\",\"venue\":\"Canuctan Hall\",\"capacity\":\"23\",\"remarks\":\"xd\",\"request_type_id\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"training_id\":1,\"reference_number\":\"TRG-000001-20260203\",\"id\":1}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'TRG-20260129-8BMEI', '{\"requires_approval\":false,\"training_title\":\"asdasd\",\"date_from\":\"2026-02-03\",\"date_to\":\"2026-03-04\",\"hours\":\"4.00\",\"facilitator\":\"Arvin Negrillo\",\"venue\":\"Canuctan Hall\",\"capacity\":\"23\",\"remarks\":\"xd\",\"request_type_id\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"training_id\":1,\"reference_number\":\"TRG-000001-20260203\",\"id\":1}', '2026-01-29 03:12:42'),
(19, 1, 'Super Admin', 'created', 'employees', 'Employee', 'EMP0003', 'Created a New Employee: Jyl Derwin Sabungan Martires', NULL, '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Non-Teaching\",\"salary\":\"225000.00\",\"date_hired\":\"2026-01-14\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0003\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-QRDT9', '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Non-Teaching\",\"salary\":\"225000.00\",\"date_hired\":\"2026-01-14\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0003\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', '2026-01-29 04:22:15'),
(20, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '4', 'Created designation for employee EMP0003: Unit #1, Position #22', NULL, '{\"employee_id\":\"EMP0003\",\"unit_id\":1,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":4,\"employee\":{\"id\":\"EMP0003\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Non-Teaching\",\"primary_designation_id\":4,\"salary\":\"225000.00\",\"date_hired\":\"2026-01-14\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-ZMMCE', '{\"employee_id\":\"EMP0003\",\"unit_id\":1,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":4,\"employee\":{\"id\":\"EMP0003\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Non-Teaching\",\"primary_designation_id\":4,\"salary\":\"225000.00\",\"date_hired\":\"2026-01-14\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 04:22:53'),
(21, 1, 'Super Admin', 'updated', 'users', 'User', '2', 'Employee Id:  > EMP0003', '{\"employee_id\":null}', '{\"employee_id\":\"EMP0003\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'USR-20260129-0FQ1W', '{\"id\":2,\"name\":\"jr\",\"email\":\"superadmin@example.com\",\"employee_id\":\"EMP0003\",\"email_verified_at\":null,\"two_factor_confirmed_at\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', '2026-01-29 04:28:15'),
(22, 1, 'Super Admin', 'created', 'employees', 'Employee', 'EMP0005', 'Created a New Employee: Jyl Derwin Sabungan Martires', NULL, '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0005\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-NBNRI', '{\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0005\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', '2026-01-29 04:54:05');
INSERT INTO `audit_logs` (`id`, `user_id`, `performed_by`, `action`, `module`, `entity_type`, `entity_id`, `description`, `old_values`, `new_values`, `ip_address`, `user_agent`, `reference_number`, `snapshot`, `created_at`) VALUES
(23, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '5', 'Created designation for employee EMP0005: Unit #1, Position #7', NULL, '{\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":7,\"academic_rank_id\":9,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":5,\"employee\":{\"id\":\"EMP0005\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"primary_designation_id\":5,\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-KH8AV', '{\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":7,\"academic_rank_id\":9,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":5,\"employee\":{\"id\":\"EMP0005\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"primary_designation_id\":5,\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 04:54:51'),
(24, 1, 'Super Admin', 'soft-deleted', 'employees', 'EmployeeDesignation', '5', 'Deleted designation for employee EMP0005', '{\"id\":5,\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":7,\"academic_rank_id\":9,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-3UGTG', '{\"id\":5,\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":7,\"academic_rank_id\":9,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', '2026-01-29 05:06:54'),
(25, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '6', 'Created designation for employee EMP0005: Unit #1, Position #22', NULL, '{\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":22,\"academic_rank_id\":3,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":6,\"employee\":{\"id\":\"EMP0005\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"primary_designation_id\":6,\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-X0YQO', '{\"employee_id\":\"EMP0005\",\"unit_id\":1,\"position_id\":22,\"academic_rank_id\":3,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":6,\"employee\":{\"id\":\"EMP0005\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Probationary\",\"employee_type\":\"Teaching\",\"primary_designation_id\":6,\"salary\":\"20000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":null,\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 05:07:17'),
(26, 1, 'Super Admin', 'created', 'employees', 'Employee', 'EMP0012', 'Created a New Employee: Test Test Test', NULL, '{\"surname\":\"Test\",\"first_name\":\"Test\",\"middle_name\":\"Test\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"salary\":\"12535.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-09\",\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0012\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-XSCJP', '{\"surname\":\"Test\",\"first_name\":\"Test\",\"middle_name\":\"Test\",\"name_extension\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"salary\":\"12535.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-09\",\"start_date\":null,\"end_date\":null,\"height_m\":\"0.71\",\"weight_kg\":\"30\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"id\":\"EMP0012\",\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\"}', '2026-01-29 05:31:26'),
(27, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '7', 'Created designation for employee EMP0012: Unit #8, Position #7', NULL, '{\"employee_id\":\"EMP0012\",\"unit_id\":8,\"position_id\":7,\"academic_rank_id\":4,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":7,\"employee\":{\"id\":\"EMP0012\",\"surname\":\"Test\",\"first_name\":\"Test\",\"middle_name\":\"Test\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"primary_designation_id\":7,\"salary\":\"12535.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-09\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-ZGSGY', '{\"employee_id\":\"EMP0012\",\"unit_id\":8,\"position_id\":7,\"academic_rank_id\":4,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":7,\"employee\":{\"id\":\"EMP0012\",\"surname\":\"Test\",\"first_name\":\"Test\",\"middle_name\":\"Test\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Non-Teaching\",\"primary_designation_id\":7,\"salary\":\"12535.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-09\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Male\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 05:32:40'),
(28, 1, 'Super Admin', 'soft-deleted', 'employees', 'EmployeeDesignation', '2', 'Deleted designation for employee EMP0001', '{\"id\":2,\"employee_id\":\"EMP0001\",\"unit_id\":147,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-W9HOK', '{\"id\":2,\"employee_id\":\"EMP0001\",\"unit_id\":147,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', '2026-01-29 06:41:33'),
(29, 1, 'Super Admin', 'soft-deleted', 'employees', 'EmployeeDesignation', '3', 'Deleted designation for employee EMP0001', '{\"id\":3,\"employee_id\":\"EMP0001\",\"unit_id\":36,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":null,\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', NULL, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-XJHHW', '{\"id\":3,\"employee_id\":\"EMP0001\",\"unit_id\":36,\"position_id\":22,\"academic_rank_id\":1,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":null,\"remarks\":null,\"created_at\":\"2026-01-29\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}', '2026-01-29 06:41:35'),
(30, 1, 'Super Admin', 'created', 'employees', 'EmployeeDesignation', '8', 'Created designation for employee EMP0001: Unit #144, Position #9', NULL, '{\"employee_id\":\"EMP0001\",\"unit_id\":144,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":8,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":8,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'EMP-20260129-YV0CY', '{\"employee_id\":\"EMP0001\",\"unit_id\":144,\"position_id\":9,\"academic_rank_id\":null,\"staff_grade_id\":null,\"is_primary\":true,\"start_date\":\"2026-01-29\",\"end_date\":\"2028-01-29\",\"remarks\":null,\"updated_at\":\"2026-01-29\",\"created_at\":\"2026-01-29\",\"id\":8,\"employee\":{\"id\":\"EMP0001\",\"surname\":\"Martires\",\"first_name\":\"Jyl Derwin\",\"middle_name\":\"Sabungan\",\"name_extension\":null,\"status\":\"active\",\"employment_status\":\"Regular\",\"employee_type\":\"Teaching\",\"primary_designation_id\":8,\"salary\":\"30000.00\",\"date_hired\":\"2026-01-01\",\"date_regularized\":\"2026-01-15\",\"start_date\":null,\"end_date\":null,\"birth_date\":\"2004-07-22\",\"birth_place\":\"Catarman, Northern Samar\",\"sex\":\"Female\",\"civil_status\":\"Single\",\"height_m\":\"0.71\",\"weight_kg\":\"30.00\",\"blood_type\":\"A\",\"gsis_id_no\":\"12345678901\",\"pagibig_id_no\":\"9876-5432-1098\",\"philhealth_no\":\"12-345678901-2\",\"sss_no\":\"34-5678912-3\",\"tin_no\":\"987-654-321\",\"agency_employee_no\":\"2023-001245\",\"citizenship\":\"Filipino\",\"dual_citizenship\":false,\"citizenship_type\":null,\"dual_citizenship_country\":null,\"res_house_no\":\"333\",\"res_street\":\"Real Street\",\"res_subdivision\":\"Santos Village\",\"res_barangay\":\"Songco\",\"res_city\":\"Borongan City\",\"res_province\":\"Eastern Samar\",\"res_zip_code\":\"6800\",\"perm_house_no\":\"33\",\"perm_street\":\"Real Street\",\"perm_subdivision\":\"Santos Village\",\"perm_barangay\":\"Songco\",\"perm_city\":\"Borongan City\",\"perm_province\":\"Eastern Samar\",\"perm_zip_code\":\"6800\",\"telephone_no\":\"09564062855\",\"mobile_no\":\"09564062855\",\"email_address\":\"jymartires@gmail.com\",\"government_issued_id\":\"2134234\",\"id_number\":\"2342455\",\"id_date_issued\":\"2024-09-15\",\"id_place_of_issue\":null,\"indigenous_group\":null,\"pwd_id_no\":null,\"solo_parent_id_no\":null,\"created_at\":\"2026-01-28\",\"updated_at\":\"2026-01-29\",\"deleted_at\":null}}', '2026-01-29 06:42:08');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('essu_hrms_cache_356a192b7913b04c54574d18c28d46e6395428ab', 'i:3;', 1769692116),
('essu_hrms_cache_356a192b7913b04c54574d18c28d46e6395428ab:timer', 'i:1769692116;', 1769692116),
('essu_hrms_cache_5c785c036466adea360111aa28563bfd556b5fba', 'i:1;', 1769699607),
('essu_hrms_cache_5c785c036466adea360111aa28563bfd556b5fba:timer', 'i:1769699607;', 1769699607),
('essu_hrms_cache_arvinnegrillo114@gmail.com|127.0.0.1', 'i:2;', 1769558800),
('essu_hrms_cache_arvinnegrillo114@gmail.com|127.0.0.1:timer', 'i:1769558800;', 1769558800),
('essu_hrms_cache_arvinnegrillo14@gmail.com|127.0.0.1', 'i:2;', 1769558789),
('essu_hrms_cache_arvinnegrillo14@gmail.com|127.0.0.1:timer', 'i:1769558789;', 1769558789),
('essu_hrms_cache_da4b9237bacccdf19c0760cab7aec4a8359010b0', 'i:7;', 1769695752),
('essu_hrms_cache_da4b9237bacccdf19c0760cab7aec4a8359010b0:timer', 'i:1769695752;', 1769695752),
('essu_hrms_cache_spatie.permission.cache', 'a:3:{s:5:\"alias\";a:9:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:6:\"module\";s:1:\"c\";s:4:\"name\";s:1:\"d\";s:5:\"label\";s:1:\"e\";s:11:\"description\";s:1:\"f\";s:9:\"is_active\";s:1:\"g\";s:10:\"guard_name\";s:1:\"h\";s:5:\"level\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:92:{i:0;a:9:{s:1:\"a\";i:1;s:1:\"b\";s:10:\"Audit Logs\";s:1:\"c\";s:15:\"view-audit-logs\";s:1:\"d\";s:15:\"View Audit Logs\";s:1:\"e\";s:46:\"Can view unified audit logs across all modules\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:1;a:9:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"Roles\";s:1:\"c\";s:19:\"access-roles-module\";s:1:\"d\";s:19:\"Access Roles Module\";s:1:\"e\";s:23:\"Can access roles module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:2;a:9:{s:1:\"a\";i:3;s:1:\"b\";s:11:\"Permissions\";s:1:\"c\";s:25:\"access-permissions-module\";s:1:\"d\";s:25:\"Access Permissions Module\";s:1:\"e\";s:29:\"Can access permissions module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:3;a:9:{s:1:\"a\";i:4;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:19:\"access-users-module\";s:1:\"d\";s:19:\"Access Users Module\";s:1:\"e\";s:23:\"Can access users module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:4;a:9:{s:1:\"a\";i:5;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:23:\"access-employees-module\";s:1:\"d\";s:23:\"Access Employees Module\";s:1:\"e\";s:26:\"Can access employee module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;}}i:5;a:9:{s:1:\"a\";i:6;s:1:\"b\";s:8:\"Requests\";s:1:\"c\";s:27:\"access-request-types-module\";s:1:\"d\";s:22:\"Access Requests Module\";s:1:\"e\";s:56:\"Can configure HR request types and fulfillment workflows\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:6;a:9:{s:1:\"a\";i:7;s:1:\"b\";s:6:\"Leaves\";s:1:\"c\";s:21:\"access-leave-calendar\";s:1:\"d\";s:21:\"Access Leave Calendar\";s:1:\"e\";s:65:\"Can view the leave calendar showing all employees\' leave requests\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:5:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;}}i:7;a:9:{s:1:\"a\";i:8;s:1:\"b\";s:6:\"Leaves\";s:1:\"c\";s:21:\"manage-leave-balances\";s:1:\"d\";s:21:\"Manage Leave Balances\";s:1:\"e\";s:81:\"Can set initial balances, grant special leaves, and adjust employee leave credits\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:8;a:9:{s:1:\"a\";i:9;s:1:\"b\";s:5:\"Roles\";s:1:\"c\";s:11:\"create-role\";s:1:\"d\";s:11:\"Create Role\";s:1:\"e\";s:20:\"Can create new roles\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:9;a:9:{s:1:\"a\";i:10;s:1:\"b\";s:5:\"Roles\";s:1:\"c\";s:9:\"edit-role\";s:1:\"d\";s:9:\"Edit Role\";s:1:\"e\";s:25:\"Can modify existing roles\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:10;a:9:{s:1:\"a\";i:11;s:1:\"b\";s:5:\"Roles\";s:1:\"c\";s:11:\"delete-role\";s:1:\"d\";s:11:\"Delete Role\";s:1:\"e\";s:16:\"Can remove roles\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:11;a:9:{s:1:\"a\";i:12;s:1:\"b\";s:5:\"Roles\";s:1:\"c\";s:9:\"view-role\";s:1:\"d\";s:9:\"View Role\";s:1:\"e\";s:21:\"Can view role details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:12;a:9:{s:1:\"a\";i:13;s:1:\"b\";s:11:\"Permissions\";s:1:\"c\";s:17:\"create-permission\";s:1:\"d\";s:17:\"Create Permission\";s:1:\"e\";s:22:\"Can create permissions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:13;a:9:{s:1:\"a\";i:14;s:1:\"b\";s:11:\"Permissions\";s:1:\"c\";s:15:\"edit-permission\";s:1:\"d\";s:15:\"Edit Permission\";s:1:\"e\";s:22:\"Can modify permissions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:14;a:9:{s:1:\"a\";i:15;s:1:\"b\";s:11:\"Permissions\";s:1:\"c\";s:17:\"delete-permission\";s:1:\"d\";s:17:\"Delete Permission\";s:1:\"e\";s:22:\"Can delete permissions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:15;a:9:{s:1:\"a\";i:16;s:1:\"b\";s:11:\"Permissions\";s:1:\"c\";s:15:\"view-permission\";s:1:\"d\";s:15:\"View Permission\";s:1:\"e\";s:20:\"Can view permissions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:16;a:9:{s:1:\"a\";i:17;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:11:\"create-user\";s:1:\"d\";s:11:\"Create User\";s:1:\"e\";s:20:\"Can create new users\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:17;a:9:{s:1:\"a\";i:18;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:9:\"edit-user\";s:1:\"d\";s:9:\"Edit User\";s:1:\"e\";s:24:\"Can modify user accounts\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:18;a:9:{s:1:\"a\";i:19;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:11:\"delete-user\";s:1:\"d\";s:11:\"Delete User\";s:1:\"e\";s:16:\"Can delete users\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:19;a:9:{s:1:\"a\";i:20;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:9:\"view-user\";s:1:\"d\";s:9:\"View User\";s:1:\"e\";s:21:\"Can view user details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:20;a:9:{s:1:\"a\";i:22;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:20:\"view-user-activities\";s:1:\"d\";s:20:\"View User Activities\";s:1:\"e\";s:37:\"Can view user login/logout activities\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:21;a:9:{s:1:\"a\";i:23;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:12:\"restore-user\";s:1:\"d\";s:12:\"Restore User\";s:1:\"e\";s:29:\"Can restore deactivated users\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:22;a:9:{s:1:\"a\";i:24;s:1:\"b\";s:5:\"Users\";s:1:\"c\";s:17:\"force-delete-user\";s:1:\"d\";s:17:\"Force Delete User\";s:1:\"e\";s:28:\"Can permanently delete users\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:23;a:9:{s:1:\"a\";i:25;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:15:\"create-employee\";s:1:\"d\";s:15:\"Create Employee\";s:1:\"e\";s:24:\"Can create new employees\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:24;a:9:{s:1:\"a\";i:26;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:13:\"edit-employee\";s:1:\"d\";s:13:\"Edit Employee\";s:1:\"e\";s:25:\"Can edit employee records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:25;a:9:{s:1:\"a\";i:27;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:15:\"delete-employee\";s:1:\"d\";s:15:\"Delete Employee\";s:1:\"e\";s:27:\"Can delete employee records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:26;a:9:{s:1:\"a\";i:28;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:13:\"view-employee\";s:1:\"d\";s:13:\"View Employee\";s:1:\"e\";s:25:\"Can view employee details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;}}i:27;a:9:{s:1:\"a\";i:29;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:18:\"view-all-employees\";s:1:\"d\";s:18:\"View All Employees\";s:1:\"e\";s:49:\"Can view all employees without scope restrictions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:28;a:9:{s:1:\"a\";i:30;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:22:\"view-faculty-employees\";s:1:\"d\";s:22:\"View Faculty Employees\";s:1:\"e\";s:54:\"Can view employees in their faculty regardless of role\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:29;a:9:{s:1:\"a\";i:31;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:25:\"view-department-employees\";s:1:\"d\";s:25:\"View Department Employees\";s:1:\"e\";s:64:\"Can view employees in their department/office regardless of role\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:30;a:9:{s:1:\"a\";i:33;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:16:\"restore-employee\";s:1:\"d\";s:16:\"Restore Employee\";s:1:\"e\";s:29:\"Can restore deleted employees\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:31;a:9:{s:1:\"a\";i:34;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:21:\"force-delete-employee\";s:1:\"d\";s:21:\"Force Delete Employee\";s:1:\"e\";s:32:\"Can permanently delete employees\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:32;a:9:{s:1:\"a\";i:56;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:15:\"access-position\";s:1:\"d\";s:15:\"Access Position\";s:1:\"e\";s:26:\"Can access position module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:8;}}i:33;a:9:{s:1:\"a\";i:57;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:15:\"create-position\";s:1:\"d\";s:15:\"Create Position\";s:1:\"e\";s:24:\"Can create new positions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:34;a:9:{s:1:\"a\";i:58;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:13:\"edit-position\";s:1:\"d\";s:13:\"Edit Position\";s:1:\"e\";s:25:\"Can edit position records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:35;a:9:{s:1:\"a\";i:59;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:15:\"delete-position\";s:1:\"d\";s:15:\"Delete Position\";s:1:\"e\";s:20:\"Can delete positions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:36;a:9:{s:1:\"a\";i:60;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:13:\"view-position\";s:1:\"d\";s:13:\"View Position\";s:1:\"e\";s:25:\"Can view position details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:8;}}i:37;a:9:{s:1:\"a\";i:61;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:16:\"restore-position\";s:1:\"d\";s:16:\"Restore Position\";s:1:\"e\";s:29:\"Can restore deleted positions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:38;a:9:{s:1:\"a\";i:62;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:21:\"force-delete-position\";s:1:\"d\";s:21:\"Force Delete Position\";s:1:\"e\";s:32:\"Can permanently delete positions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:39;a:9:{s:1:\"a\";i:63;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:13:\"access-sector\";s:1:\"d\";s:13:\"Access Sector\";s:1:\"e\";s:24:\"Can access sector module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:7:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;i:6;i:8;}}i:40;a:9:{s:1:\"a\";i:64;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:13:\"create-sector\";s:1:\"d\";s:13:\"Create Sector\";s:1:\"e\";s:22:\"Can create new sectors\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:41;a:9:{s:1:\"a\";i:65;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:11:\"edit-sector\";s:1:\"d\";s:11:\"Edit Sector\";s:1:\"e\";s:23:\"Can edit sector records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:42;a:9:{s:1:\"a\";i:66;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:13:\"delete-sector\";s:1:\"d\";s:13:\"Delete Sector\";s:1:\"e\";s:18:\"Can delete sectors\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:43;a:9:{s:1:\"a\";i:67;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:11:\"view-sector\";s:1:\"d\";s:11:\"View Sector\";s:1:\"e\";s:23:\"Can view sector details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:7:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;i:6;i:8;}}i:44;a:9:{s:1:\"a\";i:68;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:14:\"restore-sector\";s:1:\"d\";s:14:\"Restore Sector\";s:1:\"e\";s:27:\"Can restore deleted sectors\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:45;a:9:{s:1:\"a\";i:69;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:19:\"force-delete-sector\";s:1:\"d\";s:19:\"Force Delete Sector\";s:1:\"e\";s:30:\"Can permanently delete sectors\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:46;a:9:{s:1:\"a\";i:70;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:11:\"access-unit\";s:1:\"d\";s:11:\"Access Unit\";s:1:\"e\";s:22:\"Can access unit module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:7:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;i:6;i:8;}}i:47;a:9:{s:1:\"a\";i:71;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:11:\"create-unit\";s:1:\"d\";s:11:\"Create Unit\";s:1:\"e\";s:20:\"Can create new units\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:48;a:9:{s:1:\"a\";i:72;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:9:\"edit-unit\";s:1:\"d\";s:9:\"Edit Unit\";s:1:\"e\";s:21:\"Can edit unit records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:49;a:9:{s:1:\"a\";i:73;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:11:\"delete-unit\";s:1:\"d\";s:11:\"Delete Unit\";s:1:\"e\";s:16:\"Can delete units\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:50;a:9:{s:1:\"a\";i:74;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:9:\"view-unit\";s:1:\"d\";s:9:\"View Unit\";s:1:\"e\";s:21:\"Can view unit details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:7:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;i:6;i:8;}}i:51;a:9:{s:1:\"a\";i:75;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:12:\"restore-unit\";s:1:\"d\";s:12:\"Restore Unit\";s:1:\"e\";s:25:\"Can restore deleted units\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:52;a:9:{s:1:\"a\";i:76;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:17:\"force-delete-unit\";s:1:\"d\";s:17:\"Force Delete Unit\";s:1:\"e\";s:28:\"Can permanently delete units\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:53;a:9:{s:1:\"a\";i:77;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"access-unit-position\";s:1:\"d\";s:30:\"Access Unit-Position Whitelist\";s:1:\"e\";s:41:\"Can access unit-position whitelist module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:54;a:9:{s:1:\"a\";i:78;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"create-unit-position\";s:1:\"d\";s:30:\"Create Unit-Position Whitelist\";s:1:\"e\";s:35:\"Can add positions to unit whitelist\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:55;a:9:{s:1:\"a\";i:79;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"edit-unit-position\";s:1:\"d\";s:28:\"Edit Unit-Position Whitelist\";s:1:\"e\";s:32:\"Can edit unit-position whitelist\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:56;a:9:{s:1:\"a\";i:80;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"delete-unit-position\";s:1:\"d\";s:30:\"Delete Unit-Position Whitelist\";s:1:\"e\";s:42:\"Can delete unit-position whitelist entries\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:57;a:9:{s:1:\"a\";i:81;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"view-unit-position\";s:1:\"d\";s:28:\"View Unit-Position Whitelist\";s:1:\"e\";s:32:\"Can view unit-position whitelist\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:58;a:9:{s:1:\"a\";i:82;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:21:\"restore-unit-position\";s:1:\"d\";s:31:\"Restore Unit-Position Whitelist\";s:1:\"e\";s:51:\"Can restore deleted unit-position whitelist entries\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:59;a:9:{s:1:\"a\";i:83;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:26:\"force-delete-unit-position\";s:1:\"d\";s:36:\"Force Delete Unit-Position Whitelist\";s:1:\"e\";s:54:\"Can permanently delete unit-position whitelist entries\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:60;a:9:{s:1:\"a\";i:84;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:16:\"promote-employee\";s:1:\"d\";s:16:\"Promote Employee\";s:1:\"e\";s:30:\"Can record employee promotions\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:61;a:9:{s:1:\"a\";i:85;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:24:\"view-employee-promotions\";s:1:\"d\";s:24:\"View Employee Promotions\";s:1:\"e\";s:35:\"Can view employee promotion history\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:5:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;}}i:62;a:9:{s:1:\"a\";i:86;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:13:\"promote-grade\";s:1:\"d\";s:18:\"Promote Grade/Rank\";s:1:\"e\";s:52:\"Can promote employee grade/rank (upward progression)\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:63;a:9:{s:1:\"a\";i:87;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:13:\"correct-grade\";s:1:\"d\";s:18:\"Correct Grade/Rank\";s:1:\"e\";s:52:\"Can correct/adjust employee grade/rank (with reason)\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:64;a:9:{s:1:\"a\";i:88;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:18:\"view-grade-history\";s:1:\"d\";s:18:\"View Grade History\";s:1:\"e\";s:43:\"Can view employee grade/rank change history\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:5:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;}}i:65;a:9:{s:1:\"a\";i:90;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:23:\"access-trainings-module\";s:1:\"d\";s:23:\"Access Trainings Module\";s:1:\"e\";s:27:\"Can access trainings module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;}}i:66;a:9:{s:1:\"a\";i:91;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:15:\"create-training\";s:1:\"d\";s:15:\"Create Training\";s:1:\"e\";s:24:\"Can create new trainings\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:5:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:7;}}i:67;a:9:{s:1:\"a\";i:92;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:13:\"edit-training\";s:1:\"d\";s:13:\"Edit Training\";s:1:\"e\";s:25:\"Can edit training records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:5:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:7;}}i:68;a:9:{s:1:\"a\";i:93;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:15:\"delete-training\";s:1:\"d\";s:15:\"Delete Training\";s:1:\"e\";s:20:\"Can delete trainings\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:7;}}i:69;a:9:{s:1:\"a\";i:94;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:13:\"view-training\";s:1:\"d\";s:13:\"View Training\";s:1:\"e\";s:25:\"Can view training details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:6:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;i:4;i:6;i:5;i:7;}}i:70;a:9:{s:1:\"a\";i:95;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:16:\"restore-training\";s:1:\"d\";s:16:\"Restore Training\";s:1:\"e\";s:29:\"Can restore deleted trainings\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:7;}}i:71;a:9:{s:1:\"a\";i:96;s:1:\"b\";s:9:\"Trainings\";s:1:\"c\";s:21:\"force-delete-training\";s:1:\"d\";s:21:\"Force Delete Training\";s:1:\"e\";s:32:\"Can permanently delete trainings\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:72;a:9:{s:1:\"a\";i:97;s:1:\"b\";s:8:\"Requests\";s:1:\"c\";s:19:\"create-request-type\";s:1:\"d\";s:19:\"Create Request Type\";s:1:\"e\";s:28:\"Can create new request types\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:73;a:9:{s:1:\"a\";i:98;s:1:\"b\";s:8:\"Requests\";s:1:\"c\";s:17:\"edit-request-type\";s:1:\"d\";s:17:\"Edit Request Type\";s:1:\"e\";s:29:\"Can edit request type records\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:74;a:9:{s:1:\"a\";i:99;s:1:\"b\";s:8:\"Requests\";s:1:\"c\";s:19:\"delete-request-type\";s:1:\"d\";s:19:\"Delete Request Type\";s:1:\"e\";s:24:\"Can delete request types\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:4;}}i:75;a:9:{s:1:\"a\";i:100;s:1:\"b\";s:8:\"Requests\";s:1:\"c\";s:17:\"view-request-type\";s:1:\"d\";s:17:\"View Request Type\";s:1:\"e\";s:29:\"Can view request type details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:1;i:1;i:3;i:2;i:4;i:3;i:5;}}i:76;a:9:{s:1:\"a\";i:101;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:21:\"view-sector-employees\";s:1:\"d\";s:21:\"View Sector Employees\";s:1:\"e\";s:34:\"Can view employees in their sector\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:1:{i:0;i:3;}}i:77;a:9:{s:1:\"a\";i:102;s:1:\"b\";s:9:\"Employees\";s:1:\"c\";s:19:\"view-unit-employees\";s:1:\"d\";s:19:\"View Unit Employees\";s:1:\"e\";s:32:\"Can view employees in their unit\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:3:{i:0;i:3;i:1;i:6;i:2;i:7;}}i:78;a:9:{s:1:\"a\";i:103;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"access-academic-rank\";s:1:\"d\";s:21:\"Access Academic Ranks\";s:1:\"e\";s:32:\"Can access academic ranks module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:3;i:1;i:4;i:2;i:5;i:3;i:6;}}i:79;a:9:{s:1:\"a\";i:104;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"create-academic-rank\";s:1:\"d\";s:20:\"Create Academic Rank\";s:1:\"e\";s:25:\"Can create academic ranks\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:80;a:9:{s:1:\"a\";i:105;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"edit-academic-rank\";s:1:\"d\";s:18:\"Edit Academic Rank\";s:1:\"e\";s:23:\"Can edit academic ranks\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:81;a:9:{s:1:\"a\";i:106;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:20:\"delete-academic-rank\";s:1:\"d\";s:20:\"Delete Academic Rank\";s:1:\"e\";s:25:\"Can delete academic ranks\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:82;a:9:{s:1:\"a\";i:107;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"view-academic-rank\";s:1:\"d\";s:18:\"View Academic Rank\";s:1:\"e\";s:30:\"Can view academic rank details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:3;i:1;i:4;i:2;i:5;i:3;i:6;}}i:83;a:9:{s:1:\"a\";i:108;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:21:\"restore-academic-rank\";s:1:\"d\";s:21:\"Restore Academic Rank\";s:1:\"e\";s:34:\"Can restore deleted academic ranks\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:84;a:9:{s:1:\"a\";i:109;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:26:\"force-delete-academic-rank\";s:1:\"d\";s:26:\"Force Delete Academic Rank\";s:1:\"e\";s:37:\"Can permanently delete academic ranks\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:85;a:9:{s:1:\"a\";i:110;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"access-staff-grade\";s:1:\"d\";s:19:\"Access Staff Grades\";s:1:\"e\";s:30:\"Can access staff grades module\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:3;i:1;i:4;i:2;i:5;i:3;i:6;}}i:86;a:9:{s:1:\"a\";i:111;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"create-staff-grade\";s:1:\"d\";s:18:\"Create Staff Grade\";s:1:\"e\";s:23:\"Can create staff grades\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:87;a:9:{s:1:\"a\";i:112;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:16:\"edit-staff-grade\";s:1:\"d\";s:16:\"Edit Staff Grade\";s:1:\"e\";s:21:\"Can edit staff grades\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:88;a:9:{s:1:\"a\";i:113;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:18:\"delete-staff-grade\";s:1:\"d\";s:18:\"Delete Staff Grade\";s:1:\"e\";s:23:\"Can delete staff grades\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:89;a:9:{s:1:\"a\";i:114;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:16:\"view-staff-grade\";s:1:\"d\";s:16:\"View Staff Grade\";s:1:\"e\";s:28:\"Can view staff grade details\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:4:{i:0;i:3;i:1;i:4;i:2;i:5;i:3;i:6;}}i:90;a:9:{s:1:\"a\";i:115;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:19:\"restore-staff-grade\";s:1:\"d\";s:19:\"Restore Staff Grade\";s:1:\"e\";s:32:\"Can restore deleted staff grades\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}i:91;a:9:{s:1:\"a\";i:116;s:1:\"b\";s:24:\"Organizational Structure\";s:1:\"c\";s:24:\"force-delete-staff-grade\";s:1:\"d\";s:24:\"Force Delete Staff Grade\";s:1:\"e\";s:35:\"Can permanently delete staff grades\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";s:1:\"h\";i:0;s:1:\"r\";a:2:{i:0;i:3;i:1;i:4;}}}s:5:\"roles\";a:7:{i:0;a:6:{s:1:\"a\";i:1;s:1:\"c\";s:13:\"administrator\";s:1:\"d\";s:13:\"Administrator\";s:1:\"e\";s:20:\"system administrator\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:1;a:6:{s:1:\"a\";i:3;s:1:\"c\";s:11:\"super-admin\";s:1:\"d\";s:11:\"Super Admin\";s:1:\"e\";s:38:\"Full system access. Cannot be removed.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:2;a:6:{s:1:\"a\";i:4;s:1:\"c\";s:11:\"hr-director\";s:1:\"d\";s:11:\"HR Director\";s:1:\"e\";s:124:\"Full HR management including employees, org structure, trainings, and audit logs. Assign to HRMO Director, CAO, or VP Admin.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:3;a:6:{s:1:\"a\";i:5;s:1:\"c\";s:8:\"hr-staff\";s:1:\"d\";s:8:\"HR Staff\";s:1:\"e\";s:111:\"Day-to-day HR operations including employee records and trainings. Assign to Admin Officers/Assistants in HRMO.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:4;a:6:{s:1:\"a\";i:6;s:1:\"c\";s:9:\"unit-head\";s:1:\"d\";s:9:\"Unit Head\";s:1:\"e\";s:97:\"View employees within their unit and training records. Assign to Deans, Directors, Program Heads.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:5;a:6:{s:1:\"a\";i:7;s:1:\"c\";s:20:\"training-coordinator\";s:1:\"d\";s:20:\"Training Coordinator\";s:1:\"e\";s:87:\"Manage training records and view employees. Assign to designated training coordinators.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}i:6;a:6:{s:1:\"a\";i:8;s:1:\"c\";s:14:\"basic-employee\";s:1:\"d\";s:14:\"Basic Employee\";s:1:\"e\";s:57:\"Self-service access only. Default role for all employees.\";s:1:\"f\";i:1;s:1:\"g\";s:3:\"web\";}}}', 1769737084),
('essu_hrms_cache_user_permissions_1_1769559293_roles_1', 'a:100:{i:0;s:15:\"view-audit-logs\";i:1;s:19:\"access-roles-module\";i:2;s:25:\"access-permissions-module\";i:3;s:19:\"access-users-module\";i:4;s:23:\"access-employees-module\";i:5;s:27:\"access-request-types-module\";i:6;s:21:\"access-leave-calendar\";i:7;s:21:\"manage-leave-balances\";i:8;s:11:\"create-role\";i:9;s:9:\"edit-role\";i:10;s:11:\"delete-role\";i:11;s:9:\"view-role\";i:12;s:17:\"create-permission\";i:13;s:15:\"edit-permission\";i:14;s:17:\"delete-permission\";i:15;s:15:\"view-permission\";i:16;s:11:\"create-user\";i:17;s:9:\"edit-user\";i:18;s:11:\"delete-user\";i:19;s:9:\"view-user\";i:20;s:13:\"view-user-log\";i:21;s:20:\"view-user-activities\";i:22;s:12:\"restore-user\";i:23;s:17:\"force-delete-user\";i:24;s:15:\"create-employee\";i:25;s:13:\"edit-employee\";i:26;s:15:\"delete-employee\";i:27;s:13:\"view-employee\";i:28;s:18:\"view-all-employees\";i:29;s:22:\"view-faculty-employees\";i:30;s:25:\"view-department-employees\";i:31;s:17:\"view-employee-log\";i:32;s:16:\"restore-employee\";i:33;s:21:\"force-delete-employee\";i:34;s:14:\"access-faculty\";i:35;s:14:\"create-faculty\";i:36;s:12:\"edit-faculty\";i:37;s:14:\"delete-faculty\";i:38;s:12:\"view-faculty\";i:39;s:15:\"restore-faculty\";i:40;s:20:\"force-delete-faculty\";i:41;s:17:\"access-department\";i:42;s:17:\"create-department\";i:43;s:15:\"edit-department\";i:44;s:17:\"delete-department\";i:45;s:15:\"view-department\";i:46;s:18:\"restore-department\";i:47;s:23:\"force-delete-department\";i:48;s:13:\"access-office\";i:49;s:13:\"create-office\";i:50;s:11:\"edit-office\";i:51;s:13:\"delete-office\";i:52;s:11:\"view-office\";i:53;s:14:\"restore-office\";i:54;s:19:\"force-delete-office\";i:55;s:15:\"access-position\";i:56;s:15:\"create-position\";i:57;s:13:\"edit-position\";i:58;s:15:\"delete-position\";i:59;s:13:\"view-position\";i:60;s:16:\"restore-position\";i:61;s:21:\"force-delete-position\";i:62;s:13:\"access-sector\";i:63;s:13:\"create-sector\";i:64;s:11:\"edit-sector\";i:65;s:13:\"delete-sector\";i:66;s:11:\"view-sector\";i:67;s:14:\"restore-sector\";i:68;s:19:\"force-delete-sector\";i:69;s:11:\"access-unit\";i:70;s:11:\"create-unit\";i:71;s:9:\"edit-unit\";i:72;s:11:\"delete-unit\";i:73;s:9:\"view-unit\";i:74;s:12:\"restore-unit\";i:75;s:17:\"force-delete-unit\";i:76;s:20:\"access-unit-position\";i:77;s:20:\"create-unit-position\";i:78;s:18:\"edit-unit-position\";i:79;s:20:\"delete-unit-position\";i:80;s:18:\"view-unit-position\";i:81;s:21:\"restore-unit-position\";i:82;s:26:\"force-delete-unit-position\";i:83;s:16:\"promote-employee\";i:84;s:24:\"view-employee-promotions\";i:85;s:13:\"promote-grade\";i:86;s:13:\"correct-grade\";i:87;s:18:\"view-grade-history\";i:88;s:23:\"view-organizational-log\";i:89;s:23:\"access-trainings-module\";i:90;s:15:\"create-training\";i:91;s:13:\"edit-training\";i:92;s:15:\"delete-training\";i:93;s:13:\"view-training\";i:94;s:16:\"restore-training\";i:95;s:21:\"force-delete-training\";i:96;s:19:\"create-request-type\";i:97;s:17:\"edit-request-type\";i:98;s:19:\"delete-request-type\";i:99;s:17:\"view-request-type\";}', 1769601522),
('essu_hrms_cache_user_permissions_1_1769601250_roles_1', 'a:100:{i:0;s:15:\"view-audit-logs\";i:1;s:19:\"access-roles-module\";i:2;s:25:\"access-permissions-module\";i:3;s:19:\"access-users-module\";i:4;s:23:\"access-employees-module\";i:5;s:27:\"access-request-types-module\";i:6;s:21:\"access-leave-calendar\";i:7;s:21:\"manage-leave-balances\";i:8;s:11:\"create-role\";i:9;s:9:\"edit-role\";i:10;s:11:\"delete-role\";i:11;s:9:\"view-role\";i:12;s:17:\"create-permission\";i:13;s:15:\"edit-permission\";i:14;s:17:\"delete-permission\";i:15;s:15:\"view-permission\";i:16;s:11:\"create-user\";i:17;s:9:\"edit-user\";i:18;s:11:\"delete-user\";i:19;s:9:\"view-user\";i:20;s:13:\"view-user-log\";i:21;s:20:\"view-user-activities\";i:22;s:12:\"restore-user\";i:23;s:17:\"force-delete-user\";i:24;s:15:\"create-employee\";i:25;s:13:\"edit-employee\";i:26;s:15:\"delete-employee\";i:27;s:13:\"view-employee\";i:28;s:18:\"view-all-employees\";i:29;s:22:\"view-faculty-employees\";i:30;s:25:\"view-department-employees\";i:31;s:17:\"view-employee-log\";i:32;s:16:\"restore-employee\";i:33;s:21:\"force-delete-employee\";i:34;s:14:\"access-faculty\";i:35;s:14:\"create-faculty\";i:36;s:12:\"edit-faculty\";i:37;s:14:\"delete-faculty\";i:38;s:12:\"view-faculty\";i:39;s:15:\"restore-faculty\";i:40;s:20:\"force-delete-faculty\";i:41;s:17:\"access-department\";i:42;s:17:\"create-department\";i:43;s:15:\"edit-department\";i:44;s:17:\"delete-department\";i:45;s:15:\"view-department\";i:46;s:18:\"restore-department\";i:47;s:23:\"force-delete-department\";i:48;s:13:\"access-office\";i:49;s:13:\"create-office\";i:50;s:11:\"edit-office\";i:51;s:13:\"delete-office\";i:52;s:11:\"view-office\";i:53;s:14:\"restore-office\";i:54;s:19:\"force-delete-office\";i:55;s:15:\"access-position\";i:56;s:15:\"create-position\";i:57;s:13:\"edit-position\";i:58;s:15:\"delete-position\";i:59;s:13:\"view-position\";i:60;s:16:\"restore-position\";i:61;s:21:\"force-delete-position\";i:62;s:13:\"access-sector\";i:63;s:13:\"create-sector\";i:64;s:11:\"edit-sector\";i:65;s:13:\"delete-sector\";i:66;s:11:\"view-sector\";i:67;s:14:\"restore-sector\";i:68;s:19:\"force-delete-sector\";i:69;s:11:\"access-unit\";i:70;s:11:\"create-unit\";i:71;s:9:\"edit-unit\";i:72;s:11:\"delete-unit\";i:73;s:9:\"view-unit\";i:74;s:12:\"restore-unit\";i:75;s:17:\"force-delete-unit\";i:76;s:20:\"access-unit-position\";i:77;s:20:\"create-unit-position\";i:78;s:18:\"edit-unit-position\";i:79;s:20:\"delete-unit-position\";i:80;s:18:\"view-unit-position\";i:81;s:21:\"restore-unit-position\";i:82;s:26:\"force-delete-unit-position\";i:83;s:16:\"promote-employee\";i:84;s:24:\"view-employee-promotions\";i:85;s:13:\"promote-grade\";i:86;s:13:\"correct-grade\";i:87;s:18:\"view-grade-history\";i:88;s:23:\"view-organizational-log\";i:89;s:23:\"access-trainings-module\";i:90;s:15:\"create-training\";i:91;s:13:\"edit-training\";i:92;s:15:\"delete-training\";i:93;s:13:\"view-training\";i:94;s:16:\"restore-training\";i:95;s:21:\"force-delete-training\";i:96;s:19:\"create-request-type\";i:97;s:17:\"edit-request-type\";i:98;s:19:\"delete-request-type\";i:99;s:17:\"view-request-type\";}', 1769611744),
('essu_hrms_cache_user_permissions_1_1769601250_roles_1,2', 'a:116:{i:0;s:17:\"access-department\";i:1;s:23:\"access-employees-module\";i:2;s:14:\"access-faculty\";i:3;s:21:\"access-leave-calendar\";i:4;s:13:\"access-office\";i:5;s:25:\"access-permissions-module\";i:6;s:15:\"access-position\";i:7;s:27:\"access-request-types-module\";i:8;s:19:\"access-roles-module\";i:9;s:13:\"access-sector\";i:10;s:23:\"access-trainings-module\";i:11;s:11:\"access-unit\";i:12;s:20:\"access-unit-position\";i:13;s:19:\"access-users-module\";i:14;s:13:\"correct-grade\";i:15;s:17:\"create-department\";i:16;s:15:\"create-employee\";i:17;s:14:\"create-faculty\";i:18;s:13:\"create-office\";i:19;s:17:\"create-permission\";i:20;s:15:\"create-position\";i:21;s:19:\"create-request-type\";i:22;s:11:\"create-role\";i:23;s:13:\"create-sector\";i:24;s:15:\"create-training\";i:25;s:11:\"create-unit\";i:26;s:20:\"create-unit-position\";i:27;s:11:\"create-user\";i:28;s:17:\"delete-department\";i:29;s:15:\"delete-employee\";i:30;s:14:\"delete-faculty\";i:31;s:13:\"delete-office\";i:32;s:17:\"delete-permission\";i:33;s:15:\"delete-position\";i:34;s:19:\"delete-request-type\";i:35;s:11:\"delete-role\";i:36;s:13:\"delete-sector\";i:37;s:15:\"delete-training\";i:38;s:11:\"delete-unit\";i:39;s:20:\"delete-unit-position\";i:40;s:11:\"delete-user\";i:41;s:15:\"edit-department\";i:42;s:13:\"edit-employee\";i:43;s:12:\"edit-faculty\";i:44;s:11:\"edit-office\";i:45;s:15:\"edit-permission\";i:46;s:13:\"edit-position\";i:47;s:17:\"edit-request-type\";i:48;s:9:\"edit-role\";i:49;s:11:\"edit-sector\";i:50;s:13:\"edit-training\";i:51;s:9:\"edit-unit\";i:52;s:18:\"edit-unit-position\";i:53;s:9:\"edit-user\";i:54;s:23:\"force-delete-department\";i:55;s:21:\"force-delete-employee\";i:56;s:20:\"force-delete-faculty\";i:57;s:19:\"force-delete-office\";i:58;s:21:\"force-delete-position\";i:59;s:19:\"force-delete-sector\";i:60;s:21:\"force-delete-training\";i:61;s:17:\"force-delete-unit\";i:62;s:26:\"force-delete-unit-position\";i:63;s:17:\"force-delete-user\";i:64;s:21:\"manage-leave-balances\";i:65;s:16:\"promote-employee\";i:66;s:13:\"promote-grade\";i:67;s:18:\"restore-department\";i:68;s:16:\"restore-employee\";i:69;s:15:\"restore-faculty\";i:70;s:14:\"restore-office\";i:71;s:16:\"restore-position\";i:72;s:14:\"restore-sector\";i:73;s:16:\"restore-training\";i:74;s:12:\"restore-unit\";i:75;s:21:\"restore-unit-position\";i:76;s:12:\"restore-user\";i:77;s:18:\"view-all-employees\";i:78;s:15:\"view-audit-logs\";i:79;s:15:\"view-department\";i:80;s:25:\"view-department-employees\";i:81;s:13:\"view-employee\";i:82;s:17:\"view-employee-log\";i:83;s:24:\"view-employee-promotions\";i:84;s:12:\"view-faculty\";i:85;s:22:\"view-faculty-employees\";i:86;s:18:\"view-grade-history\";i:87;s:11:\"view-office\";i:88;s:23:\"view-organizational-log\";i:89;s:15:\"view-permission\";i:90;s:13:\"view-position\";i:91;s:17:\"view-request-type\";i:92;s:9:\"view-role\";i:93;s:11:\"view-sector\";i:94;s:13:\"view-training\";i:95;s:9:\"view-unit\";i:96;s:18:\"view-unit-position\";i:97;s:9:\"view-user\";i:98;s:20:\"view-user-activities\";i:99;s:13:\"view-user-log\";i:100;s:20:\"access-academic-rank\";i:101;s:18:\"access-staff-grade\";i:102;s:20:\"create-academic-rank\";i:103;s:18:\"create-staff-grade\";i:104;s:20:\"delete-academic-rank\";i:105;s:18:\"delete-staff-grade\";i:106;s:18:\"edit-academic-rank\";i:107;s:16:\"edit-staff-grade\";i:108;s:26:\"force-delete-academic-rank\";i:109;s:24:\"force-delete-staff-grade\";i:110;s:21:\"restore-academic-rank\";i:111;s:19:\"restore-staff-grade\";i:112;s:18:\"view-academic-rank\";i:113;s:21:\"view-sector-employees\";i:114;s:16:\"view-staff-grade\";i:115;s:19:\"view-unit-employees\";}', 1769649793),
('essu_hrms_cache_user_permissions_1_1769649777_roles_1,3', 'a:92:{i:0;s:23:\"access-employees-module\";i:1;s:21:\"access-leave-calendar\";i:2;s:25:\"access-permissions-module\";i:3;s:15:\"access-position\";i:4;s:27:\"access-request-types-module\";i:5;s:19:\"access-roles-module\";i:6;s:13:\"access-sector\";i:7;s:23:\"access-trainings-module\";i:8;s:11:\"access-unit\";i:9;s:20:\"access-unit-position\";i:10;s:19:\"access-users-module\";i:11;s:13:\"correct-grade\";i:12;s:15:\"create-employee\";i:13;s:17:\"create-permission\";i:14;s:15:\"create-position\";i:15;s:19:\"create-request-type\";i:16;s:11:\"create-role\";i:17;s:13:\"create-sector\";i:18;s:15:\"create-training\";i:19;s:11:\"create-unit\";i:20;s:20:\"create-unit-position\";i:21;s:11:\"create-user\";i:22;s:15:\"delete-employee\";i:23;s:17:\"delete-permission\";i:24;s:15:\"delete-position\";i:25;s:19:\"delete-request-type\";i:26;s:11:\"delete-role\";i:27;s:13:\"delete-sector\";i:28;s:15:\"delete-training\";i:29;s:11:\"delete-unit\";i:30;s:20:\"delete-unit-position\";i:31;s:11:\"delete-user\";i:32;s:13:\"edit-employee\";i:33;s:15:\"edit-permission\";i:34;s:13:\"edit-position\";i:35;s:17:\"edit-request-type\";i:36;s:9:\"edit-role\";i:37;s:11:\"edit-sector\";i:38;s:13:\"edit-training\";i:39;s:9:\"edit-unit\";i:40;s:18:\"edit-unit-position\";i:41;s:9:\"edit-user\";i:42;s:21:\"force-delete-employee\";i:43;s:21:\"force-delete-position\";i:44;s:19:\"force-delete-sector\";i:45;s:21:\"force-delete-training\";i:46;s:17:\"force-delete-unit\";i:47;s:26:\"force-delete-unit-position\";i:48;s:17:\"force-delete-user\";i:49;s:21:\"manage-leave-balances\";i:50;s:16:\"promote-employee\";i:51;s:13:\"promote-grade\";i:52;s:16:\"restore-employee\";i:53;s:16:\"restore-position\";i:54;s:14:\"restore-sector\";i:55;s:16:\"restore-training\";i:56;s:12:\"restore-unit\";i:57;s:21:\"restore-unit-position\";i:58;s:12:\"restore-user\";i:59;s:18:\"view-all-employees\";i:60;s:15:\"view-audit-logs\";i:61;s:25:\"view-department-employees\";i:62;s:13:\"view-employee\";i:63;s:24:\"view-employee-promotions\";i:64;s:22:\"view-faculty-employees\";i:65;s:18:\"view-grade-history\";i:66;s:15:\"view-permission\";i:67;s:13:\"view-position\";i:68;s:17:\"view-request-type\";i:69;s:9:\"view-role\";i:70;s:11:\"view-sector\";i:71;s:13:\"view-training\";i:72;s:9:\"view-unit\";i:73;s:18:\"view-unit-position\";i:74;s:9:\"view-user\";i:75;s:20:\"view-user-activities\";i:76;s:20:\"access-academic-rank\";i:77;s:18:\"access-staff-grade\";i:78;s:20:\"create-academic-rank\";i:79;s:18:\"create-staff-grade\";i:80;s:20:\"delete-academic-rank\";i:81;s:18:\"delete-staff-grade\";i:82;s:18:\"edit-academic-rank\";i:83;s:16:\"edit-staff-grade\";i:84;s:26:\"force-delete-academic-rank\";i:85;s:24:\"force-delete-staff-grade\";i:86;s:21:\"restore-academic-rank\";i:87;s:19:\"restore-staff-grade\";i:88;s:18:\"view-academic-rank\";i:89;s:21:\"view-sector-employees\";i:90;s:16:\"view-staff-grade\";i:91;s:19:\"view-unit-employees\";}', 1769653043),
('essu_hrms_cache_user_permissions_1_1769652767_roles_1,3', 'a:92:{i:0;s:23:\"access-employees-module\";i:1;s:21:\"access-leave-calendar\";i:2;s:25:\"access-permissions-module\";i:3;s:15:\"access-position\";i:4;s:27:\"access-request-types-module\";i:5;s:19:\"access-roles-module\";i:6;s:13:\"access-sector\";i:7;s:23:\"access-trainings-module\";i:8;s:11:\"access-unit\";i:9;s:20:\"access-unit-position\";i:10;s:19:\"access-users-module\";i:11;s:13:\"correct-grade\";i:12;s:15:\"create-employee\";i:13;s:17:\"create-permission\";i:14;s:15:\"create-position\";i:15;s:19:\"create-request-type\";i:16;s:11:\"create-role\";i:17;s:13:\"create-sector\";i:18;s:15:\"create-training\";i:19;s:11:\"create-unit\";i:20;s:20:\"create-unit-position\";i:21;s:11:\"create-user\";i:22;s:15:\"delete-employee\";i:23;s:17:\"delete-permission\";i:24;s:15:\"delete-position\";i:25;s:19:\"delete-request-type\";i:26;s:11:\"delete-role\";i:27;s:13:\"delete-sector\";i:28;s:15:\"delete-training\";i:29;s:11:\"delete-unit\";i:30;s:20:\"delete-unit-position\";i:31;s:11:\"delete-user\";i:32;s:13:\"edit-employee\";i:33;s:15:\"edit-permission\";i:34;s:13:\"edit-position\";i:35;s:17:\"edit-request-type\";i:36;s:9:\"edit-role\";i:37;s:11:\"edit-sector\";i:38;s:13:\"edit-training\";i:39;s:9:\"edit-unit\";i:40;s:18:\"edit-unit-position\";i:41;s:9:\"edit-user\";i:42;s:21:\"force-delete-employee\";i:43;s:21:\"force-delete-position\";i:44;s:19:\"force-delete-sector\";i:45;s:21:\"force-delete-training\";i:46;s:17:\"force-delete-unit\";i:47;s:26:\"force-delete-unit-position\";i:48;s:17:\"force-delete-user\";i:49;s:21:\"manage-leave-balances\";i:50;s:16:\"promote-employee\";i:51;s:13:\"promote-grade\";i:52;s:16:\"restore-employee\";i:53;s:16:\"restore-position\";i:54;s:14:\"restore-sector\";i:55;s:16:\"restore-training\";i:56;s:12:\"restore-unit\";i:57;s:21:\"restore-unit-position\";i:58;s:12:\"restore-user\";i:59;s:18:\"view-all-employees\";i:60;s:15:\"view-audit-logs\";i:61;s:25:\"view-department-employees\";i:62;s:13:\"view-employee\";i:63;s:24:\"view-employee-promotions\";i:64;s:22:\"view-faculty-employees\";i:65;s:18:\"view-grade-history\";i:66;s:15:\"view-permission\";i:67;s:13:\"view-position\";i:68;s:17:\"view-request-type\";i:69;s:9:\"view-role\";i:70;s:11:\"view-sector\";i:71;s:13:\"view-training\";i:72;s:9:\"view-unit\";i:73;s:18:\"view-unit-position\";i:74;s:9:\"view-user\";i:75;s:20:\"view-user-activities\";i:76;s:20:\"access-academic-rank\";i:77;s:18:\"access-staff-grade\";i:78;s:20:\"create-academic-rank\";i:79;s:18:\"create-staff-grade\";i:80;s:20:\"delete-academic-rank\";i:81;s:18:\"delete-staff-grade\";i:82;s:18:\"edit-academic-rank\";i:83;s:16:\"edit-staff-grade\";i:84;s:26:\"force-delete-academic-rank\";i:85;s:24:\"force-delete-staff-grade\";i:86;s:21:\"restore-academic-rank\";i:87;s:19:\"restore-staff-grade\";i:88;s:18:\"view-academic-rank\";i:89;s:21:\"view-sector-employees\";i:90;s:16:\"view-staff-grade\";i:91;s:19:\"view-unit-employees\";}', 1769701926),
('essu_hrms_cache_user_permissions_2_1769649682_roles_', 'a:0:{}', 1769649995),
('essu_hrms_cache_user_permissions_2_1769689695_roles_', 'a:0:{}', 1769699845);
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('essu_hrms_cache_ziggy_routes_dev', 'a:4:{s:3:\"url\";s:21:\"http://127.0.0.1:8000\";s:4:\"port\";i:8000;s:8:\"defaults\";a:0:{}s:6:\"routes\";a:232:{s:15:\"oauth.authorize\";a:2:{s:3:\"uri\";s:15:\"oauth/authorize\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"passport.device\";a:2:{s:3:\"uri\";s:12:\"oauth/device\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:20:\"passport.device.code\";a:2:{s:3:\"uri\";s:17:\"oauth/device/code\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:22:\"passport.token.refresh\";a:2:{s:3:\"uri\";s:19:\"oauth/token/refresh\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:13:\"oauth.approve\";a:2:{s:3:\"uri\";s:15:\"oauth/authorize\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:10:\"oauth.deny\";a:2:{s:3:\"uri\";s:15:\"oauth/authorize\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}}s:40:\"passport.device.authorizations.authorize\";a:2:{s:3:\"uri\";s:22:\"oauth/device/authorize\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:38:\"passport.device.authorizations.approve\";a:2:{s:3:\"uri\";s:22:\"oauth/device/authorize\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:35:\"passport.device.authorizations.deny\";a:2:{s:3:\"uri\";s:22:\"oauth/device/authorize\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}}s:14:\"resend.webhook\";a:2:{s:3:\"uri\";s:14:\"resend/webhook\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:19:\"api.employees.index\";a:2:{s:3:\"uri\";s:13:\"api/employees\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"api.employees.me\";a:2:{s:3:\"uri\";s:16:\"api/employees/me\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"api.employees.show\";a:4:{s:3:\"uri\";s:27:\"api/employees/{employee_id}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:6:\"wheres\";a:1:{s:11:\"employee_id\";s:9:\"[A-Z0-9]+\";}s:10:\"parameters\";a:1:{i:0;s:11:\"employee_id\";}}s:17:\"api.sectors.index\";a:2:{s:3:\"uri\";s:11:\"api/sectors\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"api.sectors.show\";a:4:{s:3:\"uri\";s:16:\"api/sectors/{id}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:6:\"wheres\";a:1:{s:2:\"id\";s:6:\"[0-9]+\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:15:\"api.units.index\";a:2:{s:3:\"uri\";s:9:\"api/units\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"api.units.show\";a:4:{s:3:\"uri\";s:14:\"api/units/{id}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:6:\"wheres\";a:1:{s:2:\"id\";s:6:\"[0-9]+\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:4:\"home\";a:2:{s:3:\"uri\";s:1:\"/\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:9:\"dashboard\";a:2:{s:3:\"uri\";s:9:\"dashboard\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"employees.create\";a:2:{s:3:\"uri\";s:16:\"employees/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"employees.profile\";a:4:{s:3:\"uri\";s:28:\"employees/{employee}/profile\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:20:\"employees.my-profile\";a:2:{s:3:\"uri\";s:10:\"my-profile\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:28:\"employees.import.cs_form_212\";a:2:{s:3:\"uri\";s:28:\"employees/import/cs-form-212\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:16:\"audit-logs.index\";a:2:{s:3:\"uri\";s:10:\"audit-logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"audit-logs.export\";a:2:{s:3:\"uri\";s:17:\"audit-logs/export\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"employees.logs\";a:2:{s:3:\"uri\";s:14:\"employees/logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:19:\"organizational.logs\";a:2:{s:3:\"uri\";s:19:\"organizational/logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:10:\"users.logs\";a:2:{s:3:\"uri\";s:10:\"users/logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"users.activities\";a:2:{s:3:\"uri\";s:16:\"users/activities\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"employees.restore\";a:3:{s:3:\"uri\";s:22:\"employees/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:22:\"employees.force-delete\";a:3:{s:3:\"uri\";s:27:\"employees/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:13:\"sectors.index\";a:2:{s:3:\"uri\";s:7:\"sectors\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"sectors.create\";a:2:{s:3:\"uri\";s:14:\"sectors/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:13:\"sectors.store\";a:2:{s:3:\"uri\";s:7:\"sectors\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:12:\"sectors.show\";a:3:{s:3:\"uri\";s:16:\"sectors/{sector}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:6:\"sector\";}}s:12:\"sectors.edit\";a:3:{s:3:\"uri\";s:21:\"sectors/{sector}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:6:\"sector\";}}s:14:\"sectors.update\";a:4:{s:3:\"uri\";s:16:\"sectors/{sector}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:6:\"sector\";}s:8:\"bindings\";a:1:{s:6:\"sector\";s:2:\"id\";}}s:15:\"sectors.destroy\";a:4:{s:3:\"uri\";s:16:\"sectors/{sector}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:6:\"sector\";}s:8:\"bindings\";a:1:{s:6:\"sector\";s:2:\"id\";}}s:15:\"sectors.restore\";a:3:{s:3:\"uri\";s:20:\"sectors/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:20:\"sectors.force-delete\";a:3:{s:3:\"uri\";s:25:\"sectors/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:11:\"units.index\";a:2:{s:3:\"uri\";s:5:\"units\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:12:\"units.create\";a:2:{s:3:\"uri\";s:12:\"units/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:11:\"units.store\";a:2:{s:3:\"uri\";s:5:\"units\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:10:\"units.show\";a:3:{s:3:\"uri\";s:12:\"units/{unit}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"unit\";}}s:10:\"units.edit\";a:3:{s:3:\"uri\";s:17:\"units/{unit}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"unit\";}}s:12:\"units.update\";a:4:{s:3:\"uri\";s:12:\"units/{unit}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:4:\"unit\";}s:8:\"bindings\";a:1:{s:4:\"unit\";s:2:\"id\";}}s:13:\"units.destroy\";a:4:{s:3:\"uri\";s:12:\"units/{unit}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:4:\"unit\";}s:8:\"bindings\";a:1:{s:4:\"unit\";s:2:\"id\";}}s:13:\"units.restore\";a:3:{s:3:\"uri\";s:18:\"units/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:18:\"units.force-delete\";a:3:{s:3:\"uri\";s:23:\"units/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:20:\"unit-positions.index\";a:2:{s:3:\"uri\";s:14:\"unit-positions\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:21:\"unit-positions.create\";a:2:{s:3:\"uri\";s:21:\"unit-positions/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:20:\"unit-positions.store\";a:2:{s:3:\"uri\";s:14:\"unit-positions\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:19:\"unit-positions.show\";a:3:{s:3:\"uri\";s:30:\"unit-positions/{unit_position}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:13:\"unit_position\";}}s:19:\"unit-positions.edit\";a:3:{s:3:\"uri\";s:35:\"unit-positions/{unit_position}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:13:\"unit_position\";}}s:21:\"unit-positions.update\";a:3:{s:3:\"uri\";s:30:\"unit-positions/{unit_position}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:13:\"unit_position\";}}s:22:\"unit-positions.destroy\";a:3:{s:3:\"uri\";s:30:\"unit-positions/{unit_position}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:13:\"unit_position\";}}s:22:\"unit-positions.restore\";a:3:{s:3:\"uri\";s:27:\"unit-positions/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:27:\"unit-positions.force-delete\";a:3:{s:3:\"uri\";s:32:\"unit-positions/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:25:\"unit-positions.bulk-store\";a:2:{s:3:\"uri\";s:19:\"unit-positions/bulk\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:20:\"academic-ranks.index\";a:2:{s:3:\"uri\";s:14:\"academic-ranks\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:21:\"academic-ranks.create\";a:2:{s:3:\"uri\";s:21:\"academic-ranks/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:20:\"academic-ranks.store\";a:2:{s:3:\"uri\";s:14:\"academic-ranks\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:19:\"academic-ranks.show\";a:3:{s:3:\"uri\";s:30:\"academic-ranks/{academic_rank}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:13:\"academic_rank\";}}s:19:\"academic-ranks.edit\";a:3:{s:3:\"uri\";s:35:\"academic-ranks/{academic_rank}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:13:\"academic_rank\";}}s:21:\"academic-ranks.update\";a:3:{s:3:\"uri\";s:30:\"academic-ranks/{academic_rank}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:13:\"academic_rank\";}}s:22:\"academic-ranks.destroy\";a:3:{s:3:\"uri\";s:30:\"academic-ranks/{academic_rank}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:13:\"academic_rank\";}}s:22:\"academic-ranks.restore\";a:3:{s:3:\"uri\";s:27:\"academic-ranks/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:27:\"academic-ranks.force-delete\";a:3:{s:3:\"uri\";s:32:\"academic-ranks/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:18:\"staff-grades.index\";a:2:{s:3:\"uri\";s:12:\"staff-grades\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:19:\"staff-grades.create\";a:2:{s:3:\"uri\";s:19:\"staff-grades/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"staff-grades.store\";a:2:{s:3:\"uri\";s:12:\"staff-grades\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:17:\"staff-grades.show\";a:3:{s:3:\"uri\";s:26:\"staff-grades/{staff_grade}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:11:\"staff_grade\";}}s:17:\"staff-grades.edit\";a:3:{s:3:\"uri\";s:31:\"staff-grades/{staff_grade}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:11:\"staff_grade\";}}s:19:\"staff-grades.update\";a:3:{s:3:\"uri\";s:26:\"staff-grades/{staff_grade}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:11:\"staff_grade\";}}s:20:\"staff-grades.destroy\";a:3:{s:3:\"uri\";s:26:\"staff-grades/{staff_grade}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:11:\"staff_grade\";}}s:20:\"staff-grades.restore\";a:3:{s:3:\"uri\";s:25:\"staff-grades/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:25:\"staff-grades.force-delete\";a:3:{s:3:\"uri\";s:30:\"staff-grades/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:27:\"employees.designations.page\";a:4:{s:3:\"uri\";s:40:\"employees/{employee}/designations/manage\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:28:\"employees.designations.index\";a:4:{s:3:\"uri\";s:33:\"employees/{employee}/designations\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:28:\"employees.designations.store\";a:4:{s:3:\"uri\";s:33:\"employees/{employee}/designations\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:29:\"employees.designations.update\";a:4:{s:3:\"uri\";s:47:\"employees/{employee}/designations/{designation}\";s:7:\"methods\";a:1:{i:0;s:3:\"PUT\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:30:\"employees.designations.destroy\";a:4:{s:3:\"uri\";s:47:\"employees/{employee}/designations/{designation}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:34:\"employees.designations.set-primary\";a:4:{s:3:\"uri\";s:59:\"employees/{employee}/designations/{designation}/set-primary\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:35:\"employees.designations.form-options\";a:4:{s:3:\"uri\";s:46:\"employees/{employee}/designations/form-options\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:36:\"employees.designations.grade-history\";a:4:{s:3:\"uri\";s:61:\"employees/{employee}/designations/{designation}/grade-history\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:30:\"employees.designations.promote\";a:4:{s:3:\"uri\";s:55:\"employees/{employee}/designations/{designation}/promote\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:30:\"employees.designations.correct\";a:4:{s:3:\"uri\";s:55:\"employees/{employee}/designations/{designation}/correct\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:41:\"employees.designations.grade-form-options\";a:4:{s:3:\"uri\";s:66:\"employees/{employee}/designations/{designation}/grade-form-options\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:11:\"designation\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:11:\"designation\";s:2:\"id\";}}s:26:\"employees.promotions.index\";a:4:{s:3:\"uri\";s:31:\"employees/{employee}/promotions\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:26:\"employees.promotions.store\";a:4:{s:3:\"uri\";s:31:\"employees/{employee}/promotions\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:33:\"employees.promotions.form-options\";a:4:{s:3:\"uri\";s:44:\"employees/{employee}/promotions/form-options\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:31:\"employees.rank-promotions.index\";a:4:{s:3:\"uri\";s:36:\"employees/{employee}/rank-promotions\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:31:\"employees.rank-promotions.store\";a:4:{s:3:\"uri\";s:36:\"employees/{employee}/rank-promotions\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:38:\"employees.rank-promotions.form-options\";a:4:{s:3:\"uri\";s:49:\"employees/{employee}/rank-promotions/form-options\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:15:\"positions.index\";a:2:{s:3:\"uri\";s:9:\"positions\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"positions.create\";a:2:{s:3:\"uri\";s:16:\"positions/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"positions.store\";a:2:{s:3:\"uri\";s:9:\"positions\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"positions.show\";a:3:{s:3:\"uri\";s:20:\"positions/{position}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"position\";}}s:14:\"positions.edit\";a:3:{s:3:\"uri\";s:25:\"positions/{position}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"position\";}}s:16:\"positions.update\";a:4:{s:3:\"uri\";s:20:\"positions/{position}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:8:\"position\";}s:8:\"bindings\";a:1:{s:8:\"position\";s:2:\"id\";}}s:17:\"positions.destroy\";a:4:{s:3:\"uri\";s:20:\"positions/{position}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:8:\"position\";}s:8:\"bindings\";a:1:{s:8:\"position\";s:2:\"id\";}}s:17:\"positions.restore\";a:3:{s:3:\"uri\";s:22:\"positions/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:22:\"positions.force-delete\";a:3:{s:3:\"uri\";s:27:\"positions/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:15:\"employees.index\";a:2:{s:3:\"uri\";s:9:\"employees\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"employees.store\";a:2:{s:3:\"uri\";s:9:\"employees\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"employees.show\";a:4:{s:3:\"uri\";s:20:\"employees/{employee}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:14:\"employees.edit\";a:4:{s:3:\"uri\";s:25:\"employees/{employee}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:16:\"employees.update\";a:4:{s:3:\"uri\";s:20:\"employees/{employee}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:17:\"employees.destroy\";a:4:{s:3:\"uri\";s:20:\"employees/{employee}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:25:\"employees.documents.index\";a:4:{s:3:\"uri\";s:30:\"employees/{employee}/documents\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:25:\"employees.documents.store\";a:4:{s:3:\"uri\";s:30:\"employees/{employee}/documents\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}s:8:\"bindings\";a:1:{s:8:\"employee\";s:2:\"id\";}}s:28:\"employees.documents.download\";a:4:{s:3:\"uri\";s:50:\"employees/{employee}/documents/{document}/download\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:8:\"document\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:8:\"document\";s:2:\"id\";}}s:27:\"employees.documents.destroy\";a:4:{s:3:\"uri\";s:41:\"employees/{employee}/documents/{document}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:2:{i:0;s:8:\"employee\";i:1;s:8:\"document\";}s:8:\"bindings\";a:2:{s:8:\"employee\";s:2:\"id\";s:8:\"document\";s:2:\"id\";}}s:17:\"permissions.index\";a:2:{s:3:\"uri\";s:11:\"permissions\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"permissions.create\";a:2:{s:3:\"uri\";s:18:\"permissions/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"permissions.store\";a:2:{s:3:\"uri\";s:11:\"permissions\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:16:\"permissions.show\";a:3:{s:3:\"uri\";s:24:\"permissions/{permission}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:10:\"permission\";}}s:16:\"permissions.edit\";a:3:{s:3:\"uri\";s:29:\"permissions/{permission}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:10:\"permission\";}}s:18:\"permissions.update\";a:4:{s:3:\"uri\";s:24:\"permissions/{permission}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:10:\"permission\";}s:8:\"bindings\";a:1:{s:10:\"permission\";s:2:\"id\";}}s:19:\"permissions.destroy\";a:4:{s:3:\"uri\";s:24:\"permissions/{permission}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:10:\"permission\";}s:8:\"bindings\";a:1:{s:10:\"permission\";s:2:\"id\";}}s:11:\"roles.index\";a:2:{s:3:\"uri\";s:5:\"roles\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:12:\"roles.create\";a:2:{s:3:\"uri\";s:12:\"roles/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:11:\"roles.store\";a:2:{s:3:\"uri\";s:5:\"roles\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:10:\"roles.show\";a:3:{s:3:\"uri\";s:12:\"roles/{role}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"role\";}}s:10:\"roles.edit\";a:3:{s:3:\"uri\";s:17:\"roles/{role}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"role\";}}s:12:\"roles.update\";a:4:{s:3:\"uri\";s:12:\"roles/{role}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:4:\"role\";}s:8:\"bindings\";a:1:{s:4:\"role\";s:2:\"id\";}}s:13:\"roles.destroy\";a:4:{s:3:\"uri\";s:12:\"roles/{role}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:4:\"role\";}s:8:\"bindings\";a:1:{s:4:\"role\";s:2:\"id\";}}s:11:\"users.index\";a:2:{s:3:\"uri\";s:5:\"users\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:12:\"users.create\";a:2:{s:3:\"uri\";s:12:\"users/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:11:\"users.store\";a:2:{s:3:\"uri\";s:5:\"users\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:10:\"users.show\";a:3:{s:3:\"uri\";s:12:\"users/{user}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"user\";}}s:10:\"users.edit\";a:4:{s:3:\"uri\";s:17:\"users/{user}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:4:\"user\";}s:8:\"bindings\";a:1:{s:4:\"user\";s:2:\"id\";}}s:12:\"users.update\";a:4:{s:3:\"uri\";s:12:\"users/{user}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:4:\"user\";}s:8:\"bindings\";a:1:{s:4:\"user\";s:2:\"id\";}}s:13:\"users.destroy\";a:4:{s:3:\"uri\";s:12:\"users/{user}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:4:\"user\";}s:8:\"bindings\";a:1:{s:4:\"user\";s:2:\"id\";}}s:13:\"users.restore\";a:3:{s:3:\"uri\";s:18:\"users/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:18:\"users.force-delete\";a:3:{s:3:\"uri\";s:23:\"users/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:21:\"request-types.publish\";a:3:{s:3:\"uri\";s:36:\"request-types/{request_type}/publish\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:12:\"request_type\";}}s:19:\"request-types.index\";a:2:{s:3:\"uri\";s:13:\"request-types\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:20:\"request-types.create\";a:2:{s:3:\"uri\";s:20:\"request-types/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:19:\"request-types.store\";a:2:{s:3:\"uri\";s:13:\"request-types\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:18:\"request-types.show\";a:3:{s:3:\"uri\";s:28:\"request-types/{request_type}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:12:\"request_type\";}}s:18:\"request-types.edit\";a:3:{s:3:\"uri\";s:33:\"request-types/{request_type}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:12:\"request_type\";}}s:20:\"request-types.update\";a:3:{s:3:\"uri\";s:28:\"request-types/{request_type}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:12:\"request_type\";}}s:21:\"request-types.destroy\";a:3:{s:3:\"uri\";s:28:\"request-types/{request_type}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:12:\"request_type\";}}s:27:\"certificate-templates.index\";a:2:{s:3:\"uri\";s:21:\"certificate-templates\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:28:\"certificate-templates.create\";a:2:{s:3:\"uri\";s:28:\"certificate-templates/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:27:\"certificate-templates.store\";a:2:{s:3:\"uri\";s:21:\"certificate-templates\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:26:\"certificate-templates.show\";a:3:{s:3:\"uri\";s:44:\"certificate-templates/{certificate_template}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:20:\"certificate_template\";}}s:26:\"certificate-templates.edit\";a:3:{s:3:\"uri\";s:49:\"certificate-templates/{certificate_template}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:20:\"certificate_template\";}}s:28:\"certificate-templates.update\";a:3:{s:3:\"uri\";s:44:\"certificate-templates/{certificate_template}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:20:\"certificate_template\";}}s:29:\"certificate-templates.destroy\";a:3:{s:3:\"uri\";s:44:\"certificate-templates/{certificate_template}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:20:\"certificate_template\";}}s:29:\"certificate-templates.preview\";a:2:{s:3:\"uri\";s:29:\"certificate-templates/preview\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"requests.index\";a:2:{s:3:\"uri\";s:8:\"requests\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"requests.export\";a:2:{s:3:\"uri\";s:15:\"requests/export\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"requests.create\";a:4:{s:3:\"uri\";s:34:\"requests/type/{requestType}/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:11:\"requestType\";}s:8:\"bindings\";a:1:{s:11:\"requestType\";s:2:\"id\";}}s:14:\"requests.store\";a:4:{s:3:\"uri\";s:27:\"requests/type/{requestType}\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:11:\"requestType\";}s:8:\"bindings\";a:1:{s:11:\"requestType\";s:2:\"id\";}}s:13:\"requests.show\";a:4:{s:3:\"uri\";s:21:\"requests/{submission}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:16:\"requests.approve\";a:4:{s:3:\"uri\";s:29:\"requests/{submission}/approve\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:15:\"requests.reject\";a:4:{s:3:\"uri\";s:28:\"requests/{submission}/reject\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:17:\"requests.withdraw\";a:4:{s:3:\"uri\";s:30:\"requests/{submission}/withdraw\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:16:\"requests.comment\";a:4:{s:3:\"uri\";s:29:\"requests/{submission}/comment\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:16:\"requests.fulfill\";a:4:{s:3:\"uri\";s:29:\"requests/{submission}/fulfill\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:29:\"requests.fulfillment.download\";a:4:{s:3:\"uri\";s:42:\"requests/{submission}/fulfillment/download\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:10:\"submission\";}s:8:\"bindings\";a:1:{s:10:\"submission\";s:2:\"id\";}}s:20:\"settings.delegations\";a:2:{s:3:\"uri\";s:20:\"settings/delegations\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:26:\"settings.delegations.store\";a:2:{s:3:\"uri\";s:20:\"settings/delegations\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:28:\"settings.delegations.destroy\";a:3:{s:3:\"uri\";s:25:\"settings/delegations/{id}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:22:\"api.delegations.active\";a:2:{s:3:\"uri\";s:22:\"api/delegations/active\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:21:\"api.delegations.to-me\";a:2:{s:3:\"uri\";s:21:\"api/delegations/to-me\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"trainings.join\";a:2:{s:3:\"uri\";s:14:\"trainings/join\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"trainings.apply\";a:2:{s:3:\"uri\";s:14:\"trainings/join\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"trainings.logs\";a:2:{s:3:\"uri\";s:14:\"trainings/logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"trainings.overview\";a:2:{s:3:\"uri\";s:18:\"trainings/overview\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"trainings.index\";a:2:{s:3:\"uri\";s:9:\"trainings\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"trainings.create\";a:2:{s:3:\"uri\";s:16:\"trainings/create\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"trainings.store\";a:2:{s:3:\"uri\";s:9:\"trainings\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"trainings.show\";a:3:{s:3:\"uri\";s:20:\"trainings/{training}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"training\";}}s:14:\"trainings.edit\";a:3:{s:3:\"uri\";s:25:\"trainings/{training}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"training\";}}s:16:\"trainings.update\";a:4:{s:3:\"uri\";s:20:\"trainings/{training}\";s:7:\"methods\";a:2:{i:0;s:3:\"PUT\";i:1;s:5:\"PATCH\";}s:10:\"parameters\";a:1:{i:0;s:8:\"training\";}s:8:\"bindings\";a:1:{s:8:\"training\";s:11:\"training_id\";}}s:17:\"trainings.destroy\";a:4:{s:3:\"uri\";s:20:\"trainings/{training}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:8:\"training\";}s:8:\"bindings\";a:1:{s:8:\"training\";s:11:\"training_id\";}}s:17:\"trainings.restore\";a:3:{s:3:\"uri\";s:22:\"trainings/{id}/restore\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:22:\"trainings.force-delete\";a:3:{s:3:\"uri\";s:27:\"trainings/{id}/force-delete\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:9:\"roles.api\";a:2:{s:3:\"uri\";s:9:\"api/roles\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"leaves.balance\";a:2:{s:3:\"uri\";s:14:\"leaves/balance\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"leaves.calendar\";a:2:{s:3:\"uri\";s:15:\"leaves/calendar\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"leaves.history\";a:2:{s:3:\"uri\";s:14:\"leaves/history\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"api.leaves.balance\";a:2:{s:3:\"uri\";s:18:\"api/leaves/balance\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"api.leaves.credits\";a:2:{s:3:\"uri\";s:18:\"api/leaves/credits\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"api.leaves.types\";a:2:{s:3:\"uri\";s:16:\"api/leaves/types\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:18:\"api.leaves.history\";a:2:{s:3:\"uri\";s:18:\"api/leaves/history\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:26:\"admin.leave-balances.index\";a:2:{s:3:\"uri\";s:20:\"admin/leave-balances\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:40:\"admin.leave-balances.special-leave-types\";a:2:{s:3:\"uri\";s:40:\"admin/leave-balances/special-leave-types\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:25:\"admin.leave-balances.show\";a:3:{s:3:\"uri\";s:31:\"admin/leave-balances/{employee}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}}s:32:\"admin.leave-balances.get-balance\";a:3:{s:3:\"uri\";s:39:\"admin/leave-balances/{employee}/balance\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}}s:40:\"admin.leave-balances.set-initial-balance\";a:3:{s:3:\"uri\";s:47:\"admin/leave-balances/{employee}/initial-balance\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}}s:27:\"admin.leave-balances.adjust\";a:3:{s:3:\"uri\";s:38:\"admin/leave-balances/{employee}/adjust\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}}s:34:\"admin.leave-balances.grant-special\";a:3:{s:3:\"uri\";s:45:\"admin/leave-balances/{employee}/grant-special\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}s:10:\"parameters\";a:1:{i:0;s:8:\"employee\";}}s:42:\"admin.leave-balances.bulk-initial-balances\";a:2:{s:3:\"uri\";s:42:\"admin/leave-balances/bulk-initial-balances\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:13:\"oauth.clients\";a:2:{s:3:\"uri\";s:13:\"oauth/clients\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:19:\"oauth.clients.store\";a:2:{s:3:\"uri\";s:13:\"oauth/clients\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:18:\"oauth.clients.edit\";a:3:{s:3:\"uri\";s:23:\"oauth/clients/{id}/edit\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:20:\"oauth.clients.update\";a:3:{s:3:\"uri\";s:18:\"oauth/clients/{id}\";s:7:\"methods\";a:1:{i:0;s:3:\"PUT\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:18:\"oauth.clients.show\";a:3:{s:3:\"uri\";s:18:\"oauth/clients/{id}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:21:\"oauth.clients.destroy\";a:3:{s:3:\"uri\";s:18:\"oauth/clients/{id}\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}s:10:\"parameters\";a:1:{i:0;s:2:\"id\";}}s:15:\"admin.logs.view\";a:2:{s:3:\"uri\";s:10:\"admin/logs\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"admin.logs.clear\";a:2:{s:3:\"uri\";s:16:\"admin/logs/clear\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:19:\"admin.logs.download\";a:2:{s:3:\"uri\";s:19:\"admin/logs/download\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:12:\"profile.edit\";a:2:{s:3:\"uri\";s:16:\"settings/profile\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"profile.update\";a:2:{s:3:\"uri\";s:16:\"settings/profile\";s:7:\"methods\";a:1:{i:0;s:5:\"PATCH\";}}s:15:\"profile.destroy\";a:2:{s:3:\"uri\";s:16:\"settings/profile\";s:7:\"methods\";a:1:{i:0;s:6:\"DELETE\";}}s:13:\"password.edit\";a:2:{s:3:\"uri\";s:17:\"settings/password\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"password.update\";a:2:{s:3:\"uri\";s:17:\"settings/password\";s:7:\"methods\";a:1:{i:0;s:3:\"PUT\";}}s:10:\"appearance\";a:2:{s:3:\"uri\";s:19:\"settings/appearance\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:15:\"two-factor.show\";a:2:{s:3:\"uri\";s:19:\"settings/two-factor\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"two-factor.enable\";a:2:{s:3:\"uri\";s:26:\"settings/two-factor/enable\";s:7:\"methods\";a:3:{i:0;s:3:\"GET\";i:1;s:4:\"POST\";i:2;s:4:\"HEAD\";}}s:18:\"two-factor.disable\";a:2:{s:3:\"uri\";s:27:\"settings/two-factor/disable\";s:7:\"methods\";a:3:{i:0;s:3:\"GET\";i:1;s:4:\"POST\";i:2;s:4:\"HEAD\";}}s:25:\"two-factor.recovery-codes\";a:2:{s:3:\"uri\";s:34:\"settings/two-factor/recovery-codes\";s:7:\"methods\";a:3:{i:0;s:3:\"GET\";i:1;s:4:\"POST\";i:2;s:4:\"HEAD\";}}s:8:\"register\";a:2:{s:3:\"uri\";s:8:\"register\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:5:\"login\";a:2:{s:3:\"uri\";s:5:\"login\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:16:\"password.request\";a:2:{s:3:\"uri\";s:15:\"forgot-password\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:14:\"password.email\";a:2:{s:3:\"uri\";s:15:\"forgot-password\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:14:\"password.reset\";a:3:{s:3:\"uri\";s:22:\"reset-password/{token}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:1:{i:0;s:5:\"token\";}}s:14:\"password.store\";a:2:{s:3:\"uri\";s:14:\"reset-password\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:16:\"two-factor.login\";a:2:{s:3:\"uri\";s:20:\"two-factor-challenge\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:17:\"two-factor.verify\";a:2:{s:3:\"uri\";s:20:\"two-factor-challenge\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:19:\"verification.notice\";a:2:{s:3:\"uri\";s:12:\"verify-email\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:19:\"verification.verify\";a:3:{s:3:\"uri\";s:24:\"verify-email/{id}/{hash}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:10:\"parameters\";a:2:{i:0;s:2:\"id\";i:1;s:4:\"hash\";}}s:17:\"verification.send\";a:2:{s:3:\"uri\";s:31:\"email/verification-notification\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:16:\"password.confirm\";a:2:{s:3:\"uri\";s:16:\"confirm-password\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:6:\"logout\";a:2:{s:3:\"uri\";s:6:\"logout\";s:7:\"methods\";a:3:{i:0;s:3:\"GET\";i:1;s:4:\"POST\";i:2;s:4:\"HEAD\";}}s:17:\"oauth.end-session\";a:2:{s:3:\"uri\";s:17:\"oauth/end-session\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}}s:25:\"oauth.back-channel-logout\";a:2:{s:3:\"uri\";s:25:\"oauth/back-channel-logout\";s:7:\"methods\";a:1:{i:0;s:4:\"POST\";}}s:13:\"storage.local\";a:4:{s:3:\"uri\";s:14:\"storage/{path}\";s:7:\"methods\";a:2:{i:0;s:3:\"GET\";i:1;s:4:\"HEAD\";}s:6:\"wheres\";a:1:{s:4:\"path\";s:2:\".*\";}s:10:\"parameters\";a:1:{i:0;s:4:\"path\";}}}}', 1769704740);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certificate_templates`
--

CREATE TABLE `certificate_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `background_image_path` varchar(255) DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 1200,
  `height` int(11) NOT NULL DEFAULT 800,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificate_templates`
--

INSERT INTO `certificate_templates` (`id`, `name`, `description`, `background_image_path`, `width`, `height`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Arvin O. Negrillo', 'xd', 'certificate-templates/temp/V25xOGJFBoCPzvcZvqyHQLiOkQlzQgJKam7cje0B.png', 1800, 2364, 1, '2026-01-28 18:52:43', '2026-01-28 18:52:43');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_text_layers`
--

CREATE TABLE `certificate_text_layers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `certificate_template_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `field_key` varchar(255) DEFAULT NULL,
  `default_text` text DEFAULT NULL,
  `x_position` int(11) NOT NULL DEFAULT 0,
  `y_position` int(11) NOT NULL DEFAULT 0,
  `font_family` varchar(255) NOT NULL DEFAULT 'Arial',
  `font_size` int(11) NOT NULL DEFAULT 24,
  `font_color` varchar(255) NOT NULL DEFAULT '#000000',
  `font_weight` varchar(255) NOT NULL DEFAULT 'normal',
  `text_align` varchar(255) NOT NULL DEFAULT 'left',
  `max_width` int(11) DEFAULT NULL,
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificate_text_layers`
--

INSERT INTO `certificate_text_layers` (`id`, `certificate_template_id`, `name`, `field_key`, `default_text`, `x_position`, `y_position`, `font_family`, `font_size`, `font_color`, `font_weight`, `text_align`, `max_width`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, 'employee_unit', 'employee_unit', NULL, 704, 1363, 'Arial', 24, '#000000', 'normal', 'left', NULL, 0, '2026-01-28 18:52:43', '2026-01-28 18:52:43'),
(2, 1, 'submitted_date', 'submitted_date', NULL, 1335, 1635, 'Arial', 24, '#000000', 'normal', 'left', NULL, 1, '2026-01-28 18:52:43', '2026-01-28 18:52:43');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` varchar(15) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `name_extension` varchar(5) DEFAULT NULL,
  `status` enum('active','inactive','on-leave') NOT NULL DEFAULT 'active',
  `employment_status` enum('Regular','Contractual','Job-Order','Probationary') NOT NULL DEFAULT 'Probationary',
  `employee_type` enum('Teaching','Non-Teaching') NOT NULL DEFAULT 'Teaching',
  `primary_designation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `salary` decimal(12,2) DEFAULT NULL,
  `date_hired` date DEFAULT NULL,
  `date_regularized` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `birth_date` date NOT NULL,
  `birth_place` varchar(100) NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `civil_status` varchar(15) NOT NULL,
  `height_m` decimal(5,2) NOT NULL,
  `weight_kg` decimal(6,2) NOT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `gsis_id_no` varchar(25) DEFAULT NULL,
  `pagibig_id_no` varchar(25) DEFAULT NULL,
  `philhealth_no` varchar(25) DEFAULT NULL,
  `sss_no` varchar(25) DEFAULT NULL,
  `tin_no` varchar(25) DEFAULT NULL,
  `agency_employee_no` varchar(25) DEFAULT NULL,
  `citizenship` varchar(30) NOT NULL,
  `dual_citizenship` tinyint(1) NOT NULL DEFAULT 0,
  `citizenship_type` enum('By birth','By naturalization') DEFAULT NULL,
  `dual_citizenship_country` varchar(50) DEFAULT NULL,
  `res_house_no` varchar(15) DEFAULT NULL,
  `res_street` varchar(50) DEFAULT NULL,
  `res_subdivision` varchar(50) DEFAULT NULL,
  `res_barangay` varchar(50) DEFAULT NULL,
  `res_city` varchar(50) DEFAULT NULL,
  `res_province` varchar(50) DEFAULT NULL,
  `res_zip_code` varchar(10) DEFAULT NULL,
  `perm_house_no` varchar(15) DEFAULT NULL,
  `perm_street` varchar(50) DEFAULT NULL,
  `perm_subdivision` varchar(50) DEFAULT NULL,
  `perm_barangay` varchar(50) DEFAULT NULL,
  `perm_city` varchar(50) DEFAULT NULL,
  `perm_province` varchar(50) DEFAULT NULL,
  `perm_zip_code` varchar(10) DEFAULT NULL,
  `telephone_no` varchar(20) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `email_address` varchar(80) DEFAULT NULL,
  `government_issued_id` varchar(50) DEFAULT NULL,
  `id_number` varchar(25) DEFAULT NULL,
  `id_date_issued` date DEFAULT NULL,
  `id_place_of_issue` varchar(100) DEFAULT NULL,
  `indigenous_group` varchar(50) DEFAULT NULL,
  `pwd_id_no` varchar(50) DEFAULT NULL,
  `solo_parent_id_no` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `surname`, `first_name`, `middle_name`, `name_extension`, `status`, `employment_status`, `employee_type`, `primary_designation_id`, `salary`, `date_hired`, `date_regularized`, `start_date`, `end_date`, `birth_date`, `birth_place`, `sex`, `civil_status`, `height_m`, `weight_kg`, `blood_type`, `gsis_id_no`, `pagibig_id_no`, `philhealth_no`, `sss_no`, `tin_no`, `agency_employee_no`, `citizenship`, `dual_citizenship`, `citizenship_type`, `dual_citizenship_country`, `res_house_no`, `res_street`, `res_subdivision`, `res_barangay`, `res_city`, `res_province`, `res_zip_code`, `perm_house_no`, `perm_street`, `perm_subdivision`, `perm_barangay`, `perm_city`, `perm_province`, `perm_zip_code`, `telephone_no`, `mobile_no`, `email_address`, `government_issued_id`, `id_number`, `id_date_issued`, `id_place_of_issue`, `indigenous_group`, `pwd_id_no`, `solo_parent_id_no`, `created_at`, `updated_at`, `deleted_at`) VALUES
('EMP0001', 'Martires', 'Jyl Derwin', 'Sabungan', NULL, 'active', 'Regular', 'Teaching', 8, 30000.00, '2026-01-01', '2026-01-15', NULL, NULL, '2004-07-22', 'Catarman, Northern Samar', 'Female', 'Single', 0.71, 30.00, 'A', '12345678901', '9876-5432-1098', '12-345678901-2', '34-5678912-3', '987-654-321', '2023-001245', 'Filipino', 0, NULL, NULL, '333', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '33', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '09564062855', '09564062855', 'jymartires@gmail.com', '2134234', '2342455', '2024-09-15', NULL, NULL, NULL, NULL, '2026-01-27 16:32:57', '2026-01-29 06:42:08', NULL),
('EMP0003', 'Martires', 'Jyl Derwin', 'Sabungan', NULL, 'active', 'Probationary', 'Non-Teaching', 4, 225000.00, '2026-01-14', NULL, NULL, NULL, '2004-07-22', 'Catarman, Northern Samar', 'Female', 'Single', 0.71, 30.00, 'A', '12345678901', '9876-5432-1098', '12-345678901-2', '34-5678912-3', '987-654-321', '2023-001245', 'Filipino', 0, NULL, NULL, '333', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '33', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '09564062855', '09564062855', 'jymartires@gmail.com', '2134234', '2342455', '2024-09-15', NULL, NULL, NULL, NULL, '2026-01-29 04:22:15', '2026-01-29 04:22:53', NULL),
('EMP0005', 'Martires', 'Jyl Derwin', 'Sabungan', NULL, 'active', 'Probationary', 'Teaching', 6, 20000.00, '2026-01-01', NULL, NULL, NULL, '2004-07-22', 'Catarman, Northern Samar', 'Female', 'Single', 0.71, 30.00, 'A', '12345678901', '9876-5432-1098', '12-345678901-2', '34-5678912-3', '987-654-321', '2023-001245', 'Filipino', 0, NULL, NULL, '333', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '33', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '09564062855', '09564062855', 'jymartires@gmail.com', '2134234', '2342455', '2024-09-15', NULL, NULL, NULL, NULL, '2026-01-29 04:54:05', '2026-01-29 05:07:17', NULL),
('EMP0012', 'Test', 'Test', 'Test', NULL, 'active', 'Regular', 'Non-Teaching', 7, 12535.00, '2026-01-01', '2026-01-09', NULL, NULL, '2004-07-22', 'Catarman, Northern Samar', 'Male', 'Single', 0.71, 30.00, 'A', '12345678901', '9876-5432-1098', '12-345678901-2', '34-5678912-3', '987-654-321', '2023-001245', 'Filipino', 0, NULL, NULL, '333', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '33', 'Real Street', 'Santos Village', 'Songco', 'Borongan City', 'Eastern Samar', '6800', '09564062855', '09564062855', 'jymartires@gmail.com', '2134234', '2342455', '2024-09-15', NULL, NULL, NULL, NULL, '2026-01-29 05:31:26', '2026-01-29 05:32:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_audit_log`
--

CREATE TABLE `employee_audit_log` (
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `employee_id` varchar(15) DEFAULT NULL,
  `action_type` enum('CREATE','UPDATE','DELETE') NOT NULL,
  `field_changed` varchar(100) DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`snapshot`)),
  `action_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `performed_by` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_childrens`
--

CREATE TABLE `employee_childrens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_childrens`
--

INSERT INTO `employee_childrens` (`id`, `employee_id`, `full_name`, `birth_date`, `created_at`, `updated_at`) VALUES
(25, 'EMP0001', 'Miguel Santos Reyes', '2006-04-22', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(26, 'EMP0001', 'Carlos Rafael De Leon Garcia', '2009-12-07', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(27, 'EMP0001', 'Jose Antonio Bautista Cruz', '2007-03-22', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(28, 'EMP0001', 'Marco Luis Villanueva Mendoza', '2003-03-06', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(29, 'EMP0001', 'Gabriel Jose Ramos Torres', '2004-06-26', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(30, 'EMP0001', 'Maria Isabel Garcia Santos', '2003-03-12', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(31, 'EMP0001', 'Ana Sophia Cruz Dela Cruz', '2003-11-15', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(32, 'EMP0001', 'Isabella Marie Reyes Lopez', '2003-12-26', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(33, 'EMP0001', 'Gabriela Luz Fernandez Aquino', '2003-12-04', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(34, 'EMP0001', 'Sophia Camille Tan Rodriguez', '2003-03-06', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(35, 'EMP0001', 'Tricia Mae Santos', '2008-07-06', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(36, 'EMP0001', 'May Ann Cruz', '2004-03-09', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(37, 'EMP0003', 'Miguel Santos Reyes', '2006-04-22', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(38, 'EMP0003', 'Carlos Rafael De Leon Garcia', '2009-12-07', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(39, 'EMP0003', 'Jose Antonio Bautista Cruz', '2007-03-22', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(40, 'EMP0003', 'Marco Luis Villanueva Mendoza', '2003-03-06', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(41, 'EMP0003', 'Gabriel Jose Ramos Torres', '2004-06-26', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(42, 'EMP0003', 'Maria Isabel Garcia Santos', '2003-03-12', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(43, 'EMP0003', 'Ana Sophia Cruz Dela Cruz', '2003-11-15', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(44, 'EMP0003', 'Isabella Marie Reyes Lopez', '2003-12-26', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(45, 'EMP0003', 'Gabriela Luz Fernandez Aquino', '2003-12-04', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(46, 'EMP0003', 'Sophia Camille Tan Rodriguez', '2003-03-06', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(47, 'EMP0003', 'Tricia Mae Santos', '2008-07-06', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(48, 'EMP0003', 'May Ann Cruz', '2004-03-09', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(49, 'EMP0005', 'Miguel Santos Reyes', '2006-04-22', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(50, 'EMP0005', 'Carlos Rafael De Leon Garcia', '2009-12-07', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(51, 'EMP0005', 'Jose Antonio Bautista Cruz', '2007-03-22', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(52, 'EMP0005', 'Marco Luis Villanueva Mendoza', '2003-03-06', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(53, 'EMP0005', 'Gabriel Jose Ramos Torres', '2004-06-26', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(54, 'EMP0005', 'Maria Isabel Garcia Santos', '2003-03-12', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(55, 'EMP0005', 'Ana Sophia Cruz Dela Cruz', '2003-11-15', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(56, 'EMP0005', 'Isabella Marie Reyes Lopez', '2003-12-26', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(57, 'EMP0005', 'Gabriela Luz Fernandez Aquino', '2003-12-04', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(58, 'EMP0005', 'Sophia Camille Tan Rodriguez', '2003-03-06', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(59, 'EMP0005', 'Tricia Mae Santos', '2008-07-06', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(60, 'EMP0005', 'May Ann Cruz', '2004-03-09', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(61, 'EMP0012', 'Miguel Santos Reyes', '2006-04-22', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(62, 'EMP0012', 'Carlos Rafael De Leon Garcia', '2009-12-07', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(63, 'EMP0012', 'Jose Antonio Bautista Cruz', '2007-03-22', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(64, 'EMP0012', 'Marco Luis Villanueva Mendoza', '2003-03-06', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(65, 'EMP0012', 'Gabriel Jose Ramos Torres', '2004-06-26', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(66, 'EMP0012', 'Maria Isabel Garcia Santos', '2003-03-12', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(67, 'EMP0012', 'Ana Sophia Cruz Dela Cruz', '2003-11-15', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(68, 'EMP0012', 'Isabella Marie Reyes Lopez', '2003-12-26', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(69, 'EMP0012', 'Gabriela Luz Fernandez Aquino', '2003-12-04', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(70, 'EMP0012', 'Sophia Camille Tan Rodriguez', '2003-03-06', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(71, 'EMP0012', 'Tricia Mae Santos', '2008-07-06', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(72, 'EMP0012', 'May Ann Cruz', '2004-03-09', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_civil_service_eligibilities`
--

CREATE TABLE `employee_civil_service_eligibilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `eligibility` varchar(80) NOT NULL,
  `rating` varchar(10) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `exam_place` varchar(100) DEFAULT NULL,
  `license_no` varchar(30) DEFAULT NULL,
  `license_validity` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_civil_service_eligibilities`
--

INSERT INTO `employee_civil_service_eligibilities` (`id`, `employee_id`, `eligibility`, `rating`, `exam_date`, `exam_place`, `license_no`, `license_validity`, `created_at`, `updated_at`) VALUES
(15, 'EMP0001', 'Career Service Sub-Professional', '0.8', '2022-08-12', 'Tacloban City, Leyte', '2554', NULL, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(16, 'EMP0001', 'Career Service Professional', 'N/A', '2023-02-20', 'LTO Borongan, Eastern Samar', 'N08-23-012345', '2028-02-20', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(17, 'EMP0001', 'Driver\'s License (Non-Professional)', '82.5', '2023-03-15', 'Manila, Metro Manila', 'N/A', '2025-05-01', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(18, 'EMP0001', 'RA 1080 (Barangay Official)', '88.0', '2022-05-01', 'Barangay Hall, Borongan City', 'N/A', NULL, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(19, 'EMP0001', 'Career Service Sub-Professional', '0.8', '2021-07-10', 'TESDA Regional Office VIII, Tacloban', 'NC II-08-2021-5678', '2029-03-05', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(20, 'EMP0001', 'Driver\'s License (Professional)', 'N/A', '2024-03-05', 'LTO Borongan, Eastern Samar', 'N08-24-987654', NULL, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(21, 'EMP0001', 'CES (Career Executive Service) Eligibility', '82.0', '2024-09-29', 'Leyte Normal University, Tacloban', '1234567', NULL, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(22, 'EMP0003', 'Career Service Sub-Professional', '0.8', '2022-08-12', 'Tacloban City, Leyte', '2554', NULL, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(23, 'EMP0003', 'Career Service Professional', 'N/A', '2023-02-20', 'LTO Borongan, Eastern Samar', 'N08-23-012345', '2028-02-20', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(24, 'EMP0003', 'Driver\'s License (Non-Professional)', '82.5', '2023-03-15', 'Manila, Metro Manila', 'N/A', '2025-05-01', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(25, 'EMP0003', 'RA 1080 (Barangay Official)', '88.0', '2022-05-01', 'Barangay Hall, Borongan City', 'N/A', NULL, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(26, 'EMP0003', 'Career Service Sub-Professional', '0.8', '2021-07-10', 'TESDA Regional Office VIII, Tacloban', 'NC II-08-2021-5678', '2029-03-05', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(27, 'EMP0003', 'Driver\'s License (Professional)', 'N/A', '2024-03-05', 'LTO Borongan, Eastern Samar', 'N08-24-987654', NULL, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(28, 'EMP0003', 'CES (Career Executive Service) Eligibility', '82.0', '2024-09-29', 'Leyte Normal University, Tacloban', '1234567', NULL, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(29, 'EMP0005', 'Career Service Sub-Professional', '0.8', '2022-08-12', 'Tacloban City, Leyte', '2554', NULL, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(30, 'EMP0005', 'Career Service Professional', 'N/A', '2023-02-20', 'LTO Borongan, Eastern Samar', 'N08-23-012345', '2028-02-20', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(31, 'EMP0005', 'Driver\'s License (Non-Professional)', '82.5', '2023-03-15', 'Manila, Metro Manila', 'N/A', '2025-05-01', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(32, 'EMP0005', 'RA 1080 (Barangay Official)', '88.0', '2022-05-01', 'Barangay Hall, Borongan City', 'N/A', NULL, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(33, 'EMP0005', 'Career Service Sub-Professional', '0.8', '2021-07-10', 'TESDA Regional Office VIII, Tacloban', 'NC II-08-2021-5678', '2029-03-05', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(34, 'EMP0005', 'Driver\'s License (Professional)', 'N/A', '2024-03-05', 'LTO Borongan, Eastern Samar', 'N08-24-987654', NULL, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(35, 'EMP0005', 'CES (Career Executive Service) Eligibility', '82.0', '2024-09-29', 'Leyte Normal University, Tacloban', '1234567', NULL, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(36, 'EMP0012', 'Career Service Sub-Professional', '0.8', '2022-08-12', 'Tacloban City, Leyte', '2554', NULL, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(37, 'EMP0012', 'Career Service Professional', 'N/A', '2023-02-20', 'LTO Borongan, Eastern Samar', 'N08-23-012345', '2028-02-20', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(38, 'EMP0012', 'Driver\'s License (Non-Professional)', '82.5', '2023-03-15', 'Manila, Metro Manila', 'N/A', '2025-05-01', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(39, 'EMP0012', 'RA 1080 (Barangay Official)', '88.0', '2022-05-01', 'Barangay Hall, Borongan City', 'N/A', NULL, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(40, 'EMP0012', 'Career Service Sub-Professional', '0.8', '2021-07-10', 'TESDA Regional Office VIII, Tacloban', 'NC II-08-2021-5678', '2029-03-05', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(41, 'EMP0012', 'Driver\'s License (Professional)', 'N/A', '2024-03-05', 'LTO Borongan, Eastern Samar', 'N08-24-987654', NULL, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(42, 'EMP0012', 'CES (Career Executive Service) Eligibility', '82.0', '2024-09-29', 'Leyte Normal University, Tacloban', '1234567', NULL, '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_designations`
--

CREATE TABLE `employee_designations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `unit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `academic_rank_id` bigint(20) UNSIGNED DEFAULT NULL,
  `staff_grade_id` bigint(20) UNSIGNED DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_designations`
--

INSERT INTO `employee_designations` (`id`, `employee_id`, `unit_id`, `position_id`, `academic_rank_id`, `staff_grade_id`, `is_primary`, `start_date`, `end_date`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'EMP0001', 18, 6, 15, NULL, 1, '2026-01-28', '2028-06-28', NULL, '2026-01-28 04:04:44', '2026-01-29 03:01:14', '2026-01-29 03:01:14'),
(2, 'EMP0001', 147, 9, NULL, NULL, 0, '2026-01-29', '2028-01-29', NULL, '2026-01-29 03:01:46', '2026-01-29 06:41:33', '2026-01-29 06:41:33'),
(3, 'EMP0001', 36, 22, 1, NULL, 1, '2026-01-29', NULL, NULL, '2026-01-29 03:04:49', '2026-01-29 06:41:35', '2026-01-29 06:41:35'),
(4, 'EMP0003', 1, 22, 1, NULL, 1, '2026-01-29', '2028-01-29', NULL, '2026-01-29 04:22:53', '2026-01-29 04:22:53', NULL),
(5, 'EMP0005', 1, 7, 9, NULL, 1, '2026-01-29', '2028-01-29', NULL, '2026-01-29 04:54:51', '2026-01-29 05:06:54', '2026-01-29 05:06:54'),
(6, 'EMP0005', 1, 22, 3, NULL, 1, '2026-01-29', '2028-01-29', NULL, '2026-01-29 05:07:17', '2026-01-29 05:07:17', NULL),
(7, 'EMP0012', 8, 7, 4, NULL, 1, '2026-01-29', '2028-01-29', NULL, '2026-01-29 05:32:40', '2026-01-29 05:32:40', NULL),
(8, 'EMP0001', 144, 9, NULL, NULL, 1, '2026-01-29', '2028-01-29', NULL, '2026-01-29 06:42:08', '2026-01-29 06:42:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_designation_history`
--

CREATE TABLE `employee_designation_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `designation_id` bigint(20) UNSIGNED NOT NULL,
  `field_changed` varchar(50) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `changed_by` varchar(15) DEFAULT NULL,
  `changed_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_designation_history`
--

INSERT INTO `employee_designation_history` (`id`, `designation_id`, `field_changed`, `old_value`, `new_value`, `changed_by`, `changed_at`) VALUES
(1, 3, 'is_primary', NULL, '1', 'EMP0001', '2026-01-29 06:41:33');

-- --------------------------------------------------------

--
-- Table structure for table `employee_documents`
--

CREATE TABLE `employee_documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `mime_type` varchar(255) NOT NULL,
  `file_size` bigint(20) UNSIGNED NOT NULL,
  `uploaded_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_educational_backgrounds`
--

CREATE TABLE `employee_educational_backgrounds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `level` varchar(255) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `degree_course` varchar(255) DEFAULT NULL,
  `period_from` date NOT NULL,
  `period_to` date NOT NULL,
  `highest_level_units` varchar(255) DEFAULT NULL,
  `year_graduated` year(4) DEFAULT NULL,
  `honors_received` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_educational_backgrounds`
--

INSERT INTO `employee_educational_backgrounds` (`id`, `employee_id`, `level`, `school_name`, `degree_course`, `period_from`, `period_to`, `highest_level_units`, `year_graduated`, `honors_received`, `created_at`, `updated_at`) VALUES
(11, 'EMP0001', 'ELEMENTARY', 'Sabang South Elementary School', 'Elementary Level', '2013-01-24', '2018-04-25', 'Grade 6', '2018', 'With High Honors', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(12, 'EMP0001', 'SECONDARY', 'Eastern Samar National Comprehensive High School', 'General Secondary Education', '2021-02-24', '2023-04-25', 'Grade 12', '2023', 'With High Honors', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(13, 'EMP0001', 'VOCATIONAL /                                                                                                                                                                                                        TRADE COURSE', 'ESDA Technology Institutions (TTIs) - government-run schools in various provinces', 'Automotive', '2016-05-28', '2020-04-25', 'NC II Completed', '2020', 'Dean\'s Lister', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(14, 'EMP0001', 'COLLEGE', 'Eastern Samar State University', 'BS in Computer Science', '2023-04-25', '2025-04-25', '4th Year', '2025', 'DOST Scholarship (Department of Science and Technology)', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(15, 'EMP0001', 'GRADUATE STUDIES', 'N/A', 'N/A', '2025-06-15', '2026-01-28', '36 units', '2029', 'Graduate Scholarship', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(16, 'EMP0003', 'ELEMENTARY', 'Sabang South Elementary School', 'Elementary Level', '2013-01-24', '2018-04-25', 'Grade 6', '2018', 'With High Honors', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(17, 'EMP0003', 'SECONDARY', 'Eastern Samar National Comprehensive High School', 'General Secondary Education', '2021-02-24', '2023-04-25', 'Grade 12', '2023', 'With High Honors', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(18, 'EMP0003', 'VOCATIONAL /                                                                                                                                                                                                        TRADE COURSE', 'ESDA Technology Institutions (TTIs) - government-run schools in various provinces', 'Automotive', '2016-05-28', '2020-04-25', 'NC II Completed', '2020', 'Dean\'s Lister', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(19, 'EMP0003', 'COLLEGE', 'Eastern Samar State University', 'BS in Computer Science', '2023-04-25', '2025-04-25', '4th Year', '2025', 'DOST Scholarship (Department of Science and Technology)', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(20, 'EMP0003', 'GRADUATE STUDIES', 'N/A', 'N/A', '2025-06-15', '2026-01-29', '36 units', '2029', 'Graduate Scholarship', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(21, 'EMP0005', 'ELEMENTARY', 'Sabang South Elementary School', 'Elementary Level', '2013-01-24', '2018-04-25', 'Grade 6', '2018', 'With High Honors', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(22, 'EMP0005', 'SECONDARY', 'Eastern Samar National Comprehensive High School', 'General Secondary Education', '2021-02-24', '2023-04-25', 'Grade 12', '2023', 'With High Honors', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(23, 'EMP0005', 'VOCATIONAL /                                                                                                                                                                                                        TRADE COURSE', 'ESDA Technology Institutions (TTIs) - government-run schools in various provinces', 'Automotive', '2016-05-28', '2020-04-25', 'NC II Completed', '2020', 'Dean\'s Lister', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(24, 'EMP0005', 'COLLEGE', 'Eastern Samar State University', 'BS in Computer Science', '2023-04-25', '2025-04-25', '4th Year', '2025', 'DOST Scholarship (Department of Science and Technology)', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(25, 'EMP0005', 'GRADUATE STUDIES', 'N/A', 'N/A', '2025-06-15', '2026-01-29', '36 units', '2029', 'Graduate Scholarship', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(26, 'EMP0012', 'ELEMENTARY', 'Sabang South Elementary School', 'Elementary Level', '2013-01-24', '2018-04-25', 'Grade 6', '2018', 'With High Honors', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(27, 'EMP0012', 'SECONDARY', 'Eastern Samar National Comprehensive High School', 'General Secondary Education', '2021-02-24', '2023-04-25', 'Grade 12', '2023', 'With High Honors', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(28, 'EMP0012', 'VOCATIONAL /                                                                                                                                                                                                        TRADE COURSE', 'ESDA Technology Institutions (TTIs) - government-run schools in various provinces', 'Automotive', '2016-05-28', '2020-04-25', 'NC II Completed', '2020', 'Dean\'s Lister', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(29, 'EMP0012', 'COLLEGE', 'Eastern Samar State University', 'BS in Computer Science', '2023-04-25', '2025-04-25', '4th Year', '2025', 'DOST Scholarship (Department of Science and Technology)', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(30, 'EMP0012', 'GRADUATE STUDIES', 'N/A', 'N/A', '2025-06-15', '2026-01-29', '36 units', '2029', 'Graduate Scholarship', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_family_backgrounds`
--

CREATE TABLE `employee_family_backgrounds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `relation` enum('Father','Mother','Spouse') NOT NULL,
  `surname` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `name_extension` varchar(5) DEFAULT NULL,
  `occupation` varchar(50) DEFAULT NULL,
  `employer` varchar(100) DEFAULT NULL,
  `business_address` varchar(100) DEFAULT NULL,
  `telephone_no` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_family_backgrounds`
--

INSERT INTO `employee_family_backgrounds` (`id`, `employee_id`, `relation`, `surname`, `first_name`, `middle_name`, `name_extension`, `occupation`, `employer`, `business_address`, `telephone_no`, `created_at`, `updated_at`) VALUES
(1, 'EMP0001', 'Spouse', 'Cruz', 'Juan', 'Miguel', '', 'Civil Servant', 'Santos General Merchandise', '123 Mabini Street, Barangay San Isidro, Quezon City, Metro Manila', '9553862699', '2026-01-27 16:32:57', '2026-01-27 16:32:57'),
(2, 'EMP0001', 'Father', 'Martires', 'Edwin', 'Marino', '', '', '', '', '', '2026-01-27 16:32:57', '2026-01-27 16:32:57'),
(3, 'EMP0001', 'Mother', 'Sabungan', 'Derbby', 'Basada', '', '', '', '', '', '2026-01-27 16:32:57', '2026-01-27 16:32:57'),
(4, 'EMP0003', 'Spouse', 'Cruz', 'Juan', 'Miguel', '', 'Civil Servant', 'Santos General Merchandise', '123 Mabini Street, Barangay San Isidro, Quezon City, Metro Manila', '9553862699', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(5, 'EMP0003', 'Father', 'Martires', 'Edwin', 'Marino', '', '', '', '', '', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(6, 'EMP0003', 'Mother', 'Sabungan', 'Derbby', 'Basada', '', '', '', '', '', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(7, 'EMP0005', 'Spouse', 'Cruz', 'Juan', 'Miguel', '', 'Civil Servant', 'Santos General Merchandise', '123 Mabini Street, Barangay San Isidro, Quezon City, Metro Manila', '9553862699', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(8, 'EMP0005', 'Father', 'Martires', 'Edwin', 'Marino', '', '', '', '', '', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(9, 'EMP0005', 'Mother', 'Sabungan', 'Derbby', 'Basada', '', '', '', '', '', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(10, 'EMP0012', 'Spouse', 'Cruz', 'Juan', 'Miguel', '', 'Civil Servant', 'Santos General Merchandise', '123 Mabini Street, Barangay San Isidro, Quezon City, Metro Manila', '9553862699', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(11, 'EMP0012', 'Father', 'Martires', 'Edwin', 'Marino', '', '', '', '', '', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(12, 'EMP0012', 'Mother', 'Sabungan', 'Derbby', 'Basada', '', '', '', '', '', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_grade_changes`
--

CREATE TABLE `employee_grade_changes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `designation_id` bigint(20) UNSIGNED NOT NULL,
  `from_grade_id` bigint(20) UNSIGNED DEFAULT NULL,
  `from_grade_type` varchar(20) DEFAULT NULL,
  `to_grade_id` bigint(20) UNSIGNED NOT NULL,
  `to_grade_type` varchar(20) NOT NULL,
  `change_type` enum('promotion','correction') NOT NULL DEFAULT 'promotion',
  `effective_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `performed_by_employee_id` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_learning_developments`
--

CREATE TABLE `employee_learning_developments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `title` varchar(100) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `hours` int(11) NOT NULL,
  `type_of_ld` enum('Managerial','Supervisory','Technical','Foundation','Others') NOT NULL,
  `conducted_by` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_learning_developments`
--

INSERT INTO `employee_learning_developments` (`id`, `employee_id`, `title`, `date_from`, `date_to`, `hours`, `type_of_ld`, `conducted_by`, `created_at`, `updated_at`) VALUES
(31, 'EMP0001', 'Basic Computer Literacy Training', '2019-03-15', '2019-03-17', 24, 'Technical', 'TESDA Regional Training Center, Region VIII, Tacloban City', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(32, 'EMP0001', 'Customer Service Excellence Seminar', '2019-05-20', '2019-05-21', 16, 'Technical', 'Department of Trade and Industry, Eastern Samar Provincial Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(33, 'EMP0001', 'First Aid and Basic Life Support Training', '2019-10-07', '2019-12-07', 20, 'Technical', 'Philippine Red Cross, Eastern Samar Chapter, Borongan City', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(34, 'EMP0001', 'Leadership and Management Development Program', '2019-05-09', '2019-07-09', 24, 'Managerial', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(35, 'EMP0001', 'Financial Literacy and Entrepreneurship Training', '2019-12-11', '2026-01-28', 18, 'Technical', 'Department of Trade and Industry, Borongan Extension Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(36, 'EMP0001', 'Basic Occupational Safety and Health Seminar', '2020-01-20', '2020-01-21', 16, 'Technical', 'Department of Labor and Employment, Regional Office VIII', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(37, 'EMP0001', 'Records Management and Filing System Training', '2020-10-03', '2020-12-03', 20, 'Technical', 'National Archives of the Philippines, Eastern Visayas Regional Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(38, 'EMP0001', 'Gender and Development Orientation Seminar', '2020-06-15', '2020-06-16', 12, 'Managerial', 'Philippine Commission on Women, Eastern Samar Provincial Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(39, 'EMP0001', 'Strategic Planning and Program Management Workshop', '2020-08-25', '2020-08-27', 24, 'Managerial', 'Department of Interior and Local Government, Region VIII', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(40, 'EMP0001', 'Values Formation and Work Ethics Seminar', '2020-05-10', '2020-06-10', 16, 'Managerial', 'Civil Service Commission, Eastern Samar Field Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(41, 'EMP0001', 'Disaster Risk Reduction and Management Training', '2020-08-12', '2020-10-12', 20, 'Technical', 'Office of Civil Defense, Regional Office VIII, Tacloban City', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(42, 'EMP0001', 'Social Media Marketing and Digital Entrepreneurship', '2022-02-14', '2022-02-16', 18, 'Technical', 'Department of Trade and Industry, E-Commerce Development Unit', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(43, 'EMP0001', 'Conflict Resolution and Mediation Skills Training', '2022-04-20', '2022-04-22', 20, 'Supervisory', 'Philippine Mediation Center, Eastern Visayas Extension Office', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(44, 'EMP0001', 'Performance Management System Training', '2022-11-07', '2026-01-28', 24, 'Supervisory', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(45, 'EMP0001', 'Climate Change Adaptation and Mitigation Seminar', '2022-09-19', '2022-09-21', 18, 'Technical', 'Department of Environment and Natural Resources, Region VIII', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(46, 'EMP0003', 'Basic Computer Literacy Training', '2019-03-15', '2019-03-17', 24, 'Technical', 'TESDA Regional Training Center, Region VIII, Tacloban City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(47, 'EMP0003', 'Customer Service Excellence Seminar', '2019-05-20', '2019-05-21', 16, 'Technical', 'Department of Trade and Industry, Eastern Samar Provincial Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(48, 'EMP0003', 'First Aid and Basic Life Support Training', '2019-10-07', '2019-12-07', 20, 'Technical', 'Philippine Red Cross, Eastern Samar Chapter, Borongan City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(49, 'EMP0003', 'Leadership and Management Development Program', '2019-05-09', '2019-07-09', 24, 'Managerial', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(50, 'EMP0003', 'Financial Literacy and Entrepreneurship Training', '2019-12-11', '2026-01-29', 18, 'Technical', 'Department of Trade and Industry, Borongan Extension Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(51, 'EMP0003', 'Basic Occupational Safety and Health Seminar', '2020-01-20', '2020-01-21', 16, 'Technical', 'Department of Labor and Employment, Regional Office VIII', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(52, 'EMP0003', 'Records Management and Filing System Training', '2020-10-03', '2020-12-03', 20, 'Technical', 'National Archives of the Philippines, Eastern Visayas Regional Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(53, 'EMP0003', 'Gender and Development Orientation Seminar', '2020-06-15', '2020-06-16', 12, 'Managerial', 'Philippine Commission on Women, Eastern Samar Provincial Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(54, 'EMP0003', 'Strategic Planning and Program Management Workshop', '2020-08-25', '2020-08-27', 24, 'Managerial', 'Department of Interior and Local Government, Region VIII', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(55, 'EMP0003', 'Values Formation and Work Ethics Seminar', '2020-05-10', '2020-06-10', 16, 'Managerial', 'Civil Service Commission, Eastern Samar Field Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(56, 'EMP0003', 'Disaster Risk Reduction and Management Training', '2020-08-12', '2020-10-12', 20, 'Technical', 'Office of Civil Defense, Regional Office VIII, Tacloban City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(57, 'EMP0003', 'Social Media Marketing and Digital Entrepreneurship', '2022-02-14', '2022-02-16', 18, 'Technical', 'Department of Trade and Industry, E-Commerce Development Unit', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(58, 'EMP0003', 'Conflict Resolution and Mediation Skills Training', '2022-04-20', '2022-04-22', 20, 'Supervisory', 'Philippine Mediation Center, Eastern Visayas Extension Office', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(59, 'EMP0003', 'Performance Management System Training', '2022-11-07', '2026-01-29', 24, 'Supervisory', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(60, 'EMP0003', 'Climate Change Adaptation and Mitigation Seminar', '2022-09-19', '2022-09-21', 18, 'Technical', 'Department of Environment and Natural Resources, Region VIII', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(61, 'EMP0005', 'Basic Computer Literacy Training', '2019-03-15', '2019-03-17', 24, 'Technical', 'TESDA Regional Training Center, Region VIII, Tacloban City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(62, 'EMP0005', 'Customer Service Excellence Seminar', '2019-05-20', '2019-05-21', 16, 'Technical', 'Department of Trade and Industry, Eastern Samar Provincial Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(63, 'EMP0005', 'First Aid and Basic Life Support Training', '2019-10-07', '2019-12-07', 20, 'Technical', 'Philippine Red Cross, Eastern Samar Chapter, Borongan City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(64, 'EMP0005', 'Leadership and Management Development Program', '2019-05-09', '2019-07-09', 24, 'Managerial', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(65, 'EMP0005', 'Financial Literacy and Entrepreneurship Training', '2019-12-11', '2026-01-29', 18, 'Technical', 'Department of Trade and Industry, Borongan Extension Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(66, 'EMP0005', 'Basic Occupational Safety and Health Seminar', '2020-01-20', '2020-01-21', 16, 'Technical', 'Department of Labor and Employment, Regional Office VIII', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(67, 'EMP0005', 'Records Management and Filing System Training', '2020-10-03', '2020-12-03', 20, 'Technical', 'National Archives of the Philippines, Eastern Visayas Regional Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(68, 'EMP0005', 'Gender and Development Orientation Seminar', '2020-06-15', '2020-06-16', 12, 'Managerial', 'Philippine Commission on Women, Eastern Samar Provincial Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(69, 'EMP0005', 'Strategic Planning and Program Management Workshop', '2020-08-25', '2020-08-27', 24, 'Managerial', 'Department of Interior and Local Government, Region VIII', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(70, 'EMP0005', 'Values Formation and Work Ethics Seminar', '2020-05-10', '2020-06-10', 16, 'Managerial', 'Civil Service Commission, Eastern Samar Field Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(71, 'EMP0005', 'Disaster Risk Reduction and Management Training', '2020-08-12', '2020-10-12', 20, 'Technical', 'Office of Civil Defense, Regional Office VIII, Tacloban City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(72, 'EMP0005', 'Social Media Marketing and Digital Entrepreneurship', '2022-02-14', '2022-02-16', 18, 'Technical', 'Department of Trade and Industry, E-Commerce Development Unit', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(73, 'EMP0005', 'Conflict Resolution and Mediation Skills Training', '2022-04-20', '2022-04-22', 20, 'Supervisory', 'Philippine Mediation Center, Eastern Visayas Extension Office', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(74, 'EMP0005', 'Performance Management System Training', '2022-11-07', '2026-01-29', 24, 'Supervisory', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(75, 'EMP0005', 'Climate Change Adaptation and Mitigation Seminar', '2022-09-19', '2022-09-21', 18, 'Technical', 'Department of Environment and Natural Resources, Region VIII', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(76, 'EMP0012', 'Basic Computer Literacy Training', '2019-03-15', '2019-03-17', 24, 'Technical', 'TESDA Regional Training Center, Region VIII, Tacloban City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(77, 'EMP0012', 'Customer Service Excellence Seminar', '2019-05-20', '2019-05-21', 16, 'Technical', 'Department of Trade and Industry, Eastern Samar Provincial Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(78, 'EMP0012', 'First Aid and Basic Life Support Training', '2019-10-07', '2019-12-07', 20, 'Technical', 'Philippine Red Cross, Eastern Samar Chapter, Borongan City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(79, 'EMP0012', 'Leadership and Management Development Program', '2019-05-09', '2019-07-09', 24, 'Managerial', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(80, 'EMP0012', 'Financial Literacy and Entrepreneurship Training', '2019-12-11', '2026-01-29', 18, 'Technical', 'Department of Trade and Industry, Borongan Extension Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(81, 'EMP0012', 'Basic Occupational Safety and Health Seminar', '2020-01-20', '2020-01-21', 16, 'Technical', 'Department of Labor and Employment, Regional Office VIII', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(82, 'EMP0012', 'Records Management and Filing System Training', '2020-10-03', '2020-12-03', 20, 'Technical', 'National Archives of the Philippines, Eastern Visayas Regional Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(83, 'EMP0012', 'Gender and Development Orientation Seminar', '2020-06-15', '2020-06-16', 12, 'Managerial', 'Philippine Commission on Women, Eastern Samar Provincial Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(84, 'EMP0012', 'Strategic Planning and Program Management Workshop', '2020-08-25', '2020-08-27', 24, 'Managerial', 'Department of Interior and Local Government, Region VIII', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(85, 'EMP0012', 'Values Formation and Work Ethics Seminar', '2020-05-10', '2020-06-10', 16, 'Managerial', 'Civil Service Commission, Eastern Samar Field Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(86, 'EMP0012', 'Disaster Risk Reduction and Management Training', '2020-08-12', '2020-10-12', 20, 'Technical', 'Office of Civil Defense, Regional Office VIII, Tacloban City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(87, 'EMP0012', 'Social Media Marketing and Digital Entrepreneurship', '2022-02-14', '2022-02-16', 18, 'Technical', 'Department of Trade and Industry, E-Commerce Development Unit', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(88, 'EMP0012', 'Conflict Resolution and Mediation Skills Training', '2022-04-20', '2022-04-22', 20, 'Supervisory', 'Philippine Mediation Center, Eastern Visayas Extension Office', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(89, 'EMP0012', 'Performance Management System Training', '2022-11-07', '2026-01-29', 24, 'Supervisory', 'Civil Service Commission, Regional Office VIII, Tacloban City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(90, 'EMP0012', 'Climate Change Adaptation and Mitigation Seminar', '2022-09-19', '2022-09-21', 18, 'Technical', 'Department of Environment and Natural Resources, Region VIII', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_other_information`
--

CREATE TABLE `employee_other_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `skill_or_hobby` text DEFAULT NULL,
  `non_academic_distinctions` text DEFAULT NULL,
  `memberships` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_other_information`
--

INSERT INTO `employee_other_information` (`id`, `employee_id`, `skill_or_hobby`, `non_academic_distinctions`, `memberships`, `created_at`, `updated_at`) VALUES
(1, 'EMP0001', 'Computer Programming (Python, Java), Graphic Design using Adobe Photoshop, Video Editing, Playing Guitar, Photography, Basketball, Cooking\nMicrosoft Office (Word, Excel, PowerPoint), Social Media Management, Public Speaking, Singing, Reading Novels, Volleyball\nData Entry and Analysis, Report Writing, Customer Service, Dancing, Gardening,', 'Outstanding Employee of the Year 2022 - Municipal Government of Borongan, Eastern Samar', 'Philippine Association of Government Employees (PAGE), Eastern Samar Chapter\nIntegrated Government Employees Association (IGEA), Region VIII\nCivil Service Employees Association (CSEA), Eastern Samar Chapter\nYoung Professionals Organization of Eastern Samar (YPOES)\nEastern Samar Government Employees Multi-Purpose Cooperative (ESGEMPC)\nKnights of Columbus, Borongan Council No. 1234\nAssociation of Local Government Employees Union (ALGEU), Borongan City Chapter', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(2, 'EMP0003', 'Computer Programming (Python, Java), Graphic Design using Adobe Photoshop, Video Editing, Playing Guitar, Photography,', 'Outstanding Employee of the Year 2022 - Municipal Government of Borongan, Eastern Samar', 'Philippine Association of Government Employees (PAGE), Eastern Samar Chapter\nIntegrated Government Employees Association (IGEA), Region VIII\nCivil Service Employees Association (CSEA), Eastern Samar Chapter\nYoung Professionals Organization of Eastern Samar (YPOES)\nEastern Samar Government Employees Multi-Purpose Cooperative (ESGEMPC)\nKnights of Columbus, Borongan Council No. 1234\nAssociation of Local Government Employees Union (ALGEU), Borongan City Chapter', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(3, 'EMP0005', 'Computer Programming (Python, Java), Graphic Design using Adobe Photoshop, Video', 'Outstanding Employee of the Year 2022 - Municipal Government of Borongan, Eastern 23', 'Philippine Association of Government Employees (PAGE), Eastern Samar Chapter\nIntegrated Government Employees Association (IGEA), Region VIII\nCivil Service Employees Association (CSEA), Eastern Samar Chapter\nYoung Professionals Organization of Eastern Samar (YPOES)\nEastern Samar Government Employees Multi-Purpose Cooperative (ESGEMPC)\nKnights of Columbus, Borongan Council No. 1234\nAssociation of Local Government Employees Union (ALGEU), Borongan City Chapter', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(4, 'EMP0012', 'Computer Programming (Python, Java), Graphic Design using Adobe Photoshop, Video Editing, Playing Guitar, Photography,', 'Outstanding Employee of the Year 2022 - Municipal Government of Borongan, Eastern', 'Philippine Association of Government Employees (PAGE), Eastern Samar Chapter\nIntegrated Government Employees Association (IGEA), Region VIII\nCivil Service Employees Association (CSEA), Eastern Samar Chapter\nYoung Professionals Organization of Eastern Samar (YPOES)\nEastern Samar Government Employees Multi-Purpose Cooperative (ESGEMPC)\nKnights of Columbus, Borongan Council No. 1234\nAssociation of Local Government Employees Union (ALGEU), Borongan City Chapter', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_promotions`
--

CREATE TABLE `employee_promotions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `from_staff_grade_id` bigint(20) UNSIGNED DEFAULT NULL,
  `to_staff_grade_id` bigint(20) UNSIGNED NOT NULL,
  `effective_date` date NOT NULL,
  `promoted_by` varchar(15) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `document_ref` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_rank_promotions`
--

CREATE TABLE `employee_rank_promotions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `from_academic_rank_id` bigint(20) UNSIGNED DEFAULT NULL,
  `to_academic_rank_id` bigint(20) UNSIGNED NOT NULL,
  `effective_date` date NOT NULL,
  `promoted_by` varchar(15) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `document_ref` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee_voluntary_works`
--

CREATE TABLE `employee_voluntary_works` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `organization_name` varchar(100) NOT NULL,
  `organization_address` varchar(100) DEFAULT NULL,
  `date_from` date NOT NULL,
  `date_to` date DEFAULT NULL,
  `hours_rendered` int(11) NOT NULL,
  `position_or_nature` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_voluntary_works`
--

INSERT INTO `employee_voluntary_works` (`id`, `employee_id`, `organization_name`, `organization_address`, `date_from`, `date_to`, `hours_rendered`, `position_or_nature`, `created_at`, `updated_at`) VALUES
(15, 'EMP0001', 'Red Cross Youth Council, Borongan City Chapter, Borongan City, Eastern Samar', NULL, '2020-01-15', '2020-05-30', 180, 'Volunteer - Disaster Response Team Member', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(16, 'EMP0001', 'Caritas Philippines, Diocese of Borongan, J. Lukban Street, Borongan City', NULL, '2020-01-07', '2021-06-30', 240, 'Volunteer - Community Feeding Program Coordinator', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(17, 'EMP0001', 'Sangguniang Kabataan Federation, Municipal Hall, Borongan City, Eastern Samar', NULL, '2021-08-15', '2021-12-20', 520, 'SK Kagawad - Youth Development Officer', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(18, 'EMP0001', 'Parish Pastoral Council, San Jose Parish Church, Borongan City, Eastern Samar', NULL, '2022-10-01', '2026-01-28', 160, 'Volunteer - Catechism Teacher', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(19, 'EMP0001', 'Borongan City Environmental Council, City Hall, Borongan City, Eastern Samar', NULL, '2022-07-15', '2022-12-31', 200, 'Volunteer - Coastal Cleanup Organizer', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(20, 'EMP0001', 'Philippine National Red Cross, Eastern Samar Chapter, Real Street, Borongan City', NULL, '2023-05-01', '2023-05-31', 280, 'Volunteer - First Aid Training Facilitator', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(21, 'EMP0001', 'Lions Club of Borongan, Borongan City, Eastern Samar', NULL, '2023-01-06', '2023-10-31', 150, 'Member - Medical Mission Volunteer', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(22, 'EMP0003', 'Red Cross Youth Council, Borongan City Chapter, Borongan City, Eastern Samar', NULL, '2020-01-15', '2020-05-30', 180, 'Volunteer - Disaster Response Team Member', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(23, 'EMP0003', 'Caritas Philippines, Diocese of Borongan, J. Lukban Street, Borongan City', NULL, '2020-01-07', '2021-06-30', 240, 'Volunteer - Community Feeding Program Coordinator', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(24, 'EMP0003', 'Sangguniang Kabataan Federation, Municipal Hall, Borongan City, Eastern Samar', NULL, '2021-08-15', '2021-12-20', 520, 'SK Kagawad - Youth Development Officer', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(25, 'EMP0003', 'Parish Pastoral Council, San Jose Parish Church, Borongan City, Eastern Samar', NULL, '2022-10-01', '2026-01-29', 160, 'Volunteer - Catechism Teacher', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(26, 'EMP0003', 'Borongan City Environmental Council, City Hall, Borongan City, Eastern Samar', NULL, '2022-07-15', '2022-12-31', 200, 'Volunteer - Coastal Cleanup Organizer', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(27, 'EMP0003', 'Philippine National Red Cross, Eastern Samar Chapter, Real Street, Borongan City', NULL, '2023-05-01', '2023-05-31', 280, 'Volunteer - First Aid Training Facilitator', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(28, 'EMP0003', 'Lions Club of Borongan, Borongan City, Eastern Samar', NULL, '2023-01-06', '2023-10-31', 150, 'Member - Medical Mission Volunteer', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(29, 'EMP0005', 'Red Cross Youth Council, Borongan City Chapter, Borongan City, Eastern Samar', NULL, '2020-01-15', '2020-05-30', 180, 'Volunteer - Disaster Response Team Member', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(30, 'EMP0005', 'Caritas Philippines, Diocese of Borongan, J. Lukban Street, Borongan City', NULL, '2020-01-07', '2021-06-30', 240, 'Volunteer - Community Feeding Program Coordinator', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(31, 'EMP0005', 'Sangguniang Kabataan Federation, Municipal Hall, Borongan City, Eastern Samar', NULL, '2021-08-15', '2021-12-20', 520, 'SK Kagawad - Youth Development Officer', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(32, 'EMP0005', 'Parish Pastoral Council, San Jose Parish Church, Borongan City, Eastern Samar', NULL, '2022-10-01', '2026-01-29', 160, 'Volunteer - Catechism Teacher', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(33, 'EMP0005', 'Borongan City Environmental Council, City Hall, Borongan City, Eastern Samar', NULL, '2022-07-15', '2022-12-31', 200, 'Volunteer - Coastal Cleanup Organizer', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(34, 'EMP0005', 'Philippine National Red Cross, Eastern Samar Chapter, Real Street, Borongan City', NULL, '2023-05-01', '2023-05-31', 280, 'Volunteer - First Aid Training Facilitator', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(35, 'EMP0005', 'Lions Club of Borongan, Borongan City, Eastern Samar', NULL, '2023-01-06', '2023-10-31', 150, 'Member - Medical Mission Volunteer', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(36, 'EMP0012', 'Red Cross Youth Council, Borongan City Chapter, Borongan City, Eastern Samar', NULL, '2020-01-15', '2020-05-30', 180, 'Volunteer - Disaster Response Team Member', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(37, 'EMP0012', 'Caritas Philippines, Diocese of Borongan, J. Lukban Street, Borongan City', NULL, '2020-01-07', '2021-06-30', 240, 'Volunteer - Community Feeding Program Coordinator', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(38, 'EMP0012', 'Sangguniang Kabataan Federation, Municipal Hall, Borongan City, Eastern Samar', NULL, '2021-08-15', '2021-12-20', 520, 'SK Kagawad - Youth Development Officer', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(39, 'EMP0012', 'Parish Pastoral Council, San Jose Parish Church, Borongan City, Eastern Samar', NULL, '2022-10-01', '2026-01-29', 160, 'Volunteer - Catechism Teacher', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(40, 'EMP0012', 'Borongan City Environmental Council, City Hall, Borongan City, Eastern Samar', NULL, '2022-07-15', '2022-12-31', 200, 'Volunteer - Coastal Cleanup Organizer', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(41, 'EMP0012', 'Philippine National Red Cross, Eastern Samar Chapter, Real Street, Borongan City', NULL, '2023-05-01', '2023-05-31', 280, 'Volunteer - First Aid Training Facilitator', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(42, 'EMP0012', 'Lions Club of Borongan, Borongan City, Eastern Samar', NULL, '2023-01-06', '2023-10-31', 150, 'Member - Medical Mission Volunteer', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `employee_work_experiences`
--

CREATE TABLE `employee_work_experiences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `position_title` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_address` varchar(100) DEFAULT NULL,
  `date_from` date NOT NULL,
  `date_to` date DEFAULT NULL,
  `monthly_salary` decimal(10,2) DEFAULT NULL,
  `salary_grade_step` varchar(7) DEFAULT NULL,
  `status_of_appointment` varchar(20) NOT NULL,
  `is_gov_service` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_work_experiences`
--

INSERT INTO `employee_work_experiences` (`id`, `employee_id`, `position_title`, `company_name`, `company_address`, `date_from`, `date_to`, `monthly_salary`, `salary_grade_step`, `status_of_appointment`, `is_gov_service`, `created_at`, `updated_at`) VALUES
(57, 'EMP0001', 'Cashier', 'SM City Borongan', NULL, '2024-11-24', '2024-11-24', 8000.00, 'N/A', 'Contractual', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(58, 'EMP0001', 'Sales Associate', 'SM City Borongan', NULL, '2020-01-15', '2020-12-31', 12000.00, 'N/A', 'Contractual', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(59, 'EMP0001', 'Customer Service Representative', 'Jollibee Borongan Branch', NULL, '2021-01-02', '2021-08-15', 13500.00, 'N/A', 'Regular', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(60, 'EMP0001', 'Administrative Assistant', 'Municipal Hall of Borongan', NULL, '2021-01-09', '2022-03-31', 15000.00, 'SG 8-1', 'Permanent', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(61, 'EMP0001', 'Computer Technician', 'Eastern Samar State University', NULL, '2022-04-15', '2022-10-30', 18000.00, 'SG 10-2', 'Job Order', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(62, 'EMP0001', 'Cashier', 'Puregold Borongan', NULL, '2022-01-11', '2023-05-31', 14000.00, 'N/A', 'Regular', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(63, 'EMP0001', 'Data Encoder', 'Department of Education Division Office', NULL, '2023-06-15', '2023-12-20', 16500.00, 'SG 6-1', 'Contract of Service', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(64, 'EMP0001', 'Call Center Agent', 'Concentrix Manila', NULL, '2024-10-01', '2026-01-28', 22000.00, 'N/A', 'Regular', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(65, 'EMP0001', 'Administrative Aide IV', 'Barangay Hall San Jose', NULL, '2024-01-07', NULL, 17000.00, 'SG 9-1', 'Permanent', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(66, 'EMP0001', 'Waiter', 'Mang Inasal Tacloban', NULL, '2019-01-03', '2019-08-31', 11000.00, 'N/A', 'Contractual', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(67, 'EMP0001', 'Store Clerk', '7-Eleven Borongan', NULL, '2019-09-15', '2019-12-31', 11500.00, 'N/A', 'Part-time', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(68, 'EMP0001', 'Utility Worker', 'Provincial Capitol of Eastern Samar', NULL, '2020-05-01', '2020-06-30', 13000.00, 'SG 1-1', 'Job Order', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(69, 'EMP0001', 'Security Guard', 'Guardline Security Agency', NULL, '2020-01-07', '2020-12-15', 14500.00, 'N/A', 'Regular', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(70, 'EMP0001', 'Barangay Tanod', 'Foodpanda Borongan', NULL, '2021-10-01', '2026-01-28', 15000.00, 'N/A', 'Freelance', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(71, 'EMP0001', 'Delivery Rider', 'Borongan Central Elementary School', NULL, '2021-06-01', '2021-11-30', 12000.00, 'N/A', 'Volunteer', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(72, 'EMP0001', 'Teacher Aide', 'Department of Agriculture Regional Office', NULL, '2021-01-12', '2022-04-30', 13500.00, 'SG 3-1', 'Seasonal', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(73, 'EMP0001', 'Farm Worker', 'DPWH Eastern Samar District', NULL, '2022-05-15', '2022-09-30', 16000.00, 'N/A', 'Project-based', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(74, 'EMP0001', 'Construction Worker', 'Construction Worker', NULL, '2022-01-10', '2023-02-28', 13000.00, 'N/A', 'Contractual', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(75, 'EMP0001', 'Warehouse Staff', 'LBC Borongan Branch', NULL, '2023-03-15', '2023-07-31', 13000.00, 'N/A', 'Contractual', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(76, 'EMP0001', 'Janitress', 'City Health Office Borongan', NULL, '2023-01-08', '2023-12-31', 11500.00, 'SG 1-1', 'Job Order', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(77, 'EMP0001', 'Sales Representative', 'Smart Communications Borongan', NULL, '2024-01-15', '2024-05-30', 18000.00, 'N/A', 'Regular', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(78, 'EMP0001', 'Records Officer I', 'Philippine Statistics Authority Eastern Samar', NULL, '2024-01-06', '2024-10-15', 19500.00, 'SG 11-1', 'Permanent', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(79, 'EMP0001', 'Bookkeeper', 'Maria\'s Sari-Sari Store', NULL, '2024-10-16', NULL, 12000.00, 'N/A', 'Self-employed', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(80, 'EMP0001', 'Kitchen Helper', 'Chowking Tacloban', NULL, '2018-01-02', '2018-07-31', 10500.00, 'N/A', 'Contractual', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(81, 'EMP0001', 'Tricycle Driver', 'Self-employed', NULL, '2018-08-15', '2018-12-31', 9000.00, 'N/A', 'Self-employed', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(82, 'EMP0001', 'Street Sweeper', 'City Government of Borongan', NULL, '2019-10-01', '2026-01-28', 10000.00, 'SG 1-1', 'Job Order', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(83, 'EMP0001', 'Encoder', 'Bureau of Internal Revenue Borongan', NULL, '2019-01-07', '2019-11-30', 14000.00, 'SG 5-1', 'Contract of Service', 1, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(84, 'EMP0001', 'Pharmacy Assistant', 'Mercury Drug Borongan', NULL, '2019-12-15', '2020-05-31', 13000.00, 'N/A', 'Regular', 0, '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(85, 'EMP0003', 'Cashier', 'SM City Borongan', NULL, '2024-11-24', '2024-11-24', 8000.00, 'N/A', 'Contractual', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(86, 'EMP0003', 'Sales Associate', 'SM City Borongan', NULL, '2020-01-15', '2020-12-31', 12000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(87, 'EMP0003', 'Customer Service Representative', 'Jollibee Borongan Branch', NULL, '2021-01-02', '2021-08-15', 13500.00, 'N/A', 'Regular', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(88, 'EMP0003', 'Administrative Assistant', 'Municipal Hall of Borongan', NULL, '2021-01-09', '2022-03-31', 15000.00, 'SG 8-1', 'Permanent', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(89, 'EMP0003', 'Computer Technician', 'Eastern Samar State University', NULL, '2022-04-15', '2022-10-30', 18000.00, 'SG 10-2', 'Job Order', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(90, 'EMP0003', 'Cashier', 'Puregold Borongan', NULL, '2022-01-11', '2023-05-31', 14000.00, 'N/A', 'Regular', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(91, 'EMP0003', 'Data Encoder', 'Department of Education Division Office', NULL, '2023-06-15', '2023-12-20', 16500.00, 'SG 6-1', 'Contract of Service', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(92, 'EMP0003', 'Call Center Agent', 'Concentrix Manila', NULL, '2024-10-01', '2026-01-29', 22000.00, 'N/A', 'Regular', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(93, 'EMP0003', 'Administrative Aide IV', 'Barangay Hall San Jose', NULL, '2024-01-07', NULL, 17000.00, 'SG 9-1', 'Permanent', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(94, 'EMP0003', 'Waiter', 'Mang Inasal Tacloban', NULL, '2019-01-03', '2019-08-31', 11000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(95, 'EMP0003', 'Store Clerk', '7-Eleven Borongan', NULL, '2019-09-15', '2019-12-31', 11500.00, 'N/A', 'Part-time', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(96, 'EMP0003', 'Utility Worker', 'Provincial Capitol of Eastern Samar', NULL, '2020-05-01', '2020-06-30', 13000.00, 'SG 1-1', 'Job Order', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(97, 'EMP0003', 'Security Guard', 'Guardline Security Agency', NULL, '2020-01-07', '2020-12-15', 14500.00, 'N/A', 'Regular', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(98, 'EMP0003', 'Barangay Tanod', 'Foodpanda Borongan', NULL, '2021-10-01', '2026-01-29', 15000.00, 'N/A', 'Freelance', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(99, 'EMP0003', 'Delivery Rider', 'Borongan Central Elementary School', NULL, '2021-06-01', '2021-11-30', 12000.00, 'N/A', 'Volunteer', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(100, 'EMP0003', 'Teacher Aide', 'Department of Agriculture Regional Office', NULL, '2021-01-12', '2022-04-30', 13500.00, 'SG 3-1', 'Seasonal', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(101, 'EMP0003', 'Farm Worker', 'DPWH Eastern Samar District', NULL, '2022-05-15', '2022-09-30', 16000.00, 'N/A', 'Project-based', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(102, 'EMP0003', 'Construction Worker', 'Construction Worker', NULL, '2022-01-10', '2023-02-28', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(103, 'EMP0003', 'Warehouse Staff', 'LBC Borongan Branch', NULL, '2023-03-15', '2023-07-31', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(104, 'EMP0003', 'Janitress', 'City Health Office Borongan', NULL, '2023-01-08', '2023-12-31', 11500.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(105, 'EMP0003', 'Sales Representative', 'Smart Communications Borongan', NULL, '2024-01-15', '2024-05-30', 18000.00, 'N/A', 'Regular', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(106, 'EMP0003', 'Records Officer I', 'Philippine Statistics Authority Eastern Samar', NULL, '2024-01-06', '2024-10-15', 19500.00, 'SG 11-1', 'Permanent', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(107, 'EMP0003', 'Bookkeeper', 'Maria\'s Sari-Sari Store', NULL, '2024-10-16', NULL, 12000.00, 'N/A', 'Self-employed', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(108, 'EMP0003', 'Kitchen Helper', 'Chowking Tacloban', NULL, '2018-01-02', '2018-07-31', 10500.00, 'N/A', 'Contractual', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(109, 'EMP0003', 'Tricycle Driver', 'Self-employed', NULL, '2018-08-15', '2018-12-31', 9000.00, 'N/A', 'Self-employed', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(110, 'EMP0003', 'Street Sweeper', 'City Government of Borongan', NULL, '2019-10-01', '2026-01-29', 10000.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(111, 'EMP0003', 'Encoder', 'Bureau of Internal Revenue Borongan', NULL, '2019-01-07', '2019-11-30', 14000.00, 'SG 5-1', 'Contract of Service', 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(112, 'EMP0003', 'Pharmacy Assistant', 'Mercury Drug Borongan', NULL, '2019-12-15', '2020-05-31', 13000.00, 'N/A', 'Regular', 0, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(113, 'EMP0005', 'Cashier', 'SM City Borongan', NULL, '2024-11-24', '2024-11-24', 8000.00, 'N/A', 'Contractual', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(114, 'EMP0005', 'Sales Associate', 'SM City Borongan', NULL, '2020-01-15', '2020-12-31', 12000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(115, 'EMP0005', 'Customer Service Representative', 'Jollibee Borongan Branch', NULL, '2021-01-02', '2021-08-15', 13500.00, 'N/A', 'Regular', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(116, 'EMP0005', 'Administrative Assistant', 'Municipal Hall of Borongan', NULL, '2021-01-09', '2022-03-31', 15000.00, 'SG 8-1', 'Permanent', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(117, 'EMP0005', 'Computer Technician', 'Eastern Samar State University', NULL, '2022-04-15', '2022-10-30', 18000.00, 'SG 10-2', 'Job Order', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(118, 'EMP0005', 'Cashier', 'Puregold Borongan', NULL, '2022-01-11', '2023-05-31', 14000.00, 'N/A', 'Regular', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(119, 'EMP0005', 'Data Encoder', 'Department of Education Division Office', NULL, '2023-06-15', '2023-12-20', 16500.00, 'SG 6-1', 'Contract of Service', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(120, 'EMP0005', 'Call Center Agent', 'Concentrix Manila', NULL, '2024-10-01', '2026-01-29', 22000.00, 'N/A', 'Regular', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(121, 'EMP0005', 'Administrative Aide IV', 'Barangay Hall San Jose', NULL, '2024-01-07', NULL, 17000.00, 'SG 9-1', 'Permanent', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(122, 'EMP0005', 'Waiter', 'Mang Inasal Tacloban', NULL, '2019-01-03', '2019-08-31', 11000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(123, 'EMP0005', 'Store Clerk', '7-Eleven Borongan', NULL, '2019-09-15', '2019-12-31', 11500.00, 'N/A', 'Part-time', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(124, 'EMP0005', 'Utility Worker', 'Provincial Capitol of Eastern Samar', NULL, '2020-05-01', '2020-06-30', 13000.00, 'SG 1-1', 'Job Order', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(125, 'EMP0005', 'Security Guard', 'Guardline Security Agency', NULL, '2020-01-07', '2020-12-15', 14500.00, 'N/A', 'Regular', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(126, 'EMP0005', 'Barangay Tanod', 'Foodpanda Borongan', NULL, '2021-10-01', '2026-01-29', 15000.00, 'N/A', 'Freelance', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(127, 'EMP0005', 'Delivery Rider', 'Borongan Central Elementary School', NULL, '2021-06-01', '2021-11-30', 12000.00, 'N/A', 'Volunteer', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(128, 'EMP0005', 'Teacher Aide', 'Department of Agriculture Regional Office', NULL, '2021-01-12', '2022-04-30', 13500.00, 'SG 3-1', 'Seasonal', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(129, 'EMP0005', 'Farm Worker', 'DPWH Eastern Samar District', NULL, '2022-05-15', '2022-09-30', 16000.00, 'N/A', 'Project-based', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(130, 'EMP0005', 'Construction Worker', 'Construction Worker', NULL, '2022-01-10', '2023-02-28', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(131, 'EMP0005', 'Warehouse Staff', 'LBC Borongan Branch', NULL, '2023-03-15', '2023-07-31', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(132, 'EMP0005', 'Janitress', 'City Health Office Borongan', NULL, '2023-01-08', '2023-12-31', 11500.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(133, 'EMP0005', 'Sales Representative', 'Smart Communications Borongan', NULL, '2024-01-15', '2024-05-30', 18000.00, 'N/A', 'Regular', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(134, 'EMP0005', 'Records Officer I', 'Philippine Statistics Authority Eastern Samar', NULL, '2024-01-06', '2024-10-15', 19500.00, 'SG 11-1', 'Permanent', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(135, 'EMP0005', 'Bookkeeper', 'Maria\'s Sari-Sari Store', NULL, '2024-10-16', NULL, 12000.00, 'N/A', 'Self-employed', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(136, 'EMP0005', 'Kitchen Helper', 'Chowking Tacloban', NULL, '2018-01-02', '2018-07-31', 10500.00, 'N/A', 'Contractual', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(137, 'EMP0005', 'Tricycle Driver', 'Self-employed', NULL, '2018-08-15', '2018-12-31', 9000.00, 'N/A', 'Self-employed', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(138, 'EMP0005', 'Street Sweeper', 'City Government of Borongan', NULL, '2019-10-01', '2026-01-29', 10000.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(139, 'EMP0005', 'Encoder', 'Bureau of Internal Revenue Borongan', NULL, '2019-01-07', '2019-11-30', 14000.00, 'SG 5-1', 'Contract of Service', 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(140, 'EMP0005', 'Pharmacy Assistant', 'Mercury Drug Borongan', NULL, '2019-12-15', '2020-05-31', 13000.00, 'N/A', 'Regular', 0, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(141, 'EMP0012', 'Cashier', 'SM City Borongan', NULL, '2024-11-24', '2024-11-24', 8000.00, 'N/A', 'Contractual', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(142, 'EMP0012', 'Sales Associate', 'SM City Borongan', NULL, '2020-01-15', '2020-12-31', 12000.00, 'N/A', 'Contractual', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(143, 'EMP0012', 'Customer Service Representative', 'Jollibee Borongan Branch', NULL, '2021-01-02', '2021-08-15', 13500.00, 'N/A', 'Regular', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(144, 'EMP0012', 'Administrative Assistant', 'Municipal Hall of Borongan', NULL, '2021-01-09', '2022-03-31', 15000.00, 'SG 8-1', 'Permanent', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(145, 'EMP0012', 'Computer Technician', 'Eastern Samar State University', NULL, '2022-04-15', '2022-10-30', 18000.00, 'SG 10-2', 'Job Order', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(146, 'EMP0012', 'Cashier', 'Puregold Borongan', NULL, '2022-01-11', '2023-05-31', 14000.00, 'N/A', 'Regular', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(147, 'EMP0012', 'Data Encoder', 'Department of Education Division Office', NULL, '2023-06-15', '2023-12-20', 16500.00, 'SG 6-1', 'Contract of Service', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(148, 'EMP0012', 'Call Center Agent', 'Concentrix Manila', NULL, '2024-10-01', '2026-01-29', 22000.00, 'N/A', 'Regular', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(149, 'EMP0012', 'Administrative Aide IV', 'Barangay Hall San Jose', NULL, '2024-01-07', NULL, 17000.00, 'SG 9-1', 'Permanent', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(150, 'EMP0012', 'Waiter', 'Mang Inasal Tacloban', NULL, '2019-01-03', '2019-08-31', 11000.00, 'N/A', 'Contractual', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(151, 'EMP0012', 'Store Clerk', '7-Eleven Borongan', NULL, '2019-09-15', '2019-12-31', 11500.00, 'N/A', 'Part-time', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(152, 'EMP0012', 'Utility Worker', 'Provincial Capitol of Eastern Samar', NULL, '2020-05-01', '2020-06-30', 13000.00, 'SG 1-1', 'Job Order', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(153, 'EMP0012', 'Security Guard', 'Guardline Security Agency', NULL, '2020-01-07', '2020-12-15', 14500.00, 'N/A', 'Regular', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(154, 'EMP0012', 'Barangay Tanod', 'Foodpanda Borongan', NULL, '2021-10-01', '2026-01-29', 15000.00, 'N/A', 'Freelance', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(155, 'EMP0012', 'Delivery Rider', 'Borongan Central Elementary School', NULL, '2021-06-01', '2021-11-30', 12000.00, 'N/A', 'Volunteer', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(156, 'EMP0012', 'Teacher Aide', 'Department of Agriculture Regional Office', NULL, '2021-01-12', '2022-04-30', 13500.00, 'SG 3-1', 'Seasonal', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(157, 'EMP0012', 'Farm Worker', 'DPWH Eastern Samar District', NULL, '2022-05-15', '2022-09-30', 16000.00, 'N/A', 'Project-based', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(158, 'EMP0012', 'Construction Worker', 'Construction Worker', NULL, '2022-01-10', '2023-02-28', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(159, 'EMP0012', 'Warehouse Staff', 'LBC Borongan Branch', NULL, '2023-03-15', '2023-07-31', 13000.00, 'N/A', 'Contractual', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(160, 'EMP0012', 'Janitress', 'City Health Office Borongan', NULL, '2023-01-08', '2023-12-31', 11500.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(161, 'EMP0012', 'Sales Representative', 'Smart Communications Borongan', NULL, '2024-01-15', '2024-05-30', 18000.00, 'N/A', 'Regular', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(162, 'EMP0012', 'Records Officer I', 'Philippine Statistics Authority Eastern Samar', NULL, '2024-01-06', '2024-10-15', 19500.00, 'SG 11-1', 'Permanent', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(163, 'EMP0012', 'Bookkeeper', 'Maria\'s Sari-Sari Store', NULL, '2024-10-16', NULL, 12000.00, 'N/A', 'Self-employed', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(164, 'EMP0012', 'Kitchen Helper', 'Chowking Tacloban', NULL, '2018-01-02', '2018-07-31', 10500.00, 'N/A', 'Contractual', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(165, 'EMP0012', 'Tricycle Driver', 'Self-employed', NULL, '2018-08-15', '2018-12-31', 9000.00, 'N/A', 'Self-employed', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(166, 'EMP0012', 'Street Sweeper', 'City Government of Borongan', NULL, '2019-10-01', '2026-01-29', 10000.00, 'SG 1-1', 'Job Order', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(167, 'EMP0012', 'Encoder', 'Bureau of Internal Revenue Borongan', NULL, '2019-01-07', '2019-11-30', 14000.00, 'SG 5-1', 'Contract of Service', 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(168, 'EMP0012', 'Pharmacy Assistant', 'Mercury Drug Borongan', NULL, '2019-12-15', '2020-05-31', 13000.00, 'N/A', 'Regular', 0, '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `type` enum('regular','special','local') NOT NULL DEFAULT 'regular',
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_accruals`
--

CREATE TABLE `leave_accruals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `accrual_date` date NOT NULL,
  `accrual_type` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `supporting_document` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_accruals`
--

INSERT INTO `leave_accruals` (`id`, `employee_id`, `leave_type_id`, `amount`, `accrual_date`, `accrual_type`, `notes`, `supporting_document`, `reference_number`, `effective_date`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'EMP0001', 6, 3.00, '2026-01-28', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, 1, '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(2, 'EMP0001', 1, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 16:59:09', '2026-01-28 16:59:09'),
(3, 'EMP0001', 3, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 16:59:10', '2026-01-28 16:59:10'),
(4, 'EMP0001', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 16:59:10', '2026-01-28 16:59:10'),
(5, 'EMP0001', 12, 5.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 16:59:10', '2026-01-28 16:59:10'),
(6, 'EMP0001', 1, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:07:30', '2026-01-28 17:07:30'),
(7, 'EMP0001', 3, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:07:30', '2026-01-28 17:07:30'),
(8, 'EMP0001', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:07:30', '2026-01-28 17:07:30'),
(9, 'EMP0001', 12, 5.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:07:30', '2026-01-28 17:07:30'),
(10, 'EMP0001', 1, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:18:32', '2026-01-28 17:18:32'),
(11, 'EMP0001', 3, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:18:32', '2026-01-28 17:18:32'),
(12, 'EMP0001', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:18:32', '2026-01-28 17:18:32'),
(13, 'EMP0001', 12, 5.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:18:32', '2026-01-28 17:18:32'),
(14, 'EMP0001', 1, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:27:41', '2026-01-28 17:27:41'),
(15, 'EMP0001', 3, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:27:41', '2026-01-28 17:27:41'),
(16, 'EMP0001', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:27:41', '2026-01-28 17:27:41'),
(17, 'EMP0001', 12, 5.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:27:41', '2026-01-28 17:27:41'),
(18, 'EMP0001', 1, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(19, 'EMP0001', 3, 15.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(20, 'EMP0001', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(21, 'EMP0001', 12, 5.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(22, 'EMP0003', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, 1, '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(23, 'EMP0005', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, 1, '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(24, 'EMP0012', 6, 3.00, '2026-01-29', 'annual', 'CSC annual leave entitlement for 2026', NULL, NULL, NULL, 1, '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `leave_balances`
--

CREATE TABLE `leave_balances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `entitled` decimal(8,2) NOT NULL DEFAULT 0.00,
  `accrued` decimal(8,2) NOT NULL DEFAULT 0.00,
  `used` decimal(8,2) NOT NULL DEFAULT 0.00,
  `pending` decimal(8,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(8,2) NOT NULL DEFAULT 0.00,
  `carried_over` decimal(8,2) NOT NULL DEFAULT 0.00,
  `initial_balance` decimal(8,2) NOT NULL DEFAULT 0.00,
  `balance_as_of_date` date DEFAULT NULL,
  `migration_notes` text DEFAULT NULL,
  `is_manually_set` tinyint(1) NOT NULL DEFAULT 0,
  `year` year(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_balances`
--

INSERT INTO `leave_balances` (`id`, `employee_id`, `leave_type_id`, `entitled`, `accrued`, `used`, `pending`, `balance`, `carried_over`, `initial_balance`, `balance_as_of_date`, `migration_notes`, `is_manually_set`, `year`, `created_at`, `updated_at`) VALUES
(1, 'EMP0001', 6, 18.00, 18.00, 0.00, 0.00, 18.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-27 16:32:58', '2026-01-28 17:37:33'),
(2, 'EMP0001', 1, 75.00, 75.00, 0.00, 0.00, 75.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 16:59:09', '2026-01-28 17:37:33'),
(3, 'EMP0001', 3, 75.00, 75.00, 0.00, 0.00, 75.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 16:59:10', '2026-01-28 17:37:33'),
(4, 'EMP0001', 12, 25.00, 25.00, 0.00, 0.00, 25.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 16:59:10', '2026-01-28 17:37:33'),
(5, 'EMP0001', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(6, 'EMP0001', 4, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(7, 'EMP0001', 5, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(8, 'EMP0001', 7, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(9, 'EMP0001', 8, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(10, 'EMP0001', 9, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(11, 'EMP0001', 10, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(12, 'EMP0001', 11, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(13, 'EMP0001', 13, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(14, 'EMP0001', 14, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(15, 'EMP0001', 15, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-28 17:33:44', '2026-01-28 17:33:44'),
(16, 'EMP0003', 6, 3.00, 3.00, 0.00, 0.00, 3.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(17, 'EMP0005', 6, 3.00, 3.00, 0.00, 0.00, 3.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(18, 'EMP0012', 6, 3.00, 3.00, 0.00, 0.00, 3.00, 0.00, 0.00, NULL, NULL, 0, '2026', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `leave_credits_history`
--

CREATE TABLE `leave_credits_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `earned` decimal(8,3) NOT NULL DEFAULT 0.000,
  `used` decimal(8,3) NOT NULL DEFAULT 0.000,
  `balance` decimal(8,3) NOT NULL DEFAULT 0.000,
  `abs_undertime_deduction` decimal(8,3) NOT NULL DEFAULT 0.000,
  `period` varchar(255) DEFAULT NULL,
  `as_of_date` date NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE `leave_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `request_submission_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days` decimal(5,2) NOT NULL,
  `reason` text DEFAULT NULL,
  `location` enum('within_philippines','abroad') DEFAULT NULL,
  `location_details` varchar(255) DEFAULT NULL,
  `sick_leave_type` enum('in_hospital','out_patient') DEFAULT NULL,
  `illness_description` varchar(255) DEFAULT NULL,
  `women_special_illness` varchar(255) DEFAULT NULL,
  `study_leave_type` enum('completion_masters','bar_board_exam','other') DEFAULT NULL,
  `study_leave_details` varchar(255) DEFAULT NULL,
  `other_leave_type` enum('monetization','terminal_leave','other') DEFAULT NULL,
  `other_leave_details` varchar(255) DEFAULT NULL,
  `commutation_requested` tinyint(1) NOT NULL DEFAULT 0,
  `vacation_leave_balance` decimal(8,3) DEFAULT NULL,
  `sick_leave_balance` decimal(8,3) DEFAULT NULL,
  `recommendation` enum('approval','disapproval') DEFAULT NULL,
  `recommendation_reason` text DEFAULT NULL,
  `recommended_by` bigint(20) UNSIGNED DEFAULT NULL,
  `recommended_at` timestamp NULL DEFAULT NULL,
  `days_with_pay` decimal(5,2) DEFAULT NULL,
  `days_without_pay` decimal(5,2) DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `rejected_by` bigint(20) UNSIGNED DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) NOT NULL DEFAULT '#6366f1',
  `requires_approval` tinyint(1) NOT NULL DEFAULT 1,
  `requires_medical_certificate` tinyint(1) NOT NULL DEFAULT 0,
  `max_days_per_request` int(11) DEFAULT NULL,
  `max_days_per_year` int(11) DEFAULT NULL,
  `min_notice_days` int(11) NOT NULL DEFAULT 0,
  `can_carry_over` tinyint(1) NOT NULL DEFAULT 0,
  `max_carry_over_days` int(11) DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `gender_restriction` enum('male','female','all') NOT NULL DEFAULT 'all',
  `uses_credits_from` varchar(255) DEFAULT NULL,
  `is_monetizable` tinyint(1) NOT NULL DEFAULT 0,
  `is_special_leave` tinyint(1) NOT NULL DEFAULT 0,
  `required_document` varchar(255) DEFAULT NULL,
  `legal_basis` varchar(255) DEFAULT NULL,
  `commutation_applicable` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `name`, `code`, `description`, `color`, `requires_approval`, `requires_medical_certificate`, `max_days_per_request`, `max_days_per_year`, `min_notice_days`, `can_carry_over`, `max_carry_over_days`, `is_paid`, `is_active`, `gender_restriction`, `uses_credits_from`, `is_monetizable`, `is_special_leave`, `required_document`, `legal_basis`, `commutation_applicable`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Vacation Leave', 'VL', 'Annual vacation leave for rest, recreation, and personal transactions. Accrued at 1.25 days per month of service.', '#3b82f6', 1, 0, NULL, NULL, 5, 1, NULL, 1, 1, 'all', NULL, 1, 0, NULL, 'CSC MC No. 41, s. 1998', 1, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(2, 'Mandatory/Forced Leave', 'FL', 'Mandatory leave of 5 working days annually for employees with 10 days or more VL credits. Uses VL credits.', '#6366f1', 1, 0, 5, 5, 5, 0, NULL, 1, 1, 'all', 'VL', 0, 0, NULL, 'CSC MC No. 41, s. 1998; EO 1077', 0, 2, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(3, 'Sick Leave', 'SL', 'Leave for illness, injury, or medical/dental consultation. Accrued at 1.25 days per month of service.', '#ef4444', 1, 1, NULL, NULL, 0, 1, NULL, 1, 1, 'all', NULL, 1, 0, 'Medical Certificate (if 5+ days)', 'CSC MC No. 41, s. 1998', 1, 3, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(4, 'Maternity Leave', 'ML', '105 calendar days maternity leave with full pay. Additional 15 days for solo parents. 60 days for miscarriage/emergency termination.', '#ec4899', 1, 1, 105, 105, 30, 0, NULL, 1, 1, 'female', NULL, 0, 1, 'Medical Certificate, Birth Certificate of child', 'RA 11210 (105-Day Expanded Maternity Leave Law)', 0, 4, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(5, 'Paternity Leave', 'PL', '7 working days paternity leave for married male employees. Must be used within 60 days from childbirth.', '#06b6d4', 1, 0, 7, 7, 0, 0, NULL, 1, 1, 'male', NULL, 0, 1, 'Birth Certificate of child, Marriage Certificate', 'RA 8187 (Paternity Leave Act of 1996)', 0, 5, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(6, 'Special Privilege Leave', 'SPL', '3 days per year for personal milestones, parental obligations, filial obligations, domestic emergencies, government transactions, or medical attention not covered by sick leave.', '#8b5cf6', 1, 0, 3, 3, 1, 0, NULL, 1, 1, 'all', NULL, 0, 1, NULL, 'CSC MC No. 6, s. 1996', 0, 6, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(7, 'Solo Parent Leave', 'SoloP', '7 working days per year for solo parents. Cannot be converted to cash or carried over.', '#f59e0b', 1, 0, 7, 7, 5, 0, NULL, 1, 1, 'all', NULL, 0, 1, 'Solo Parent ID', 'RA 8972 (Solo Parents Welfare Act)', 0, 7, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(8, 'Study Leave', 'Study', 'Up to 6 months with pay for employees completing masters degree, taking bar/board exams, or other short-term studies.', '#14b8a6', 1, 0, 180, 180, 30, 0, NULL, 1, 1, 'all', NULL, 0, 1, 'Enrollment proof, Study plan', 'CSC MC No. 21, s. 2004', 0, 8, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(9, '10-Day VAWC Leave', 'VAWC', '10-day paid leave for women employees who are victims of violence as defined under RA 9262.', '#f43f5e', 1, 0, 10, 10, 0, 0, NULL, 1, 1, 'female', NULL, 0, 1, 'Barangay Protection Order, Police Report, or Medical Certificate', 'RA 9262 (Anti-VAWC Act of 2004)', 0, 9, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(10, 'Rehabilitation Privilege', 'Rehab', 'Leave for employees who sustained wounds or injuries while performing official duties.', '#22c55e', 1, 1, NULL, NULL, 0, 0, NULL, 1, 1, 'all', NULL, 0, 1, 'Medical Certificate, Incident Report', 'CSC MC No. 41, s. 1998', 0, 10, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(11, 'Special Leave Benefits for Women', 'WSL', 'Up to 2 months leave with pay for women who underwent surgery due to gynecological disorders.', '#d946ef', 1, 1, 60, 60, 0, 0, NULL, 1, 1, 'female', NULL, 0, 1, 'Medical Certificate, Hospital records', 'RA 9710 (Magna Carta of Women)', 0, 11, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(12, 'Special Emergency (Calamity) Leave', 'CL', '5 working days for employees directly affected by natural calamity/disaster as declared by NDRRMC.', '#ea580c', 1, 0, 5, 5, 0, 0, NULL, 1, 1, 'all', NULL, 0, 1, 'Certification from Barangay, DSWD, or local DRRM office', 'CSC MC No. 2, s. 2012', 0, 12, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(13, 'Adoption Leave', 'Adopt', '60 days leave for female employees who legally adopt a child below 7 years old.', '#a855f7', 1, 0, 60, 60, 7, 0, NULL, 1, 1, 'female', NULL, 0, 1, 'DSWD Pre-Adoption Placement Authority, Adoption Decree', 'RA 8552 (Domestic Adoption Act)', 0, 13, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(14, 'Terminal Leave', 'TL', 'Leave applied upon separation from service to monetize unused leave credits.', '#64748b', 1, 0, NULL, NULL, 30, 0, NULL, 1, 1, 'all', NULL, 1, 0, 'Resignation/Retirement letter, Clearance', 'CSC MC No. 41, s. 1998', 1, 14, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL),
(15, 'Other Leave', 'OTHER', 'Other leave types not covered by standard categories. Specify details in the application.', '#71717a', 1, 0, NULL, NULL, 0, 0, NULL, 1, 1, 'all', NULL, 0, 1, NULL, NULL, 0, 15, '2026-01-27 16:13:30', '2026-01-27 16:13:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000001_create_cache_table', 1),
(2, '0001_01_01_000002_create_jobs_table', 1),
(3, '2025_05_25_080415_create_permission_tables', 1),
(4, '2025_07_23_114136_create_employees_table', 1),
(5, '2025_07_24_000000_create_users_table', 1),
(6, '2025_07_25_000000_create_employee_audit_log_table', 1),
(7, '2025_11_20_230000_create_certificate_templates_table', 1),
(8, '2025_11_20_230100_create_certificate_text_layers_table', 1),
(9, '2025_11_21_030307_create_request_management_tables', 1),
(10, '2025_11_22_043413_create_training_module_tables', 1),
(11, '2025_11_25_125201_create_employee_documents_table', 1),
(12, '2025_11_27_120000_create_employee_audit_log_table', 1),
(13, '2025_11_27_140408_create_organizational_audit_log_table', 1),
(14, '2025_11_27_152757_cleanup_employee_log_permissions', 1),
(15, '2025_11_27_153538_move_organizational_log_to_organizational_structure', 1),
(16, '2025_11_27_153931_move_all_org_structure_permissions_to_organizational_structure', 1),
(17, '2025_11_27_154841_remove_restore_and_force_delete_organizational_log_permissions', 1),
(18, '2025_11_27_164129_remove_old_organizational_structure_access_permissions', 1),
(19, '2025_11_28_043025_create_request_type_faculties_and_departments_tables', 1),
(20, '2025_11_30_111259_create_oauth_auth_codes_table', 1),
(21, '2025_11_30_111300_create_oauth_access_tokens_table', 1),
(22, '2025_11_30_111301_create_oauth_refresh_tokens_table', 1),
(23, '2025_11_30_111302_create_oauth_clients_table', 1),
(24, '2025_11_30_111303_create_oauth_device_codes_table', 1),
(25, '2025_11_30_200000_create_leave_management_tables', 1),
(26, '2025_12_05_000001_add_performance_indexes', 1),
(27, '2025_12_08_074631_add_two_factor_columns_to_users_table', 1),
(28, '2025_12_08_150348_create_user_audit_log_table', 1),
(29, '2025_12_08_160157_create_user_activities_table', 1),
(30, '2025_12_11_000001_update_user_audit_log_foreign_key', 1),
(31, '2025_12_11_100000_update_leave_tables_for_csc_form_6', 1),
(32, '2025_12_11_120000_update_log_foreign_keys_to_preserve_history', 1),
(33, '2025_12_11_130000_preserve_training_logs', 1),
(34, '2025_12_11_140000_add_snapshot_to_audit_logs', 1),
(35, '2025_12_12_000000_add_salary_to_employees', 1),
(36, '2025_12_13_101115_add_oauth_logout_to_user_activities_table', 1),
(37, '2025_12_13_162642_add_post_logout_redirect_uris_to_oauth_clients_table', 1),
(38, '2025_12_14_034854_rollback_sso_login_from_user_activities_table', 1),
(39, '2026_01_09_030855_add_initial_balance_to_leave_tables', 1),
(40, '2026_01_24_092858_create_employee_audit_log_table_if_not_exists', 1),
(41, '2026_01_24_093359_create_user_audit_log_table_if_not_exists', 1),
(42, '2026_01_24_093403_create_organizational_audit_log_table_if_not_exists', 1),
(43, '2026_01_24_093640_create_audit_logs_table', 1),
(44, '2026_01_24_093753_migrate_existing_logs_to_audit_logs_table', 1),
(45, '2026_01_24_120446_add_snapshot_and_reference_number_to_audit_logs_table', 1),
(46, '2026_01_25_051833_change_entity_id_to_string_in_audit_logs_table', 1),
(47, '2026_01_25_100000_fix_audit_log_foreign_keys_for_permanent_deletes', 1),
(48, '2026_01_26_012815_add_view_audit_logs_permission', 1),
(49, '2026_01_27_033301_update_user_activities_to_preserve_on_user_delete', 1),
(50, '2026_01_27_113544_create_sectors_table', 1),
(51, '2026_01_27_113548_create_units_table', 1),
(52, '2026_01_27_113551_refactor_positions_table_add_power_level_and_sector', 1),
(53, '2026_01_27_113555_create_academic_ranks_table', 1),
(54, '2026_01_27_113610_create_staff_grades_table', 1),
(55, '2026_01_27_120000_add_performed_by_to_audit_logs', 1),
(56, '2026_01_27_120100_create_employee_assignments_table', 1),
(57, '2026_01_27_120200_add_primary_assignment_id_to_employees_table', 1),
(58, '2026_01_27_120300_create_unit_positions_table', 1),
(59, '2026_01_27_120400_create_employee_promotions_table', 1),
(60, '2026_01_27_133607_create_employee_rank_promotions_table', 1),
(61, '2026_01_27_133611_create_employee_assignment_history_table', 1),
(62, '2026_01_27_133614_add_performance_indexes_to_employee_assignments', 1),
(63, '2026_01_27_140000_add_user_name_email_to_user_activities', 1),
(64, '2026_01_27_150000_add_session_expired_to_user_activities', 1),
(65, '2026_01_27_152814_create_employee_grade_changes_table', 1),
(66, '2026_01_27_160000_add_oauth_login_to_user_activities', 1),
(67, '2026_01_28_002946_make_legacy_employee_fields_nullable', 2),
(69, '2026_01_28_005332_make_unit_id_nullable_in_employee_designations', 3),
(70, '2026_01_28_120647_rename_power_level_to_authority_level_in_positions_table', 4),
(71, '2026_01_28_124109_add_contract_dates_to_employees_table', 5),
(72, '2026_01_28_140146_drop_legacy_org_structure_from_employees_table', 6),
(73, '2026_01_28_140241_drop_legacy_columns_from_positions_table', 6),
(74, '2026_01_28_141023_create_training_allowed_sectors_and_units_tables', 6),
(75, '2026_01_29_014923_add_approval_workflow_enhancements', 7),
(76, '2026_01_29_014930_create_approval_comments_table', 7),
(77, '2026_01_29_014930_create_approval_delegations_table', 7),
(78, '2026_01_29_150000_fix_training_allowed_tables_and_cleanup_legacy_org', 8),
(79, '2026_01_29_160000_ensure_employees_contract_dates_and_training_pivots', 8);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(3, 'App\\Models\\User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('017e8a6aa853e8a0901f916fc6a4ae407a2bf69be424124ada87254c498965ccf70b724c2520d663', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 03:50:04', '2026-01-29 04:28:24', '2026-01-29 12:50:04'),
('0afbfd7eaa31ed2415f5e78296bbe8ceb1df604f54c9cd55a2d7acacaa60c552e11303e08831445a', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 05:04:52', '2026-01-29 05:04:52', '2026-01-29 14:04:52'),
('19778d9cda97d7f6e174cce494472c8b8c66df160d562f9642c63d68b79c7053c11632f3824fe42a', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 04:27:28', '2026-01-29 04:28:24', '2026-01-29 13:27:28'),
('2a5698da6c764ed5b5f884eca816ed6b11854c00eb235f8855f9053804105804a9ae8c93faaa6099', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:01:54', '2026-01-29 03:01:54', '2026-01-29 12:01:54'),
('46a7d3117737f854d84f97689c20d7c318691ceb259a3d8207867d4521598398b1e36ad77c48bbd1', 1, '019c0a31-8e8e-71d3-8d3b-e4126ab262d0', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 07:10:46', '2026-01-29 07:47:06', '2026-01-29 16:10:46'),
('4a0dc3a5f28bcb7e93a9c02d012ea77c91a9f6f52455abb46cfd48c68225c8f7ec06ad792b64b87f', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:02:41', '2026-01-29 03:02:41', '2026-01-29 12:02:41'),
('5f1160f42c5501d7b185134c923e99c91534feab925459e97e2d6aae8201a08e77ca18636df93a7c', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 02:58:29', '2026-01-29 02:59:49', '2026-01-29 11:58:29'),
('65533ed6f110bcbfa40260e6dd21c9913cc3db8dda8465062c98ccd8328bbeba7481d7451a359d91', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 04:28:41', '2026-01-29 04:28:41', '2026-01-29 13:28:41'),
('7b7f4c4acbba5d83d8ab79c8d1b3998190fa5e6271a5d97e65488a23e9d6b2356ebc9127183e3dc1', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:18:57', '2026-01-29 03:18:57', '2026-01-29 12:18:57'),
('871d42fe0533ed0188c1bf8ae065f2d5923b867b9c59f85d379bf7b1ac9589d98357bc0a1697538c', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 06:00:21', '2026-01-29 06:34:17', '2026-01-29 15:00:21'),
('8c2a10c50b6797aa814ff883b6fb316ff297b62124dc1fdd97b0b6115381b9444b927eb3e2e3e7ad', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 03:41:49', '2026-01-29 04:28:24', '2026-01-29 12:41:49'),
('96a8515b246dbd912a6448fab669565348fedc47fce5b1575fcfa57da8ace6dc0df089038beb1be5', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:18:00', '2026-01-29 03:18:00', '2026-01-29 12:18:00'),
('d696c1d0e4d68c0631734492425a6906db3f6c61e3f2e45f7aca10585807b58971f058c8779f402a', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 04:55:32', '2026-01-29 04:55:32', '2026-01-29 13:55:32'),
('df824343c5ee5bb4c87eb1ff33dbae00e36aebd5794957f4e6fc41d416c36c6b3919beee42a34731', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:02:51', '2026-01-29 03:02:51', '2026-01-29 12:02:51'),
('f52d089f03702e4d3ce0df6ebdd4eaef06ff2677bc5de593dd140a279f6d292852b32567e11347b6', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 03:15:33', '2026-01-29 03:15:33', '2026-01-29 12:15:33'),
('f772519dda440efddd48480ab46b8e6ddc0dbbcb47fc529ea5ef59d11f42fea075aab150f34501bb', 2, '019c0a31-8e8e-71d3-8d3b-e4126ab262d0', NULL, '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 07:12:27', '2026-01-29 07:12:27', '2026-01-29 16:12:27');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` char(36) NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_auth_codes`
--

INSERT INTO `oauth_auth_codes` (`id`, `user_id`, `client_id`, `scopes`, `revoked`, `expires_at`) VALUES
('1459e3b40c507c2dc92aa03d3580b4c75b875d3a563f7cf3e9a09b6e29e06eef085a76c593613e7d', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:28:56'),
('249cfc90d406e34f54f7884a8ec8ecc1d7d45fef52ea9e2fb43d8b93ce2f44bc854704712fbf1971', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:51:48'),
('2b13fa337105d4e2eb87994147d181ed059826fb8b4b558dddb67c842bbc952902f714a18510b5e3', 1, '019c0a31-8e8e-71d3-8d3b-e4126ab262d0', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 15:20:45'),
('3562ed4ef7ef4e5b762c0e761c288f37b7f1d7ed450314d5a5c53c07ffff6c90aeda53150a46f258', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 12:00:04'),
('41d7e18318cc8dad75d17555148534bee84a3a4b77f46c272b0fc343b34a5187fe9474e03faed84e', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:11:53'),
('43ce728340e314661a0e1952e4df4dab1e1d0e6455316d4a42a6b6f77a4a7413fabc5b5040f8b6ed', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:12:50'),
('4d575f1276d99ee4e12de2f54edce800f4956ae230cca75eced3e87e2e34c6e87cec84135fa2af10', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 14:10:20'),
('89f06c7f0b355f45d1c97eaf7e7415a442eb148b80b88efaa06017df75c541c633ad8368633cf4ee', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:25:32'),
('8bb4cf9d5a7ab108e4b9f7b9568fc4f080d1c3fd1e368ca6345c21245887354ebde69329c73dedc8', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 0, '2026-01-29 11:10:16'),
('a11307bee43b16444dbd4e68f630e1942c7d120aaa73cda38da30a889cff8648f2b28d041b1ba550', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 12:37:27'),
('ad60431cca7e608e80558cec94a938b5a6399e95ebb161049dc6be0adea59a83b4d573343cd149b0', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:08:28'),
('bb5848482acd7cda1d0d6ef195fa8286de434a7278551f84c4bc245daccacfe290fe80480a790c4b', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:27:59'),
('bf338d1e846d200cd03f8f1bd262afba319965e391e9ac6338ded98ba85c246a9a28c15f73871b8a', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 11:12:40'),
('c7372b66755d75a6356cfd157a8af29e29b9b23b13c638a33aeca2c5c06b721242f1c85708d507f5', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 13:05:31'),
('daf9a582c0f053db8af365fbb0a1846f46a6d0bf12977ed759069ef21cb500c3add01770f6c07e44', 1, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 13:14:51'),
('e4b186ab0beab3754a68d2f59c8dcfc22d53844a29997c3a5ef78ff692a5d0eeca2057a355b24155', 2, '019c095e-df71-7015-b771-aaf0f2c7b6a2', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 12:38:41'),
('ef632324feb6f0ecb1337a9ea8a5c9ab68bf3fcd75111d02c60f5f966a4cff05efd204554b430285', 2, '019c0a31-8e8e-71d3-8d3b-e4126ab262d0', '[\"openid\",\"profile\",\"email\"]', 1, '2026-01-29 15:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` char(36) NOT NULL,
  `owner_type` varchar(255) DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect_uris` text NOT NULL,
  `post_logout_redirect_uris` text DEFAULT NULL,
  `grant_types` text NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `owner_type`, `owner_id`, `name`, `secret`, `provider`, `redirect_uris`, `post_logout_redirect_uris`, `grant_types`, `revoked`, `created_at`, `updated_at`) VALUES
('019c095e-df71-7015-b771-aaf0f2c7b6a2', 'App\\Models\\User', 1, 'RMS', '$2y$12$cLXHPW7O92boBmQswmladOtH.C/CCFTXurPwD71tycQEqV1/efqim', NULL, '[\"http:\\/\\/localhost:8000\\/oauth_callback.php\"]', '[\"http:\\/\\/localhost:8000\\/logged-out\"]', '[\"authorization_code\",\"refresh_token\"]', 0, '2026-01-29 02:48:58', '2026-01-29 02:58:20'),
('019c0a31-8e8e-71d3-8d3b-e4126ab262d0', 'App\\Models\\User', 1, 'Maintenance Office', '$2y$12$dgUnbaHDEnjSS8pXRX29TOZ.Losmw0GXAiqgOB5eq1AVGNFzmqetu', NULL, '[\"http:\\/\\/localhost:8000\\/oauth_callback.php\"]', '[\"http:\\/\\/localhost:8000\\/logged-out\"]', '[\"authorization_code\",\"refresh_token\"]', 0, '2026-01-29 06:39:05', '2026-01-29 06:39:05');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_device_codes`
--

CREATE TABLE `oauth_device_codes` (
  `id` char(80) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` char(36) NOT NULL,
  `user_code` char(8) NOT NULL,
  `scopes` text NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `user_approved_at` datetime DEFAULT NULL,
  `last_polled_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` char(80) NOT NULL,
  `access_token_id` char(80) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_refresh_tokens`
--

INSERT INTO `oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('03f7792d2e1deab19661584ee24f3e752cbf4cfb98ef15a5a98c0436effaf2e4503d7d47e5bb23bc', '871d42fe0533ed0188c1bf8ae065f2d5923b867b9c59f85d379bf7b1ac9589d98357bc0a1697538c', 0, '2026-02-28 14:00:21'),
('22f05f612f2f6d4765adc7a3abbbb56140eb1e17bd305d2a9ce107226c1eafa1e9fa77204abea35c', '7b7f4c4acbba5d83d8ab79c8d1b3998190fa5e6271a5d97e65488a23e9d6b2356ebc9127183e3dc1', 0, '2026-02-28 11:18:57'),
('34c9dfb34e8093be0e83431b91889db4999778dbc72fd4c635237ea4f027a7bc02bdf71e0328607d', '2a5698da6c764ed5b5f884eca816ed6b11854c00eb235f8855f9053804105804a9ae8c93faaa6099', 0, '2026-02-28 11:01:54'),
('3c38404014c84f425d71b70819bb970c7896c6a108323ceb67341af43210bf922a46487bfa578820', 'df824343c5ee5bb4c87eb1ff33dbae00e36aebd5794957f4e6fc41d416c36c6b3919beee42a34731', 0, '2026-02-28 11:02:51'),
('44fa978e74320655a15c45baa8b8b6d9edfdb4d301cfe276a524e128cf3b206137941d19e09b50c3', '65533ed6f110bcbfa40260e6dd21c9913cc3db8dda8465062c98ccd8328bbeba7481d7451a359d91', 0, '2026-02-28 12:28:41'),
('4a84bf5e3764728156465ef7ee7c1e848599721b98fc037c30854c5398fc16c39f8e22e494049cda', '017e8a6aa853e8a0901f916fc6a4ae407a2bf69be424124ada87254c498965ccf70b724c2520d663', 0, '2026-02-28 11:50:04'),
('4e57195657f2deb2573397ba1a2062572583e4524e226e943191c98b5f183434ab9d3ae8b75cfdeb', 'd696c1d0e4d68c0631734492425a6906db3f6c61e3f2e45f7aca10585807b58971f058c8779f402a', 0, '2026-02-28 12:55:32'),
('50615c53c2796428598940be94e39863e542f2a59c81529c7817ea698d04970489b34f62f41c4ff3', '5f1160f42c5501d7b185134c923e99c91534feab925459e97e2d6aae8201a08e77ca18636df93a7c', 0, '2026-02-28 10:58:29'),
('6284d48536dd42b99ea486c1f18fb032325f3fa4aabd5a810723145535c18d0ab9356bfa12c4b580', '96a8515b246dbd912a6448fab669565348fedc47fce5b1575fcfa57da8ace6dc0df089038beb1be5', 0, '2026-02-28 11:18:00'),
('6c45bc66ff20cc059ca2fc527c37c4bc154ba9479d2320d48da77458948d98a6f850591145558f21', 'f52d089f03702e4d3ce0df6ebdd4eaef06ff2677bc5de593dd140a279f6d292852b32567e11347b6', 0, '2026-02-28 11:15:33'),
('73222fed68ee8a5c9cf75255d42a5b00d40a6135f2e37616a10a86ae47e83045bfd0de705cff5124', '19778d9cda97d7f6e174cce494472c8b8c66df160d562f9642c63d68b79c7053c11632f3824fe42a', 0, '2026-02-28 12:27:28'),
('73e2fd2e9098ba9a56a7dc4bb226cbc81697b26078c37f66c300f0995a26549d7bddb9431c69c37c', '0afbfd7eaa31ed2415f5e78296bbe8ceb1df604f54c9cd55a2d7acacaa60c552e11303e08831445a', 0, '2026-02-28 13:04:52'),
('81a9e7f05020432c87e0bda5e02279338ddc9ca62a15b19ce47e33c96339a862578e66c69af8890f', '46a7d3117737f854d84f97689c20d7c318691ceb259a3d8207867d4521598398b1e36ad77c48bbd1', 0, '2026-02-28 15:10:46'),
('9058ef12f207476a5b8a2c4e5652becb814416bf59038f4944204b5d1af335147aeab861b283baed', 'f772519dda440efddd48480ab46b8e6ddc0dbbcb47fc529ea5ef59d11f42fea075aab150f34501bb', 0, '2026-02-28 15:12:27'),
('9bafeab1312276877ee250c94f769526d887919f963c64c2044d512e1b858ecd2c49b3f1cfd0b3c9', '8c2a10c50b6797aa814ff883b6fb316ff297b62124dc1fdd97b0b6115381b9444b927eb3e2e3e7ad', 0, '2026-02-28 11:41:49'),
('e5e7df7db4451958faec7cc6a07c200c862fb038e1cb63d3984443bd5722b64c1368147cf73c58f6', '4a0dc3a5f28bcb7e93a9c02d012ea77c91a9f6f52455abb46cfd48c68225c8f7ec06ad792b64b87f', 0, '2026-02-28 11:02:41');

-- --------------------------------------------------------

--
-- Table structure for table `organizational_audit_log`
--

CREATE TABLE `organizational_audit_log` (
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `unit_type` enum('faculty','department','position','office') NOT NULL,
  `unit_id` bigint(20) UNSIGNED NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `action_type` enum('CREATE','UPDATE','DELETE') NOT NULL,
  `field_changed` varchar(100) DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`snapshot`)),
  `action_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `performed_by` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `guard_name` varchar(255) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `module`, `name`, `label`, `description`, `is_active`, `guard_name`, `level`, `created_at`, `updated_at`) VALUES
(1, 'Audit Logs', 'view-audit-logs', 'View Audit Logs', 'Can view unified audit logs across all modules', 1, 'web', 0, '2026-01-27 16:04:25', '2026-01-27 16:04:25'),
(2, 'Roles', 'access-roles-module', 'Access Roles Module', 'Can access roles module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(3, 'Permissions', 'access-permissions-module', 'Access Permissions Module', 'Can access permissions module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(4, 'Users', 'access-users-module', 'Access Users Module', 'Can access users module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(5, 'Employees', 'access-employees-module', 'Access Employees Module', 'Can access employee module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(6, 'Requests', 'access-request-types-module', 'Access Requests Module', 'Can configure HR request types and fulfillment workflows', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(7, 'Leaves', 'access-leave-calendar', 'Access Leave Calendar', 'Can view the leave calendar showing all employees\' leave requests', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(8, 'Leaves', 'manage-leave-balances', 'Manage Leave Balances', 'Can set initial balances, grant special leaves, and adjust employee leave credits', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(9, 'Roles', 'create-role', 'Create Role', 'Can create new roles', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(10, 'Roles', 'edit-role', 'Edit Role', 'Can modify existing roles', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(11, 'Roles', 'delete-role', 'Delete Role', 'Can remove roles', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(12, 'Roles', 'view-role', 'View Role', 'Can view role details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(13, 'Permissions', 'create-permission', 'Create Permission', 'Can create permissions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(14, 'Permissions', 'edit-permission', 'Edit Permission', 'Can modify permissions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(15, 'Permissions', 'delete-permission', 'Delete Permission', 'Can delete permissions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(16, 'Permissions', 'view-permission', 'View Permission', 'Can view permissions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(17, 'Users', 'create-user', 'Create User', 'Can create new users', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(18, 'Users', 'edit-user', 'Edit User', 'Can modify user accounts', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(19, 'Users', 'delete-user', 'Delete User', 'Can delete users', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(20, 'Users', 'view-user', 'View User', 'Can view user details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(22, 'Users', 'view-user-activities', 'View User Activities', 'Can view user login/logout activities', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(23, 'Users', 'restore-user', 'Restore User', 'Can restore deactivated users', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(24, 'Users', 'force-delete-user', 'Force Delete User', 'Can permanently delete users', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(25, 'Employees', 'create-employee', 'Create Employee', 'Can create new employees', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(26, 'Employees', 'edit-employee', 'Edit Employee', 'Can edit employee records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(27, 'Employees', 'delete-employee', 'Delete Employee', 'Can delete employee records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(28, 'Employees', 'view-employee', 'View Employee', 'Can view employee details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(29, 'Employees', 'view-all-employees', 'View All Employees', 'Can view all employees without scope restrictions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(30, 'Employees', 'view-faculty-employees', 'View Faculty Employees', 'Can view employees in their faculty regardless of role', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(31, 'Employees', 'view-department-employees', 'View Department Employees', 'Can view employees in their department/office regardless of role', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(33, 'Employees', 'restore-employee', 'Restore Employee', 'Can restore deleted employees', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(34, 'Employees', 'force-delete-employee', 'Force Delete Employee', 'Can permanently delete employees', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(56, 'Organizational Structure', 'access-position', 'Access Position', 'Can access position module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(57, 'Organizational Structure', 'create-position', 'Create Position', 'Can create new positions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(58, 'Organizational Structure', 'edit-position', 'Edit Position', 'Can edit position records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(59, 'Organizational Structure', 'delete-position', 'Delete Position', 'Can delete positions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(60, 'Organizational Structure', 'view-position', 'View Position', 'Can view position details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(61, 'Organizational Structure', 'restore-position', 'Restore Position', 'Can restore deleted positions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(62, 'Organizational Structure', 'force-delete-position', 'Force Delete Position', 'Can permanently delete positions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(63, 'Organizational Structure', 'access-sector', 'Access Sector', 'Can access sector module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(64, 'Organizational Structure', 'create-sector', 'Create Sector', 'Can create new sectors', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(65, 'Organizational Structure', 'edit-sector', 'Edit Sector', 'Can edit sector records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(66, 'Organizational Structure', 'delete-sector', 'Delete Sector', 'Can delete sectors', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(67, 'Organizational Structure', 'view-sector', 'View Sector', 'Can view sector details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(68, 'Organizational Structure', 'restore-sector', 'Restore Sector', 'Can restore deleted sectors', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(69, 'Organizational Structure', 'force-delete-sector', 'Force Delete Sector', 'Can permanently delete sectors', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(70, 'Organizational Structure', 'access-unit', 'Access Unit', 'Can access unit module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(71, 'Organizational Structure', 'create-unit', 'Create Unit', 'Can create new units', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(72, 'Organizational Structure', 'edit-unit', 'Edit Unit', 'Can edit unit records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(73, 'Organizational Structure', 'delete-unit', 'Delete Unit', 'Can delete units', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(74, 'Organizational Structure', 'view-unit', 'View Unit', 'Can view unit details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(75, 'Organizational Structure', 'restore-unit', 'Restore Unit', 'Can restore deleted units', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(76, 'Organizational Structure', 'force-delete-unit', 'Force Delete Unit', 'Can permanently delete units', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(77, 'Organizational Structure', 'access-unit-position', 'Access Unit-Position Whitelist', 'Can access unit-position whitelist module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(78, 'Organizational Structure', 'create-unit-position', 'Create Unit-Position Whitelist', 'Can add positions to unit whitelist', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(79, 'Organizational Structure', 'edit-unit-position', 'Edit Unit-Position Whitelist', 'Can edit unit-position whitelist', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(80, 'Organizational Structure', 'delete-unit-position', 'Delete Unit-Position Whitelist', 'Can delete unit-position whitelist entries', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(81, 'Organizational Structure', 'view-unit-position', 'View Unit-Position Whitelist', 'Can view unit-position whitelist', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(82, 'Organizational Structure', 'restore-unit-position', 'Restore Unit-Position Whitelist', 'Can restore deleted unit-position whitelist entries', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(83, 'Organizational Structure', 'force-delete-unit-position', 'Force Delete Unit-Position Whitelist', 'Can permanently delete unit-position whitelist entries', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(84, 'Employees', 'promote-employee', 'Promote Employee', 'Can record employee promotions', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(85, 'Employees', 'view-employee-promotions', 'View Employee Promotions', 'Can view employee promotion history', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(86, 'Employees', 'promote-grade', 'Promote Grade/Rank', 'Can promote employee grade/rank (upward progression)', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(87, 'Employees', 'correct-grade', 'Correct Grade/Rank', 'Can correct/adjust employee grade/rank (with reason)', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(88, 'Employees', 'view-grade-history', 'View Grade History', 'Can view employee grade/rank change history', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(90, 'Trainings', 'access-trainings-module', 'Access Trainings Module', 'Can access trainings module', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(91, 'Trainings', 'create-training', 'Create Training', 'Can create new trainings', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(92, 'Trainings', 'edit-training', 'Edit Training', 'Can edit training records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(93, 'Trainings', 'delete-training', 'Delete Training', 'Can delete trainings', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(94, 'Trainings', 'view-training', 'View Training', 'Can view training details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(95, 'Trainings', 'restore-training', 'Restore Training', 'Can restore deleted trainings', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(96, 'Trainings', 'force-delete-training', 'Force Delete Training', 'Can permanently delete trainings', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(97, 'Requests', 'create-request-type', 'Create Request Type', 'Can create new request types', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(98, 'Requests', 'edit-request-type', 'Edit Request Type', 'Can edit request type records', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(99, 'Requests', 'delete-request-type', 'Delete Request Type', 'Can delete request types', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(100, 'Requests', 'view-request-type', 'View Request Type', 'Can view request type details', 1, 'web', 0, '2026-01-27 16:13:29', '2026-01-27 16:13:29'),
(101, 'Employees', 'view-sector-employees', 'View Sector Employees', 'Can view employees in their sector', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(102, 'Employees', 'view-unit-employees', 'View Unit Employees', 'Can view employees in their unit', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(103, 'Organizational Structure', 'access-academic-rank', 'Access Academic Ranks', 'Can access academic ranks module', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(104, 'Organizational Structure', 'create-academic-rank', 'Create Academic Rank', 'Can create academic ranks', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(105, 'Organizational Structure', 'edit-academic-rank', 'Edit Academic Rank', 'Can edit academic ranks', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(106, 'Organizational Structure', 'delete-academic-rank', 'Delete Academic Rank', 'Can delete academic ranks', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(107, 'Organizational Structure', 'view-academic-rank', 'View Academic Rank', 'Can view academic rank details', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(108, 'Organizational Structure', 'restore-academic-rank', 'Restore Academic Rank', 'Can restore deleted academic ranks', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(109, 'Organizational Structure', 'force-delete-academic-rank', 'Force Delete Academic Rank', 'Can permanently delete academic ranks', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(110, 'Organizational Structure', 'access-staff-grade', 'Access Staff Grades', 'Can access staff grades module', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(111, 'Organizational Structure', 'create-staff-grade', 'Create Staff Grade', 'Can create staff grades', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(112, 'Organizational Structure', 'edit-staff-grade', 'Edit Staff Grade', 'Can edit staff grades', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(113, 'Organizational Structure', 'delete-staff-grade', 'Delete Staff Grade', 'Can delete staff grades', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(114, 'Organizational Structure', 'view-staff-grade', 'View Staff Grade', 'Can view staff grade details', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(115, 'Organizational Structure', 'restore-staff-grade', 'Restore Staff Grade', 'Can restore deleted staff grades', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13'),
(116, 'Organizational Structure', 'force-delete-staff-grade', 'Force Delete Staff Grade', 'Can permanently delete staff grades', 1, 'web', 0, '2026-01-28 06:47:13', '2026-01-28 06:47:13');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pos_code` varchar(25) NOT NULL,
  `pos_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `sector_id` bigint(20) UNSIGNED DEFAULT NULL,
  `authority_level` tinyint(3) UNSIGNED DEFAULT 1,
  `hierarchy_level` int(11) NOT NULL DEFAULT 1,
  `position_type` varchar(50) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `creation_type` enum('manual','auto') NOT NULL DEFAULT 'manual',
  `position_category` enum('executive','academic_teaching','academic_support','administrative_non_teaching','technical_skilled','support_utility','specialized_compliance') DEFAULT NULL,
  `capacity` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `pos_code`, `pos_name`, `description`, `sector_id`, `authority_level`, `hierarchy_level`, `position_type`, `slug`, `creation_type`, `position_category`, `capacity`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'UNIV_PRES', 'University President', NULL, NULL, 100, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(2, 'VP_ACAD', 'Vice President for Academic Affairs', NULL, NULL, 95, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(3, 'VP_ADMIN', 'Vice President for Administration', NULL, NULL, 95, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(4, 'DEAN', 'Dean', NULL, 1, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(5, 'ASSO_DEAN', 'Associate Dean', NULL, 1, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(6, 'PROG_HEAD', 'Program Head', NULL, 1, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(7, 'FACULTY', 'Faculty', NULL, 1, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(8, 'COORD', 'Coordinator', NULL, 1, 40, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(9, 'DIRECTOR', 'Director', NULL, 2, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(10, 'HEAD', 'Head', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(11, 'OFFICER', 'Officer', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(12, 'STAFF', 'Staff', NULL, 2, 45, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(13, 'AIDE', 'Administrative Aide', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(14, 'SUC_PRES_III', 'SUC President III', NULL, NULL, 100, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(15, 'VP_RES_EXT', 'Vice President for Research and Extension', NULL, NULL, 95, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(16, 'VP_EXT_QA', 'Vice President for External Affairs and Quality Assurance', NULL, NULL, 95, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(17, 'BOARD_SEC_V', 'Board Secretary V', NULL, NULL, 85, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(18, 'BOARD_SEC_I', 'Board Secretary I', NULL, NULL, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(19, 'COLLEGE_DEAN', 'College Dean', NULL, 1, 85, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(20, 'ASSOC_DEAN', 'Associate Dean', NULL, 1, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(21, 'COLLEGE_SEC', 'College Secretary', NULL, 1, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(22, 'RES_COORD', 'Research Coordinator', NULL, 1, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(23, 'EXT_COORD', 'Extension Coordinator', NULL, 1, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(24, 'OJT_COORD', 'OJT Coordinator', NULL, 1, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(25, 'INTERN_COORD', 'Internship Coordinator', NULL, 1, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(26, 'STUD_SERV_COORD', 'Student Services Coordinator', NULL, 1, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(27, 'ALUMNI_COORD', 'Alumni Affairs Coordinator', NULL, 1, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(28, 'GAD_FOCAL', 'GAD Focal Person', NULL, 1, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(29, 'QAA_COORD', 'QAA Coordinator', NULL, 1, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(30, 'CLINICAL_COORD', 'Clinical Coordinator', NULL, 1, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(31, 'LECTURER', 'Lecturer', NULL, 1, 45, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(32, 'AFFILIATE_FAC', 'Affiliate Faculty', NULL, 1, 45, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(33, 'VISIT_DEAN', 'Visiting Dean', NULL, 1, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(34, 'LAB_INCHARGE', 'Laboratory In-Charge', NULL, 1, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(35, 'COLLEGE_LIB', 'College Librarian', NULL, 1, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(36, 'ADMIN_STAFF_ACAD', 'Administrative Staff', NULL, 1, 40, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(37, 'ASST_DIRECTOR', 'Assistant Director', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(38, 'CAO_FIN', 'Chief Administrative Officer (Finance)', NULL, 2, 85, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(39, 'CAO', 'Chief Administrative Officer', NULL, 2, 85, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(40, 'SUP_ADMIN_OFF', 'Supervising Administrative Officer', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(41, 'ADMIN_OFF_V', 'Administrative Officer V', NULL, 2, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(42, 'ADMIN_OFF_IV', 'Administrative Officer IV', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(43, 'ADMIN_OFF_III', 'Administrative Officer III', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(44, 'ADMIN_OFF_II', 'Administrative Officer II', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(45, 'ADMIN_OFF_I', 'Administrative Officer I', NULL, 2, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(46, 'ADMIN_ASST_V', 'Administrative Assistant V', NULL, 2, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(47, 'ADMIN_ASST_III', 'Administrative Assistant III', NULL, 2, 45, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(48, 'ADMIN_ASST_II', 'Administrative Assistant II', NULL, 2, 40, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(49, 'ADMIN_ASST_I', 'Administrative Assistant I', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(50, 'ADMIN_AIDE_VI', 'Administrative Aide VI', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(51, 'ADMIN_AIDE_IV', 'Administrative Aide IV', NULL, 2, 30, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(52, 'ADMIN_AIDE_III', 'Administrative Aide III', NULL, 2, 25, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(53, 'ADMIN_AIDE_I', 'Administrative Aide I', NULL, 2, 20, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(54, 'ACCOUNTANT_III', 'Accountant III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(55, 'ACCOUNTANT_II', 'Accountant II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(56, 'BUDGET_OFF_IV', 'Budget Officer IV', NULL, 2, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(57, 'BUDGET_OFF_III', 'Budget Officer III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(58, 'BUDGET_OFF_II', 'Budget Officer II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(59, 'BUDGET_OFF_I', 'Budget Officer I', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(60, 'CASHIER_III', 'Cashier III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(61, 'CASHIER_II', 'Cashier II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(62, 'COLLECT_OFF', 'Collecting Officer', NULL, 2, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(63, 'DISBURS_OFF', 'Disbursing Officer', NULL, 2, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(64, 'HRMO_DIR', 'HRMO Director', NULL, 2, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(65, 'ATTORNEY_IV', 'Attorney IV', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(66, 'LEGAL_ASST_III', 'Legal Assistant III', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(67, 'LEGAL_ASST_II', 'Legal Assistant II', NULL, 2, 50, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(68, 'INT_AUDITOR_III', 'Internal Auditor III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(69, 'INT_AUDITOR_II', 'Internal Auditor II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(70, 'INT_AUDITOR_I', 'Internal Auditor I', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(71, 'UNIV_REG', 'University Registrar', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(72, 'REGISTRAR_III', 'Registrar III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(73, 'RECORDS_OFF_III', 'Records Officer III', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(74, 'LIB_DIR', 'Director, Library Services', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(75, 'COLLEGE_LIB_I', 'College Librarian I', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(76, 'ICTC_DIR', 'ICTC Director', NULL, 2, 80, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(77, 'COMP_PROG_I', 'Computer Programmer I', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(78, 'PROJ_DEV_OFF_III', 'Project Development Officer III', NULL, 2, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(79, 'PROJ_DEV_OFF_I', 'Project Development Officer I', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(80, 'PLANNING_OFF_II', 'Planning Officer II', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(81, 'ARCHITECT', 'Architect', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(82, 'ENGINEER_I', 'Engineer I', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(83, 'PROC_OFF', 'Procurement Officer', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(84, 'BAC_CHAIR', 'BAC Chairman', NULL, 2, 75, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(85, 'BAC_VICE_CHAIR', 'BAC Vice-Chairman', NULL, 2, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(86, 'BAC_MEMBER', 'BAC Member', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(87, 'DENTIST_II', 'Dentist II', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(88, 'NURSE_II', 'Nurse II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(89, 'NUTRI_DIET_II', 'Nutritionist Dietitian II', NULL, 2, 60, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(90, 'UNIV_PSYCHO', 'University Psychometrician', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(91, 'INFO_OFF_III', 'Information Officer III', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(92, 'INFO_OFF_I', 'Information Officer I', NULL, 2, 55, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(93, 'SR_AGRI', 'Senior Agriculturist', NULL, 2, 65, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(94, 'EXEC_SEC', 'Executive Secretary', NULL, 2, 70, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(95, 'SECRETARY', 'Secretary', NULL, 2, 45, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(96, 'CLERK', 'Clerk', NULL, 2, 30, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(97, 'STOREKEEPER', 'Storekeeper', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(98, 'INSPECTOR', 'Inspector', NULL, 2, 40, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(99, 'UTILITY', 'Utility', NULL, 2, 15, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(100, 'DRIVER', 'Driver', NULL, 2, 25, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(101, 'SECURITY_GUARD', 'Security Guard', NULL, 2, 25, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(102, 'SKILLED_WORKER', 'Skilled Worker', NULL, 2, 30, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(103, 'ELECTRICIAN', 'Electrician', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(104, 'PLUMBER', 'Plumber', NULL, 2, 35, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(105, 'JOB_ORDER', 'Job Order', NULL, 2, 10, 1, NULL, NULL, 'manual', NULL, NULL, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `questionnaires`
--

CREATE TABLE `questionnaires` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `question_number` int(11) NOT NULL,
  `answer` tinyint(1) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questionnaires`
--

INSERT INTO `questionnaires` (`id`, `employee_id`, `question_number`, `answer`, `details`, `created_at`, `updated_at`) VALUES
(1, 'EMP0001', 341, 0, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(2, 'EMP0001', 342, 0, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(3, 'EMP0001', 351, 0, 'ound guilty of Simple Neglect of Duty on March 15, 2020', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(4, 'EMP0001', 352, 0, '', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(5, 'EMP0001', 36, 0, 'Convicted of Reckless Imprudence Resulting in Damage to Property', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(6, 'EMP0001', 37, 0, 'Resigned from position as Administrative Aide III', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(7, 'EMP0001', 381, 0, 'Ran for City Councilor', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(8, 'EMP0001', 382, 0, 'Resigned as Records Officer I', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(9, 'EMP0001', 39, 0, 'United States of America - Green Card Holder (Permanent Resident) acquired on November 15, 2020', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(10, 'EMP0001', 401, 0, 'Waray Ethnic Group, Eastern Samar', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(11, 'EMP0001', 402, 0, 'PWD ID No. 08-2022-012345 - Visual Impairment', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(12, 'EMP0001', 403, 0, 'Solo Parent ID No. SP-2023-67890, issued by City Social Welfare and Development Office, Borongan City on March 20, 2023', '2026-01-27 16:32:58', '2026-01-27 16:32:58'),
(13, 'EMP0003', 341, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(14, 'EMP0003', 342, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(15, 'EMP0003', 351, 1, 'ound guilty of Simple Neglect of Duty on March 15, 2020', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(16, 'EMP0003', 352, 0, '', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(17, 'EMP0003', 36, 1, 'Convicted of Reckless Imprudence Resulting in Damage to Property', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(18, 'EMP0003', 37, 1, 'Resigned from position as Administrative Aide III', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(19, 'EMP0003', 381, 1, 'Ran for City Councilor', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(20, 'EMP0003', 382, 1, 'Resigned as Records Officer I', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(21, 'EMP0003', 39, 1, 'United States of America - Green Card Holder (Permanent Resident) acquired on November 15, 2020', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(22, 'EMP0003', 401, 1, 'Waray Ethnic Group, Eastern Samar', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(23, 'EMP0003', 402, 1, 'PWD ID No. 08-2022-012345 - Visual Impairment', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(24, 'EMP0003', 403, 1, 'Solo Parent ID No. SP-2023-67890, issued by City Social Welfare and Development Office, Borongan City on March 20, 2023', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(25, 'EMP0005', 341, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(26, 'EMP0005', 342, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(27, 'EMP0005', 351, 1, 'ound guilty of Simple Neglect of Duty on March 15, 2020', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(28, 'EMP0005', 352, 0, '', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(29, 'EMP0005', 36, 1, 'Convicted of Reckless Imprudence Resulting in Damage to Property', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(30, 'EMP0005', 37, 1, 'Resigned from position as Administrative Aide III', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(31, 'EMP0005', 381, 1, 'Ran for City Councilor', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(32, 'EMP0005', 382, 1, 'Resigned as Records Officer I', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(33, 'EMP0005', 39, 1, 'United States of America - Green Card Holder (Permanent Resident) acquired on November 15, 2020', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(34, 'EMP0005', 401, 1, 'Waray Ethnic Group, Eastern Samar', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(35, 'EMP0005', 402, 1, 'PWD ID No. 08-2022-012345 - Visual Impairment', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(36, 'EMP0005', 403, 1, 'Solo Parent ID No. SP-2023-67890, issued by City Social Welfare and Development Office, Borongan City on March 20, 2023', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(37, 'EMP0012', 341, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(38, 'EMP0012', 342, 1, 'Maria Santos Cruz - Cousin (Third Degree) - Administrative Officer III, Municipal Administrator\'s Office, Borongan City', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(39, 'EMP0012', 351, 1, 'ound guilty of Simple Neglect of Duty on March 15, 2020', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(40, 'EMP0012', 352, 0, '', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(41, 'EMP0012', 36, 1, 'Convicted of Reckless Imprudence Resulting in Damage to Property', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(42, 'EMP0012', 37, 1, 'Resigned from position as Administrative Aide III', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(43, 'EMP0012', 381, 1, 'Ran for City Councilor', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(44, 'EMP0012', 382, 1, 'Resigned as Records Officer I', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(45, 'EMP0012', 39, 1, 'United States of America - Green Card Holder (Permanent Resident) acquired on November 15, 2020', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(46, 'EMP0012', 401, 1, 'Waray Ethnic Group, Eastern Samar', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(47, 'EMP0012', 402, 1, 'PWD ID No. 08-2022-012345 - Visual Impairment', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(48, 'EMP0012', 403, 1, 'Solo Parent ID No. SP-2023-67890, issued by City Social Welfare and Development Office, Borongan City on March 20, 2023', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `references`
--

CREATE TABLE `references` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(15) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_initial` varchar(5) DEFAULT NULL,
  `surname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `telephone_no` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `references`
--

INSERT INTO `references` (`id`, `employee_id`, `first_name`, `middle_initial`, `surname`, `address`, `telephone_no`, `created_at`, `updated_at`) VALUES
(7, 'EMP0001', 'Juan', '', '', 'Brgy. Mabini, Borongan City, Eastern Samar', '9562062855', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(8, 'EMP0001', 'Cruz', '', '', 'Brgy. Songco,  Eastern samar', '24243689133', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(9, 'EMP0001', 'Thea', '', '', 'Brgy. Songco,  Eastern samar', '234234524', '2026-01-28 05:35:36', '2026-01-28 05:35:36'),
(10, 'EMP0003', 'Juan', '', '', 'Brgy. Mabini, Borongan City, Eastern Samar', '9562062855', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(11, 'EMP0003', 'Cruz', '', '', 'Brgy. Songco,  Eastern samar', '24243689133', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(12, 'EMP0003', 'Thea', '', '', 'Brgy. Songco,  Eastern samar', '234234524', '2026-01-29 04:22:15', '2026-01-29 04:22:15'),
(13, 'EMP0005', 'Juan', '', '', 'Brgy. Mabini, Borongan City, Eastern Samar', '9562062855', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(14, 'EMP0005', 'Cruz', '', '', 'Brgy. Songco,  Eastern samar', '24243689133', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(15, 'EMP0005', 'Thea', '', '', 'Brgy. Songco,  Eastern samar', '234234524', '2026-01-29 04:54:05', '2026-01-29 04:54:05'),
(16, 'EMP0012', 'Juan', '', '', 'Brgy. Mabini, Borongan City, Eastern Samar', '9562062855', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(17, 'EMP0012', 'Cruz', '', '', 'Brgy. Songco,  Eastern samar', '24243689133', '2026-01-29 05:31:26', '2026-01-29 05:31:26'),
(18, 'EMP0012', 'Thea', '', '', 'Brgy. Songco,  Eastern samar', '234234524', '2026-01-29 05:31:26', '2026-01-29 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `request_answers`
--

CREATE TABLE `request_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_id` bigint(20) UNSIGNED NOT NULL,
  `field_id` bigint(20) UNSIGNED NOT NULL,
  `value` longtext DEFAULT NULL,
  `value_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`value_json`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_approval_actions`
--

CREATE TABLE `request_approval_actions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_id` bigint(20) UNSIGNED NOT NULL,
  `step_index` int(10) UNSIGNED NOT NULL,
  `approver_id` bigint(20) UNSIGNED DEFAULT NULL,
  `approver_role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `approver_position_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `acted_at` timestamp NULL DEFAULT NULL,
  `due_at` timestamp NULL DEFAULT NULL,
  `reminded_at` timestamp NULL DEFAULT NULL,
  `reminder_count` int(11) NOT NULL DEFAULT 0,
  `is_escalated` tinyint(1) NOT NULL DEFAULT 0,
  `escalated_at` timestamp NULL DEFAULT NULL,
  `escalated_from_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `delegated_from_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_fields`
--

CREATE TABLE `request_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `request_type_id` bigint(20) UNSIGNED NOT NULL,
  `field_key` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `request_fields`
--

INSERT INTO `request_fields` (`id`, `request_type_id`, `field_key`, `label`, `field_type`, `is_required`, `description`, `options`, `sort_order`, `created_at`, `updated_at`) VALUES
(126, 1, 'employee_name', 'Employee Name (Auto-filled)', 'text', 1, 'Auto-filled from your employee profile.', NULL, 0, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(127, 1, 'department_office', 'Department/Office (Auto-filled)', 'text', 1, 'Auto-filled from your employee record.', NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(128, 1, 'position_title', 'Position Title (Auto-filled)', 'text', 1, 'Auto-filled from your employee record.', NULL, 2, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(129, 1, 'salary', 'Salary (Auto-filled)', 'text', 0, 'Auto-filled from your employee record.', NULL, 3, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(130, 1, 'date_of_filing', 'Date of Filing (Auto-filled)', 'text', 1, 'Auto-filled with today\'s date.', NULL, 4, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(131, 1, 'leave_type', '5. TYPE OF LEAVE TO BE AVAILED OF', 'dropdown', 1, 'Select leave type per CS Form No. 6 categories', '[{\"label\":\"Vacation Leave (Sec. 51, Rule XVI, Omnibus Rules)\",\"value\":\"VL\"},{\"label\":\"Mandatory\\/Forced Leave (Sec. 25, Rule XVI)\",\"value\":\"FL\"},{\"label\":\"Sick Leave (Sec. 43, Rule XVI)\",\"value\":\"SL\"},{\"label\":\"Maternity Leave (RA 11210)\",\"value\":\"ML\"},{\"label\":\"Paternity Leave (RA 8187)\",\"value\":\"PL\"},{\"label\":\"Special Privilege Leave (Sec. 21, Rule XVI)\",\"value\":\"SPL\"},{\"label\":\"Solo Parent Leave (RA 8972)\",\"value\":\"SoloP\"},{\"label\":\"Study Leave (Sec. 68, Rule XVI)\",\"value\":\"Study\"},{\"label\":\"10-Day VAWC Leave (RA 9262)\",\"value\":\"VAWC\"},{\"label\":\"Rehabilitation Privilege (Sec. 55, Rule XVI)\",\"value\":\"Rehab\"},{\"label\":\"Special Leave Benefits for Women (RA 9710)\",\"value\":\"WSL\"},{\"label\":\"Special Emergency (Calamity) Leave (CSC MC 2, s.2012)\",\"value\":\"CL\"},{\"label\":\"Adoption Leave (RA 8552)\",\"value\":\"Adopt\"},{\"label\":\"Others (specify below)\",\"value\":\"OTHER\"}]', 5, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(132, 1, 'other_leave_specify', 'If Others, please specify', 'text', 0, 'Specify the type of leave if \"Others\" is selected', NULL, 6, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(133, 1, 'leave_location', '6.A. LOCATION (For Vacation/SPL)', 'dropdown', 0, 'Where leave will be spent (required for VL/SPL)', '[{\"label\":\"Within the Philippines\",\"value\":\"within_philippines\"},{\"label\":\"Abroad (specify country)\",\"value\":\"abroad\"}]', 7, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(134, 1, 'location_details', 'Specify Location/Address', 'text', 0, 'Specific address or country if abroad', NULL, 8, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(135, 1, 'sick_leave_type', '6.B. SICK LEAVE TYPE', 'dropdown', 0, 'Required for Sick Leave applications', '[{\"label\":\"In Hospital (specify illness)\",\"value\":\"in_hospital\"},{\"label\":\"Out Patient (specify illness)\",\"value\":\"out_patient\"}]', 9, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(136, 1, 'illness_description', 'Illness/Diagnosis', 'text', 0, 'Specify illness for sick leave', NULL, 10, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(137, 1, 'women_special_illness', '6.C. SPECIAL LEAVE FOR WOMEN - Specify Illness', 'text', 0, 'Required for Special Leave Benefits for Women (gynecological disorder)', NULL, 11, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(138, 1, 'study_leave_type', '6.D. STUDY LEAVE PURPOSE', 'dropdown', 0, 'Purpose of study leave', '[{\"label\":\"Completion of Master\'s Degree\",\"value\":\"completion_masters\"},{\"label\":\"BAR\\/Board Examination Review\",\"value\":\"bar_board_exam\"},{\"label\":\"Other purpose (specify)\",\"value\":\"other\"}]', 12, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(139, 1, 'study_leave_details', 'Study Leave Details', 'text', 0, 'Specify course/examination details', NULL, 13, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(140, 1, 'other_purpose_type', '6.E. OTHER PURPOSE', 'dropdown', 0, 'For monetization or terminal leave', '[{\"label\":\"Monetization of Leave Credits\",\"value\":\"monetization\"},{\"label\":\"Terminal Leave\",\"value\":\"terminal_leave\"}]', 14, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(141, 1, 'start_date', 'INCLUSIVE DATE - Start', 'date', 1, 'First day of leave', NULL, 15, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(142, 1, 'end_date', 'INCLUSIVE DATE - End', 'date', 1, 'Last day of leave', NULL, 16, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(143, 1, 'total_days', 'NUMBER OF WORKING DAYS APPLIED FOR', 'number', 1, 'Total working days (excluding weekends and holidays). Use 0.5 for half-day.', NULL, 17, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(144, 1, 'commutation_requested', 'COMMUTATION', 'dropdown', 1, 'Request for commutation of leave (applicable for VL/SL)', '[{\"label\":\"Not Requested\",\"value\":\"not_requested\"},{\"label\":\"Requested\",\"value\":\"requested\"}]', 18, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(145, 1, 'reason', 'REASON/PURPOSE FOR LEAVE', 'textarea', 1, 'Detailed reason for applying for leave', NULL, 19, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(146, 1, 'contact_number', 'Contact Number While on Leave', 'text', 1, 'Mobile number where employee may be reached', NULL, 20, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(147, 1, 'contact_address', 'Address While on Leave', 'text', 0, 'Address where employee can be contacted during leave', NULL, 21, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(148, 1, 'medical_certificate', 'Medical Certificate', 'file', 0, 'Required for sick leave of 5 days or more. Upload scanned copy.', NULL, 22, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(149, 1, 'supporting_documents', 'Other Supporting Documents', 'file', 0, 'Travel authority, court summons, birth certificate (for maternity/paternity), Solo Parent ID, etc.', NULL, 23, '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(150, 1, 'declaration', 'Declaration', 'checkbox', 1, 'I hereby certify that the information provided above is true and correct.', NULL, 24, '2026-01-28 17:37:33', '2026-01-28 17:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `request_fulfillments`
--

CREATE TABLE `request_fulfillments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `submission_id` bigint(20) UNSIGNED NOT NULL,
  `fulfilled_by` bigint(20) UNSIGNED DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `original_filename` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_submissions`
--

CREATE TABLE `request_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `request_type_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reference_code` varchar(255) NOT NULL,
  `status` enum('pending','approved','fulfillment','completed','rejected') NOT NULL DEFAULT 'pending',
  `current_step_index` int(10) UNSIGNED DEFAULT NULL,
  `approval_state` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`approval_state`)),
  `submitted_at` timestamp NULL DEFAULT NULL,
  `fulfilled_at` timestamp NULL DEFAULT NULL,
  `withdrawn_at` timestamp NULL DEFAULT NULL,
  `withdrawal_reason` text DEFAULT NULL,
  `certificate_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request_types`
--

CREATE TABLE `request_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `has_fulfillment` tinyint(1) NOT NULL DEFAULT 0,
  `certificate_template_id` bigint(20) UNSIGNED DEFAULT NULL,
  `certificate_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`certificate_config`)),
  `approval_steps` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`approval_steps`)),
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `request_types`
--

INSERT INTO `request_types` (`id`, `created_by`, `name`, `description`, `has_fulfillment`, `certificate_template_id`, `certificate_config`, `approval_steps`, `is_published`, `published_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Leave Request', 'CS Form No. 6 (Revised 2020) - Application for Leave. Covers all CSC-mandated leave types including Vacation, Sick, Special Privilege, Maternity, Paternity, and other special leaves.', 1, 1, '{\"field_mappings\":[]}', '[{\"name\":\"Immediate Supervisor Recommendation\",\"description\":\"Section 8.A - Supervisor reviews leave application and provides recommendation for approval\\/disapproval.\",\"approvers\":[],\"sort_order\":0},{\"name\":\"HR Leave Credits Certification\",\"description\":\"Section 7 - HR certifies leave credits as of filing date and validates compliance with CSC rules.\",\"approvers\":[],\"sort_order\":1},{\"name\":\"Authorized Official Approval\",\"description\":\"Section 8.B - Final approval\\/disapproval by authorized official (Head of Office\\/Agency).\",\"approvers\":[],\"sort_order\":2}]', 1, '2026-01-28 17:37:33', '2026-01-27 16:13:30', '2026-01-28 18:52:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `label`, `description`, `is_active`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'Administrator', 'system administrator', 1, 'web', '2026-01-27 16:13:29', '2026-01-27 16:14:53'),
(3, 'super-admin', 'Super Admin', 'Full system access. Cannot be removed.', 1, 'web', '2026-01-28 17:18:32', '2026-01-28 17:18:32'),
(4, 'hr-director', 'HR Director', 'Full HR management including employees, org structure, trainings, and audit logs. Assign to HRMO Director, CAO, or VP Admin.', 1, 'web', '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(5, 'hr-staff', 'HR Staff', 'Day-to-day HR operations including employee records and trainings. Assign to Admin Officers/Assistants in HRMO.', 1, 'web', '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(6, 'unit-head', 'Unit Head', 'View employees within their unit and training records. Assign to Deans, Directors, Program Heads.', 1, 'web', '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(7, 'training-coordinator', 'Training Coordinator', 'Manage training records and view employees. Assign to designated training coordinators.', 1, 'web', '2026-01-28 17:37:33', '2026-01-28 17:37:33'),
(8, 'basic-employee', 'Basic Employee', 'Self-service access only. Default role for all employees.', 1, 'web', '2026-01-28 17:37:33', '2026-01-28 17:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(33, 1),
(34, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(87, 1),
(88, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1),
(97, 1),
(98, 1),
(99, 1),
(100, 1),
(1, 3),
(2, 3),
(3, 3),
(4, 3),
(5, 3),
(6, 3),
(7, 3),
(8, 3),
(9, 3),
(10, 3),
(11, 3),
(12, 3),
(13, 3),
(14, 3),
(15, 3),
(16, 3),
(17, 3),
(18, 3),
(19, 3),
(20, 3),
(22, 3),
(23, 3),
(24, 3),
(25, 3),
(26, 3),
(27, 3),
(28, 3),
(29, 3),
(30, 3),
(31, 3),
(33, 3),
(34, 3),
(56, 3),
(57, 3),
(58, 3),
(59, 3),
(60, 3),
(61, 3),
(62, 3),
(63, 3),
(64, 3),
(65, 3),
(66, 3),
(67, 3),
(68, 3),
(69, 3),
(70, 3),
(71, 3),
(72, 3),
(73, 3),
(74, 3),
(75, 3),
(76, 3),
(77, 3),
(78, 3),
(79, 3),
(80, 3),
(81, 3),
(82, 3),
(83, 3),
(84, 3),
(85, 3),
(86, 3),
(87, 3),
(88, 3),
(90, 3),
(91, 3),
(92, 3),
(93, 3),
(94, 3),
(95, 3),
(96, 3),
(97, 3),
(98, 3),
(99, 3),
(100, 3),
(101, 3),
(102, 3),
(103, 3),
(104, 3),
(105, 3),
(106, 3),
(107, 3),
(108, 3),
(109, 3),
(110, 3),
(111, 3),
(112, 3),
(113, 3),
(114, 3),
(115, 3),
(116, 3),
(1, 4),
(5, 4),
(6, 4),
(7, 4),
(8, 4),
(25, 4),
(26, 4),
(27, 4),
(28, 4),
(29, 4),
(33, 4),
(34, 4),
(56, 4),
(57, 4),
(58, 4),
(59, 4),
(60, 4),
(61, 4),
(62, 4),
(63, 4),
(64, 4),
(65, 4),
(66, 4),
(67, 4),
(68, 4),
(69, 4),
(70, 4),
(71, 4),
(72, 4),
(73, 4),
(74, 4),
(75, 4),
(76, 4),
(77, 4),
(78, 4),
(79, 4),
(80, 4),
(81, 4),
(82, 4),
(83, 4),
(84, 4),
(85, 4),
(86, 4),
(87, 4),
(88, 4),
(90, 4),
(91, 4),
(92, 4),
(93, 4),
(94, 4),
(95, 4),
(96, 4),
(97, 4),
(98, 4),
(99, 4),
(100, 4),
(103, 4),
(104, 4),
(105, 4),
(106, 4),
(107, 4),
(108, 4),
(109, 4),
(110, 4),
(111, 4),
(112, 4),
(113, 4),
(114, 4),
(115, 4),
(116, 4),
(5, 5),
(7, 5),
(25, 5),
(26, 5),
(28, 5),
(29, 5),
(56, 5),
(60, 5),
(63, 5),
(67, 5),
(70, 5),
(74, 5),
(77, 5),
(81, 5),
(85, 5),
(88, 5),
(90, 5),
(91, 5),
(92, 5),
(94, 5),
(100, 5),
(103, 5),
(107, 5),
(110, 5),
(114, 5),
(5, 6),
(7, 6),
(28, 6),
(56, 6),
(60, 6),
(63, 6),
(67, 6),
(70, 6),
(74, 6),
(85, 6),
(88, 6),
(90, 6),
(94, 6),
(102, 6),
(103, 6),
(107, 6),
(110, 6),
(114, 6),
(5, 7),
(28, 7),
(63, 7),
(67, 7),
(70, 7),
(74, 7),
(90, 7),
(91, 7),
(92, 7),
(93, 7),
(94, 7),
(95, 7),
(102, 7),
(56, 8),
(60, 8),
(63, 8),
(67, 8),
(70, 8),
(74, 8);

-- --------------------------------------------------------

--
-- Table structure for table `sectors`
--

CREATE TABLE `sectors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sectors`
--

INSERT INTO `sectors` (`id`, `name`, `code`, `description`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Academic', 'ACAD', 'Academic units (Colleges and Programs)', 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(2, 'Administrative', 'ADMIN', 'Administrative units (Offices)', 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('4aLTY9PsNZVrMAfbb6Rfvfp3cJLmx2Lm0iotv6IT', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoic1VUU083TTdrUHVPRVB5andIUldUb0NKRmU2RVFJOUxJd1dXOXlmYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvb2F1dGgvYXV0aG9yaXplP2NsaWVudF9pZD0wMTljMGEzMS04ZThlLTcxZDMtOGQzYi1lNDEyNmFiMjYyZDAmcmVkaXJlY3RfdXJpPWh0dHAlM0ElMkYlMkZsb2NhbGhvc3QlM0E4MDAwJTJGb2F1dGhfY2FsbGJhY2sucGhwJnJlc3BvbnNlX3R5cGU9Y29kZSZzY29wZT1vcGVuaWQlMjBwcm9maWxlJTIwZW1haWwmc3RhdGU9ODE0NWVjM2NlZWUzZDlkZjQ3Y2ZlZTAyMWM1NTNhNDMiO3M6NToicm91dGUiO3M6MTU6Im9hdXRoLmF1dGhvcml6ZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MjM3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvb2F1dGgvYXV0aG9yaXplP2NsaWVudF9pZD0wMTljMGEzMS04ZThlLTcxZDMtOGQzYi1lNDEyNmFiMjYyZDAmcmVkaXJlY3RfdXJpPWh0dHAlM0ElMkYlMkZsb2NhbGhvc3QlM0E4MDAwJTJGb2F1dGhfY2FsbGJhY2sucGhwJnJlc3BvbnNlX3R5cGU9Y29kZSZzY29wZT1vcGVuaWQlMjBwcm9maWxlJTIwZW1haWwmc3RhdGU9ODE0NWVjM2NlZWUzZDlkZjQ3Y2ZlZTAyMWM1NTNhNDMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO3M6MTY6Imxhc3RfYWN0aXZpdHlfaWQiO2k6MTk7czoxNDoib2F1dGhfcmVkaXJlY3QiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vYXV0aC9hdXRob3JpemUiO30=', 1769699547),
('6XBXDoUC980dxFMC68D2Caiwaw73SAsza22PmJwt', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDBHTWIzVGE5ZzlyVndOVFlscUhzSFhFUGFyZ0RsbDJUOFBaNmNDcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769697213),
('bMiA4ExKpYb3PPzBUPD5v4IbeBY59mSs0IJrCIHn', NULL, '127.0.0.1', '', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiT2lJUXo1NlZlZnN6Q1NCZVhXd2puOEF5NEFYanBMV1E5MGNiMjA3QiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769699547),
('ciZtetl7U9APjIVURcADIiawoG0m8Gbc2LduWZI3', 2, '127.0.0.1', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiekVlR3NZaUU5b3Q1aWJ3UEZ3WmoxdnlHT3BEaUwydHZGQVlLdjlBdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vYXV0aC91c2VyaW5mbyI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769695222),
('DuZPaJRD0sUKQO40YZ55LNipkZ5sXMrmGVz9WaYD', NULL, '127.0.0.1', '', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiYVR2YUFWWkxITWJaNDl1SVNsUXE3b3MwUnp5MXpLUXhZb2tpaVhYdCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769699446),
('KHuwldebEqKIGrMdw1xMghOX6R7CabtW6oWyyOXG', NULL, '127.0.0.1', '', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiYzlGelFBQkhzRkUydmZSMmFONFh6VlYzZ0QwbTVLcVc0cEFEV2NiUyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769695222),
('md5e5aVo3XDW8vvA4RQ5SR3QBhHyJO8VtpLZGnGT', 1, '127.0.0.1', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0FvNnlxdUd1YzFIZmtqd0pxbEwzNVI4MzZPYVIxMG00Wk5JTndnTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vYXV0aC91c2VyaW5mbyI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769699446),
('Mmd9AL4W2x6F7oUXNc0GneaND3ilwO7T7WiByZRS', 2, '127.0.0.1', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicmc5YkdhT25GVEJxZnhWTTE5alVaYnFaTXZOODJhc05JTzBQNEFmdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9vYXV0aC91c2VyaW5mbyI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769699548),
('Q5lvuc3h7IuVTOvXKwjxC2vnPuogfn2gD1lPOOYY', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiektLU3dBanBZQVVVRnRNVGxGc3NBSHRpUHhrNDNwbTZtRlQ0NFQzaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTU2OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvdW5pdHM/cGVyUGFnZT0xMCZzZWFyY2g9QWcuJTIwRWNvbi4lMjAlMjYlMjBNa3RnLiZzZWFyY2hfbW9kZT1hbnkmc2VjdG9yX2lkPSZzaG93X2RlbGV0ZWQ9ZmFsc2Umc29ydF9ieT1uYW1lJnNvcnRfb3JkZXI9YXNjJnVuaXRfdHlwZT0iO3M6NToicm91dGUiO3M6MTE6InVuaXRzLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE2OiJsYXN0X2FjdGl2aXR5X2lkIjtpOjEzO3M6MTQ6Im9hdXRoX3JlZGlyZWN0IjtzOjM3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvb2F1dGgvYXV0aG9yaXplIjt9', 1769695619),
('RlUt3NLX7O53PE0LuUKHS3Vebr9cVVwYDQDae0ID', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVNTd1BaZTNoeVJwOVlodjBQeVZ5QVg0b1drb1NmM3UyeDBSS0VXWSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9fQ==', 1769701675);

-- --------------------------------------------------------

--
-- Table structure for table `staff_grades`
--

CREATE TABLE `staff_grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `level` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff_grades`
--

INSERT INTO `staff_grades` (`id`, `name`, `code`, `level`, `description`, `is_active`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Administrative Aide I', 'ADMIN_AIDE_I', 1, NULL, 1, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(2, 'Administrative Aide II', 'ADMIN_AIDE_II', 2, NULL, 1, 2, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(3, 'Administrative Aide III', 'ADMIN_AIDE_III', 3, NULL, 1, 3, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(4, 'Administrative Officer I', 'ADMIN_OFF_I', 12, NULL, 1, 12, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(5, 'Administrative Officer II', 'ADMIN_OFF_II', 13, NULL, 1, 13, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(6, 'Administrative Officer III', 'ADMIN_OFF_III', 14, NULL, 1, 14, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(7, 'Administrative Officer IV', 'ADMIN_OFF_IV', 15, NULL, 1, 15, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(8, 'Senior Administrative Officer I', 'SR_ADMIN_OFF_I', 8, NULL, 1, 8, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(9, 'Senior Administrative Officer II', 'SR_ADMIN_OFF_II', 9, NULL, 1, 9, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(10, 'Senior Administrative Officer III', 'SR_ADMIN_OFF_III', 10, NULL, 1, 10, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(11, 'Administrative Aide IV', 'ADMIN_AIDE_IV', 4, NULL, 1, 4, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(12, 'Administrative Aide V', 'ADMIN_AIDE_V', 5, NULL, 1, 5, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(13, 'Administrative Aide VI', 'ADMIN_AIDE_VI', 6, NULL, 1, 6, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(14, 'Administrative Assistant I', 'ADMIN_ASST_I', 7, NULL, 1, 7, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(15, 'Administrative Assistant II', 'ADMIN_ASST_II', 8, NULL, 1, 8, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(16, 'Administrative Assistant III', 'ADMIN_ASST_III', 9, NULL, 1, 9, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(17, 'Administrative Assistant IV', 'ADMIN_ASST_IV', 10, NULL, 1, 10, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(18, 'Administrative Assistant V', 'ADMIN_ASST_V', 11, NULL, 1, 11, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(19, 'Administrative Officer V', 'ADMIN_OFF_V', 16, NULL, 1, 16, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(20, 'Supervising Administrative Officer', 'SUP_ADMIN_OFF', 17, NULL, 1, 17, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(21, 'Chief Administrative Officer', 'CHIEF_ADMIN_OFF', 18, NULL, 1, 18, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `trainings`
--

CREATE TABLE `trainings` (
  `training_id` bigint(20) UNSIGNED NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `training_title` varchar(100) NOT NULL,
  `training_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `hours` decimal(5,2) NOT NULL,
  `facilitator` varchar(100) DEFAULT NULL,
  `venue` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `requires_approval` tinyint(1) NOT NULL DEFAULT 0,
  `request_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trainings`
--

INSERT INTO `trainings` (`training_id`, `reference_number`, `training_title`, `training_category_id`, `date_from`, `date_to`, `hours`, `facilitator`, `venue`, `capacity`, `remarks`, `requires_approval`, `request_type_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'TRG-000001-20260203', 'asdasd', NULL, '2026-02-03', '2026-03-04', 4.00, 'Arvin Negrillo', 'Canuctan Hall', 23, 'xd', 0, NULL, '2026-01-29 03:12:42', '2026-01-29 03:12:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `training_allowed_positions`
--

CREATE TABLE `training_allowed_positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `training_id` bigint(20) UNSIGNED NOT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `training_allowed_sectors`
--

CREATE TABLE `training_allowed_sectors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `training_id` bigint(20) UNSIGNED NOT NULL,
  `sector_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_allowed_sectors`
--

INSERT INTO `training_allowed_sectors` (`id`, `training_id`, `sector_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-01-29 03:12:42', '2026-01-29 03:12:42');

-- --------------------------------------------------------

--
-- Table structure for table `training_allowed_units`
--

CREATE TABLE `training_allowed_units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `training_id` bigint(20) UNSIGNED NOT NULL,
  `unit_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_allowed_units`
--

INSERT INTO `training_allowed_units` (`id`, `training_id`, `unit_id`, `created_at`, `updated_at`) VALUES
(1, 1, 98, '2026-01-29 03:12:42', '2026-01-29 03:12:42');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sector_id` bigint(20) UNSIGNED NOT NULL,
  `unit_type` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `parent_unit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `sector_id`, `unit_type`, `name`, `code`, `parent_unit_id`, `description`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'college', 'College of Agriculture', 'COA', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(2, 1, 'program', 'DAS', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(3, 1, 'program', 'Crop Science', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(4, 1, 'program', 'Ag. Ex. & Comm.', NULL, 1, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(5, 1, 'program', 'Soil Science', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(6, 1, 'program', 'Animal Science', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(7, 1, 'program', 'Crop Protection', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(8, 1, 'program', 'Ag. Econ. & Mktg.', NULL, 1, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(9, 1, 'college', 'College of Arts & Social Sciences', 'COASS', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(10, 1, 'college', 'College of Business Management and Accountancy', 'COBMAA', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(11, 1, 'program', 'Bachelor of Science in Accountancy (BSAcct)', NULL, 10, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(12, 1, 'program', 'Bachelor of Science in Accounting Information System (BSAIS)', NULL, 10, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(13, 1, 'program', 'Bachelor of Science in Business Administration (BSBA)', NULL, 10, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(14, 1, 'program', 'Bachelor of Science in Entrepreneurship (BSEntrep)', NULL, 10, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(15, 1, 'college', 'College of Criminal Justice Education Bachelor of Science in Criminology', 'COCJEBOSIC', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(16, 1, 'program', 'Bachelor of Science in Criminology (BSCrim)', NULL, 15, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(17, 1, 'college', 'College of Computer Studies', 'COCS', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(18, 1, 'program', 'Bachelor of Science in Computer Science (BSCS)', NULL, 17, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(19, 1, 'program', 'Bachelor of Science in Information Technology (BSIT)', NULL, 17, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(20, 1, 'program', 'Bachelor of Science in Entertainment and Multimedia Computing (BSEMC) - Digital Animation', NULL, 17, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(21, 1, 'program', 'Associate in Computer Technology (ACT)', NULL, 17, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(22, 1, 'college', 'College of Fisheries & Aquatic Sciences', 'COFAS', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(23, 1, 'college', 'College of Hospitality Management', 'COHM', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(24, 1, 'program', 'Bachelor of Science in Tourism Management (BSTM)', NULL, 23, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(25, 1, 'program', 'Bachelor of Science in Hospitality Management (BSHM)', NULL, 23, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(26, 1, 'college', 'College of Engineering', 'COE', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(27, 1, 'program', 'Bachelor of Science in Civil Engineering (BSCE)', NULL, 26, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(28, 1, 'program', 'Bachelor of Science in Electrical Engineering (BSEE)', NULL, 26, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(29, 1, 'program', 'Bachelor of Science in Computer Engineering (BSCpE)', NULL, 26, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(30, 1, 'college', 'College of Education', 'COED', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(31, 1, 'program', 'Bachelor of Elementary Education (BEED)', NULL, 30, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(32, 1, 'program', 'Bachelor of Secondary Education (BSED)', NULL, 30, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(33, 1, 'program', 'Bachelor of Early Childhood Education (BECED)', NULL, 30, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(34, 1, 'college', 'College of Law', 'COL', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(35, 1, 'program', 'Juris Doctor (JD)', NULL, 34, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(36, 1, 'college', 'College of Nursing', 'CON', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(37, 1, 'program', 'Bachelor of Science in Nursing (BSND)', NULL, 36, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(38, 1, 'program', 'Bachelor of Science in Nursing (BSN)', NULL, 36, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(39, 1, 'program', 'Diploma in Midwifery (DM)', NULL, 36, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(40, 1, 'college', 'College of Technology', 'COT', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(41, 1, 'program', 'Automotive Technology', NULL, 40, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(42, 1, 'program', 'Architectural Drafting Technology', NULL, 40, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(43, 1, 'program', 'Electrical Technology', NULL, 40, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(44, 1, 'program', 'Electronics Technology', NULL, 40, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(45, 1, 'college', 'College of Science', 'COS', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(46, 1, 'program', 'BS in Environmental Science', NULL, 45, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(47, 1, 'program', 'BS in Biology', NULL, 45, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(48, 1, 'college', 'Graduate School', 'GS', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(49, 1, 'program', 'PhD in Education', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(50, 1, 'program', 'MA in Teaching Vocational Education', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(51, 1, 'program', 'MA in Education', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(52, 1, 'program', 'PhD in Animal Science and Master in Agricultural Science', NULL, 48, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(53, 1, 'program', 'MA in Management', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(54, 1, 'program', 'PhD in Crop and Science and Master in Agricultural Science', NULL, 48, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(55, 1, 'program', 'MA in Engineering', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(56, 1, 'program', 'MS in Criminal Justice Education', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(57, 2, 'office', 'Accounting Office', 'AO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(58, 2, 'office', 'Admission Services Office', 'ASO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(59, 2, 'office', 'Administrative and Support Services Offices', 'AASSO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(60, 2, 'office', 'Procurement Office', 'PO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(61, 2, 'office', 'Bids and Awards Committee Office', 'BAACO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(62, 2, 'office', 'Budget Office', 'BO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(63, 2, 'office', 'Cashier\'s Office', 'CSO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(64, 2, 'office', 'Guidance and Counseling Services Office', 'GACSO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(65, 2, 'office', 'Human Resource Management Office', 'HRMO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(66, 2, 'office', 'Internal Control Office', 'ICO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(67, 2, 'office', 'Information and Communication Technology Center', 'IACTC', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(68, 2, 'office', 'Infrastructure Projects Development Engineering Services Office', 'IPDESO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(69, 2, 'office', 'Institutional Planning & Development Office', 'IPDO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(70, 2, 'office', 'Knowledge Management Office', 'KMO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(71, 2, 'office', 'Legal Office', 'LO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(72, 2, 'office', 'University Library', 'UL', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(73, 2, 'office', 'Motorpool & Transportation Services Office', 'MTSO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(74, 2, 'office', 'Physical Plant and Facilities Office', 'PPAFO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(75, 2, 'office', 'Office of the Quality Assurance and Accreditation Center', 'OOTQAAAC', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(76, 2, 'office', 'Registrar\'s Office', 'RSO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(77, 2, 'office', 'Records Management Office', 'RMO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(78, 2, 'office', 'Training and Extension Service Office', 'TAESO', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(79, 2, 'office', 'Utilities and Equipment Services', 'UAES', NULL, NULL, 1, '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(97, 1, 'program', 'Agricultural Extension & Communication', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(98, 1, 'program', 'Agricultural Economics & Marketing', NULL, 1, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(99, 1, 'college', 'College of Business Management and Accountancy', 'COBMA', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(100, 1, 'program', 'Bachelor of Science in Accountancy (BSAcc)', NULL, 99, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(101, 1, 'program', 'Bachelor of Science in Accounting Information System (BSAIS)', NULL, 99, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(102, 1, 'program', 'Bachelor of Science in Business Administration (BSBA)', NULL, 99, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(103, 1, 'program', 'Bachelor of Science in Entrepreneurship (BSEntrep)', NULL, 99, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(104, 1, 'college', 'College of Criminal Justice Education', 'CCJE', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(105, 1, 'program', 'Bachelor of Science in Criminology (BSCrim)', NULL, 104, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(106, 1, 'college', 'College of Computer Studies', 'CCS', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(107, 1, 'program', 'Bachelor of Science in Computer Science (BSCS)', NULL, 106, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(108, 1, 'program', 'Bachelor of Science in Information Technology (BSIT)', NULL, 106, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(109, 1, 'program', 'Bachelor of Science in Entertainment and Multimedia Computing (BSEMC) - Digital Animation', NULL, 106, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(110, 1, 'program', 'Associate in Computer Technology (ACT)', NULL, 106, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(111, 1, 'college', 'College of Fisheries & Aquatic Sciences', 'CFAS', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(112, 1, 'program', 'Capture Fisheries', NULL, 111, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(113, 1, 'program', 'Aquaculture', NULL, 111, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(114, 1, 'program', 'Fisheries Extension', NULL, 111, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(115, 1, 'program', 'Post-harvest', NULL, 111, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(116, 1, 'program', 'Aquatic Resources and Ecology', NULL, 111, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(117, 1, 'college', 'College of Hospitality Management', 'CHM', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(118, 1, 'program', 'Bachelor of Science in Tourism Management (BSTM)', NULL, 117, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(119, 1, 'program', 'Bachelor of Science in Hospitality Management (BSHM)', NULL, 117, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(120, 1, 'program', 'Bachelor of Science in Nursing Diploma (BSND)', NULL, 36, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(121, 1, 'program', 'Bachelor of Science in Environmental Science', NULL, 45, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(122, 1, 'program', 'Bachelor of Science in Biology', NULL, 45, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(123, 1, 'program', 'PhD in Animal Science', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(124, 1, 'program', 'Master in Agricultural Science', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(125, 1, 'program', 'PhD in Crop Science', NULL, 48, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(126, 2, 'office', 'Admission, Registration & Records Office', 'ARRO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(127, 2, 'office', 'Administrative and Support Services Office', 'ASSO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(128, 2, 'office', 'Bids and Awards Committee Office', 'BACO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(129, 2, 'office', 'Office of the Chief Administrative Officer', 'OCAO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(130, 2, 'office', 'Cashier\'s Office', 'CO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(131, 2, 'office', 'Gender and Development Office', 'GAD', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(132, 2, 'office', 'Guidance and Counseling Services Office', 'GCSO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(133, 2, 'office', 'Information and Communication Technology Center', 'ICTC', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(134, 2, 'office', 'Income Generating Project Office', 'IGP', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(135, 2, 'office', 'University Infirmary', 'UI', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(136, 2, 'office', 'Intellectual Property Office of the University', 'IPOU', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(137, 2, 'office', 'Innovation and Technology Support Office', 'ITSO', NULL, NULL, 1, '2026-01-28 17:37:32', '2026-01-28 17:37:32', NULL),
(138, 2, 'office', 'Knowledge and Technology Transfer Office', 'KTTO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(139, 2, 'office', 'Legal Aid Clinic', 'LAC', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(140, 2, 'office', 'National Service Training Program Office', 'NSTP', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(141, 2, 'office', 'Office of the University President', 'OUP', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(142, 2, 'office', 'Office of the Vice President for Research, Extension and Innovation', 'OVPREI', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(143, 2, 'office', 'Office of the Vice President for External Affairs & Quality Assurance', 'OVPEAQA', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(144, 2, 'office', 'Physical Plant and Facilities Office', 'PPFO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(145, 2, 'office', 'Public Relations & Information Management Office', 'PRIMO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(146, 2, 'office', 'Quality Assurance and Accreditation Center', 'QAAC', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(147, 2, 'office', 'Research and Development Services Office', 'RDSO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(148, 2, 'office', 'Registrar\'s Office', 'RO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(149, 2, 'office', 'Supply and Property Management Office', 'SPMO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(150, 2, 'office', 'Sports and Physical Fitness Office', 'SPFO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(151, 2, 'office', 'Training and Extension Service Office', 'TESO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(152, 2, 'office', 'University Disaster Risk Reduction and Management Office', 'UDRRMO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(153, 2, 'office', 'Utilities and Equipment Services Office', 'UESO', NULL, NULL, 1, '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `unit_positions`
--

CREATE TABLE `unit_positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_type` varchar(20) NOT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `unit_positions`
--

INSERT INTO `unit_positions` (`id`, `unit_type`, `position_id`, `is_active`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'college', 4, 1, 'Auto-seeded: Dean for college', '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(2, 'college', 7, 1, 'Whitelisted: Faculty for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(3, 'college', 1, 1, 'Whitelisted: University President for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(4, 'college', 3, 1, 'Whitelisted: Vice President for Administration for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(5, 'college', 2, 1, 'Whitelisted: Vice President for Academic Affairs for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(6, 'program', 6, 1, 'Whitelisted: Program Head for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(7, 'program', 7, 1, 'Whitelisted: Faculty for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(8, 'program', 1, 1, 'Whitelisted: University President for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(9, 'program', 3, 1, 'Whitelisted: Vice President for Administration for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(10, 'program', 2, 1, 'Whitelisted: Vice President for Academic Affairs for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(11, 'office', 9, 1, 'Whitelisted: Director for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(12, 'office', 12, 1, 'Auto-seeded: Staff for office', '2026-01-27 16:13:29', '2026-01-27 16:13:29', NULL),
(13, 'office', 1, 1, 'Whitelisted: University President for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(14, 'office', 3, 1, 'Whitelisted: Vice President for Administration for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(15, 'office', 2, 1, 'Whitelisted: Vice President for Academic Affairs for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(16, 'college', 19, 1, 'Whitelisted: College Dean for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(17, 'college', 20, 1, 'Whitelisted: Associate Dean for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(18, 'college', 21, 1, 'Whitelisted: College Secretary for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(19, 'college', 33, 1, 'Whitelisted: Visiting Dean for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(20, 'college', 22, 1, 'Whitelisted: Research Coordinator for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(21, 'college', 23, 1, 'Whitelisted: Extension Coordinator for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(22, 'college', 29, 1, 'Whitelisted: QAA Coordinator for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(23, 'college', 28, 1, 'Whitelisted: GAD Focal Person for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(24, 'college', 31, 1, 'Whitelisted: Lecturer for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(25, 'college', 32, 1, 'Whitelisted: Affiliate Faculty for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(26, 'college', 35, 1, 'Whitelisted: College Librarian for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(27, 'college', 34, 1, 'Whitelisted: Laboratory In-Charge for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(28, 'college', 36, 1, 'Whitelisted: Administrative Staff for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(29, 'college', 14, 1, 'Whitelisted: SUC President III for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(30, 'college', 15, 1, 'Whitelisted: Vice President for Research and Extension for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(31, 'college', 16, 1, 'Whitelisted: Vice President for External Affairs and Quality Assurance for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(32, 'college', 17, 1, 'Whitelisted: Board Secretary V for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(33, 'college', 18, 1, 'Whitelisted: Board Secretary I for college units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(34, 'program', 24, 1, 'Whitelisted: OJT Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(35, 'program', 25, 1, 'Whitelisted: Internship Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(36, 'program', 26, 1, 'Whitelisted: Student Services Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(37, 'program', 27, 1, 'Whitelisted: Alumni Affairs Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(38, 'program', 30, 1, 'Whitelisted: Clinical Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(39, 'program', 22, 1, 'Whitelisted: Research Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(40, 'program', 23, 1, 'Whitelisted: Extension Coordinator for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(41, 'program', 31, 1, 'Whitelisted: Lecturer for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(42, 'program', 32, 1, 'Whitelisted: Affiliate Faculty for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(43, 'program', 34, 1, 'Whitelisted: Laboratory In-Charge for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(44, 'program', 36, 1, 'Whitelisted: Administrative Staff for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(45, 'program', 14, 1, 'Whitelisted: SUC President III for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(46, 'program', 15, 1, 'Whitelisted: Vice President for Research and Extension for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(47, 'program', 16, 1, 'Whitelisted: Vice President for External Affairs and Quality Assurance for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(48, 'program', 17, 1, 'Whitelisted: Board Secretary V for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(49, 'program', 18, 1, 'Whitelisted: Board Secretary I for program units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(50, 'office', 37, 1, 'Whitelisted: Assistant Director for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(51, 'office', 39, 1, 'Whitelisted: Chief Administrative Officer for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(52, 'office', 38, 1, 'Whitelisted: Chief Administrative Officer (Finance) for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(53, 'office', 40, 1, 'Whitelisted: Supervising Administrative Officer for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(54, 'office', 41, 1, 'Whitelisted: Administrative Officer V for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(55, 'office', 42, 1, 'Whitelisted: Administrative Officer IV for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(56, 'office', 43, 1, 'Whitelisted: Administrative Officer III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(57, 'office', 44, 1, 'Whitelisted: Administrative Officer II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(58, 'office', 45, 1, 'Whitelisted: Administrative Officer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(59, 'office', 46, 1, 'Whitelisted: Administrative Assistant V for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(60, 'office', 47, 1, 'Whitelisted: Administrative Assistant III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(61, 'office', 48, 1, 'Whitelisted: Administrative Assistant II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(62, 'office', 49, 1, 'Whitelisted: Administrative Assistant I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(63, 'office', 50, 1, 'Whitelisted: Administrative Aide VI for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(64, 'office', 51, 1, 'Whitelisted: Administrative Aide IV for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(65, 'office', 52, 1, 'Whitelisted: Administrative Aide III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(66, 'office', 53, 1, 'Whitelisted: Administrative Aide I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(67, 'office', 54, 1, 'Whitelisted: Accountant III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(68, 'office', 55, 1, 'Whitelisted: Accountant II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(69, 'office', 56, 1, 'Whitelisted: Budget Officer IV for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(70, 'office', 57, 1, 'Whitelisted: Budget Officer III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(71, 'office', 58, 1, 'Whitelisted: Budget Officer II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(72, 'office', 59, 1, 'Whitelisted: Budget Officer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(73, 'office', 60, 1, 'Whitelisted: Cashier III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(74, 'office', 61, 1, 'Whitelisted: Cashier II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(75, 'office', 62, 1, 'Whitelisted: Collecting Officer for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(76, 'office', 63, 1, 'Whitelisted: Disbursing Officer for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(77, 'office', 64, 1, 'Whitelisted: HRMO Director for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(78, 'office', 65, 1, 'Whitelisted: Attorney IV for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(79, 'office', 66, 1, 'Whitelisted: Legal Assistant III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(80, 'office', 67, 1, 'Whitelisted: Legal Assistant II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(81, 'office', 68, 1, 'Whitelisted: Internal Auditor III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(82, 'office', 69, 1, 'Whitelisted: Internal Auditor II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(83, 'office', 70, 1, 'Whitelisted: Internal Auditor I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(84, 'office', 71, 1, 'Whitelisted: University Registrar for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(85, 'office', 72, 1, 'Whitelisted: Registrar III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(86, 'office', 73, 1, 'Whitelisted: Records Officer III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(87, 'office', 74, 1, 'Whitelisted: Director, Library Services for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(88, 'office', 75, 1, 'Whitelisted: College Librarian I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(89, 'office', 76, 1, 'Whitelisted: ICTC Director for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(90, 'office', 77, 1, 'Whitelisted: Computer Programmer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(91, 'office', 78, 1, 'Whitelisted: Project Development Officer III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(92, 'office', 79, 1, 'Whitelisted: Project Development Officer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(93, 'office', 80, 1, 'Whitelisted: Planning Officer II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(94, 'office', 81, 1, 'Whitelisted: Architect for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(95, 'office', 82, 1, 'Whitelisted: Engineer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(96, 'office', 83, 1, 'Whitelisted: Procurement Officer for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(97, 'office', 84, 1, 'Whitelisted: BAC Chairman for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(98, 'office', 85, 1, 'Whitelisted: BAC Vice-Chairman for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(99, 'office', 86, 1, 'Whitelisted: BAC Member for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(100, 'office', 87, 1, 'Whitelisted: Dentist II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(101, 'office', 88, 1, 'Whitelisted: Nurse II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(102, 'office', 89, 1, 'Whitelisted: Nutritionist Dietitian II for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(103, 'office', 90, 1, 'Whitelisted: University Psychometrician for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(104, 'office', 91, 1, 'Whitelisted: Information Officer III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(105, 'office', 92, 1, 'Whitelisted: Information Officer I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(106, 'office', 93, 1, 'Whitelisted: Senior Agriculturist for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(107, 'office', 94, 1, 'Whitelisted: Executive Secretary for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(108, 'office', 95, 1, 'Whitelisted: Secretary for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(109, 'office', 96, 1, 'Whitelisted: Clerk for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(110, 'office', 97, 1, 'Whitelisted: Storekeeper for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(111, 'office', 98, 1, 'Whitelisted: Inspector for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(112, 'office', 99, 1, 'Whitelisted: Utility for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(113, 'office', 100, 1, 'Whitelisted: Driver for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(114, 'office', 101, 1, 'Whitelisted: Security Guard for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(115, 'office', 102, 1, 'Whitelisted: Skilled Worker for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(116, 'office', 103, 1, 'Whitelisted: Electrician for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(117, 'office', 104, 1, 'Whitelisted: Plumber for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(118, 'office', 105, 1, 'Whitelisted: Job Order for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(119, 'office', 14, 1, 'Whitelisted: SUC President III for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(120, 'office', 15, 1, 'Whitelisted: Vice President for Research and Extension for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(121, 'office', 16, 1, 'Whitelisted: Vice President for External Affairs and Quality Assurance for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(122, 'office', 17, 1, 'Whitelisted: Board Secretary V for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL),
(123, 'office', 18, 1, 'Whitelisted: Board Secretary I for office units', '2026-01-28 17:37:33', '2026-01-28 17:37:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `employee_id` varchar(15) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `employee_id`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'EMP0001', NULL, '$2y$12$eTnudBReXcVSh7UTDZVGvuf60r6jHmC9lvnEmy9D88ziqRxVB2wSu', 'L44Q3M77CP7H4QWJAWPL62VUZLRNUZKJ', NULL, NULL, 'driXYY9lfjBJNzAjTqBFUzHBiDFikPcVIlR3wBCstcsBCb776GqeJhS0m2yF', '2026-01-27 16:13:29', '2026-01-28 18:12:47', NULL),
(2, 'jr', 'superadmin@example.com', 'EMP0003', NULL, '$2y$12$1dwqOzAs6zgxjblBtksZPOa9z1ijCqFUS2mgQkGwnQ91gYcHEoQGe', NULL, NULL, NULL, NULL, '2026-01-28 17:21:22', '2026-01-29 04:28:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_activities`
--

CREATE TABLE `user_activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL COMMENT 'User name at time of activity; preserved when user is deleted',
  `user_email` varchar(255) DEFAULT NULL COMMENT 'User email at time of activity; preserved when user is deleted',
  `activity_type` enum('login','logout','login_failed','oauth_logout','oauth_login','session_expired') DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `status` enum('success','failed') NOT NULL DEFAULT 'success',
  `login_time` timestamp NULL DEFAULT NULL,
  `logout_time` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_activities`
--

INSERT INTO `user_activities` (`id`, `user_id`, `user_name`, `user_email`, `activity_type`, `ip_address`, `user_agent`, `device`, `browser`, `status`, `login_time`, `logout_time`, `created_at`, `updated_at`) VALUES
(1, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-27 16:13:59', NULL, '2026-01-27 16:13:59', '2026-01-27 16:13:59'),
(2, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-28 03:53:41', NULL, '2026-01-28 03:53:41', '2026-01-28 03:53:41'),
(3, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-28 16:47:22', NULL, '2026-01-28 16:47:22', '2026-01-28 16:47:22'),
(4, 2, 'jr', 'superadmin@example.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-28 17:21:35', NULL, '2026-01-28 17:21:35', '2026-01-28 17:21:35'),
(5, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 02:58:28', NULL, '2026-01-29 02:58:28', '2026-01-29 02:58:28'),
(6, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', NULL, '2026-01-29 02:59:49', '2026-01-29 02:59:49', '2026-01-29 02:59:49'),
(7, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 03:00:14', NULL, '2026-01-29 03:00:14', '2026-01-29 03:00:14'),
(8, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 03:00:16', NULL, '2026-01-29 03:00:16', '2026-01-29 03:00:16'),
(9, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 03:01:53', NULL, '2026-01-29 03:01:53', '2026-01-29 03:01:53'),
(10, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', NULL, '2026-01-29 04:28:24', '2026-01-29 04:28:24', '2026-01-29 04:28:24'),
(11, 2, 'jr', 'superadmin@example.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 04:28:31', NULL, '2026-01-29 04:28:31', '2026-01-29 04:28:31'),
(12, 2, 'jr', 'superadmin@example.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 04:28:41', NULL, '2026-01-29 04:28:41', '2026-01-29 04:28:41'),
(13, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 04:37:23', NULL, '2026-01-29 04:37:23', '2026-01-29 04:37:23'),
(14, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 05:04:51', NULL, '2026-01-29 05:04:51', '2026-01-29 05:04:51'),
(15, 2, 'jr', 'superadmin@example.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 06:00:20', NULL, '2026-01-29 06:00:20', '2026-01-29 06:00:20'),
(16, 2, 'jr', 'superadmin@example.com', 'logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', NULL, '2026-01-29 06:34:17', '2026-01-29 06:34:17', '2026-01-29 06:34:17'),
(17, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 06:37:38', NULL, '2026-01-29 06:37:38', '2026-01-29 06:37:38'),
(18, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 07:10:45', NULL, '2026-01-29 07:10:45', '2026-01-29 07:10:45'),
(19, 2, 'jr', 'superadmin@example.com', 'login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 07:12:25', NULL, '2026-01-29 07:12:25', '2026-01-29 07:12:25'),
(20, 2, 'jr', 'superadmin@example.com', 'oauth_login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', '2026-01-29 07:12:27', NULL, '2026-01-29 07:12:27', '2026-01-29 07:12:27'),
(21, 1, 'Super Admin', 'arvinnegrillo4@gmail.com', 'logout', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'Desktop', 'Chrome', 'success', NULL, '2026-01-29 07:47:06', '2026-01-29 07:47:06', '2026-01-29 07:47:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_audit_log`
--

CREATE TABLE `user_audit_log` (
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action_type` enum('CREATE','UPDATE','DELETE') NOT NULL,
  `field_changed` varchar(100) DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`snapshot`)),
  `action_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `performed_by` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_ranks`
--
ALTER TABLE `academic_ranks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `academic_ranks_code_unique` (`code`),
  ADD KEY `academic_ranks_level_index` (`level`),
  ADD KEY `academic_ranks_is_active_index` (`is_active`),
  ADD KEY `academic_ranks_sort_order_index` (`sort_order`);

--
-- Indexes for table `apply_training`
--
ALTER TABLE `apply_training`
  ADD PRIMARY KEY (`apply_id`),
  ADD KEY `apply_training_request_submission_id_foreign` (`request_submission_id`),
  ADD KEY `apply_training_training_id_foreign` (`training_id`),
  ADD KEY `apply_training_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `approval_comments`
--
ALTER TABLE `approval_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approval_comments_user_id_foreign` (`user_id`),
  ADD KEY `approval_comments_approval_action_id_foreign` (`approval_action_id`),
  ADD KEY `idx_comments_submission` (`submission_id`,`created_at`);

--
-- Indexes for table `approval_delegations`
--
ALTER TABLE `approval_delegations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approval_delegations_created_by_foreign` (`created_by`),
  ADD KEY `idx_delegations_active` (`delegator_id`,`is_active`,`starts_at`,`ends_at`),
  ADD KEY `idx_delegations_delegate` (`delegate_id`,`is_active`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_user_date` (`user_id`,`created_at`),
  ADD KEY `idx_audit_module_date` (`module`,`created_at`),
  ADD KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_audit_action` (`action`),
  ADD KEY `idx_audit_created_at` (`created_at`),
  ADD KEY `idx_audit_reference` (`reference_number`),
  ADD KEY `audit_logs_performed_by_index` (`performed_by`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate_text_layers`
--
ALTER TABLE `certificate_text_layers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `certificate_text_layers_certificate_template_id_foreign` (`certificate_template_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employees_gsis_id_no_index` (`gsis_id_no`),
  ADD KEY `employees_sss_no_index` (`sss_no`),
  ADD KEY `employees_tin_no_index` (`tin_no`),
  ADD KEY `employees_mobile_no_index` (`mobile_no`),
  ADD KEY `employees_email_address_index` (`email_address`),
  ADD KEY `employees_status_index` (`status`),
  ADD KEY `employees_employee_type_index` (`employee_type`),
  ADD KEY `employees_created_at_index` (`created_at`),
  ADD KEY `employees_status_type_index` (`status`,`employee_type`),
  ADD KEY `employees_primary_designation_id_index` (`primary_designation_id`);

--
-- Indexes for table `employee_audit_log`
--
ALTER TABLE `employee_audit_log`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `idx_employee_date` (`employee_id`,`action_date`),
  ADD KEY `idx_employee_audit_action_type` (`action_type`),
  ADD KEY `idx_employee_audit_reference_number` (`reference_number`);

--
-- Indexes for table `employee_childrens`
--
ALTER TABLE `employee_childrens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_childrens_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_civil_service_eligibilities`
--
ALTER TABLE `employee_civil_service_eligibilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_civil_service_eligibilities_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_designations`
--
ALTER TABLE `employee_designations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_designations_academic_rank_id_foreign` (`academic_rank_id`),
  ADD KEY `employee_designations_staff_grade_id_foreign` (`staff_grade_id`),
  ADD KEY `employee_designations_employee_id_index` (`employee_id`),
  ADD KEY `employee_designations_unit_id_index` (`unit_id`),
  ADD KEY `employee_designations_position_id_index` (`position_id`),
  ADD KEY `employee_designations_is_primary_index` (`is_primary`),
  ADD KEY `employee_designations_employee_id_is_primary_index` (`employee_id`,`is_primary`),
  ADD KEY `idx_employee_primary` (`employee_id`,`is_primary`,`deleted_at`),
  ADD KEY `idx_unit_position_primary` (`unit_id`,`position_id`,`is_primary`),
  ADD KEY `idx_employee_active` (`employee_id`,`end_date`);

--
-- Indexes for table `employee_designation_history`
--
ALTER TABLE `employee_designation_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_designation_history_designation_id_index` (`designation_id`),
  ADD KEY `employee_designation_history_changed_at_index` (`changed_at`),
  ADD KEY `employee_designation_history_designation_id_changed_at_index` (`designation_id`,`changed_at`),
  ADD KEY `employee_designation_history_changed_by_foreign` (`changed_by`);

--
-- Indexes for table `employee_documents`
--
ALTER TABLE `employee_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_documents_employee_id_index` (`employee_id`),
  ADD KEY `employee_documents_uploaded_by_index` (`uploaded_by`);

--
-- Indexes for table `employee_educational_backgrounds`
--
ALTER TABLE `employee_educational_backgrounds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_educational_backgrounds_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_family_backgrounds`
--
ALTER TABLE `employee_family_backgrounds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_family_backgrounds_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_grade_changes`
--
ALTER TABLE `employee_grade_changes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_grade_changes_employee_id_index` (`employee_id`),
  ADD KEY `employee_grade_changes_designation_id_index` (`designation_id`),
  ADD KEY `employee_grade_changes_effective_date_index` (`effective_date`),
  ADD KEY `employee_grade_changes_employee_id_effective_date_index` (`employee_id`,`effective_date`),
  ADD KEY `employee_grade_changes_change_type_index` (`change_type`),
  ADD KEY `employee_grade_changes_performed_by_employee_id_foreign` (`performed_by_employee_id`);

--
-- Indexes for table `employee_learning_developments`
--
ALTER TABLE `employee_learning_developments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_learning_developments_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_other_information`
--
ALTER TABLE `employee_other_information`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_other_information_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_promotions`
--
ALTER TABLE `employee_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_promotions_from_staff_grade_id_foreign` (`from_staff_grade_id`),
  ADD KEY `employee_promotions_to_staff_grade_id_foreign` (`to_staff_grade_id`),
  ADD KEY `employee_promotions_employee_id_index` (`employee_id`),
  ADD KEY `employee_promotions_effective_date_index` (`effective_date`),
  ADD KEY `employee_promotions_employee_id_effective_date_index` (`employee_id`,`effective_date`);

--
-- Indexes for table `employee_rank_promotions`
--
ALTER TABLE `employee_rank_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_rank_promotions_from_academic_rank_id_foreign` (`from_academic_rank_id`),
  ADD KEY `employee_rank_promotions_to_academic_rank_id_foreign` (`to_academic_rank_id`),
  ADD KEY `employee_rank_promotions_employee_id_index` (`employee_id`),
  ADD KEY `employee_rank_promotions_effective_date_index` (`effective_date`),
  ADD KEY `employee_rank_promotions_employee_id_effective_date_index` (`employee_id`,`effective_date`);

--
-- Indexes for table `employee_voluntary_works`
--
ALTER TABLE `employee_voluntary_works`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_voluntary_works_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `employee_work_experiences`
--
ALTER TABLE `employee_work_experiences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_work_experiences_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `holidays_date_type_unique` (`date`,`type`),
  ADD KEY `holidays_date_index` (`date`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_accruals`
--
ALTER TABLE `leave_accruals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_accruals_created_by_foreign` (`created_by`),
  ADD KEY `leave_accruals_employee_id_accrual_date_index` (`employee_id`,`accrual_date`),
  ADD KEY `leave_accruals_leave_type_id_index` (`leave_type_id`),
  ADD KEY `leave_accruals_accrual_type_index` (`accrual_type`);

--
-- Indexes for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_balances_employee_id_leave_type_id_year_unique` (`employee_id`,`leave_type_id`,`year`),
  ADD KEY `leave_balances_leave_type_id_foreign` (`leave_type_id`),
  ADD KEY `leave_balances_employee_id_year_index` (`employee_id`,`year`);

--
-- Indexes for table `leave_credits_history`
--
ALTER TABLE `leave_credits_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_credits_history_leave_type_id_foreign` (`leave_type_id`),
  ADD KEY `leave_credits_history_employee_id_leave_type_id_as_of_date_index` (`employee_id`,`leave_type_id`,`as_of_date`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_requests_request_submission_id_unique` (`request_submission_id`),
  ADD KEY `leave_requests_approved_by_foreign` (`approved_by`),
  ADD KEY `leave_requests_rejected_by_foreign` (`rejected_by`),
  ADD KEY `leave_requests_employee_id_status_index` (`employee_id`,`status`),
  ADD KEY `leave_requests_start_date_end_date_index` (`start_date`,`end_date`),
  ADD KEY `leave_requests_leave_type_id_index` (`leave_type_id`),
  ADD KEY `leave_requests_recommended_by_foreign` (`recommended_by`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_types_code_unique` (`code`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_owner_type_owner_id_index` (`owner_type`,`owner_id`);

--
-- Indexes for table `oauth_device_codes`
--
ALTER TABLE `oauth_device_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `oauth_device_codes_user_code_unique` (`user_code`),
  ADD KEY `oauth_device_codes_user_id_index` (`user_id`),
  ADD KEY `oauth_device_codes_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `organizational_audit_log`
--
ALTER TABLE `organizational_audit_log`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `idx_unit_date` (`unit_type`,`unit_id`,`action_date`),
  ADD KEY `idx_org_audit_action_type` (`action_type`),
  ADD KEY `idx_org_audit_reference_number` (`reference_number`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `positions_pos_code_unique` (`pos_code`),
  ADD KEY `positions_slug_index` (`slug`),
  ADD KEY `positions_sector_id_index` (`sector_id`),
  ADD KEY `positions_authority_level_index` (`authority_level`);

--
-- Indexes for table `questionnaires`
--
ALTER TABLE `questionnaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questionnaires_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `references`
--
ALTER TABLE `references`
  ADD PRIMARY KEY (`id`),
  ADD KEY `references_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `request_answers`
--
ALTER TABLE `request_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_answers_submission_id_foreign` (`submission_id`),
  ADD KEY `request_answers_field_id_foreign` (`field_id`);

--
-- Indexes for table `request_approval_actions`
--
ALTER TABLE `request_approval_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_approval_actions_submission_id_foreign` (`submission_id`),
  ADD KEY `request_approval_actions_approver_position_id_foreign` (`approver_position_id`),
  ADD KEY `request_approval_actions_status_index` (`status`),
  ADD KEY `request_approval_actions_approver_id_index` (`approver_id`),
  ADD KEY `request_approval_actions_approver_role_id_index` (`approver_role_id`),
  ADD KEY `request_approval_actions_status_step_index` (`status`,`step_index`),
  ADD KEY `request_approval_actions_escalated_from_user_id_foreign` (`escalated_from_user_id`),
  ADD KEY `request_approval_actions_delegated_from_user_id_foreign` (`delegated_from_user_id`),
  ADD KEY `idx_approval_actions_status_due` (`status`,`due_at`);

--
-- Indexes for table `request_fields`
--
ALTER TABLE `request_fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_fields_request_type_id_field_key_unique` (`request_type_id`,`field_key`);

--
-- Indexes for table `request_fulfillments`
--
ALTER TABLE `request_fulfillments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_fulfillments_submission_id_unique` (`submission_id`),
  ADD KEY `request_fulfillments_fulfilled_by_foreign` (`fulfilled_by`);

--
-- Indexes for table `request_submissions`
--
ALTER TABLE `request_submissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_submissions_reference_code_unique` (`reference_code`),
  ADD KEY `request_submissions_status_index` (`status`),
  ADD KEY `request_submissions_user_id_index` (`user_id`),
  ADD KEY `request_submissions_request_type_id_index` (`request_type_id`),
  ADD KEY `request_submissions_submitted_at_index` (`submitted_at`),
  ADD KEY `request_submissions_status_user_index` (`status`,`user_id`);

--
-- Indexes for table `request_types`
--
ALTER TABLE `request_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_types_created_by_foreign` (`created_by`),
  ADD KEY `request_types_certificate_template_id_foreign` (`certificate_template_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sectors`
--
ALTER TABLE `sectors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sectors_name_unique` (`name`),
  ADD UNIQUE KEY `sectors_code_unique` (`code`),
  ADD KEY `sectors_is_active_index` (`is_active`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `staff_grades`
--
ALTER TABLE `staff_grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_grades_code_unique` (`code`),
  ADD KEY `staff_grades_level_index` (`level`),
  ADD KEY `staff_grades_is_active_index` (`is_active`),
  ADD KEY `staff_grades_sort_order_index` (`sort_order`);

--
-- Indexes for table `trainings`
--
ALTER TABLE `trainings`
  ADD PRIMARY KEY (`training_id`),
  ADD UNIQUE KEY `trainings_reference_number_unique` (`reference_number`),
  ADD KEY `trainings_request_type_id_foreign` (`request_type_id`),
  ADD KEY `idx_training_reference_number` (`reference_number`);

--
-- Indexes for table `training_allowed_positions`
--
ALTER TABLE `training_allowed_positions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `training_allowed_positions_training_id_foreign` (`training_id`),
  ADD KEY `training_allowed_positions_position_id_foreign` (`position_id`);

--
-- Indexes for table `training_allowed_sectors`
--
ALTER TABLE `training_allowed_sectors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `training_allowed_sectors_training_id_sector_id_unique` (`training_id`,`sector_id`),
  ADD KEY `training_allowed_sectors_sector_id_foreign` (`sector_id`);

--
-- Indexes for table `training_allowed_units`
--
ALTER TABLE `training_allowed_units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `training_allowed_units_training_id_unit_id_unique` (`training_id`,`unit_id`),
  ADD KEY `training_allowed_units_unit_id_foreign` (`unit_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `units_code_unique` (`code`),
  ADD KEY `units_sector_id_foreign` (`sector_id`),
  ADD KEY `units_unit_type_sector_id_index` (`unit_type`,`sector_id`),
  ADD KEY `units_parent_unit_id_index` (`parent_unit_id`),
  ADD KEY `units_is_active_index` (`is_active`);

--
-- Indexes for table `unit_positions`
--
ALTER TABLE `unit_positions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unit_positions_unit_type_position_id_unique` (`unit_type`,`position_id`),
  ADD KEY `unit_positions_unit_type_index` (`unit_type`),
  ADD KEY `unit_positions_position_id_index` (`position_id`),
  ADD KEY `unit_positions_unit_type_position_id_index` (`unit_type`,`position_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_employee_id_unique` (`employee_id`),
  ADD KEY `users_employee_id_index` (`employee_id`);

--
-- Indexes for table `user_activities`
--
ALTER TABLE `user_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_activity_date` (`user_id`,`activity_type`,`created_at`),
  ADD KEY `idx_activity_type` (`activity_type`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `user_audit_log`
--
ALTER TABLE `user_audit_log`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `idx_user_date` (`user_id`,`action_date`),
  ADD KEY `idx_user_audit_action_type` (`action_type`),
  ADD KEY `idx_user_audit_reference_number` (`reference_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_ranks`
--
ALTER TABLE `academic_ranks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `apply_training`
--
ALTER TABLE `apply_training`
  MODIFY `apply_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `approval_comments`
--
ALTER TABLE `approval_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `approval_delegations`
--
ALTER TABLE `approval_delegations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `certificate_templates`
--
ALTER TABLE `certificate_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `certificate_text_layers`
--
ALTER TABLE `certificate_text_layers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_audit_log`
--
ALTER TABLE `employee_audit_log`
  MODIFY `record_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_childrens`
--
ALTER TABLE `employee_childrens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `employee_civil_service_eligibilities`
--
ALTER TABLE `employee_civil_service_eligibilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `employee_designations`
--
ALTER TABLE `employee_designations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employee_designation_history`
--
ALTER TABLE `employee_designation_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_documents`
--
ALTER TABLE `employee_documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_educational_backgrounds`
--
ALTER TABLE `employee_educational_backgrounds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `employee_family_backgrounds`
--
ALTER TABLE `employee_family_backgrounds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employee_grade_changes`
--
ALTER TABLE `employee_grade_changes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_learning_developments`
--
ALTER TABLE `employee_learning_developments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `employee_other_information`
--
ALTER TABLE `employee_other_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `employee_promotions`
--
ALTER TABLE `employee_promotions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_rank_promotions`
--
ALTER TABLE `employee_rank_promotions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_voluntary_works`
--
ALTER TABLE `employee_voluntary_works`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `employee_work_experiences`
--
ALTER TABLE `employee_work_experiences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_accruals`
--
ALTER TABLE `leave_accruals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `leave_balances`
--
ALTER TABLE `leave_balances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `leave_credits_history`
--
ALTER TABLE `leave_credits_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `organizational_audit_log`
--
ALTER TABLE `organizational_audit_log`
  MODIFY `record_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `questionnaires`
--
ALTER TABLE `questionnaires`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `references`
--
ALTER TABLE `references`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `request_answers`
--
ALTER TABLE `request_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request_approval_actions`
--
ALTER TABLE `request_approval_actions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request_fields`
--
ALTER TABLE `request_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `request_fulfillments`
--
ALTER TABLE `request_fulfillments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request_submissions`
--
ALTER TABLE `request_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request_types`
--
ALTER TABLE `request_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sectors`
--
ALTER TABLE `sectors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff_grades`
--
ALTER TABLE `staff_grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `trainings`
--
ALTER TABLE `trainings`
  MODIFY `training_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `training_allowed_positions`
--
ALTER TABLE `training_allowed_positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `training_allowed_sectors`
--
ALTER TABLE `training_allowed_sectors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `training_allowed_units`
--
ALTER TABLE `training_allowed_units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `unit_positions`
--
ALTER TABLE `unit_positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_activities`
--
ALTER TABLE `user_activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user_audit_log`
--
ALTER TABLE `user_audit_log`
  MODIFY `record_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `apply_training`
--
ALTER TABLE `apply_training`
  ADD CONSTRAINT `apply_training_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `apply_training_request_submission_id_foreign` FOREIGN KEY (`request_submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `apply_training_training_id_foreign` FOREIGN KEY (`training_id`) REFERENCES `trainings` (`training_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `approval_comments`
--
ALTER TABLE `approval_comments`
  ADD CONSTRAINT `approval_comments_approval_action_id_foreign` FOREIGN KEY (`approval_action_id`) REFERENCES `request_approval_actions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `approval_comments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `approval_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `approval_delegations`
--
ALTER TABLE `approval_delegations`
  ADD CONSTRAINT `approval_delegations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `approval_delegations_delegate_id_foreign` FOREIGN KEY (`delegate_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `approval_delegations_delegator_id_foreign` FOREIGN KEY (`delegator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `certificate_text_layers`
--
ALTER TABLE `certificate_text_layers`
  ADD CONSTRAINT `certificate_text_layers_certificate_template_id_foreign` FOREIGN KEY (`certificate_template_id`) REFERENCES `certificate_templates` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_primary_designation_id_foreign` FOREIGN KEY (`primary_designation_id`) REFERENCES `employee_designations` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_audit_log`
--
ALTER TABLE `employee_audit_log`
  ADD CONSTRAINT `employee_audit_log_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `employee_childrens`
--
ALTER TABLE `employee_childrens`
  ADD CONSTRAINT `employee_childrens_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_civil_service_eligibilities`
--
ALTER TABLE `employee_civil_service_eligibilities`
  ADD CONSTRAINT `employee_civil_service_eligibilities_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_designations`
--
ALTER TABLE `employee_designations`
  ADD CONSTRAINT `employee_designations_academic_rank_id_foreign` FOREIGN KEY (`academic_rank_id`) REFERENCES `academic_ranks` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `employee_designations_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_designations_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_designations_staff_grade_id_foreign` FOREIGN KEY (`staff_grade_id`) REFERENCES `staff_grades` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `employee_designations_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_designation_history`
--
ALTER TABLE `employee_designation_history`
  ADD CONSTRAINT `employee_designation_history_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `employee_designation_history_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `employee_designations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_educational_backgrounds`
--
ALTER TABLE `employee_educational_backgrounds`
  ADD CONSTRAINT `employee_educational_backgrounds_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_family_backgrounds`
--
ALTER TABLE `employee_family_backgrounds`
  ADD CONSTRAINT `employee_family_backgrounds_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_grade_changes`
--
ALTER TABLE `employee_grade_changes`
  ADD CONSTRAINT `employee_grade_changes_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `employee_designations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_grade_changes_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_grade_changes_performed_by_employee_id_foreign` FOREIGN KEY (`performed_by_employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employee_learning_developments`
--
ALTER TABLE `employee_learning_developments`
  ADD CONSTRAINT `employee_learning_developments_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_other_information`
--
ALTER TABLE `employee_other_information`
  ADD CONSTRAINT `employee_other_information_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_promotions`
--
ALTER TABLE `employee_promotions`
  ADD CONSTRAINT `employee_promotions_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_promotions_from_staff_grade_id_foreign` FOREIGN KEY (`from_staff_grade_id`) REFERENCES `staff_grades` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `employee_promotions_to_staff_grade_id_foreign` FOREIGN KEY (`to_staff_grade_id`) REFERENCES `staff_grades` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_rank_promotions`
--
ALTER TABLE `employee_rank_promotions`
  ADD CONSTRAINT `employee_rank_promotions_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_rank_promotions_from_academic_rank_id_foreign` FOREIGN KEY (`from_academic_rank_id`) REFERENCES `academic_ranks` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `employee_rank_promotions_to_academic_rank_id_foreign` FOREIGN KEY (`to_academic_rank_id`) REFERENCES `academic_ranks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_voluntary_works`
--
ALTER TABLE `employee_voluntary_works`
  ADD CONSTRAINT `employee_voluntary_works_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employee_work_experiences`
--
ALTER TABLE `employee_work_experiences`
  ADD CONSTRAINT `employee_work_experiences_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_accruals`
--
ALTER TABLE `leave_accruals`
  ADD CONSTRAINT `leave_accruals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `leave_accruals_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leave_accruals_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_balances`
--
ALTER TABLE `leave_balances`
  ADD CONSTRAINT `leave_balances_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leave_balances_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_credits_history`
--
ALTER TABLE `leave_credits_history`
  ADD CONSTRAINT `leave_credits_history_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leave_credits_history_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD CONSTRAINT `leave_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `leave_requests_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leave_requests_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leave_requests_recommended_by_foreign` FOREIGN KEY (`recommended_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `leave_requests_rejected_by_foreign` FOREIGN KEY (`rejected_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `leave_requests_request_submission_id_foreign` FOREIGN KEY (`request_submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `positions`
--
ALTER TABLE `positions`
  ADD CONSTRAINT `positions_sector_id_foreign` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `questionnaires`
--
ALTER TABLE `questionnaires`
  ADD CONSTRAINT `questionnaires_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `references`
--
ALTER TABLE `references`
  ADD CONSTRAINT `references_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_answers`
--
ALTER TABLE `request_answers`
  ADD CONSTRAINT `request_answers_field_id_foreign` FOREIGN KEY (`field_id`) REFERENCES `request_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `request_answers_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_approval_actions`
--
ALTER TABLE `request_approval_actions`
  ADD CONSTRAINT `request_approval_actions_approver_id_foreign` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_approval_actions_approver_position_id_foreign` FOREIGN KEY (`approver_position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_approval_actions_approver_role_id_foreign` FOREIGN KEY (`approver_role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_approval_actions_delegated_from_user_id_foreign` FOREIGN KEY (`delegated_from_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_approval_actions_escalated_from_user_id_foreign` FOREIGN KEY (`escalated_from_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_approval_actions_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_fields`
--
ALTER TABLE `request_fields`
  ADD CONSTRAINT `request_fields_request_type_id_foreign` FOREIGN KEY (`request_type_id`) REFERENCES `request_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_fulfillments`
--
ALTER TABLE `request_fulfillments`
  ADD CONSTRAINT `request_fulfillments_fulfilled_by_foreign` FOREIGN KEY (`fulfilled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_fulfillments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `request_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_submissions`
--
ALTER TABLE `request_submissions`
  ADD CONSTRAINT `request_submissions_request_type_id_foreign` FOREIGN KEY (`request_type_id`) REFERENCES `request_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `request_submissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `request_types`
--
ALTER TABLE `request_types`
  ADD CONSTRAINT `request_types_certificate_template_id_foreign` FOREIGN KEY (`certificate_template_id`) REFERENCES `certificate_templates` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `request_types_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `trainings`
--
ALTER TABLE `trainings`
  ADD CONSTRAINT `trainings_request_type_id_foreign` FOREIGN KEY (`request_type_id`) REFERENCES `request_types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `training_allowed_positions`
--
ALTER TABLE `training_allowed_positions`
  ADD CONSTRAINT `training_allowed_positions_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `training_allowed_positions_training_id_foreign` FOREIGN KEY (`training_id`) REFERENCES `trainings` (`training_id`) ON DELETE CASCADE;

--
-- Constraints for table `training_allowed_sectors`
--
ALTER TABLE `training_allowed_sectors`
  ADD CONSTRAINT `training_allowed_sectors_sector_id_foreign` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `training_allowed_sectors_training_id_foreign` FOREIGN KEY (`training_id`) REFERENCES `trainings` (`training_id`) ON DELETE CASCADE;

--
-- Constraints for table `training_allowed_units`
--
ALTER TABLE `training_allowed_units`
  ADD CONSTRAINT `training_allowed_units_training_id_foreign` FOREIGN KEY (`training_id`) REFERENCES `trainings` (`training_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `training_allowed_units_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `units`
--
ALTER TABLE `units`
  ADD CONSTRAINT `units_parent_unit_id_foreign` FOREIGN KEY (`parent_unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `units_sector_id_foreign` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `unit_positions`
--
ALTER TABLE `unit_positions`
  ADD CONSTRAINT `unit_positions_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_activities`
--
ALTER TABLE `user_activities`
  ADD CONSTRAINT `user_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_audit_log`
--
ALTER TABLE `user_audit_log`
  ADD CONSTRAINT `user_audit_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
