<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db.php';

// Access control - allow admin, coordinator, and researcher (for their own profile)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

if ($userRole === 'coordinator' && $coordinatorType !== 'faculty') {
    header("Location: research.php");
    exit;
}

// NEW: Get faculty_id and check access
if (!isset($_GET['id'])) {
    if ($userRole === 'researcher') {
        // If researcher, try to find their own faculty_id
        $findStmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
        $findStmt->bind_param("i", $userId);
        $findStmt->execute();
        $findResult = $findStmt->get_result();
        if ($findResult && $findResult->num_rows > 0) {
            $findData = $findResult->fetch_assoc();
            header("Location: facultyresearcherprofile.php?id=" . $findData['id']);
            exit;
        }
        $findStmt->close();
    }
    header("Location: facultyresearcher.php");
    exit;
}

$faculty_id = (int) $_GET['id'];

// NEW: Check access based on role
if ($userRole === 'researcher') {
    // Researchers can only view their own profile
    $checkOwnProfile = $conn->prepare("SELECT user_id FROM faculty_researchers WHERE id = ? LIMIT 1");
    $checkOwnProfile->bind_param("i", $faculty_id);
    $checkOwnProfile->execute();
    $ownProfileResult = $checkOwnProfile->get_result();
    $ownProfileData = $ownProfileResult->fetch_assoc();
    
    if (!$ownProfileData || $ownProfileData['user_id'] != $userId) {
        die("<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Access Denied</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
                .access-denied { 
                    max-width: 500px; 
                    margin: 100px auto; 
                    background: white; 
                    padding: 40px; 
                    border-radius: 8px; 
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .access-denied h2 { color: #dc3545; margin-bottom: 20px; }
                .access-denied i { font-size: 48px; margin-bottom: 20px; color: #dc3545; }
                .access-denied p { color: #666; margin-bottom: 30px; }
                .btn-back { 
                    display: inline-block; 
                    padding: 12px 24px; 
                    background: #007bff; 
                    color: white; 
                    text-decoration: none; 
                    border-radius: 4px;
                    transition: background 0.3s;
                }
                .btn-back:hover { background: #0056b3; }
            </style>
        </head>
        <body>
            <div class='access-denied'>
                <i class='fa fa-ban'></i>
                <h2>Access Denied</h2>
                <p>You can only view your own profile.</p>
                <a href='research.php' class='btn-back'>
                    <i class='fa fa-arrow-left'></i> Back to Dashboard
                </a>
            </div>
        </body>
        </html>");
    }
    $checkOwnProfile->close();
} elseif ($userRole === 'coordinator') {
    // Coordinators can only view faculty researchers they created
    $checkAccess = $conn->prepare("SELECT created_by FROM faculty_researchers WHERE id = ?");
    $checkAccess->bind_param("i", $faculty_id);
    $checkAccess->execute();
    $result = $checkAccess->get_result();
    $accessCheck = $result->fetch_assoc();
    
    if (!$accessCheck || $accessCheck['created_by'] != $userId) {
        die("<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Access Denied</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
                .access-denied { 
                    max-width: 500px; 
                    margin: 100px auto; 
                    background: white; 
                    padding: 40px; 
                    border-radius: 8px; 
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .access-denied h2 { color: #dc3545; margin-bottom: 20px; }
                .access-denied i { font-size: 48px; margin-bottom: 20px; color: #dc3545; }
                .access-denied p { color: #666; margin-bottom: 30px; }
                .btn-back { 
                    display: inline-block; 
                    padding: 12px 24px; 
                    background: #007bff; 
                    color: white; 
                    text-decoration: none; 
                    border-radius: 4px;
                    transition: background 0.3s;
                }
                .btn-back:hover { background: #0056b3; }
            </style>
        </head>
        <body>
            <div class='access-denied'>
                <i class='fa fa-ban'></i>
                <h2>Access Denied</h2>
                <p>You can only view faculty researchers that you created.</p>
                <a href='facultyresearcher.php' class='btn-back'>
                    <i class='fa fa-arrow-left'></i> Back to Faculty List
                </a>
            </div>
        </body>
        </html>");
    }
    $checkAccess->close();
}

// Create tables if they don't exist
try {
    $conn->query("ALTER TABLE faculty_projects ADD COLUMN IF NOT EXISTS parent_project_id INT DEFAULT NULL");
    $conn->query("ALTER TABLE faculty_projects ADD COLUMN IF NOT EXISTS is_project_leader TINYINT(1) DEFAULT 1");
    $conn->query("CREATE INDEX IF NOT EXISTS idx_parent_project ON faculty_projects(parent_project_id)");
    
    $conn->query("CREATE TABLE IF NOT EXISTS faculty_project_team (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        faculty_rank VARCHAR(100),
        employment_status VARCHAR(50),
        highest_attainment VARCHAR(255),
        nature_of_involvement VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES faculty_projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS faculty_project_costs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        item_of_expenditure VARCHAR(255) NOT NULL,
        institution_fund DECIMAL(15,2) DEFAULT 0,
        government_fund DECIMAL(15,2) DEFAULT 0,
        government_fund_source VARCHAR(255),
        private_fund DECIMAL(15,2) DEFAULT 0,
        private_fund_source VARCHAR(255),
        foreign_fund DECIMAL(15,2) DEFAULT 0,
        foreign_fund_source VARCHAR(255),
        other_sources DECIMAL(15,2) DEFAULT 0,
        other_sources_name VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES faculty_projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {
    // Tables already exist
}

// Handle AJAX operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    ob_clean();
    header('Content-Type: application/json');
    
    // Check access for all POST operations
    if ($userRole === 'coordinator') {
        $checkAccess = $conn->prepare("SELECT created_by FROM faculty_researchers WHERE id = ?");
        $checkAccess->bind_param("i", $faculty_id);
        $checkAccess->execute();
        $result = $checkAccess->get_result();
        $accessCheck = $result->fetch_assoc();
        
        if (!$accessCheck || $accessCheck['created_by'] != $userId) {
            echo json_encode(["success" => false, "error" => "Access denied"]);
            exit;
        }
    }
    
    try {
        if ($_POST['action'] === 'add_project') {
            if (empty($_POST['title'])) {
                echo json_encode(["success" => false, "error" => "Project title is required"]);
                exit;
            }
            
            $conn->begin_transaction();
            
            try {
                $stmt = $conn->prepare("INSERT INTO faculty_projects 
                    (faculty_id, title, project_status, classification, funding_source, nature_of_involvement, start_date, end_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                
                if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);
                
                $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
                $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
                
                $stmt->bind_param("isssssss",
                    $faculty_id, $_POST['title'], $_POST['project_status'], $_POST['classification'],
                    $_POST['funding_source'], $_POST['nature_of_involvement'], $start_date, $end_date
                );
                
                if (!$stmt->execute()) throw new Exception("Execute failed: " . $stmt->error);
                
                $project_id = $conn->insert_id;
                
                // Insert costs if provided
                $savedCount = 0;
                if (!empty($_POST['expenditure']) && is_array($_POST['expenditure'])) {
                    $costStmt = $conn->prepare("INSERT INTO faculty_project_costs 
                        (project_id, item_of_expenditure, institution_fund, government_fund, government_fund_source, 
                         private_fund, private_fund_source, foreign_fund, foreign_fund_source, other_sources, other_sources_name)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    foreach ($_POST['expenditure'] as $i => $exp) {
                        $exp = trim($exp);
                        if ($exp === '') continue;
                        
                        $inst = isset($_POST['institution_fund'][$i]) && $_POST['institution_fund'][$i] !== '' ? (float)$_POST['institution_fund'][$i] : 0;
                        $govt = isset($_POST['government_fund'][$i]) && $_POST['government_fund'][$i] !== '' ? (float)$_POST['government_fund'][$i] : 0;
                        $priv = isset($_POST['private_fund'][$i]) && $_POST['private_fund'][$i] !== '' ? (float)$_POST['private_fund'][$i] : 0;
                        $foreign = isset($_POST['foreign_fund'][$i]) && $_POST['foreign_fund'][$i] !== '' ? (float)$_POST['foreign_fund'][$i] : 0;
                        $other = isset($_POST['other_sources'][$i]) && $_POST['other_sources'][$i] !== '' ? (float)$_POST['other_sources'][$i] : 0;
                        
                        $govt_source = $_POST['government_fund_source'][$i] ?? '';
                        $priv_source = $_POST['private_fund_source'][$i] ?? '';
                        $foreign_source = $_POST['foreign_fund_source'][$i] ?? '';
                        $other_source = $_POST['other_sources_name'][$i] ?? '';
                        
                        if ($inst > 0 || $govt > 0 || $priv > 0 || $foreign > 0 || $other > 0) {
                            $costStmt->bind_param("isddsdsdsds", $project_id, $exp, $inst, $govt, $govt_source,
                                $priv, $priv_source, $foreign, $foreign_source, $other, $other_source);
                            $costStmt->execute();
                            $savedCount++;
                        }
                    }
                }
                
                $conn->commit();
                echo json_encode(["success" => true, "project_id" => $project_id, "costs_saved" => $savedCount]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                throw $e;
            }
        }

        if ($_POST['action'] === 'edit_project') {
            $stmt = $conn->prepare("UPDATE faculty_projects 
                SET title=?, project_status=?, classification=?, funding_source=?, nature_of_involvement=?, start_date=?, end_date=? 
                WHERE id=? AND faculty_id=?");
            $stmt->bind_param("sssssssii", $_POST['title'], $_POST['project_status'], $_POST['classification'],
                $_POST['funding_source'], $_POST['nature_of_involvement'], $_POST['start_date'], $_POST['end_date'],
                $_POST['id'], $faculty_id);
            $stmt->execute();
            echo json_encode(["success" => true]);
            exit;
        }

        if ($_POST['action'] === 'delete_project') {
            $stmt = $conn->prepare("DELETE FROM faculty_projects WHERE id=? AND faculty_id=?");
            $stmt->bind_param("ii", $_POST['id'], $faculty_id);
            $stmt->execute();
            echo json_encode(["success" => true]);
            exit;
        }

        if ($_POST['action'] === 'add_team') {
            $selectedFacultyId = isset($_POST['faculty_id']) ? (int)$_POST['faculty_id'] : 0;
            if (empty($selectedFacultyId)) {
                echo json_encode(["success" => false, "error" => "Please select a faculty member"]);
                exit;
            }
            
            // Get project's faculty_id first
            $projectStmt = $conn->prepare("SELECT faculty_id FROM faculty_projects WHERE id = ?");
            $projectStmt->bind_param("i", $_POST['project_id']);
            $projectStmt->execute();
            $projectResult = $projectStmt->get_result()->fetch_assoc();
            $projectFacultyId = $projectResult['faculty_id'] ?? null;
            $projectStmt->close();
            
            if (!$projectFacultyId) {
                echo json_encode(["success" => false, "error" => "Project not found"]);
                exit;
            }
            
            // Get current faculty researcher's parent unit
            $currentFacultyStmt = $conn->prepare("SELECT user_id, hr_data_json FROM faculty_researchers WHERE id = ?");
            $currentFacultyStmt->bind_param("i", $projectFacultyId);
            $currentFacultyStmt->execute();
            $currentFacultyResult = $currentFacultyStmt->get_result()->fetch_assoc();
            $currentFacultyStmt->close();
            
            if (!$currentFacultyResult) {
                echo json_encode(["success" => false, "error" => "Current faculty researcher not found"]);
                exit;
            }
            
            $currentParentUnit = null;
            
            // Get parent unit from users table
            if (!empty($currentFacultyResult['user_id'])) {
                $checkParentUnitColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'parent_unit'");
                $hasParentUnitColumn = $checkParentUnitColumn->num_rows > 0;
                
                if ($hasParentUnitColumn) {
                    $parentUnitStmt = $conn->prepare("SELECT parent_unit FROM users WHERE id = ? LIMIT 1");
                    $parentUnitStmt->bind_param("i", $currentFacultyResult['user_id']);
                    $parentUnitStmt->execute();
                    $parentUnitResult = $parentUnitStmt->get_result();
                    if ($parentUnitRow = $parentUnitResult->fetch_assoc()) {
                        $currentParentUnit = $parentUnitRow['parent_unit'];
                    }
                    $parentUnitStmt->close();
                }
            }
            
            // Fallback: get from hr_data_json
            if (empty($currentParentUnit) && !empty($currentFacultyResult['hr_data_json'])) {
                $hrData = json_decode($currentFacultyResult['hr_data_json'], true);
                if (isset($hrData['unit']['parent_unit']['name'])) {
                    $currentParentUnit = $hrData['unit']['parent_unit']['name'];
                }
            }
            
            if (empty($currentParentUnit)) {
                echo json_encode(["success" => false, "error" => "Cannot determine parent unit"]);
                exit;
            }
            
            // Get the selected faculty member and verify they are from the same parent unit
            $facultyStmt = $conn->prepare("
                SELECT fr.*, u.parent_unit, u.imported
                FROM faculty_researchers fr
                LEFT JOIN users u ON fr.user_id = u.id
                WHERE fr.id = ?
            ");
            $facultyStmt->bind_param("i", $selectedFacultyId);
            $facultyStmt->execute();
            $facultyMember = $facultyStmt->get_result()->fetch_assoc();
            $facultyStmt->close();
            
            if (!$facultyMember) {
                echo json_encode(["success" => false, "error" => "Faculty member not found"]);
                exit;
            }
            
            // Verify parent unit match
            $selectedParentUnit = null;
            if (!empty($facultyMember['parent_unit'])) {
                $selectedParentUnit = $facultyMember['parent_unit'];
            } elseif (!empty($facultyMember['hr_data_json'])) {
                $selectedHrData = json_decode($facultyMember['hr_data_json'], true);
                if (isset($selectedHrData['unit']['parent_unit']['name'])) {
                    $selectedParentUnit = $selectedHrData['unit']['parent_unit']['name'];
                }
            }
            
            if (empty($selectedParentUnit) || $selectedParentUnit !== $currentParentUnit) {
                echo json_encode(["success" => false, "error" => "Faculty member is not from the same parent unit"]);
                exit;
            }
            
            // Verify they are imported
            if (empty($facultyMember['imported']) && $facultyMember['imported'] != 1 && empty($facultyMember['hr_employee_id'])) {
                echo json_encode(["success" => false, "error" => "Only imported researchers can be added as team members"]);
                exit;
            }
            
            $checkStmt = $conn->prepare("SELECT id FROM faculty_project_team WHERE project_id = ? AND name = ?");
            $fullName = $facultyMember['last_name'] . ', ' . $facultyMember['first_name'] . ' ' . $facultyMember['middle_name'];
            $checkStmt->bind_param("is", $_POST['project_id'], $fullName);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows > 0) {
                echo json_encode(["success" => false, "error" => "This faculty member is already in the team"]);
                exit;
            }
            
            $eduStmt = $conn->prepare("SELECT degree_program FROM faculty_education WHERE faculty_id = ? ORDER BY id DESC LIMIT 1");
            $eduStmt->bind_param("i", $facultyMember['id']);
            $eduStmt->execute();
            $eduResult = $eduStmt->get_result()->fetch_assoc();
            $highestAttainment = $eduResult ? $eduResult['degree_program'] : 'Not specified';
            
            $projectStmt = $conn->prepare("SELECT * FROM faculty_projects WHERE id = ?");
            $projectStmt->bind_param("i", $_POST['project_id']);
            $projectStmt->execute();
            $originalProject = $projectStmt->get_result()->fetch_assoc();
            
            if (!$originalProject) {
                echo json_encode(["success" => false, "error" => "Project not found"]);
                exit;
            }
            
            $conn->begin_transaction();
            
            try {
                $teamStmt = $conn->prepare("INSERT INTO faculty_project_team 
                    (project_id, name, faculty_rank, employment_status, highest_attainment, nature_of_involvement)
                    VALUES (?, ?, ?, ?, ?, ?)");
                $teamStmt->bind_param("isssss", $_POST['project_id'], $fullName, $facultyMember['faculty_rank'],
                    $facultyMember['employment_status'], $highestAttainment, $_POST['nature_of_involvement']);
                $teamStmt->execute();
                
                $linkedProjectStmt = $conn->prepare("INSERT INTO faculty_projects 
                    (faculty_id, parent_project_id, is_project_leader, title, project_status, classification, 
                     funding_source, nature_of_involvement, start_date, end_date, created_at)
                    VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?, ?, NOW())");
                
                $linkedProjectStmt->bind_param("iisssssss", $facultyMember['id'], $_POST['project_id'],
                    $originalProject['title'], $originalProject['project_status'], $originalProject['classification'],
                    $originalProject['funding_source'], $_POST['nature_of_involvement'], 
                    $originalProject['start_date'], $originalProject['end_date']);
                
                if (!$linkedProjectStmt->execute()) throw new Exception("Failed to create linked project");
                
                $linkedProjectId = $conn->insert_id;
                
                $costCopyStmt = $conn->prepare("INSERT INTO faculty_project_costs 
                    (project_id, item_of_expenditure, institution_fund, government_fund, government_fund_source,
                     private_fund, private_fund_source, foreign_fund, foreign_fund_source, other_sources, other_sources_name)
                    SELECT ?, item_of_expenditure, institution_fund, government_fund, government_fund_source,
                           private_fund, private_fund_source, foreign_fund, foreign_fund_source, other_sources, other_sources_name
                    FROM faculty_project_costs WHERE project_id = ?");
                $costCopyStmt->bind_param("ii", $linkedProjectId, $_POST['project_id']);
                $costCopyStmt->execute();
                
                $conn->commit();
                echo json_encode(["success" => true, "message" => "Team member added successfully"]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(["success" => false, "error" => $e->getMessage()]);
                exit;
            }
        }

        if ($_POST['action'] === 'delete_team') {
            $teamId = (int)$_POST['id'];
            $projectId = (int)$_POST['project_id'];
            
            $conn->begin_transaction();
            
            try {
                $teamInfo = $conn->query("SELECT name FROM faculty_project_team WHERE id = $teamId")->fetch_assoc();
                
                $stmt = $conn->prepare("DELETE FROM faculty_project_team WHERE id=?");
                $stmt->bind_param("i", $teamId);
                $stmt->execute();
                
                if ($teamInfo) {
                    $nameParts = explode(', ', $teamInfo['name']);
                    if (count($nameParts) >= 2) {
                        $lastName = $conn->real_escape_string($nameParts[0]);
                        $firstName = $conn->real_escape_string(explode(' ', $nameParts[1])[0]);
                        
                        $facultyResult = $conn->query("SELECT id FROM faculty_researchers 
                            WHERE last_name = '$lastName' AND first_name = '$firstName' LIMIT 1");
                        
                        if ($faculty = $facultyResult->fetch_assoc()) {
                            $conn->query("DELETE FROM faculty_projects 
                                WHERE faculty_id = {$faculty['id']} AND parent_project_id = $projectId");
                        }
                    }
                }
                
                $conn->commit();
                echo json_encode(["success" => true]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(["success" => false, "error" => $e->getMessage()]);
                exit;
            }
        }

        if ($_POST['action'] === 'save_costs') {
            $project_id = (int)$_POST['project_id'];
            $conn->query("DELETE FROM faculty_project_costs WHERE project_id = $project_id");
            
            $savedCount = 0;
            if (!empty($_POST['expenditure'])) {
                $stmt = $conn->prepare("INSERT INTO faculty_project_costs 
                    (project_id, item_of_expenditure, institution_fund, government_fund, government_fund_source, 
                     private_fund, private_fund_source, foreign_fund, foreign_fund_source, other_sources, other_sources_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
                foreach ($_POST['expenditure'] as $i => $exp) {
                    $exp = trim($exp);
                    if ($exp === '') continue;
                    
                    $inst = isset($_POST['institution_fund'][$i]) && $_POST['institution_fund'][$i] !== '' ? (float)$_POST['institution_fund'][$i] : 0;
                    $govt = isset($_POST['government_fund'][$i]) && $_POST['government_fund'][$i] !== '' ? (float)$_POST['government_fund'][$i] : 0;
                    $priv = isset($_POST['private_fund'][$i]) && $_POST['private_fund'][$i] !== '' ? (float)$_POST['private_fund'][$i] : 0;
                    $foreign = isset($_POST['foreign_fund'][$i]) && $_POST['foreign_fund'][$i] !== '' ? (float)$_POST['foreign_fund'][$i] : 0;
                    $other = isset($_POST['other_sources'][$i]) && $_POST['other_sources'][$i] !== '' ? (float)$_POST['other_sources'][$i] : 0;
                    
                    $govt_source = $_POST['government_fund_source'][$i] ?? '';
                    $priv_source = $_POST['private_fund_source'][$i] ?? '';
                    $foreign_source = $_POST['foreign_fund_source'][$i] ?? '';
                    $other_source = $_POST['other_sources_name'][$i] ?? '';
                    
                    if ($inst > 0 || $govt > 0 || $priv > 0 || $foreign > 0 || $other > 0) {
                        $stmt->bind_param("isddsdsdsds", $project_id, $exp, $inst, $govt, $govt_source,
                            $priv, $priv_source, $foreign, $foreign_source, $other, $other_source);
                        $stmt->execute();
                        $savedCount++;
                    }
                }
            }
            
            if ($savedCount === 0) {
                echo json_encode(["success" => false, "error" => "No valid cost entries"]);
                exit;
            }
            
            echo json_encode(["success" => true, "saved_count" => $savedCount]);
            exit;
        }
        
    } catch (Exception $e) {
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
        exit;
    }
    
    echo json_encode(["success" => false, "error" => "Unknown action"]);
    exit;
}

// Fetch faculty data
$stmt = $conn->prepare("SELECT *, sync_status FROM faculty_researchers WHERE id = ?");
$stmt->bind_param("i", $faculty_id);
$stmt->execute();
$faculty = $stmt->get_result()->fetch_assoc();

if (!$faculty) die("Faculty not found.");

// Get all imported researchers from the same parent unit (for team member dropdown)
$teamMemberOptions = [];
$currentParentUnit = null;

// Get current faculty researcher's parent unit from users table
if (!empty($faculty['user_id'])) {
    $checkParentUnitColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'parent_unit'");
    $hasParentUnitColumn = $checkParentUnitColumn->num_rows > 0;
    
    if ($hasParentUnitColumn) {
        $parentUnitStmt = $conn->prepare("SELECT parent_unit FROM users WHERE id = ? LIMIT 1");
        $parentUnitStmt->bind_param("i", $faculty['user_id']);
        $parentUnitStmt->execute();
        $parentUnitResult = $parentUnitStmt->get_result();
        if ($parentUnitRow = $parentUnitResult->fetch_assoc()) {
            $currentParentUnit = $parentUnitRow['parent_unit'];
        }
        $parentUnitStmt->close();
    }
}

// Fallback: try to get from hr_data_json if parent_unit not in users table
if (empty($currentParentUnit) && !empty($faculty['hr_data_json'])) {
    $hrData = json_decode($faculty['hr_data_json'], true);
    if (isset($hrData['unit']['parent_unit']['name'])) {
        $currentParentUnit = $hrData['unit']['parent_unit']['name'];
    } elseif (isset($hrData['unit']['parent_unit_id'])) {
        // If we only have parent_unit_id, we'd need to fetch from API, but for now use unit name as fallback
        $currentParentUnit = $hrData['unit']['name'] ?? null;
    }
}

// If we have a parent unit, get all researchers from the same parent unit
if (!empty($currentParentUnit)) {
    // First, get all imported researchers
    $teamStmt = $conn->prepare("
        SELECT fr.id, fr.faculty_number, fr.first_name, fr.middle_name, fr.last_name, fr.email,
               u.imported, u.parent_unit, fr.hr_data_json
        FROM faculty_researchers fr
        LEFT JOIN users u ON fr.user_id = u.id
        WHERE (u.imported = 1 OR fr.hr_employee_id IS NOT NULL)
        AND fr.id != ?
    ");
    $teamStmt->bind_param("i", $faculty_id);
    $teamStmt->execute();
    $teamResult = $teamStmt->get_result();
    
    // Filter by parent unit match
    while ($teamMember = $teamResult->fetch_assoc()) {
        $memberParentUnit = null;
        
        // Check users.parent_unit first
        if (!empty($teamMember['parent_unit'])) {
            $memberParentUnit = $teamMember['parent_unit'];
        } 
        // Fallback: check hr_data_json
        elseif (!empty($teamMember['hr_data_json'])) {
            $hrData = json_decode($teamMember['hr_data_json'], true);
            if (isset($hrData['unit']['parent_unit']['name'])) {
                $memberParentUnit = $hrData['unit']['parent_unit']['name'];
            }
        }
        
        // Only include if parent unit matches
        if (!empty($memberParentUnit) && $memberParentUnit === $currentParentUnit) {
            $fullName = trim($teamMember['last_name'] . ', ' . $teamMember['first_name'] . ' ' . ($teamMember['middle_name'] ?? ''));
            $teamMemberOptions[] = [
                'id' => $teamMember['id'],
                'name' => $fullName,
                'faculty_number' => $teamMember['faculty_number'],
                'email' => $teamMember['email']
            ];
        }
    }
    $teamStmt->close();
}

$education = $conn->query("SELECT * FROM faculty_education WHERE faculty_id = $faculty_id ORDER BY id")->fetch_all(MYSQLI_ASSOC);

$ownedProjects = $conn->query("SELECT *, 1 as is_owner FROM faculty_projects 
    WHERE faculty_id = $faculty_id AND (parent_project_id IS NULL OR parent_project_id = 0)
    ORDER BY start_date DESC, id DESC")->fetch_all(MYSQLI_ASSOC);

$collaborativeProjects = $conn->query("SELECT *, 0 as is_owner FROM faculty_projects 
    WHERE faculty_id = $faculty_id AND parent_project_id IS NOT NULL AND parent_project_id > 0
    ORDER BY start_date DESC, id DESC")->fetch_all(MYSQLI_ASSOC);

$projects = array_merge($ownedProjects, $collaborativeProjects);

$stats = ['total' => count($ownedProjects), 'ongoing' => 0, 'completed' => 0, 'published' => 0, 'collaborative' => count($collaborativeProjects)];
foreach ($ownedProjects as $p) {
    if ($p['project_status'] == 'on-going') $stats['ongoing']++;
    if ($p['project_status'] == 'completed') $stats['completed']++;
    if ($p['project_status'] == 'published') $stats['published']++;
}

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faculty Research Profile</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="facultyresearcherprofilestyle.css">
<style>
.add-project-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background: #9ca3af !important;
}
.add-project-btn:disabled:hover {
    background: #9ca3af !important;
    transform: none;
}
</style>
</head>
<body>

<div class="page-header">
    <?php if ($userRole !== 'researcher'): ?>
    <a href="facultyresearcher.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Faculty List
    </a>
    <?php else: ?>
    <a href="index.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Homepage
    </a>
    <?php endif; ?>
</div>

<div class="container">
    <div class="profile-card">
        <div class="profile-header">
            <div class="profile-avatar"><i class="fa fa-user-graduate"></i></div>
            <h2><?= s($faculty['last_name'] . ', ' . $faculty['first_name']) ?></h2>
            <div class="profile-subtitle"><?= s($faculty['faculty_rank']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-id-card"></i> Faculty Number</div>
            <div class="info-value"><?= s($faculty['faculty_number']) ?></div>
        </div>
        <div class="info-group">
            <div class="info-label"><i class="fa fa-briefcase"></i> Employment Status</div>
            <div class="info-value"><?= s($faculty['employment_status']) ?></div>
        </div>
        <div class="info-group">
            <div class="info-label"><i class="fa fa-building"></i> Unit</div>
            <div class="info-value"><?= s($faculty['home_unit']) ?: 'N/A' ?></div>
        </div>
        <div class="info-group">
            <div class="info-label"><i class="fa fa-envelope"></i> Email</div>
            <div class="info-value"><?= s($faculty['email']) ?></div>
        </div>
        <div class="info-group">
            <div class="info-label"><i class="fa fa-phone"></i> Telephone</div>
            <div class="info-value"><?= s($faculty['telephone']) ?: 'N/A' ?></div>
        </div>
        
        <?php if (!empty($education)): ?>
        <div class="education-section">
            <h3><i class="fa fa-graduation-cap"></i> Education</h3>
            <?php foreach ($education as $edu): ?>
            <div class="education-item">
                <div class="degree"><?= s($edu['degree_program']) ?></div>
                <div class="university"><?= s($edu['college_university']) ?></div>
                <div class="details">
                    <?= $edu['has_thesis'] == 'Yes' ? '📄 With Thesis' : '📋 No Thesis' ?> • 
                    Graduated: <?= s($edu['year_graduated']) ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="research-section">
        <div class="research-header">
            <h2><i class="fa fa-flask"></i> Research Outputs</h2>
            <?php 
            $syncStatusDisabled = !empty($faculty['sync_status']) && $faculty['sync_status'] === 'n/a';
            ?>
            <button class="add-project-btn" onclick="openAddProjectModal()" <?= $syncStatusDisabled ? 'disabled title="Cannot add research project: Employee is no longer in HR system or not in same unit"' : '' ?>>
                <i class="fa fa-plus-circle"></i> Add Research Project
            </button>
        </div>

        <div class="stats-row">
            <div class="stat-card">
                <div class="number"><?= $stats['total'] ?></div>
                <div class="label">Led Outputs</div>
            </div>
            <div class="stat-card collaborative">
                <div class="number"><?= $stats['collaborative'] ?></div>
                <div class="label">Collaborative</div>
            </div>
            <div class="stat-card warning">
                <div class="number"><?= $stats['ongoing'] ?></div>
                <div class="label">On-going</div>
            </div>
            <div class="stat-card success">
                <div class="number"><?= $stats['completed'] ?></div>
                <div class="label">Completed</div>
            </div>
        </div>

        <?php if (empty($projects)): ?>
            <div class="no-data">
                <i class="fa fa-folder-open"></i>
                <p>No research outputs yet. Click "Add Research Project" to get started.</p>
            </div>
        <?php else: foreach ($projects as $p): 
            $statusClass = 'status-' . str_replace('-', '', $p['project_status']);
            $duration = '';
            if ($p['start_date']) {
                $duration = date('M Y', strtotime($p['start_date']));
                if ($p['end_date']) $duration .= ' - ' . date('M Y', strtotime($p['end_date']));
            }
            
            $isOwner = empty($p['parent_project_id']) || $p['parent_project_id'] == 0;
            $projectType = $isOwner ? 'Led Project' : 'Collaborative Project';
            $projectIcon = $isOwner ? 'crown' : 'users';
            
            $team = [];
            $costs = [];
            if ($isOwner) {
                $team = $conn->query("SELECT * FROM faculty_project_team WHERE project_id = {$p['id']}")->fetch_all(MYSQLI_ASSOC);
                $costs = $conn->query("SELECT * FROM faculty_project_costs WHERE project_id = {$p['id']}")->fetch_all(MYSQLI_ASSOC);
            }
        ?>
            <div class="project-card">
                <div class="project-type-badge <?= $isOwner ? 'owner' : 'collaborator' ?>">
                    <i class="fa fa-<?= $projectIcon ?>"></i>
                    <?= $projectType ?>
                </div>
                
                <div class="project-card-header">
                    <div class="project-title"><?= s($p['title']) ?></div>
                    <div class="project-actions">
                        <?php if ($isOwner): ?>
                            <?php if ($userRole !== 'researcher'): ?>
                            <button class="btn btn-success btn-sm" onclick="location.href='faculty_research_outputs.php?project_id=<?= $p['id'] ?>'">
                                <i class="fa fa-file-alt"></i> Research Outputs
                            </button>
                            <?php endif; ?>
                            <button class="btn btn-primary btn-sm" onclick='openEditProjectModal(<?= json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteProject(<?= $p['id'] ?>)">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        <?php else: ?>
                            <div class="readonly-notice" style="margin: 0; padding: 10px 15px;">
                                <p style="font-size: 12px; margin: 0;">
                                    <i class="fa fa-info-circle"></i> Team Member View
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="project-meta">
                    <div class="meta-item">
                        <div class="meta-label">Status</div>
                        <div class="meta-value">
                            <span class="status-badge <?= $statusClass ?>"><?= s($p['project_status']) ?></span>
                        </div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Your Role</div>
                        <div class="meta-value" style="color: <?= $isOwner ? 'var(--primary)' : 'var(--secondary)' ?>;">
                            <?= s($p['nature_of_involvement']) ?>
                        </div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Classification</div>
                        <div class="meta-value"><?= s($p['classification']) ?: 'N/A' ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Funding Source</div>
                        <div class="meta-value"><?= s($p['funding_source']) ?: 'N/A' ?></div>
                    </div>
                    <?php 
                    $totalFunding = 0;
                    $projectCosts = $conn->query("SELECT * FROM faculty_project_costs WHERE project_id = {$p['id']}")->fetch_all(MYSQLI_ASSOC);
                    foreach ($projectCosts as $cost) {
                        $totalFunding += $cost['institution_fund'] + $cost['government_fund'] + $cost['private_fund'] + $cost['foreign_fund'] + $cost['other_sources'];
                    }
                    ?>
                    <div class="meta-item">
                        <div class="meta-label">Total Funding</div>
                        <div class="meta-value" style="color: var(--success); font-weight: 700;">
                            <?= $totalFunding > 0 ? '₱' . number_format($totalFunding, 2) : 'Not specified' ?>
                        </div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Duration</div>
                        <div class="meta-value"><?= $duration ?: 'N/A' ?></div>
                    </div>
                </div>

                <?php if ($isOwner): ?>
                <div class="tabs">
                    <button class="tab active" onclick="switchTab(event, 'team-<?= $p['id'] ?>')">
                        <i class="fa fa-users"></i> Research Team
                    </button>
                    <button class="tab" onclick="switchTab(event, 'costs-<?= $p['id'] ?>')">
                        <i class="fa fa-money-bill-wave"></i> Cost & Funding
                    </button>
                </div>

                <div id="team-<?= $p['id'] ?>" class="tab-content active">
                    <?php if ($userRole !== 'researcher'): ?>
                    <button class="btn btn-primary btn-sm" onclick="openTeamModal(<?= $p['id'] ?>)">
                        <i class="fa fa-user-plus"></i> Add Team Member
                    </button>
                    <?php endif; ?>
                    
                    <?php if (empty($team)): ?>
                        <p style="color: var(--gray); margin-top: 20px; text-align: center;">No team members added yet.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Faculty Rank</th>
                                        <th>Employment Status</th>
                                        <th>Highest Attainment</th>
                                        <th>Nature of Involvement</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($team as $t): ?>
                                    <tr>
                                        <td><?= s($t['name']) ?></td>
                                        <td><?= s($t['faculty_rank']) ?></td>
                                        <td><?= s($t['employment_status']) ?></td>
                                        <td><?= s($t['highest_attainment']) ?></td>
                                        <td><?= s($t['nature_of_involvement']) ?></td>
                                        <td>
                                            <?php if ($userRole !== 'researcher'): ?>
                                            <button class="btn btn-danger btn-sm" onclick="deleteTeam(<?= $t['id'] ?>, <?= $p['id'] ?>)">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                            <?php else: ?>
                                            <span style="color: var(--gray);">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <div id="costs-<?= $p['id'] ?>" class="tab-content">
                    <?php if ($userRole !== 'researcher'): ?>
                    <button class="btn btn-primary btn-sm" onclick='openCostsModal(<?= $p["id"] ?>, <?= htmlspecialchars(json_encode($costs), ENT_QUOTES) ?>)'>
                        <i class="fa fa-edit"></i> Edit Cost & Funding
                    </button>
                    <?php endif; ?>
                    
                    <?php if (empty($costs)): ?>
                        <p style="color: var(--gray); margin-top: 20px; text-align: center;">No cost breakdown added yet.</p>
                    <?php else: 
                        $totals = ['institution' => 0, 'government' => 0, 'private' => 0, 'foreign' => 0, 'other' => 0];
                        foreach ($costs as $c) {
                            $totals['institution'] += $c['institution_fund'];
                            $totals['government'] += $c['government_fund'];
                            $totals['private'] += $c['private_fund'];
                            $totals['foreign'] += $c['foreign_fund'];
                            $totals['other'] += $c['other_sources'];
                        }
                        $totals['grand'] = array_sum($totals);
                    ?>
                        <div style="overflow-x: auto;">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Item of Expenditure</th>
                                        <th>Institution Fund</th>
                                        <th>Government Fund</th>
                                        <th>Private Fund</th>
                                        <th>Foreign Fund</th>
                                        <th>Other Sources</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($costs as $c): 
                                        $rowTotal = $c['institution_fund'] + $c['government_fund'] + $c['private_fund'] + $c['foreign_fund'] + $c['other_sources'];
                                    ?>
                                    <tr>
                                        <td><strong><?= s($c['item_of_expenditure']) ?></strong></td>
                                        <td>₱<?= number_format($c['institution_fund'], 2) ?></td>
                                        <td>
                                            ₱<?= number_format($c['government_fund'], 2) ?>
                                            <?php if ($c['government_fund_source']): ?>
                                                <br><small style="color: var(--gray);">(<?= s($c['government_fund_source']) ?>)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            ₱<?= number_format($c['private_fund'], 2) ?>
                                            <?php if ($c['private_fund_source']): ?>
                                                <br><small style="color: var(--gray);">(<?= s($c['private_fund_source']) ?>)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            ₱<?= number_format($c['foreign_fund'], 2) ?>
                                            <?php if ($c['foreign_fund_source']): ?>
                                                <br><small style="color: var(--gray);">(<?= s($c['foreign_fund_source']) ?>)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            ₱<?= number_format($c['other_sources'], 2) ?>
                                            <?php if ($c['other_sources_name']): ?>
                                                <br><small style="color: var(--gray);">(<?= s($c['other_sources_name']) ?>)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><strong>₱<?= number_format($rowTotal, 2) ?></strong></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <tr style="background: var(--success-light); font-weight: 700;">
                                        <td><strong>TOTAL</strong></td>
                                        <td>₱<?= number_format($totals['institution'], 2) ?></td>
                                        <td>₱<?= number_format($totals['government'], 2) ?></td>
                                        <td>₱<?= number_format($totals['private'], 2) ?></td>
                                        <td>₱<?= number_format($totals['foreign'], 2) ?></td>
                                        <td>₱<?= number_format($totals['other'], 2) ?></td>
                                        <td style="background: var(--success); color: var(--white);">₱<?= number_format($totals['grand'], 2) ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                    <div class="readonly-notice">
                        <p>
                            <i class="fa fa-info-circle"></i> 
                            You are a team member on this project. Contact the project leader to view or modify team and funding details.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<!-- ADD PROJECT MODAL -->
<div id="addProjectModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-plus-circle"></i> Add Research Project</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="addProjectForm">
            <input type="hidden" name="action" value="add_project">
            
            <div class="section-title"><i class="fa fa-info-circle"></i> Project Information</div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Title of Research Project <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="title" required placeholder="Enter project title">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Project Status</label>
                    <select name="project_status">
                        <option value="on-going">On-going</option>
                        <option value="completed">Completed</option>
                        <option value="published">Published</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Classification</label>
                    <input type="text" name="classification" placeholder="e.g., Basic or Applied">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Funding Source</label>
                    <input type="text" name="funding_source" placeholder="e.g., DOST, Internal, Private">
                </div>
                <div class="form-group">
                    <label>Nature of Involvement</label>
                    <input type="text" name="nature_of_involvement" placeholder="e.g., Lead Researcher">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="end_date">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Project
                </button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT PROJECT MODAL -->
<div id="editProjectModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-edit"></i> Edit Research Project</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="editProjectForm">
            <input type="hidden" name="action" value="edit_project">
            <input type="hidden" name="id">
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Title of Research Project <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="title" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Project Status</label>
                    <select name="project_status">
                        <option value="on-going">On-going</option>
                        <option value="completed">Completed</option>
                        <option value="published">Published</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Classification</label>
                    <input type="text" name="classification" placeholder="e.g., Basic or Applied">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Funding Source</label>
                    <input type="text" name="funding_source" placeholder="e.g., DOST, Internal">
                </div>
                <div class="form-group">
                    <label>Nature of Involvement</label>
                    <input type="text" name="nature_of_involvement" placeholder="e.g., Lead Researcher">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="start_date">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="end_date">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ADD TEAM MEMBER MODAL -->
<div id="teamModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user-plus"></i> Add Team Member</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="teamForm">
            <input type="hidden" name="action" value="add_team">
            <input type="hidden" name="project_id" id="team_project_id">
            
            <div class="info-box">
                <p>
                    <i class="fa fa-info-circle"></i> 
                    <strong>Select Faculty Member:</strong> Choose an imported researcher from the same parent unit. 
                    Their information will be automatically filled and the project will be added to their profile.
                </p>
            </div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Select Faculty Member <span style="color: var(--danger);">*</span></label>
                    <select name="faculty_id" id="team_faculty_id" required>
                        <option value="">-- Select a faculty member --</option>
                        <?php foreach ($teamMemberOptions as $option): ?>
                            <option value="<?= $option['id'] ?>">
                                <?= htmlspecialchars($option['name']) ?> 
                                (<?= htmlspecialchars($option['faculty_number']) ?>)
                                <?php if (!empty($option['email'])): ?>
                                    - <?= htmlspecialchars($option['email']) ?>
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($teamMemberOptions)): ?>
                        <small style="color: var(--warning); font-size: 12px; margin-top: 6px; display: block;">
                            <i class="fa fa-exclamation-triangle"></i> No imported researchers available. Only imported researchers from the same parent unit can be added as team members.
                        </small>
                    <?php else: ?>
                        <small style="color: var(--gray); font-size: 12px; margin-top: 6px; display: block;">
                            Showing <?= count($teamMemberOptions) ?> imported researcher(s) from the same parent unit
                        </small>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Nature of Involvement <span style="color: var(--danger);">*</span></label>
                    <select name="nature_of_involvement" required>
                        <option value="">Select role...</option>
                        <option value="Project Leader">Project Leader</option>
                        <option value="Co-Researcher">Co-Researcher</option>
                        <option value="Research Assistant">Research Assistant</option>
                        <option value="Technical Consultant">Technical Consultant</option>
                        <option value="Data Analyst">Data Analyst</option>
                        <option value="Subject Matter Expert">Subject Matter Expert</option>
                        <option value="Adviser">Adviser</option>
                    </select>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-user-plus"></i> Add Member
                </button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT PROJECT COSTS MODAL -->
<div id="costsModal" class="modal">
    <div class="modal-content" style="max-width: 1200px;">
        <div class="modal-header">
            <h3><i class="fa fa-money-bill-wave"></i> Edit Project Cost and Funding Source</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="costsForm">
            <input type="hidden" name="action" value="save_costs">
            <input type="hidden" name="project_id" id="costs_project_id">
            
            <div class="section-title"><i class="fa fa-money-bill-wave"></i> Project Cost and Funding Source</div>
            <p style="color: var(--gray); font-size: 13px; margin-bottom: 15px;">
                Specify the source and amount for each expenditure item. Click "Add Row" to add more items.
            </p>
            
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Item of Expenditure</th>
                            <th>Institution Fund</th>
                            <th>Government Fund</th>
                            <th>Private Fund</th>
                            <th>Foreign Fund</th>
                            <th>Other Sources</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="costsTableBody">
                    </tbody>
                </table>
            </div>
            
            <button type="button" class="btn btn-secondary btn-sm" onclick="addCostRow()" style="margin-top: 15px;">
                <i class="fa fa-plus"></i> Add Row
            </button>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Cost Breakdown
                </button>
            </div>
        </form>
    </div>
</div>

<script src="facultyresearcherprofilescript.js"></script>
</body>
</html>