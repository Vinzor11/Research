<?php
require 'db.php';
require 'config.php';
session_start();
$ssoConfig = getOAuthConfig($conn);
$ssoEnabled = !empty($ssoConfig['enabled']) && !empty($ssoConfig['client_id']) && !empty($ssoConfig['client_secret']) && !empty($ssoConfig['provider_url']) && !empty($ssoConfig['redirect_uri']);
$error = "";
if (isset($_GET['error'])) {
    $error = $_GET['error'];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    // Check which role column exists (user_role is preferred, role is legacy)
    $checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'");
    $hasUserRoleColumn = $checkRoleColumn->num_rows > 0;
    $roleColumn = $hasUserRoleColumn ? 'user_role' : 'role';
    
    // Check if fullname column exists
    $checkFullnameColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'fullname'");
    $hasFullnameColumn = $checkFullnameColumn->num_rows > 0;
    $fullnameSelect = $hasFullnameColumn ? ', fullname' : '';
    
    $stmt = $conn->prepare("SELECT id, password, $roleColumn, coordinator_type$fullnameSelect FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    if ($user) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['fullname'] = $user['fullname'] ?? $username;
            $_SESSION['user_role'] = $user[$roleColumn];
            $_SESSION['coordinator_type'] = $user['coordinator_type'];
            
            // Check if user is an imported researcher and redirect to their profile
            $checkImported = $conn->query("SELECT imported FROM users WHERE id = " . $user['id'] . " LIMIT 1");
            if ($checkImported && $checkImported->num_rows > 0) {
                $userData = $checkImported->fetch_assoc();
                if (!empty($userData['imported']) && $userData['imported'] == 1) {
                    // User is an imported researcher - find their faculty_researcher record
                    $facultyStmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
                    $facultyStmt->bind_param("i", $user['id']);
                    $facultyStmt->execute();
                    $facultyResult = $facultyStmt->get_result();
                    
                    if ($facultyResult && $facultyResult->num_rows > 0) {
                        $facultyData = $facultyResult->fetch_assoc();
                        $facultyId = $facultyData['id'];
                        $facultyStmt->close();
                        
                        // Redirect to faculty researcher profile
                        header("Location: facultyresearcherprofile.php?id=" . $facultyId);
                        exit;
                    }
                    $facultyStmt->close();
                }
            }
            
            header("Location: index.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMS - Login</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="logo-container">
            <img src="essu.png" alt="University Logo" class="logo">
            <div class="university-name">Eastern Samar State University</div>
            <div class="system-subtitle">Research Management System</div>
        </div>

        <div class="login-container">
            <div class="form-title">Welcome Back</div>
            <div class="form-subtitle">Sign in to continue to your account</div>
            
            <?php if ($error): ?>
                <div class="error-message">
                    <strong>⚠️ <?= htmlspecialchars($error) ?></strong>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required autofocus>
                </div>
                
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <div class="form-buttons">
                    <button type="submit" class="btn btn-login" style="width: 100%;">Login</button>
                </div>
            </form>

            <!-- SSO Login Option (from Admin → SSO Settings or config) -->
            <?php if ($ssoEnabled): ?>
            <div style="margin-top: 20px; text-align: center;">
                <div style="margin: 20px 0; position: relative;">
                    <hr style="border: none; border-top: 1px solid #ddd;">
                    <span style="position: absolute; top: -10px; left: 50%; transform: translateX(-50%); background: white; padding: 0 15px; color: #666;">OR</span>
                </div>
                <a href="oauth_redirect.php" style="display: inline-block; padding: 12px 24px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; font-weight: 500; transition: background 0.3s;">
                    🔐 Sign in with HR System (SSO)
                </a>
            </div>
            <?php endif; ?>

            <div class="footer-text">
                © <?php echo date("Y"); ?> ESSU. All rights reserved.
            </div>
        </div>
    </div>
</body>
</html>
