<?php
/**
 * Assign Coordinators Page
 * Shows employees with Research Coordinator position and allows assignment
 */

session_start();
require 'db.php';
require 'config.php';
require 'hr_api_helper.php';

// Admin only access
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? null) !== 'admin') {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$coordinatorType = $_GET['type'] ?? 'faculty'; // faculty or student
$coordinatorType = in_array($coordinatorType, ['faculty', 'student']) ? $coordinatorType : 'faculty';

$error = '';
$success = '';
$employees = [];
$assignedCoordinators = [];

// Ensure table for persisting synced coordinators exists
try {
    $conn->query("CREATE TABLE IF NOT EXISTS synced_research_coordinators (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(100) NOT NULL,
        full_name VARCHAR(255) DEFAULT '',
        email VARCHAR(255) DEFAULT '',
        position_name VARCHAR(255) DEFAULT '',
        unit_name VARCHAR(255) DEFAULT '',
        sector_name VARCHAR(255) DEFAULT '',
        synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_employee_id (employee_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {
    errorLog("Assign Coordinators - Create table", ['error' => $e->getMessage()]);
}

// Get assigned coordinators from database
try {
    $stmt = $conn->prepare("
        SELECT ca.id, ca.employee_id, ca.coordinator_type, ca.assigned_at, ca.status,
               u.username as assigned_by_username
        FROM coordinator_assignments ca
        LEFT JOIN users u ON ca.assigned_by = u.id
        WHERE ca.coordinator_type = ? AND ca.status = 'active'
        ORDER BY ca.assigned_at DESC
    ");
    $stmt->bind_param("s", $coordinatorType);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $assignedCoordinators[$row['employee_id']] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    $error = "Error loading assigned coordinators: " . $e->getMessage();
}

// Helper: check if employee has Research Coordinator position (name or code per RESEARCH_OFFICE_API_GUIDE)
function isResearchCoordinatorPosition($employee) {
    $position = $employee['position'] ?? [];
    $positionName = strtolower(trim($position['name'] ?? ''));
    $positionCode = strtoupper(trim($position['code'] ?? ''));
    $matches = (
        $positionCode === 'RES_COORD' ||
        strpos($positionName, 'research coordinator') !== false ||
        strpos($positionName, 'researchcoordinator') !== false ||
        strpos($positionName, 'research coord') !== false ||
        strpos($positionName, 'res coord') !== false
    );
    return $matches;
}

// Fetch employees only when user clicks Sync (RESEARCH_OFFICE_API_GUIDE)
$syncRequested = isset($_GET['sync']) && $_GET['sync'] === '1';
$syncDiagnostic = '';
if ($syncRequested && isHRIntegrationAvailable()) {
    try {
        $hrAPI = new HRSystemAPI($conn, $userId);
        
        // Try Research Office API first: GET /api/research/coordinators (RESEARCH_OFFICE_API_GUIDE)
        debugLog("Assign Coordinators - Trying Research Office API /api/research/coordinators");
        $employees = $hrAPI->fetchAllResearchCoordinators('active');
        
        // Fallback 2: Try Designations API GET /api/designations?position_code=RES_COORD (RESEARCH_OFFICE_API_GUIDE)
        if (empty($employees)) {
            debugLog("Assign Coordinators - Trying Designations API /api/designations?position_code=RES_COORD");
            $employees = $hrAPI->fetchCoordinatorsFromDesignations();
        }
        
        // Fallback 3: fetch all employees and filter by position if Research Office / Designations APIs not available
        if (empty($employees)) {
            debugLog("Assign Coordinators - APIs not available, falling back to fetchAllEmployees + filter");
            $firstPage = $hrAPI->getAllEmployees(1, 50, 'active');
            if (!empty($firstPage['error'])) {
                throw new Exception($firstPage['error']);
            }
            $allEmployees = $firstPage['data'] ?? [];
            $lastPage = $firstPage['meta']['last_page'] ?? 1;
            for ($page = 2; $page <= $lastPage; $page++) {
                sleep(1);
                $nextPage = $hrAPI->getAllEmployees($page, 50, 'active');
                if (!empty($nextPage['error'])) {
                    throw new Exception($nextPage['error']);
                }
                $allEmployees = array_merge($allEmployees, $nextPage['data'] ?? []);
            }
            $syncDiagnostic = "Fetched " . count($allEmployees) . " total employee(s) from HR; ";
            foreach ($allEmployees as $employee) {
                if (isResearchCoordinatorPosition($employee)) {
                    $employees[] = $employee;
                }
            }
            $syncDiagnostic .= count($employees) . " had Research Coordinator position.";
        }
        
        debugLog("Assign Coordinators - Found " . count($employees) . " employees with Research Coordinator position");
        
        if (empty($employees)) {
            $error = "No employees with Research Coordinator position found in HR System.";
            if ($syncDiagnostic) {
                $error .= " (" . $syncDiagnostic . ")";
            } else {
                $error .= " The Research Office API may not be available on your HR system, or no employees have the Research Coordinator (RES_COORD) position.";
            }
        } else {
            syncCoordinatorsToUsers($conn, $employees);
            saveSyncedCoordinators($conn, $employees);
            $success = "Synced " . count($employees) . " employee(s) with Research Coordinator position from HR System. User accounts have been created or updated.";
        }
        
    } catch (Exception $e) {
        $error = "Error fetching employees from HR System: " . $e->getMessage();
        errorLog("Assign Coordinators - HR API Error", ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
    }
} elseif ($syncRequested && !isHRIntegrationAvailable()) {
    $error = "HR System integration is not available. Please configure OAuth credentials.";
} elseif (!isHRIntegrationAvailable()) {
    $error = "HR System integration is not available. Please configure OAuth credentials.";
}

// When not syncing, load coordinators from last saved snapshot so the table persists across page visits
if (empty($employees)) {
    $employees = loadSyncedCoordinators($conn);
}

// Last sync time for indicator
$lastSyncedAt = null;
try {
    $r = $conn->query("SELECT MAX(synced_at) AS last_synced FROM synced_research_coordinators");
    if ($r && ($row = $r->fetch_assoc()) && !empty($row['last_synced'])) {
        $lastSyncedAt = $row['last_synced'];
    }
} catch (Exception $e) {
    // ignore
}

/**
 * Save synced research coordinators to database so the list persists when leaving the page.
 */
function saveSyncedCoordinators($conn, $employees) {
    if (empty($employees)) return;
    try {
        $conn->query("DELETE FROM synced_research_coordinators");
        $stmt = $conn->prepare("INSERT INTO synced_research_coordinators (employee_id, full_name, email, position_name, unit_name, sector_name) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($employees as $emp) {
            $id = $emp['id'] ?? '';
            $name = $emp['name'] ?? [];
            $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
            $email = $emp['contact']['email'] ?? '';
            $positionName = $emp['position']['name'] ?? '';
            $unitName = $emp['unit']['name'] ?? '';
            $sectorName = is_array($emp['sector'] ?? null) ? ($emp['sector']['name'] ?? '') : '';
            $stmt->bind_param("ssssss", $id, $fullName, $email, $positionName, $unitName, $sectorName);
            $stmt->execute();
        }
        $stmt->close();
    } catch (Exception $e) {
        errorLog("saveSyncedCoordinators", ['error' => $e->getMessage()]);
    }
}

/**
 * Load synced research coordinators from database (same structure as HR API response for display).
 */
function loadSyncedCoordinators($conn) {
    $employees = [];
    try {
        $result = $conn->query("SELECT employee_id, full_name, email, position_name, unit_name, sector_name FROM synced_research_coordinators ORDER BY full_name");
        if (!$result) return $employees;
        while ($row = $result->fetch_assoc()) {
            $employees[] = [
                'id' => $row['employee_id'],
                'name' => ['full_name' => $row['full_name']],
                'contact' => ['email' => $row['email'] ?? ''],
                'position' => ['name' => $row['position_name'] ?? 'N/A'],
                'unit' => ['name' => $row['unit_name'] ?? 'N/A'],
                'sector' => ['name' => $row['sector_name'] ?? ''],
            ];
        }
    } catch (Exception $e) {
        errorLog("loadSyncedCoordinators", ['error' => $e->getMessage()]);
    }
    return $employees;
}

/**
 * Sync research coordinator employees to users table (create or update).
 * Called after successful sync from HR so users exist when admin assigns coordinator type.
 */
function syncCoordinatorsToUsers($conn, $employees) {
    if (empty($employees)) return;
    $hasEmployeeId = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'")->num_rows > 0;
    $hasUserRole = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'")->num_rows > 0;
    $hasCoordType = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'")->num_rows > 0;
    $hasEmail = $conn->query("SHOW COLUMNS FROM users LIKE 'email'")->num_rows > 0;
    if (!$hasEmployeeId || !$hasUserRole) return;
    $created = 0;
    $updated = 0;
    foreach ($employees as $emp) {
        $employeeId = $emp['id'] ?? '';
        $contact = $emp['contact'] ?? [];
        $email = trim($contact['email'] ?? '');
        $name = $emp['name'] ?? [];
        $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
        $username = $email ?: $employeeId;
        if (empty($employeeId)) continue;
        $normalizedId = normalizeEmployeeId($employeeId);
        $existing = null;
        if ($hasEmployeeId) {
            $stmt = $conn->prepare("SELECT id, username, user_role, coordinator_type FROM users WHERE employee_id = ? LIMIT 1");
            $stmt->bind_param("s", $normalizedId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
        if (!$existing && $hasEmail && $email) {
            $stmt = $conn->prepare("SELECT id, username, user_role, coordinator_type FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
        if ($existing) {
            $updates = ["user_role = 'coordinator'"];
            $params = [];
            $types = '';
            if ($hasEmail && $email && ($existing['email'] ?? '') !== $email) {
                $updates[] = "email = ?";
                $params[] = $email;
                $types .= 's';
            }
            if ($hasEmployeeId && ($existing['employee_id'] ?? '') !== $normalizedId) {
                $updates[] = "employee_id = ?";
                $params[] = $normalizedId;
                $types .= 's';
            }
            $params[] = $existing['id'];
            $types .= 'i';
            $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $stmt->close();
            $updated++;
        } else {
            $randomPassword = bin2hex(random_bytes(16));
            $passwordHash = password_hash($randomPassword, PASSWORD_DEFAULT);
            $cols = ['username', 'password', 'user_role'];
            $vals = [$username, $passwordHash, 'coordinator'];
            $types = 'sss';
            if ($hasEmail) { $cols[] = 'email'; $vals[] = $email ?: ''; $types .= 's'; }
            if ($hasEmployeeId) { $cols[] = 'employee_id'; $vals[] = $normalizedId; $types .= 's'; }
            $placeholders = implode(',', array_fill(0, count($vals), '?'));
            $sql = "INSERT INTO users (" . implode(', ', $cols) . ") VALUES ($placeholders)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$vals);
            $stmt->execute();
            $stmt->close();
            $created++;
        }
    }
    debugLog("Sync coordinators to users", ['created' => $created, 'updated' => $updated]);
}

function s($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign <?= ucfirst($coordinatorType) ?> Coordinator - Research Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #f5f7fa;
            color: #1f2937;
        }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #064e1a 0%, #0b6a24 100%);
            color: white;
            padding: 20px 0;
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header img {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        
        .sidebar-header h3 {
            font-size: 16px;
            font-weight: 600;
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .main {
            margin-left: 250px;
            min-height: 100vh;
        }
        
        .header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header-title i {
            font-size: 24px;
            color: #064e1a;
        }
        
        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }
        
        .content {
            padding: 30px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #dc2626;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #064e1a;
            color: white;
        }
        
        .btn-primary:hover {
            background: #0b6a24;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-assign {
            background: #3b82f6;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .btn-assign:hover {
            background: #2563eb;
        }
        
        .btn-remove {
            background: #ef4444;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .btn-remove:hover {
            background: #dc2626;
        }
        
        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f9fafb;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        tr:hover {
            background: #f9fafb;
        }
        
        .badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-assigned {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-unassigned {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #d1d5db;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="essu.png" alt="ESSU Logo">
            <h3>Research Management</h3>
        </div>
        <div class="sidebar-nav">
            <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
            <a href="users.php"><i class="fa fa-users-cog"></i> User Management</a>
            <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php?type=faculty" class="active"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
        </div>
    </div>
    
    <div class="main">
        <div class="header">
            <div class="header-title">
                <i class="fa fa-user-tie"></i>
                <h1>Assign <?= ucfirst($coordinatorType) ?> Coordinator</h1>
            </div>
            <div>
                <a href="assign_coordinators.php?type=faculty" class="btn <?= $coordinatorType === 'faculty' ? 'btn-primary' : 'btn-secondary' ?>">
                    <i class="fa fa-chalkboard-teacher"></i> Faculty
                </a>
                <a href="assign_coordinators.php?type=student" class="btn <?= $coordinatorType === 'student' ? 'btn-primary' : 'btn-secondary' ?>">
                    <i class="fa fa-user-graduate"></i> Student
                </a>
            </div>
        </div>
        
        <div class="content">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fa fa-exclamation-circle"></i>
                    <span><?= s($error) ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <span><?= s($success) ?></span>
                </div>
            <?php endif; ?>
            
            <div class="page-header">
                <div>
                    <h2>Research Coordinators from HR System</h2>
                    <p style="color: #6b7280; margin-top: 5px;">
                        Employees with "Research Coordinator" position fetched from HR System. 
                        Select employees to assign as <?= $coordinatorType ?> research coordinators.
                    </p>
                    <?php if (!empty($employees)): ?>
                        <p style="color: #059669; margin-top: 5px; font-weight: 600;">
                            <i class="fa fa-check-circle"></i> Found <?= count($employees) ?> employee(s) with Research Coordinator position
                        </p>
                    <?php endif; ?>
                    <p style="color: #6b7280; margin-top: 4px; font-size: 13px;">
                        <?php if ($lastSyncedAt): ?>
                            <i class="fa fa-clock-o"></i> Last synced: <?= date('M j, Y \a\t g:i A', strtotime($lastSyncedAt)) ?>
                        <?php else: ?>
                            <i class="fa fa-clock-o"></i> Last synced: Never
                        <?php endif; ?>
                    </p>
                </div>
                <?php if (isHRIntegrationAvailable()): ?>
                <a href="assign_coordinators.php?sync=1&type=<?= $coordinatorType ?>" class="btn btn-primary">
                    <i class="fa fa-sync-alt"></i> Sync from HR
                </a>
                <?php endif; ?>
            </div>
            
            <div class="table-container">
                <?php if (empty($employees) && empty($error)): ?>
                    <div class="empty-state">
                        <i class="fa fa-cloud-download-alt" style="font-size: 48px; color: #064e1a;"></i>
                        <p>Click <strong>Sync from HR</strong> to fetch employees with Research Coordinator position.</p>
                        <p style="margin-top: 10px; font-size: 14px; color: #6b7280;">
                            Uses Research Office API (<code>/api/research/coordinators</code>), then Designations API (<code>/api/designations?position_code=RES_COORD</code>), then HR Employees API.
                        </p>
                    </div>
                <?php elseif (empty($employees) && !empty($error)): ?>
                    <div class="empty-state">
                        <i class="fa fa-exclamation-triangle" style="color: #dc2626;"></i>
                        <p style="color: #dc2626;"><?= s($error) ?></p>
                        <?php if (!isHRIntegrationAvailable()): ?>
                            <p style="margin-top: 10px; color: #dc2626;">HR System integration is not configured. Please check your OAuth credentials in config.php</p>
                        <?php else: ?>
                            <div style="margin-top: 15px; padding: 15px; background: #fef3c7; border-radius: 8px; text-align: left; max-width: 540px;">
                                <p style="font-weight: 600; color: #92400e; margin-bottom: 8px;">Troubleshooting:</p>
                                <ul style="margin: 0; padding-left: 20px; color: #78350f; font-size: 14px; line-height: 1.6;">
                                    <li><strong>Different HR provider?</strong> Go to <a href="oauth_settings.php">SSO Settings</a> and set your correct <strong>OAuth Provider URL</strong> (e.g. <code>https://your-hr-system.edu</code>).</li>
                                    <li><strong>Token expired?</strong> Log out and log in again via SSO.</li>
                                    <li><strong>HR API not reachable?</strong> Verify that <code>/api/research/coordinators</code>, <code>/api/designations</code>, or <code>/api/employees</code> is accessible at your HR URL.</li>
                                    <li><strong>No coordinators in HR?</strong> Ensure employees have position "Research Coordinator" or code <code>RES_COORD</code> in your HR system.</li>
                                </ul>
                                <?php 
                                $hrConfig = getOAuthConfig($conn);
                                $currentUrl = rtrim($hrConfig['provider_url'] ?? '', '/');
                                if (!empty($currentUrl)): ?>
                                <p style="margin-top: 10px; font-size: 13px; color: #92400e;"><strong>Current HR URL:</strong> <code><?= htmlspecialchars($currentUrl) ?></code></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Unit</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employees as $emp): 
                                $empId = $emp['id'] ?? '';
                                $isAssigned = isset($assignedCoordinators[$empId]);
                                $name = $emp['name'] ?? [];
                                // Use full_name if available, otherwise construct from parts
                                $fullName = $name['full_name'] ?? '';
                                if (empty($fullName)) {
                                    $fullName = trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                                }
                                if (empty($fullName)) {
                                    $fullName = 'N/A';
                                }
                            ?>
                                <tr>
                                    <td><strong><?= s($empId) ?></strong></td>
                                    <td><?= s($fullName) ?></td>
                                    <td><?= s($emp['position']['name'] ?? 'N/A') ?></td>
                                    <td><?= s($emp['unit']['name'] ?? ($emp['sector']['name'] ?? 'N/A')) ?></td>
                                    <td><?= s($emp['contact']['email'] ?? 'N/A') ?></td>
                                    <td>
                                        <?php if ($isAssigned): ?>
                                            <span class="badge badge-assigned">
                                                <i class="fa fa-check"></i> Assigned
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-unassigned">
                                                <i class="fa fa-times"></i> Not Assigned
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($isAssigned): ?>
                                            <button class="btn btn-remove" onclick="removeCoordinator('<?= s($empId) ?>', '<?= $coordinatorType ?>')">
                                                <i class="fa fa-trash"></i> Remove
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-assign" onclick="assignCoordinator('<?= s($empId) ?>', '<?= $coordinatorType ?>')">
                                                <i class="fa fa-plus"></i> Assign
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        async function assignCoordinator(employeeId, type) {
            if (!confirm(`Assign this employee as ${type} research coordinator?`)) {
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('action', 'assign');
                formData.append('employee_id', employeeId);
                formData.append('coordinator_type', type);
                
                const response = await fetch('assign_coordinator_api.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Coordinator assigned successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to assign coordinator'));
                }
            } catch (error) {
                alert('Error: ' + error.message);
            }
        }
        
        async function removeCoordinator(employeeId, type) {
            if (!confirm(`Remove this employee from ${type} research coordinator assignment?`)) {
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('action', 'remove');
                formData.append('employee_id', employeeId);
                formData.append('coordinator_type', type);
                
                const response = await fetch('assign_coordinator_api.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Coordinator removed successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to remove coordinator'));
                }
            } catch (error) {
                alert('Error: ' + error.message);
            }
        }
    </script>
</body>
</html>
