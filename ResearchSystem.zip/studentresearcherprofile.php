<?php
/**
 * Student Researcher Profile Page
 * 
 * Displays student researcher details and research outputs
 * Uses ResearcherProfileAccess for scope-based access control
 * 
 * Access Rules:
 * - Admin: Full view (institution-wide), read-only for HR data
 * - Coordinator: Scoped view (unit + student coordinator type required)
 * - Researcher: Own profile only
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db.php';
require_once 'ResearcherProfileAccess.php';

// Initialize access control
$profileAccess = new ResearcherProfileAccess($conn);

// ============================================
// SESSION & ACCESS CONTROL
// ============================================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? null;

// This page runs as a full standalone page (not SPA)

// Check if student ID is provided
if (!isset($_GET['id'])) {
    // For researchers, try to find their own profile
    if ($userRole === 'researcher') {
        $findStmt = $conn->prepare("SELECT id FROM student_researchers WHERE user_id = ? LIMIT 1");
        $findStmt->bind_param("i", $userId);
        $findStmt->execute();
        $findResult = $findStmt->get_result();
        if ($findResult && $findResult->num_rows > 0) {
            $findData = $findResult->fetch_assoc();
            header("Location: studentresearcherprofile.php?id=" . $findData['id']);
            exit;
        }
        $findStmt->close();
    }
    header("Location: studentresearcher.php");
    exit;
}

$student_id = (int) $_GET['id'];

// ============================================
// ACCESS CONTROL CHECK (Using ResearcherProfileAccess)
// ============================================
$accessResult = $profileAccess->requireProfileAccess('student', $student_id);
$accessLevel = $accessResult['access_level'];
$isReadOnly = $accessResult['is_read_only'];
$accessSummary = $profileAccess->getAccessSummary();

// Fetch student data
$stmt = $conn->prepare("SELECT * FROM student_researchers WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    die("Student not found.");
}

// Filter restricted fields
$student = $profileAccess->filterResearcherData($student);

// ============================================
// OVERRIDE: Allow admin and coordinator to modify student profiles
// ============================================
if ($userRole === 'admin' || $userRole === 'coordinator') {
    $isReadOnly = false;
}

// Determine if user can edit
$canEdit = !$isReadOnly && (
    $userRole === 'admin' || 
    $userRole === 'coordinator' ||
    $accessLevel === 'own_profile'
);

// Create student research team table if doesn't exist
try {
    $conn->query("
        CREATE TABLE IF NOT EXISTS student_research_team (
            id INT AUTO_INCREMENT PRIMARY KEY,
            research_id INT NOT NULL,
            name VARCHAR(255) NOT NULL,
            student_number VARCHAR(20),
            email VARCHAR(150),
            course_year_section VARCHAR(50),
            role VARCHAR(100),
            department VARCHAR(150),
            contribution TEXT,
            FOREIGN KEY (research_id) REFERENCES research_outputs(id) ON DELETE CASCADE,
            INDEX idx_research_id (research_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (Exception $e) {
    // Table already exists
}

// Handle AJAX operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Clear any previous output
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    
    header('Content-Type: application/json');
    
    try {
        // ============================================
        // ADD RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'add_research') {
            $title = trim($_POST['title']);
            $project_leader = trim($_POST['project_leader'] ?? '');
            $project_start = !empty($_POST['project_start']) ? $_POST['project_start'] : null;
            $project_end = !empty($_POST['project_end']) ? $_POST['project_end'] : null;
            $isbn = trim($_POST['isbn'] ?? '');
            $tracking_number = trim($_POST['tracking_number'] ?? '');
            $status = trim($_POST['status'] ?? 'on-going');

            if (empty($title)) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Title is required"]);
                exit;
            }

            $stmt = $conn->prepare("INSERT INTO research_outputs (student_id, title, project_leader, project_start, project_end, isbn, tracking_number, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isssssss", $student_id, $title, $project_leader, $project_start, $project_end, $isbn, $tracking_number, $status);
            
            if ($stmt->execute()) {
                ob_end_clean();
                echo json_encode(["success" => true]);
            } else {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => $stmt->error]);
            }
            exit;
        }

        // ============================================
        // EDIT RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'edit_research') {
            $research_id = (int)$_POST['id'];
            $title = trim($_POST['title']);
            $project_leader = trim($_POST['project_leader'] ?? '');
            $project_start = !empty($_POST['project_start']) ? $_POST['project_start'] : null;
            $project_end = !empty($_POST['project_end']) ? $_POST['project_end'] : null;
            $isbn = trim($_POST['isbn'] ?? '');
            $tracking_number = trim($_POST['tracking_number'] ?? '');
            $status = trim($_POST['status'] ?? 'on-going');

            $stmt = $conn->prepare("UPDATE research_outputs SET title=?, project_leader=?, project_start=?, project_end=?, isbn=?, tracking_number=?, status=? WHERE id=? AND student_id=?");
            $stmt->bind_param("sssssssii", $title, $project_leader, $project_start, $project_end, $isbn, $tracking_number, $status, $research_id, $student_id);
            
            if ($stmt->execute()) {
                ob_end_clean();
                echo json_encode(["success" => true]);
            } else {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => $stmt->error]);
            }
            exit;
        }

        // ============================================
        // DELETE RESEARCH OUTPUT
        // ============================================
        if ($_POST['action'] === 'delete_research') {
            $research_id = (int)$_POST['id'];
            $stmt = $conn->prepare("DELETE FROM research_outputs WHERE id=? AND student_id=?");
            $stmt->bind_param("ii", $research_id, $student_id);
            
            if ($stmt->execute()) {
                ob_end_clean();
                echo json_encode(["success" => true]);
            } else {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => $stmt->error]);
            }
            exit;
        }

        // ============================================
        // ADD TEAM MEMBER
        // ============================================
        if ($_POST['action'] === 'add_team') {
            $search = trim($_POST['search_student']);
            $research_id = (int)$_POST['research_id'];
            
            if (empty($search)) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Please enter a student number, name, or email to search"]);
                exit;
            }
            
            // Search query
            $searchStmt = $conn->prepare("SELECT * FROM student_researchers 
                WHERE student_number = ? 
                OR email = ? 
                OR CONCAT(last_name, ', ', first_name, ' ', middle_name) LIKE ?
                OR CONCAT(first_name, ' ', last_name) LIKE ?
                LIMIT 1");
            
            $searchPattern = "%{$search}%";
            $searchStmt->bind_param("ssss", $search, $search, $searchPattern, $searchPattern);
            $searchStmt->execute();
            $studentMember = $searchStmt->get_result()->fetch_assoc();
            
            if (!$studentMember) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "The person you're trying to add does not exist in the Student Researchers database"]);
                exit;
            }
            
            // Check if already a team member
            $checkStmt = $conn->prepare("SELECT id FROM student_research_team WHERE research_id = ? AND student_number = ?");
            $checkStmt->bind_param("is", $research_id, $studentMember['student_number']);
            $checkStmt->execute();
            if ($checkStmt->get_result()->num_rows > 0) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "This student is already part of the team"]);
                exit;
            }
            
            // Get the original research details
            $researchStmt = $conn->prepare("SELECT * FROM research_outputs WHERE id = ?");
            $researchStmt->bind_param("i", $research_id);
            $researchStmt->execute();
            $originalResearch = $researchStmt->get_result()->fetch_assoc();
            
            if (!$originalResearch) {
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Original research not found"]);
                exit;
            }
            
            $fullName = $studentMember['last_name'] . ', ' . $studentMember['first_name'] . ' ' . $studentMember['middle_name'];
            $role = trim($_POST['role'] ?? '');
            $contribution = trim($_POST['contribution'] ?? '');
            
            $conn->begin_transaction();
            
            try {
                // 1. Insert team member record
                $teamStmt = $conn->prepare("INSERT INTO student_research_team 
                    (research_id, name, student_number, email, course_year_section, role, department, contribution)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $teamStmt->bind_param("isssssss",
                    $research_id,
                    $fullName,
                    $studentMember['student_number'],
                    $studentMember['email'],
                    $studentMember['course_year_section'],
                    $role,
                    $studentMember['department'],
                    $contribution
                );
                $teamStmt->execute();
                
                // 2. Create linked research entry for the team member
                $linkedResearchStmt = $conn->prepare("INSERT INTO research_outputs 
                    (student_id, parent_project_id, is_project_leader, title, status, 
                     project_leader, project_start, project_end, isbn, tracking_number, created_at)
                    VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?, ?, NOW())");
                
                $linkedResearchStmt->bind_param("iisssssss",
                    $studentMember['id'],
                    $research_id,
                    $originalResearch['title'],
                    $originalResearch['status'],
                    $originalResearch['project_leader'],
                    $originalResearch['project_start'],
                    $originalResearch['project_end'],
                    $originalResearch['isbn'],
                    $originalResearch['tracking_number']
                );
                
                if (!$linkedResearchStmt->execute()) {
                    throw new Exception("Failed to create linked research: " . $linkedResearchStmt->error);
                }
                
                $conn->commit();
                ob_end_clean();
                echo json_encode([
                    "success" => true, 
                    "message" => "Team member added successfully and research linked to their profile"
                ]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                ob_end_clean();
                echo json_encode(["success" => false, "error" => "Failed to add team member: " . $e->getMessage()]);
                exit;
            }
        }

        // ============================================
        // DELETE TEAM MEMBER
        // ============================================
        if ($_POST['action'] === 'delete_team') {
            $team_id = (int)$_POST['id'];
            $research_id = (int)$_POST['research_id'];
            
            $conn->begin_transaction();
            
            try {
                // Get team member info before deletion
                $teamInfo = $conn->query("SELECT student_number FROM student_research_team WHERE id = $team_id")->fetch_assoc();
                
                // Delete from team table
                $stmt = $conn->prepare("DELETE FROM student_research_team WHERE id=?");
                $stmt->bind_param("i", $team_id);
                $stmt->execute();
                
                // Find and delete the linked research for this team member
                if ($teamInfo) {
                    $studentResult = $conn->query("
                        SELECT id FROM student_researchers 
                        WHERE student_number = '{$teamInfo['student_number']}'
                        LIMIT 1
                    ");
                    
                    if ($student = $studentResult->fetch_assoc()) {
                        // Delete the linked research
                        $conn->query("
                            DELETE FROM research_outputs 
                            WHERE student_id = {$student['id']} 
                            AND parent_project_id = $research_id
                        ");
                    }
                }
                
                $conn->commit();
                ob_end_clean();
                echo json_encode(["success" => true]);
                exit;
                
            } catch (Exception $e) {
                $conn->rollback();
                ob_end_clean();
                echo json_encode(["success" => false, "error" => $e->getMessage()]);
                exit;
            }
        }
        
    } catch (Exception $e) {
        ob_end_clean();
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
        exit;
    }
    
    ob_end_clean();
    echo json_encode(["success" => false, "error" => "Unknown action"]);
    exit;
}

// Fetch both owned projects and collaborative projects
$ownedProjects = $conn->query("
    SELECT *, 1 as is_owner 
    FROM research_outputs 
    WHERE student_id = $student_id AND (parent_project_id IS NULL OR parent_project_id = 0)
    ORDER BY project_start DESC, id DESC
")->fetch_all(MYSQLI_ASSOC);

$collaborativeProjects = $conn->query("
    SELECT *, 0 as is_owner 
    FROM research_outputs 
    WHERE student_id = $student_id AND parent_project_id IS NOT NULL AND parent_project_id > 0
    ORDER BY project_start DESC, id DESC
")->fetch_all(MYSQLI_ASSOC);

// Merge arrays
$researches = array_merge($ownedProjects, $collaborativeProjects);

// Calculate stats - only count owned projects
$stats = ['total' => count($ownedProjects), 'ongoing' => 0, 'completed' => 0, 'published' => 0];
$stats['collaborative'] = count($collaborativeProjects);

foreach ($ownedProjects as $p) {
    if ($p['status'] == 'on-going') $stats['ongoing']++;
    if ($p['status'] == 'completed') $stats['completed']++;
    if ($p['status'] == 'published') $stats['published']++;
}

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile - <?= s($student['last_name'] . ', ' . $student['first_name']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="studentresearcherprofilestyle.css">
</head>
<body>

<div class="page-header">
    <a href="studentresearcher.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Student List
    </a>
</div>

<div class="container">
    <!-- Profile Card -->
    <div class="profile-card">
        <div class="profile-header">
            <div class="profile-avatar">
                <i class="fa fa-user-graduate"></i>
            </div>
            <h2><?= s($student['last_name'] . ', ' . $student['first_name']) ?></h2>
            <div class="profile-subtitle"><?= s($student['course_year_section']) ?></div>
            
            <!-- Access Level Badges -->
            <div class="access-badges">
                <?php if ($accessLevel === 'institution_wide'): ?>
                    <span class="access-badge institution"><i class="fa fa-globe"></i> Institution-Wide</span>
                <?php elseif ($accessLevel === 'scoped'): ?>
                    <span class="access-badge scoped"><i class="fa fa-layer-group"></i> Scoped Access</span>
                <?php elseif ($accessLevel === 'own_profile'): ?>
                    <span class="access-badge own"><i class="fa fa-user-check"></i> Own Profile</span>
                <?php endif; ?>
                
                <?php if ($isReadOnly): ?>
                    <span class="access-badge readonly"><i class="fa fa-lock"></i> Read-Only</span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-id-card"></i> Student Number</div>
            <div class="info-value"><?= s($student['student_number']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-graduation-cap"></i> Course & Year</div>
            <div class="info-value"><?= s($student['course_year_section']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-building"></i> Department</div>
            <div class="info-value"><?= s($student['department']) ?: 'N/A' ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-home"></i> Address</div>
            <div class="info-value"><?= s($student['home_address']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-envelope"></i> Email</div>
            <div class="info-value"><?= s($student['email']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-phone"></i> Mobile</div>
            <div class="info-value"><?= s($student['mobile']) ?></div>
        </div>
        
        <div class="info-group">
            <div class="info-label"><i class="fa fa-user-tie"></i> Research Adviser</div>
            <div class="info-value"><?= s($student['research_adviser']) ?: 'N/A' ?></div>
        </div>
        
        <?php if ($canEdit): ?>
        <button class="edit-profile-btn" onclick="location.href='studentresearcherform.php?id=<?= $student_id ?>'">
            <i class="fa fa-edit"></i> Edit Profile
        </button>
        <?php elseif ($isReadOnly): ?>
        <div class="readonly-notice">
            <p><i class="fa fa-info-circle"></i> You have read-only access to this profile.</p>
        </div>
        <?php endif; ?>
        
        <?php if ($accessLevel === 'scoped'): ?>
        <div class="scope-info">
            <strong>Scope:</strong> <?= htmlspecialchars($accessSummary['scope_mode'] ?? 'N/A') ?>
            <?php if (!empty($accessSummary['hr_unit_name'])): ?>
             | <strong>Unit:</strong> <?= htmlspecialchars($accessSummary['hr_unit_name']) ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Research Section -->
    <div class="research-section">
        <?php if ($isReadOnly): ?>
        <div class="readonly-banner">
            <i class="fa fa-eye"></i>
            <span>Viewing in read-only mode. Modifications are not permitted.</span>
        </div>
        <?php endif; ?>
        
        <div class="research-header">
            <h2><i class="fa fa-flask"></i> Research Outputs</h2>
            <?php if ($canEdit): ?>
            <button class="add-research-btn" onclick="openAddResearchModal()">
                <i class="fa fa-plus-circle"></i> Add Research Output
            </button>
            <?php endif; ?>
        </div>

        <div class="stats-row">
            <div class="stat-card">
                <div class="number"><?= $stats['total'] ?></div>
                <div class="label">Led Projects</div>
            </div>
            <div class="stat-card collaborative">
                <div class="number"><?= $stats['collaborative'] ?></div>
                <div class="label">Collaborative</div>
            </div>
            <div class="stat-card warning">
                <div class="number"><?= $stats['ongoing'] ?></div>
                <div class="label">On-going</div>
            </div>
            <div class="stat-card success">
                <div class="number"><?= $stats['completed'] ?></div>
                <div class="label">Completed</div>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);">
                <div class="number"><?= $stats['published'] ?></div>
                <div class="label">Published</div>
            </div>
        </div>

        <?php if (empty($researches)): ?>
            <div class="no-data">
                <i class="fa fa-folder-open"></i>
                <p style="font-size: 18px; font-weight: 600; margin-bottom: 10px;">No research outputs yet.</p>
                <p style="font-size: 14px;">Click "Add Research Output" to get started.</p>
            </div>
        <?php else: foreach ($researches as $r): 
            $statusClass = 'status-' . str_replace('-', '', $r['status']);
            $duration = '';
            if ($r['project_start']) {
                $duration = date('M Y', strtotime($r['project_start']));
                if ($r['project_end']) {
                    $duration .= ' - ' . date('M Y', strtotime($r['project_end']));
                }
            }
            
            $isOwner = empty($r['parent_project_id']) || $r['parent_project_id'] == 0;
            $projectType = $isOwner ? 'Project Leader' : 'Collaborative Project';
            $projectIcon = $isOwner ? 'crown' : 'users';
            
            // Only fetch team for owned projects
            $team = [];
            if ($isOwner) {
                $team = $conn->query("SELECT * FROM student_research_team WHERE research_id = {$r['id']}")->fetch_all(MYSQLI_ASSOC);
            }
        ?>
            <div class="project-card">
                <div class="project-type-badge <?= $isOwner ? 'owner' : 'collaborator' ?>">
                    <i class="fa fa-<?= $projectIcon ?>"></i>
                    <?= $projectType ?>
                </div>
                
                <div class="project-card-header">
                    <div class="project-title"><?= s($r['title']) ?></div>
                    <div class="project-actions">
                        <?php if ($isOwner): ?>
                            <button class="btn btn-success btn-sm" onclick="location.href='student_research_outputs.php?research_id=<?= $r['id'] ?>'">
                                <i class="fa fa-file-alt"></i> Research Outputs
                            </button>
                            <button class="btn btn-primary btn-sm" onclick='openEditResearchModal(<?= json_encode($r, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteResearch(<?= $r['id'] ?>)">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        <?php else: ?>
                            <div class="readonly-notice" style="margin: 0; padding: 10px 15px;">
                                <p style="font-size: 12px; margin: 0;">
                                    <i class="fa fa-info-circle"></i> 
                                    Team Member View
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="project-meta">
                    <div class="meta-item">
                        <div class="meta-label">Status</div>
                        <div class="meta-value">
                            <span class="status-badge <?= $statusClass ?>"><?= s($r['status']) ?></span>
                        </div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Project Leader</div>
                        <div class="meta-value"><?= s($r['project_leader']) ?: 'N/A' ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Duration</div>
                        <div class="meta-value"><?= $duration ?: 'N/A' ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">ISBN</div>
                        <div class="meta-value"><?= s($r['isbn']) ?: 'N/A' ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Tracking Number</div>
                        <div class="meta-value"><?= s($r['tracking_number']) ?: 'N/A' ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Team Members</div>
                        <div class="meta-value" style="color: var(--primary); font-weight: 700;">
                            <?= count($team) ?> Member<?= count($team) != 1 ? 's' : '' ?>
                        </div>
                    </div>
                </div>

                <?php if ($isOwner): ?>
                <div class="tabs">
                    <button class="tab active" onclick="switchTab(event, 'team-<?= $r['id'] ?>')">
                        <i class="fa fa-users"></i> Research Project Team
                    </button>
                </div>

                <div id="team-<?= $r['id'] ?>" class="tab-content active">
                    <button class="btn btn-primary btn-sm" onclick="openTeamModal(<?= $r['id'] ?>)">
                        <i class="fa fa-user-plus"></i> Add Team Member
                    </button>
                    
                    <?php if (empty($team)): ?>
                        <p style="color: var(--gray); margin-top: 20px; text-align: center;">No team members added yet.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Student Number</th>
                                        <th>Course & Year</th>
                                        <th>Role</th>
                                        <th>Department</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($team as $t): ?>
                                    <tr>
                                        <td><strong><?= s($t['name']) ?></strong></td>
                                        <td><?= s($t['student_number']) ?></td>
                                        <td><?= s($t['course_year_section']) ?></td>
                                        <td><?= s($t['role']) ?></td>
                                        <td><?= s($t['department']) ?></td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" onclick="deleteTeam(<?= $t['id'] ?>, <?= $r['id'] ?>)">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                    <div class="readonly-notice">
                        <p>
                            <i class="fa fa-info-circle"></i> 
                            You are a team member on this project. Contact the project leader to view or modify team details.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<!-- ADD RESEARCH MODAL -->
<div id="addResearchModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-plus-circle"></i> Add Research Output</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="addResearchForm">
            <input type="hidden" name="action" value="add_research">
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Title <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="title" required placeholder="Enter research title">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Project Leader</label>
                    <input type="text" name="project_leader" placeholder="Name of project leader">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="on-going">On-going</option>
                        <option value="completed">Completed</option>
                        <option value="published">Published</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="project_start">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="project_end">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>ISBN</label>
                    <input type="text" name="isbn" placeholder="International Standard Book Number">
                </div>
                <div class="form-group">
                    <label>Tracking Number</label>
                    <input type="text" name="tracking_number" placeholder="Research tracking number">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Research
                </button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT RESEARCH MODAL -->
<div id="editResearchModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-edit"></i> Edit Research Output</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="editResearchForm">
            <input type="hidden" name="action" value="edit_research">
            <input type="hidden" name="id" id="edit_id">
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Title <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="title" id="edit_title" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Project Leader</label>
                    <input type="text" name="project_leader" id="edit_project_leader">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="edit_status">
                        <option value="on-going">On-going</option>
                        <option value="completed">Completed</option>
                        <option value="published">Published</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" name="project_start" id="edit_project_start">
                </div>
                <div class="form-group">
                    <label>End Date</label>
                    <input type="date" name="project_end" id="edit_project_end">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>ISBN</label>
                    <input type="text" name="isbn" id="edit_isbn">
                </div>
                <div class="form-group">
                    <label>Tracking Number</label>
                    <input type="text" name="tracking_number" id="edit_tracking_number">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ADD TEAM MEMBER MODAL -->
<div id="teamModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fa fa-user-plus"></i> Add Team Member</h3>
            <span class="close" onclick="closeModals()">&times;</span>
        </div>
        <form id="teamForm">
            <input type="hidden" name="action" value="add_team">
            <input type="hidden" name="research_id" id="team_research_id">
            
            <div class="info-box">
                <p>
                    <i class="fa fa-info-circle"></i> 
                    <strong>Search for Student:</strong> Enter the student number, email, or name of an existing student researcher. 
                    Their information will be automatically filled and the research will be linked to their profile.
                </p>
            </div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Search Student <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="search_student" id="search_student" required 
                           placeholder="Enter student number, email, or name (e.g., '2024-00001' or 'john.doe@email.com')">
                    <small style="color: var(--gray); font-size: 12px; margin-top: 6px; display: block;">
                        Try searching by: Student Number (2024-00001), Email (john@example.com), or Full Name (Juan Dela Cruz)
                    </small>
                </div>
            </div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Role in Research</label>
                    <select name="role">
                        <option value="">Select role...</option>
                        <option value="Co-Researcher">Co-Researcher</option>
                        <option value="Research Assistant">Research Assistant</option>
                        <option value="Data Analyst">Data Analyst</option>
                        <option value="Technical Writer">Technical Writer</option>
                        <option value="Subject Matter Expert">Subject Matter Expert</option>
                        <option value="Project Member">Project Member</option>
                    </select>
                    <small style="color: var(--gray); font-size: 12px; margin-top: 6px; display: block;">
                        Select the role this member will play in the research project
                    </small>
                </div>
            </div>
            
            <div class="form-row form-row-full">
                <div class="form-group">
                    <label>Contribution (Optional)</label>
                    <textarea name="contribution" rows="3" 
                              placeholder="Describe their contribution to the research..."></textarea>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModals()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-user-plus"></i> Add Member
                </button>
            </div>
        </form>
    </div>
</div>

<script src="studentresearcherprofilescript.js"></script>

</body>
</html>
