<?php
/**
 * Migration Script: Add imported column to users table and sync_status/user_id columns to faculty_researchers table
 * Run this once to add the columns to existing databases
 */

require 'db.php';

try {
    // Check if imported column already exists in users table
    $checkImported = $conn->query("SHOW COLUMNS FROM users LIKE 'imported'");
    
    if ($checkImported->num_rows > 0) {
        echo "✅ Column 'imported' already exists in users table.\n";
    } else {
        // Add imported column after parent_unit
        $sql = "ALTER TABLE users ADD COLUMN imported TINYINT(1) DEFAULT 0 COMMENT '1 if imported as researcher, 0 otherwise' AFTER parent_unit";
        
        if ($conn->query($sql)) {
            echo "✅ Successfully added 'imported' column to users table.\n";
        } else {
            throw new Exception("Failed to add imported column: " . $conn->error);
        }
    }
    
    // Check if sync_status column already exists in faculty_researchers table
    $checkSyncStatus = $conn->query("SHOW COLUMNS FROM faculty_researchers LIKE 'sync_status'");
    
    if ($checkSyncStatus->num_rows > 0) {
        echo "✅ Column 'sync_status' already exists in faculty_researchers table.\n";
    } else {
        // Add sync_status column after is_synced
        $sql = "ALTER TABLE faculty_researchers ADD COLUMN sync_status ENUM('synced','needs-sync','not-synced','n/a') DEFAULT 'not-synced' COMMENT 'n/a when employee deleted or not in same unit' AFTER is_synced";
        
        if ($conn->query($sql)) {
            echo "✅ Successfully added 'sync_status' column to faculty_researchers table.\n";
        } else {
            throw new Exception("Failed to add sync_status column: " . $conn->error);
        }
    }
    
    // Check if user_id column already exists in faculty_researchers table
    $checkUserId = $conn->query("SHOW COLUMNS FROM faculty_researchers LIKE 'user_id'");
    
    if ($checkUserId->num_rows > 0) {
        echo "✅ Column 'user_id' already exists in faculty_researchers table.\n";
    } else {
        // Add user_id column after created_by
        $sql = "ALTER TABLE faculty_researchers ADD COLUMN user_id INT(11) DEFAULT NULL COMMENT 'References users.id for imported researchers' AFTER created_by";
        
        if ($conn->query($sql)) {
            echo "✅ Successfully added 'user_id' column to faculty_researchers table.\n";
        } else {
            throw new Exception("Failed to add user_id column: " . $conn->error);
        }
    }
    
    // Update existing records: set sync_status based on is_synced and last_synced_at
    $updateSql = "UPDATE faculty_researchers 
                  SET sync_status = CASE 
                      WHEN is_synced = 1 AND last_synced_at IS NOT NULL THEN 
                          CASE 
                              WHEN DATEDIFF(NOW(), last_synced_at) > 30 THEN 'needs-sync'
                              ELSE 'synced'
                          END
                      ELSE 'not-synced'
                  END
                  WHERE sync_status = 'not-synced' OR sync_status IS NULL";
    
    if ($conn->query($updateSql)) {
        $affected = $conn->affected_rows;
        echo "✅ Updated sync_status for $affected existing faculty records.\n";
    } else {
        echo "⚠️ Warning: Could not update existing sync_status values: " . $conn->error . "\n";
    }
    
    echo "\n✅ Migration completed successfully!\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}

$conn->close();
?>
