<?php
/**
 * Progress Report View Page
 * Unified design matching collaboration_view.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'ProjectService.php';
require_once 'spa_helper.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$isSpa = isSpaRequest();
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';

// Get report ID
$reportId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$reportId) {
    if ($isSpa) {
        echo '<div class="error-state" style="padding: 40px; text-align: center;">
            <h3><i class="fa fa-exclamation-triangle" style="color: #f59e0b;"></i> Invalid Report ID</h3>
            <p>No report ID was provided in the URL.</p>
            <p style="color: #6b7280; font-size: 14px; margin-top: 16px;">
                This may happen if you accessed this page via an invalid link.<br>
                Please go back to the <a href="work_queue.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'work_queue.php\',true)}">Work Queue</a> 
                or <a href="research.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'research.php\',true)}">My Projects</a> and try again.
            </p>
        </div>';
    } else {
        header('Location: research.php');
    }
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$projectService = new ProjectService($conn);
$report = $projectService->getProgressReport($reportId);

if (!$report) {
    echo '<div class="error-state"><h3>Report Not Found</h3><p>The requested progress report could not be found.</p></div>';
    exit;
}

// Get project details
$project = $projectService->getProject($report['project_id']);

// Check access permission
$isOwner = ($project['created_by'] == $userId);
$isAdmin = ($userRole === 'admin');
$isCoordinator = ($userRole === 'coordinator');

if (!$isOwner && !$isAdmin && !$isCoordinator) {
    echo '<div class="error-state"><h3>Access Denied</h3><p>You do not have permission to view this report.</p></div>';
    exit;
}

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get reviewer info if reviewed
$reviewerName = null;
if ($report['reviewed_by']) {
    $stmt = $conn->prepare("SELECT fullname FROM users WHERE id = ?");
    $stmt->bind_param("i", $report['reviewed_by']);
    $stmt->execute();
    $reviewer = $stmt->get_result()->fetch_assoc();
    $reviewerName = $reviewer['fullname'] ?? 'Unknown';
    $stmt->close();
}

// Get submitter info
$submitterName = null;
if ($report['submitted_by']) {
    $stmt = $conn->prepare("SELECT fullname FROM users WHERE id = ?");
    $stmt->bind_param("i", $report['submitted_by']);
    $stmt->execute();
    $submitter = $stmt->get_result()->fetch_assoc();
    $submitterName = $submitter['fullname'] ?? 'Unknown';
    $stmt->close();
}

// Status configuration
$statusConfig = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'class' => 'status-draft'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'class' => 'status-submitted'],
    'reviewed' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_review' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_coordinator_review' => ['label' => 'Coordinator Review', 'icon' => 'fa-user-tie', 'class' => 'status-reviewing'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'class' => 'status-endorsed'],
    'under_ro_review' => ['label' => 'RO Review', 'icon' => 'fa-building', 'class' => 'status-reviewing'],
    'accepted' => ['label' => 'Accepted', 'icon' => 'fa-check-circle', 'class' => 'status-approved'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-check-circle', 'class' => 'status-approved'],
    'returned' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned'],
    'returned_for_revision' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'class' => 'status-rejected']
];
$currentStatus = $statusConfig[$report['status']] ?? ['label' => ucfirst(str_replace('_', ' ', $report['status'])), 'icon' => 'fa-info-circle', 'class' => 'status-draft'];

// Calculate completion percentage color
$completion = (int)($report['completion_percentage'] ?? 0);
if ($completion >= 75) {
    $progressColor = '#10b981';
} elseif ($completion >= 50) {
    $progressColor = '#f59e0b';
} elseif ($completion >= 25) {
    $progressColor = '#f97316';
} else {
    $progressColor = '#ef4444';
}

// Determine if on track
$isOnTrack = $report['is_on_track'] ?? true;
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   PROGRESS REPORT VIEW - UNIFIED DESIGN
   ============================================ */

.report-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.report-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.report-header-left { flex: 1; }

.report-header-left h1 {
    font-size: 24px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.3;
}

.report-header-left .project-link {
    font-size: 14px;
    color: rgba(255,255,255,0.9);
    margin-bottom: 12px;
}

.report-header-left .project-link a {
    color: white;
    text-decoration: none;
}

.report-header-left .project-link a:hover {
    text-decoration: underline;
}

.report-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.report-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255,255,255,0.2);
    color: white;
}

.report-header-right { text-align: right; }

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted { color: #2563eb; }
.status-reviewing { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-returned { color: #ea580c; }
.status-rejected { color: #dc2626; }

/* Content Layout */
.report-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.report-main { display: flex; flex-direction: column; gap: 24px; }
.report-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: #064e1a; }

.section-body { padding: 20px; }

/* Detail Grid */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.6;
    white-space: pre-wrap;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

/* Prevent layout break from long text */
.section-card {
    min-width: 0;
    overflow: hidden;
}

.section-body {
    overflow-wrap: break-word;
    word-break: break-word;
}

.report-main, .report-sidebar {
    min-width: 0;
}

/* Completion Progress */
.completion-display {
    background: #f9fafb;
    padding: 20px;
    border-radius: 12px;
    text-align: center;
}

.completion-percentage {
    font-size: 48px;
    font-weight: 700;
    color: <?= $progressColor ?>;
    line-height: 1;
    margin-bottom: 8px;
}

.completion-label {
    font-size: 13px;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.completion-bar {
    height: 12px;
    background: #e5e7eb;
    border-radius: 6px;
    overflow: hidden;
    margin-top: 16px;
}

.completion-bar .fill {
    height: 100%;
    background: linear-gradient(135deg, #064e1a 0%, <?= $progressColor ?> 100%);
    border-radius: 6px;
    transition: width 0.3s ease;
}

/* Track Status */
.track-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
}

.track-badge.on-track { background: #d1fae5; color: #065f46; }
.track-badge.off-track { background: #fee2e2; color: #991b1b; }

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.btn-accept { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-accept:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-return { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.btn-return:hover { background: #fde68a; }

/* Info List */
.info-list { display: flex; flex-direction: column; gap: 12px; }
.info-item { display: flex; flex-direction: column; gap: 2px; }
.info-label { font-size: 11px; color: #6b7280; text-transform: uppercase; }
.info-value { font-size: 14px; color: #1f2937; font-weight: 500; }

.researcher-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    background: #dbeafe;
    color: #1e40af;
}

/* Review Section */
.review-card {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
    border: 1px solid #93c5fd;
}

.review-card .section-header {
    background: transparent;
    border-bottom-color: rgba(59, 130, 246, 0.3);
}

.review-card .section-header h3 i { color: #2563eb !important; }

.return-card {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 1px solid #fbbf24;
}

.return-card .section-header {
    background: transparent;
    border-bottom-color: rgba(245, 158, 11, 0.3);
}

.return-card .section-header h3 i { color: #d97706 !important; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 { font-size: 18px; color: #1f2937; margin: 0; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #6b7280; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e5e7eb; display: flex; justify-content: flex-end; gap: 12px; }

/* Modal Buttons */
.modal-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600;
    cursor: pointer; border: none; transition: all 0.2s ease;
}
.modal-btn i { font-size: 13px; }
.modal-btn-secondary { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; }
.modal-btn-secondary:hover { background: #e5e7eb; border-color: #9ca3af; }
.modal-btn-warning {
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%); color: white;
    box-shadow: 0 2px 8px rgba(217, 119, 6, 0.3);
}
.modal-btn-warning:hover {
    background: linear-gradient(135deg, #b45309 0%, #d97706 100%);
    transform: translateY(-1px); box-shadow: 0 4px 12px rgba(217, 119, 6, 0.4);
}

.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    min-height: 100px;
    resize: vertical;
}

/* Responsive */
@media (max-width: 1024px) {
    .report-content { grid-template-columns: 1fr; }
    .report-sidebar { order: -1; }
}

@media (max-width: 768px) {
    .report-header-content { flex-direction: column; }
    .report-header-right { text-align: left; }
    .detail-grid { grid-template-columns: 1fr; }
}
</style>

<div class="content">
    <!-- Header Banner -->
    <div class="report-header-banner">
        <div class="report-header-content">
            <div class="report-header-left">
                <div class="project-link">
                    <i class="fa fa-folder"></i>
                    <a href="project_view.php?id=<?= $report['project_id'] ?>" 
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $report['project_id'] ?>',true)}">
                        <?= s($project['title']) ?>
                    </a>
                    <?php if (!empty($project['project_code'])): ?>
                        <span style="opacity: 0.7;">(<?= s($project['project_code']) ?>)</span>
                    <?php endif; ?>
                </div>
                <h1>
                    <i class="fa fa-chart-line"></i>
                    Progress Report
                </h1>
                <div class="report-header-badges">
                    <span class="report-badge">
                        <i class="fa fa-calendar-alt"></i>
                        <?= date('M d', strtotime($report['period_start_date'])) ?> - <?= date('M d, Y', strtotime($report['period_end_date'])) ?>
                    </span>
                    <span class="report-badge">
                        <i class="fa fa-percentage"></i>
                        <?= $completion ?>% Complete
                    </span>
                </div>
            </div>
            <div class="report-header-right">
                <span class="status-badge-large <?= $currentStatus['class'] ?>">
                    <i class="fa <?= $currentStatus['icon'] ?>"></i>
                    <?= $currentStatus['label'] ?>
                </span>
            </div>
        </div>
    </div>

    <div class="report-content">
        <!-- Main Content -->
        <div class="report-main">
            <!-- Report Period -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-calendar"></i> Report Period</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Start Date</span>
                            <span class="detail-value"><?= date('F d, Y', strtotime($report['period_start_date'])) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">End Date</span>
                            <span class="detail-value"><?= date('F d, Y', strtotime($report['period_end_date'])) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Progress Status -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-tasks"></i> Progress Status</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <div class="completion-display">
                                <div class="completion-percentage"><?= $completion ?>%</div>
                                <div class="completion-label">Completion Rate</div>
                                <div class="completion-bar">
                                    <div class="fill" style="width: <?= $completion ?>%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Project Track Status</span>
                            <span class="detail-value">
                                <span class="track-badge <?= $isOnTrack ? 'on-track' : 'off-track' ?>">
                                    <i class="fa <?= $isOnTrack ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i>
                                    <?= $isOnTrack ? 'On Track' : 'Off Track' ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Activities Conducted -->
            <?php if (!empty($report['activities_conducted'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clipboard-check"></i> Activities Conducted</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($report['activities_conducted'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Accomplishments -->
            <?php if (!empty($report['accomplishments'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-trophy"></i> Accomplishments</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($report['accomplishments'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Challenges Encountered -->
            <?php if (!empty($report['challenges_encountered'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-exclamation-circle"></i> Challenges Encountered</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($report['challenges_encountered'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Next Period Plans -->
            <?php if (!empty($report['next_period_plans'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-arrow-right"></i> Next Period Plans</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($report['next_period_plans'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Review Information -->
            <?php if ($report['status'] === 'accepted' && $report['reviewed_by']): ?>
            <div class="section-card review-card">
                <div class="section-header">
                    <h3><i class="fa fa-check-circle"></i> Review Information</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Reviewed By</span>
                            <span class="detail-value"><?= s($reviewerName) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Reviewed On</span>
                            <span class="detail-value"><?= $report['reviewed_at'] ? date('M d, Y \a\t g:i A', strtotime($report['reviewed_at'])) : 'N/A' ?></span>
                        </div>
                        <?php if (!empty($report['reviewer_comments'])): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Comments</span>
                            <span class="detail-value"><?= nl2br(s($report['reviewer_comments'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php elseif ($report['status'] === 'returned'): ?>
            <div class="section-card return-card">
                <div class="section-header">
                    <h3><i class="fa fa-undo"></i> Returned for Revision</h3>
                </div>
                <div class="section-body">
                    <?php if ($reviewerName): ?>
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Returned By</span>
                            <span class="detail-value"><?= s($reviewerName) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Returned On</span>
                            <span class="detail-value"><?= $report['reviewed_at'] ? date('M d, Y \a\t g:i A', strtotime($report['reviewed_at'])) : 'N/A' ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($report['reviewer_comments'])): ?>
                    <div style="margin-top: 16px;">
                        <span class="detail-label">Reason</span>
                        <div class="detail-value" style="margin-top: 4px;"><?= nl2br(s($report['reviewer_comments'])) ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="report-sidebar">
            <!-- Actions -->
            <?php 
            // Coordinator can act on submitted/under_coordinator_review/reviewed status
            $coordinatorCanAct = $isCoordinator && in_array($report['status'], ['submitted', 'under_coordinator_review', 'reviewed']);
            // Admin can act on endorsed/under_ro_review status
            $adminCanAct = $isAdmin && in_array($report['status'], ['endorsed', 'under_ro_review']);
            ?>
            <?php if ($coordinatorCanAct || $adminCanAct): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if ($coordinatorCanAct): ?>
                            <!-- Coordinator Actions -->
                            <button onclick="endorseReport()" class="action-btn btn-accept">
                                <i class="fa fa-check"></i> Endorse to Research Office
                            </button>
                            <button onclick="showReturnModal()" class="action-btn btn-return">
                                <i class="fa fa-undo"></i> Return for Revision
                            </button>
                        <?php elseif ($adminCanAct): ?>
                            <!-- Research Office Actions -->
                            <button onclick="approveReport()" class="action-btn btn-accept">
                                <i class="fa fa-check"></i> Approve Report
                            </button>
                            <button onclick="rejectReport()" class="action-btn btn-reject" style="background: #fee2e2; color: #991b1b; border: 1px solid #fecaca;">
                                <i class="fa fa-times"></i> Reject Report
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Submitter Info -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-user"></i> Submitter</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Researcher Type</span>
                            <span class="researcher-badge"><?= strtoupper($project['researcher_type'] ?? 'FACULTY') ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Submitted By</span>
                            <span class="info-value"><?= s($submitterName) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Created</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($report['created_at'])) ?></span>
                        </div>
                        <?php if (!empty($report['submitted_at'])): ?>
                        <div class="info-item">
                            <span class="info-label">Submitted</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($report['submitted_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($report['reviewed_at'])): ?>
                        <div class="info-item">
                            <span class="info-label">Reviewed</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($report['reviewed_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Back Button -->
            <div class="section-card">
                <div class="section-body" style="padding: 12px 20px;">
                    <?php if ($isCoordinator || $isAdmin): ?>
                    <a href="work_queue.php" class="action-btn" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('work_queue.php',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Work Queue
                    </a>
                    <?php else: ?>
                    <a href="project_view.php?id=<?= $report['project_id'] ?>&tab=reports" class="action-btn" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $report['project_id'] ?>&tab=reports',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Project
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Return Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-undo"></i> Return for Revision</h3>
            <button class="modal-close" onclick="closeReturnModal()">&times;</button>
        </div>
        <form id="returnForm" method="POST" onsubmit="return false;">
            <div class="modal-body">
                <div class="form-group">
                    <label>Comments / Reason for Return</label>
                    <textarea name="comments" required placeholder="Explain what needs to be revised..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeReturnModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-warning">
                    <i class="fa fa-undo"></i> Return Report
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const reportId = <?= $reportId ?>;
const isAdminUser = <?= $isAdmin ? 'true' : 'false' ?>;
const currentStatus = '<?= $report['status'] ?>';

// Coordinator: Endorse report to Research Office
function endorseReport() {
    if (!confirm('Endorse this progress report to the Research Office?')) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'endorse_progress_report',
            report_id: reportId,
            remarks: ''
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Progress report endorsed successfully!');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to endorse'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

// Research Office: Approve report
function approveReport() {
    if (!confirm('Approve this progress report?')) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'approve_progress_report',
            report_id: reportId,
            comments: ''
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Progress report approved!');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to approve'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

// Research Office: Reject report
function rejectReport() {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'reject_progress_report',
            report_id: reportId,
            reason: reason
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Progress report rejected.');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to reject'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

function showReturnModal() {
    document.getElementById('returnModal').classList.add('active');
}

function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('active');
}

document.getElementById('returnForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const comments = this.comments.value;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'return_progress_report',
            report_id: reportId,
            reason: comments
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Progress report returned for revision.');
            closeReturnModal();
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to return'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
});
</script>
