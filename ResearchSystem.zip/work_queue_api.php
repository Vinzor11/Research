<?php
/**
 * work_queue_api.php
 * 
 * Unified Work Queue API
 * 
 * Handles all Work Queue operations including:
 * - Fetching queue items and statistics
 * - Workflow actions: start_review, endorse, return, approve, reject
 * - Audit logging
 * 
 * AUTHORIZATION:
 * - Coordinators: Can start review, endorse, return for revision
 * - Research Office (Admin): Can approve, reject, return to coordinator
 * 
 * CORE RULE: "Only submitted, decision-requiring requests appear in the Work Queue;
 * coordinators endorse, the Research Office approves, and all actions are audit-logged."
 * 
 * @version 2.0
 * @date 2026-02-06
 */

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'UnifiedQueueService.php';
require_once 'ProjectService.php';
require_once 'CollaborationService.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Only coordinators and admins can access the work queue
$userRole = $_SESSION['user_role'] ?? 'researcher';
if (!in_array($userRole, ['coordinator', 'admin'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Access denied - Work Queue requires coordinator or admin role']);
    exit;
}

$userId = $_SESSION['user_id'];
$employeeId = $_SESSION['employee_id'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';

$queueService = new UnifiedQueueService($conn, $userId);
$projectService = new ProjectService($conn);

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        handleGetRequest($queueService);
    } elseif ($method === 'POST') {
        handlePostRequest($conn, $queueService, $projectService, $userRole, $userId, $employeeId, $fullname);
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    error_log("work_queue_api error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}

/**
 * Handle GET requests
 */
function handleGetRequest($queueService) {
    $action = $_GET['action'] ?? 'get_items';
    
    switch ($action) {
        case 'get_items':
            // Build filters from query parameters
            $filters = [
                'type' => $_GET['type'] ?? null,
                'status' => $_GET['status'] ?? null,
                'search' => $_GET['q'] ?? null,
                'date_from' => $_GET['date_from'] ?? null,
                'date_to' => $_GET['date_to'] ?? null,
                'unit' => $_GET['unit'] ?? null
            ];
            
            // Remove null values
            $filters = array_filter($filters, function($v) { return $v !== null && $v !== ''; });
            
            $page = max(1, (int)($_GET['page'] ?? 1));
            $perPage = min(50, max(10, (int)($_GET['per_page'] ?? 20)));
            
            $result = $queueService->getQueueItems($filters, $page, $perPage);
            
            echo json_encode([
                'success' => true,
                'data' => $result['data'],
                'pagination' => $result['pagination'],
                'filters' => $filters
            ]);
            break;
            
        case 'get_stats':
            $stats = $queueService->getQueueStats();
            echo json_encode([
                'success' => true,
                'stats' => $stats
            ]);
            break;
            
        case 'get_item':
            // Get details of a single queue item
            $itemType = $_GET['item_type'] ?? '';
            $sourceId = (int)($_GET['source_id'] ?? 0);
            
            if (!$itemType || !$sourceId) {
                echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
                return;
            }
            
            // Delegate to appropriate service based on item type
            $item = getQueueItemDetails($itemType, $sourceId);
            if ($item) {
                echo json_encode(['success' => true, 'data' => $item]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Item not found']);
            }
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
    }
}

/**
 * Handle POST requests (workflow actions)
 */
function handlePostRequest($conn, $queueService, $projectService, $userRole, $userId, $employeeId, $fullname) {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    
    $action = $input['action'] ?? '';
    
    switch ($action) {
        // ========================================
        // COORDINATOR ACTIONS
        // ========================================
        
        case 'start_review':
            // Coordinator starts reviewing an item (submitted → under_coordinator_review)
            handleStartReview($conn, $queueService, $input, $userRole, $userId);
            break;
            
        case 'endorse':
            // Coordinator endorses and forwards to Research Office
            handleEndorse($conn, $queueService, $projectService, $input, $userRole, $userId, $employeeId);
            break;
            
        case 'return_for_revision':
            // Coordinator returns item to researcher for revision
            handleReturnForRevision($conn, $queueService, $projectService, $input, $userRole, $userId);
            break;
            
        // ========================================
        // RESEARCH OFFICE ACTIONS
        // ========================================
        
        case 'start_ro_review':
            // RO starts reviewing an endorsed item (endorsed → under_ro_review)
            handleStartROReview($conn, $queueService, $input, $userRole, $userId);
            break;
            
        case 'approve':
            // RO approves the request (FINAL decision)
            handleApprove($conn, $queueService, $projectService, $input, $userRole, $userId);
            break;
            
        case 'reject':
            // RO rejects the request (FINAL decision)
            handleReject($conn, $queueService, $projectService, $input, $userRole, $userId);
            break;
            
        case 'return_to_coordinator':
            // RO returns item back to coordinator for re-evaluation
            handleReturnToCoordinator($conn, $queueService, $input, $userRole, $userId);
            break;
            
        // ========================================
        // AUDIT / LOGGING
        // ========================================
        
        case 'log_action':
            // Log a queue action for audit
            $itemType = $input['item_type'] ?? '';
            $sourceId = $input['source_id'] ?? 0;
            $actionType = $input['action_type'] ?? '';
            $previousStatus = $input['previous_status'] ?? '';
            $newStatus = $input['new_status'] ?? '';
            $remarks = $input['remarks'] ?? null;
            
            if (!$itemType || !$sourceId || !$actionType) {
                echo json_encode(['success' => false, 'error' => 'Missing required fields']);
                return;
            }
            
            $queueService->logQueueAction($itemType, $sourceId, $actionType, $previousStatus, $newStatus, $remarks);
            echo json_encode(['success' => true, 'message' => 'Action logged']);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
    }
}

/**
 * Get queue item details based on type
 */
function getQueueItemDetails($itemType, $sourceId) {
    global $conn, $projectService;
    
    switch ($itemType) {
        case 'proposal':
            $stmt = $conn->prepare("SELECT * FROM research_submissions WHERE id = ?");
            break;
        case 'progress':
            return $projectService->getProgressReport($sourceId);
        case 'extension':
            return $projectService->getExtensionRequest($sourceId);
        case 'completion':
            return $projectService->getCompletionReport($sourceId);
        case 'output':
            return $projectService->getOutput($sourceId);
        case 'collaboration':
            $collabService = new CollaborationService($conn);
            return $collabService->getCollaboration($sourceId);
        default:
            return null;
    }
    
    if (isset($stmt)) {
        $stmt->bind_param("i", $sourceId);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();
        return $data;
    }
    
    return null;
}

// ============================================================
// COORDINATOR ACTION HANDLERS
// ============================================================

/**
 * Handle start_review action (Coordinator)
 * Changes status: submitted → under_coordinator_review
 */
function handleStartReview($conn, $queueService, $input, $userRole, $userId) {
    if (!in_array($userRole, ['coordinator', 'admin'])) {
        echo json_encode(['success' => false, 'error' => 'Only coordinators can start review']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    // Get table and status column based on item type
    $tableInfo = getTableInfo($itemType);
    if (!$tableInfo) {
        echo json_encode(['success' => false, 'error' => 'Invalid item type']);
        return;
    }
    
    // Get current status
    $stmt = $conn->prepare("SELECT status FROM {$tableInfo['table']} WHERE id = ?");
    $stmt->bind_param("i", $sourceId);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();
    $stmt->close();
    
    if (!$item) {
        echo json_encode(['success' => false, 'error' => 'Item not found']);
        return;
    }
    
    if ($item['status'] !== 'submitted') {
        echo json_encode(['success' => false, 'error' => 'Can only start review on submitted items']);
        return;
    }
    
    // Update status
    $newStatus = 'under_coordinator_review';
    $stmt = $conn->prepare("UPDATE {$tableInfo['table']} SET status = ?, {$tableInfo['reviewer_column']} = ?, {$tableInfo['review_date_column']} = NOW() WHERE id = ?");
    $stmt->bind_param("sii", $newStatus, $userId, $sourceId);
    
    if ($stmt->execute()) {
        $queueService->logQueueAction($itemType, $sourceId, 'coordinator_review_started', 'submitted', $newStatus);
        echo json_encode(['success' => true, 'message' => 'Review started']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to start review']);
    }
    $stmt->close();
}

/**
 * Handle endorse action (Coordinator → Research Office)
 * Changes status: under_coordinator_review → endorsed
 */
function handleEndorse($conn, $queueService, $projectService, $input, $userRole, $userId, $employeeId) {
    if (!in_array($userRole, ['coordinator', 'admin'])) {
        echo json_encode(['success' => false, 'error' => 'Only coordinators can endorse']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    $validationData = $input['validation_data'] ?? [];
    $remarks = $input['remarks'] ?? null;
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    // Use ProjectService for project-related items, CollaborationService for collaborations
    $result = null;
    
    switch ($itemType) {
        case 'progress':
            $result = $projectService->endorseProgressReport($sourceId, $validationData, $remarks);
            break;
        case 'extension':
            $result = $projectService->endorseExtension($sourceId, $validationData, $remarks);
            break;
        case 'completion':
            $result = $projectService->endorseCompletionReport($sourceId, $validationData, $remarks);
            break;
        case 'output':
            $result = $projectService->endorseOutput($sourceId, $remarks);
            break;
        case 'collaboration':
            $collabService = new CollaborationService($conn);
            $result = $collabService->endorse($sourceId, $validationData);
            break;
        case 'proposal':
            // Use submission API for proposals
            require_once 'SubmissionService.php';
            $submissionService = new SubmissionService($conn);
            $result = $submissionService->endorse($sourceId, $remarks);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown item type for endorsement']);
            return;
    }
    
    if ($result) {
        if ($result['success']) {
            $queueService->logQueueAction($itemType, $sourceId, 'endorsed', 'under_coordinator_review', 'endorsed', $remarks, $validationData);
        }
        echo json_encode($result);
    } else {
        echo json_encode(['success' => false, 'error' => 'Endorsement handler not available']);
    }
}

/**
 * Handle return_for_revision action (Coordinator → Researcher)
 * Changes status: under_coordinator_review → returned_for_revision
 */
function handleReturnForRevision($conn, $queueService, $projectService, $input, $userRole, $userId) {
    if (!in_array($userRole, ['coordinator', 'admin'])) {
        echo json_encode(['success' => false, 'error' => 'Only coordinators can return for revision']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    if (empty($reason)) {
        echo json_encode(['success' => false, 'error' => 'Return reason is required']);
        return;
    }
    
    $result = null;
    
    switch ($itemType) {
        case 'progress':
            $result = $projectService->returnProgressReport($sourceId, $reason);
            break;
        case 'extension':
            $result = $projectService->returnExtensionForRevision($sourceId, $reason);
            break;
        case 'completion':
            $result = $projectService->returnCompletionReport($sourceId, $reason);
            break;
        case 'output':
            $result = $projectService->returnOutput($sourceId, $reason);
            break;
        case 'collaboration':
            $collabService = new CollaborationService($conn);
            $result = $collabService->returnForRevision($sourceId, $reason);
            break;
        case 'proposal':
            require_once 'SubmissionService.php';
            $submissionService = new SubmissionService($conn);
            $result = $submissionService->returnForRevision($sourceId, $reason);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown item type for return']);
            return;
    }
    
    if ($result) {
        if ($result['success']) {
            $queueService->logQueueAction($itemType, $sourceId, 'returned_for_revision', 'under_coordinator_review', 'returned_for_revision', $reason);
        }
        echo json_encode($result);
    } else {
        echo json_encode(['success' => false, 'error' => 'Return handler not available']);
    }
}

// ============================================================
// RESEARCH OFFICE ACTION HANDLERS
// ============================================================

/**
 * Handle start_ro_review action (Research Office)
 * Changes status: endorsed → under_ro_review
 */
function handleStartROReview($conn, $queueService, $input, $userRole, $userId) {
    if ($userRole !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Only Research Office can start RO review']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    $tableInfo = getTableInfo($itemType);
    if (!$tableInfo) {
        echo json_encode(['success' => false, 'error' => 'Invalid item type']);
        return;
    }
    
    // Get current status
    $stmt = $conn->prepare("SELECT status FROM {$tableInfo['table']} WHERE id = ?");
    $stmt->bind_param("i", $sourceId);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();
    $stmt->close();
    
    if (!$item) {
        echo json_encode(['success' => false, 'error' => 'Item not found']);
        return;
    }
    
    if ($item['status'] !== 'endorsed') {
        echo json_encode(['success' => false, 'error' => 'Can only start RO review on endorsed items']);
        return;
    }
    
    // Update status
    $newStatus = 'under_ro_review';
    $roColumn = $tableInfo['ro_reviewer_column'] ?? 'ro_reviewed_by';
    $roDateColumn = $tableInfo['ro_review_date_column'] ?? 'ro_received_at';
    
    $stmt = $conn->prepare("UPDATE {$tableInfo['table']} SET status = ?, $roColumn = ?, $roDateColumn = NOW() WHERE id = ?");
    $stmt->bind_param("sii", $newStatus, $userId, $sourceId);
    
    if ($stmt->execute()) {
        $queueService->logQueueAction($itemType, $sourceId, 'ro_review_started', 'endorsed', $newStatus);
        echo json_encode(['success' => true, 'message' => 'RO review started']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to start RO review']);
    }
    $stmt->close();
}

/**
 * Handle approve action (Research Office - FINAL)
 * Changes status: under_ro_review → approved
 */
function handleApprove($conn, $queueService, $projectService, $input, $userRole, $userId) {
    if ($userRole !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Only Research Office can approve']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    $remarks = $input['remarks'] ?? null;
    $approvalData = $input['approval_data'] ?? [];
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    $result = null;
    
    switch ($itemType) {
        case 'progress':
            $result = $projectService->approveProgressReport($sourceId, $remarks);
            break;
        case 'extension':
            $result = $projectService->approveExtensionRequest($sourceId, $approvalData, $remarks);
            break;
        case 'completion':
            $result = $projectService->approveCompletionReport($sourceId, $remarks);
            break;
        case 'output':
            $result = $projectService->verifyOutput($sourceId, $remarks);
            break;
        case 'collaboration':
            $collabService = new CollaborationService($conn);
            $result = $collabService->approve($sourceId, $remarks);
            break;
        case 'proposal':
            require_once 'WorkflowEngine.php';
            $workflowEngine = new WorkflowEngine($conn);
            $result = $workflowEngine->approve($sourceId, $remarks);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown item type for approval']);
            return;
    }
    
    if ($result) {
        if ($result['success']) {
            $queueService->logQueueAction($itemType, $sourceId, 'approved', 'under_ro_review', 'approved', $remarks);
        }
        echo json_encode($result);
    } else {
        echo json_encode(['success' => false, 'error' => 'Approval handler not available']);
    }
}

/**
 * Handle reject action (Research Office - FINAL)
 * Changes status: under_ro_review → rejected
 */
function handleReject($conn, $queueService, $projectService, $input, $userRole, $userId) {
    if ($userRole !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Only Research Office can reject']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    if (empty($reason)) {
        echo json_encode(['success' => false, 'error' => 'Rejection reason is required']);
        return;
    }
    
    $result = null;
    
    switch ($itemType) {
        case 'progress':
            $result = $projectService->rejectProgressReport($sourceId, $reason);
            break;
        case 'extension':
            $result = $projectService->rejectExtensionRequest($sourceId, $reason);
            break;
        case 'completion':
            $result = $projectService->rejectCompletionReport($sourceId, $reason);
            break;
        case 'output':
            $result = $projectService->rejectOutput($sourceId, $reason);
            break;
        case 'collaboration':
            $collabService = new CollaborationService($conn);
            $result = $collabService->reject($sourceId, $reason);
            break;
        case 'proposal':
            require_once 'WorkflowEngine.php';
            $workflowEngine = new WorkflowEngine($conn);
            $result = $workflowEngine->reject($sourceId, $reason);
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown item type for rejection']);
            return;
    }
    
    if ($result) {
        if ($result['success']) {
            $queueService->logQueueAction($itemType, $sourceId, 'rejected', 'under_ro_review', 'rejected', $reason);
        }
        echo json_encode($result);
    } else {
        echo json_encode(['success' => false, 'error' => 'Rejection handler not available']);
    }
}

/**
 * Handle return_to_coordinator action (Research Office → Coordinator)
 * Changes status: under_ro_review → endorsed
 */
function handleReturnToCoordinator($conn, $queueService, $input, $userRole, $userId) {
    if ($userRole !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Only Research Office can return to coordinator']);
        return;
    }
    
    $itemType = $input['item_type'] ?? '';
    $sourceId = (int)($input['source_id'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if (!$itemType || !$sourceId) {
        echo json_encode(['success' => false, 'error' => 'Item type and source ID required']);
        return;
    }
    
    if (empty($reason)) {
        echo json_encode(['success' => false, 'error' => 'Return reason is required']);
        return;
    }
    
    $tableInfo = getTableInfo($itemType);
    if (!$tableInfo) {
        echo json_encode(['success' => false, 'error' => 'Invalid item type']);
        return;
    }
    
    // Update status back to endorsed (coordinator needs to re-evaluate)
    $newStatus = 'endorsed';
    $stmt = $conn->prepare("UPDATE {$tableInfo['table']} SET status = ?, ro_remarks = ? WHERE id = ?");
    $stmt->bind_param("ssi", $newStatus, $reason, $sourceId);
    
    if ($stmt->execute()) {
        $queueService->logQueueAction($itemType, $sourceId, 'returned_to_coordinator', 'under_ro_review', $newStatus, $reason);
        echo json_encode(['success' => true, 'message' => 'Returned to coordinator for re-evaluation']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to return to coordinator']);
    }
    $stmt->close();
}

/**
 * Get table information for item type
 */
function getTableInfo($itemType) {
    $tables = [
        'proposal' => [
            'table' => 'research_submissions',
            'reviewer_column' => 'current_handler_id',
            'review_date_column' => 'updated_at',
            'ro_reviewer_column' => 'ro_admin_id',
            'ro_review_date_column' => 'decision_at'
        ],
        'progress' => [
            'table' => 'project_progress_reports',
            'reviewer_column' => 'coordinator_reviewed_by',
            'review_date_column' => 'coordinator_reviewed_at',
            'ro_reviewer_column' => 'ro_reviewed_by',
            'ro_review_date_column' => 'ro_reviewed_at'
        ],
        'extension' => [
            'table' => 'project_extensions',
            'reviewer_column' => 'coordinator_reviewed_by',
            'review_date_column' => 'coordinator_reviewed_at',
            'ro_reviewer_column' => 'ro_reviewed_by',
            'ro_review_date_column' => 'ro_reviewed_at'
        ],
        'completion' => [
            'table' => 'project_completion_reports',
            'reviewer_column' => 'coordinator_reviewed_by',
            'review_date_column' => 'coordinator_reviewed_at',
            'ro_reviewer_column' => 'ro_reviewed_by',
            'ro_review_date_column' => 'ro_reviewed_at'
        ],
        'output' => [
            'table' => 'project_outputs',
            'reviewer_column' => 'coordinator_verified_by',
            'review_date_column' => 'coordinator_verified_at',
            'ro_reviewer_column' => 'verified_by',
            'ro_review_date_column' => 'verified_at'
        ],
        'collaboration' => [
            'table' => 'project_collaborations',
            'reviewer_column' => 'assigned_coordinator_id',
            'review_date_column' => 'coordinator_received_at',
            'ro_reviewer_column' => 'assigned_ro_admin_id',
            'ro_review_date_column' => 'ro_received_at'
        ]
    ];
    
    return $tables[$itemType] ?? null;
}
