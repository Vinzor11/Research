<?php
/**
 * WorkflowAuditLogger.php
 * Immutable audit logging for the research workflow system
 * 
 * All workflow events are logged with:
 * - Status changes (old → new)
 * - Actor (user ID, role)
 * - Timestamp
 * - Comments and return reasons
 * 
 * CRITICAL: Audit logs must be immutable - no updates or deletes allowed
 * 
 * @version 1.0
 */

class WorkflowAuditLogger {
    private $conn;
    private $userId;
    private $userRole;
    private $userName;
    
    /**
     * Constructor
     */
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? 'unknown';
        $this->userName = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'Unknown User';
    }
    
    /**
     * Log a workflow event
     * 
     * @param int $submissionId - ID of the submission
     * @param string $actionType - Type of action performed
     * @param array $data - Additional data for the log entry
     * @return bool - True if logged successfully
     */
    public function log($submissionId, $actionType, array $data = []) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO workflow_history (
                    submission_id,
                    action_type,
                    previous_status,
                    new_status,
                    performed_by,
                    performed_by_role,
                    performed_by_name,
                    target_user_id,
                    target_role,
                    comments,
                    return_reason,
                    metadata,
                    ip_address,
                    user_agent
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            if (!$stmt) {
                error_log("WorkflowAuditLogger: Failed to prepare statement - " . $this->conn->error);
                return false;
            }
            
            $performedBy = $data['performed_by'] ?? $this->userId;
            $performedByRole = $data['performed_by_role'] ?? $this->userRole;
            $performedByName = $data['performed_by_name'] ?? $this->userName;
            $previousStatus = $data['previous_status'] ?? null;
            $newStatus = $data['new_status'] ?? null;
            $targetUserId = $data['target_user_id'] ?? null;
            $targetRole = $data['target_role'] ?? null;
            $comments = $data['comments'] ?? null;
            $returnReason = $data['return_reason'] ?? null;
            $metadata = isset($data['metadata']) ? json_encode($data['metadata']) : null;
            $ipAddress = $this->getClientIP();
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
            
            $stmt->bind_param(
                "issssissssssss",
                $submissionId,
                $actionType,
                $previousStatus,
                $newStatus,
                $performedBy,
                $performedByRole,
                $performedByName,
                $targetUserId,
                $targetRole,
                $comments,
                $returnReason,
                $metadata,
                $ipAddress,
                $userAgent
            );
            
            $result = $stmt->execute();
            
            if (!$result) {
                error_log("WorkflowAuditLogger: Failed to log event - " . $stmt->error);
            }
            
            $stmt->close();
            return $result;
            
        } catch (Exception $e) {
            error_log("WorkflowAuditLogger: Exception - " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get complete workflow history for a submission
     * 
     * @param int $submissionId
     * @return array
     */
    public function getHistory($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT 
                wh.*,
                COALESCE(wh.performed_by_name, u.fullname, u.username) as actor_name
            FROM workflow_history wh
            LEFT JOIN users u ON wh.performed_by = u.id
            WHERE wh.submission_id = ?
            ORDER BY wh.created_at DESC
        ");
        
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Decode metadata for each entry
        foreach ($result as &$entry) {
            if (!empty($entry['metadata'])) {
                $entry['metadata'] = json_decode($entry['metadata'], true);
            }
        }
        
        return $result;
    }
    
    /**
     * Get history filtered by action type
     * 
     * @param int $submissionId
     * @param string|array $actionTypes
     * @return array
     */
    public function getHistoryByType($submissionId, $actionTypes) {
        if (!is_array($actionTypes)) {
            $actionTypes = [$actionTypes];
        }
        
        $placeholders = implode(',', array_fill(0, count($actionTypes), '?'));
        
        $sql = "
            SELECT 
                wh.*,
                COALESCE(wh.performed_by_name, u.fullname, u.username) as actor_name
            FROM workflow_history wh
            LEFT JOIN users u ON wh.performed_by = u.id
            WHERE wh.submission_id = ?
            AND wh.action_type IN ($placeholders)
            ORDER BY wh.created_at DESC
        ";
        
        $stmt = $this->conn->prepare($sql);
        
        $types = 'i' . str_repeat('s', count($actionTypes));
        $params = array_merge([$submissionId], $actionTypes);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get the last action of a specific type
     * 
     * @param int $submissionId
     * @param string $actionType
     * @return array|null
     */
    public function getLastAction($submissionId, $actionType) {
        $stmt = $this->conn->prepare("
            SELECT 
                wh.*,
                COALESCE(wh.performed_by_name, u.fullname, u.username) as actor_name
            FROM workflow_history wh
            LEFT JOIN users u ON wh.performed_by = u.id
            WHERE wh.submission_id = ?
            AND wh.action_type = ?
            ORDER BY wh.created_at DESC
            LIMIT 1
        ");
        
        $stmt->bind_param("is", $submissionId, $actionType);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result && !empty($result['metadata'])) {
            $result['metadata'] = json_decode($result['metadata'], true);
        }
        
        return $result;
    }
    
    /**
     * Get status change history
     * 
     * @param int $submissionId
     * @return array
     */
    public function getStatusChanges($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT 
                wh.id,
                wh.previous_status,
                wh.new_status,
                wh.action_type,
                wh.performed_by,
                COALESCE(wh.performed_by_name, u.fullname, u.username) as actor_name,
                wh.performed_by_role,
                wh.comments,
                wh.return_reason,
                wh.created_at
            FROM workflow_history wh
            LEFT JOIN users u ON wh.performed_by = u.id
            WHERE wh.submission_id = ?
            AND wh.new_status IS NOT NULL
            ORDER BY wh.created_at ASC
        ");
        
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get all return/revision history
     * 
     * @param int $submissionId
     * @return array
     */
    public function getRevisionHistory($submissionId) {
        return $this->getHistoryByType($submissionId, [
            'returned_for_revision',
            'revision_submitted',
            'returned_to_coordinator'
        ]);
    }
    
    /**
     * Get recent activity across all submissions
     * For dashboard/reporting purposes
     * 
     * @param int $limit
     * @param array $filters - Optional filters: action_types, user_id, status
     * @return array
     */
    public function getRecentActivity($limit = 50, array $filters = []) {
        $where = [];
        $params = [];
        $types = '';
        
        if (!empty($filters['action_types'])) {
            $placeholders = implode(',', array_fill(0, count($filters['action_types']), '?'));
            $where[] = "wh.action_type IN ($placeholders)";
            $params = array_merge($params, $filters['action_types']);
            $types .= str_repeat('s', count($filters['action_types']));
        }
        
        if (!empty($filters['user_id'])) {
            $where[] = "wh.performed_by = ?";
            $params[] = $filters['user_id'];
            $types .= 'i';
        }
        
        if (!empty($filters['new_status'])) {
            $where[] = "wh.new_status = ?";
            $params[] = $filters['new_status'];
            $types .= 's';
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "wh.created_at >= ?";
            $params[] = $filters['date_from'];
            $types .= 's';
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "wh.created_at <= ?";
            $params[] = $filters['date_to'];
            $types .= 's';
        }
        
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $sql = "
            SELECT 
                wh.*,
                rs.title as submission_title,
                rs.reference_number,
                rs.researcher_type,
                COALESCE(wh.performed_by_name, u.fullname, u.username) as actor_name
            FROM workflow_history wh
            JOIN research_submissions rs ON wh.submission_id = rs.id
            LEFT JOIN users u ON wh.performed_by = u.id
            $whereClause
            ORDER BY wh.created_at DESC
            LIMIT ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        
        $params[] = $limit;
        $types .= 'i';
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get activity statistics
     * 
     * @param string $period - 'day', 'week', 'month', 'year'
     * @return array
     */
    public function getActivityStats($period = 'month') {
        $dateFormat = '%Y-%m-%d';
        $interval = '30 DAY';
        
        switch ($period) {
            case 'day':
                $dateFormat = '%Y-%m-%d %H:00';
                $interval = '1 DAY';
                break;
            case 'week':
                $dateFormat = '%Y-%m-%d';
                $interval = '7 DAY';
                break;
            case 'year':
                $dateFormat = '%Y-%m';
                $interval = '365 DAY';
                break;
        }
        
        // Actions by type
        $stmt = $this->conn->prepare("
            SELECT action_type, COUNT(*) as count
            FROM workflow_history
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL $interval)
            GROUP BY action_type
            ORDER BY count DESC
        ");
        $stmt->execute();
        $byType = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Actions by user
        $stmt = $this->conn->prepare("
            SELECT 
                performed_by,
                COALESCE(performed_by_name, 'Unknown') as user_name,
                performed_by_role,
                COUNT(*) as count
            FROM workflow_history
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL $interval)
            GROUP BY performed_by, performed_by_name, performed_by_role
            ORDER BY count DESC
            LIMIT 10
        ");
        $stmt->execute();
        $byUser = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Timeline
        $stmt = $this->conn->prepare("
            SELECT 
                DATE_FORMAT(created_at, '$dateFormat') as period,
                COUNT(*) as count
            FROM workflow_history
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL $interval)
            GROUP BY period
            ORDER BY period ASC
        ");
        $stmt->execute();
        $timeline = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Decisions (approvals/rejections)
        $stmt = $this->conn->prepare("
            SELECT 
                action_type,
                COUNT(*) as count
            FROM workflow_history
            WHERE action_type IN ('approved', 'rejected')
            AND created_at >= DATE_SUB(NOW(), INTERVAL $interval)
            GROUP BY action_type
        ");
        $stmt->execute();
        $decisions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return [
            'by_type' => $byType,
            'by_user' => $byUser,
            'timeline' => $timeline,
            'decisions' => $decisions
        ];
    }
    
    /**
     * Generate audit report for a submission
     * 
     * @param int $submissionId
     * @return array
     */
    public function generateAuditReport($submissionId) {
        $history = $this->getHistory($submissionId);
        
        $report = [
            'submission_id' => $submissionId,
            'generated_at' => date('Y-m-d H:i:s'),
            'total_events' => count($history),
            'timeline' => [],
            'summary' => [
                'times_returned' => 0,
                'times_revised' => 0,
                'total_review_time' => null,
                'coordinator_review_time' => null,
                'ro_review_time' => null
            ]
        ];
        
        $submittedAt = null;
        $coordinatorStarted = null;
        $coordinatorEnded = null;
        $roStarted = null;
        $roEnded = null;
        
        foreach ($history as $event) {
            $report['timeline'][] = [
                'timestamp' => $event['created_at'],
                'action' => $this->getActionLabel($event['action_type']),
                'actor' => $event['actor_name'],
                'role' => $event['performed_by_role'],
                'status_change' => $event['previous_status'] 
                    ? "{$event['previous_status']} → {$event['new_status']}"
                    : null,
                'notes' => $event['comments'] ?: $event['return_reason']
            ];
            
            // Track metrics
            switch ($event['action_type']) {
                case 'returned_for_revision':
                case 'returned_to_coordinator':
                    $report['summary']['times_returned']++;
                    break;
                case 'revision_submitted':
                    $report['summary']['times_revised']++;
                    break;
                case 'submitted':
                    $submittedAt = $submittedAt ?? strtotime($event['created_at']);
                    break;
                case 'coordinator_review_started':
                    $coordinatorStarted = strtotime($event['created_at']);
                    break;
                case 'endorsed':
                    $coordinatorEnded = strtotime($event['created_at']);
                    break;
                case 'ro_review_started':
                    $roStarted = strtotime($event['created_at']);
                    break;
                case 'approved':
                case 'rejected':
                    $roEnded = strtotime($event['created_at']);
                    break;
            }
        }
        
        // Calculate review times
        if ($coordinatorStarted && $coordinatorEnded) {
            $report['summary']['coordinator_review_time'] = $this->formatDuration($coordinatorEnded - $coordinatorStarted);
        }
        if ($roStarted && $roEnded) {
            $report['summary']['ro_review_time'] = $this->formatDuration($roEnded - $roStarted);
        }
        if ($submittedAt && $roEnded) {
            $report['summary']['total_review_time'] = $this->formatDuration($roEnded - $submittedAt);
        }
        
        return $report;
    }
    
    /**
     * Get human-readable action label
     */
    private function getActionLabel($actionType) {
        $labels = [
            'created' => 'Submission Created',
            'submitted' => 'Submitted to Coordinator',
            'assigned_coordinator' => 'Coordinator Assigned',
            'coordinator_review_started' => 'Coordinator Started Review',
            'validated' => 'Validation Completed',
            'returned_for_revision' => 'Returned for Revision',
            'revision_submitted' => 'Revision Submitted',
            'endorsed' => 'Endorsed to Research Office',
            'assigned_ro_admin' => 'Research Office Admin Assigned',
            'ro_review_started' => 'Research Office Started Review',
            'classification_assigned' => 'Classification Assigned',
            'approved' => 'Approved',
            'rejected' => 'Rejected',
            'returned_to_coordinator' => 'Returned to Coordinator',
            'reference_assigned' => 'Reference Number Assigned',
            'comment_added' => 'Comment Added',
            'attachment_added' => 'Attachment Added',
            'attachment_removed' => 'Attachment Removed'
        ];
        
        return $labels[$actionType] ?? ucfirst(str_replace('_', ' ', $actionType));
    }
    
    /**
     * Format duration in human-readable format
     */
    private function formatDuration($seconds) {
        if ($seconds < 60) {
            return "$seconds seconds";
        }
        if ($seconds < 3600) {
            $minutes = round($seconds / 60);
            return "$minutes minute" . ($minutes > 1 ? 's' : '');
        }
        if ($seconds < 86400) {
            $hours = round($seconds / 3600, 1);
            return "$hours hour" . ($hours > 1 ? 's' : '');
        }
        $days = round($seconds / 86400, 1);
        return "$days day" . ($days > 1 ? 's' : '');
    }
    
    /**
     * Get client IP address
     */
    private function getClientIP() {
        $ip = 'Unknown';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ip_list[0]);
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'Unknown';
    }
}
