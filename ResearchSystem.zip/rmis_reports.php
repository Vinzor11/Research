<?php
/**
 * rmis_reports.php
 * 
 * RMIS Forms Generation Interface (SPA Compatible)
 * Allows Research Office admins to generate official RMIS Forms A-E
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'RMISFormGenerator.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? '';
$isSpa = isSpaRequest();

// Check authorization - only Research Office admins can generate official reports
$canGenerateReports = in_array($userRole, ['admin', 'research_director', 'assistant_director']);
$generator = new RMISFormGenerator($conn);

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Default fiscal year
$currentFiscalYear = 'FY ' . date('Y');
$selectedFiscalYear = $_GET['fiscal_year'] ?? $currentFiscalYear;
$selectedForm = $_GET['form'] ?? '';

// Get available fiscal years
$fiscalYears = [];
$result = $conn->query("SELECT DISTINCT fiscal_year FROM research_submissions WHERE fiscal_year IS NOT NULL ORDER BY fiscal_year DESC");
while ($row = $result->fetch_assoc()) {
    $fiscalYears[] = $row['fiscal_year'];
}
if (empty($fiscalYears)) {
    for ($y = date('Y') + 1; $y >= date('Y') - 3; $y--) {
        $fiscalYears[] = "FY $y";
    }
}

// Get report data if form is selected
$reportData = null;
$reportError = null;
if ($selectedForm && $canGenerateReports) {
    $filters = [
        'researcher_type' => $_GET['researcher_type'] ?? '',
        'unit_id' => $_GET['unit_id'] ?? ''
    ];
    try {
        $result = $generator->generateAndLog($selectedForm, $selectedFiscalYear, $filters);
        if ($result['success']) {
            $reportData = $result['data'];
        } else {
            $reportError = $result['error'] ?? 'Failed to generate report';
        }
    } catch (Exception $e) {
        $reportError = $e->getMessage();
    }
}

// Get generation history
$generationHistory = [];
try {
    $generationHistory = $generator->getGenerationHistory(null, 10);
} catch (Exception $e) {
    // Ignore errors - table might not exist
}

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* RMIS Reports Page Styles */
.rmis-header {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
}

.rmis-header h1 {
    font-size: 28px;
    color: #1f2937;
    margin: 0 0 8px 0;
    font-weight: 700;
}

.rmis-header p {
    color: #6b7280;
    margin: 0;
    font-size: 15px;
}

/* Form Selection Cards */
.form-selection-section {
    background: white;
    border-radius: 16px;
    padding: 28px;
    margin-bottom: 24px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.form-selection-section h2 {
    font-size: 16px;
    color: #374151;
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-cards-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 16px;
    margin-bottom: 28px;
}

@media (max-width: 1200px) {
    .form-cards-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 768px) {
    .form-cards-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

.form-card {
    background: #f9fafb;
    border: 2px solid #e5e7eb;
    border-radius: 12px;
    padding: 20px 16px;
    text-align: center;
    cursor: pointer;
    transition: all 0.25s ease;
    position: relative;
    overflow: hidden;
}

.form-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: transparent;
    transition: background 0.25s ease;
}

.form-card:hover {
    border-color: #d1d5db;
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}

.form-card.selected {
    border-color: #064e1a;
    background: linear-gradient(to bottom, #f0fdf4, #ffffff);
    box-shadow: 0 4px 15px rgba(6, 78, 26, 0.15);
}

.form-card.selected::before {
    background: #064e1a;
}

.form-badge {
    width: 56px;
    height: 56px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 800;
    margin: 0 auto 12px auto;
    transition: transform 0.25s ease;
}

.form-card:hover .form-badge {
    transform: scale(1.08);
}

.form-card h3 {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    margin: 0 0 4px 0;
}

.form-card p {
    font-size: 11px;
    color: #6b7280;
    margin: 0;
}

/* Form Badge Colors */
.form-card[data-form="a"] .form-badge { background: #dbeafe; color: #1e40af; }
.form-card[data-form="b"] .form-badge { background: #f3e8ff; color: #7c3aed; }
.form-card[data-form="c"] .form-badge { background: #ffedd5; color: #ea580c; }
.form-card[data-form="d"] .form-badge { background: #dcfce7; color: #16a34a; }
.form-card[data-form="d1"] .form-badge { background: #cffafe; color: #0891b2; }
.form-card[data-form="e"] .form-badge { background: #fce7f3; color: #db2777; }

/* Filter Row */
.filter-row {
    display: flex;
    gap: 16px;
    align-items: flex-end;
    flex-wrap: wrap;
    padding-top: 20px;
    border-top: 1px solid #e5e7eb;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 12px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select {
    padding: 10px 14px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 14px;
    min-width: 160px;
    background: white;
    cursor: pointer;
    transition: border-color 0.2s ease;
}

.filter-group select:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.btn-generate {
    padding: 10px 24px;
    background: linear-gradient(135deg, #064e1a 0%, #0a7c2e 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(6, 78, 26, 0.3);
}

.btn-generate:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(6, 78, 26, 0.4);
}

.btn-generate:disabled {
    background: #9ca3af;
    cursor: not-allowed;
    box-shadow: none;
    transform: none;
}

/* Report Output Section */
.report-section {
    background: white;
    border-radius: 16px;
    padding: 28px;
    margin-bottom: 24px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.report-header-official {
    text-align: center;
    padding-bottom: 24px;
    margin-bottom: 24px;
    border-bottom: 2px solid #064e1a;
}

.report-header-official img {
    height: 70px;
    margin-bottom: 12px;
}

.report-header-official h4 {
    font-size: 18px;
    color: #1f2937;
    margin: 0 0 4px 0;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.report-header-official .subtitle {
    color: #6b7280;
    font-size: 13px;
    margin-bottom: 12px;
}

.report-header-official h5 {
    font-size: 16px;
    color: #064e1a;
    margin: 8px 0;
    font-weight: 600;
}

.report-header-official .meta {
    font-size: 12px;
    color: #9ca3af;
}

/* Stats Cards */
.stats-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.stat-card .number {
    font-size: 28px;
    font-weight: 700;
    color: #064e1a;
    line-height: 1;
}

.stat-card .label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 6px;
}

.stat-card.danger .number { color: #dc2626; }

/* Report Tables */
.report-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.report-table th {
    background: #064e1a;
    color: white;
    padding: 12px 14px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.report-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
}

.report-table tbody tr:hover {
    background: #f9fafb;
}

.report-table .text-end { text-align: right; }
.report-table .text-center { text-align: center; }

/* History Section */
.history-section {
    background: white;
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

.history-section h2 {
    font-size: 16px;
    color: #374151;
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.history-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.history-table th {
    background: #f9fafb;
    padding: 12px 14px;
    text-align: left;
    font-weight: 600;
    font-size: 11px;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

.history-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #f3f4f6;
}

.history-table tbody tr:hover {
    background: #f9fafb;
}

.form-type-badge {
    display: inline-flex;
    align-items: center;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
}

.form-type-badge.form-a { background: #dbeafe; color: #1e40af; }
.form-type-badge.form-b { background: #f3e8ff; color: #7c3aed; }
.form-type-badge.form-c { background: #ffedd5; color: #ea580c; }
.form-type-badge.form-d { background: #dcfce7; color: #16a34a; }
.form-type-badge.form-d1 { background: #cffafe; color: #0891b2; }
.form-type-badge.form-e { background: #fce7f3; color: #db2777; }

/* Empty State */
.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #6b7280;
}

.empty-state i {
    font-size: 48px;
    opacity: 0.4;
    margin-bottom: 12px;
}

/* Print Actions */
.print-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-bottom: 20px;
}

.btn-print {
    padding: 8px 16px;
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.2s ease;
}

.btn-print:hover {
    background: #e5e7eb;
}

.btn-export {
    padding: 8px 16px;
    background: #dbeafe;
    color: #1e40af;
    border: 1px solid #93c5fd;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.2s ease;
}

.btn-export:hover {
    background: #bfdbfe;
}

/* Alert */
.alert-warning {
    background: #fef3c7;
    border: 1px solid #fde68a;
    color: #92400e;
    padding: 16px 20px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 24px;
}

.alert-error {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #991b1b;
    padding: 16px 20px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 24px;
}

/* Section Titles in Reports */
.section-title {
    font-size: 14px;
    font-weight: 600;
    color: #064e1a;
    margin: 24px 0 12px 0;
    padding-bottom: 8px;
    border-bottom: 1px solid #e5e7eb;
}

/* Report Footer */
.report-footer {
    margin-top: 24px;
    padding-top: 16px;
    border-top: 1px solid #e5e7eb;
    text-align: center;
    font-size: 11px;
    color: #9ca3af;
}

@media print {
    .no-print { display: none !important; }
    .report-section { box-shadow: none; border: 1px solid #e5e7eb; }
}
</style>

<div class="content">
    <!-- Header -->
    <div class="rmis-header">
        <h1><i class="fa fa-file-alt" style="color: #064e1a;"></i> RMIS Official Reports</h1>
        <p>Generate RMIS Forms A-E from validated system data</p>
    </div>

    <?php if (!$canGenerateReports): ?>
    <div class="alert-warning">
        <i class="fa fa-exclamation-triangle"></i>
        <div>
            <strong>Access Restricted</strong><br>
            Only Research Office administrators can generate official RMIS reports.
        </div>
    </div>
    <?php else: ?>
    
    <!-- Form Selection -->
    <div class="form-selection-section no-print">
        <h2><i class="fa fa-folder-open" style="color: #6b7280;"></i> Select RMIS Form</h2>
        
        <div class="form-cards-grid">
            <div class="form-card <?= $selectedForm === 'a' ? 'selected' : '' ?>" data-form="a" onclick="selectForm('a')">
                <div class="form-badge">A</div>
                <h3>HEI Profile</h3>
                <p>Institution data</p>
            </div>
            
            <div class="form-card <?= $selectedForm === 'b' ? 'selected' : '' ?>" data-form="b" onclick="selectForm('b')">
                <div class="form-badge">B</div>
                <h3>Research Units</h3>
                <p>Unit registry</p>
            </div>
            
            <div class="form-card <?= $selectedForm === 'c' ? 'selected' : '' ?>" data-form="c" onclick="selectForm('c')">
                <div class="form-badge">C</div>
                <h3>Programs</h3>
                <p>Program summary</p>
            </div>
            
            <div class="form-card <?= $selectedForm === 'd' ? 'selected' : '' ?>" data-form="d" onclick="selectForm('d')">
                <div class="form-badge">D</div>
                <h3>Completed</h3>
                <p>Finished projects</p>
            </div>
            
            <div class="form-card <?= $selectedForm === 'd1' ? 'selected' : '' ?>" data-form="d1" onclick="selectForm('d1')">
                <div class="form-badge">D1</div>
                <h3>Ongoing</h3>
                <p>Active projects</p>
            </div>
            
            <div class="form-card <?= $selectedForm === 'e' ? 'selected' : '' ?>" data-form="e" onclick="selectForm('e')">
                <div class="form-badge">E</div>
                <h3>Researchers</h3>
                <p>Faculty profiles</p>
            </div>
        </div>
        
        <form method="GET" id="filterForm" class="filter-row">
            <input type="hidden" name="form" id="selectedFormInput" value="<?= s($selectedForm) ?>">
            
            <div class="filter-group">
                <label>Fiscal Year</label>
                <select name="fiscal_year" onchange="this.form.submit()">
                    <?php foreach ($fiscalYears as $fy): ?>
                    <option value="<?= s($fy) ?>" <?= $selectedFiscalYear === $fy ? 'selected' : '' ?>>
                        <?= s($fy) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group" id="researcherTypeFilter" style="display: <?= in_array($selectedForm, ['d', 'd1', 'e']) ? 'flex' : 'none' ?>">
                <label>Researcher Type</label>
                <select name="researcher_type">
                    <option value="">All Types</option>
                    <option value="faculty" <?= ($_GET['researcher_type'] ?? '') === 'faculty' ? 'selected' : '' ?>>Faculty</option>
                    <option value="student" <?= ($_GET['researcher_type'] ?? '') === 'student' ? 'selected' : '' ?>>Student</option>
                    <option value="personnel" <?= ($_GET['researcher_type'] ?? '') === 'personnel' ? 'selected' : '' ?>>Personnel</option>
                </select>
            </div>
            
            <button type="submit" class="btn-generate" <?= !$selectedForm ? 'disabled' : '' ?>>
                <i class="fa fa-sync-alt"></i> Generate Report
            </button>
        </form>
    </div>

    <?php if ($reportError): ?>
    <div class="alert-error">
        <i class="fa fa-times-circle"></i>
        <div>
            <strong>Error Generating Report</strong><br>
            <?= s($reportError) ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Report Output -->
    <?php if ($reportData): ?>
    <div class="print-actions no-print">
        <button class="btn-print" onclick="window.print()">
            <i class="fa fa-print"></i> Print Report
        </button>
        <button class="btn-export" onclick="exportReport('excel')">
            <i class="fa fa-file-excel"></i> Export Excel
        </button>
    </div>
    
    <div class="report-section" id="reportContent">
        <!-- Report Header -->
        <div class="report-header-official">
            <img src="assets/images/essu-logo.png" alt="ESSU Logo" onerror="this.style.display='none'">
            <h4>Eastern Samar State University</h4>
            <p class="subtitle">Research Development and Services Office</p>
            <h5><?= s($reportData['title'] ?? 'RMIS Report') ?></h5>
            <p class="meta">
                Fiscal Year: <?= s($reportData['fiscal_year'] ?? $selectedFiscalYear) ?> | 
                Generated: <?= date('F d, Y h:i A') ?>
            </p>
        </div>

        <?php if ($selectedForm === 'a' && isset($reportData['data'])): ?>
        <!-- FORM A: HEI Profile -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['statistics']['total_faculty_researchers'] ?? 0) ?></div>
                <div class="label">Faculty Researchers</div>
            </div>
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['statistics']['total_student_researchers'] ?? 0) ?></div>
                <div class="label">Student Researchers</div>
            </div>
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['statistics']['approved_submissions'] ?? 0) ?></div>
                <div class="label">Approved Projects</div>
            </div>
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['statistics']['total_outputs'] ?? 0) ?></div>
                <div class="label">Research Outputs</div>
            </div>
        </div>
        
        <table class="report-table">
            <thead><tr><th colspan="2">Institution Information</th></tr></thead>
            <tbody>
                <tr><td width="30%"><strong>Institution Name</strong></td><td><?= s($reportData['data']['hei_name'] ?? 'Eastern Samar State University') ?></td></tr>
                <tr><td><strong>HEI Code</strong></td><td><?= s($reportData['data']['hei_code'] ?? 'N/A') ?></td></tr>
                <tr><td><strong>Type</strong></td><td><?= s($reportData['data']['hei_type'] ?? 'State University') ?></td></tr>
                <tr><td><strong>Region</strong></td><td><?= s($reportData['data']['region'] ?? 'Region VIII') ?></td></tr>
                <tr><td><strong>Province</strong></td><td><?= s($reportData['data']['province'] ?? 'Eastern Samar') ?></td></tr>
                <tr><td><strong>Municipality</strong></td><td><?= s($reportData['data']['municipality'] ?? 'Borongan City') ?></td></tr>
            </tbody>
        </table>

        <?php elseif ($selectedForm === 'd1' && isset($reportData['data'])): ?>
        <!-- FORM D1: Ongoing Research Projects -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['summary']['total_projects'] ?? 0) ?></div>
                <div class="label">Ongoing Projects</div>
            </div>
            <div class="stat-card">
                <div class="number">₱<?= number_format($reportData['data']['summary']['total_budget'] ?? 0, 2) ?></div>
                <div class="label">Total Budget</div>
            </div>
            <div class="stat-card danger">
                <div class="number"><?= number_format($reportData['data']['summary']['overdue_count'] ?? 0) ?></div>
                <div class="label">Overdue Projects</div>
            </div>
        </div>
        
        <table class="report-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Reference No.</th>
                    <th>Project Title</th>
                    <th>Researchers</th>
                    <th>Timeline</th>
                    <th class="text-end">Budget</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($reportData['data']['projects'])): ?>
                    <?php foreach ($reportData['data']['projects'] as $i => $project): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><code style="font-size: 11px;"><?= s($project['reference_number'] ?? '-') ?></code></td>
                        <td>
                            <strong><?= s($project['title']) ?></strong>
                            <?php if (($project['status'] ?? '') === 'overdue'): ?>
                            <span style="background: #fee2e2; color: #dc2626; padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: 6px;">OVERDUE</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($project['researchers'])): ?>
                                <?php foreach ($project['researchers'] as $r): ?>
                                <div style="font-size: 12px;"><?= s($r['name']) ?></div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span style="color: #9ca3af;">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size: 12px;">
                            <?= $project['proposed_start_date'] ? date('M d, Y', strtotime($project['proposed_start_date'])) : '-' ?>
                            to<br>
                            <?= $project['proposed_end_date'] ? date('M d, Y', strtotime($project['proposed_end_date'])) : '-' ?>
                        </td>
                        <td class="text-end">₱<?= number_format($project['total_budget'] ?? 0, 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center" style="padding: 40px; color: #9ca3af;">No ongoing projects found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php elseif ($selectedForm === 'd' && isset($reportData['data'])): ?>
        <!-- FORM D: Completed Research Projects -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="number"><?= number_format($reportData['data']['summary']['total_projects'] ?? 0) ?></div>
                <div class="label">Completed Projects</div>
            </div>
            <div class="stat-card">
                <div class="number">₱<?= number_format($reportData['data']['summary']['total_budget'] ?? 0, 2) ?></div>
                <div class="label">Total Investment</div>
            </div>
        </div>
        
        <table class="report-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Reference No.</th>
                    <th>Project Title</th>
                    <th>Researchers</th>
                    <th>Funding</th>
                    <th class="text-end">Budget</th>
                    <th>Completed</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($reportData['data']['projects'])): ?>
                    <?php foreach ($reportData['data']['projects'] as $i => $project): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><code style="font-size: 11px;"><?= s($project['reference_number'] ?? '-') ?></code></td>
                        <td><strong><?= s($project['title']) ?></strong></td>
                        <td>
                            <?php if (!empty($project['researchers'])): ?>
                                <?php foreach ($project['researchers'] as $r): ?>
                                <div style="font-size: 12px;"><?= s($r['name']) ?> (<?= s($r['role']) ?>)</div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span style="color: #9ca3af;">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size: 12px;"><?= s($project['funding_source'] ?? '-') ?></td>
                        <td class="text-end">₱<?= number_format($project['total_budget'] ?? 0, 2) ?></td>
                        <td style="font-size: 12px;"><?= $project['approved_at'] ? date('M Y', strtotime($project['approved_at'])) : '-' ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center" style="padding: 40px; color: #9ca3af;">No completed projects found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php else: ?>
        <!-- Generic Display for other forms -->
        <div class="empty-state">
            <i class="fa fa-file-alt"></i>
            <p>Report generated successfully. Data format coming soon.</p>
        </div>
        <?php endif; ?>

        <!-- Report Footer -->
        <div class="report-footer">
            RMIS Form <?= strtoupper(s($selectedForm)) ?> | ESSU-RDSO-115 Version 5 | 
            Generated by Research Management Information System
        </div>
    </div>
    <?php endif; ?>

    <!-- Generation History -->
    <div class="history-section no-print">
        <h2><i class="fa fa-clock" style="color: #6b7280;"></i> Recent Report Generations</h2>
        
        <?php if (empty($generationHistory)): ?>
        <div class="empty-state">
            <i class="fa fa-history"></i>
            <p>No reports have been generated yet.</p>
        </div>
        <?php else: ?>
        <table class="history-table">
            <thead>
                <tr>
                    <th>Form</th>
                    <th>Fiscal Year</th>
                    <th>Records</th>
                    <th>Generated By</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($generationHistory as $gen): ?>
                <tr>
                    <td>
                        <span class="form-type-badge form-<?= s($gen['report_type']) ?>">
                            Form <?= strtoupper(s($gen['report_type'])) ?>
                        </span>
                    </td>
                    <td><?= s($gen['fiscal_year'] ?? '-') ?></td>
                    <td><?= number_format($gen['record_count'] ?? 0) ?></td>
                    <td><?= s($gen['generated_by_name'] ?? 'System') ?></td>
                    <td><?= isset($gen['generated_at']) ? date('M d, Y h:i A', strtotime($gen['generated_at'])) : '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<script>
function selectForm(formType) {
    document.getElementById('selectedFormInput').value = formType;
    
    // Update visual selection
    document.querySelectorAll('.form-card').forEach(card => card.classList.remove('selected'));
    document.querySelector(`.form-card[data-form="${formType}"]`).classList.add('selected');
    
    // Show/hide researcher type filter
    const researcherFilter = document.getElementById('researcherTypeFilter');
    if (['d', 'd1', 'e'].includes(formType)) {
        researcherFilter.style.display = 'flex';
    } else {
        researcherFilter.style.display = 'none';
    }
    
    // Enable generate button
    document.querySelector('.btn-generate').disabled = false;
}

function exportReport(format) {
    const params = new URLSearchParams(window.location.search);
    params.set('export', format);
    
    // TODO: Implement export endpoint
    alert('Export to ' + format.toUpperCase() + ' coming soon!\n\nCurrent filters: ' + params.toString());
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    const selectedForm = document.getElementById('selectedFormInput').value;
    if (!selectedForm) {
        document.querySelector('.btn-generate').disabled = true;
    }
});
</script>
