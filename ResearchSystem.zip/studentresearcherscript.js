/**
 * Student Researcher Actions JavaScript
 * File: studentresearcherscript.js
 */

// Confirmation dialog for delete action
function confirmDelete(studentId, studentName) {
    const confirmMessage = 'Are you sure you want to delete ' + studentName + ' and all their research records?\n\nThis action cannot be undone.';
    
    if (confirm(confirmMessage)) {
        window.location.href = 'studentresearcher.php?delete=' + studentId;
    }
}

// Navigate to student profile page
function viewProfile(studentId) {
    window.location.href = 'studentresearcherprofile.php?id=' + studentId;
}
