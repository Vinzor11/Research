<?php
/**
 * Researcher Projects Dashboard
 * 
 * This page allows researchers to:
 * - View their approved research projects (elevated from proposals)
 * - Monitor project status (On-Going, Extended, Completed)
 * - Submit progress reports
 * - Request extensions or amendments
 * - Report research outputs/publications
 * - Submit completion reports
 * 
 * DESIGN:
 * - Only shows approved submissions with project_status
 * - Displays locked fields with indication
 * - Provides clear lifecycle progression
 * - RMIS Form mapping (D1 for On-Going, D for Completed)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Initialize service
$projectService = new ProjectService($conn);
$workflowEngine = $projectService->getWorkflowEngine();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Determine researcher type for badge display
$researcherType = 'Researcher';
$researcherTypeQuery = $conn->prepare("
    SELECT 'Faculty' as type FROM faculty_researchers WHERE user_id = ? OR created_by = ?
    UNION
    SELECT 'Student' as type FROM student_researchers WHERE created_by = ?
    UNION  
    SELECT 'Personnel' as type FROM personnel_researchers WHERE user_id = ? OR created_by = ?
    LIMIT 1
");
$researcherTypeQuery->bind_param("iiiii", $userId, $userId, $userId, $userId, $userId);
$researcherTypeQuery->execute();
$typeResult = $researcherTypeQuery->get_result();
if ($typeRow = $typeResult->fetch_assoc()) {
    $researcherType = $typeRow['type'];
}
$researcherTypeQuery->close();

// Get filters and pagination
$statusFilter = $_GET['status'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get researcher's projects
$filters = [
    'project_status' => $statusFilter ?: null,
    'search' => $searchQuery ?: null
];
$projects = $projectService->getResearcherProjects($filters, $page, 12);

// Get project statistics
$stats = $workflowEngine->getProjectStatistics('researcher');

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   MY PROJECTS - UNIFIED DESIGN (Unit Projects Style)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    cursor: pointer;
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-ongoing { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-extended { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-completed { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }
.stat-icon.icon-overdue { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header-left i { color: #064e1a; font-size: 18px; }

.filter-link {
    font-size: 13px;
    color: #064e1a;
    text-decoration: none;
    font-weight: 500;
}

.filter-link:hover {
    text-decoration: underline;
}

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Projects Table */
.projects-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.projects-table {
    width: 100%;
    border-collapse: collapse;
}

.projects-table thead th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

/* Column widths */
.projects-table thead th:nth-child(1) { width: 28%; }
.projects-table thead th:nth-child(2) { width: 12%; text-align: center; }
.projects-table thead th:nth-child(3) { width: 10%; text-align: center; }
.projects-table thead th:nth-child(4) { width: 20%; text-align: center; }
.projects-table thead th:nth-child(5) { width: 30%; text-align: center; }

.projects-table tbody td {
    padding: 14px 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
}

.projects-table tbody td:nth-child(2),
.projects-table tbody td:nth-child(3),
.projects-table tbody td:nth-child(4),
.projects-table tbody td:nth-child(5) {
    text-align: center;
    vertical-align: middle;
}

.projects-table tbody tr:hover {
    background: #f9fafb;
}

/* Project Title Cell */
.project-title-cell { text-align: left; }

.project-title-link {
    font-weight: 600;
    font-size: 14px;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 6px;
    line-height: 1.4;
}

.project-title-link:hover { color: #064e1a; }

.project-code {
    font-size: 11px;
    color: #9ca3af;
    font-family: 'Consolas', monospace;
    display: inline-block;
    background: #f3f4f6;
    padding: 3px 8px;
    border-radius: 4px;
}

/* RMIS Badge */
.rmis-badge {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 2px 6px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    color: #166534;
    margin-left: 6px;
}

/* Reference Cell */
.ref-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.ref-code {
    font-family: 'Consolas', monospace;
    font-size: 11px;
    color: #047857;
    background: #ecfdf5;
    padding: 4px 10px;
    border-radius: 4px;
    font-weight: 600;
    border: 1px solid #a7f3d0;
}

.ref-secondary {
    font-size: 10px;
    color: #9ca3af;
}

/* Status Cell */
.status-cell-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.project-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.project-ongoing { background: #dbeafe; color: #1e40af; }
.project-extended { background: #fef3c7; color: #92400e; }
.project-completed { background: #d1fae5; color: #065f46; }
.project-not-started { background: #f3f4f6; color: #6b7280; }

.extension-indicator {
    font-size: 10px;
    color: #d97706;
    display: inline-flex;
    align-items: center;
    gap: 3px;
}

/* Timeline Cell */
.timeline-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.timeline-dates {
    font-size: 12px;
    color: #374151;
    font-weight: 500;
    white-space: nowrap;
}

.mini-progress {
    width: 100%;
    max-width: 100px;
    height: 5px;
    background: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
}

.mini-progress-bar {
    height: 100%;
    border-radius: 3px;
    transition: width 0.3s;
}

.mini-progress-bar.on-track { background: linear-gradient(90deg, #10b981, #34d399); }
.mini-progress-bar.near-due { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
.mini-progress-bar.overdue { background: linear-gradient(90deg, #ef4444, #f87171); }
.mini-progress-bar.completed { background: linear-gradient(90deg, #10b981, #34d399); }

.timeline-status {
    font-size: 11px;
    font-weight: 500;
}

.timeline-status.on-track { color: #10b981; }
.timeline-status.near-due { color: #f59e0b; }
.timeline-status.overdue { color: #ef4444; }
.timeline-status.completed { color: #10b981; }

.completed-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
}

.completed-badge {
    font-size: 12px;
    color: #10b981;
    font-weight: 600;
}

.completed-date {
    font-size: 10px;
    color: #6b7280;
}

/* Action Buttons */
.action-btns {
    display: flex !important;
    align-items: center;
    gap: 8px;
    justify-content: center;
    flex-wrap: wrap;
}

.action-btns .btn {
    padding: 8px 16px !important;
    border-radius: 8px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer;
    border: none;
    display: inline-flex !important;
    align-items: center;
    gap: 6px;
    text-decoration: none !important;
    transition: all 0.2s ease;
    white-space: nowrap;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.action-btns .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.action-btns .btn i {
    font-size: 12px;
}

.btn-view { 
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%) !important; 
    color: white !important; 
}
.btn-view:hover { 
    background: linear-gradient(135deg, #053615 0%, #096b24 100%) !important;
}

.btn-progress { 
    background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%) !important; 
    color: white !important; 
}
.btn-progress:hover { 
    background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%) !important; 
}

.btn-output { 
    background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%) !important; 
    color: white !important; 
}
.btn-output:hover { 
    background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%) !important; 
}

.btn-extension { 
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%) !important; 
    color: white !important; 
}
.btn-extension:hover { 
    background: linear-gradient(135deg, #b45309 0%, #d97706 100%) !important; 
}
.btn-extension.urgency-overdue { 
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%) !important; 
    color: white !important; 
}

.btn-completion { 
    background: linear-gradient(135deg, #059669 0%, #10b981 100%) !important; 
    color: white !important; 
}
.btn-completion:hover { 
    background: linear-gradient(135deg, #047857 0%, #059669 100%) !important; 
}

.btn-complete { 
    background: linear-gradient(135deg, #059669 0%, #10b981 100%) !important; 
    color: white !important; 
}
.btn-complete:hover { 
    background: linear-gradient(135deg, #047857 0%, #059669 100%) !important; 
}

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }
.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; }
.pagination .current { background: #064e1a; color: white; }

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Responsive */
@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .page-header-banner { padding: 20px; }
    .header-content { flex-direction: column; text-align: center; }
    .header-left { flex-direction: column; }
    .stats-row { flex-wrap: wrap; }
    .stat-card { min-width: calc(50% - 8px); flex: unset; }
    .filter-grid { grid-template-columns: 1fr; }
    .projects-table thead th:nth-child(2),
    .projects-table tbody td:nth-child(2) { display: none; }
    .pagination-container { flex-direction: column; gap: 12px; }
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa fa-folder-open header-icon"></i>
                <div>
                    <h1>My Projects</h1>
                    <p>Manage your approved and on-going research projects</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px;">
                <span class="role-badge">
                    <i class="fa fa-user-graduate"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    <?= s($researcherType) ?> Researcher
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <div class="stats-row">
        <div class="stat-card" onclick="filterByStatus('on_going')">
            <div class="stat-icon icon-ongoing"><i class="fa fa-spinner"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['on_going'] ?? 0 ?></div>
                <div class="stat-label">On-Going</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('extended')">
            <div class="stat-icon icon-extended"><i class="fa fa-calendar-plus"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['extended'] ?? 0 ?></div>
                <div class="stat-label">Extended</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('completed')">
            <div class="stat-icon icon-completed"><i class="fa fa-check-circle"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['completed'] ?? 0 ?></div>
                <div class="stat-label">Completed</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('overdue')">
            <div class="stat-icon icon-overdue"><i class="fa fa-exclamation-triangle"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['overdue'] ?? 0 ?></div>
                <div class="stat-label">Overdue</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <div class="filter-header-left">
                <i class="fa fa-filter"></i>
            </div>
            <a href="researcher_projects.php" class="filter-link">Filter Projects</a>
        </div>
        
        <form id="filterForm" method="GET">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status" onchange="this.form.submit()">
                        <option value="">All Projects</option>
                        <option value="on_going" <?= $statusFilter === 'on_going' ? 'selected' : '' ?>>On-Going</option>
                        <option value="extended" <?= $statusFilter === 'extended' ? 'selected' : '' ?>>Extended</option>
                        <option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by title, reference..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-actions">
                    <?php if ($statusFilter || $searchQuery): ?>
                        <a href="researcher_projects.php" class="clear-btn" title="Clear Filters">
                            <i class="fa fa-times"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Projects Table -->
    <div class="projects-table-container">
        <?php if (empty($projects['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-folder-open"></i>
                <h3>No Projects Found</h3>
                <p>You don't have any approved research projects yet.<br>
                Once your proposals are approved, they will appear here as active projects.</p>
            </div>
        <?php else: ?>
            <table class="projects-table">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Reference</th>
                        <th>Status</th>
                        <th>Timeline</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects['data'] as $project): ?>
                        <?php
                        // Calculate timeline status
                        $timelineClass = 'on-track';
                        $progressPercent = 0;
                        $daysInfo = '';
                        
                        if ($project['proposed_start_date'] && $project['current_end_date']) {
                            $start = strtotime($project['proposed_start_date']);
                            $end = strtotime($project['current_end_date']);
                            $now = time();
                            
                            if ($now >= $end) {
                                $timelineClass = 'overdue';
                                $daysOverdue = floor(($now - $end) / 86400);
                                $daysInfo = $daysOverdue . 'd overdue';
                                $progressPercent = 100;
                            } elseif ($now <= $start) {
                                $timelineClass = 'on-track';
                                $daysInfo = 'Not started';
                                $progressPercent = 0;
                            } else {
                                $total = $end - $start;
                                $elapsed = $now - $start;
                                $progressPercent = min(100, round(($elapsed / $total) * 100));
                                $daysRemaining = ceil(($end - $now) / 86400);
                                $daysInfo = $daysRemaining . 'd remaining';
                                
                                if ($daysRemaining <= 30) {
                                    $timelineClass = 'near-due';
                                }
                            }
                        }
                        
                        if ($project['project_status'] === 'completed') {
                            $timelineClass = 'completed';
                            $progressPercent = 100;
                            $daysInfo = 'Done';
                        }
                        
                        $actions = $project['actions'] ?? [];
                        $projectTitle = s(addslashes($project['title']));
                        $projectId = $project['id'];
                        ?>
                        <tr>
                            <!-- Column 1: Project Title -->
                            <td class="project-title-cell">
                                <a href="project_view.php?id=<?= $projectId ?>" class="project-title-link"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $projectId ?>',true)}">
                                    <?= s($project['title']) ?>
                                </a>
                                <span class="project-code"><?= s($project['project_code'] ?? 'No Code') ?></span>
                                <?php if ($project['rmis_form_mapping']): ?>
                                    <span class="rmis-badge">
                                        <i class="fa fa-file-alt"></i> <?= s($project['rmis_form_mapping']) ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            
                            <!-- Column 2: Reference -->
                            <td>
                                <div class="ref-info">
                                    <?php if ($project['reference_number']): ?>
                                        <span class="ref-code"><?= s($project['reference_number']) ?></span>
                                    <?php else: ?>
                                        <span style="color: #9ca3af;">—</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            
                            <!-- Column 3: Status -->
                            <td>
                                <div class="status-cell-content">
                                    <span class="project-status-badge <?= s($project['project_status_class']) ?>">
                                        <?= s($project['project_status_label']) ?>
                                    </span>
                                    <?php if ($project['extension_count'] > 0): ?>
                                        <span class="extension-indicator">
                                            <i class="fa fa-calendar-plus"></i> <?= $project['extension_count'] ?>x
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            
                            <!-- Column 4: Timeline -->
                            <td>
                                <?php if ($project['project_status'] !== 'completed'): ?>
                                    <div class="timeline-content">
                                        <div class="timeline-dates">
                                            <?= $project['proposed_start_date'] ? date('M d', strtotime($project['proposed_start_date'])) : '—' ?> – 
                                            <?= $project['current_end_date'] ? date('M d, Y', strtotime($project['current_end_date'])) : '—' ?>
                                        </div>
                                        <div class="mini-progress">
                                            <div class="mini-progress-bar <?= $timelineClass ?>" style="width: <?= $progressPercent ?>%"></div>
                                        </div>
                                        <div class="timeline-status <?= $timelineClass ?>"><?= $daysInfo ?></div>
                                    </div>
                                <?php else: ?>
                                    <div class="completed-info">
                                        <span class="completed-badge">
                                            <i class="fa fa-check-circle"></i> Completed
                                        </span>
                                        <?php if ($project['completed_at']): ?>
                                            <span class="completed-date"><?= date('M d, Y', strtotime($project['completed_at'])) ?></span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            
                            <!-- Column 5: Actions -->
                            <td>
                                <div class="action-btns">
                                    <?php if (in_array($project['project_status'], ['on_going', 'extended'])): ?>
                                        <?php $progressAction = $actions['progress'] ?? ['allowed' => true, 'reason' => null]; ?>
                                        <?php if ($progressAction['allowed']): ?>
                                            <button class="btn btn-progress" onclick="openProgressReportModal(<?= $projectId ?>, '<?= $projectTitle ?>')" title="Submit Progress Report">
                                                <i class="fa fa-chart-line"></i> Progress
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php $outputAction = $actions['output'] ?? ['allowed' => false]; ?>
                                        <?php if ($outputAction['allowed']): ?>
                                            <button class="btn btn-output" onclick="openOutputModal(<?= $projectId ?>, '<?= $projectTitle ?>')" title="Report Research Output">
                                                <i class="fa fa-file-alt"></i> Output
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php $extensionAction = $actions['extension'] ?? ['allowed' => false, 'urgency' => null]; ?>
                                        <?php if ($extensionAction['allowed']): ?>
                                            <?php $urgencyClass = $extensionAction['urgency'] === 'overdue' ? ' urgency-overdue' : ''; ?>
                                            <button class="btn btn-extension<?= $urgencyClass ?>" onclick="openExtensionModal(<?= $projectId ?>, '<?= $projectTitle ?>')" title="Request Extension">
                                                <i class="fa fa-calendar-plus"></i> Extend
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php $completionAction = $actions['completion'] ?? ['allowed' => false]; ?>
                                        <?php if ($completionAction['allowed']): ?>
                                            <button class="btn btn-completion" onclick="openCompletionModal(<?= $projectId ?>, '<?= $projectTitle ?>')" title="Submit Completion Report">
                                                <i class="fa fa-flag-checkered"></i> Complete
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <a href="project_view.php?id=<?= $projectId ?>" class="btn btn-view"
                                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $projectId ?>',true)}">
                                        <i class="fa fa-eye"></i> View
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <div class="pagination-container">
                <div class="pagination-info">
                    Showing <?= count($projects['data']) ?> of <?= $projects['total'] ?? count($projects['data']) ?> projects
                </div>
                
                <?php if ($projects['total_pages'] > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&q=<?= s($searchQuery) ?>">
                                <i class="fa fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($projects['total_pages'], $page + 2); $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $projects['total_pages']): ?>
                            <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&q=<?= s($searchQuery) ?>">
                                <i class="fa fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Progress Report Modal -->
<div id="progressReportModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-chart-line" style="color: #3b82f6;"></i> Submit Progress Report</h3>
            <button class="modal-close" onclick="closeModal('progressReportModal')">&times;</button>
        </div>
        <form id="progressReportForm" method="POST" onsubmit="submitProgressReport(event); return false;">
            <input type="hidden" name="project_id" id="progress_project_id">
            <div class="modal-body">
                <p class="modal-project-title" id="progress_project_title" style="color: #6b7280; margin-bottom: 16px; font-style: italic;"></p>
                
                <div class="form-group">
                    <label>Report Period <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="report_period" placeholder="e.g., Q1 2026, January 2026" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Period Start <span style="color: #dc2626;">*</span></label>
                        <input type="date" name="period_start_date" required>
                    </div>
                    <div class="form-group">
                        <label>Period End <span style="color: #dc2626;">*</span></label>
                        <input type="date" name="period_end_date" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Completion Percentage <span style="color: #dc2626;">*</span></label>
                    <input type="number" name="completion_percentage" min="0" max="100" placeholder="0-100" required>
                </div>
                
                <div class="form-group">
                    <label>Activities Conducted <span style="color: #dc2626;">*</span></label>
                    <textarea name="activities_conducted" placeholder="Describe what was accomplished during this period..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Issues/Challenges</label>
                    <textarea name="issues_encountered" placeholder="Any issues or challenges faced..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Next Steps</label>
                    <textarea name="next_steps" placeholder="Planned activities for next period..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal-cancel btn-modal-lg" onclick="closeModal('progressReportModal')">Cancel</button>
                <button type="submit" class="btn-modal-submit btn-modal-lg" style="background: #3b82f6; color: white;">
                    <i class="fa fa-paper-plane"></i> Submit Report
                </button>
            </div>
        </form>
    </div>
</div>

<style>
#progressReportModal textarea {
    overflow: hidden !important;
    resize: none !important;
    min-height: 80px;
    height: auto;
    box-sizing: border-box;
}
</style>

<script>
document.querySelectorAll('#progressReportModal textarea').forEach(function(textarea) {
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
    });
});
</script>

<!-- Extension Request Modal -->
<div id="extensionModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-calendar-plus" style="color: #f59e0b;"></i> Request Extension</h3>
            <button class="modal-close" onclick="closeModal('extensionModal')">&times;</button>
        </div>
        <form id="extensionForm" method="POST" onsubmit="submitExtensionRequest(event); return false;">
            <input type="hidden" name="project_id" id="extension_project_id">
            <div class="modal-body">
                <p class="modal-project-title" id="extension_project_title" style="color: #6b7280; margin-bottom: 16px; font-style: italic;"></p>
                
                <div class="form-group">
                    <label>Extension Type <span style="color: #dc2626;">*</span></label>
                    <select name="extension_type" id="ext_type_select" required onchange="toggleExtensionFields()">
                        <option value="">Select Type</option>
                        <option value="timeline">Time Extension Only</option>
                        <option value="budget">Budget Extension Only</option>
                        <option value="timeline_budget">Both Time & Budget</option>
                    </select>
                </div>
                
                <div class="form-group" id="ext_date_group" style="display: none;">
                    <label>New End Date <span class="ext-required" style="color: #dc2626;">*</span></label>
                    <input type="date" name="requested_end_date" id="ext_end_date" min="<?= date('Y-m-d') ?>">
                    <small style="color: #6b7280; display: block; margin-top: 4px;">Required for time extension</small>
                </div>
                
                <div class="form-group" id="ext_budget_group" style="display: none;">
                    <label>Additional Budget (PHP) <span class="ext-required" style="color: #dc2626;">*</span></label>
                    <input type="number" name="requested_additional_budget" id="ext_budget" min="0" step="0.01" placeholder="0.00">
                    <small style="color: #6b7280; display: block; margin-top: 4px;">Required for budget extension</small>
                </div>
                
                <div class="form-group">
                    <label>Justification <span style="color: #dc2626;">*</span></label>
                    <textarea name="justification" rows="4" placeholder="Explain why an extension is needed..." required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal-cancel btn-modal-lg" onclick="closeModal('extensionModal')">Cancel</button>
                <button type="submit" class="btn-modal-submit btn-modal-lg" style="background: #f59e0b; color: white;">
                    <i class="fa fa-paper-plane"></i> Submit Request
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Completion Report Modal -->
<div id="completionModal" class="modal-overlay">
    <div class="modal-box" style="max-width: 650px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #10b981, #059669);">
            <h3 style="color: white;"><i class="fa fa-flag-checkered"></i> Submit Completion Report</h3>
            <button class="modal-close" style="color: white;" onclick="closeModal('completionModal')">&times;</button>
        </div>
        <form id="completionForm" method="POST" onsubmit="submitCompletionReport(event); return false;">
            <input type="hidden" name="project_id" id="completion_project_id">
            <div class="modal-body">
                <p class="modal-project-title" id="completion_project_title" style="color: #6b7280; margin-bottom: 16px; font-style: italic;"></p>
                
                <div style="background: #d1fae5; color: #065f46; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                    <i class="fa fa-info-circle"></i>
                    <strong>Important:</strong> Submitting this report will mark the project as completed.
                </div>
                
                <div class="form-group">
                    <label>Actual Completion Date <span style="color: #dc2626;">*</span></label>
                    <input type="date" name="actual_completion_date" max="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Executive Summary <span style="color: #dc2626;">*</span></label>
                    <textarea name="executive_summary" placeholder="Provide a brief summary of the research project and its outcomes..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Objectives Achieved <span style="color: #dc2626;">*</span></label>
                    <textarea name="objectives_achieved" placeholder="Describe the objectives that were achieved and the extent to which they were met..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Key Findings <span style="color: #dc2626;">*</span></label>
                    <textarea name="key_findings" placeholder="List the key findings or results of the research..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Deliverables Produced <span style="color: #dc2626;">*</span></label>
                    <textarea name="deliverables_produced" placeholder="List all deliverables produced (publications, patents, software, etc.)..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Recommendations</label>
                    <textarea name="recommendations" placeholder="Any recommendations for future research or implementation..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Challenges Overcome</label>
                    <textarea name="challenges_overcome" placeholder="Major challenges faced and how they were addressed..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal-cancel btn-modal-lg" onclick="closeModal('completionModal')">Cancel</button>
                <button type="submit" class="btn-modal-submit btn-modal-lg" style="background: #10b981; color: white;">
                    <i class="fa fa-check-circle"></i> Submit & Complete
                </button>
            </div>
        </form>
    </div>
</div>

<style>
#completionModal textarea {
    overflow: hidden !important;
    resize: none !important;
    min-height: 80px;
    height: auto;
    box-sizing: border-box;
}
</style>

<script>
document.querySelectorAll('#completionModal textarea').forEach(function(textarea) {
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
    });
});
</script>

<!-- Research Output Modal -->
<div id="outputModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-file-alt" style="color: #8b5cf6;"></i> Report Research Output</h3>
            <button class="modal-close" onclick="closeModal('outputModal')">&times;</button>
        </div>
        <form id="outputForm" method="POST" onsubmit="submitOutput(event); return false;">
            <input type="hidden" name="project_id" id="output_project_id">
            <div class="modal-body">
                <p class="modal-project-title" id="output_project_title" style="color: #6b7280; margin-bottom: 16px; font-style: italic;"></p>
                
                <div class="form-group">
                    <label>Output Type <span style="color: #dc2626;">*</span></label>
                    <select name="output_type" required>
                        <option value="">Select Type</option>
                        <option value="journal_article">Journal Article</option>
                        <option value="conference_paper">Conference Paper</option>
                        <option value="book_chapter">Book Chapter</option>
                        <option value="patent">Patent</option>
                        <option value="software">Software/Application</option>
                        <option value="thesis">Thesis/Dissertation</option>
                        <option value="technical_report">Technical Report</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Title <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="title" placeholder="Title of the output" required>
                </div>
                
                <div class="form-group">
                    <label>Authors <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="authors" placeholder="e.g., Dela Cruz, J., Santos, M., Reyes, A." required>
                    <small style="color: #6b7280; display: block; margin-top: 4px;">List all authors in order (Last Name, First Initial format)</small>
                </div>
                
                <div class="form-group">
                    <label>Publication Venue</label>
                    <input type="text" name="publication_venue" placeholder="e.g., Journal name, Conference name">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Publication Date</label>
                        <input type="date" name="publication_date">
                    </div>
                    <div class="form-group">
                        <label>DOI/URL</label>
                        <input type="text" name="doi_url" placeholder="DOI or URL link">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Brief description of the output..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-modal-cancel btn-modal-lg" onclick="closeModal('outputModal')">Cancel</button>
                <button type="submit" class="btn-modal-submit btn-modal-lg" style="background: #8b5cf6; color: white;">
                    <i class="fa fa-paper-plane"></i> Submit Output
                </button>
            </div>
        </form>
    </div>
</div>

<style>
/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

.modal-overlay.active .modal-box {
    transform: scale(1);
}

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body {
    padding: 24px;
}

.modal-body .form-group {
    margin-bottom: 16px;
}

.modal-body .form-group label {
    display: block;
    margin-bottom: 6px;
    font-weight: 500;
    font-size: 14px;
    color: #374151;
}

.modal-body .form-group input,
.modal-body .form-group select,
.modal-body .form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
}

.modal-body .form-group input:focus,
.modal-body .form-group select:focus,
.modal-body .form-group textarea:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.modal-body .form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.btn-modal-cancel {
    padding: 10px 20px;
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 500;
}

.btn-modal-submit {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-modal-lg {
    padding: 12px 24px !important;
    font-size: 15px !important;
    font-weight: 600 !important;
    min-width: 120px;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.9; }
}
</style>

<script>
// Filter by clicking stat cards
function filterByStatus(status) {
    const form = document.getElementById('filterForm');
    const statusSelect = form.querySelector('select[name="status"]');
    statusSelect.value = status;
    form.submit();
}

// Debounce search input
if (typeof window.projectSearchTimeout === 'undefined') {
    window.projectSearchTimeout = null;
}
const projectSearchInput = document.querySelector('input[name="q"]');
if (projectSearchInput && !projectSearchInput.dataset.listenerAttached) {
    projectSearchInput.dataset.listenerAttached = 'true';
    projectSearchInput.addEventListener('input', function() {
        clearTimeout(window.projectSearchTimeout);
        window.projectSearchTimeout = setTimeout(() => {
            document.getElementById('filterForm').submit();
        }, 500);
    });
}

// Modal Functions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('active');
    const form = modal.querySelector('form');
    if (form) form.reset();
}

function openProgressReportModal(projectId, projectTitle) {
    document.getElementById('progress_project_id').value = projectId;
    document.getElementById('progress_project_title').textContent = projectTitle;
    openModal('progressReportModal');
}

function openExtensionModal(projectId, projectTitle) {
    document.getElementById('extension_project_id').value = projectId;
    document.getElementById('extension_project_title').textContent = projectTitle;
    openModal('extensionModal');
}

function openOutputModal(projectId, projectTitle) {
    document.getElementById('output_project_id').value = projectId;
    document.getElementById('output_project_title').textContent = projectTitle;
    openModal('outputModal');
}

function openCompletionModal(projectId, projectTitle) {
    document.getElementById('completion_project_id').value = projectId;
    document.getElementById('completion_project_title').textContent = projectTitle;
    openModal('completionModal');
}

// Close modal on outside click
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
    }
});

// API Submissions
async function submitProgressReport(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_progress_report',
                project_id: formData.get('project_id'),
                report_period: formData.get('report_period'),
                period_start_date: formData.get('period_start_date'),
                period_end_date: formData.get('period_end_date'),
                completion_percentage: formData.get('completion_percentage'),
                activities_conducted: formData.get('activities_conducted'),
                issues_encountered: formData.get('issues_encountered'),
                next_steps: formData.get('next_steps'),
                submit: true
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Progress report submitted successfully!');
            closeModal('progressReportModal');
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while submitting');
    }
}

function toggleExtensionFields() {
    const extType = document.getElementById('ext_type_select').value;
    const dateGroup = document.getElementById('ext_date_group');
    const budgetGroup = document.getElementById('ext_budget_group');
    const dateInput = document.getElementById('ext_end_date');
    const budgetInput = document.getElementById('ext_budget');
    
    // Reset
    dateInput.required = false;
    budgetInput.required = false;
    dateGroup.style.display = 'none';
    budgetGroup.style.display = 'none';
    
    // Show fields based on extension type
    if (extType === 'timeline') {
        dateGroup.style.display = 'block';
        dateInput.required = true;
    } else if (extType === 'budget') {
        budgetGroup.style.display = 'block';
        budgetInput.required = true;
    } else if (extType === 'timeline_budget') {
        dateGroup.style.display = 'block';
        budgetGroup.style.display = 'block';
        dateInput.required = true;
        budgetInput.required = true;
    }
}

async function submitExtensionRequest(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const extType = formData.get('extension_type');
    const endDate = formData.get('requested_end_date');
    const budget = formData.get('requested_additional_budget');
    
    // Client-side validation
    if (!extType) {
        alert('❌ Please select an extension type');
        return;
    }
    
    if ((extType === 'timeline' || extType === 'timeline_budget') && !endDate) {
        alert('❌ New end date is required for time extension');
        return;
    }
    
    if ((extType === 'budget' || extType === 'timeline_budget') && !budget) {
        alert('❌ Additional budget amount is required for budget extension');
        return;
    }
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_extension',
                project_id: formData.get('project_id'),
                extension_type: extType,
                requested_end_date: endDate || null,
                requested_additional_budget: budget ? parseFloat(budget) : null,
                justification: formData.get('justification'),
                submit: true
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Extension request submitted successfully!');
            closeModal('extensionModal');
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while submitting');
    }
}

async function submitOutput(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'report_output',
                project_id: formData.get('project_id'),
                output_type: formData.get('output_type'),
                title: formData.get('title'),
                authors: formData.get('authors'),
                publication_venue: formData.get('publication_venue') || null,
                publication_date: formData.get('publication_date') || null,
                doi_url: formData.get('doi_url') || null,
                description: formData.get('description') || null
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Research output reported successfully!');
            closeModal('outputModal');
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while submitting');
    }
}

async function submitCompletionReport(event) {
    event.preventDefault();
    
    if (!confirm('Are you sure you want to submit this completion report? This will mark the project as COMPLETED.')) {
        return;
    }
    
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_completion_report',
                project_id: formData.get('project_id'),
                actual_completion_date: formData.get('actual_completion_date'),
                executive_summary: formData.get('executive_summary'),
                objectives_achieved: formData.get('objectives_achieved'),
                key_findings: formData.get('key_findings'),
                deliverables_produced: formData.get('deliverables_produced'),
                recommendations: formData.get('recommendations') || null,
                challenges_overcome: formData.get('challenges_overcome') || null,
                submit: true
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            let message = '✅ Completion report submitted successfully!\n\n';
            message += '📄 Project Status: COMPLETED\n';
            message += '📋 RMIS Form: Form D (Completed Research Project)\n\n';
            message += 'The project has been successfully completed and archived.';
            alert(message);
            closeModal('completionModal');
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while submitting');
    }
}

// Highlight overdue projects
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.project-card.status-overdue').forEach(card => {
        card.style.animation = 'pulse 2s infinite';
    });
});
</script>
