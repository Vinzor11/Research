<?php
/**
 * SPA Main Shell
 * This file serves as the main application shell with a persistent sidebar.
 * Content is loaded dynamically via AJAX.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';
require_once 'UnifiedQueueService.php';

// Get user info
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$currentUserId = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';

// Get initial page from URL or default to dashboard
$initialPage = $_GET['page'] ?? 'dashboard';

// Get all coordinator types for the current user from coordinator_assignments table
$userCoordinatorTypes = [];
if ($userRole === 'coordinator') {
    // Get employee_id for current user
    $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
    $empStmt->bind_param("i", $currentUserId);
    $empStmt->execute();
    $empResult = $empStmt->get_result();
    if ($empRow = $empResult->fetch_assoc()) {
        $employeeId = $empRow['employee_id'];
        if ($employeeId) {
            // Get all active coordinator types for this employee
            $typeStmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
            $typeStmt->bind_param("s", $employeeId);
            $typeStmt->execute();
            $typeResult = $typeStmt->get_result();
            while ($typeRow = $typeResult->fetch_assoc()) {
                $userCoordinatorTypes[] = $typeRow['coordinator_type'];
            }
            $typeStmt->close();
        }
    }
    $empStmt->close();
}

// Determine what sections to show based on role and ALL assigned coordinator types
$isAdmin = ($userRole === 'admin');
$showFaculty = $isAdmin || in_array('faculty', $userCoordinatorTypes);
$showStudent = $isAdmin || in_array('student', $userCoordinatorTypes);
$showPersonnel = $isAdmin || in_array('personnel', $userCoordinatorTypes);
$isCoordinator = ($userRole === 'coordinator' && !empty($userCoordinatorTypes));

// Check if user is Research Office admin
$isROAdmin = false;
if ($isAdmin) {
    $isROAdmin = true;
} else {
    $roStmt = $conn->prepare("SELECT id FROM research_office_admins WHERE user_id = ? AND status = 'active'");
    $roStmt->bind_param("i", $currentUserId);
    $roStmt->execute();
    $isROAdmin = $roStmt->get_result()->num_rows > 0;
    $roStmt->close();
}

// Check if user is a researcher (can create submissions)
// A user is a researcher if they have a record in faculty_researchers, student_researchers, or personnel_researchers
// OR if they are a coordinator (coordinators are typically also researchers)
$isResearcher = $isCoordinator; // Coordinators can submit their own research

if (!$isResearcher && !$isAdmin) {
    // Check if user has a researcher record linked to their account
    // faculty/personnel use user_id, students use created_by (students don't have user accounts)
    $researcherCheck = $conn->prepare("
        SELECT 'faculty' as type FROM faculty_researchers WHERE user_id = ?
        UNION
        SELECT 'student' as type FROM student_researchers WHERE created_by = ?
        UNION  
        SELECT 'personnel' as type FROM personnel_researchers WHERE user_id = ?
        LIMIT 1
    ");
    $researcherCheck->bind_param("iii", $currentUserId, $currentUserId, $currentUserId);
    $researcherCheck->execute();
    $isResearcher = $researcherCheck->get_result()->num_rows > 0;
    $researcherCheck->close();
}

// Get queue stats for sidebar badge
$queueStats = ['total' => 0];
if ($isCoordinator || $isROAdmin || $isAdmin) {
    $queueService = new UnifiedQueueService($conn, $currentUserId);
    $queueStats = $queueService->getQueueStats();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Research Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="researchStyle.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
    <style>
        /* SPA Specific Styles */
        .spa-loading {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #064e1a, #10b981, #064e1a);
            background-size: 200% 100%;
            animation: loading-bar 1.5s infinite;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .spa-loading.active {
            opacity: 1;
        }
        
        @keyframes loading-bar {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        
        .main-content {
            opacity: 1;
            transition: opacity 0.2s ease;
            min-height: 100vh;
            background: #f8fafc;
        }
        
        .main-content.loading {
            opacity: 0.5;
            pointer-events: none;
        }
        
        /* Sidebar active state animation */
        .sidebar-nav a {
            position: relative;
            overflow: hidden;
        }
        
        .sidebar-nav a::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: white;
            transform: scaleY(0);
            transition: transform 0.2s ease;
        }
        
        .sidebar-nav a.active::after {
            transform: scaleY(1);
        }
        
        /* Queue badge in sidebar */
        .queue-badge {
            background: #ef4444;
            color: white;
            font-size: 11px;
            font-weight: 600;
            padding: 2px 7px;
            border-radius: 10px;
            margin-left: auto;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        
        .sidebar-nav a {
            display: flex;
            align-items: center;
        }
        
        .sidebar-nav a i {
            width: 20px;
            margin-right: 10px;
        }

        /* Page transition */
        .page-enter {
            animation: pageEnter 0.3s ease forwards;
        }
        
        @keyframes pageEnter {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- Loading Bar -->
    <div class="spa-loading" id="loadingBar"></div>

    <!-- Sidebar - This stays constant -->
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="essu.png" alt="logo">
            <h3>Research Management</h3>
        </div>
        <div class="sidebar-nav">
            <?php if ($userRole === 'researcher'): ?>
            <a href="researcher_dashboard.php" data-page="researcher_dashboard" class="spa-link <?= $initialPage === 'researcher_dashboard' || $initialPage === 'dashboard' ? 'active' : '' ?>">
                <i class="fa fa-dashboard"></i> Dashboard
            </a>
            <?php else: ?>
            <a href="research.php" data-page="dashboard" class="spa-link <?= $initialPage === 'dashboard' ? 'active' : '' ?>">
                <i class="fa fa-dashboard"></i> Dashboard
            </a>
            <?php endif; ?>
            
            <!-- Research Workflow Section -->
            <?php if ($isResearcher || $isCoordinator || $isROAdmin): ?>
            <div class="sidebar-section-title" style="padding: 12px 20px 6px; font-size: 11px; text-transform: uppercase; color: rgba(255,255,255,0.5); letter-spacing: 1px;">
                Research Workflow
            </div>
            <?php endif; ?>
            <?php if ($isResearcher || $isCoordinator): ?>
            <a href="researcher_submissions.php" data-page="submissions" class="spa-link <?= $initialPage === 'submissions' ? 'active' : '' ?>">
                <i class="fa fa-file-lines"></i> My Submissions
            </a>
            <a href="researcher_projects.php" data-page="projects" class="spa-link <?= $initialPage === 'projects' ? 'active' : '' ?>">
                <i class="fa fa-flask"></i> My Projects
            </a>
            <?php endif; ?>
            <?php if ($isCoordinator || $isROAdmin || $isAdmin): ?>
            <!-- Unified Work Queue -->
            <a href="work_queue.php" data-page="work_queue" class="spa-link <?= $initialPage === 'work_queue' ? 'active' : '' ?>">
                <i class="fa fa-inbox"></i> Work Queue
                <?php if ($queueStats['total'] > 0): ?>
                <span class="queue-badge" id="sidebar-queue-badge"><?= $queueStats['total'] ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>
            <?php if ($isCoordinator): ?>
            <a href="coordinator_projects.php" data-page="coordinator_projects" class="spa-link <?= $initialPage === 'coordinator_projects' ? 'active' : '' ?>">
                <i class="fa fa-folder-open"></i> Unit Projects
            </a>
            <?php endif; ?>
            <?php if ($isROAdmin && !$isAdmin): ?>
            <a href="admin_projects.php" data-page="admin_projects" class="spa-link <?= $initialPage === 'admin_projects' ? 'active' : '' ?>">
                <i class="fa fa-folder-tree"></i> All Projects
            </a>
            <?php endif; ?>
            <?php if ($isAdmin): ?>
            <a href="admin_projects.php" data-page="admin_projects" class="spa-link <?= $initialPage === 'admin_projects' ? 'active' : '' ?>">
                <i class="fa fa-folder-tree"></i> All Projects
            </a>
            <?php endif; ?>
            
            <!-- Researcher Records Section (hidden for pure researchers) -->
            <?php if ($userRole !== 'researcher'): ?>
            <div class="sidebar-section-title" style="padding: 12px 20px 6px; font-size: 11px; text-transform: uppercase; color: rgba(255,255,255,0.5); letter-spacing: 1px;">
                Researcher Records
            </div>
            <?php if ($showFaculty): ?>
            <a href="facultyresearcher.php" data-page="faculty" class="spa-link <?= $initialPage === 'faculty' ? 'active' : '' ?>">
                <i class="fa fa-chalkboard-teacher"></i> Faculty
            </a>
            <?php endif; ?>
            <?php if ($showStudent): ?>
            <a href="studentresearcher.php" data-page="students" class="spa-link <?= $initialPage === 'students' ? 'active' : '' ?>">
                <i class="fa fa-user-graduate"></i> Students
            </a>
            <?php endif; ?>
            <?php if ($showPersonnel): ?>
            <a href="personnelresearcher.php" data-page="personnel" class="spa-link <?= $initialPage === 'personnel' ? 'active' : '' ?>">
                <i class="fa fa-briefcase"></i> Personnel
            </a>
            <?php endif; ?>
            <?php endif; ?>
            
            <?php if ($isAdmin): ?>
            <!-- Administration Section -->
            <div class="sidebar-section-title" style="padding: 12px 20px 6px; font-size: 11px; text-transform: uppercase; color: rgba(255,255,255,0.5); letter-spacing: 1px;">
                Administration
            </div>
            <a href="users.php" data-page="users" class="spa-link <?= $initialPage === 'users' ? 'active' : '' ?>">
                <i class="fa fa-users-gear"></i> User Management
            </a>
            <a href="oauth_settings.php" data-page="oauth" class="spa-link <?= $initialPage === 'oauth' ? 'active' : '' ?>">
                <i class="fa fa-key"></i> SSO Settings
            </a>
            <a href="assign_coordinators.php" data-page="coordinators" class="spa-link <?= $initialPage === 'coordinators' ? 'active' : '' ?>">
                <i class="fa fa-user-tie"></i> Assign Coordinators
            </a>
            <a href="activity_logs.php" data-page="logs" class="spa-link <?= $initialPage === 'logs' ? 'active' : '' ?>">
                <i class="fa fa-history"></i> Activity Logs
            </a>
            <?php endif; ?>
            
        </div>
        <div class="sidebar-footer">
            <a href="logout.php" class="logout-link" onclick="return confirmLogout(event)">
                <i class="fa fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    
    <!-- Logout Confirmation Modal -->
    <div id="logoutModal" class="logout-modal">
        <div class="logout-modal-content">
            <div class="logout-modal-icon">
                <i class="fa fa-sign-out-alt"></i>
            </div>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to logout?</p>
            <div class="logout-modal-buttons">
                <button class="btn-cancel" onclick="closeLogoutModal()">Cancel</button>
                <button class="btn-confirm" onclick="proceedLogout()">Yes, Logout</button>
            </div>
        </div>
    </div>
    
    <script>
        function confirmLogout(event) {
            event.preventDefault();
            document.getElementById('logoutModal').classList.add('active');
            return false;
        }
        
        function closeLogoutModal() {
            document.getElementById('logoutModal').classList.remove('active');
        }
        
        function proceedLogout() {
            window.location.href = 'logout.php';
        }
        
        // Close modal when clicking outside
        document.getElementById('logoutModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeLogoutModal();
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeLogoutModal();
            }
        });
    </script>

    <!-- Main Content Area - This gets updated -->
    <div class="main">
        <div class="main-content" id="mainContent">
            <!-- Content will be loaded here -->
            <div style="display: flex; justify-content: center; align-items: center; height: 80vh;">
                <div style="text-align: center;">
                    <i class="fa fa-spinner fa-spin" style="font-size: 48px; color: #064e1a;"></i>
                    <p style="margin-top: 15px; color: #6b7280;">Loading...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- SPA Configuration -->
    <script>
        window.SPA_CONFIG = {
            userRole: '<?= $userRole ?>',
            coordinatorType: '<?= $coordinatorType ?>',
            userId: <?= $currentUserId ?>,
            fullname: '<?= addslashes($fullname) ?>',
            showFaculty: <?= $showFaculty ? 'true' : 'false' ?>,
            showStudent: <?= $showStudent ? 'true' : 'false' ?>,
            showPersonnel: <?= $showPersonnel ? 'true' : 'false' ?>,
            isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
            isCoordinator: <?= $isCoordinator ? 'true' : 'false' ?>,
            isROAdmin: <?= $isROAdmin ? 'true' : 'false' ?>,
            isResearcher: <?= $isResearcher ? 'true' : 'false' ?>
        };
    </script>
    <script src="spa.js"></script>
    
    <!-- Load initial page -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            
            // Check if redirected from a page with 'load' parameter
            const loadUrl = urlParams.get('load');
            if (loadUrl) {
                // Load the requested page and update URL
                if (window.SPA) {
                    window.SPA.loadPage(loadUrl, true);
                }
                return;
            }
            
            // Otherwise, determine initial page from 'page' parameter
            const page = urlParams.get('page') || 'dashboard';
            
            // Map page param to actual PHP file
            const pageMap = {
                'dashboard': 'research.php',
                'submissions': 'researcher_submissions.php',
                'projects': 'researcher_projects.php',
                'collaborations': 'researcher_collaborations.php',
                'work_queue': 'work_queue.php',
                'coordinator_queue': 'coordinator_queue.php',
                'coordinator_ext_queue': 'coordinator_extension_queue.php',
                'coordinator_projects': 'coordinator_projects.php',
                'ro_queue': 'research_office_queue.php',
                'ro_ext_queue': 'research_office_extension_queue.php',
                'admin_projects': 'admin_projects.php',
                'faculty': 'facultyresearcher.php',
                'students': 'studentresearcher.php',
                'personnel': 'personnelresearcher.php',
                'users': 'users.php',
                'oauth': 'oauth_settings.php',
                'coordinators': 'assign_coordinators.php',
                'logs': 'activity_logs.php'
            };
            
            const targetUrl = pageMap[page] || 'research.php';
            
            // Load initial content
            if (window.SPA) {
                window.SPA.loadPage(targetUrl, false);
            }
            
            // Function to refresh sidebar queue badge
            function refreshSidebarBadge() {
                fetch('work_queue_api.php?action=get_stats')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.stats) {
                            const badge = document.getElementById('sidebar-queue-badge');
                            const count = data.stats.total || 0;
                            if (count > 0) {
                                if (badge) {
                                    badge.textContent = count;
                                    badge.style.display = '';
                                } else {
                                    // Create badge if it doesn't exist
                                    const queueLink = document.querySelector('a[data-page="work_queue"]');
                                    if (queueLink) {
                                        const newBadge = document.createElement('span');
                                        newBadge.className = 'queue-badge';
                                        newBadge.id = 'sidebar-queue-badge';
                                        newBadge.textContent = count;
                                        queueLink.appendChild(newBadge);
                                    }
                                }
                            } else if (badge) {
                                badge.style.display = 'none';
                            }
                        }
                    })
                    .catch(err => console.log('Badge refresh error:', err));
            }
            
            // Refresh badge every 60 seconds
            setInterval(refreshSidebarBadge, 60000);
        });
    </script>
</body>
</html>
