/**
 * Faculty Researcher Form Script - COMPLETE WITH PAGINATION
 * Handles search, selection, and import of employees from HR System
 */

// Wrap in IIFE to prevent duplicate declaration errors in SPA
(function() {
    'use strict';
    
    // Check if already initialized for THIS page instance
    const container = document.getElementById('searchInput');
    if (container && container.dataset.initialized === 'true') {
        console.log('⚠️ Faculty Form already initialized for this page instance, skipping...');
        return;
    }
    
    console.log('🚀 Faculty Form Script Loading...');

    // Global state (scoped to this IIFE)
    let selectedEmployee = null;
    let searchTimeout = null;
    let currentPage = 1;
    let totalPages = 1;
    let currentQuery = '';

    // Initialize function
    function initFacultyForm() {
        console.log('✅ DOM Ready, initializing...');
        
        // Get DOM elements
        const searchInput = document.getElementById('searchInput');
        
        // Mark as initialized for this page instance
        if (searchInput) {
            searchInput.dataset.initialized = 'true';
        }
        
        const loadingState = document.getElementById('loadingState');
        const resultsSection = document.getElementById('resultsSection');
        const emptyState = document.getElementById('emptyState');
        const employeeList = document.getElementById('employeeList');
        const resultsCount = document.getElementById('resultsCount');
        const previewSection = document.getElementById('previewSection');
        const previewGrid = document.getElementById('previewGrid');
        const importBtn = document.getElementById('importBtn');
    
    // Verify all elements exist
    if (!searchInput || !importBtn || !previewSection) {
        console.error('❌ Critical DOM elements missing!');
        return;
    }
    
    console.log('✅ All critical DOM elements found');
    
    // ============================================
    // SEARCH INPUT HANDLER
    // ============================================
    searchInput.addEventListener('input', function(e) {
        const query = e.target.value.trim();
        
        // Clear previous timeout
        if (searchTimeout) {
            clearTimeout(searchTimeout);
        }
        
        // Debounce search (wait 500ms after user stops typing)
        searchTimeout = setTimeout(() => {
            if (query.length >= 2) {
                searchEmployees(query, 1);
            } else if (query.length === 0) {
                clearResults();
            }
        }, 500);
    });
    
    // Search on Enter key
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const query = e.target.value.trim();
            if (query.length >= 2) {
                searchEmployees(query, 1);
            }
        }
    });
    
    // ============================================
    // IMPORT BUTTON HANDLER
    // ============================================
    importBtn.addEventListener('click', async function() {
        console.log('🎯 Import button clicked!');
        
        if (!selectedEmployee) {
            alert('⚠️ Please select an employee first');
            return;
        }
        
        // Get employee ID - try multiple possible field names
        const employeeId = selectedEmployee.id || 
                          selectedEmployee.employee_id || 
                          selectedEmployee.hr_employee_id;
        
        console.log('📤 Importing employee with ID:', employeeId);
        
        if (!employeeId) {
            alert('❌ Employee ID not found. Please try selecting the employee again.');
            console.error('❌ No employee ID in:', selectedEmployee);
            return;
        }
        
        // Confirm import
        const employeeName = selectedEmployee.full_name || 
                            (selectedEmployee.first_name + ' ' + selectedEmployee.last_name);
        
        if (!confirm(`Import ${employeeName} to the Research Management System?`)) {
            return;
        }
        
        // Disable button and show loading
        importBtn.disabled = true;
        const originalText = importBtn.innerHTML;
        importBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Importing...';
        
        try {
            // Send import request
            const formData = new FormData();
            formData.append('action', 'import');
            formData.append('employee_id', employeeId);
            
            console.log('📡 Sending import request...');
            
            const response = await fetch('fetch_employee.php', {
                method: 'POST',
                body: formData
            });
            
            console.log('📥 Import response status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('📊 Import response data:', data);
            
            if (data.success) {
                console.log('✅ Import successful!');
                
                // Show success message
                showAlert('success', '✅ Employee imported successfully!');
                
                // Redirect after 1.5 seconds
                setTimeout(() => {
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else if (data.faculty_id) {
                        window.location.href = 'facultyresearcherprofile.php?id=' + data.faculty_id;
                    } else {
                        window.location.href = 'facultyresearcher.php';
                    }
                }, 1500);
            } else {
                // Check if it's a deletion error
                if (data.status === 'deleted') {
                    showAlert('error', data.message || 'This employee no longer exists in the HR System');
                } else if (data.existing_id) {
                    showAlert('error', `This employee is already imported. <a href="facultyresearcherprofile.php?id=${data.existing_id}" style="color: white; text-decoration: underline;">View Profile</a>`, true);
                } else {
                    throw new Error(data.error || 'Import failed');
                }
                
                importBtn.disabled = false;
                importBtn.innerHTML = originalText;
            }
            
        } catch (error) {
            console.error('❌ Import failed:', error);
            showAlert('error', 'Import failed: ' + error.message);
            importBtn.disabled = false;
            importBtn.innerHTML = originalText;
        }
    });
    
    // ============================================
    // SEARCH EMPLOYEES WITH PAGINATION
    // ============================================
    async function searchEmployees(query, page = 1) {
        console.log('🔍 Searching for:', query, 'Page:', page);
        
        currentQuery = query;
        currentPage = page;
        
        showLoading();
        
        try {
            const url = `fetch_employee.php?action=search&q=${encodeURIComponent(query)}&page=${page}`;
            console.log('📡 Fetching:', url);
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('📊 Search results:', data);
            
            if (data.success) {
                if (data.data && data.data.length > 0) {
                    console.log('✅ Found', data.data.length, 'employees');
                    totalPages = data.last_page || 1;
                    displayResults(data);
                } else {
                    totalPages = 1;
                    showEmptyState('No employees found matching "' + query + '"');
                }
            } else {
                throw new Error(data.error || 'Search failed');
            }
            
        } catch (error) {
            console.error('❌ Search error:', error);
            showAlert('error', 'Search failed: ' + error.message);
            showEmptyState('Search failed. Please try again.');
        }
    }
    
    // Make searchEmployees available globally for pagination
    window.searchEmployees = searchEmployees;
    
    // ============================================
    // DISPLAY SEARCH RESULTS WITH PAGINATION
    // ============================================
    function displayResults(data) {
        console.log('📋 Displaying results');
        
        hideLoading();
        emptyState.style.display = 'none';
        resultsSection.classList.add('show');
        
        const employees = data.data || [];
        const total = data.total || employees.length;
        
        resultsCount.textContent = total;
        
        // Clear previous results
        employeeList.innerHTML = '';
        
        // Display employees
        employees.forEach((employee, index) => {
            const empId = employee.id || employee.employee_id;
            const fullName = employee.full_name || 
                           (employee.first_name + ' ' + employee.last_name);
            
            const card = document.createElement('div');
            card.className = 'employee-card';
            card.setAttribute('data-employee-id', empId);
            
            card.innerHTML = `
                <div class="employee-info">
                    <div class="employee-details">
                        <h3>${escapeHtml(fullName)}</h3>
                        <div class="employee-meta">
                            <span><i class="fa fa-id-badge"></i> ${escapeHtml(empId)}</span>
                            <span><i class="fa fa-envelope"></i> ${escapeHtml(employee.email || 'N/A')}</span>
                            <span><i class="fa fa-building"></i> ${escapeHtml(employee.department || 'N/A')}</span>
                            <span><i class="fa fa-briefcase"></i> ${escapeHtml(employee.position || 'N/A')}</span>
                        </div>
                    </div>
                    <div class="radio-indicator"></div>
                </div>
            `;
            
            // Store full employee data on the card
            card._employeeData = employee;
            
            // Add click handler
            card.addEventListener('click', function() {
                selectEmployee(this._employeeData, this);
            });
            
            employeeList.appendChild(card);
        });
        
        // Render pagination
        renderPagination(data);
        
        console.log('✅ Results displayed');
    }
    
    // ============================================
    // RENDER PAGINATION CONTROLS
    // ============================================
    function renderPagination(data) {
        // Remove existing pagination
        const existingPagination = document.querySelector('.search-pagination');
        if (existingPagination) {
            existingPagination.remove();
        }
        
        if (totalPages <= 1) {
            return; // No pagination needed
        }
        
        const pagination = document.createElement('div');
        pagination.className = 'search-pagination';
        
        let html = '<div class="pagination-info">';
        html += `Showing ${data.from || 1} to ${data.to || data.data.length} of ${data.total} employees`;
        html += '</div><div class="pagination-controls">';
        
        // Previous button
        if (currentPage > 1) {
            html += `<button class="pagination-btn" onclick="searchEmployees('${escapeJs(currentQuery)}', ${currentPage - 1})">
                <i class="fa fa-chevron-left"></i> Previous
            </button>`;
        }
        
        // Page numbers with smart ellipsis
        const maxVisible = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
        let endPage = Math.min(totalPages, startPage + maxVisible - 1);
        
        if (endPage - startPage < maxVisible - 1) {
            startPage = Math.max(1, endPage - maxVisible + 1);
        }
        
        // First page
        if (startPage > 1) {
            html += `<button class="pagination-btn" onclick="searchEmployees('${escapeJs(currentQuery)}', 1)">1</button>`;
            if (startPage > 2) {
                html += '<span class="pagination-ellipsis">...</span>';
            }
        }
        
        // Page numbers
        for (let i = startPage; i <= endPage; i++) {
            const activeClass = i === currentPage ? 'active' : '';
            html += `<button class="pagination-btn ${activeClass}" onclick="searchEmployees('${escapeJs(currentQuery)}', ${i})">${i}</button>`;
        }
        
        // Last page
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += '<span class="pagination-ellipsis">...</span>';
            }
            html += `<button class="pagination-btn" onclick="searchEmployees('${escapeJs(currentQuery)}', ${totalPages})">${totalPages}</button>`;
        }
        
        // Next button
        if (currentPage < totalPages) {
            html += `<button class="pagination-btn" onclick="searchEmployees('${escapeJs(currentQuery)}', ${currentPage + 1})">
                Next <i class="fa fa-chevron-right"></i>
            </button>`;
        }
        
        html += '</div>';
        pagination.innerHTML = html;
        
        resultsSection.appendChild(pagination);
    }
    
    // ============================================
    // SELECT EMPLOYEE
    // ============================================
    function selectEmployee(employeeData, clickedCard) {
        const empId = employeeData.id || employeeData.employee_id;
        console.log('🎯 Employee selected:', empId);
        
        // Remove selected class from all cards
        const allCards = employeeList.querySelectorAll('.employee-card');
        allCards.forEach(c => c.classList.remove('selected'));
        
        // Mark clicked card as selected
        if (clickedCard) {
            clickedCard.classList.add('selected');
        }
        
        // Store selected employee
        selectedEmployee = employeeData;
        
        // Display preview
        displayPreview(employeeData);
        
        // Enable import button
        importBtn.disabled = false;
        
        console.log('✅ Employee selected successfully');
    }
    
    // ============================================
    // DISPLAY PREVIEW
    // ============================================
    function displayPreview(employee) {
        console.log('👁️ Displaying preview');
        
        const fullName = employee.full_name || 
                        ((employee.first_name || '') + ' ' + 
                         (employee.middle_name || '') + ' ' + 
                         (employee.last_name || '')).trim();
        
        previewGrid.innerHTML = `
            <div class="preview-item">
                <div class="preview-label">Employee ID</div>
                <div class="preview-value">${escapeHtml(employee.id || employee.employee_id || 'N/A')}</div>
            </div>
            <div class="preview-item">
                <div class="preview-label">Full Name</div>
                <div class="preview-value">${escapeHtml(fullName)}</div>
            </div>
            <div class="preview-item">
                <div class="preview-label">Email</div>
                <div class="preview-value">${escapeHtml(employee.email || 'N/A')}</div>
            </div>
            <div class="preview-item">
                <div class="preview-label">Department</div>
                <div class="preview-value">${escapeHtml(employee.department || 'N/A')}</div>
            </div>
            <div class="preview-item">
                <div class="preview-label">Position</div>
                <div class="preview-value">${escapeHtml(employee.position || employee.faculty_rank || 'N/A')}</div>
            </div>
            <div class="preview-item preview-full">
                <div class="preview-label">Status</div>
                <div class="preview-value">${escapeHtml(employee.employment_status || 'Active')}</div>
            </div>
        `;
        
        previewSection.classList.add('show');
        
        // Scroll to preview
        previewSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    // ============================================
    // UTILITY FUNCTIONS
    // ============================================
    
    function showLoading() {
        loadingState.style.display = 'block';
        resultsSection.classList.remove('show');
        emptyState.style.display = 'none';
        previewSection.classList.remove('show');
    }
    
    function hideLoading() {
        loadingState.style.display = 'none';
    }
    
    function clearResults() {
        employeeList.innerHTML = '';
        resultsSection.classList.remove('show');
        emptyState.style.display = 'flex';
        previewSection.classList.remove('show');
        selectedEmployee = null;
        importBtn.disabled = true;
        currentPage = 1;
        totalPages = 1;
    }
    
    function showEmptyState(message) {
        hideLoading();
        resultsSection.classList.remove('show');
        previewSection.classList.remove('show');
        emptyState.style.display = 'flex';
        
        if (message) {
            emptyState.innerHTML = `
                <i class="fa fa-search"></i>
                <h3>No Results</h3>
                <p>${escapeHtml(message)}</p>
            `;
        } else {
            emptyState.innerHTML = `
                <i class="fa fa-search"></i>
                <h3>Start Your Search</h3>
                <p>Enter a name, email, or employee ID to search for faculty in the HR System</p>
            `;
        }
    }
    
    function showAlert(type, message, allowHtml = false) {
        // Remove existing alerts
        const existingAlerts = document.querySelectorAll('.alert-custom');
        existingAlerts.forEach(alert => alert.remove());
        
        const alert = document.createElement('div');
        alert.className = `alert-custom alert-${type}`;
        
        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
        
        if (allowHtml) {
            alert.innerHTML = `<i class="fa ${icon}"></i> <div>${message}</div>`;
        } else {
            alert.innerHTML = `<i class="fa ${icon}"></i> <div>${escapeHtml(message)}</div>`;
        }
        
        // Insert at top of card body
        const cardBody = document.querySelector('.card-body');
        if (cardBody) {
            cardBody.insertBefore(alert, cardBody.firstChild);
            
            // Auto-remove after 10 seconds
            setTimeout(() => alert.remove(), 10000);
        }
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }
    
    function escapeJs(text) {
        return (text || '').replace(/'/g, "\\'").replace(/"/g, '\\"');
    }
    
    console.log('✅ Faculty Form Script Initialized');
    }
    
    // Initialize when DOM is ready or immediately if already loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initFacultyForm);
    } else {
        // DOM already loaded (SPA navigation)
        initFacultyForm();
    }

    // Add required CSS for pagination and alerts (only once)
    if (!document.getElementById('faculty-form-styles')) {
        const style = document.createElement('style');
        style.id = 'faculty-form-styles';
style.textContent = `
    .search-pagination {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 2px solid var(--gray-200, #e5e7eb);
    }
    
    .pagination-info {
        text-align: center;
        color: var(--gray-500, #6b7280);
        font-size: 14px;
        margin-bottom: 15px;
    }
    
    .pagination-controls {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .pagination-btn {
        padding: 8px 12px;
        background: white;
        border: 2px solid var(--gray-200, #e5e7eb);
        color: var(--gray-700, #374151);
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }
    
    .pagination-btn:hover:not(.active) {
        background: var(--gray-100, #f3f4f6);
        border-color: var(--gray-300, #d1d5db);
    }
    
    .pagination-btn.active {
        background: var(--primary, #064e1a);
        color: white;
        border-color: var(--primary, #064e1a);
    }
    
    .pagination-ellipsis {
        padding: 8px;
        color: var(--gray-500, #6b7280);
    }
    
    .alert-custom {
        padding: 15px 20px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
        animation: slideIn 0.3s ease;
    }
    
    .alert-custom i {
        font-size: 20px;
    }
    
    .alert-error {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
    }
    
    .alert-success {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
        document.head.appendChild(style);
    }
})();