<?php
/**
 * SubmissionService.php
 * CRUD operations and business logic for research submissions
 * 
 * This service handles:
 * - Creating new submissions (draft)
 * - Updating submission content
 * - Fetching submissions with filters
 * - Managing attachments
 * - Role-based querying
 * 
 * @version 1.0
 */

require_once __DIR__ . '/WorkflowEngine.php';
require_once __DIR__ . '/WorkflowAuditLogger.php';

class SubmissionService {
    private $conn;
    private $workflowEngine;
    private $auditLogger;
    private $userId;
    private $userRole;
    private $employeeId;
    
    // Upload directory for attachments
    const UPLOAD_DIR = 'uploads/submissions/';
    const MAX_FILE_SIZE = 52428800; // 50MB
    const ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'jpg', 'jpeg', 'png', 'gif'];
    
    /**
     * Constructor
     */
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        $this->workflowEngine = new WorkflowEngine($dbConnection);
        $this->auditLogger = new WorkflowAuditLogger($dbConnection);
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        
        // Ensure upload directory exists
        $this->ensureUploadDirectory();
    }
    
    /**
     * Get workflow engine instance
     */
    public function getWorkflowEngine() {
        return $this->workflowEngine;
    }
    
    // ========================================
    // SUBMISSION CRUD OPERATIONS
    // ========================================
    
    /**
     * Create a new submission (draft status)
     * 
     * @param array $data - Submission data
     * @return array - Result with success/error
     */
    public function create(array $data) {
        // Validate required fields
        if (empty($data['title'])) {
            return ['success' => false, 'error' => 'Title is required'];
        }
        
        if (empty($data['submission_type_id'])) {
            return ['success' => false, 'error' => 'Submission type is required'];
        }
        
        if (empty($data['researcher_type']) || empty($data['researcher_id'])) {
            return ['success' => false, 'error' => 'Researcher information is required'];
        }
        
        // Check if submission type requires a project
        // All types except 'proposal' require an approved project
        $projectBasedTypeCodes = ['ongoing', 'extension', 'output', 'completed', 'completion', 'amendment', 'progress'];
        $typeCheck = $this->conn->prepare("SELECT type_code FROM research_submission_types WHERE id = ?");
        $typeCheck->bind_param("i", $data['submission_type_id']);
        $typeCheck->execute();
        $typeResult = $typeCheck->get_result()->fetch_assoc();
        $typeCheck->close();
        
        if ($typeResult && in_array($typeResult['type_code'], $projectBasedTypeCodes)) {
            // This submission type requires an approved project
            // Project-based submissions must be created from My Projects page
            if (empty($data['project_id'])) {
                return [
                    'success' => false, 
                    'error' => 'This submission type must be created from an approved project. Go to My Projects and select the project you want to create this submission for.'
                ];
            }
            
            // Validate that the project exists, is approved, and belongs to this researcher
            $projectCheck = $this->conn->prepare("
                SELECT id, project_status, researcher_type, researcher_id 
                FROM research_submissions 
                WHERE id = ? 
                  AND status = 'approved' 
                  AND project_status IN ('on_going', 'extended')
            ");
            $projectCheck->bind_param("i", $data['project_id']);
            $projectCheck->execute();
            $projectResult = $projectCheck->get_result()->fetch_assoc();
            $projectCheck->close();
            
            if (!$projectResult) {
                return [
                    'success' => false, 
                    'error' => 'The selected project is not valid or is not approved.'
                ];
            }
            
            // Verify ownership
            if ($projectResult['researcher_type'] !== $data['researcher_type'] || 
                $projectResult['researcher_id'] != $data['researcher_id']) {
                return [
                    'success' => false, 
                    'error' => 'You do not have permission to create submissions for this project.'
                ];
            }
            
        }
        
        try {
            $this->conn->begin_transaction();
            
            // Get researcher unit info for routing
            $researcherInfo = $this->getResearcherInfo($data['researcher_type'], $data['researcher_id']);
            if (!$researcherInfo) {
                throw new Exception('Researcher not found');
            }
            
            // Prepare parent_project_id (null for proposals, set for project-based submissions)
            $parentProjectId = !empty($data['project_id']) ? intval($data['project_id']) : null;
            
            $stmt = $this->conn->prepare("
                INSERT INTO research_submissions (
                    submission_type_id,
                    parent_project_id,
                    researcher_type,
                    researcher_id,
                    researcher_user_id,
                    researcher_unit_id,
                    researcher_unit_name,
                    title,
                    abstract,
                    objectives,
                    methodology,
                    expected_outcomes,
                    proposed_start_date,
                    proposed_end_date,
                    total_budget,
                    budget_breakdown,
                    status,
                    current_handler_type,
                    current_handler_id,
                    created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', 'researcher', ?, ?)
            ");
            
            $budgetBreakdown = !empty($data['budget_breakdown']) 
                ? json_encode($data['budget_breakdown']) 
                : null;
            
            $stmt->bind_param(
                "iisissssssssssdsii",
                $data['submission_type_id'],
                $parentProjectId,
                $data['researcher_type'],
                $data['researcher_id'],
                $researcherInfo['user_id'],
                $researcherInfo['unit_id'],
                $researcherInfo['unit_name'],
                $data['title'],
                $data['abstract'],
                $data['objectives'],
                $data['methodology'],
                $data['expected_outcomes'],
                $data['proposed_start_date'],
                $data['proposed_end_date'],
                $data['total_budget'],
                $budgetBreakdown,
                $this->userId,
                $this->userId
            );
            
            $stmt->execute();
            $submissionId = $this->conn->insert_id;
            $stmt->close();
            
            // Log creation with project link if applicable
            $logMetadata = [
                'title' => $data['title'],
                'type_id' => $data['submission_type_id']
            ];
            if (!empty($data['project_id'])) {
                $logMetadata['parent_project_id'] = $data['project_id'];
                $logMetadata['submission_linked_to_project'] = true;
            }
            
            $this->auditLogger->log($submissionId, 'created', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'new_status' => 'draft',
                'metadata' => $logMetadata
            ]);
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'message' => 'Submission created successfully',
                'submission_id' => $submissionId
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("SubmissionService::create error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Update an existing submission
     * Only allowed if user owns the current status
     * 
     * @param int $submissionId
     * @param array $data
     * @return array
     */
    public function update($submissionId, array $data) {
        $submission = $this->getById($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        // Check if user can edit based on workflow status
        if (!$this->workflowEngine->canEdit($submission)) {
            return ['success' => false, 'error' => 'You are not authorized to edit this submission at its current status'];
        }
        
        try {
            // Build update query dynamically based on provided fields
            $updates = [];
            $params = [];
            $types = '';
            
            $allowedFields = [
                'title' => 's',
                'abstract' => 's',
                'objectives' => 's',
                'methodology' => 's',
                'expected_outcomes' => 's',
                'proposed_start_date' => 's',
                'proposed_end_date' => 's',
                'total_budget' => 'd'
            ];
            
            foreach ($allowedFields as $field => $type) {
                if (isset($data[$field])) {
                    $updates[] = "$field = ?";
                    $params[] = $data[$field];
                    $types .= $type;
                }
            }
            
            // Handle budget breakdown separately (JSON)
            if (isset($data['budget_breakdown'])) {
                $updates[] = "budget_breakdown = ?";
                $params[] = json_encode($data['budget_breakdown']);
                $types .= 's';
            }
            
            if (empty($updates)) {
                return ['success' => false, 'error' => 'No fields to update'];
            }
            
            $updates[] = "updated_at = NOW()";
            $params[] = $submissionId;
            $types .= 'i';
            
            $sql = "UPDATE research_submissions SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'message' => 'Submission updated successfully'];
            
        } catch (Exception $e) {
            error_log("SubmissionService::update error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get submission by ID with full details
     * 
     * @param int $submissionId
     * @return array|null
     */
    public function getById($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT 
                rs.*,
                rst.type_code,
                rst.type_name,
                rst.requires_ethics_clearance,
                rst.requires_budget,
                rst.requires_timeline
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE rs.id = ?
        ");
        
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result) {
            // Decode JSON fields
            if (!empty($result['budget_breakdown'])) {
                $result['budget_breakdown'] = json_decode($result['budget_breakdown'], true);
            }
            if (!empty($result['tags'])) {
                $result['tags'] = json_decode($result['tags'], true);
            }
            
            // Get researcher info
            $result['researcher'] = $this->getResearcherInfo($result['researcher_type'], $result['researcher_id']);
            
            // Get attachments
            $result['attachments'] = $this->getAttachments($submissionId);
            
            // Get allowed actions for current user
            $result['allowed_actions'] = $this->workflowEngine->getAllowedActions($result);
            
            // Get status label and class
            $result['status_label'] = WorkflowEngine::getStatusLabel($result['status']);
            $result['status_class'] = WorkflowEngine::getStatusClass($result['status']);
        }
        
        return $result;
    }
    
    /**
     * Get submissions for researcher dashboard
     * Shows only submissions created by or assigned to the current user
     */
    public function getResearcherSubmissions($filters = [], $page = 1, $perPage = 20) {
        $where = ["(rs.created_by = ? OR rs.researcher_user_id = ?)"];
        $params = [$this->userId, $this->userId];
        $types = "ii";
        
        // Apply filters
        if (!empty($filters['status'])) {
            $where[] = "rs.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }
        
        if (!empty($filters['type_id'])) {
            $where[] = "rs.submission_type_id = ?";
            $params[] = $filters['type_id'];
            $types .= 'i';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ?)";
            $search = "%" . $filters['search'] . "%";
            $params[] = $search;
            $params[] = $search;
            $types .= 'ss';
        }
        
        return $this->fetchSubmissions($where, $params, $types, $page, $perPage);
    }
    
    /**
     * Get submissions for coordinator queue
     * Shows submissions assigned to this coordinator OR matching their coordinator types
     */
    public function getCoordinatorQueue($filters = [], $page = 1, $perPage = 20) {
        // Get coordinator types for current user
        $coordinatorTypes = $this->getCoordinatorTypes();
        
        // Build the assignment/type matching condition
        $assignmentConditions = [];
        $params = [];
        $types = "";
        
        // Match by direct assignment (user_id or employee_id)
        $assignmentConditions[] = "rs.assigned_coordinator_id = ?";
        $params[] = $this->userId;
        $types .= "i";
        
        if (!empty($this->employeeId)) {
            $assignmentConditions[] = "rs.assigned_coordinator_employee_id COLLATE utf8mb4_general_ci = ?";
            $params[] = $this->employeeId;
            $types .= "s";
        }
        
        // Also match by coordinator type (faculty coordinator sees faculty submissions, etc.)
        if (!empty($coordinatorTypes)) {
            $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
            $assignmentConditions[] = "rs.researcher_type IN ($typePlaceholders)";
            $params = array_merge($params, $coordinatorTypes);
            $types .= str_repeat('s', count($coordinatorTypes));
        }
        
        // Combine assignment conditions with OR
        $where = ["(" . implode(" OR ", $assignmentConditions) . ")"];
        
        // Default to coordinator-relevant statuses
        $coordinatorStatuses = [
            WorkflowEngine::STATUS_SUBMITTED,
            WorkflowEngine::STATUS_UNDER_COORDINATOR_REVIEW
        ];
        
        if (!empty($filters['status'])) {
            $where[] = "rs.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        } else {
            $placeholders = implode(',', array_fill(0, count($coordinatorStatuses), '?'));
            $where[] = "rs.status IN ($placeholders)";
            $params = array_merge($params, $coordinatorStatuses);
            $types .= str_repeat('s', count($coordinatorStatuses));
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ?)";
            $search = "%" . $filters['search'] . "%";
            $params[] = $search;
            $params[] = $search;
            $types .= 'ss';
        }
        
        return $this->fetchSubmissions($where, $params, $types, $page, $perPage, 'submitted_at ASC');
    }
    
    /**
     * Get coordinator types for current user from coordinator_assignments
     */
    private function getCoordinatorTypes() {
        $types = [];
        
        if (empty($this->employeeId)) {
            return $types;
        }
        
        $stmt = $this->conn->prepare("
            SELECT coordinator_type 
            FROM coordinator_assignments 
            WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $types[] = $row['coordinator_type'];
        }
        $stmt->close();
        
        return $types;
    }
    
    /**
     * Get submissions for Research Office queue
     * Shows endorsed and under-review submissions
     */
    public function getResearchOfficeQueue($filters = [], $page = 1, $perPage = 20) {
        if (!$this->workflowEngine->isResearchOfficeAdmin()) {
            return ['data' => [], 'total' => 0, 'page' => $page, 'per_page' => $perPage];
        }
        
        // RO sees endorsed and under review submissions
        $roStatuses = [
            WorkflowEngine::STATUS_ENDORSED,
            WorkflowEngine::STATUS_UNDER_RO_REVIEW
        ];
        
        $where = [];
        $params = [];
        $types = "";
        
        if (!empty($filters['status'])) {
            $where[] = "rs.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        } else {
            $placeholders = implode(',', array_fill(0, count($roStatuses), '?'));
            $where[] = "rs.status IN ($placeholders)";
            $params = array_merge($params, $roStatuses);
            $types .= str_repeat('s', count($roStatuses));
        }
        
        // Optional: filter by assigned admin
        if (!empty($filters['assigned_to_me'])) {
            $where[] = "rs.assigned_ro_admin_id = ?";
            $params[] = $this->userId;
            $types .= 'i';
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ?)";
            $search = "%" . $filters['search'] . "%";
            $params[] = $search;
            $params[] = $search;
            $types .= 'ss';
        }
        
        return $this->fetchSubmissions($where, $params, $types, $page, $perPage, 'coordinator_endorsed_at ASC');
    }
    
    /**
     * Get all submissions (admin only)
     */
    public function getAllSubmissions($filters = [], $page = 1, $perPage = 20) {
        if ($this->userRole !== 'admin') {
            return ['data' => [], 'total' => 0, 'page' => $page, 'per_page' => $perPage];
        }
        
        $where = [];
        $params = [];
        $types = "";
        
        if (!empty($filters['status'])) {
            $where[] = "rs.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ?)";
            $search = "%" . $filters['search'] . "%";
            $params[] = $search;
            $params[] = $search;
            $types .= 'ss';
        }
        
        return $this->fetchSubmissions($where, $params, $types, $page, $perPage);
    }
    
    /**
     * Internal method to fetch submissions with common logic
     */
    private function fetchSubmissions($where, $params, $types, $page, $perPage, $orderBy = 'rs.created_at DESC') {
        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
        $offset = ($page - 1) * $perPage;
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM research_submissions rs $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Get data
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.project_code,
                rs.title,
                rs.status,
                rs.project_status,
                rs.rmis_form_mapping,
                rs.researcher_type,
                rs.researcher_id,
                rs.researcher_unit_name,
                rs.revision_count,
                rs.submitted_at,
                rs.coordinator_endorsed_at,
                rs.decision_at,
                rs.created_at,
                rs.created_by,
                rst.type_code,
                rst.type_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            $whereClause
            ORDER BY $orderBy
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Add status labels
        foreach ($data as &$row) {
            $row['status_label'] = WorkflowEngine::getStatusLabel($row['status']);
            $row['status_class'] = WorkflowEngine::getStatusClass($row['status']);
        }
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    // ========================================
    // ATTACHMENT MANAGEMENT
    // ========================================
    
    /**
     * Upload and attach a file to a submission
     */
    public function addAttachment($submissionId, $file, $attachmentType, $description = null, $isRequired = false) {
        $submission = $this->getById($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if (!$this->workflowEngine->canEdit($submission)) {
            return ['success' => false, 'error' => 'You cannot add attachments to this submission'];
        }
        
        // Validate file
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => 'File upload error'];
        }
        
        if ($file['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'error' => 'File size exceeds maximum allowed (50MB)'];
        }
        
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED_EXTENSIONS)) {
            return ['success' => false, 'error' => 'File type not allowed'];
        }
        
        try {
            // Generate unique filename
            $filename = uniqid('att_') . '_' . time() . '.' . $ext;
            $subDir = date('Y/m/');
            $uploadPath = self::UPLOAD_DIR . $subDir;
            
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            
            $fullPath = $uploadPath . $filename;
            
            if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
                throw new Exception('Failed to save uploaded file');
            }
            
            // Get MIME type
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($fullPath);
            
            $stmt = $this->conn->prepare("
                INSERT INTO submission_attachments (
                    submission_id, file_name, original_name, file_path, 
                    file_size, file_type, mime_type, attachment_type,
                    description, is_required, uploaded_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->bind_param(
                "isssissssii",
                $submissionId,
                $filename,
                $file['name'],
                $fullPath,
                $file['size'],
                $ext,
                $mimeType,
                $attachmentType,
                $description,
                $isRequired,
                $this->userId
            );
            
            $stmt->execute();
            $attachmentId = $this->conn->insert_id;
            $stmt->close();
            
            // Log attachment
            $this->auditLogger->log($submissionId, 'attachment_added', [
                'performed_by' => $this->userId,
                'metadata' => [
                    'attachment_id' => $attachmentId,
                    'filename' => $file['name'],
                    'type' => $attachmentType
                ]
            ]);
            
            return [
                'success' => true,
                'message' => 'Attachment uploaded successfully',
                'attachment_id' => $attachmentId
            ];
            
        } catch (Exception $e) {
            error_log("SubmissionService::addAttachment error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Remove an attachment
     */
    public function removeAttachment($attachmentId) {
        $stmt = $this->conn->prepare("
            SELECT sa.*, rs.status 
            FROM submission_attachments sa
            JOIN research_submissions rs ON sa.submission_id = rs.id
            WHERE sa.id = ?
        ");
        $stmt->bind_param("i", $attachmentId);
        $stmt->execute();
        $attachment = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$attachment) {
            return ['success' => false, 'error' => 'Attachment not found'];
        }
        
        // Get full submission to check edit permissions
        $submission = $this->getById($attachment['submission_id']);
        if (!$this->workflowEngine->canEdit($submission)) {
            return ['success' => false, 'error' => 'You cannot remove attachments from this submission'];
        }
        
        try {
            // Delete file
            if (file_exists($attachment['file_path'])) {
                unlink($attachment['file_path']);
            }
            
            // Delete record
            $stmt = $this->conn->prepare("DELETE FROM submission_attachments WHERE id = ?");
            $stmt->bind_param("i", $attachmentId);
            $stmt->execute();
            $stmt->close();
            
            // Log removal
            $this->auditLogger->log($attachment['submission_id'], 'attachment_removed', [
                'performed_by' => $this->userId,
                'metadata' => [
                    'attachment_id' => $attachmentId,
                    'filename' => $attachment['original_name']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Attachment removed'];
            
        } catch (Exception $e) {
            error_log("SubmissionService::removeAttachment error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get attachments for a submission
     */
    public function getAttachments($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT 
                sa.*,
                u.fullname as uploader_name
            FROM submission_attachments sa
            LEFT JOIN users u ON sa.uploaded_by = u.id
            WHERE sa.submission_id = ?
            ORDER BY sa.uploaded_at DESC
        ");
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $result;
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get researcher information based on type and ID
     */
    public function getResearcherInfo($type, $id) {
        $table = '';
        $userIdField = 'user_id';
        $unitField = 'department';
        
        switch ($type) {
            case 'faculty':
                $table = 'faculty_researchers';
                $unitField = 'home_unit';
                break;
            case 'student':
                $table = 'student_researchers';
                break;
            case 'personnel':
                $table = 'personnel_researchers';
                $unitField = 'office_unit';
                break;
            default:
                return null;
        }
        
        $stmt = $this->conn->prepare("
            SELECT 
                id,
                CONCAT(last_name, ', ', first_name, IFNULL(CONCAT(' ', middle_name), '')) as full_name,
                email,
                $unitField as unit_name,
                COALESCE(user_id, created_by) as user_id
            FROM $table
            WHERE id = ?
        ");
        
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result) {
            // Try to get HR unit ID for routing
            // For now, use unit name as ID (will be enhanced with HR integration)
            $result['unit_id'] = $result['unit_name'];
        }
        
        return $result;
    }
    
    /**
     * Get submission types
     */
    public function getSubmissionTypes() {
        $result = $this->conn->query("
            SELECT * FROM research_submission_types 
            WHERE is_active = 1 
            ORDER BY display_order ASC
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get comments for a submission
     */
    public function getComments($submissionId) {
        // Build visibility filter based on role
        $visibilityFilter = '';
        if ($this->userRole === 'coordinator') {
            $visibilityFilter = 'AND (sc.visible_to_coordinator = 1 OR sc.created_by = ?)';
        } elseif (!in_array($this->userRole, ['admin'])) {
            // Researcher view
            $visibilityFilter = 'AND (sc.visible_to_researcher = 1 OR sc.created_by = ?)';
        }
        
        $sql = "
            SELECT sc.*
            FROM submission_comments sc
            WHERE sc.submission_id = ?
            $visibilityFilter
            ORDER BY sc.created_at ASC
        ";
        
        $stmt = $this->conn->prepare($sql);
        
        if (!empty($visibilityFilter)) {
            $stmt->bind_param("ii", $submissionId, $this->userId);
        } else {
            $stmt->bind_param("i", $submissionId);
        }
        
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get workflow history for a submission
     */
    public function getHistory($submissionId) {
        return $this->auditLogger->getHistory($submissionId);
    }
    
    /**
     * Get endorsement summary
     */
    public function getEndorsementSummary($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT ces.*, u.fullname as coordinator_name
            FROM coordinator_endorsement_summary ces
            LEFT JOIN users u ON ces.coordinator_id = u.id
            WHERE ces.submission_id = ?
        ");
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Get submission statistics
     */
    public function getStatistics($scope = 'all') {
        $where = '';
        $params = [];
        $types = '';
        
        switch ($scope) {
            case 'researcher':
                $where = 'WHERE (created_by = ? OR researcher_user_id = ?)';
                $params = [$this->userId, $this->userId];
                $types = 'ii';
                break;
            case 'coordinator':
                $where = 'WHERE assigned_coordinator_id = ?';
                $params = [$this->userId];
                $types = 'i';
                break;
            case 'research_office':
                // RO sees all
                break;
        }
        
        $sql = "
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft,
                SUM(CASE WHEN status IN ('submitted', 'under_coordinator_review') THEN 1 ELSE 0 END) as pending_coordinator,
                SUM(CASE WHEN status IN ('endorsed', 'under_ro_review') THEN 1 ELSE 0 END) as pending_ro,
                SUM(CASE WHEN status = 'returned_for_revision' THEN 1 ELSE 0 END) as returned,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
            FROM research_submissions
            $where
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Ensure upload directory exists
     */
    private function ensureUploadDirectory() {
        if (!is_dir(self::UPLOAD_DIR)) {
            mkdir(self::UPLOAD_DIR, 0755, true);
        }
    }
}
