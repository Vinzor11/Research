<?php
/**
 * Project View Page
 * 
 * Displays an approved research project with:
 * - Project details and identifiers (reference number, project code)
 * - Locked fields indication
 * - Project lifecycle status
 * - Progress reports history
 * - Extensions history
 * - Research outputs
 * - Collaborations (records and requests)
 * - Post-approval actions
 * 
 * GUIDING PRINCIPLE: "Project pages are for managing research; decisions happen in the Work Queue."
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';
require_once 'CollaborationService.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Get project ID
$projectId = intval($_GET['id'] ?? 0);
if (!$projectId) {
    header("Location: researcher_projects.php");
    exit;
}

// Initialize services
$projectService = new ProjectService($conn);
$workflowEngine = $projectService->getWorkflowEngine();
$collaborationService = new CollaborationService($conn);

// Get project data
$project = $projectService->getProject($projectId);

if (!$project) {
    header("Location: researcher_projects.php?error=not_found");
    exit;
}

// Check access
$isCoordinator = $workflowEngine->isAssignedCoordinator($project);
$isROAdmin = $workflowEngine->isResearchOfficeAdmin();

// Determine if user is the actual researcher owner (NOT admin viewing)
$isActualOwner = ($project['created_by'] == $userId || $project['researcher_user_id'] == $userId);
$isOwner = $isActualOwner && $userRole !== 'admin' && !$isROAdmin;

if (!$isActualOwner && !$isCoordinator && !$isROAdmin && $userRole !== 'admin') {
    header("Location: researcher_projects.php?error=access_denied");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Helper function to format status labels consistently
function formatStatusLabel($status) {
    $statusLabels = [
        'draft' => 'Draft',
        'submitted' => 'Submitted',
        'reviewed' => 'Under Review',
        'under_review' => 'Under Review',
        'under_coordinator_review' => 'Under Review',
        'under_ro_review' => 'Under Review',
        'accepted' => 'Accepted',
        'approved' => 'Approved',
        'endorsed' => 'Endorsed',
        'rejected' => 'Rejected',
        'returned' => 'Returned',
        'returned_for_revision' => 'Returned',
        'verified' => 'Verified',
        'pending' => 'Pending',
        'reported' => 'Reported'
    ];
    
    return $statusLabels[$status] ?? ucfirst(str_replace('_', ' ', $status));
}

// Get related data
$progressReports = $projectService->getProgressReports($projectId);
$extensions = $projectService->getExtensions($projectId);
$outputs = $projectService->getOutputs($projectId);
$completionReport = $projectService->getProjectCompletionReport($projectId);
$pendingFieldChanges = $projectService->getPendingFieldChanges($projectId);
$collaborations = $collaborationService->getProjectCollaborations($projectId);

// Separate collaborations into records and requests
$collabRecords = array_filter($collaborations, fn($c) => $c['collaboration_category'] === 'record');
$collabRequests = array_filter($collaborations, fn($c) => $c['collaboration_category'] === 'request');

// Get locked fields
$lockedFields = WorkflowEngine::getLockedFields();

// Get action availability for conditional buttons
$actions = $project['actions'] ?? [];

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Helper function to get icon for output type
function getOutputIcon($type) {
    $icons = [
        'publication' => 'book',
        'journal_article' => 'newspaper',
        'conference_paper' => 'users',
        'book' => 'book-open',
        'book_chapter' => 'bookmark',
        'thesis' => 'graduation-cap',
        'patent' => 'certificate',
        'software' => 'code',
        'dataset' => 'database',
        'prototype' => 'cogs',
        'technology' => 'microchip',
        'poster' => 'image',
        'presentation' => 'chalkboard-teacher',
        'report' => 'file-alt',
        'other' => 'file'
    ];
    return $icons[$type] ?? 'file-alt';
}

// Calculate progress data
$progressPercent = 0;
$timelineClass = '';
$daysInfo = '';

if ($project['proposed_start_date'] && $project['current_end_date']) {
    $start = strtotime($project['proposed_start_date']);
    $end = strtotime($project['current_end_date']);
    $now = time();
    
    if ($now >= $end) {
        $timelineClass = 'overdue';
        $daysOverdue = floor(($now - $end) / 86400);
        $daysInfo = $daysOverdue . ' days overdue';
        $progressPercent = 100;
    } elseif ($now <= $start) {
        $daysInfo = 'Not yet started';
        $progressPercent = 0;
    } else {
        $total = $end - $start;
        $elapsed = $now - $start;
        $progressPercent = min(100, round(($elapsed / $total) * 100));
        $daysRemaining = ceil(($end - $now) / 86400);
        $daysInfo = $daysRemaining . ' days remaining';
        
        if ($daysRemaining <= 30) {
            $timelineClass = 'near-due';
        }
    }
}
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   PROJECT VIEW STYLES - Refined Layout
   ============================================ */

/* Header Section */
.project-header {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    border: 1px solid #e2e8f0;
}

.project-header-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    flex-wrap: wrap;
}

.project-header-left {
    flex: 1;
    min-width: 300px;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #64748b;
    font-size: 13px;
    text-decoration: none;
    margin-bottom: 12px;
    transition: color 0.15s;
}

.back-link:hover {
    color: #064e1a;
}

.project-title {
    font-size: 24px;
    font-weight: 700;
    color: #1e293b;
    margin: 0 0 16px 0;
    line-height: 1.3;
}

/* Compact Meta Block */
.project-meta-block {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 12px;
}

.meta-item {
    display: flex;
    flex-direction: column;
    padding: 0 12px;
    border-right: 1px solid #e2e8f0;
}

.meta-item:last-child {
    border-right: none;
}

.meta-item:first-child {
    padding-left: 0;
}

.meta-label {
    font-size: 10px;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 2px;
}

.meta-value {
    font-size: 13px;
    font-weight: 600;
    color: #166534;
    font-family: 'Monaco', 'Consolas', monospace;
}

/* Status Area - Visually Dominant */
.project-status-area {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 12px;
}

.status-badge-main {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 14px 24px;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 700;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.status-badge-main.ongoing {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    color: white;
}

.status-badge-main.extended {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
}

.status-badge-main.completed {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
}

.progress-mini {
    display: flex;
    align-items: center;
    gap: 10px;
    background: white;
    padding: 8px 14px;
    border-radius: 20px;
    border: 1px solid #e2e8f0;
}

.progress-mini-bar {
    width: 80px;
    height: 6px;
    background: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
}

.progress-mini-fill {
    height: 100%;
    background: #3b82f6;
    border-radius: 3px;
    transition: width 0.5s ease;
}

.progress-mini-fill.overdue { background: #ef4444; }
.progress-mini-fill.near-due { background: #f59e0b; }

.progress-mini-text {
    font-size: 13px;
    font-weight: 600;
    color: #1e293b;
}

.rmis-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    color: #166534;
}

/* Timeline & Budget Card - Read-only Emphasis */
.approved-info-card {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
    position: relative;
}

.approved-info-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #e2e8f0;
}

.approved-info-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: #64748b;
    margin: 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.approved-info-header .lock-indicator {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    background: #fef3c7;
    border-radius: 12px;
    font-size: 11px;
    color: #92400e;
    cursor: help;
}

.approved-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.approved-info-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.approved-info-label {
    font-size: 11px;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.approved-info-value {
    font-size: 15px;
    font-weight: 600;
    color: #475569;
}

.approved-info-value.highlight {
    color: #1e40af;
}

.approved-info-value.extended {
    color: #d97706;
}

/* Tab Navigation - Clean & Intentional */
.project-tabs {
    display: flex;
    gap: 0;
    background: white;
    border-radius: 12px 12px 0 0;
    border: 1px solid #e5e7eb;
    border-bottom: none;
    overflow-x: auto;
    padding: 0 4px;
}

.project-tab {
    padding: 14px 20px;
    font-size: 13px;
    font-weight: 500;
    color: #64748b;
    background: none;
    border: none;
    cursor: pointer;
    position: relative;
    white-space: nowrap;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.15s ease;
}

.project-tab i {
    font-size: 14px;
    opacity: 0.7;
}

.project-tab:hover {
    color: #064e1a;
    background: #f8fafc;
}

.project-tab.active {
    color: #064e1a;
    font-weight: 600;
    background: #f0fdf4;
}

.project-tab.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 8px;
    right: 8px;
    height: 3px;
    background: #064e1a;
    border-radius: 3px 3px 0 0;
}

.project-tab.active i {
    opacity: 1;
}

.tab-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 20px;
    font-size: 11px;
    padding: 0 6px;
    border-radius: 10px;
    font-weight: 600;
}

.tab-badge.count {
    background: #e0e7ff;
    color: #3730a3;
}

.tab-badge.pending {
    background: #fef3c7;
    color: #92400e;
}

.tab-badge.success {
    background: #d1fae5;
    color: #065f46;
}

/* Tab Content Container */
.tab-content-wrapper {
    background: white;
    border: 1px solid #e5e7eb;
    border-top: none;
    border-radius: 0 0 12px 12px;
    min-height: 300px;
}

.tab-content {
    display: none;
    padding: 24px;
}

.tab-content.active {
    display: block;
}

/* Detail Sections */
.detail-section {
    background: #f8fafc;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
}

.detail-section:last-child {
    margin-bottom: 0;
}

.detail-section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #e2e8f0;
}

.detail-section-header h3 {
    font-size: 15px;
    color: #1e293b;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.detail-row {
    display: grid;
    grid-template-columns: 160px 1fr;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid #f1f5f9;
}

.detail-row:last-child {
    border-bottom: none;
}

.detail-label {
    font-size: 13px;
    color: #64748b;
    font-weight: 500;
    display: flex;
    align-items: flex-start;
    gap: 6px;
}

.detail-label .fa-lock {
    color: #f59e0b;
    font-size: 11px;
}

.detail-value {
    font-size: 14px;
    color: #1e293b;
    line-height: 1.5;
}

/* Tab Header with Action Button */
.tab-header {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #e2e8f0;
}

.tab-header .btn {
    margin: 0;
}

/* Action Button Styles - Tab-Scoped (legacy, keeping for compatibility) */
.tab-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    padding-top: 20px;
    margin-top: 20px;
    border-top: 1px solid #e2e8f0;
}

.btn {
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    transition: all 0.15s ease;
    white-space: nowrap;
}

.btn i {
    font-size: 12px;
}

.btn-primary {
    background: linear-gradient(135deg, #064e1a 0%, #053615 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(6, 78, 26, 0.2);
}

.btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(6, 78, 26, 0.25);
}

.btn-secondary {
    background: white;
    color: #374151;
    border: 1px solid #d1d5db;
}

.btn-secondary:hover {
    background: #f9fafb;
    border-color: #9ca3af;
}

/* Progress Report Button */
.btn-progress {
    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(37, 99, 235, 0.25);
}

.btn-progress:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
}

/* Output Button */
.btn-output {
    background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(124, 58, 237, 0.25);
}

.btn-output:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.3);
}

/* Extension Button */
.btn-extension {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(245, 158, 11, 0.25);
}

.btn-extension:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
}

.btn-extension.urgency-overdue {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    box-shadow: 0 2px 6px rgba(239, 68, 68, 0.25);
}

/* Collaboration Button */
.btn-collaboration {
    background: linear-gradient(135deg, #0891b2 0%, #0e7490 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(8, 145, 178, 0.25);
}

.btn-collaboration:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(8, 145, 178, 0.3);
}

/* Completion Button */
.btn-completion {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    box-shadow: 0 2px 6px rgba(16, 185, 129, 0.25);
}

.btn-completion:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

/* Disabled Button */
.btn-disabled {
    background: #f1f5f9 !important;
    color: #94a3b8 !important;
    cursor: not-allowed !important;
    box-shadow: none !important;
    border: 1px solid #e2e8f0 !important;
}

.btn-disabled:hover {
    transform: none !important;
}

/* Tooltip */
.action-tooltip {
    position: relative;
    display: inline-block;
}

.action-tooltip .tooltip-text {
    visibility: hidden;
    width: 240px;
    background: #1e293b;
    color: white;
    text-align: center;
    border-radius: 8px;
    padding: 10px 14px;
    position: absolute;
    z-index: 1000;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    opacity: 0;
    transition: opacity 0.2s, visibility 0.2s;
    font-size: 12px;
    font-weight: 400;
    line-height: 1.4;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

.action-tooltip .tooltip-text::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -6px;
    border-width: 6px;
    border-style: solid;
    border-color: #1e293b transparent transparent transparent;
}

.action-tooltip:hover .tooltip-text {
    visibility: visible;
    opacity: 1;
}

/* Reports List */
.reports-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.report-item {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    transition: border-color 0.15s, box-shadow 0.15s;
}

.report-item:hover {
    border-color: #cbd5e1;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.report-info h4 {
    font-size: 14px;
    color: #1e293b;
    margin: 0 0 4px 0;
    font-weight: 600;
}

.report-info p {
    font-size: 12px;
    color: #64748b;
    margin: 0;
}

.report-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}

.report-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: capitalize;
}

.status-draft { background: #f1f5f9; color: #64748b; }
.status-submitted { background: #dbeafe; color: #1e40af; }
.status-under_coordinator_review, .status-pending { background: #fef3c7; color: #92400e; }
.status-endorsed { background: #e0e7ff; color: #4338ca; }
.status-under_ro_review { background: #fae8ff; color: #a21caf; }
.status-approved, .status-accepted { background: #d1fae5; color: #065f46; }
.status-returned, .status-returned_for_revision { background: #fee2e2; color: #991b1b; }
.status-rejected { background: #fecaca; color: #b91c1c; }
.status-logged { background: #f0fdf4; color: #166534; }
.status-reviewed { background: #fef3c7; color: #92400e; }
.status-verified { background: #d1fae5; color: #065f46; }

/* Expanded Report Item Styles */
.report-item-expanded {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
}

.report-item-expanded .report-main {
    flex: 1;
}

.report-item-expanded .report-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 8px;
}

.report-item-expanded .report-header h4 {
    font-size: 15px;
    color: #1e293b;
    margin: 0;
    font-weight: 600;
    display: flex;
    align-items: center;
}

.report-item-expanded .report-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    font-size: 12px;
    color: #64748b;
    margin-bottom: 12px;
}

.report-item-expanded .report-meta span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.report-item-expanded .report-meta i {
    color: #94a3b8;
}

.report-details-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 12px;
    margin-bottom: 12px;
}

.report-detail-item {
    background: #f8fafc;
    padding: 10px 12px;
    border-radius: 8px;
}

.report-detail-item.full-width {
    grid-column: 1 / -1;
}

.report-detail-item .detail-label {
    font-size: 11px;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
}

.report-detail-item .detail-value {
    font-size: 13px;
    color: #1e293b;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
}

.report-detail-item .detail-value.highlight {
    color: #059669;
    font-weight: 600;
}

.report-summary {
    background: #f8fafc;
    padding: 10px 12px;
    border-radius: 8px;
    font-size: 12px;
    color: #475569;
    line-height: 1.5;
}

.report-summary strong {
    color: #334155;
}

.report-actions-vertical {
    display: flex;
    gap: 8px;
    padding-top: 12px;
    border-top: 1px solid #f1f5f9;
    flex-wrap: wrap;
}

.report-actions-vertical .btn-primary {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
}

.report-actions-vertical .btn-primary:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
}

/* Progress Bar Mini */
.progress-bar-mini {
    width: 80px;
    height: 6px;
    background: #e2e8f0;
    border-radius: 3px;
    overflow: hidden;
}

.progress-bar-mini .progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #10b981, #059669);
    border-radius: 3px;
}

/* Track Badge */
.track-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.track-badge.on-track {
    background: #d1fae5;
    color: #065f46;
}

.track-badge.off-track {
    background: #fee2e2;
    color: #991b1b;
}

/* Index Badge */
.index-badge {
    display: inline-block;
    padding: 2px 8px;
    background: #e0e7ff;
    color: #4338ca;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
}

/* MOA Badge */
.moa-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
}

.moa-pending, .moa-draft { background: #fef3c7; color: #92400e; }
.moa-in_progress { background: #dbeafe; color: #1e40af; }
.moa-signed, .moa-active { background: #d1fae5; color: #065f46; }
.moa-expired { background: #f1f5f9; color: #64748b; }

/* Empty State - Friendly & Actionable */
.empty-state {
    text-align: center;
    padding: 48px 24px;
    background: white;
    border-radius: 10px;
    border: 2px dashed #e2e8f0;
}

.empty-state-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 16px;
    background: #f1f5f9;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.empty-state-icon i {
    font-size: 28px;
    color: #94a3b8;
}

.empty-state h4 {
    font-size: 16px;
    color: #1e293b;
    margin: 0 0 8px 0;
}

.empty-state p {
    font-size: 13px;
    color: #64748b;
    margin: 0 0 20px 0;
    max-width: 400px;
    margin-left: auto;
    margin-right: auto;
    line-height: 1.5;
}

.empty-state .btn {
    margin-top: 4px;
}

/* Collaboration Section Styles */
.collab-section {
    margin-bottom: 24px;
}

.collab-section:last-child {
    margin-bottom: 0;
}

.collab-section-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
}

.collab-section-header h4 {
    font-size: 14px;
    font-weight: 600;
    color: #1e293b;
    margin: 0;
}

.collab-section-header .section-badge {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

.section-badge.records {
    background: #f0fdf4;
    color: #166534;
}

.section-badge.requests {
    background: #dbeafe;
    color: #1e40af;
}

.collab-item {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
}

.collab-item:last-child {
    margin-bottom: 0;
}

.collab-info {
    flex: 1;
}

.collab-info h5 {
    font-size: 14px;
    font-weight: 600;
    color: #1e293b;
    margin: 0 0 4px 0;
}

.collab-info .partner {
    font-size: 12px;
    color: #64748b;
    margin: 0;
}

.collab-info .partner i {
    margin-right: 4px;
    color: #94a3b8;
}

/* Checklist Tooltip */
.tooltip-checklist {
    width: 220px !important;
    text-align: left !important;
}

.checklist-item {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 0;
    font-size: 11px;
}

.checklist-item.met { color: #86efac; }
.checklist-item.met i { color: #22c55e; }
.checklist-item.unmet { color: #fca5a5; }
.checklist-item.unmet i { color: #ef4444; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(15, 23, 42, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.25s ease;
    backdrop-filter: blur(4px);
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 560px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.95) translateY(10px);
    transition: transform 0.25s ease;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

.modal-overlay.active .modal-box {
    transform: scale(1) translateY(0);
}

.modal-header {
    padding: 20px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-radius: 16px 16px 0 0;
}

.modal-header h3 {
    font-size: 18px;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
}

.modal-close {
    background: rgba(255,255,255,0.2);
    border: none;
    font-size: 20px;
    cursor: pointer;
    color: white;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.15s;
}

.modal-close:hover {
    background: rgba(255,255,255,0.3);
}

.modal-body {
    padding: 24px;
}

.modal-body .form-group {
    margin-bottom: 18px;
}

.modal-body .form-group:last-child {
    margin-bottom: 0;
}

.modal-body .form-group label {
    display: block;
    margin-bottom: 6px;
    font-weight: 500;
    font-size: 13px;
    color: #374151;
}

.modal-body .form-group input,
.modal-body .form-group select,
.modal-body .form-group textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.15s, box-shadow 0.15s;
}

.modal-body .form-group input:focus,
.modal-body .form-group select:focus,
.modal-body .form-group textarea:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.modal-body textarea {
    resize: none;
    min-height: 60px;
}

.modal-body textarea.auto-expand {
    resize: vertical;
    min-height: 60px;
    overflow-y: hidden;
    transition: height 0.1s ease;
}

/* Date validation hints and errors */
.date-hint {
    display: block;
    font-size: 11px;
    color: #6b7280;
    margin-top: 4px;
}

.date-error {
    display: block;
    font-size: 12px;
    color: #dc2626;
    margin-top: 4px;
    font-weight: 500;
}

.modal-body .form-group input:invalid {
    border-color: #dc2626;
}

.modal-body .form-group input[type="date"]:disabled {
    background: #f3f4f6;
    cursor: not-allowed;
}

.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    background: #f9fafb;
    border-radius: 0 0 16px 16px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.btn-sm {
    padding: 6px 12px !important;
    font-size: 12px !important;
}

/* Collaboration Modal Styles */
.collab-form-section {
    background: #f8fafc;
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 16px;
}

.collab-form-section:last-child {
    margin-bottom: 0;
}

.collab-section-title {
    font-size: 14px;
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.collab-section-title i {
    color: #064e1a;
}

.collab-category-selection {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 16px;
}

.collab-category-option {
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    padding: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: white;
}

.collab-category-option:hover {
    border-color: #94a3b8;
    background: #f8fafc;
}

.collab-category-option.selected {
    border-color: #064e1a;
    background: #f0fdf4;
}

.collab-category-option h4 {
    font-size: 14px;
    font-weight: 600;
    color: #1e293b;
    margin: 0 0 6px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.collab-category-option p {
    font-size: 12px;
    color: #64748b;
    margin: 0;
}
</style>

<div class="content">
    <!-- ============================================
         HEADER SECTION - Project Identity & Status
         ============================================ -->
    <div class="project-header">
        <div class="project-header-top">
            <div class="project-header-left">
                <?php 
                // Determine back link based on user role
                if ($userRole === 'admin' || $isROAdmin) {
                    $backLink = 'admin_projects.php';
                    $backText = 'Back to All Projects';
                } elseif ($isCoordinator && !$isOwner) {
                    $backLink = 'coordinator_projects.php';
                    $backText = 'Back to Unit Projects';
                } else {
                    $backLink = 'researcher_projects.php';
                    $backText = 'Back to My Projects';
                }
                ?>
                <a href="<?= $backLink ?>" class="back-link"
                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('<?= $backLink ?>',true)}">
                    <i class="fa fa-arrow-left"></i> <?= $backText ?>
                </a>
                
                <h1 class="project-title"><?= s($project['title']) ?></h1>
                
                <!-- Compact Meta Block -->
                <div class="project-meta-block">
                    <div class="meta-item">
                        <span class="meta-label">Reference No.</span>
                        <span class="meta-value"><?= s($project['reference_number'] ?: 'N/A') ?></span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label">Project Code</span>
                        <span class="meta-value"><?= s($project['project_code'] ?: 'N/A') ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Status Area - Visually Dominant -->
            <div class="project-status-area">
                <?php
                $statusClass = 'ongoing';
                $statusIcon = 'spinner fa-pulse';
                if ($project['project_status'] === 'completed') {
                    $statusClass = 'completed';
                    $statusIcon = 'check-circle';
                } elseif ($project['project_status'] === 'extended') {
                    $statusClass = 'extended';
                    $statusIcon = 'clock';
                }
                ?>
                <span class="status-badge-main <?= $statusClass ?>">
                    <i class="fa fa-<?= $statusIcon ?>"></i>
                    <?= s($project['project_status_label']) ?>
                </span>
                
                <?php if ($project['project_status'] !== 'completed'): ?>
                    <div class="progress-mini">
                        <div class="progress-mini-bar">
                            <div class="progress-mini-fill <?= $timelineClass ?>" style="width: <?= $progressPercent ?>%"></div>
                        </div>
                        <span class="progress-mini-text"><?= $progressPercent ?>% • <?= $daysInfo ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($project['rmis_form_mapping']): ?>
                    <span class="rmis-badge">
                        <i class="fa fa-file-alt"></i>
                        RMIS Form <?= s($project['rmis_form_mapping']) ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ============================================
         APPROVED TIMELINE & BUDGET - Read-only Block
         ============================================ -->
    <div class="approved-info-card">
        <div class="approved-info-header">
            <i class="fa fa-shield-alt" style="color: #64748b;"></i>
            <h3>Approved Timeline & Budget</h3>
            <span class="lock-indicator" title="Approved by Research Office – changes require formal request">
                <i class="fa fa-lock"></i> Locked
            </span>
        </div>
        <div class="approved-info-grid">
            <div class="approved-info-item">
                <span class="approved-info-label">Start Date</span>
                <span class="approved-info-value highlight">
                    <?= $project['proposed_start_date'] ? date('M d, Y', strtotime($project['proposed_start_date'])) : 'Not set' ?>
                </span>
            </div>
            <div class="approved-info-item">
                <span class="approved-info-label">Original End Date</span>
                <span class="approved-info-value">
                    <?= $project['proposed_end_date'] ? date('M d, Y', strtotime($project['proposed_end_date'])) : 'Not set' ?>
                </span>
            </div>
            <?php if ($project['extension_count'] > 0): ?>
                <div class="approved-info-item">
                    <span class="approved-info-label">Current End Date</span>
                    <span class="approved-info-value extended">
                        <?= date('M d, Y', strtotime($project['current_end_date'])) ?>
                        <small style="font-weight: 400; color: #94a3b8;">(+<?= $project['extension_count'] ?> ext)</small>
                    </span>
                </div>
            <?php endif; ?>
            <div class="approved-info-item">
                <span class="approved-info-label">Approved Budget</span>
                <span class="approved-info-value">
                    PHP <?= number_format($project['total_budget'] ?? 0, 2) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- ============================================
         TAB NAVIGATION - Project Modules
         ============================================ -->
    <div class="project-tabs">
        <button class="project-tab active" onclick="showTab('details', this)">
            <i class="fa fa-info-circle"></i> Project Details
        </button>
        <button class="project-tab" onclick="showTab('progress', this)">
            <i class="fa fa-chart-line"></i> Progress Reports
            <?php if (count($progressReports) > 0): ?>
                <span class="tab-badge count"><?= count($progressReports) ?></span>
            <?php endif; ?>
        </button>
        <button class="project-tab" onclick="showTab('extensions', this)">
            <i class="fa fa-calendar-plus"></i> Extensions
            <?php if (count($extensions) > 0): ?>
                <span class="tab-badge count"><?= count($extensions) ?></span>
            <?php endif; ?>
        </button>
        <button class="project-tab" onclick="showTab('outputs', this)">
            <i class="fa fa-file-alt"></i> Outputs
            <?php if (count($outputs) > 0): ?>
                <span class="tab-badge success"><?= count($outputs) ?></span>
            <?php endif; ?>
        </button>
        <button class="project-tab" onclick="showTab('collaborations', this)">
            <i class="fa fa-users"></i> Collaborations
            <?php 
            $pendingCollabs = count(array_filter($collabRequests, fn($c) => !in_array($c['status'], ['approved', 'rejected'])));
            if (count($collaborations) > 0): ?>
                <span class="tab-badge <?= $pendingCollabs > 0 ? 'pending' : 'count' ?>"><?= count($collaborations) ?></span>
            <?php endif; ?>
        </button>
        <button class="project-tab" onclick="showTab('completion', this)">
            <i class="fa fa-flag-checkered"></i> Completion
            <?php if ($completionReport): ?>
                <span class="tab-badge <?= $completionReport['status'] === 'approved' ? 'success' : ($completionReport['status'] === 'draft' ? 'count' : 'pending') ?>">1</span>
            <?php endif; ?>
        </button>
    </div>

    <!-- Tab Content Wrapper -->
    <div class="tab-content-wrapper">
        
        <!-- ============================================
             TAB: Project Details
             ============================================ -->
        <div id="tab-details" class="tab-content active">
            <div class="detail-section">
                <div class="detail-section-header">
                    <h3><i class="fa fa-file-alt" style="color: #064e1a;"></i> Proposal Information</h3>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">
                        <?php if ($project['is_proposal_locked']): ?><i class="fa fa-lock"></i><?php endif; ?>
                        Title
                    </div>
                    <div class="detail-value"><?= s($project['title']) ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Type</div>
                    <div class="detail-value"><?= s($project['type_name']) ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">
                        <?php if ($project['is_proposal_locked']): ?><i class="fa fa-lock"></i><?php endif; ?>
                        Objectives
                    </div>
                    <div class="detail-value"><?= nl2br(s($project['objectives'] ?: 'Not specified')) ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Abstract</div>
                    <div class="detail-value"><?= nl2br(s($project['abstract'] ?: 'Not specified')) ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Methodology</div>
                    <div class="detail-value"><?= nl2br(s($project['methodology'] ?: 'Not specified')) ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Expected Outcomes</div>
                    <div class="detail-value"><?= nl2br(s($project['expected_outcomes'] ?: 'Not specified')) ?></div>
                </div>
            </div>
            
            <div class="detail-section">
                <div class="detail-section-header">
                    <h3><i class="fa fa-tags" style="color: #8b5cf6;"></i> Classification</h3>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Research Program</div>
                    <div class="detail-value"><?= s($project['research_program'] ?: 'Not assigned') ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Funding Source</div>
                    <div class="detail-value"><?= s($project['funding_source'] ?: 'Not assigned') ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Fiscal Year</div>
                    <div class="detail-value"><?= s($project['fiscal_year'] ?: 'Not assigned') ?></div>
                </div>
            </div>
        </div>

        <!-- ============================================
             TAB: Progress Reports
             ============================================ -->
        <div id="tab-progress" class="tab-content">
            <?php if ($isOwner && in_array($project['project_status'], ['on_going', 'extended'])): ?>
                <?php $progressAction = $actions['progress'] ?? ['allowed' => true, 'reason' => null]; ?>
                <div class="tab-header">
                    <?php if ($progressAction['allowed']): ?>
                        <button onclick="openProgressReportModal()" class="btn btn-progress">
                            <i class="fa fa-plus"></i> Submit Progress Report
                        </button>
                    <?php else: ?>
                        <span class="action-tooltip">
                            <button class="btn btn-progress btn-disabled" disabled>
                                <i class="fa fa-lock"></i> Submit Progress Report
                            </button>
                            <span class="tooltip-text"><?= s($progressAction['reason'] ?? 'Not available') ?></span>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if (empty($progressReports)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-chart-line"></i>
                    </div>
                    <h4>No Progress Reports Yet</h4>
                    <p>Progress reports help track your research milestones and keep stakeholders informed. Submit your first report to document your research progress.</p>
                </div>
            <?php else: ?>
                <div class="reports-list">
                    <?php foreach ($progressReports as $report): ?>
                        <div class="report-item report-item-expanded">
                            <div class="report-main">
                                <div class="report-header">
                                    <h4><?= s($report['report_period']) ?></h4>
                                    <span class="report-status status-<?= s($report['status']) ?>">
                                        <?= formatStatusLabel($report['status']) ?>
                                    </span>
                                </div>
                                <div class="report-meta">
                                    <span><i class="fa fa-calendar-alt"></i> <?= date('M d, Y', strtotime($report['period_start_date'])) ?> - <?= date('M d, Y', strtotime($report['period_end_date'])) ?></span>
                                    <span><i class="fa fa-user"></i> <?= s($report['submitted_by_name'] ?? 'Unknown') ?></span>
                                    <?php if ($report['submitted_at']): ?>
                                        <span><i class="fa fa-clock"></i> <?= date('M d, Y', strtotime($report['submitted_at'])) ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="report-details-grid">
                                    <div class="report-detail-item">
                                        <div class="detail-label">Completion</div>
                                        <div class="detail-value">
                                            <div class="progress-bar-mini">
                                                <div class="progress-fill" style="width: <?= $report['completion_percentage'] ?>%"></div>
                                            </div>
                                            <span><?= $report['completion_percentage'] ?>%</span>
                                        </div>
                                    </div>
                                    <div class="report-detail-item">
                                        <div class="detail-label">Project Status</div>
                                        <div class="detail-value">
                                            <span class="track-badge <?= $report['is_on_track'] ? 'on-track' : 'off-track' ?>">
                                                <i class="fa fa-<?= $report['is_on_track'] ? 'check-circle' : 'exclamation-circle' ?>"></i>
                                                <?= $report['is_on_track'] ? 'On Track' : 'Behind Schedule' ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if ($report['activities_conducted']): ?>
                                <div class="report-summary">
                                    <strong>Activities:</strong> <?= s(mb_substr($report['activities_conducted'], 0, 150)) ?><?= mb_strlen($report['activities_conducted']) > 150 ? '...' : '' ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="report-actions-vertical">
                                <?php if ($report['status'] === 'draft' && $isOwner): ?>
                                <button onclick="submitDraftReport(<?= $report['id'] ?>)" class="btn btn-primary btn-sm">
                                    <i class="fa fa-paper-plane"></i> Submit
                                </button>
                                <?php endif; ?>
                                <a href="project_progress_view.php?id=<?= $report['id'] ?>" class="btn btn-secondary btn-sm"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_progress_view.php?id=<?= $report['id'] ?>',true)}">
                                    <i class="fa fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- ============================================
             TAB: Extensions
             ============================================ -->
        <div id="tab-extensions" class="tab-content">
            <?php if ($isOwner && in_array($project['project_status'], ['on_going', 'extended'])): ?>
                <?php 
                $extensionAction = $actions['extension'] ?? ['allowed' => false, 'reason' => 'Not available'];
                $urgencyClass = ($extensionAction['urgency'] ?? '') === 'overdue' ? ' urgency-overdue' : '';
                ?>
                <div class="tab-header">
                    <?php if ($extensionAction['allowed']): ?>
                        <button onclick="openExtensionModal()" class="btn btn-extension<?= $urgencyClass ?>">
                            <?php if (($extensionAction['urgency'] ?? '') === 'overdue'): ?>
                                <i class="fa fa-exclamation-triangle"></i> Request Extension (Overdue)
                            <?php else: ?>
                                <i class="fa fa-plus"></i> Request Extension
                            <?php endif; ?>
                        </button>
                    <?php else: ?>
                        <span class="action-tooltip">
                            <button class="btn btn-extension btn-disabled" disabled>
                                <i class="fa fa-lock"></i> Request Extension
                            </button>
                            <span class="tooltip-text"><?= s($extensionAction['reason'] ?? 'Not available') ?></span>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if (empty($extensions)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-calendar-plus"></i>
                    </div>
                    <h4>No Extension Requests</h4>
                    <p>Need more time or budget for your research? Extension requests allow you to formally request additional resources while maintaining compliance.</p>
                </div>
            <?php else: ?>
                <div class="reports-list">
                    <?php foreach ($extensions as $ext): ?>
                        <div class="report-item report-item-expanded">
                            <div class="report-main">
                                <div class="report-header">
                                    <h4>
                                        <i class="fa fa-<?= $ext['extension_type'] === 'budget' ? 'coins' : ($ext['extension_type'] === 'timeline_budget' ? 'calendar-plus' : 'clock') ?>" style="color: #f59e0b; margin-right: 8px;"></i>
                                        <?= ucfirst(str_replace('_', ' & ', $ext['extension_type'])) ?> Extension
                                    </h4>
                                    <span class="report-status status-<?= s($ext['status']) ?>">
                                        <?= ucfirst(str_replace('_', ' ', s($ext['status']))) ?>
                                    </span>
                                </div>
                                <div class="report-meta">
                                    <span><i class="fa fa-calendar"></i> Created <?= date('M d, Y', strtotime($ext['created_at'])) ?></span>
                                    <?php if ($ext['requested_at']): ?>
                                        <span><i class="fa fa-paper-plane"></i> Submitted <?= date('M d, Y', strtotime($ext['requested_at'])) ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="report-details-grid">
                                    <?php if ($ext['requested_end_date'] && in_array($ext['extension_type'], ['timeline', 'timeline_budget'])): ?>
                                    <div class="report-detail-item">
                                        <div class="detail-label">New End Date</div>
                                        <div class="detail-value highlight"><?= date('M d, Y', strtotime($ext['requested_end_date'])) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if ($ext['requested_additional_budget'] && in_array($ext['extension_type'], ['budget', 'timeline_budget'])): ?>
                                    <div class="report-detail-item">
                                        <div class="detail-label">Additional Budget</div>
                                        <div class="detail-value highlight">₱<?= number_format($ext['requested_additional_budget'], 2) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php 
                                    // Calculate extension duration if both dates exist
                                    $extensionMonths = null;
                                    if ($ext['original_end_date'] && $ext['requested_end_date']) {
                                        $original = new DateTime($ext['original_end_date']);
                                        $requested = new DateTime($ext['requested_end_date']);
                                        $diff = $original->diff($requested);
                                        $extensionMonths = ($diff->y * 12) + $diff->m + ($diff->d > 15 ? 1 : 0);
                                    }
                                    ?>
                                    <?php if ($extensionMonths > 0): ?>
                                    <div class="report-detail-item">
                                        <div class="detail-label">Extension Period</div>
                                        <div class="detail-value"><?= $extensionMonths ?> month(s)</div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($ext['justification']): ?>
                                <div class="report-summary">
                                    <strong>Justification:</strong> <?= s(mb_substr($ext['justification'], 0, 150)) ?><?= mb_strlen($ext['justification']) > 150 ? '...' : '' ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="report-actions-vertical">
                                <?php if ($ext['status'] === 'draft' && $isOwner): ?>
                                    <button onclick="submitDraftExtension(<?= $ext['id'] ?>)" class="btn btn-primary btn-sm">
                                        <i class="fa fa-paper-plane"></i> Submit
                                    </button>
                                <?php endif; ?>
                                <a href="project_extension_view.php?id=<?= $ext['id'] ?>" class="btn btn-secondary btn-sm"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_extension_view.php?id=<?= $ext['id'] ?>',true)}">
                                    <i class="fa fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- ============================================
             TAB: Outputs
             ============================================ -->
        <div id="tab-outputs" class="tab-content">
            <?php if ($isOwner): ?>
                <?php $outputAction = $actions['output'] ?? ['allowed' => false, 'reason' => 'Not available']; ?>
                <div class="tab-header">
                    <?php if ($outputAction['allowed']): ?>
                        <button onclick="openOutputModal()" class="btn btn-output">
                            <i class="fa fa-plus"></i> Report Output
                        </button>
                    <?php else: ?>
                        <span class="action-tooltip">
                            <button class="btn btn-output btn-disabled" disabled>
                                <i class="fa fa-lock"></i> Report Output
                            </button>
                            <span class="tooltip-text"><?= s($outputAction['reason'] ?? 'Not available') ?></span>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if (empty($outputs)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-file-alt"></i>
                    </div>
                    <h4>No Research Outputs Yet</h4>
                    <p>Document your research deliverables here — publications, patents, software, and other tangible outcomes that result from your project.</p>
                </div>
            <?php else: ?>
                <div class="reports-list">
                    <?php foreach ($outputs as $output): ?>
                        <div class="report-item report-item-expanded">
                            <div class="report-main">
                                <div class="report-header">
                                    <h4>
                                        <i class="fa fa-<?= getOutputIcon($output['output_type']) ?>" style="color: #8b5cf6; margin-right: 8px;"></i>
                                        <?= s($output['title']) ?>
                                    </h4>
                                    <span class="report-status status-<?= s($output['status']) ?>">
                                        <?= formatStatusLabel($output['status']) ?>
                                    </span>
                                </div>
                                <div class="report-meta">
                                    <span><i class="fa fa-tag"></i> <?= ucfirst(str_replace('_', ' ', $output['output_type'])) ?></span>
                                    <?php if (!empty($output['publication_date'])): ?>
                                        <span><i class="fa fa-calendar"></i> <?= date('M d, Y', strtotime($output['publication_date'])) ?></span>
                                    <?php endif; ?>
                                    <span><i class="fa fa-clock"></i> Reported <?= date('M d, Y', strtotime($output['created_at'])) ?></span>
                                </div>
                                
                                <div class="report-details-grid">
                                    <?php if (!empty($output['authors'])): ?>
                                    <div class="report-detail-item full-width">
                                        <div class="detail-label">Authors</div>
                                        <div class="detail-value"><?= s($output['authors']) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (!empty($output['publication_venue'])): ?>
                                    <div class="report-detail-item">
                                        <div class="detail-label">Publication Venue</div>
                                        <div class="detail-value"><?= s($output['publication_venue']) ?></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (!empty($output['indexing_status'])): ?>
                                    <div class="report-detail-item">
                                        <div class="detail-label">Indexing</div>
                                        <div class="detail-value">
                                            <span class="index-badge"><?= ucfirst(str_replace('_', ' ', $output['indexing_status'])) ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if (!empty($output['doi']) || !empty($output['isbn_issn'])): ?>
                                <div class="report-summary">
                                    <?php if (!empty($output['doi'])): ?>
                                        <span><strong>DOI:</strong> <?= s($output['doi']) ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($output['isbn_issn'])): ?>
                                        <span><strong>ISBN/ISSN:</strong> <?= s($output['isbn_issn']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="report-actions-vertical">
                                <a href="project_output_view.php?id=<?= $output['id'] ?>" class="btn btn-secondary btn-sm"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_output_view.php?id=<?= $output['id'] ?>',true)}">
                                    <i class="fa fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- ============================================
             TAB: Collaborations
             ============================================ -->
        <div id="tab-collaborations" class="tab-content">
            <?php if ($isOwner): ?>
                <div class="tab-header">
                    <button onclick="openCollaborationModal()" class="btn btn-collaboration">
                        <i class="fa fa-plus"></i> Add Collaboration
                    </button>
                </div>
            <?php endif; ?>
            
            <?php if (empty($collaborations)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <h4>No Collaborations Added</h4>
                    <p>Add collaborators to record research partnerships or submit collaboration requests for formal agreements like MOAs and joint research projects.</p>
                </div>
            <?php else: ?>
                <!-- Collaboration Records Section -->
                <?php if (!empty($collabRecords)): ?>
                    <div class="collab-section">
                        <div class="collab-section-header">
                            <h4><i class="fa fa-book" style="color: #166534;"></i> Collaboration Records</h4>
                            <span class="section-badge records"><?= count($collabRecords) ?> logged</span>
                        </div>
                        <?php foreach ($collabRecords as $collab): ?>
                            <div class="report-item report-item-expanded">
                                <div class="report-main">
                                    <div class="report-header">
                                        <h4>
                                            <i class="fa fa-handshake" style="color: #166534; margin-right: 8px;"></i>
                                            <?= s($collab['title']) ?>
                                        </h4>
                                        <span class="report-status status-logged">
                                            <i class="fa fa-check-circle"></i> Logged
                                        </span>
                                    </div>
                                    <div class="report-meta">
                                        <span><i class="fa fa-building"></i> <?= s($collab['partner_name']) ?></span>
                                        <span><i class="fa fa-tag"></i> <?= ucfirst($collab['partner_type']) ?></span>
                                        <?php if ($collab['created_at']): ?>
                                            <span><i class="fa fa-clock"></i> Logged <?= date('M d, Y', strtotime($collab['created_at'])) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="report-details-grid">
                                        <?php if ($collab['type_name']): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Collaboration Type</div>
                                            <div class="detail-value"><?= s($collab['type_name']) ?></div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($collab['start_date'] || $collab['end_date']): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Duration</div>
                                            <div class="detail-value">
                                                <?= $collab['start_date'] ? date('M Y', strtotime($collab['start_date'])) : 'N/A' ?>
                                                - <?= $collab['end_date'] ? date('M Y', strtotime($collab['end_date'])) : 'Ongoing' ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($collab['partner_contact_person']): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Contact Person</div>
                                            <div class="detail-value"><?= s($collab['partner_contact_person']) ?></div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($collab['financial_contribution']): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Financial Contribution</div>
                                            <div class="detail-value highlight">₱<?= number_format($collab['financial_contribution'], 2) ?></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($collab['nature_of_collaboration']): ?>
                                    <div class="report-summary">
                                        <strong>Nature:</strong> <?= s(mb_substr($collab['nature_of_collaboration'], 0, 150)) ?><?= mb_strlen($collab['nature_of_collaboration']) > 150 ? '...' : '' ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="report-actions-vertical">
                                    <a href="collaboration_view.php?id=<?= $collab['id'] ?>" class="btn btn-secondary btn-sm"
                                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('collaboration_view.php?id=<?= $collab['id'] ?>',true)}">
                                        <i class="fa fa-eye"></i> View Details
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Collaboration Requests Section -->
                <?php if (!empty($collabRequests)): ?>
                    <div class="collab-section">
                        <div class="collab-section-header">
                            <h4><i class="fa fa-file-signature" style="color: #1e40af;"></i> Collaboration Requests</h4>
                            <span class="section-badge requests"><?= count($collabRequests) ?> request<?= count($collabRequests) > 1 ? 's' : '' ?></span>
                        </div>
                        <?php foreach ($collabRequests as $collab): ?>
                            <div class="report-item report-item-expanded">
                                <div class="report-main">
                                    <div class="report-header">
                                        <h4>
                                            <i class="fa fa-file-signature" style="color: #1e40af; margin-right: 8px;"></i>
                                            <?= s($collab['title']) ?>
                                        </h4>
                                        <span class="report-status status-<?= s($collab['status']) ?>">
                                            <?= formatStatusLabel($collab['status']) ?>
                                        </span>
                                    </div>
                                    <div class="report-meta">
                                        <span><i class="fa fa-building"></i> <?= s($collab['partner_name']) ?></span>
                                        <span><i class="fa fa-tag"></i> <?= s($collab['type_name'] ?? ucfirst($collab['partner_type'])) ?></span>
                                        <?php if ($collab['submitted_at']): ?>
                                            <span><i class="fa fa-paper-plane"></i> Submitted <?= date('M d, Y', strtotime($collab['submitted_at'])) ?></span>
                                        <?php elseif ($collab['created_at']): ?>
                                            <span><i class="fa fa-clock"></i> Created <?= date('M d, Y', strtotime($collab['created_at'])) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="report-details-grid">
                                        <?php if ($collab['start_date'] || $collab['end_date']): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Duration</div>
                                            <div class="detail-value">
                                                <?= $collab['start_date'] ? date('M Y', strtotime($collab['start_date'])) : 'N/A' ?>
                                                - <?= $collab['end_date'] ? date('M Y', strtotime($collab['end_date'])) : 'TBD' ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (!empty($collab['moa_status'])): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">MOA Status</div>
                                            <div class="detail-value">
                                                <span class="moa-badge moa-<?= $collab['moa_status'] ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $collab['moa_status'])) ?>
                                                </span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (!empty($collab['partner_contact_person'])): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Contact Person</div>
                                            <div class="detail-value"><?= s($collab['partner_contact_person']) ?></div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (!empty($collab['has_financial_component']) && !empty($collab['amount_involved'])): ?>
                                        <div class="report-detail-item">
                                            <div class="detail-label">Financial Contribution</div>
                                            <div class="detail-value highlight">₱<?= number_format($collab['amount_involved'], 2) ?></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if (!empty($collab['purpose'])): ?>
                                    <div class="report-summary">
                                        <strong>Purpose:</strong> <?= s(mb_substr($collab['purpose'], 0, 150)) ?><?= mb_strlen($collab['purpose']) > 150 ? '...' : '' ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="report-actions-vertical">
                                    <?php if ($collab['status'] === 'draft' && $isOwner): ?>
                                        <button onclick="submitCollaboration(<?= $collab['id'] ?>)" class="btn btn-primary btn-sm">
                                            <i class="fa fa-paper-plane"></i> Submit
                                        </button>
                                    <?php endif; ?>
                                    <a href="collaboration_view.php?id=<?= $collab['id'] ?>" class="btn btn-secondary btn-sm"
                                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('collaboration_view.php?id=<?= $collab['id'] ?>',true)}">
                                        <i class="fa fa-eye"></i> View Details
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- ============================================
             TAB: Completion
             ============================================ -->
        <div id="tab-completion" class="tab-content">
            <?php 
            $completionAction = $actions['completion'] ?? ['allowed' => false, 'reason' => null, 'missing' => []];
            $missingItems = $completionAction['missing'] ?? [];
            $canSubmitCompletion = $isOwner && in_array($project['project_status'], ['on_going', 'extended']) && !$completionReport;
            ?>
            
            <?php if ($canSubmitCompletion): ?>
                <!-- Tab Header with Submit Button -->
                <div class="tab-header">
                    <?php if ($completionAction['allowed']): ?>
                        <button onclick="openCompletionModal()" class="btn btn-completion">
                            <i class="fa fa-flag-checkered"></i> Submit Completion Report
                        </button>
                    <?php else: ?>
                        <span class="action-tooltip">
                            <button class="btn btn-completion btn-disabled" disabled>
                                <i class="fa fa-lock"></i> Submit Completion Report
                            </button>
                            <span class="tooltip-text"><?= s($completionAction['reason'] ?? 'Requirements not met') ?></span>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($completionReport): ?>
                <!-- Existing Completion Report -->
                <div class="reports-list">
                    <div class="report-item report-item-expanded">
                        <div class="report-main">
                            <div class="report-header">
                                <div class="report-title">
                                    <i class="fa fa-flag-checkered" style="color: #10b981;"></i>
                                    Completion Report
                                </div>
                                <span class="report-status status-<?= s($completionReport['status']) ?>">
                                    <?= formatStatusLabel($completionReport['status']) ?>
                                </span>
                            </div>
                            
                            <div class="report-details-grid">
                                <div class="report-detail-item">
                                    <div class="detail-label">Completion Date</div>
                                    <div class="detail-value"><?= date('M d, Y', strtotime($completionReport['actual_completion_date'])) ?></div>
                                </div>
                                <div class="report-detail-item">
                                    <div class="detail-label">Submitted</div>
                                    <div class="detail-value"><?= date('M d, Y', strtotime($completionReport['created_at'])) ?></div>
                                </div>
                            </div>
                            
                            <div class="report-summary">
                                <strong>Executive Summary:</strong><br>
                                <?= nl2br(s($completionReport['executive_summary'])) ?>
                            </div>
                            
                            <div class="report-summary" style="margin-top: 12px;">
                                <strong>Key Findings:</strong><br>
                                <?= nl2br(s($completionReport['key_findings'])) ?>
                            </div>
                            
                            <div class="report-summary" style="margin-top: 12px;">
                                <strong>Deliverables Produced:</strong><br>
                                <?= nl2br(s($completionReport['deliverables_produced'])) ?>
                            </div>
                        </div>
                        
                        <div class="report-actions-vertical">
                            <?php if ($completionReport['status'] === 'draft' && $isOwner): ?>
                                <button onclick="submitDraftCompletion(<?= $completionReport['id'] ?>)" class="btn btn-primary btn-sm">
                                    <i class="fa fa-paper-plane"></i> Submit
                                </button>
                            <?php endif; ?>
                            
                            <?php 
                            // Coordinator can act on submitted/under_coordinator_review status
                            $coordCanActCompletion = ($userRole === 'coordinator') && in_array($completionReport['status'], ['submitted', 'under_coordinator_review']);
                            // Admin can act on endorsed/under_ro_review status
                            $adminCanActCompletion = ($userRole === 'admin') && in_array($completionReport['status'], ['endorsed', 'under_ro_review']);
                            ?>
                            
                            <?php if ($coordCanActCompletion): ?>
                                <button onclick="endorseCompletionReport(<?= $completionReport['id'] ?>)" class="btn btn-primary btn-sm">
                                    <i class="fa fa-check"></i> Endorse
                                </button>
                                <button onclick="returnCompletionReport(<?= $completionReport['id'] ?>)" class="btn btn-warning btn-sm">
                                    <i class="fa fa-undo"></i> Return
                                </button>
                            <?php elseif ($adminCanActCompletion): ?>
                                <button onclick="approveCompletionReport(<?= $completionReport['id'] ?>)" class="btn btn-success btn-sm">
                                    <i class="fa fa-check"></i> Approve
                                </button>
                                <button onclick="rejectCompletionReport(<?= $completionReport['id'] ?>)" class="btn btn-danger btn-sm">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                            <?php endif; ?>
                            
                            <a href="project_completion_view.php?id=<?= $completionReport['id'] ?>" class="btn btn-secondary btn-sm"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_completion_view.php?id=<?= $completionReport['id'] ?>',true)}">
                                <i class="fa fa-eye"></i> View Details
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif (!$canSubmitCompletion): ?>
                <!-- Empty State for non-owners or completed projects -->
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-flag-checkered"></i>
                    </div>
                    <?php if ($project['project_status'] === 'completed'): ?>
                        <h4>Project Completed</h4>
                        <p>This project has been successfully completed.</p>
                    <?php else: ?>
                        <h4>No Completion Report Yet</h4>
                        <p>A completion report will be submitted when the project is ready to be finalized.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <!-- Requirements Checklist for Owner -->
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fa fa-flag-checkered"></i>
                    </div>
                    <h4>Ready to Complete Your Project?</h4>
                    <p style="margin-bottom: 20px;">Submit a completion report to finalize your research project. Make sure all requirements are met.</p>
                    
                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; text-align: left; max-width: 400px; margin: 0 auto;">
                        <strong style="display: block; margin-bottom: 12px; color: #374151;">
                            <i class="fa fa-clipboard-check"></i> Requirements Checklist:
                        </strong>
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <span class="checklist-item <?= !in_array('start', $missingItems) ? 'met' : 'unmet' ?>" style="display: flex; align-items: center; gap: 8px;">
                                <i class="fa <?= !in_array('start', $missingItems) ? 'fa-check-circle' : 'fa-times-circle' ?>" 
                                   style="color: <?= !in_array('start', $missingItems) ? '#10b981' : '#ef4444' ?>;"></i>
                                Project has started
                            </span>
                            <span class="checklist-item <?= !in_array('progress', $missingItems) ? 'met' : 'unmet' ?>" style="display: flex; align-items: center; gap: 8px;">
                                <i class="fa <?= !in_array('progress', $missingItems) ? 'fa-check-circle' : 'fa-times-circle' ?>"
                                   style="color: <?= !in_array('progress', $missingItems) ? '#10b981' : '#ef4444' ?>;"></i>
                                At least 1 progress report
                            </span>
                            <span class="checklist-item <?= !in_array('timeline', $missingItems) ? 'met' : 'unmet' ?>" style="display: flex; align-items: center; gap: 8px;">
                                <i class="fa <?= !in_array('timeline', $missingItems) ? 'fa-check-circle' : 'fa-times-circle' ?>"
                                   style="color: <?= !in_array('timeline', $missingItems) ? '#10b981' : '#ef4444' ?>;"></i>
                                Within approved timeline
                            </span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ============================================
     MODALS
     ============================================ -->

<!-- Progress Report Modal -->
<div id="progressReportModal" class="modal-overlay">
    <div class="modal-box" style="max-width: 700px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);">
            <h3><i class="fa fa-chart-line"></i> Submit Progress Report</h3>
            <button class="modal-close" onclick="closeModal('progressReportModal')">&times;</button>
        </div>
        <form id="progressReportForm" method="POST" onsubmit="submitProgressReport(event); return false;">
            <input type="hidden" name="project_id" value="<?= $projectId ?>">
            <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                <!-- Report Period Section -->
                <h4 style="margin: 0 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-calendar"></i> Report Period
                </h4>
                
                <div class="form-group">
                    <label>Report Period Name <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="report_period" placeholder="e.g., Q1 2026, January-March 2026" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Period Start Date <span style="color: #dc2626;">*</span></label>
                        <input type="date" name="period_start_date" id="progress_start_date" required
                               min="<?= $project['proposed_start_date'] ?>" 
                               max="<?= $project['current_end_date'] ?? $project['proposed_end_date'] ?>"
                               onchange="validateProgressDates()">
                        <small class="date-hint">
                            Project period: <?= date('M d, Y', strtotime($project['proposed_start_date'])) ?> - <?= date('M d, Y', strtotime($project['current_end_date'] ?? $project['proposed_end_date'])) ?>
                        </small>
                    </div>
                    <div class="form-group">
                        <label>Period End Date <span style="color: #dc2626;">*</span></label>
                        <input type="date" name="period_end_date" id="progress_end_date" required
                               min="<?= $project['proposed_start_date'] ?>" 
                               max="<?= $project['current_end_date'] ?? $project['proposed_end_date'] ?>"
                               onchange="validateProgressDates()">
                        <span id="progress_date_error" class="date-error"></span>
                    </div>
                </div>
                
                <!-- Progress Assessment Section -->
                <h4 style="margin: 20px 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-chart-pie"></i> Progress Assessment
                </h4>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Completion Percentage <span style="color: #dc2626;">*</span></label>
                        <input type="number" name="completion_percentage" min="0" max="100" placeholder="0-100" required>
                    </div>
                    <div class="form-group">
                        <label>Project Status</label>
                        <select name="is_on_track">
                            <option value="1">On Track</option>
                            <option value="0">Behind Schedule</option>
                        </select>
                    </div>
                </div>
                
                <!-- Activities & Accomplishments Section -->
                <h4 style="margin: 20px 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-tasks"></i> Activities & Accomplishments
                </h4>
                
                <div class="form-group">
                    <label>Activities Conducted <span style="color: #dc2626;">*</span></label>
                    <textarea name="activities_conducted" rows="2" placeholder="Describe the activities conducted during this reporting period..." required class="auto-expand"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Key Accomplishments</label>
                    <textarea name="accomplishments" rows="2" placeholder="List key accomplishments and achievements..." class="auto-expand"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Milestones Achieved</label>
                    <textarea name="milestones_achieved" rows="2" placeholder="List any milestones reached during this period..." class="auto-expand"></textarea>
                </div>
                
                <!-- Challenges Section -->
                <h4 style="margin: 20px 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-exclamation-triangle"></i> Challenges & Solutions
                </h4>
                
                <div class="form-group">
                    <label>Challenges Encountered</label>
                    <textarea name="challenges_encountered" rows="2" placeholder="Describe any challenges or issues faced..." class="auto-expand"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Remedial Actions Taken</label>
                    <textarea name="remedial_actions" rows="2" placeholder="Actions taken to address the challenges..." class="auto-expand"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Deviation Remarks (if behind schedule)</label>
                    <textarea name="deviation_remarks" rows="2" placeholder="Explain reasons for any delays or deviations..." class="auto-expand"></textarea>
                </div>
                
                <!-- Next Steps Section -->
                <h4 style="margin: 20px 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-forward"></i> Next Steps
                </h4>
                
                <div class="form-group">
                    <label>Plans for Next Period</label>
                    <textarea name="next_period_plans" rows="2" placeholder="Planned activities and goals for the next reporting period..." class="auto-expand"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Assistance Needed</label>
                    <textarea name="assistance_needed" rows="2" placeholder="Any support or resources needed from the institution..." class="auto-expand"></textarea>
                </div>
                
                <!-- Financial Section (Optional) -->
                <h4 style="margin: 20px 0 15px 0; color: #374151; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">
                    <i class="fa fa-coins"></i> Financial Update (Optional)
                </h4>
                
                <div class="form-group" style="background: #f0f9ff; padding: 12px; border-radius: 8px; border: 1px solid #bae6fd; margin-bottom: 15px;">
                    <label style="color: #0369a1; font-weight: 600; margin-bottom: 5px;">
                        <i class="fa fa-wallet"></i> Total Project Budget
                    </label>
                    <div style="font-size: 18px; font-weight: 700; color: #0c4a6e;">
                        ₱ <?= number_format($project['total_budget'] ?? 0, 2) ?>
                    </div>
                    <input type="hidden" id="total_project_budget" value="<?= $project['total_budget'] ?? 0 ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Budget Utilized (₱)</label>
                        <input type="number" name="budget_utilized" id="budget_utilized" step="0.01" min="0" max="<?= $project['total_budget'] ?? 0 ?>" placeholder="0.00" oninput="calculateBudgetRemaining()">
                    </div>
                    <div class="form-group">
                        <label>Budget Remaining (₱)</label>
                        <input type="text" id="budget_remaining_display" readonly 
                               style="background: #ecfdf5; color: #059669; font-weight: 600;"
                               value="₱ <?= number_format($project['total_budget'] ?? 0, 2) ?>">
                        <input type="hidden" name="budget_remaining" id="budget_remaining" value="<?= $project['total_budget'] ?? 0 ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Financial Remarks</label>
                    <textarea name="financial_remarks" rows="2" placeholder="Any notes regarding budget utilization..." class="auto-expand"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('progressReportModal')">Cancel</button>
                <button type="submit" class="btn btn-progress">
                    <i class="fa fa-paper-plane"></i> Submit Report
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Extension Request Modal -->
<div id="extensionModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
            <h3><i class="fa fa-calendar-plus"></i> Request Extension</h3>
            <button class="modal-close" onclick="closeModal('extensionModal')">&times;</button>
        </div>
        <form id="extensionForm" method="POST" onsubmit="submitExtensionRequest(event); return false;">
            <input type="hidden" name="project_id" value="<?= $projectId ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Extension Type <span style="color: #dc2626;">*</span></label>
                    <select name="extension_type" id="ext_type" required onchange="toggleExtensionFields()">
                        <option value="">Select Type</option>
                        <option value="timeline">Time Extension Only</option>
                        <option value="budget">Budget Extension Only</option>
                        <option value="timeline_budget">Both Time & Budget</option>
                    </select>
                </div>
                
                <div class="form-group" id="ext_date_group" style="display: none;">
                    <label>New End Date <span style="color: #dc2626;">*</span></label>
                    <input type="date" name="requested_end_date" id="ext_end_date" 
                           min="<?= date('Y-m-d') ?>" 
                           value=""
                           pattern="\d{4}-\d{2}-\d{2}"
                           placeholder="YYYY-MM-DD">
                    <small style="color: #6b7280; font-size: 11px;">Select a new end date for your project</small>
                </div>
                
                <div class="form-group" id="ext_budget_group" style="display: none;">
                    <label>Additional Budget (PHP) <span style="color: #dc2626;">*</span></label>
                    <input type="number" name="requested_additional_budget" id="ext_budget" min="0" step="0.01" placeholder="0.00">
                </div>
                
                <div class="form-group">
                    <label>Justification <span style="color: #dc2626;">*</span></label>
                    <textarea name="justification" placeholder="Explain why an extension is needed..." required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('extensionModal')">Cancel</button>
                <button type="submit" class="btn btn-extension">
                    <i class="fa fa-paper-plane"></i> Submit Request
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Research Output Modal -->
<div id="outputModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header" style="background: linear-gradient(135deg, #7c3aed 0%, #6d28d9 100%);">
            <h3><i class="fa fa-file-alt"></i> Report Research Output</h3>
            <button class="modal-close" onclick="closeModal('outputModal')">&times;</button>
        </div>
        <form id="outputForm" method="POST" onsubmit="submitOutput(event); return false;">
            <input type="hidden" name="project_id" value="<?= $projectId ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Output Type <span style="color: #dc2626;">*</span></label>
                    <select name="output_type" required>
                        <option value="">Select Type</option>
                        <option value="journal_article">Journal Article</option>
                        <option value="conference_paper">Conference Paper</option>
                        <option value="book_chapter">Book Chapter</option>
                        <option value="patent">Patent</option>
                        <option value="software">Software/Application</option>
                        <option value="thesis">Thesis/Dissertation</option>
                        <option value="technical_report">Technical Report</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Title <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="title" placeholder="Title of the output" required>
                </div>
                
                <div class="form-group">
                    <label>Authors <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="authors" placeholder="e.g., Dela Cruz, J., Santos, M." required>
                </div>
                
                <div class="form-group">
                    <label>Publication Venue</label>
                    <input type="text" name="publication_venue" placeholder="Journal name, conference name, etc.">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Publication Date</label>
                        <input type="date" name="publication_date">
                    </div>
                    <div class="form-group">
                        <label>Indexing Status</label>
                        <select name="indexing_status">
                            <option value="pending">Pending</option>
                            <option value="scopus">Scopus</option>
                            <option value="wos">Web of Science</option>
                            <option value="asean">ASEAN Citation Index</option>
                            <option value="ched_recognized">CHED Recognized</option>
                            <option value="peer_reviewed">Peer Reviewed</option>
                            <option value="non_indexed">Non-Indexed</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>DOI</label>
                        <input type="text" name="doi_url" placeholder="e.g., 10.1000/xyz123">
                    </div>
                    <div class="form-group">
                        <label>ISBN/ISSN</label>
                        <input type="text" name="isbn_issn" placeholder="ISBN or ISSN number">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('outputModal')">Cancel</button>
                <button type="submit" class="btn btn-output">
                    <i class="fa fa-paper-plane"></i> Submit Output
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Collaboration Modal -->
<div id="collaborationModal" class="modal-overlay">
    <div class="modal-box" style="max-width: 680px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #064e1a 0%, #053615 100%);">
            <h3><i class="fa fa-handshake"></i> New Collaboration</h3>
            <button class="modal-close" onclick="closeModal('collaborationModal')">&times;</button>
        </div>
        <form id="collaborationForm" method="POST" onsubmit="submitCollaborationForm(event); return false;">
            <input type="hidden" name="project_id" value="<?= $projectId ?>">
            <div class="modal-body">
                <!-- Category Selection -->
                <div class="collab-form-section">
                    <div class="collab-section-title">
                        <i class="fa fa-tag"></i> Collaboration Type
                    </div>
                    <p style="font-size: 13px; color: #6b7280; margin-bottom: 16px;">
                        Choose whether this collaboration requires institutional approval or is for documentation only.
                    </p>
                    
                    <div class="collab-category-selection">
                        <div class="collab-category-option" data-category="request" onclick="selectCollabCategory('request')">
                            <h4><i class="fa fa-file-contract" style="color: #1e40af;"></i> Collaboration Request</h4>
                            <p>Requires approval (MOA, MOU, formal agreements)</p>
                            <p style="color: #dc2626; font-size: 11px; margin-top: 4px;">
                                <i class="fa fa-info-circle"></i> Will appear in Work Queue for review
                            </p>
                        </div>
                        <div class="collab-category-option" data-category="record" onclick="selectCollabCategory('record')">
                            <h4><i class="fa fa-clipboard-list" style="color: #065f46;"></i> Collaboration Record</h4>
                            <p>For documentation only (conferences, informal)</p>
                            <p style="color: #059669; font-size: 11px; margin-top: 4px;">
                                <i class="fa fa-info-circle"></i> Stays in My Projects only
                            </p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Collaboration Type <span style="color: #dc2626;">*</span></label>
                        <select name="collaboration_type_id" id="collab_type" required>
                            <option value="">-- Select type first --</option>
                        </select>
                    </div>
                </div>

                <!-- Partner Information -->
                <div class="collab-form-section">
                    <div class="collab-section-title">
                        <i class="fa fa-building"></i> Partner Information
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Partner Name <span style="color: #dc2626;">*</span></label>
                            <input type="text" name="partner_name" required placeholder="Institution or individual name">
                        </div>
                        <div class="form-group">
                            <label>Partner Type <span style="color: #dc2626;">*</span></label>
                            <select name="partner_type" required>
                                <option value="">Select type</option>
                                <option value="academic">Academic Institution</option>
                                <option value="government">Government Agency</option>
                                <option value="industry">Industry / Private</option>
                                <option value="ngo">NGO / Non-Profit</option>
                                <option value="international">International Organization</option>
                                <option value="individual">Individual Researcher</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" name="partner_country" value="Philippines" placeholder="Partner country">
                        </div>
                        <div class="form-group">
                            <label>Contact Person</label>
                            <input type="text" name="partner_contact_person" placeholder="Name of contact person">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Contact Email</label>
                            <input type="email" name="partner_contact_email" placeholder="email@example.com">
                        </div>
                        <div class="form-group">
                            <label>Contact Phone</label>
                            <input type="text" name="partner_contact_phone" placeholder="+63...">
                        </div>
                    </div>
                </div>

                <!-- Collaboration Details -->
                <div class="collab-form-section">
                    <div class="collab-section-title">
                        <i class="fa fa-info-circle"></i> Collaboration Details
                    </div>
                    <div class="form-group">
                        <label>Title <span style="color: #dc2626;">*</span></label>
                        <input type="text" name="title" required placeholder="Title or description of collaboration">
                    </div>
                    <div class="form-group">
                        <label>Purpose / Objectives <span style="color: #dc2626;">*</span></label>
                        <textarea name="purpose" required placeholder="Describe the purpose and objectives of this collaboration"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Scope of Work</label>
                        <textarea name="scope_of_work" placeholder="Detailed scope of the collaboration"></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="date" name="start_date" id="collabStartDate" 
                                   min="<?= date('Y-m-d') ?>"
                                   onchange="updateCollabEndDateMin()">
                            <small class="date-hint">When does the collaboration begin?</small>
                        </div>
                        <div class="form-group">
                            <label>End Date</label>
                            <input type="date" name="end_date" id="collabEndDate">
                            <span id="collab_date_error" class="date-error"></span>
                            <label style="display: flex; align-items: center; gap: 6px; margin-top: 6px; font-size: 12px; font-weight: normal; cursor: pointer;">
                                <input type="checkbox" name="is_ongoing" id="collabOngoing" value="1" 
                                       onchange="toggleCollabOngoing()"> 
                                <span style="color: #0369a1;">On-going (no end date)</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Financial Information (Optional) -->
                <div class="collab-form-section">
                    <div class="collab-section-title">
                        <i class="fa fa-coins"></i> Financial Component (Optional)
                    </div>
                    <div class="form-group">
                        <label style="display: flex; align-items: center; gap: 8px; font-weight: normal;">
                            <input type="checkbox" name="has_financial_component" value="1" id="hasFinancialCollab" onchange="toggleCollabFinancialFields()">
                            This collaboration involves financial component
                        </label>
                    </div>
                    <div id="collabFinancialFields" style="display: none;">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Amount Involved (PHP)</label>
                                <input type="number" name="amount_involved" step="0.01" min="0" placeholder="0.00">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Financial Details</label>
                            <textarea name="financial_details" placeholder="Describe the financial arrangement"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('collaborationModal')">Cancel</button>
                <button type="submit" name="save_draft" class="btn btn-secondary" style="margin-right: 8px;">
                    <i class="fa fa-save"></i> Save as Draft
                </button>
                <button type="submit" name="save_submit" id="collabSubmitBtn" class="btn btn-collaboration" style="display: none;">
                    <i class="fa fa-paper-plane"></i> Save & Submit
                </button>
                <button type="submit" name="save_record" id="collabSaveRecordBtn" class="btn btn-collaboration" style="display: none;">
                    <i class="fa fa-check"></i> Save Record
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Completion Report Modal -->
<div id="completionModal" class="modal-overlay">
    <div class="modal-box" style="max-width: 650px;">
        <div class="modal-header" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
            <h3><i class="fa fa-flag-checkered"></i> Submit Completion Report</h3>
            <button class="modal-close" onclick="closeModal('completionModal')">&times;</button>
        </div>
        <form id="completionForm" method="POST" onsubmit="submitCompletionReport(event); return false;">
            <input type="hidden" name="project_id" value="<?= $projectId ?>">
            <div class="modal-body">
                <div style="background: #d1fae5; color: #065f46; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 13px;">
                    <i class="fa fa-info-circle"></i>
                    <strong>Important:</strong> Submitting this report will mark the project as completed and map it to RMIS Form D.
                </div>
                
                <div class="form-group">
                    <label>Actual Completion Date <span style="color: #dc2626;">*</span></label>
                    <input type="date" name="actual_completion_date" max="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Executive Summary <span style="color: #dc2626;">*</span></label>
                    <textarea name="executive_summary" placeholder="Brief summary of the research project..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Objectives Achieved <span style="color: #dc2626;">*</span></label>
                    <textarea name="objectives_achieved" placeholder="Describe achieved objectives..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Key Findings <span style="color: #dc2626;">*</span></label>
                    <textarea name="key_findings" placeholder="List key findings or results..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Deliverables Produced <span style="color: #dc2626;">*</span></label>
                    <textarea name="deliverables_produced" placeholder="Publications, patents, software, etc..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Recommendations</label>
                    <textarea name="recommendations" placeholder="Future research or implementation recommendations..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('completionModal')">Cancel</button>
                <button type="submit" class="btn btn-completion">
                    <i class="fa fa-check-circle"></i> Submit & Complete
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// ============================================
// TAB NAVIGATION
// ============================================
function showTab(tabName, btn) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Deactivate all tabs
    document.querySelectorAll('.project-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    const tabContent = document.getElementById('tab-' + tabName);
    if (tabContent) {
        tabContent.classList.add('active');
    }
    
    // Activate clicked tab
    if (btn) {
        btn.classList.add('active');
    }
}

// ============================================
// MODAL FUNCTIONS
// ============================================
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('active');
    document.body.style.overflow = '';
    const form = modal.querySelector('form');
    if (form) form.reset();
    
    // Reset conditional fields
    if (modalId === 'extensionModal') {
        document.getElementById('ext_date_group').style.display = 'none';
        document.getElementById('ext_budget_group').style.display = 'none';
    }
    if (modalId === 'collaborationModal') {
        window.selectedCollabCategory = null;
        document.querySelectorAll('.collab-category-option').forEach(opt => opt.classList.remove('selected'));
        document.getElementById('collab_type').innerHTML = '<option value="">-- Select type first --</option>';
        document.getElementById('collabSubmitBtn').style.display = 'none';
        document.getElementById('collabSaveRecordBtn').style.display = 'none';
        document.getElementById('collabFinancialFields').style.display = 'none';
        
        // Reset date fields
        const endDateInput = document.getElementById('collabEndDate');
        endDateInput.disabled = false;
        endDateInput.style.backgroundColor = '';
        endDateInput.style.cursor = '';
        endDateInput.min = '';
        document.getElementById('collab_date_error').textContent = '';
        document.getElementById('collab_date_error').style.display = 'none';
    }
}

function openProgressReportModal() { 
    openModal('progressReportModal');
    // Reset date validation state
    document.getElementById('progress_date_error').textContent = '';
    // Reset budget fields
    document.getElementById('budget_utilized').value = '';
    calculateBudgetRemaining();
    // Initialize auto-expand textareas
    initAutoExpandTextareas();
}

// ============================================
// BUDGET CALCULATION
// ============================================
function calculateBudgetRemaining() {
    const totalBudget = parseFloat(document.getElementById('total_project_budget').value) || 0;
    const utilized = parseFloat(document.getElementById('budget_utilized').value) || 0;
    const remaining = totalBudget - utilized;
    
    // Update hidden field with numeric value
    document.getElementById('budget_remaining').value = remaining.toFixed(2);
    
    // Update display field with formatted value
    const displayInput = document.getElementById('budget_remaining_display');
    displayInput.value = '₱ ' + remaining.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    
    // Visual feedback based on remaining amount
    if (remaining < 0) {
        displayInput.style.color = '#dc2626';
        displayInput.style.background = '#fef2f2';
    } else if (remaining < totalBudget * 0.1) {
        displayInput.style.color = '#d97706';
        displayInput.style.background = '#fffbeb';
    } else {
        displayInput.style.color = '#059669';
        displayInput.style.background = '#ecfdf5';
    }
}

// ============================================
// AUTO-EXPAND TEXTAREAS
// ============================================
function autoExpand(textarea) {
    // Reset height to get correct scrollHeight
    textarea.style.height = 'auto';
    // Set to scrollHeight (minimum 60px for 2 rows)
    const minHeight = 60;
    textarea.style.height = Math.max(textarea.scrollHeight, minHeight) + 'px';
}

function initAutoExpandTextareas() {
    document.querySelectorAll('.auto-expand').forEach(textarea => {
        // Set initial height
        autoExpand(textarea);
        
        // Listen for input
        textarea.addEventListener('input', function() {
            autoExpand(this);
        });
    });
}

// Date validation for progress reports
const projectStartDate = '<?= $project['proposed_start_date'] ?>';
const projectEndDate = '<?= $project['current_end_date'] ?? $project['proposed_end_date'] ?>';

function validateProgressDates() {
    const startInput = document.getElementById('progress_start_date');
    const endInput = document.getElementById('progress_end_date');
    const errorSpan = document.getElementById('progress_date_error');
    
    errorSpan.textContent = '';
    startInput.setCustomValidity('');
    endInput.setCustomValidity('');
    
    const startDate = startInput.value;
    const endDate = endInput.value;
    
    // Validate start date is within project period
    if (startDate && startDate < projectStartDate) {
        const msg = 'Start date cannot be before project start date';
        startInput.setCustomValidity(msg);
        errorSpan.textContent = msg;
        return false;
    }
    
    if (startDate && startDate > projectEndDate) {
        const msg = 'Start date cannot be after project end date';
        startInput.setCustomValidity(msg);
        errorSpan.textContent = msg;
        return false;
    }
    
    // Validate end date is within project period
    if (endDate && endDate < projectStartDate) {
        const msg = 'End date cannot be before project start date';
        endInput.setCustomValidity(msg);
        errorSpan.textContent = msg;
        return false;
    }
    
    if (endDate && endDate > projectEndDate) {
        const msg = 'End date cannot be after project end date';
        endInput.setCustomValidity(msg);
        errorSpan.textContent = msg;
        return false;
    }
    
    // Validate end date is after start date
    if (startDate && endDate && endDate < startDate) {
        const msg = 'End date must be after start date';
        endInput.setCustomValidity(msg);
        errorSpan.textContent = msg;
        return false;
    }
    
    // Update end date min to be at least the start date
    if (startDate) {
        endInput.min = startDate;
    } else {
        endInput.min = projectStartDate;
    }
    
    return true;
}

function openExtensionModal() { openModal('extensionModal'); }
function openOutputModal() { openModal('outputModal'); }
function openCompletionModal() { openModal('completionModal'); }
function openCollaborationModal() { 
    openModal('collaborationModal');
    loadCollaborationTypes();
}

// Close modal on outside click
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
});

// Close modal on Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
});

// ============================================
// EXTENSION FIELDS TOGGLE
// ============================================
function toggleExtensionFields() {
    const extType = document.getElementById('ext_type').value;
    const dateGroup = document.getElementById('ext_date_group');
    const budgetGroup = document.getElementById('ext_budget_group');
    const dateInput = document.getElementById('ext_end_date');
    const budgetInput = document.getElementById('ext_budget');
    
    dateInput.required = false;
    budgetInput.required = false;
    dateGroup.style.display = 'none';
    budgetGroup.style.display = 'none';
    
    if (extType === 'timeline' || extType === 'timeline_budget') {
        dateGroup.style.display = 'block';
        dateInput.required = true;
    }
    if (extType === 'budget' || extType === 'timeline_budget') {
        budgetGroup.style.display = 'block';
        budgetInput.required = true;
    }
}

// ============================================
// COLLABORATION FIELDS
// ============================================
if (typeof window.collabTypes === 'undefined') {
    window.collabTypes = [];
}
if (typeof window.selectedCollabCategory === 'undefined') {
    window.selectedCollabCategory = null;
}

async function loadCollaborationTypes() {
    try {
        const response = await fetch('collaboration_api.php?action=get_types');
        const data = await response.json();
        if (data.success) {
            window.collabTypes = data.data || [];
        }
    } catch (e) {
        console.error('Failed to load collaboration types:', e);
    }
}

function selectCollabCategory(category) {
    window.selectedCollabCategory = category;
    const types = window.collabTypes || [];
    
    // Update visual selection
    document.querySelectorAll('.collab-category-option').forEach(opt => {
        opt.classList.remove('selected');
        if (opt.dataset.category === category) {
            opt.classList.add('selected');
        }
    });
    
    // Populate type dropdown
    const typeSelect = document.getElementById('collab_type');
    typeSelect.innerHTML = '<option value="">-- Select type --</option>';
    
    types.filter(t => t.category === category).forEach(type => {
        typeSelect.innerHTML += `<option value="${type.id}">${type.type_name}</option>`;
    });
    
    // Show/hide buttons based on category
    const submitBtn = document.getElementById('collabSubmitBtn');
    const saveRecordBtn = document.getElementById('collabSaveRecordBtn');
    
    if (category === 'request') {
        submitBtn.style.display = '';
        saveRecordBtn.style.display = 'none';
    } else {
        submitBtn.style.display = 'none';
        saveRecordBtn.style.display = '';
    }
}

function toggleCollabFinancialFields() {
    const hasFinancial = document.getElementById('hasFinancialCollab').checked;
    document.getElementById('collabFinancialFields').style.display = hasFinancial ? 'block' : 'none';
}

function updateCollabEndDateMin() {
    const startDate = document.getElementById('collabStartDate');
    const endDate = document.getElementById('collabEndDate');
    const errorEl = document.getElementById('collab_date_error');
    
    if (startDate.value) {
        // Set end date min to start date
        endDate.min = startDate.value;
        
        // If end date is before start date, clear it
        if (endDate.value && endDate.value < startDate.value) {
            endDate.value = '';
            errorEl.textContent = 'End date was reset (must be after start date)';
            errorEl.style.display = 'block';
            setTimeout(() => { errorEl.style.display = 'none'; }, 3000);
        }
    }
}

function toggleCollabOngoing() {
    const isOngoing = document.getElementById('collabOngoing').checked;
    const endDateInput = document.getElementById('collabEndDate');
    const startDateInput = document.getElementById('collabStartDate');
    
    if (isOngoing) {
        // Clear and disable end date
        endDateInput.value = '';
        endDateInput.disabled = true;
        endDateInput.style.backgroundColor = '#f3f4f6';
        endDateInput.style.cursor = 'not-allowed';
        
        // If no start date set, default to today
        if (!startDateInput.value) {
            startDateInput.value = new Date().toISOString().split('T')[0];
        }
    } else {
        // Enable end date
        endDateInput.disabled = false;
        endDateInput.style.backgroundColor = '';
        endDateInput.style.cursor = '';
        
        // Set min to start date if available
        if (startDateInput.value) {
            endDateInput.min = startDateInput.value;
        }
    }
}

// ============================================
// API SUBMISSIONS
// ============================================
async function submitProgressReport(event) {
    event.preventDefault();
    
    // Validate dates before submission
    if (!validateProgressDates()) {
        alert('Please fix the date errors before submitting.');
        return;
    }
    
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_progress_report',
                project_id: formData.get('project_id'),
                report_period: formData.get('report_period'),
                period_start_date: formData.get('period_start_date'),
                period_end_date: formData.get('period_end_date'),
                completion_percentage: formData.get('completion_percentage'),
                is_on_track: formData.get('is_on_track'),
                activities_conducted: formData.get('activities_conducted'),
                accomplishments: formData.get('accomplishments'),
                milestones_achieved: formData.get('milestones_achieved'),
                challenges_encountered: formData.get('challenges_encountered'),
                remedial_actions: formData.get('remedial_actions'),
                deviation_remarks: formData.get('deviation_remarks'),
                next_period_plans: formData.get('next_period_plans'),
                assistance_needed: formData.get('assistance_needed'),
                budget_utilized: formData.get('budget_utilized') || null,
                budget_remaining: formData.get('budget_remaining') || null,
                financial_remarks: formData.get('financial_remarks'),
                submit: true
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Progress report submitted successfully!');
            closeModal('progressReportModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting');
    }
}

async function submitDraftReport(reportId) {
    if (!confirm('Submit this progress report? It will be sent to your coordinator for review.')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'submit_progress_report',
                report_id: reportId
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Progress report submitted successfully!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting');
    }
}

async function submitDraftExtension(extensionId) {
    if (!confirm('Submit this extension request? It will be sent to your coordinator for review.')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'submit_extension',
                extension_id: extensionId
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Extension request submitted successfully!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to submit extension request');
    }
}

async function submitExtensionRequest(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const extensionType = formData.get('extension_type');
    let requestedEndDate = formData.get('requested_end_date');
    
    // Validate date for timeline extensions
    if (['timeline', 'timeline_budget'].includes(extensionType)) {
        if (!requestedEndDate) {
            alert('Please select a new end date for timeline extension.');
            return;
        }
        // Validate date format (YYYY-MM-DD)
        if (!/^\d{4}-\d{2}-\d{2}$/.test(requestedEndDate)) {
            alert('Invalid date format. Please use the date picker to select a valid date.');
            return;
        }
    } else {
        requestedEndDate = null;
    }
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_extension',
                project_id: formData.get('project_id'),
                extension_type: extensionType,
                requested_end_date: requestedEndDate,
                requested_additional_budget: formData.get('requested_additional_budget') ? parseFloat(formData.get('requested_additional_budget')) : null,
                justification: formData.get('justification'),
                submit: true
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Extension request submitted successfully!');
            closeModal('extensionModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting');
    }
}

async function submitOutput(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'report_output',
                project_id: formData.get('project_id'),
                output_type: formData.get('output_type'),
                title: formData.get('title'),
                authors: formData.get('authors'),
                publication_venue: formData.get('publication_venue') || null,
                publication_date: formData.get('publication_date') || null,
                doi: formData.get('doi_url') || null,
                isbn_issn: formData.get('isbn_issn') || null,
                indexing_status: formData.get('indexing_status') || 'pending'
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Research output reported successfully!');
            closeModal('outputModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting');
    }
}

async function submitCollaborationForm(event) {
    event.preventDefault();
    
    if (!window.selectedCollabCategory) {
        alert('Please select a collaboration category (Request or Record)');
        return;
    }
    
    const form = event.target;
    const formData = new FormData(form);
    const submitBtn = document.activeElement;
    const shouldSubmit = submitBtn.name === 'save_submit';
    const isRecord = submitBtn.name === 'save_record';
    
    // Validate required fields
    const typeId = formData.get('collaboration_type_id');
    if (!typeId || typeId === '') {
        alert('Please select a collaboration type');
        return;
    }
    
    const partnerName = formData.get('partner_name');
    if (!partnerName || partnerName.trim() === '') {
        alert('Please enter a partner name');
        return;
    }
    
    const title = formData.get('title');
    if (!title || title.trim() === '') {
        alert('Please enter a collaboration title');
        return;
    }
    
    const purpose = formData.get('purpose');
    if (!purpose || purpose.trim() === '') {
        alert('Please enter the purpose of the collaboration');
        return;
    }
    
    try {
        // Get the ongoing checkbox directly (disabled fields may not be in FormData)
        const isOngoing = document.getElementById('collabOngoing').checked;
        const startDate = document.getElementById('collabStartDate').value;
        const endDate = isOngoing ? null : document.getElementById('collabEndDate').value;
        
        const payload = {
            action: 'create',
            project_id: formData.get('project_id') || null,
            collaboration_type_id: parseInt(typeId),
            partner_name: partnerName.trim(),
            partner_type: formData.get('partner_type'),
            partner_country: formData.get('partner_country') || 'Philippines',
            partner_contact_person: formData.get('partner_contact_person') || null,
            partner_contact_email: formData.get('partner_contact_email') || null,
            partner_contact_phone: formData.get('partner_contact_phone') || null,
            title: title.trim(),
            purpose: purpose.trim(),
            scope_of_work: formData.get('scope_of_work') || null,
            start_date: startDate || null,
            end_date: endDate || null,
            is_ongoing: isOngoing ? 1 : 0,
            has_financial_component: formData.get('has_financial_component') ? 1 : 0,
            amount_involved: formData.get('amount_involved') ? parseFloat(formData.get('amount_involved')) : null,
            financial_details: formData.get('financial_details') || null
        };
        
        console.log('Submitting collaboration:', payload);
        
        const response = await fetch('collaboration_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        // Check if response is ok first
        if (!response.ok) {
            const text = await response.text();
            console.error('Server error response:', text);
            throw new Error('Server returned ' + response.status + ': ' + text.substring(0, 200));
        }
        
        const result = await response.json();
        
        if (result.success) {
            // If should submit (for requests), submit it
            if (shouldSubmit && window.selectedCollabCategory === 'request') {
                const submitResponse = await fetch('collaboration_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'submit', id: result.collaboration_id })
                });
                
                const submitResult = await submitResponse.json();
                
                if (submitResult.success) {
                    alert('Collaboration created and submitted successfully!');
                } else {
                    alert('Collaboration created as draft. Submit failed: ' + (submitResult.error || 'Unknown error'));
                }
            } else if (isRecord) {
                alert('Collaboration record saved successfully!');
            } else {
                alert('Collaboration saved as draft successfully!');
            }
            
            closeModal('collaborationModal');
            window.location.reload();
        } else {
            console.error('API error:', result);
            alert('Error: ' + (result.error || 'Failed to create collaboration'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while creating collaboration: ' + error.message);
    }
}

async function submitCollaboration(collabId) {
    if (!confirm('Submit this collaboration request for approval?')) return;
    
    try {
        const response = await fetch('collaboration_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'submit',
                id: collabId
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Collaboration request submitted for approval!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to submit collaboration request');
    }
}

async function submitCompletionReport(event) {
    event.preventDefault();
    
    if (!confirm('Are you sure you want to submit this completion report?\n\nThis will mark the project as COMPLETED.')) {
        return;
    }
    
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create_completion_report',
                project_id: formData.get('project_id'),
                actual_completion_date: formData.get('actual_completion_date'),
                executive_summary: formData.get('executive_summary'),
                objectives_achieved: formData.get('objectives_achieved'),
                key_findings: formData.get('key_findings'),
                deliverables_produced: formData.get('deliverables_produced'),
                recommendations: formData.get('recommendations') || null,
                submit: true
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report submitted successfully!\n\nProject Status: COMPLETED\nRMIS Form: Form D');
            closeModal('completionModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting');
    }
}

// ============================================
// Completion Report Workflow Actions
// ============================================

// Submit draft completion report for review
async function submitDraftCompletion(reportId) {
    if (!confirm('Submit this completion report? It will be sent to your coordinator for review.')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'submit_completion',
                report_id: reportId
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report submitted successfully!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

// Coordinator: Endorse completion report to Research Office
async function endorseCompletionReport(reportId) {
    if (!confirm('Endorse this completion report to the Research Office?')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'endorse_completion',
                report_id: reportId,
                remarks: ''
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report endorsed successfully!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to endorse'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

// Coordinator: Return completion report for revision
async function returnCompletionReport(reportId) {
    const reason = prompt('Reason for returning the completion report:');
    if (!reason) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'return_completion',
                report_id: reportId,
                reason: reason
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report returned for revision.');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to return'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

// Research Office: Approve completion report and complete project
async function approveCompletionReport(reportId) {
    if (!confirm('Approve this completion report?\n\nThis will mark the project as COMPLETED.')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'approve_completion',
                report_id: reportId
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report approved! Project is now marked as COMPLETED.');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to approve'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

// Research Office: Reject completion report
async function rejectCompletionReport(reportId) {
    const reason = prompt('Reason for rejecting the completion report:');
    if (!reason) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'reject_completion',
                report_id: reportId,
                reason: reason
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report rejected.');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to reject'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}
</script>
