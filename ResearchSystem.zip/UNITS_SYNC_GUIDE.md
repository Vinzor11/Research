# Units Sync Guide for OAuth Clients

This guide explains how OAuth clients can synchronize organizational units (programs, colleges, offices, departments, etc.) from the HR System into their own systems.

## Table of Contents

1. [Overview](#overview)
2. [Organizational Structure](#organizational-structure)
3. [Prerequisites](#prerequisites)
4. [Authentication](#authentication)
5. [API Endpoints](#api-endpoints)
6. [Query Parameters](#query-parameters)
7. [Response Formats](#response-formats)
8. [Sync Strategies](#sync-strategies)
9. [Code Examples](#code-examples)
10. [Best Practices](#best-practices)
11. [Troubleshooting](#troubleshooting)

## Overview

The HR System provides API endpoints for external OAuth clients to fetch and sync organizational structure data. This includes:

- **Sectors** - Top-level organizational divisions (e.g., Academic Affairs, Administrative Services)
- **Units** - Individual organizational units that belong to sectors, including:
  - Colleges
  - Programs/Departments
  - Offices
  - Institutes
  - Centers

**Use Cases:**
- Building organizational dropdowns in external systems
- Syncing department/college data for reporting
- Populating employee assignment options
- Cross-system data consistency

## Organizational Structure

The HR System uses a hierarchical organizational structure:

```
Sector (Top Level)
├── Unit (College/Office)
│   ├── Unit (Program/Department) - child of College
│   ├── Unit (Program/Department) - child of College
│   └── ...
└── Unit (Office)
```

### Unit Types

| Type | Description | Examples |
|------|-------------|----------|
| `college` | Academic colleges | College of Engineering, College of Arts |
| `program` | Academic programs/departments | Computer Science, Information Technology |
| `office` | Administrative offices | HR Office, Registrar's Office |
| `institute` | Research institutes | Research Institute, Innovation Center |
| `center` | Service centers | Testing Center, Counseling Center |

### Hierarchical Relationships

Units can have parent-child relationships:
- A **College** can have multiple **Programs** as children
- An **Office** can have sub-offices as children
- Use `parent_unit_id` to establish these relationships

## Prerequisites

Before syncing units, ensure you have:

1. **OAuth Client Credentials** from the HR System administrator:
   - Client ID
   - Client Secret
   - Redirect URI (registered with the HR System)

2. **HR System Base URL** (e.g., `https://hr.example.com`)

3. **Valid OAuth Access Token** obtained through the OAuth 2.0 Authorization Code flow

For OAuth setup instructions, see the [Employees API Guide](./EMPLOYEES_API_GUIDE.md#authentication).

## Authentication

All API requests require a Bearer token in the Authorization header:

```
Authorization: Bearer {access_token}
```

### Token Refresh

Access tokens expire. Implement token refresh logic:

```javascript
async function refreshToken(refreshToken) {
  const response = await fetch(`${HR_SYSTEM_URL}/oauth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
    }),
  });
  return await response.json();
}
```

## API Endpoints

### Sectors

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/sectors` | List all active sectors |
| `GET` | `/api/sectors/{id}` | Get a specific sector with its units |

### Units

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/units` | List all active units |
| `GET` | `/api/units/{id}` | Get a specific unit with details |

**Rate Limit:** 60 requests per minute

## Query Parameters

### Sectors Endpoint (`/api/sectors`)

| Parameter | Type | Description |
|-----------|------|-------------|
| `search` | string | Search by sector name or code |

### Units Endpoint (`/api/units`)

| Parameter | Type | Description |
|-----------|------|-------------|
| `sector_id` | integer | Filter units by sector ID |
| `unit_type` | string | Filter by unit type: `college`, `program`, `office`, `institute`, `center` |
| `search` | string | Search by unit name or code |

**Examples:**

```bash
# Get all units
GET /api/units

# Get only colleges
GET /api/units?unit_type=college

# Get units in a specific sector
GET /api/units?sector_id=1

# Get programs in a specific sector
GET /api/units?sector_id=1&unit_type=program

# Search for units
GET /api/units?search=computer
```

## Response Formats

### Sectors List Response

```json
{
  "data": [
    {
      "id": 1,
      "name": "Academic Affairs",
      "code": "AA",
      "description": "Handles academic programs and faculty",
      "units_count": 15
    },
    {
      "id": 2,
      "name": "Administrative Services",
      "code": "AS",
      "description": "Handles administrative functions",
      "units_count": 8
    }
  ]
}
```

### Single Sector Response (with Units)

```json
{
  "data": {
    "id": 1,
    "name": "Academic Affairs",
    "code": "AA",
    "description": "Handles academic programs and faculty",
    "units": [
      {
        "id": 1,
        "name": "College of Engineering",
        "code": "COE",
        "unit_type": "college"
      },
      {
        "id": 2,
        "name": "College of Information Technology",
        "code": "CIT",
        "unit_type": "college"
      }
    ]
  }
}
```

### Units List Response

```json
{
  "data": [
    {
      "id": 1,
      "name": "College of Engineering",
      "code": "COE",
      "unit_type": "college",
      "description": "Engineering programs and courses",
      "sector": {
        "id": 1,
        "name": "Academic Affairs",
        "code": "AA"
      },
      "parent_unit_id": null
    },
    {
      "id": 5,
      "name": "Computer Science",
      "code": "CS",
      "unit_type": "program",
      "description": "Bachelor of Science in Computer Science",
      "sector": {
        "id": 1,
        "name": "Academic Affairs",
        "code": "AA"
      },
      "parent_unit_id": 2
    }
  ]
}
```

### Single Unit Response (with Relationships)

```json
{
  "data": {
    "id": 2,
    "name": "College of Information Technology",
    "code": "CIT",
    "unit_type": "college",
    "description": "Information Technology programs",
    "sector": {
      "id": 1,
      "name": "Academic Affairs",
      "code": "AA"
    },
    "parent_unit": null,
    "child_units": [
      {
        "id": 5,
        "name": "Computer Science",
        "code": "CS",
        "unit_type": "program"
      },
      {
        "id": 6,
        "name": "Information Technology",
        "code": "IT",
        "unit_type": "program"
      }
    ]
  }
}
```

### Response Fields

#### Sector Object

| Field | Type | Description |
|-------|------|-------------|
| `id` | integer | Unique sector identifier |
| `name` | string | Sector name |
| `code` | string | Short code for the sector |
| `description` | string | Sector description |
| `units_count` | integer | Number of units in this sector (list only) |
| `units` | array | Units in this sector (single sector view) |

#### Unit Object

| Field | Type | Description |
|-------|------|-------------|
| `id` | integer | Unique unit identifier |
| `name` | string | Unit name |
| `code` | string | Short code for the unit |
| `unit_type` | string | Type: `college`, `program`, `office`, `institute`, `center` |
| `description` | string | Unit description |
| `sector` | object | Parent sector information |
| `parent_unit_id` | integer\|null | ID of parent unit (for hierarchies) |
| `parent_unit` | object\|null | Parent unit details (single unit view) |
| `child_units` | array | Child units (single unit view) |

## Sync Strategies

### Strategy 1: Full Sync (Recommended for Initial Setup)

Fetch all sectors and units, then replace local data entirely.

```javascript
async function fullSync() {
  // 1. Fetch all sectors
  const sectorsResponse = await fetch(`${HR_URL}/api/sectors`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const sectors = (await sectorsResponse.json()).data;

  // 2. Fetch all units
  const unitsResponse = await fetch(`${HR_URL}/api/units`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const units = (await unitsResponse.json()).data;

  // 3. Replace local data in a transaction
  await database.transaction(async (trx) => {
    await trx('sectors').truncate();
    await trx('units').truncate();
    
    await trx('sectors').insert(sectors.map(s => ({
      hr_sector_id: s.id,
      name: s.name,
      code: s.code,
      description: s.description,
    })));
    
    await trx('units').insert(units.map(u => ({
      hr_unit_id: u.id,
      name: u.name,
      code: u.code,
      unit_type: u.unit_type,
      description: u.description,
      hr_sector_id: u.sector?.id,
      hr_parent_unit_id: u.parent_unit_id,
    })));
  });
}
```

### Strategy 2: Incremental Sync by Type

Fetch and sync specific unit types separately.

```javascript
async function syncColleges() {
  const response = await fetch(`${HR_URL}/api/units?unit_type=college`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const colleges = (await response.json()).data;
  
  for (const college of colleges) {
    await database('colleges').updateOrInsert(
      { hr_unit_id: college.id },
      {
        name: college.name,
        code: college.code,
        description: college.description,
        hr_sector_id: college.sector?.id,
        updated_at: new Date(),
      }
    );
  }
}

async function syncPrograms() {
  const response = await fetch(`${HR_URL}/api/units?unit_type=program`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const programs = (await response.json()).data;
  
  for (const program of programs) {
    await database('programs').updateOrInsert(
      { hr_unit_id: program.id },
      {
        name: program.name,
        code: program.code,
        description: program.description,
        hr_college_id: program.parent_unit_id, // Links to parent college
        updated_at: new Date(),
      }
    );
  }
}
```

### Strategy 3: Sync by Sector

Fetch complete organizational structure sector by sector.

```javascript
async function syncBySector() {
  // Get all sectors
  const sectorsResponse = await fetch(`${HR_URL}/api/sectors`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const sectors = (await sectorsResponse.json()).data;

  for (const sector of sectors) {
    // Get sector with all its units
    const detailResponse = await fetch(`${HR_URL}/api/sectors/${sector.id}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const sectorDetail = (await detailResponse.json()).data;

    // Sync sector
    await database('sectors').updateOrInsert(
      { hr_sector_id: sector.id },
      {
        name: sector.name,
        code: sector.code,
        description: sector.description,
      }
    );

    // Sync its units
    for (const unit of sectorDetail.units) {
      await database('units').updateOrInsert(
        { hr_unit_id: unit.id },
        {
          name: unit.name,
          code: unit.code,
          unit_type: unit.unit_type,
          hr_sector_id: sector.id,
        }
      );
    }

    // Rate limiting
    await new Promise(r => setTimeout(r, 1000));
  }
}
```

## Code Examples

### JavaScript/TypeScript

```javascript
class HRUnitsSync {
  constructor(baseUrl, accessToken) {
    this.baseUrl = baseUrl;
    this.accessToken = accessToken;
  }

  async request(endpoint) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Authentication failed. Refresh your access token.');
      }
      throw new Error(`API error: ${response.status}`);
    }

    return await response.json();
  }

  async getAllSectors() {
    const data = await this.request('/api/sectors');
    return data.data;
  }

  async getSectorWithUnits(sectorId) {
    const data = await this.request(`/api/sectors/${sectorId}`);
    return data.data;
  }

  async getAllUnits(filters = {}) {
    const params = new URLSearchParams(filters);
    const data = await this.request(`/api/units?${params}`);
    return data.data;
  }

  async getUnitDetails(unitId) {
    const data = await this.request(`/api/units/${unitId}`);
    return data.data;
  }

  // Convenience methods for specific unit types
  async getColleges() {
    return this.getAllUnits({ unit_type: 'college' });
  }

  async getPrograms() {
    return this.getAllUnits({ unit_type: 'program' });
  }

  async getOffices() {
    return this.getAllUnits({ unit_type: 'office' });
  }

  async getProgramsByCollege(collegeId) {
    const unit = await this.getUnitDetails(collegeId);
    return unit.child_units || [];
  }
}

// Usage
const sync = new HRUnitsSync('https://hr.example.com', 'your-access-token');

// Get all colleges
const colleges = await sync.getColleges();
console.log(`Found ${colleges.length} colleges`);

// Get all programs under a specific college
const programs = await sync.getProgramsByCollege(2);
console.log(`College has ${programs.length} programs`);

// Full sync example
async function fullSync() {
  const sectors = await sync.getAllSectors();
  const units = await sync.getAllUnits();

  // Store in your database
  for (const sector of sectors) {
    await db.sectors.upsert({
      hr_id: sector.id,
      name: sector.name,
      code: sector.code,
    });
  }

  for (const unit of units) {
    await db.units.upsert({
      hr_id: unit.id,
      name: unit.name,
      code: unit.code,
      unit_type: unit.unit_type,
      sector_id: unit.sector?.id,
      parent_unit_id: unit.parent_unit_id,
    });
  }
}
```

### PHP

```php
<?php

class HRUnitsSync
{
    private string $baseUrl;
    private string $accessToken;

    public function __construct(string $baseUrl, string $accessToken)
    {
        $this->baseUrl = $baseUrl;
        $this->accessToken = $accessToken;
    }

    private function request(string $endpoint): array
    {
        $ch = curl_init($this->baseUrl . $endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->accessToken,
            'Accept: application/json',
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new Exception("API request failed with status {$httpCode}");
        }

        return json_decode($response, true);
    }

    public function getAllSectors(): array
    {
        return $this->request('/api/sectors')['data'];
    }

    public function getSectorWithUnits(int $sectorId): array
    {
        return $this->request("/api/sectors/{$sectorId}")['data'];
    }

    public function getAllUnits(array $filters = []): array
    {
        $query = http_build_query($filters);
        $endpoint = '/api/units' . ($query ? "?{$query}" : '');
        return $this->request($endpoint)['data'];
    }

    public function getUnitDetails(int $unitId): array
    {
        return $this->request("/api/units/{$unitId}")['data'];
    }

    public function getColleges(): array
    {
        return $this->getAllUnits(['unit_type' => 'college']);
    }

    public function getPrograms(): array
    {
        return $this->getAllUnits(['unit_type' => 'program']);
    }

    public function getOffices(): array
    {
        return $this->getAllUnits(['unit_type' => 'office']);
    }
}

// Usage
$sync = new HRUnitsSync('https://hr.example.com', 'your-access-token');

// Get all colleges
$colleges = $sync->getColleges();
echo "Found " . count($colleges) . " colleges\n";

// Get all units in Academic Affairs sector (sector_id = 1)
$academicUnits = $sync->getAllUnits(['sector_id' => 1]);
echo "Academic sector has " . count($academicUnits) . " units\n";

// Full sync with Laravel
function syncUnits()
{
    $sync = new HRUnitsSync(config('hr.base_url'), session('hr_access_token'));

    DB::transaction(function () use ($sync) {
        // Sync sectors
        $sectors = $sync->getAllSectors();
        foreach ($sectors as $sector) {
            Sector::updateOrCreate(
                ['hr_id' => $sector['id']],
                [
                    'name' => $sector['name'],
                    'code' => $sector['code'],
                    'description' => $sector['description'],
                ]
            );
        }

        // Sync units
        $units = $sync->getAllUnits();
        foreach ($units as $unit) {
            Unit::updateOrCreate(
                ['hr_id' => $unit['id']],
                [
                    'name' => $unit['name'],
                    'code' => $unit['code'],
                    'unit_type' => $unit['unit_type'],
                    'description' => $unit['description'],
                    'hr_sector_id' => $unit['sector']['id'] ?? null,
                    'hr_parent_unit_id' => $unit['parent_unit_id'],
                ]
            );
        }
    });
}
```

### Python

```python
import requests
from typing import List, Dict, Optional

class HRUnitsSync:
    def __init__(self, base_url: str, access_token: str):
        self.base_url = base_url
        self.headers = {
            'Authorization': f'Bearer {access_token}',
            'Accept': 'application/json',
        }

    def _request(self, endpoint: str) -> Dict:
        response = requests.get(
            f"{self.base_url}{endpoint}",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()

    def get_all_sectors(self) -> List[Dict]:
        return self._request('/api/sectors')['data']

    def get_sector_with_units(self, sector_id: int) -> Dict:
        return self._request(f'/api/sectors/{sector_id}')['data']

    def get_all_units(self, filters: Optional[Dict] = None) -> List[Dict]:
        endpoint = '/api/units'
        if filters:
            params = '&'.join(f"{k}={v}" for k, v in filters.items())
            endpoint = f"{endpoint}?{params}"
        return self._request(endpoint)['data']

    def get_unit_details(self, unit_id: int) -> Dict:
        return self._request(f'/api/units/{unit_id}')['data']

    def get_colleges(self) -> List[Dict]:
        return self.get_all_units({'unit_type': 'college'})

    def get_programs(self) -> List[Dict]:
        return self.get_all_units({'unit_type': 'program'})

    def get_offices(self) -> List[Dict]:
        return self.get_all_units({'unit_type': 'office'})


# Usage
sync = HRUnitsSync('https://hr.example.com', 'your-access-token')

# Get all colleges
colleges = sync.get_colleges()
print(f"Found {len(colleges)} colleges")

# Get programs in specific sector
academic_programs = sync.get_all_units({
    'sector_id': 1,
    'unit_type': 'program'
})
print(f"Found {len(academic_programs)} academic programs")

# Full sync with SQLAlchemy
from sqlalchemy.orm import Session

def sync_units(db: Session):
    sync = HRUnitsSync(HR_BASE_URL, get_access_token())

    # Sync sectors
    sectors = sync.get_all_sectors()
    for sector in sectors:
        db_sector = db.query(Sector).filter(
            Sector.hr_id == sector['id']
        ).first()
        
        if db_sector:
            db_sector.name = sector['name']
            db_sector.code = sector['code']
        else:
            db.add(Sector(
                hr_id=sector['id'],
                name=sector['name'],
                code=sector['code'],
            ))

    # Sync units
    units = sync.get_all_units()
    for unit in units:
        db_unit = db.query(Unit).filter(
            Unit.hr_id == unit['id']
        ).first()
        
        if db_unit:
            db_unit.name = unit['name']
            db_unit.code = unit['code']
            db_unit.unit_type = unit['unit_type']
        else:
            db.add(Unit(
                hr_id=unit['id'],
                name=unit['name'],
                code=unit['code'],
                unit_type=unit['unit_type'],
                hr_sector_id=unit['sector']['id'] if unit['sector'] else None,
                hr_parent_unit_id=unit['parent_unit_id'],
            ))

    db.commit()
```

### cURL Examples

```bash
# Get all sectors
curl -X GET "https://hr.example.com/api/sectors" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Get a specific sector with its units
curl -X GET "https://hr.example.com/api/sectors/1" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Get all units
curl -X GET "https://hr.example.com/api/units" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Get only colleges
curl -X GET "https://hr.example.com/api/units?unit_type=college" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Get programs in a specific sector
curl -X GET "https://hr.example.com/api/units?sector_id=1&unit_type=program" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Search for units
curl -X GET "https://hr.example.com/api/units?search=computer" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"

# Get a specific unit with details
curl -X GET "https://hr.example.com/api/units/5" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Accept: application/json"
```

## Best Practices

### 1. Store HR System IDs

Always store the HR System's IDs (`hr_id`, `hr_sector_id`, etc.) in your local database to maintain data mapping:

```sql
CREATE TABLE units (
  id INT PRIMARY KEY AUTO_INCREMENT,
  hr_unit_id INT UNIQUE NOT NULL,        -- HR System's unit ID
  hr_sector_id INT,                       -- HR System's sector ID
  hr_parent_unit_id INT,                  -- HR System's parent unit ID
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50),
  unit_type VARCHAR(50),
  -- ... your other fields
  synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. Schedule Regular Syncs

Set up periodic synchronization (e.g., daily) to keep data current:

```javascript
// Node.js with node-cron
const cron = require('node-cron');

// Sync every day at 2 AM
cron.schedule('0 2 * * *', async () => {
  console.log('Starting daily units sync...');
  await syncUnits();
  console.log('Units sync completed');
});
```

### 3. Handle Deleted Units

Units may be deactivated in the HR System. Compare local data with API responses:

```javascript
async function handleDeletions() {
  const hrUnits = await sync.getAllUnits();
  const hrUnitIds = hrUnits.map(u => u.id);
  
  // Find local units not in HR System
  const localUnits = await db.units.findAll();
  const orphanedUnits = localUnits.filter(
    u => !hrUnitIds.includes(u.hr_unit_id)
  );
  
  // Mark as inactive or handle appropriately
  for (const unit of orphanedUnits) {
    await db.units.update(unit.id, { is_active: false });
    console.log(`Deactivated unit: ${unit.name}`);
  }
}
```

### 4. Build Hierarchical Structures

When displaying units, reconstruct the hierarchy using `parent_unit_id`:

```javascript
function buildHierarchy(units) {
  const unitMap = new Map(units.map(u => [u.id, { ...u, children: [] }]));
  const roots = [];

  for (const unit of unitMap.values()) {
    if (unit.parent_unit_id && unitMap.has(unit.parent_unit_id)) {
      unitMap.get(unit.parent_unit_id).children.push(unit);
    } else {
      roots.push(unit);
    }
  }

  return roots;
}

// Result: nested structure
// [
//   {
//     id: 1, name: "College of Engineering", children: [
//       { id: 5, name: "Computer Science", children: [] },
//       { id: 6, name: "Information Technology", children: [] }
//     ]
//   }
// ]
```

### 5. Implement Caching

Cache API responses to reduce load and improve performance:

```javascript
class CachedUnitsSync {
  constructor(sync, ttl = 3600000) { // 1 hour default
    this.sync = sync;
    this.cache = new Map();
    this.ttl = ttl;
  }

  async getCached(key, fetcher) {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.time < this.ttl) {
      return cached.data;
    }

    const data = await fetcher();
    this.cache.set(key, { data, time: Date.now() });
    return data;
  }

  async getAllUnits() {
    return this.getCached('all_units', () => this.sync.getAllUnits());
  }

  async getColleges() {
    return this.getCached('colleges', () => this.sync.getColleges());
  }
}
```

### 6. Log Sync Operations

Maintain logs for debugging and audit purposes:

```javascript
async function syncWithLogging() {
  const log = {
    started_at: new Date(),
    sectors_synced: 0,
    units_synced: 0,
    errors: [],
  };

  try {
    const sectors = await sync.getAllSectors();
    log.sectors_synced = sectors.length;

    const units = await sync.getAllUnits();
    log.units_synced = units.length;

    // Perform sync...

    log.completed_at = new Date();
    log.status = 'success';
  } catch (error) {
    log.errors.push(error.message);
    log.status = 'failed';
  }

  await db.sync_logs.insert(log);
  return log;
}
```

## Troubleshooting

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `401 Unauthorized` | Invalid or expired token | Refresh your OAuth access token |
| `404 Not Found` | Invalid endpoint or ID | Verify the endpoint URL and resource ID |
| `429 Too Many Requests` | Rate limit exceeded | Implement rate limiting; wait before retrying |
| `500 Server Error` | HR System error | Contact HR System administrator |

### Debugging Tips

1. **Check Token Validity**: Ensure your access token hasn't expired
2. **Verify Scopes**: Confirm your OAuth client has the required scopes
3. **Inspect Response**: Log full API responses to identify issues
4. **Test with cURL**: Use cURL to test endpoints independently

### Getting Help

For questions or issues:

1. Check the [API Sync Strategy Guide](./API_SYNC_STRATEGY.md) for general sync patterns
2. Review the [Employees API Guide](./EMPLOYEES_API_GUIDE.md) for authentication details
3. Contact the HR System administrator for:
   - OAuth client registration
   - Access permissions
   - API questions

## Changelog

- **v1.0.0** - Initial release
  - Sectors list and detail endpoints
  - Units list and detail endpoints
  - Filtering by sector and unit type
  - Search functionality
  - Hierarchical unit relationships
