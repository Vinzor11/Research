<?php
/**
 * ActivityLogger.php
 * Enhanced Activity Logging Class for Research Management System
 * 
 * This file should be placed in your root directory alongside db.php
 * 
 * @version 2.0
 * @author Research Management System Team
 */

class ActivityLogger {
    private $conn;
    private $user_id;

    /**
     * Constructor - Initialize the logger
     * 
     * @param mysqli $db_connection - Database connection object
     * @param int|null $user_id - User ID (auto-detects from session if not provided)
     */
    public function __construct($db_connection, $user_id = null) {
        $this->conn = $db_connection;
        $this->user_id = $user_id ?? $_SESSION['user_id'] ?? null;
    }

    /**
     * Main logging method - Records any activity to the database
     * 
     * @param string $action_type - Type of action: create, update, delete, view, export, login, logout
     * @param string $description - Human-readable description of what happened
     * @param string|null $table_affected - Name of the database table that was affected
     * @param int|null $record_id - ID of the specific record that was affected
     * @return bool - True if logged successfully, false otherwise
     */
    public function log($action_type, $description, $table_affected = null, $record_id = null) {
        // Can't log without a user
        if (!$this->user_id) {
            error_log("ActivityLogger: Cannot log activity - no user_id provided");
            return false;
        }

        // Validate required fields
        if (empty($action_type) || empty($description)) {
            error_log("ActivityLogger: Cannot log activity - action_type and description are required");
            return false;
        }

        // Validate action type against allowed values
        $valid_actions = ['create', 'update', 'delete', 'view', 'export', 'login', 'logout'];
        if (!in_array($action_type, $valid_actions)) {
            error_log("ActivityLogger: Invalid action_type '$action_type'. Must be one of: " . implode(', ', $valid_actions));
            return false;
        }

        // Gather context information
        $ip_address = $this->getClientIP();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        // Insert the log entry
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO activity_logs 
                (user_id, action_type, table_affected, record_id, description, ip_address, user_agent) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            if (!$stmt) {
                error_log("ActivityLogger: Failed to prepare statement - " . $this->conn->error);
                return false;
            }

            $stmt->bind_param(
                "issssss",
                $this->user_id,
                $action_type,
                $table_affected,
                $record_id,
                $description,
                $ip_address,
                $user_agent
            );

            $result = $stmt->execute();
            
            if (!$result) {
                error_log("ActivityLogger: Failed to execute log - " . $stmt->error);
            }

            $stmt->close();
            return $result;

        } catch (Exception $e) {
            error_log("ActivityLogger: Exception occurred - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Log when something is CREATED
     * Use this after INSERT queries
     * 
     * @param string $table - Table name (e.g., 'student_researchers')
     * @param int $record_id - The new record's ID (use $conn->insert_id)
     * @param string $description - What was created (e.g., "Created student: John Doe")
     * @return bool
     */
    public function logCreate($table, $record_id, $description) {
        return $this->log('create', $description, $table, $record_id);
    }

    /**
     * Log when something is UPDATED
     * Use this after UPDATE queries
     * 
     * @param string $table - Table name
     * @param int $record_id - The record's ID that was updated
     * @param string $description - What was updated (e.g., "Updated student: John Doe")
     * @return bool
     */
    public function logUpdate($table, $record_id, $description) {
        return $this->log('update', $description, $table, $record_id);
    }

    /**
     * Log when something is DELETED
     * IMPORTANT: Get the record info BEFORE deleting, then log with that info
     * 
     * @param string $table - Table name
     * @param int $record_id - The record's ID that was deleted
     * @param string $description - What was deleted with identifying info (e.g., "Deleted student: John Doe (ID: 123)")
     * @return bool
     */
    public function logDelete($table, $record_id, $description) {
        return $this->log('delete', $description, $table, $record_id);
    }

    /**
     * Log when a page or record is VIEWED
     * Use this when someone accesses a page or views specific data
     * 
     * @param string $table - Table/page that was viewed
     * @param int|null $record_id - Specific record ID if viewing a single record
     * @param string|null $description - Custom description (auto-generated if not provided)
     * @return bool
     */
    public function logView($table, $record_id = null, $description = null) {
        // Auto-generate description if not provided
        if (empty($description)) {
            $description = "Viewed " . $this->formatTableName($table);
            if ($record_id) {
                $description .= " (Record ID: $record_id)";
            }
        }
        return $this->log('view', $description, $table, $record_id);
    }

    /**
     * Log when data is EXPORTED
     * Use this when exporting to Excel, PDF, CSV, etc.
     * 
     * @param string $description - What was exported (e.g., "Exported student data to Excel")
     * @param string|null $table - Table that was exported (optional)
     * @return bool
     */
    public function logExport($description, $table = null) {
        return $this->log('export', $description, $table);
    }

    /**
     * Log when a user LOGS IN
     * Call this immediately after successful login
     * 
     * @param string|null $username - Username (uses session if not provided)
     * @return bool
     */
    public function logLogin($username = null) {
        $username = $username ?? $_SESSION['username'] ?? 'Unknown user';
        return $this->log('login', "User '$username' logged in successfully");
    }

    /**
     * Log when a user LOGS OUT
     * Call this before destroying the session
     * 
     * @param string|null $username - Username (uses session if not provided)
     * @return bool
     */
    public function logLogout($username = null) {
        $username = $username ?? $_SESSION['username'] ?? 'Unknown user';
        return $this->log('logout', "User '$username' logged out");
    }

    /**
     * Get the client's real IP address
     * Handles proxies, load balancers, and various server configurations
     * 
     * @return string - Client IP address or 'Unknown'
     */
    private function getClientIP() {
        $ip = 'Unknown';
        
        // Check various server variables for IP (in order of preference)
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            // IP from shared internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // IP passed from proxy (can contain multiple IPs)
            $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ip_list[0]); // Take the first IP (original client)
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
            $ip = $_SERVER['HTTP_FORWARDED'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        // Validate IP address
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
        
        return 'Unknown';
    }

    /**
     * Convert database table names to readable format
     * 
     * @param string $table - Database table name
     * @return string - Human-readable name
     */
    private function formatTableName($table) {
        $table_names = [
            'student_researchers' => 'Student Researchers',
            'research_outputs' => 'Research Outputs',
            'student_research_team' => 'Student Research Team',
            'faculty_researchers' => 'Faculty Researchers',
            'faculty_projects' => 'Faculty Projects',
            'faculty_education' => 'Faculty Education',
            'faculty_project_team' => 'Faculty Project Team',
            'faculty_project_costs' => 'Faculty Project Costs',
            'users' => 'User Management',
            'activity_logs' => 'Activity Logs'
        ];
        
        return $table_names[$table] ?? ucwords(str_replace('_', ' ', $table));
    }

    /**
     * Get activities for a specific user
     * 
     * @param int $user_id - User ID
     * @param int $limit - Maximum records to return (1-1000)
     * @return array - Array of activity records
     */
    public function getUserActivities($user_id, $limit = 50) {
        $limit = max(1, min(1000, (int)$limit));
        
        $stmt = $this->conn->prepare("
            SELECT 
                id,
                user_id,
                action_type,
                table_affected,
                record_id,
                description,
                ip_address,
                created_at
            FROM activity_logs 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare getUserActivities - " . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }

    /**
     * Get all activities (for admin dashboard)
     * 
     * @param int $limit - Maximum records to return
     * @param int $offset - Offset for pagination
     * @return array - Array of activity records with user details
     */
    public function getAllActivities($limit = 100, $offset = 0) {
        $limit = max(1, min(1000, (int)$limit));
        $offset = max(0, (int)$offset);
        
        $stmt = $this->conn->prepare("
            SELECT 
                al.id,
                al.user_id,
                u.username,
                u.user_role,
                u.coordinator_type,
                al.action_type,
                al.table_affected,
                al.record_id,
                al.description,
                al.ip_address,
                al.created_at
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC
            LIMIT ? OFFSET ?
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare getAllActivities - " . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("ii", $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }

    /**
     * Get activities filtered by action type
     * 
     * @param string $action_type - Type to filter by (create, update, delete, etc.)
     * @param int $limit - Maximum records to return
     * @return array - Filtered activity records
     */
    public function getActivitiesByType($action_type, $limit = 50) {
        $limit = max(1, min(1000, (int)$limit));
        
        $stmt = $this->conn->prepare("
            SELECT 
                al.id,
                al.user_id,
                u.username,
                al.action_type,
                al.table_affected,
                al.record_id,
                al.description,
                al.ip_address,
                al.created_at
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE al.action_type = ?
            ORDER BY al.created_at DESC
            LIMIT ?
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare getActivitiesByType - " . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("si", $action_type, $limit);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }

    /**
     * Get complete audit trail for a specific record
     * Shows all actions ever performed on a record
     * 
     * @param string $table - Table name
     * @param int $record_id - Record ID
     * @return array - Complete history of the record
     */
    public function getRecordHistory($table, $record_id) {
        $stmt = $this->conn->prepare("
            SELECT 
                al.id,
                al.user_id,
                u.username,
                u.user_role,
                al.action_type,
                al.description,
                al.ip_address,
                al.created_at
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE al.table_affected = ? AND al.record_id = ?
            ORDER BY al.created_at DESC
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare getRecordHistory - " . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("si", $table, $record_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }

    /**
     * Get all activities for a specific table
     * 
     * @param string $table - Table name
     * @param int $limit - Maximum records to return
     * @return array - Activities for the table
     */
    public function getActivitiesByTable($table, $limit = 100) {
        $limit = max(1, min(1000, (int)$limit));
        
        $stmt = $this->conn->prepare("
            SELECT 
                al.id,
                al.user_id,
                u.username,
                al.action_type,
                al.record_id,
                al.description,
                al.ip_address,
                al.created_at
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE al.table_affected = ?
            ORDER BY al.created_at DESC
            LIMIT ?
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare getActivitiesByTable - " . $this->conn->error);
            return [];
        }
        
        $stmt->bind_param("si", $table, $limit);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }

    /**
     * Get statistics about activities
     * Returns count for each action type
     * 
     * @return array - Statistics (e.g., ['create' => 150, 'update' => 200, ...])
     */
    public function getActivityStats() {
        $query = "
            SELECT 
                action_type,
                COUNT(*) as count
            FROM activity_logs
            GROUP BY action_type
        ";
        
        $result = $this->conn->query($query);
        
        if (!$result) {
            error_log("ActivityLogger: Failed to get activity stats - " . $this->conn->error);
            return [];
        }
        
        $stats = [];
        while ($row = $result->fetch_assoc()) {
            $stats[$row['action_type']] = (int)$row['count'];
        }
        
        return $stats;
    }

    /**
     * Count activities with optional filters
     * 
     * @param array $filters - Filters: ['action_type' => 'create', 'user_id' => 5, 'table_affected' => 'students']
     * @return int - Total count
     */
    public function countActivities($filters = []) {
        $where_clauses = [];
        $params = [];
        $types = "";
        
        if (isset($filters['action_type'])) {
            $where_clauses[] = "action_type = ?";
            $params[] = $filters['action_type'];
            $types .= "s";
        }
        
        if (isset($filters['user_id'])) {
            $where_clauses[] = "user_id = ?";
            $params[] = $filters['user_id'];
            $types .= "i";
        }
        
        if (isset($filters['table_affected'])) {
            $where_clauses[] = "table_affected = ?";
            $params[] = $filters['table_affected'];
            $types .= "s";
        }
        
        $where_sql = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";
        $query = "SELECT COUNT(*) as total FROM activity_logs $where_sql";
        
        if (!empty($params)) {
            $stmt = $this->conn->prepare($query);
            if (!$stmt) return 0;
            
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            return (int)$result['total'];
        } else {
            $result = $this->conn->query($query);
            if (!$result) return 0;
            
            $row = $result->fetch_assoc();
            return (int)$row['total'];
        }
    }

    /**
     * Check if a specific action was performed on a record
     * Useful for verification and audit purposes
     * 
     * @param string $table - Table name
     * @param int $record_id - Record ID
     * @param string $action_type - Action to check for (e.g., 'delete')
     * @return bool - True if action exists, false otherwise
     */
    public function hasAction($table, $record_id, $action_type) {
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as count 
            FROM activity_logs 
            WHERE table_affected = ? 
            AND record_id = ? 
            AND action_type = ?
        ");
        
        if (!$stmt) {
            return false;
        }
        
        $stmt->bind_param("sis", $table, $record_id, $action_type);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result['count'] > 0;
    }

    /**
     * Clean up old log entries (maintenance function)
     * Run this periodically to keep database size manageable
     * 
     * @param int $days - Delete logs older than this many days (minimum: 1, default: 90)
     * @return bool - True on success
     */
    public function cleanOldLogs($days = 90) {
        $days = max(1, (int)$days); // Minimum 1 day
        
        $stmt = $this->conn->prepare("
            DELETE FROM activity_logs 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        
        if (!$stmt) {
            error_log("ActivityLogger: Failed to prepare cleanOldLogs - " . $this->conn->error);
            return false;
        }
        
        $stmt->bind_param("i", $days);
        $result = $stmt->execute();
        
        if ($result) {
            $deleted_count = $stmt->affected_rows;
            error_log("ActivityLogger: Successfully cleaned $deleted_count log entries older than $days days");
        } else {
            error_log("ActivityLogger: Failed to clean old logs - " . $stmt->error);
        }
        
        $stmt->close();
        return $result;
    }
}
?>
