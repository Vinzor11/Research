<?php
/**
 * Extension Request View Page
 * Unified design matching collaboration_view.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'ProjectService.php';
require_once 'spa_helper.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$isSpa = isSpaRequest();
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';

// Get extension ID
$extensionId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$extensionId) {
    if ($isSpa) {
        echo '<div class="error-state" style="padding: 40px; text-align: center;">
            <h3><i class="fa fa-exclamation-triangle" style="color: #f59e0b;"></i> Invalid Extension ID</h3>
            <p>No extension ID was provided in the URL.</p>
            <p style="color: #6b7280; font-size: 14px; margin-top: 16px;">
                This may happen if you accessed this page via an invalid link.<br>
                Please go back to the <a href="work_queue.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'work_queue.php\',true)}">Work Queue</a> 
                or <a href="research.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'research.php\',true)}">My Projects</a> and try again.
            </p>
        </div>';
    } else {
        header('Location: research.php');
    }
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$projectService = new ProjectService($conn);

// Fetch extension with project info
$stmt = $conn->prepare("
    SELECT pe.*, 
           rs.title as project_title,
           rs.project_code,
           rs.reference_number as project_reference,
           rs.created_by as project_owner,
           rs.researcher_type,
           u.fullname as requested_by_name,
           u.email as requester_email,
           cr.fullname as coordinator_name,
           ro.fullname as ro_reviewer_name
    FROM project_extensions pe
    JOIN research_submissions rs ON pe.project_id = rs.id
    LEFT JOIN users u ON pe.requested_by = u.id
    LEFT JOIN users cr ON pe.coordinator_reviewed_by = cr.id
    LEFT JOIN users ro ON pe.ro_reviewed_by = ro.id
    WHERE pe.id = ?
");
$stmt->bind_param("i", $extensionId);
$stmt->execute();
$extension = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$extension) {
    echo '<div class="error-state"><h3>Extension Not Found</h3><p>The requested extension could not be found.</p></div>';
    exit;
}

// Get project details for access check
$project = $projectService->getProject($extension['project_id']);

// Check access permission
$isOwner = ($project['created_by'] == $userId);
$isAdmin = ($userRole === 'admin');
$isCoordinator = ($userRole === 'coordinator');

if (!$isOwner && !$isAdmin && !$isCoordinator) {
    echo '<div class="error-state"><h3>Access Denied</h3><p>You do not have permission to view this extension.</p></div>';
    exit;
}

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Calculate extension duration
$extensionMonths = null;
if ($extension['original_end_date'] && $extension['requested_end_date']) {
    $original = new DateTime($extension['original_end_date']);
    $requested = new DateTime($extension['requested_end_date']);
    $diff = $original->diff($requested);
    $extensionMonths = ($diff->y * 12) + $diff->m + ($diff->d > 15 ? 1 : 0);
}

// Type configuration
$typeConfig = [
    'timeline' => ['icon' => 'clock', 'color' => '#3b82f6', 'label' => 'Timeline Extension'],
    'budget' => ['icon' => 'coins', 'color' => '#f59e0b', 'label' => 'Budget Extension'],
    'scope' => ['icon' => 'expand-alt', 'color' => '#8b5cf6', 'label' => 'Scope Change'],
    'timeline_budget' => ['icon' => 'calendar-plus', 'color' => '#10b981', 'label' => 'Timeline & Budget Extension']
];
$typeData = $typeConfig[$extension['extension_type']] ?? ['icon' => 'file', 'color' => '#64748b', 'label' => 'Extension Request'];

// Status configuration
$statusConfig = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'class' => 'status-draft'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'class' => 'status-submitted'],
    'reviewed' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_review' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_coordinator_review' => ['label' => 'Under Review', 'icon' => 'fa-user-tie', 'class' => 'status-reviewing'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'class' => 'status-endorsed'],
    'under_ro_review' => ['label' => 'RO Review', 'icon' => 'fa-building', 'class' => 'status-reviewing'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-thumbs-up', 'class' => 'status-approved'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'class' => 'status-rejected'],
    'returned' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned'],
    'returned_for_revision' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned']
];
$currentStatus = $statusConfig[$extension['status']] ?? ['label' => ucfirst(str_replace('_', ' ', $extension['status'])), 'icon' => 'fa-info-circle', 'class' => 'status-draft'];
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   EXTENSION VIEW - UNIFIED DESIGN
   ============================================ */

.ext-header-banner {
    background: linear-gradient(135deg, <?= $typeData['color'] ?> 0%, <?= adjustBrightness($typeData['color'], -30) ?> 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.ext-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.ext-header-left { flex: 1; }

.ext-header-left h1 {
    font-size: 24px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.3;
    display: flex;
    align-items: center;
    gap: 12px;
}

.ext-header-left .project-link {
    font-size: 14px;
    color: rgba(255,255,255,0.9);
    margin-bottom: 12px;
}

.ext-header-left .project-link a {
    color: white;
    text-decoration: none;
}

.ext-header-left .project-link a:hover {
    text-decoration: underline;
}

.ext-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.ext-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255,255,255,0.2);
    color: white;
}

.ext-header-right { text-align: right; }

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted { color: #2563eb; }
.status-reviewing { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-rejected { color: #dc2626; }
.status-returned { color: #ea580c; }

/* Status Timeline */
.status-timeline {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 16px 20px;
    background: #f9fafb;
    border-radius: 8px;
    overflow-x: auto;
}

.timeline-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    min-width: 80px;
    flex: 1;
    position: relative;
}

.timeline-step::after {
    content: '';
    position: absolute;
    top: 16px;
    right: -50%;
    width: 100%;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
}

.timeline-step:last-child::after { display: none; }
.timeline-step.completed::after { background: #10b981; }
.timeline-step.current::after { background: linear-gradient(90deg, #10b981 50%, #e5e7eb 50%); }

.timeline-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    color: #9ca3af;
    font-size: 12px;
    position: relative;
    z-index: 1;
}

.timeline-step.completed .timeline-icon { background: #d1fae5; color: #059669; }
.timeline-step.current .timeline-icon { background: #dbeafe; color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2); }
.timeline-step.rejected .timeline-icon { background: #fee2e2; color: #dc2626; }

.timeline-label {
    font-size: 10px;
    color: #6b7280;
    text-align: center;
    white-space: nowrap;
}

.timeline-step.current .timeline-label { color: #1f2937; font-weight: 600; }

/* Content Layout */
.ext-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.ext-main { display: flex; flex-direction: column; gap: 24px; }
.ext-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: <?= $typeData['color'] ?>; }

.section-body { padding: 20px; }

/* Detail Grid */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.5;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

/* Prevent layout break from long text */
.section-card {
    min-width: 0;
    overflow: hidden;
}

.section-body {
    overflow-wrap: break-word;
    word-break: break-word;
}

.ext-main, .ext-sidebar {
    min-width: 0;
}

.detail-value.highlight { color: #059669; font-weight: 600; }
.detail-value.money { color: #f59e0b; font-weight: 600; font-size: 16px; }

/* Timeline Comparison */
.timeline-compare {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: 16px;
    align-items: center;
    background: #f9fafb;
    padding: 20px;
    border-radius: 8px;
}

.timeline-item { text-align: center; }
.timeline-item .label {
    font-size: 11px;
    color: #6b7280;
    text-transform: uppercase;
    margin-bottom: 6px;
}
.timeline-item .date { font-size: 15px; font-weight: 600; color: #1f2937; }
.timeline-item.new .date { color: #059669; }
.timeline-arrow { font-size: 20px; color: #9ca3af; }

.extension-badge {
    display: inline-block;
    background: <?= $typeData['color'] ?>;
    color: white;
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.btn-endorse { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%); color: white; }
.btn-endorse:hover { background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%); }

.btn-approve { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-approve:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-return { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.btn-return:hover { background: #fde68a; }

.btn-reject { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.btn-reject:hover { background: #fecaca; }

/* Info List */
.info-list { display: flex; flex-direction: column; gap: 12px; }
.info-item { display: flex; flex-direction: column; gap: 2px; }
.info-label { font-size: 11px; color: #6b7280; text-transform: uppercase; }
.info-value { font-size: 14px; color: #1f2937; font-weight: 500; }

.researcher-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    background: #dbeafe;
    color: #1e40af;
}

/* Review Section */
.review-item {
    padding: 16px;
    background: #f9fafb;
    border-radius: 8px;
    margin-bottom: 12px;
}

.review-item:last-child { margin-bottom: 0; }

.review-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.review-title {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    display: flex;
    align-items: center;
    gap: 8px;
}

.recommendation-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

.recommendation-badge.endorse { background: #d1fae5; color: #065f46; }
.recommendation-badge.return { background: #fef3c7; color: #92400e; }
.recommendation-badge.reject { background: #fee2e2; color: #991b1b; }

.review-meta { font-size: 12px; color: #6b7280; margin-bottom: 8px; }
.review-content { font-size: 13px; color: #4b5563; line-height: 1.5; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 { font-size: 18px; color: #1f2937; margin: 0; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #6b7280; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e5e7eb; display: flex; justify-content: flex-end; gap: 12px; }

/* Modal Buttons */
.modal-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s ease;
}
.modal-btn i { font-size: 13px; }
.modal-btn-secondary {
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
}
.modal-btn-secondary:hover { background: #e5e7eb; border-color: #9ca3af; }
.modal-btn-primary {
    background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(124, 58, 237, 0.3);
}
.modal-btn-primary:hover {
    background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4);
}
.modal-btn-success {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(5, 150, 105, 0.3);
}
.modal-btn-success:hover {
    background: linear-gradient(135deg, #047857 0%, #059669 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(5, 150, 105, 0.4);
}
.modal-btn-warning {
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(217, 119, 6, 0.3);
}
.modal-btn-warning:hover {
    background: linear-gradient(135deg, #b45309 0%, #d97706 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(217, 119, 6, 0.4);
}
.modal-btn-danger {
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
}
.modal-btn-danger:hover {
    background: linear-gradient(135deg, #b91c1c 0%, #dc2626 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
}

.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
.form-group input, .form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
}
.form-group textarea { min-height: 100px; resize: vertical; }

/* Responsive */
@media (max-width: 1024px) {
    .ext-content { grid-template-columns: 1fr; }
    .ext-sidebar { order: -1; }
}

@media (max-width: 768px) {
    .ext-header-content { flex-direction: column; }
    .ext-header-right { text-align: left; }
    .detail-grid { grid-template-columns: 1fr; }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = hexdec(substr($hex, 4, 2));
    $b = max(0, min(255, $b + $steps));
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>

<div class="content">
    <!-- Header Banner -->
    <div class="ext-header-banner">
        <div class="ext-header-content">
            <div class="ext-header-left">
                <div class="project-link">
                    <i class="fa fa-folder"></i>
                    <a href="project_view.php?id=<?= $extension['project_id'] ?>" 
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $extension['project_id'] ?>',true)}">
                        <?= s($extension['project_title']) ?>
                    </a>
                    <?php if ($extension['project_code']): ?>
                        <span style="opacity: 0.7;">(<?= s($extension['project_code']) ?>)</span>
                    <?php endif; ?>
                </div>
                <h1>
                    <i class="fa fa-<?= $typeData['icon'] ?>"></i>
                    <?= $typeData['label'] ?>
                </h1>
                <div class="ext-header-badges">
                    <span class="ext-badge">
                        <i class="fa fa-calendar"></i>
                        Requested <?= date('M d, Y', strtotime($extension['created_at'])) ?>
                    </span>
                    <?php if ($extensionMonths): ?>
                    <span class="ext-badge">
                        <i class="fa fa-clock"></i>
                        +<?= $extensionMonths ?> Month(s)
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="ext-header-right">
                <span class="status-badge-large <?= $currentStatus['class'] ?>">
                    <i class="fa <?= $currentStatus['icon'] ?>"></i>
                    <?= $currentStatus['label'] ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Status Timeline -->
    <div class="section-card" style="margin-bottom: 24px;">
        <div class="status-timeline">
            <?php
            $workflowSteps = [
                'draft' => 'Draft',
                'submitted' => 'Submitted',
                'under_coordinator_review' => 'Coord. Review',
                'endorsed' => 'Endorsed',
                'under_ro_review' => 'RO Review',
                'approved' => 'Approved'
            ];
            
            $currentFound = false;
            $isRejected = $extension['status'] === 'rejected';
            $isReturned = $extension['status'] === 'returned';
            
            foreach ($workflowSteps as $stepKey => $stepLabel):
                $stepClass = '';
                if ($isRejected && $stepKey === 'approved') {
                    $stepClass = 'rejected';
                    $stepLabel = 'Rejected';
                } elseif (!$currentFound) {
                    if ($stepKey === $extension['status']) {
                        $stepClass = 'current';
                        $currentFound = true;
                    } elseif ($isReturned && $stepKey === 'draft') {
                        $stepClass = 'current';
                        $currentFound = true;
                        $stepLabel = 'Returned';
                    } else {
                        $stepClass = 'completed';
                    }
                }
            ?>
            <div class="timeline-step <?= $stepClass ?>">
                <div class="timeline-icon">
                    <i class="fa <?= $stepClass === 'completed' ? 'fa-check' : ($stepClass === 'rejected' ? 'fa-times' : 'fa-circle') ?>"></i>
                </div>
                <span class="timeline-label"><?= $stepLabel ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="ext-content">
        <!-- Main Content -->
        <div class="ext-main">
            <?php if (in_array($extension['extension_type'], ['timeline', 'timeline_budget'])): ?>
            <!-- Timeline Extension Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline Extension</h3>
                </div>
                <div class="section-body">
                    <div class="timeline-compare">
                        <div class="timeline-item">
                            <div class="label">Original End Date</div>
                            <div class="date"><?= $extension['original_end_date'] ? date('M d, Y', strtotime($extension['original_end_date'])) : 'Not set' ?></div>
                        </div>
                        <div class="timeline-arrow"><i class="fa fa-arrow-right"></i></div>
                        <div class="timeline-item new">
                            <div class="label">Requested End Date</div>
                            <div class="date"><?= $extension['requested_end_date'] ? date('M d, Y', strtotime($extension['requested_end_date'])) : 'Not set' ?></div>
                        </div>
                    </div>
                    <?php if ($extensionMonths): ?>
                    <p style="text-align: center; margin-top: 16px;">
                        <span class="extension-badge"><i class="fa fa-calendar-plus"></i> +<?= $extensionMonths ?> month(s) extension</span>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (in_array($extension['extension_type'], ['budget', 'timeline_budget'])): ?>
            <!-- Budget Extension Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-coins"></i> Budget Extension</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Original Budget</span>
                            <span class="detail-value">₱<?= number_format($extension['original_budget'] ?? 0, 2) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Additional Budget Requested</span>
                            <span class="detail-value money">+₱<?= number_format($extension['requested_additional_budget'] ?? 0, 2) ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Justification -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-file-alt"></i> Justification</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($extension['justification'])) ?></div>
                </div>
            </div>

            <!-- Review History -->
            <?php if ($extension['coordinator_reviewed_by'] || $extension['ro_reviewed_by']): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-history"></i> Review History</h3>
                </div>
                <div class="section-body">
                    <?php if ($extension['coordinator_reviewed_by']): ?>
                    <div class="review-item">
                        <div class="review-header">
                            <span class="review-title">
                                <i class="fa fa-user-tie"></i> Coordinator Review
                            </span>
                            <?php if ($extension['coordinator_recommendation']): ?>
                                <span class="recommendation-badge <?= $extension['coordinator_recommendation'] ?>">
                                    <?= ucfirst($extension['coordinator_recommendation']) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="review-meta">
                            Reviewed by <?= s($extension['coordinator_name']) ?> on <?= date('M d, Y \a\t g:i A', strtotime($extension['coordinator_reviewed_at'])) ?>
                        </div>
                        <?php if ($extension['coordinator_remarks']): ?>
                        <div class="review-content"><?= nl2br(s($extension['coordinator_remarks'])) ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($extension['ro_reviewed_by']): ?>
                    <div class="review-item">
                        <div class="review-header">
                            <span class="review-title">
                                <i class="fa fa-building"></i> Research Office Review
                            </span>
                        </div>
                        <div class="review-meta">
                            Reviewed by <?= s($extension['ro_reviewer_name']) ?> on <?= date('M d, Y \a\t g:i A', strtotime($extension['ro_reviewed_at'])) ?>
                        </div>
                        <?php if ($extension['ro_remarks']): ?>
                        <div class="review-content"><?= nl2br(s($extension['ro_remarks'])) ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($extension['status'] === 'approved'): ?>
            <!-- Approval Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-check-circle" style="color: #10b981 !important;"></i> Approval Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <?php if ($extension['approved_end_date']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Approved End Date</span>
                            <span class="detail-value highlight"><?= date('M d, Y', strtotime($extension['approved_end_date'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($extension['approved_additional_budget']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Approved Additional Budget</span>
                            <span class="detail-value highlight">₱<?= number_format($extension['approved_additional_budget'], 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($extension['approval_conditions']): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Conditions</span>
                            <span class="detail-value"><?= nl2br(s($extension['approval_conditions'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="ext-sidebar">
            <!-- Actions -->
            <?php if (($isCoordinator || $isAdmin) && in_array($extension['status'], ['submitted', 'under_coordinator_review', 'endorsed', 'under_ro_review'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if ($isCoordinator && in_array($extension['status'], ['submitted', 'under_coordinator_review'])): ?>
                            <button onclick="showEndorseModal()" class="action-btn btn-endorse">
                                <i class="fa fa-check"></i> Endorse to Research Office
                            </button>
                            <button onclick="showReturnModal()" class="action-btn btn-return">
                                <i class="fa fa-undo"></i> Return for Revision
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($isAdmin && in_array($extension['status'], ['endorsed', 'under_ro_review'])): ?>
                            <button onclick="showApproveModal()" class="action-btn btn-approve">
                                <i class="fa fa-check"></i> Approve Extension
                            </button>
                            <button onclick="showReturnModal()" class="action-btn btn-return">
                                <i class="fa fa-undo"></i> Return for Revision
                            </button>
                            <button onclick="rejectExtension()" class="action-btn btn-reject">
                                <i class="fa fa-times"></i> Reject
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Requester Info -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-user"></i> Requester</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Researcher Type</span>
                            <span class="researcher-badge"><?= strtoupper($extension['researcher_type'] ?? 'FACULTY') ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Name</span>
                            <span class="info-value"><?= s($extension['requested_by_name']) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Created</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($extension['created_at'])) ?></span>
                        </div>
                        <?php if ($extension['requested_at']): ?>
                        <div class="info-item">
                            <span class="info-label">Submitted</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($extension['requested_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($extension['coordinator_reviewed_at']): ?>
                        <div class="info-item">
                            <span class="info-label">Coordinator Review</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($extension['coordinator_reviewed_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($extension['decision_at']): ?>
                        <div class="info-item">
                            <span class="info-label">Decision</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($extension['decision_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Back Button -->
            <div class="section-card">
                <div class="section-body" style="padding: 12px 20px;">
                    <?php if ($isCoordinator || $isAdmin): ?>
                    <a href="work_queue.php" class="action-btn btn-return" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('work_queue.php',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Work Queue
                    </a>
                    <?php else: ?>
                    <a href="project_view.php?id=<?= $extension['project_id'] ?>&tab=extensions" class="action-btn btn-return" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $extension['project_id'] ?>&tab=extensions',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Project
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Return Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-undo"></i> Return for Revision</h3>
            <button class="modal-close" onclick="closeReturnModal()">&times;</button>
        </div>
        <form id="returnForm" method="POST" onsubmit="return false;">
            <div class="modal-body">
                <div class="form-group">
                    <label>Comments / Reason for Return</label>
                    <textarea name="remarks" required placeholder="Explain what needs to be revised..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeReturnModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-warning">
                    <i class="fa fa-undo"></i> Return
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-check-double" style="color: #7c3aed;"></i> Endorse Extension Request</h3>
            <button class="modal-close" onclick="closeEndorseModal()">&times;</button>
        </div>
        <form id="endorseForm" method="POST" onsubmit="return false;">
            <div class="modal-body">
                <p style="color: #6b7280; margin-bottom: 20px;">Please verify the following before endorsing this extension request:</p>
                
                <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="justification_valid" value="1" required>
                        <span>Justification is valid and reasonable</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="timeline_reasonable" value="1" required>
                        <span>Requested timeline/budget is reasonable</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="documents_complete" value="1" required>
                        <span>Required documents are complete</span>
                    </label>
                </div>
                
                <div class="form-group">
                    <label>Endorsement Remarks (Optional)</label>
                    <textarea name="remarks" placeholder="Any remarks for the Research Office..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeEndorseModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-primary">
                    <i class="fa fa-check-double"></i> Endorse
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-check-circle"></i> Approve Extension</h3>
            <button class="modal-close" onclick="closeApproveModal()">&times;</button>
        </div>
        <form id="approveForm" method="POST" onsubmit="return false;">
            <div class="modal-body">
                <?php if (in_array($extension['extension_type'], ['timeline', 'timeline_budget'])): ?>
                <div class="form-group">
                    <label>Approved End Date</label>
                    <input type="date" name="approved_end_date" value="<?= $extension['requested_end_date'] ?>" required>
                </div>
                <?php endif; ?>
                <?php if (in_array($extension['extension_type'], ['budget', 'timeline_budget'])): ?>
                <div class="form-group">
                    <label>Approved Additional Budget</label>
                    <input type="number" name="approved_additional_budget" value="<?= $extension['requested_additional_budget'] ?>" step="0.01" required>
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label>Conditions (Optional)</label>
                    <textarea name="approval_conditions" placeholder="Any conditions for this approval..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeApproveModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-success">
                    <i class="fa fa-check"></i> Approve
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const extensionId = <?= $extensionId ?>;

// Endorse Modal Functions
function showEndorseModal() {
    document.getElementById('endorseModal').classList.add('active');
}

function closeEndorseModal() {
    document.getElementById('endorseModal').classList.remove('active');
    document.getElementById('endorseForm').reset();
}

// Handle endorse form submission
document.getElementById('endorseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const justificationValid = form.querySelector('input[name="justification_valid"]').checked;
    const timelineReasonable = form.querySelector('input[name="timeline_reasonable"]').checked;
    const documentsComplete = form.querySelector('input[name="documents_complete"]').checked;
    const remarks = form.querySelector('textarea[name="remarks"]').value;
    
    if (!justificationValid || !timelineReasonable || !documentsComplete) {
        alert('Please check all validation items before endorsing.');
        return;
    }
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'endorse_extension',
            extension_id: extensionId,
            validation_data: {
                justification_valid: justificationValid,
                timeline_reasonable: timelineReasonable,
                documents_complete: documentsComplete
            },
            remarks: remarks
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Extension endorsed successfully!');
            closeEndorseModal();
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to endorse'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
});

// Return Modal Functions
function showReturnModal() {
    document.getElementById('returnModal').classList.add('active');
}

function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('active');
}

document.getElementById('returnForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const remarks = this.remarks.value;
    
    const isROAdmin = <?= $isAdmin ? 'true' : 'false' ?>;
    const status = '<?= $extension['status'] ?>';
    
    let action = 'return_extension';
    if (isROAdmin && (status === 'endorsed' || status === 'under_ro_review')) {
        action = 'return_extension_to_coordinator';
    }
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: action,
            extension_id: extensionId,
            reason: remarks
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Extension returned for revision.');
            closeReturnModal();
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to return'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
});

function showApproveModal() {
    document.getElementById('approveModal').classList.add('active');
}

function closeApproveModal() {
    document.getElementById('approveModal').classList.remove('active');
}

document.getElementById('approveForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    const payload = {
        action: 'approve_extension',
        extension_id: extensionId,
        approval_conditions: formData.get('approval_conditions') || ''
    };
    
    if (formData.get('approved_end_date')) {
        payload.approved_end_date = formData.get('approved_end_date');
    }
    if (formData.get('approved_additional_budget')) {
        payload.approved_additional_budget = parseFloat(formData.get('approved_additional_budget'));
    }
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Extension approved successfully!');
            closeApproveModal();
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to approve'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
});

function rejectExtension() {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'reject_extension',
            extension_id: extensionId,
            reason: reason
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Extension rejected.');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to reject'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}
</script>
