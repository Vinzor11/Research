<?php
/**
 * UnifiedQueueService.php
 * 
 * Provides a centralized, role-based work queue that aggregates actionable items
 * from multiple sources (proposals, progress reports, extensions, outputs, completions,
 * and collaborations) into a single normalized interface.
 * 
 * CORE RULE: "Only submitted, decision-requiring requests appear in the Work Queue;
 * coordinators endorse, the Research Office approves, and all actions are audit-logged."
 * 
 * This service enforces strict backend filtering based on user role and scope.
 * 
 * STATUS LIFECYCLE (all request types):
 *   draft → submitted → under_coordinator_review → [returned_for_revision] → 
 *   endorsed → under_ro_review → approved/rejected
 * 
 * KEY RULES:
 * - Draft requests NEVER appear in Work Queue
 * - Only submitted, decision-requiring items appear
 * - Returned items are removed from queue until re-submitted
 * - Coordinators can endorse or return for revision - NOT approve
 * - Research Office is the ONLY final approving authority
 * - Every status change MUST be audit logged
 * 
 * @version 2.0
 * @date 2026-02-06
 */

require_once 'db.php';
require_once 'WorkflowAuditLogger.php';

class UnifiedQueueService {
    private $conn;
    private $userId;
    private $userRole;
    private $coordinatorTypes = [];
    private $employeeId;
    private $auditLogger;
    
    // Item type constants
    const TYPE_PROPOSAL = 'proposal';
    const TYPE_PROGRESS = 'progress';
    const TYPE_EXTENSION = 'extension';
    const TYPE_OUTPUT = 'output';
    const TYPE_COMPLETION = 'completion';
    const TYPE_COLLABORATION = 'collaboration';
    
    // Unified Status Constants - Apply to ALL request types
    const STATUS_DRAFT = 'draft';
    const STATUS_SUBMITTED = 'submitted';
    const STATUS_COORDINATOR_REVIEW = 'under_coordinator_review';
    const STATUS_RETURNED_FOR_REVISION = 'returned_for_revision';
    const STATUS_ENDORSED = 'endorsed';
    const STATUS_RO_REVIEW = 'under_ro_review';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    
    // Backward compatibility aliases
    const STATUS_RETURNED = 'returned_for_revision';
    
    // Handler Types
    const HANDLER_RESEARCHER = 'researcher';
    const HANDLER_COORDINATOR = 'coordinator';
    const HANDLER_RESEARCH_OFFICE = 'research_office';
    
    public function __construct($conn, $userId) {
        $this->conn = $conn;
        $this->userId = $userId;
        $this->userRole = $_SESSION['user_role'] ?? 'researcher';
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        $this->auditLogger = new WorkflowAuditLogger($conn);
        
        // Load coordinator types if user is coordinator
        if ($this->userRole === 'coordinator' && $this->employeeId) {
            $this->loadCoordinatorTypes();
        }
    }
    
    /**
     * Load coordinator types for the current user
     */
    private function loadCoordinatorTypes() {
        $stmt = $this->conn->prepare("
            SELECT coordinator_type 
            FROM coordinator_assignments 
            WHERE employee_id = ? AND status = 'active'
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $this->coordinatorTypes[] = $row['coordinator_type'];
        }
        $stmt->close();
    }
    
    /**
     * Get unified queue items based on user role
     * 
     * @param array $filters - Optional filters (type, status, unit, search, date_from, date_to)
     * @param int $page - Page number for pagination
     * @param int $perPage - Items per page
     * @return array - Normalized queue items with pagination
     */
    public function getQueueItems($filters = [], $page = 1, $perPage = 20) {
        if ($this->userRole === 'admin') {
            return $this->getAdminQueueItems($filters, $page, $perPage);
        } elseif ($this->userRole === 'coordinator') {
            return $this->getCoordinatorQueueItems($filters, $page, $perPage);
        }
        
        return ['data' => [], 'pagination' => $this->emptyPagination($page, $perPage)];
    }
    
    /**
     * Get queue items for Research Office Admin (institution-wide)
     */
    private function getAdminQueueItems($filters, $page, $perPage) {
        $items = [];
        $typeFilter = $filters['type'] ?? null;
        
        // Proposals - items endorsed by coordinator, pending RO review
        if (!$typeFilter || $typeFilter === self::TYPE_PROPOSAL) {
            $proposals = $this->getProposalItems('admin', $filters);
            $items = array_merge($items, $proposals);
        }
        
        // Progress Reports - submitted/endorsed items
        if (!$typeFilter || $typeFilter === self::TYPE_PROGRESS) {
            $progress = $this->getProgressReportItems('admin', $filters);
            $items = array_merge($items, $progress);
        }
        
        // Extension Requests - endorsed items pending RO review
        if (!$typeFilter || $typeFilter === self::TYPE_EXTENSION) {
            $extensions = $this->getExtensionItems('admin', $filters);
            $items = array_merge($items, $extensions);
        }
        
        // Output Reports - submitted items
        if (!$typeFilter || $typeFilter === self::TYPE_OUTPUT) {
            $outputs = $this->getOutputItems('admin', $filters);
            $items = array_merge($items, $outputs);
        }
        
        // Completion Reports - endorsed items pending RO review
        if (!$typeFilter || $typeFilter === self::TYPE_COMPLETION) {
            $completions = $this->getCompletionItems('admin', $filters);
            $items = array_merge($items, $completions);
        }
        
        // Collaboration Requests - endorsed items pending RO approval
        if (!$typeFilter || $typeFilter === self::TYPE_COLLABORATION) {
            $collaborations = $this->getCollaborationItems('admin', $filters);
            $items = array_merge($items, $collaborations);
        }
        
        return $this->paginateAndSort($items, $page, $perPage, $filters);
    }
    
    /**
     * Get queue items for Coordinator (scoped by assigned types and units)
     */
    private function getCoordinatorQueueItems($filters, $page, $perPage) {
        if (empty($this->coordinatorTypes)) {
            return ['data' => [], 'pagination' => $this->emptyPagination($page, $perPage)];
        }
        
        $items = [];
        $typeFilter = $filters['type'] ?? null;
        
        // Proposals - submitted items pending coordinator review
        if (!$typeFilter || $typeFilter === self::TYPE_PROPOSAL) {
            $proposals = $this->getProposalItems('coordinator', $filters);
            $items = array_merge($items, $proposals);
        }
        
        // Progress Reports
        if (!$typeFilter || $typeFilter === self::TYPE_PROGRESS) {
            $progress = $this->getProgressReportItems('coordinator', $filters);
            $items = array_merge($items, $progress);
        }
        
        // Extension Requests
        if (!$typeFilter || $typeFilter === self::TYPE_EXTENSION) {
            $extensions = $this->getExtensionItems('coordinator', $filters);
            $items = array_merge($items, $extensions);
        }
        
        // Output Reports
        if (!$typeFilter || $typeFilter === self::TYPE_OUTPUT) {
            $outputs = $this->getOutputItems('coordinator', $filters);
            $items = array_merge($items, $outputs);
        }
        
        // Completion Reports
        if (!$typeFilter || $typeFilter === self::TYPE_COMPLETION) {
            $completions = $this->getCompletionItems('coordinator', $filters);
            $items = array_merge($items, $completions);
        }
        
        // Collaboration Requests - submitted items pending coordinator review
        if (!$typeFilter || $typeFilter === self::TYPE_COLLABORATION) {
            $collaborations = $this->getCollaborationItems('coordinator', $filters);
            $items = array_merge($items, $collaborations);
        }
        
        return $this->paginateAndSort($items, $page, $perPage, $filters);
    }
    
    /**
     * Get proposal items for the queue
     */
    private function getProposalItems($role, $filters) {
        $items = [];
        
        if ($role === 'admin') {
            // Admin sees ONLY endorsed proposals pending RO review (not coordinator-level items)
            $statusCondition = "rs.status IN ('endorsed', 'under_ro_review')";
        } else {
            // Coordinator sees submitted proposals for their researcher types
            $statusCondition = "rs.status IN ('submitted', 'under_coordinator_review')";
        }
        
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.title as project_title,
                rs.status,
                rs.researcher_type,
                rs.created_by as requester_id,
                rs.submitted_at,
                rs.created_at,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM research_submissions rs
            LEFT JOIN faculty_researchers fr ON rs.researcher_id = fr.id AND rs.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON rs.researcher_id = sr.id AND rs.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON rs.researcher_id = pr.id AND rs.researcher_type = 'personnel'
            LEFT JOIN users u ON rs.created_by = u.id
            WHERE {$statusCondition}
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND rs.researcher_type IN ({$types})";
            
            // CRITICAL: Exclude self-created submissions - coordinators cannot endorse their own work
            // This prevents items from appearing in queue when self-endorsement is not allowed
            $sql .= " AND rs.created_by != " . intval($this->userId);
            
            // Also exclude coordinator-submitted items where the coordinator is the submitter
            if ($this->employeeId) {
                $escapedEmployeeId = $this->conn->real_escape_string($this->employeeId);
                $sql .= " AND NOT (rs.submitted_by_coordinator = 1 AND rs.submitter_coordinator_employee_id = '{$escapedEmployeeId}')";
            }
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (rs.reference_number LIKE '%{$search}%' OR rs.title LIKE '%{$search}%')";
        }
        
        // Apply status filter
        if (!empty($filters['status'])) {
            $status = $this->conn->real_escape_string($filters['status']);
            $sql .= " AND rs.status = '{$status}'";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(COALESCE(rs.submitted_at, rs.created_at)) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(COALESCE(rs.submitted_at, rs.created_at)) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY COALESCE(rs.submitted_at, rs.created_at) DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeItem($row, self::TYPE_PROPOSAL, 'research_submissions');
            }
        }
        
        return $items;
    }
    
    /**
     * Get progress report items for the queue
     * 
     * Progress Report Lifecycle:
     *   draft → submitted → under_coordinator_review → [returned_for_revision] → 
     *   endorsed → under_ro_review → approved/rejected
     */
    private function getProgressReportItems($role, $filters) {
        $items = [];
        
        if ($role === 'admin') {
            // Admin sees only endorsed progress reports awaiting RO decision
            // 'endorsed' = coordinator validated, now needs RO approval
            // 'under_ro_review' = RO has started review
            $statusCondition = "ppr.status IN ('endorsed', 'under_ro_review')";
        } else {
            // Coordinator sees submitted progress reports awaiting review
            // 'submitted' = new submission awaiting coordinator
            // 'under_coordinator_review' = coordinator reviewing
            $statusCondition = "ppr.status IN ('submitted', 'under_coordinator_review')";
        }
        
        $sql = "
            SELECT 
                ppr.id,
                ppr.project_id,
                ppr.report_period,
                ppr.status,
                ppr.submitted_by as requester_id,
                ppr.submitted_at,
                ppr.created_at,
                rs.reference_number,
                rs.title as project_title,
                rs.researcher_type,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_progress_reports ppr
            JOIN research_submissions rs ON ppr.project_id = rs.id
            LEFT JOIN faculty_researchers fr ON rs.researcher_id = fr.id AND rs.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON rs.researcher_id = sr.id AND rs.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON rs.researcher_id = pr.id AND rs.researcher_type = 'personnel'
            LEFT JOIN users u ON ppr.submitted_by = u.id
            WHERE {$statusCondition}
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND rs.researcher_type IN ({$types})";
            
            // Exclude self-submitted progress reports - coordinators cannot endorse their own work
            $sql .= " AND ppr.submitted_by != " . intval($this->userId);
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (rs.reference_number LIKE '%{$search}%' OR rs.title LIKE '%{$search}%' OR ppr.report_period LIKE '%{$search}%')";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(COALESCE(ppr.submitted_at, ppr.created_at)) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(COALESCE(ppr.submitted_at, ppr.created_at)) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY COALESCE(ppr.submitted_at, ppr.created_at) DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeItem($row, self::TYPE_PROGRESS, 'project_progress_reports');
            }
        }
        
        return $items;
    }
    
    /**
     * Get extension items for the queue
     */
    private function getExtensionItems($role, $filters) {
        $items = [];
        
        if ($role === 'admin') {
            $statusCondition = "pe.status IN ('endorsed', 'under_ro_review')";
        } else {
            $statusCondition = "pe.status IN ('submitted', 'under_coordinator_review')";
        }
        
        $sql = "
            SELECT 
                pe.id,
                pe.project_id,
                pe.extension_type,
                pe.status,
                pe.requested_by as requester_id,
                pe.created_at as submitted_at,
                pe.created_at,
                rs.reference_number,
                rs.title as project_title,
                rs.researcher_type,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            LEFT JOIN faculty_researchers fr ON rs.researcher_id = fr.id AND rs.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON rs.researcher_id = sr.id AND rs.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON rs.researcher_id = pr.id AND rs.researcher_type = 'personnel'
            LEFT JOIN users u ON pe.requested_by = u.id
            WHERE {$statusCondition}
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND rs.researcher_type IN ({$types})";
            
            // Exclude self-submitted extension requests - coordinators cannot endorse their own work
            $sql .= " AND pe.requested_by != " . intval($this->userId);
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (rs.reference_number LIKE '%{$search}%' OR rs.title LIKE '%{$search}%')";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(pe.created_at) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(pe.created_at) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY pe.created_at DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeItem($row, self::TYPE_EXTENSION, 'project_extensions');
            }
        }
        
        return $items;
    }
    
    /**
     * Get output items for the queue
     */
    private function getOutputItems($role, $filters) {
        $items = [];
        
        // Outputs workflow: draft -> submitted -> endorsed -> verified/rejected
        // Admin sees endorsed outputs, coordinator sees submitted outputs
        if ($role === 'admin') {
            $statusCondition = "po.status IN ('endorsed', 'submitted')";
        } else {
            $statusCondition = "po.status = 'submitted'";
        }
        
        $sql = "
            SELECT 
                po.id,
                po.project_id,
                po.title as output_title,
                po.output_type,
                po.status,
                po.reported_by as requester_id,
                po.created_at,
                po.created_at as submitted_at,
                rs.reference_number,
                rs.title as project_title,
                rs.researcher_type,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_outputs po
            JOIN research_submissions rs ON po.project_id = rs.id
            LEFT JOIN faculty_researchers fr ON rs.researcher_id = fr.id AND rs.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON rs.researcher_id = sr.id AND rs.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON rs.researcher_id = pr.id AND rs.researcher_type = 'personnel'
            LEFT JOIN users u ON po.reported_by = u.id
            WHERE {$statusCondition}
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND rs.researcher_type IN ({$types})";
            
            // Exclude self-submitted output reports - coordinators cannot endorse their own work
            $sql .= " AND po.reported_by != " . intval($this->userId);
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (rs.reference_number LIKE '%{$search}%' OR rs.title LIKE '%{$search}%' OR po.title LIKE '%{$search}%')";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(po.created_at) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(po.created_at) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY po.created_at DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeItem($row, self::TYPE_OUTPUT, 'project_outputs');
            }
        }
        
        return $items;
    }
    
    /**
     * Get completion report items for the queue
     */
    private function getCompletionItems($role, $filters) {
        $items = [];
        
        if ($role === 'admin') {
            $statusCondition = "pcr.status IN ('endorsed', 'under_ro_review')";
        } else {
            $statusCondition = "pcr.status IN ('submitted', 'under_coordinator_review')";
        }
        
        $sql = "
            SELECT 
                pcr.id,
                pcr.project_id,
                pcr.status,
                pcr.submitted_by as requester_id,
                pcr.submitted_at,
                pcr.created_at,
                rs.reference_number,
                rs.title as project_title,
                rs.researcher_type,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_completion_reports pcr
            JOIN research_submissions rs ON pcr.project_id = rs.id
            LEFT JOIN faculty_researchers fr ON rs.researcher_id = fr.id AND rs.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON rs.researcher_id = sr.id AND rs.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON rs.researcher_id = pr.id AND rs.researcher_type = 'personnel'
            LEFT JOIN users u ON pcr.submitted_by = u.id
            WHERE {$statusCondition}
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND rs.researcher_type IN ({$types})";
            
            // Exclude self-submitted completion reports - coordinators cannot endorse their own work
            $sql .= " AND pcr.submitted_by != " . intval($this->userId);
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (rs.reference_number LIKE '%{$search}%' OR rs.title LIKE '%{$search}%')";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(COALESCE(pcr.submitted_at, pcr.created_at)) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(COALESCE(pcr.submitted_at, pcr.created_at)) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY COALESCE(pcr.submitted_at, pcr.created_at) DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeItem($row, self::TYPE_COMPLETION, 'project_completion_reports');
            }
        }
        
        return $items;
    }
    
    /**
     * Get collaboration request items for the queue
     * NOTE: Only collaboration REQUESTS appear here, not RECORDS
     */
    private function getCollaborationItems($role, $filters) {
        $items = [];
        
        // Check if collaboration tables exist
        $tableCheck = $this->conn->query("SHOW TABLES LIKE 'project_collaborations'");
        if ($tableCheck->num_rows === 0) {
            return $items; // Tables not yet created
        }
        
        if ($role === 'admin') {
            // Admin sees ONLY endorsed collaboration requests
            $statusCondition = "pc.status IN ('endorsed', 'under_ro_review')";
        } else {
            // Coordinator sees submitted collaboration requests
            $statusCondition = "pc.status IN ('submitted', 'under_coordinator_review')";
        }
        
        $sql = "
            SELECT 
                pc.id,
                pc.reference_number,
                pc.project_id,
                pc.title as collaboration_title,
                pc.partner_name,
                pc.status,
                pc.researcher_type,
                pc.created_by as requester_id,
                pc.submitted_at,
                pc.created_at,
                ct.type_name as collaboration_type,
                ct.icon_class,
                ct.color_class,
                rs.title as project_title,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit, pc.researcher_unit_name) as unit_name
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            LEFT JOIN research_submissions rs ON pc.project_id = rs.id
            LEFT JOIN faculty_researchers fr ON pc.researcher_id = fr.id AND pc.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON pc.researcher_id = sr.id AND pc.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON pc.researcher_id = pr.id AND pc.researcher_type = 'personnel'
            LEFT JOIN users u ON pc.created_by = u.id
            WHERE {$statusCondition}
            AND pc.collaboration_category = 'request'
            AND pc.is_queue_item = 1
        ";
        
        // Add coordinator type filter
        if ($role === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $sql .= " AND pc.researcher_type IN ({$types})";
            
            // Exclude self-submitted collaboration requests - coordinators cannot endorse their own work
            $sql .= " AND pc.created_by != " . intval($this->userId);
        }
        
        // Apply search filter
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (pc.reference_number LIKE '%{$search}%' OR pc.title LIKE '%{$search}%' OR pc.partner_name LIKE '%{$search}%')";
        }
        
        // Apply date filter
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(COALESCE(pc.submitted_at, pc.created_at)) >= '{$filters['date_from']}'";
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(COALESCE(pc.submitted_at, pc.created_at)) <= '{$filters['date_to']}'";
        }
        
        $sql .= " ORDER BY COALESCE(pc.submitted_at, pc.created_at) DESC";
        
        $result = $this->conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $this->normalizeCollaborationItem($row);
            }
        }
        
        return $items;
    }
    
    /**
     * Normalize collaboration item for queue display
     */
    private function normalizeCollaborationItem($row) {
        return [
            'queue_id' => "collaboration_{$row['id']}",
            'item_type' => self::TYPE_COLLABORATION,
            'source_table' => 'project_collaborations',
            'source_id' => $row['id'],
            'reference_number' => $row['reference_number'] ?? null,
            'project_id' => $row['project_id'],
            'project_title' => $row['collaboration_title'],
            'item_subtitle' => ($row['collaboration_type'] ?? 'Collaboration') . ' with ' . ($row['partner_name'] ?? 'Partner'),
            'requester_id' => $row['requester_id'] ?? null,
            'requester_name' => $row['requester_name'] ?? 'Unknown',
            'researcher_type' => $row['researcher_type'] ?? null,
            'unit_name' => $row['unit_name'] ?? 'Unknown Unit',
            'status' => $row['status'],
            'status_label' => $this->getStatusLabel($row['status']),
            'status_class' => $this->getStatusClass($row['status']),
            'assigned_role' => $this->getAssignedRole($row['status']),
            'submitted_at' => $row['submitted_at'] ?? $row['created_at'],
            'review_url' => "collaboration_view.php?id={$row['id']}",
            'type_label' => 'Collaboration',
            'type_icon' => $row['icon_class'] ?? 'fa-handshake',
            'type_color' => 'type-collaboration'
        ];
    }
    
    /**
     * Normalize a raw database row into the unified queue item format
     */
    private function normalizeItem($row, $itemType, $sourceTable) {
        // Ensure source_id is always valid
        $sourceId = $row['id'] ?? null;
        if (!$sourceId) {
            error_log("UnifiedQueueService: normalizeItem received row without id for type {$itemType}");
            return null; // Skip items without valid ID
        }
        $projectId = $row['project_id'] ?? $row['id'];
        
        return [
            'queue_id' => "{$itemType}_{$sourceId}",
            'item_type' => $itemType,
            'source_table' => $sourceTable,
            'source_id' => $sourceId,
            'reference_number' => $row['reference_number'] ?? null,
            'project_id' => $projectId,
            'project_title' => $row['project_title'] ?? null,
            'item_subtitle' => $this->getItemSubtitle($row, $itemType),
            'requester_id' => $row['requester_id'] ?? null,
            'requester_name' => $row['requester_name'] ?? 'Unknown',
            'researcher_type' => $row['researcher_type'] ?? null,
            'unit_name' => $row['unit_name'] ?? 'Unknown Unit',
            'status' => $row['status'],
            'status_label' => $this->getStatusLabel($row['status']),
            'status_class' => $this->getStatusClass($row['status']),
            'assigned_role' => $this->getAssignedRole($row['status']),
            'submitted_at' => $row['submitted_at'] ?? $row['created_at'],
            'review_url' => $this->getReviewUrl($itemType, $sourceId, $projectId),
            'type_label' => $this->getTypeLabel($itemType),
            'type_icon' => $this->getTypeIcon($itemType),
            'type_color' => $this->getTypeColor($itemType)
        ];
    }
    
    /**
     * Get subtitle for item based on type
     */
    private function getItemSubtitle($row, $itemType) {
        switch ($itemType) {
            case self::TYPE_PROGRESS:
                return $row['report_period'] ?? 'Progress Report';
            case self::TYPE_EXTENSION:
                $type = $row['extension_type'] ?? 'extension';
                return ucfirst(str_replace('_', ' & ', $type)) . ' Extension';
            case self::TYPE_OUTPUT:
                return $row['output_title'] ?? ($row['output_type'] ?? 'Output');
            case self::TYPE_COMPLETION:
                return 'Completion Report';
            default:
                return 'Research Proposal';
        }
    }
    
    /**
     * Get review URL based on item type
     */
    private function getReviewUrl($itemType, $sourceId, $projectId) {
        // Validate IDs before building URL
        if (empty($sourceId) || !is_numeric($sourceId)) {
            error_log("UnifiedQueueService: Invalid sourceId for review_url: " . var_export($sourceId, true));
            return null;
        }
        
        switch ($itemType) {
            case self::TYPE_PROPOSAL:
                return "submission_view.php?id={$sourceId}";
            case self::TYPE_PROGRESS:
                return "project_progress_view.php?id={$sourceId}";
            case self::TYPE_EXTENSION:
                return "project_extension_view.php?id={$sourceId}";
            case self::TYPE_OUTPUT:
                if (empty($projectId) || !is_numeric($projectId)) {
                    error_log("UnifiedQueueService: Invalid projectId for output review_url");
                    return null;
                }
                return "project_view.php?id={$projectId}&tab=outputs";
            case self::TYPE_COMPLETION:
                if (empty($sourceId) || !is_numeric($sourceId)) {
                    error_log("UnifiedQueueService: Invalid sourceId for completion review_url");
                    return null;
                }
                return "project_completion_view.php?id={$sourceId}";
            default:
                return "submission_view.php?id={$sourceId}";
        }
    }
    
    /**
     * Get human-readable status label
     */
    private function getStatusLabel($status) {
        $labels = [
            'draft' => 'Draft',
            'submitted' => 'Pending Review',
            'under_coordinator_review' => 'Coordinator Review',
            'returned_for_revision' => 'Revision Required',
            'endorsed' => 'Endorsed',
            'under_ro_review' => 'RO Review',
            'approved' => 'Approved',
            'rejected' => 'Rejected',
            // Legacy/alias mappings for backward compatibility
            'reviewed' => 'Endorsed',
            'under_review' => 'Under Review',
            'returned' => 'Revision Required',
            'accepted' => 'Approved',
            'verified' => 'Verified'
        ];
        return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
    }
    
    /**
     * Get CSS class for status badge
     */
    private function getStatusClass($status) {
        $classes = [
            'draft' => 'status-draft',
            'submitted' => 'status-pending',
            'under_coordinator_review' => 'status-reviewing',
            'returned_for_revision' => 'status-returned',
            'endorsed' => 'status-endorsed',
            'under_ro_review' => 'status-reviewing',
            'approved' => 'status-approved',
            'rejected' => 'status-rejected',
            // Legacy/alias mappings
            'reviewed' => 'status-endorsed',
            'under_review' => 'status-reviewing',
            'returned' => 'status-returned',
            'accepted' => 'status-approved',
            'verified' => 'status-approved'
        ];
        return $classes[$status] ?? 'status-default';
    }
    
    /**
     * Get which role should handle this status
     * Used to determine whose Work Queue an item appears in
     */
    private function getAssignedRole($status) {
        // Statuses that should be handled by Coordinator
        $coordinatorStatuses = [
            self::STATUS_SUBMITTED, 
            self::STATUS_COORDINATOR_REVIEW
        ];
        
        // Statuses that should be handled by Research Office
        $roStatuses = [
            self::STATUS_ENDORSED, 
            self::STATUS_RO_REVIEW
        ];
        
        // Statuses that return to researcher (NOT in any queue)
        $researcherStatuses = [
            self::STATUS_DRAFT,
            self::STATUS_RETURNED_FOR_REVISION,
            self::STATUS_APPROVED,
            self::STATUS_REJECTED
        ];
        
        if (in_array($status, $coordinatorStatuses)) {
            return self::HANDLER_COORDINATOR;
        } elseif (in_array($status, $roStatuses)) {
            return self::HANDLER_RESEARCH_OFFICE;
        } elseif (in_array($status, $researcherStatuses)) {
            return self::HANDLER_RESEARCHER;
        }
        
        return 'none';
    }
    
    /**
     * Get type label
     */
    private function getTypeLabel($itemType) {
        $labels = [
            self::TYPE_PROPOSAL => 'Proposal',
            self::TYPE_PROGRESS => 'Progress',
            self::TYPE_EXTENSION => 'Extension',
            self::TYPE_OUTPUT => 'Output',
            self::TYPE_COMPLETION => 'Completion',
            self::TYPE_COLLABORATION => 'Collaboration'
        ];
        return $labels[$itemType] ?? 'Unknown';
    }
    
    /**
     * Get type icon (Font Awesome)
     */
    private function getTypeIcon($itemType) {
        $icons = [
            self::TYPE_PROPOSAL => 'fa-file-alt',
            self::TYPE_PROGRESS => 'fa-chart-line',
            self::TYPE_EXTENSION => 'fa-calendar-plus',
            self::TYPE_OUTPUT => 'fa-book',
            self::TYPE_COMPLETION => 'fa-flag-checkered',
            self::TYPE_COLLABORATION => 'fa-handshake'
        ];
        return $icons[$itemType] ?? 'fa-file';
    }
    
    /**
     * Get type color class
     */
    private function getTypeColor($itemType) {
        $colors = [
            self::TYPE_PROPOSAL => 'type-proposal',
            self::TYPE_PROGRESS => 'type-progress',
            self::TYPE_EXTENSION => 'type-extension',
            self::TYPE_OUTPUT => 'type-output',
            self::TYPE_COMPLETION => 'type-completion',
            self::TYPE_COLLABORATION => 'type-collaboration'
        ];
        return $colors[$itemType] ?? 'type-default';
    }
    
    /**
     * Sort and paginate items
     */
    private function paginateAndSort($items, $page, $perPage, $filters) {
        // Filter out any null items (from normalizeItem returning null for invalid data)
        $items = array_filter($items, function($item) {
            return $item !== null && !empty($item['source_id']);
        });
        $items = array_values($items); // Re-index array
        
        // Sort by submitted_at descending (most recent first)
        usort($items, function($a, $b) {
            return strtotime($b['submitted_at']) - strtotime($a['submitted_at']);
        });
        
        $total = count($items);
        $totalPages = ceil($total / $perPage);
        $offset = ($page - 1) * $perPage;
        
        $paginatedItems = array_slice($items, $offset, $perPage);
        
        return [
            'data' => $paginatedItems,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => $totalPages
            ]
        ];
    }
    
    /**
     * Get queue statistics for badges
     */
    public function getQueueStats() {
        if ($this->userRole === 'admin') {
            return $this->getAdminQueueStats();
        } elseif ($this->userRole === 'coordinator') {
            return $this->getCoordinatorQueueStats();
        }
        return $this->emptyStats();
    }
    
    /**
     * Get admin queue statistics
     * 
     * Admin (Research Office) sees items that have been endorsed by coordinators
     * and are awaiting final approval/rejection decision.
     */
    private function getAdminQueueStats() {
        $stats = [
            'total' => 0,
            'proposals' => 0,
            'progress' => 0,
            'extensions' => 0,
            'outputs' => 0,
            'completions' => 0,
            'collaborations' => 0
        ];
        
        // Proposals - endorsed by coordinator, awaiting RO decision
        $result = $this->conn->query("SELECT COUNT(*) as c FROM research_submissions WHERE status IN ('endorsed', 'under_ro_review')");
        $stats['proposals'] = $result->fetch_assoc()['c'];
        
        // Progress Reports - endorsed by coordinator, awaiting RO decision
        // Using unified status: 'endorsed', 'under_ro_review'
        $result = $this->conn->query("SELECT COUNT(*) as c FROM project_progress_reports WHERE status IN ('endorsed', 'under_ro_review')");
        $stats['progress'] = $result->fetch_assoc()['c'];
        
        // Extensions - endorsed by coordinator, awaiting RO decision
        $result = $this->conn->query("SELECT COUNT(*) as c FROM project_extensions WHERE status IN ('endorsed', 'under_ro_review')");
        $stats['extensions'] = $result->fetch_assoc()['c'];
        
        // Outputs - endorsed by coordinator OR submitted (if skipping coordinator)
        // Outputs can go directly to RO if workflow_settings.output_skip_coordinator = 1
        $result = $this->conn->query("SELECT COUNT(*) as c FROM project_outputs WHERE status IN ('endorsed', 'submitted')");
        $stats['outputs'] = $result->fetch_assoc()['c'];
        
        // Completions - endorsed by coordinator, awaiting RO decision
        $result = $this->conn->query("SELECT COUNT(*) as c FROM project_completion_reports WHERE status IN ('endorsed', 'under_ro_review')");
        $stats['completions'] = $result->fetch_assoc()['c'];
        
        // Collaborations - endorsed requests awaiting RO approval
        $tableCheck = $this->conn->query("SHOW TABLES LIKE 'project_collaborations'");
        if ($tableCheck->num_rows > 0) {
            $result = $this->conn->query("SELECT COUNT(*) as c FROM project_collaborations WHERE status IN ('endorsed', 'under_ro_review') AND collaboration_category = 'request' AND is_queue_item = 1");
            $stats['collaborations'] = $result->fetch_assoc()['c'];
        }
        
        $stats['total'] = $stats['proposals'] + $stats['progress'] + $stats['extensions'] + $stats['outputs'] + $stats['completions'] + $stats['collaborations'];
        
        return $stats;
    }
    
    /**
     * Get coordinator queue statistics
     * 
     * Coordinators see newly submitted items awaiting their review/endorsement.
     * They can: review, endorse (forward to RO), or return for revision.
     * They CANNOT: approve or reject.
     * 
     * IMPORTANT: Self-submitted items are excluded - coordinators cannot endorse their own work.
     */
    private function getCoordinatorQueueStats() {
        if (empty($this->coordinatorTypes)) {
            return $this->emptyStats();
        }
        
        $types = "'" . implode("','", $this->coordinatorTypes) . "'";
        $userId = intval($this->userId);
        $stats = [
            'total' => 0,
            'proposals' => 0,
            'progress' => 0,
            'extensions' => 0,
            'outputs' => 0,
            'completions' => 0,
            'collaborations' => 0
        ];
        
        // Build self-exclusion clause for proposals
        $proposalSelfExclusion = "AND created_by != {$userId}";
        if ($this->employeeId) {
            $escapedEmployeeId = $this->conn->real_escape_string($this->employeeId);
            $proposalSelfExclusion .= " AND NOT (submitted_by_coordinator = 1 AND submitter_coordinator_employee_id = '{$escapedEmployeeId}')";
        }
        
        // Proposals - submitted, awaiting coordinator review (excluding self-submitted)
        $result = $this->conn->query("
            SELECT COUNT(*) as c FROM research_submissions 
            WHERE status IN ('submitted', 'under_coordinator_review') 
            AND researcher_type IN ({$types})
            {$proposalSelfExclusion}
        ");
        $stats['proposals'] = $result->fetch_assoc()['c'];
        
        // Progress Reports - submitted, awaiting coordinator review/endorsement (excluding self-submitted)
        $result = $this->conn->query("
            SELECT COUNT(*) as c FROM project_progress_reports ppr
            JOIN research_submissions rs ON ppr.project_id = rs.id
            WHERE ppr.status IN ('submitted', 'under_coordinator_review') 
            AND rs.researcher_type IN ({$types})
            AND ppr.submitted_by != {$userId}
        ");
        $stats['progress'] = $result->fetch_assoc()['c'];
        
        // Extensions - submitted, awaiting coordinator review (excluding self-submitted)
        $result = $this->conn->query("
            SELECT COUNT(*) as c FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            WHERE pe.status IN ('submitted', 'under_coordinator_review') 
            AND rs.researcher_type IN ({$types})
            AND pe.requested_by != {$userId}
        ");
        $stats['extensions'] = $result->fetch_assoc()['c'];
        
        // Outputs - submitted, awaiting coordinator review (excluding self-submitted)
        $result = $this->conn->query("
            SELECT COUNT(*) as c FROM project_outputs po
            JOIN research_submissions rs ON po.project_id = rs.id
            WHERE po.status IN ('submitted', 'under_review') 
            AND rs.researcher_type IN ({$types})
            AND po.reported_by != {$userId}
        ");
        $stats['outputs'] = $result->fetch_assoc()['c'];
        
        // Completions - submitted, awaiting coordinator review (excluding self-submitted)
        $result = $this->conn->query("
            SELECT COUNT(*) as c FROM project_completion_reports pcr
            JOIN research_submissions rs ON pcr.project_id = rs.id
            WHERE pcr.status IN ('submitted', 'under_coordinator_review') 
            AND rs.researcher_type IN ({$types})
            AND pcr.submitted_by != {$userId}
        ");
        $stats['completions'] = $result->fetch_assoc()['c'];
        
        // Collaborations - submitted requests awaiting coordinator review (excluding self-submitted)
        $tableCheck = $this->conn->query("SHOW TABLES LIKE 'project_collaborations'");
        if ($tableCheck->num_rows > 0) {
            $result = $this->conn->query("
                SELECT COUNT(*) as c FROM project_collaborations 
                WHERE status IN ('submitted', 'under_coordinator_review') 
                AND collaboration_category = 'request' 
                AND is_queue_item = 1
                AND researcher_type IN ({$types})
                AND created_by != {$userId}
            ");
            $stats['collaborations'] = $result->fetch_assoc()['c'];
        }
        
        $stats['total'] = $stats['proposals'] + $stats['progress'] + $stats['extensions'] + $stats['outputs'] + $stats['completions'] + $stats['collaborations'];
        
        return $stats;
    }
    
    /**
     * Empty stats structure
     */
    private function emptyStats() {
        return [
            'total' => 0,
            'proposals' => 0,
            'progress' => 0,
            'extensions' => 0,
            'outputs' => 0,
            'completions' => 0,
            'collaborations' => 0
        ];
    }
    
    /**
     * Empty pagination structure
     */
    private function emptyPagination($page, $perPage) {
        return [
            'total' => 0,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => 0
        ];
    }
    
    /**
     * Log queue action for audit
     * 
     * Every status change in the Work Queue MUST be audit logged.
     * This creates an immutable record of all workflow actions.
     * 
     * @param string $itemType Type of item (proposal, progress, extension, etc.)
     * @param int $sourceId ID in the source table
     * @param string $action Action performed (submitted, endorsed, approved, etc.)
     * @param string|null $previousStatus Previous status before action
     * @param string $newStatus New status after action
     * @param string|null $remarks Optional remarks or reason
     * @param array|null $extraData Optional additional data to log
     */
    public function logQueueAction($itemType, $sourceId, $action, $previousStatus, $newStatus, $remarks = null, $extraData = null) {
        // Log via the existing audit logger for backward compatibility
        $this->auditLogger->log(null, "queue_{$action}", [
            'performed_by' => $this->userId,
            'performed_by_role' => $this->userRole,
            'metadata' => [
                'item_type' => $itemType,
                'source_id' => $sourceId,
                'previous_status' => $previousStatus,
                'new_status' => $newStatus,
                'remarks' => $remarks
            ]
        ]);
        
        // Also log to the unified queue audit log for comprehensive tracking
        $this->logToUnifiedAuditTable($itemType, $sourceId, $action, $previousStatus, $newStatus, $remarks, $extraData);
    }
    
    /**
     * Log to the unified_queue_audit_log table
     */
    private function logToUnifiedAuditTable($itemType, $sourceId, $action, $previousStatus, $newStatus, $remarks = null, $extraData = null) {
        // Check if table exists
        $tableCheck = $this->conn->query("SHOW TABLES LIKE 'unified_queue_audit_log'");
        if ($tableCheck->num_rows === 0) {
            return; // Table not created yet
        }
        
        // Get source table and project ID based on item type
        $sourceTable = $this->getSourceTable($itemType);
        $projectId = $this->getProjectIdForItem($itemType, $sourceId);
        $referenceNumber = $this->getReferenceNumber($itemType, $sourceId);
        
        $fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'System';
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        $metadataJson = $extraData ? json_encode($extraData) : null;
        
        $stmt = $this->conn->prepare("
            INSERT INTO unified_queue_audit_log 
            (item_type, source_table, source_id, project_id, reference_number,
             previous_status, new_status, action_type, 
             performed_by, performed_by_role, performed_by_name,
             remarks, metadata, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            "ssiissssississs",
            $itemType, $sourceTable, $sourceId, $projectId, $referenceNumber,
            $previousStatus, $newStatus, $action,
            $this->userId, $this->userRole, $fullname,
            $remarks, $metadataJson, $ipAddress, $userAgent
        );
        
        try {
            $stmt->execute();
        } catch (Exception $e) {
            error_log("UnifiedQueueService: Failed to log to audit table: " . $e->getMessage());
        }
        $stmt->close();
    }
    
    /**
     * Get source table name for item type
     */
    private function getSourceTable($itemType) {
        $tables = [
            self::TYPE_PROPOSAL => 'research_submissions',
            self::TYPE_PROGRESS => 'project_progress_reports',
            self::TYPE_EXTENSION => 'project_extensions',
            self::TYPE_OUTPUT => 'project_outputs',
            self::TYPE_COMPLETION => 'project_completion_reports',
            self::TYPE_COLLABORATION => 'project_collaborations'
        ];
        return $tables[$itemType] ?? 'unknown';
    }
    
    /**
     * Get project ID for an item
     */
    private function getProjectIdForItem($itemType, $sourceId) {
        if ($itemType === self::TYPE_PROPOSAL) {
            return $sourceId; // For proposals, source_id IS the project_id
        }
        
        $table = $this->getSourceTable($itemType);
        if ($table === 'unknown') {
            return null;
        }
        
        $stmt = $this->conn->prepare("SELECT project_id FROM $table WHERE id = ?");
        $stmt->bind_param("i", $sourceId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['project_id'] ?? null;
    }
    
    /**
     * Get reference number for an item
     */
    private function getReferenceNumber($itemType, $sourceId) {
        if ($itemType === self::TYPE_PROPOSAL) {
            $stmt = $this->conn->prepare("SELECT reference_number FROM research_submissions WHERE id = ?");
        } elseif ($itemType === self::TYPE_COLLABORATION) {
            $stmt = $this->conn->prepare("SELECT reference_number FROM project_collaborations WHERE id = ?");
        } else {
            return null;
        }
        
        $stmt->bind_param("i", $sourceId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['reference_number'] ?? null;
    }
    
    /**
     * Get valid transitions from a given status
     * Used to validate workflow actions
     */
    public function getValidTransitions($currentStatus) {
        $transitions = [
            self::STATUS_DRAFT => [self::STATUS_SUBMITTED],
            self::STATUS_SUBMITTED => [self::STATUS_COORDINATOR_REVIEW],
            self::STATUS_COORDINATOR_REVIEW => [
                self::STATUS_RETURNED_FOR_REVISION,
                self::STATUS_ENDORSED
            ],
            self::STATUS_RETURNED_FOR_REVISION => [self::STATUS_SUBMITTED],
            self::STATUS_ENDORSED => [self::STATUS_RO_REVIEW],
            self::STATUS_RO_REVIEW => [
                self::STATUS_APPROVED,
                self::STATUS_REJECTED,
                self::STATUS_ENDORSED // Return to coordinator
            ],
            self::STATUS_APPROVED => [], // Final state
            self::STATUS_REJECTED => []  // Final state
        ];
        
        return $transitions[$currentStatus] ?? [];
    }
    
    /**
     * Validate if a status transition is allowed
     */
    public function isValidTransition($currentStatus, $newStatus) {
        $validTransitions = $this->getValidTransitions($currentStatus);
        return in_array($newStatus, $validTransitions);
    }
    
    /**
     * Check if user can perform action on item based on status and role
     */
    public function canPerformAction($itemStatus, $action) {
        // Actions available to coordinators
        $coordinatorActions = ['start_review', 'endorse', 'return_for_revision'];
        $coordinatorStatuses = [self::STATUS_SUBMITTED, self::STATUS_COORDINATOR_REVIEW];
        
        // Actions available to Research Office
        $roActions = ['start_ro_review', 'approve', 'reject', 'return_to_coordinator'];
        $roStatuses = [self::STATUS_ENDORSED, self::STATUS_RO_REVIEW];
        
        // Actions available to researchers
        $researcherActions = ['submit', 'resubmit'];
        $researcherStatuses = [self::STATUS_DRAFT, self::STATUS_RETURNED_FOR_REVISION];
        
        if ($this->userRole === 'admin') {
            // Admin can perform RO actions on endorsed/under_ro_review items
            if (in_array($action, $roActions) && in_array($itemStatus, $roStatuses)) {
                return true;
            }
            // Admin can also perform coordinator actions (fallback)
            if (in_array($action, $coordinatorActions) && in_array($itemStatus, $coordinatorStatuses)) {
                return true;
            }
            return false;
        }
        
        if ($this->userRole === 'coordinator') {
            // Coordinator can only perform coordinator actions on coordinator statuses
            return in_array($action, $coordinatorActions) && in_array($itemStatus, $coordinatorStatuses);
        }
        
        if ($this->userRole === 'researcher') {
            return in_array($action, $researcherActions) && in_array($itemStatus, $researcherStatuses);
        }
        
        return false;
    }
}
