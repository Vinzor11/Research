<?php
/**
 * HR System API Helper - ON-DEMAND SYNCING ONLY
 * No bulk operations, no proactive verification
 * Fetch employees ONLY when explicitly requested
 */

require_once 'config.php';
require_once 'TokenManager.php';

class HRSystemAPI {
    private $conn;
    private $tokenManager;
    private $accessToken;
    private $baseUrl;
    private $rateLimitKey;
    
    public function __construct($dbConnection, $userId = null) {
        $this->conn = $dbConnection;
        $config = getOAuthConfig($dbConnection);
        $providerUrl = rtrim($config['provider_url'] ?? '', '/');
        $this->baseUrl = !empty($providerUrl) ? $providerUrl : HR_API_BASE_URL;
        
        $this->tokenManager = new TokenManager($dbConnection, $userId);
        $this->accessToken = $this->tokenManager->getValidToken();
        
        if (empty($this->accessToken)) {
            throw new Exception("HR System access token not available. Please login via SSO.");
        }
        
        $this->rateLimitKey = 'hr_api_rate_' . ($userId ?? session_id());
        
        debugLog("[HR_API] Initialized for on-demand queries only");
    }
    
    private function checkRateLimit() {
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $now = time();
        $windowStart = $now - API_RATE_WINDOW;
        $requests = $_SESSION[$this->rateLimitKey] ?? [];
        
        $requests = array_filter($requests, function($timestamp) use ($windowStart) {
            return $timestamp > $windowStart;
        });
        
        if (count($requests) >= API_RATE_LIMIT) {
            errorLog("[HR_API] Rate limit exceeded", [
                'key' => $this->rateLimitKey,
                'requests_in_window' => count($requests)
            ]);
            throw new Exception("Rate limit exceeded. Please wait a moment and try again.");
        }
        
        $requests[] = $now;
        $_SESSION[$this->rateLimitKey] = $requests;
        
        debugLog("[HR_API] Rate limit check passed: " . count($requests) . "/" . API_RATE_LIMIT);
    }
    
    private function makeRequest($endpoint, $method = 'GET', $data = null) {
        $this->checkRateLimit();
        
        $url = $this->baseUrl . $endpoint;
        
        debugLog("[HR_API] Request: $method $url");
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, API_TIMEOUT);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->accessToken,
            'Accept: application/json',
            'Content-Type: application/json'
        ]);
        
        if ($method !== 'GET' && $data) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        debugLog("[HR_API] Response HTTP: $httpCode");
        
        if ($curlError) {
            errorLog("[HR_API] CURL Error: $curlError");
            throw new Exception("Connection error: $curlError");
        }
        
        if ($httpCode === 401) {
            errorLog("[HR_API] Authentication failed");
            throw new Exception("Authentication failed. Please login again.");
        }
        
        if ($httpCode === 404) {
            debugLog("[HR_API] 404 Not Found");
            return null;
        }
        
        if ($httpCode === 429) {
            errorLog("[HR_API] Rate limit exceeded");
            throw new Exception("HR System is busy. Please try again in a few moments.");
        }
        
        if ($httpCode === 403) {
            errorLog("[HR_API] Access denied (403)");
            throw new Exception("Access denied. You may not have permission to access this resource. For unit-employees, your account must have a Research Coordinator (RES_COORD) designation.");
        }
        
        if ($httpCode >= 400) {
            errorLog("[HR_API] HTTP $httpCode");
            throw new Exception("HR System error: HTTP $httpCode");
        }
        
        $decoded = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Check if response is HTML (likely a PHP error page)
            $isHtml = stripos($response, '<html') !== false || 
                     stripos($response, '<!DOCTYPE') !== false ||
                     stripos($response, '<br') !== false;
            
            $errorMsg = "Invalid response from HR System";
            if ($isHtml) {
                // Extract error message from HTML if possible
                if (preg_match('/<b>([^<]+)<\/b>/i', $response, $matches)) {
                    $errorMsg = "HR System error: " . html_entity_decode($matches[1]);
                } else {
                    $errorMsg = "HR System returned an error page. Please check server logs.";
                }
            }
            
            errorLog("[HR_API] JSON Error: " . json_last_error_msg(), [
                'response_preview' => substr($response, 0, 500),
                'http_code' => $httpCode,
                'is_html' => $isHtml
            ]);
            throw new Exception($errorMsg);
        }
        
        return $decoded;
    }
    
    public function getEmployeeById($employeeId) {
        try {
            $normalizedId = normalizeEmployeeId($employeeId);
            
            debugLog("[HR_API] Fetching employee: $normalizedId (original: $employeeId)");
            
            // Try /api/employees/{id} first (correct endpoint)
            $endpoint = '/api/employees/' . urlencode($employeeId);
            $lastError = null;
            
            try {
                debugLog("[HR_API] Trying endpoint: $endpoint");
                $response = $this->makeRequest($endpoint);
                
                if ($response !== null && isset($response['id'])) {
                    debugLog("[HR_API] ✅ Employee found via /api/employees/{id}");
                    return $response;
                }
                
                if (isset($response['data']['id'])) {
                    debugLog("[HR_API] ✅ Employee found in data wrapper");
                    return $response['data'];
                }
                
                // Log response structure for debugging
                if ($response !== null) {
                    debugLog("[HR_API] Response received but no employee ID found", [
                        'response_keys' => array_keys($response),
                        'has_data' => isset($response['data']),
                        'data_keys' => isset($response['data']) ? array_keys($response['data']) : []
                    ]);
                }
            } catch (Exception $e) {
                $lastError = $e->getMessage();
                debugLog("[HR_API] Direct fetch failed: " . $lastError);
                
                // Try fallback endpoint /employees/{id}
                try {
                    $endpoint = '/employees/' . urlencode($employeeId);
                    debugLog("[HR_API] Trying fallback endpoint: $endpoint");
                    $response = $this->makeRequest($endpoint);
                    
                    if ($response !== null && isset($response['id'])) {
                        debugLog("[HR_API] ✅ Employee found via /employees/{id}");
                        return $response;
                    }
                    
                    if (isset($response['data']['id'])) {
                        debugLog("[HR_API] ✅ Employee found in data wrapper (fallback)");
                        return $response['data'];
                    }
                } catch (Exception $e2) {
                    $lastError = $e2->getMessage();
                    debugLog("[HR_API] Fallback endpoint also failed: " . $lastError);
                }
            }
            
            // Last resort: search
            debugLog("[HR_API] Trying search as last resort for: $employeeId");
            try {
                $searchResult = $this->searchEmployees($employeeId, 1, 50);
                
                if (!empty($searchResult['data'])) {
                    debugLog("[HR_API] Search returned " . count($searchResult['data']) . " results");
                    foreach ($searchResult['data'] as $employee) {
                        $empId = normalizeEmployeeId($employee['id'] ?? '');
                        
                        debugLog("[HR_API] Comparing: search_id=$empId vs normalized=$normalizedId");
                        if ($empId === $normalizedId) {
                            debugLog("[HR_API] ✅ Employee found via search");
                            return $employee;
                        }
                    }
                    debugLog("[HR_API] Employee ID not found in search results");
                } else {
                    debugLog("[HR_API] Search returned no results");
                }
            } catch (Exception $e3) {
                $lastError = $e3->getMessage();
                errorLog("[HR_API] Search also failed: " . $lastError);
            }
            
            errorLog("[HR_API] ❌ Employee not found after all attempts", [
                'employee_id' => $employeeId,
                'normalized_id' => $normalizedId,
                'last_error' => $lastError
            ]);
            return null;
            
        } catch (Exception $e) {
            errorLog("[HR_API] getEmployeeById exception: " . $e->getMessage(), [
                'employee_id' => $employeeId,
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }
    
    /**
     * Get current employee (authenticated user) - API_INTEGRATION_GUIDE
     * Endpoint: GET /api/employees/me
     * 
     * @return array|null - Employee data or null
     */
    public function getCurrentEmployee() {
        try {
            debugLog("[HR_API] getCurrentEmployee: /api/employees/me");
            $response = $this->makeRequest('/api/employees/me');
            if ($response === null) return null;
            if (isset($response['id'])) return $response;
            if (isset($response['data']['id'])) return $response['data'];
            return null;
        } catch (Exception $e) {
            errorLog("[HR_API] getCurrentEmployee: " . $e->getMessage());
            return null;
        }
    }
    
    public function searchEmployees($query, $page = 1, $perPage = 20) {
        try {
            debugLog("[HR_API] searchEmployees: '$query', page: $page");
            
            $params = [
                'page' => $page,
                'per_page' => min($perPage, API_MAX_PER_PAGE)
            ];
            
            if (!empty($query)) {
                $params['q'] = $query;
            }
            
            $endpoint = '/api/employees?' . http_build_query($params);
            $response = $this->makeRequest($endpoint);
            
            if ($response === null) {
                return [
                    'data' => [],
                    'total' => 0,
                    'current_page' => 1,
                    'last_page' => 1,
                    'per_page' => $perPage,
                    'from' => 0,
                    'to' => 0
                ];
            }
            
            $data = $response['data'] ?? [];
            $meta = $response['meta'] ?? [];
            
            debugLog("[HR_API] Search returned " . count($data) . " results");
            
            return [
                'data' => $data,
                'total' => $meta['total'] ?? count($data),
                'current_page' => $meta['current_page'] ?? $page,
                'last_page' => $meta['last_page'] ?? 1,
                'per_page' => $meta['per_page'] ?? $perPage,
                'from' => $meta['from'] ?? (count($data) > 0 ? 1 : 0),
                'to' => $meta['to'] ?? count($data)
            ];
            
        } catch (Exception $e) {
            errorLog("[HR_API] searchEmployees error: " . $e->getMessage());
            return [
                'data' => [],
                'total' => 0,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get all employees from HR API (following EMPLOYEES_API_GUIDE.md)
     * Fetches employees with pagination support
     * 
     * @param int $page - Page number (default: 1)
     * @param int $perPage - Items per page (default: 50, max: 100)
     * @param string $status - Filter by status: 'active', 'inactive', or 'all' (default: 'active')
     * @return array - Response with data, meta, and links
     */
    public function getAllEmployees($page = 1, $perPage = 50, $status = 'active') {
        try {
            debugLog("[HR_API] getAllEmployees: page=$page, per_page=$perPage, status=$status");
            
            $params = [
                'page' => $page,
                'per_page' => min($perPage, API_MAX_PER_PAGE),
                'status' => $status
            ];
            
            $endpoint = '/api/employees?' . http_build_query($params);
            $response = $this->makeRequest($endpoint);
            
            if ($response === null) {
                return [
                    'data' => [],
                    'meta' => [
                        'current_page' => $page,
                        'last_page' => 1,
                        'per_page' => $perPage,
                        'total' => 0,
                        'from' => 0,
                        'to' => 0
                    ],
                    'links' => []
                ];
            }
            
            $data = $response['data'] ?? [];
            $meta = $response['meta'] ?? [];
            $links = $response['links'] ?? [];
            
            debugLog("[HR_API] getAllEmployees returned " . count($data) . " results");
            
            return [
                'data' => $data,
                'meta' => $meta,
                'links' => $links
            ];
            
        } catch (Exception $e) {
            errorLog("[HR_API] getAllEmployees error: " . $e->getMessage());
            return [
                'data' => [],
                'meta' => [
                    'current_page' => $page,
                    'last_page' => 1,
                    'per_page' => $perPage,
                    'total' => 0,
                    'from' => 0,
                    'to' => 0
                ],
                'links' => [],
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Fetch all employees across all pages
     * 
     * @param string $status - Filter by status: 'active', 'inactive', or 'all'
     * @return array - All employees
     */
    public function fetchAllEmployees($status = 'active') {
        $allEmployees = [];
        $currentPage = 1;
        $hasMore = true;
        
        while ($hasMore) {
            $result = $this->getAllEmployees($currentPage, 50, $status);
            
            if (!empty($result['data'])) {
                $allEmployees = array_merge($allEmployees, $result['data']);
            }
            
            $lastPage = $result['meta']['last_page'] ?? 1;
            $hasMore = $currentPage < $lastPage;
            $currentPage++;
            
            // Rate limiting: wait 1 second between requests
            if ($hasMore) {
                sleep(1);
            }
        }
        
        debugLog("[HR_API] fetchAllEmployees: Total fetched " . count($allEmployees) . " employees");
        return $allEmployees;
    }
    
    /**
     * Get unit details including parent unit information
     * 
     * @param int|string $unitId - Unit ID
     * @return array|null - Unit data with parent unit info
     */
    public function getUnitById($unitId) {
        try {
            debugLog("[HR_API] getUnitById: $unitId");
            
            $endpoint = '/api/units/' . urlencode($unitId);
            $response = $this->makeRequest($endpoint);
            
            if ($response !== null && isset($response['id'])) {
                debugLog("[HR_API] ✅ Unit found");
                return $response;
            }
            
            if (isset($response['data']['id'])) {
                debugLog("[HR_API] ✅ Unit found in data wrapper");
                return $response['data'];
            }
            
            debugLog("[HR_API] ❌ Unit not found");
            return null;
            
        } catch (Exception $e) {
            errorLog("[HR_API] getUnitById exception: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * List sectors - API_INTEGRATION_GUIDE
     * Endpoint: GET /api/sectors
     * 
     * @param string|null $search - Search by name or code
     * @return array - data, meta, links (or empty on error)
     */
    public function getSectors($search = null) {
        try {
            $params = [];
            if ($search) $params['search'] = $search;
            $endpoint = '/api/sectors' . (empty($params) ? '' : '?' . http_build_query($params));
            $response = $this->makeRequest($endpoint);
            if ($response === null) return ['data' => [], 'meta' => [], 'links' => []];
            return [
                'data' => $response['data'] ?? [],
                'meta' => $response['meta'] ?? [],
                'links' => $response['links'] ?? []
            ];
        } catch (Exception $e) {
            errorLog("[HR_API] getSectors: " . $e->getMessage());
            return ['data' => [], 'meta' => [], 'links' => []];
        }
    }
    
    /**
     * Get sector by ID - API_INTEGRATION_GUIDE
     * Endpoint: GET /api/sectors/{id}
     * 
     * @param int|string $sectorId - Sector ID
     * @return array|null - Sector with units
     */
    public function getSector($sectorId) {
        try {
            $response = $this->makeRequest('/api/sectors/' . urlencode($sectorId));
            if ($response === null) return null;
            if (isset($response['id'])) return $response;
            if (isset($response['data']['id'])) return $response['data'];
            return null;
        } catch (Exception $e) {
            errorLog("[HR_API] getSector: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * List units - API_INTEGRATION_GUIDE
     * Endpoint: GET /api/units
     * 
     * @param int|null $sectorId - Filter by sector ID
     * @param string|null $unitType - Filter: college, program, office
     * @param string|null $search - Search by name or code
     * @return array - data, meta, links
     */
    public function getUnits($sectorId = null, $unitType = null, $search = null) {
        try {
            $params = array_filter([
                'sector_id' => $sectorId,
                'unit_type' => $unitType,
                'search' => $search
            ]);
            $endpoint = '/api/units' . (empty($params) ? '' : '?' . http_build_query($params));
            $response = $this->makeRequest($endpoint);
            if ($response === null) return ['data' => [], 'meta' => [], 'links' => []];
            return [
                'data' => $response['data'] ?? [],
                'meta' => $response['meta'] ?? [],
                'links' => $response['links'] ?? []
            ];
        } catch (Exception $e) {
            errorLog("[HR_API] getUnits: " . $e->getMessage());
            return ['data' => [], 'meta' => [], 'links' => []];
        }
    }
    
    /**
     * Get Research Coordinators from HR API (RESEARCH_OFFICE_API_GUIDE)
     * Any valid OAuth token - returns employees with Research Coordinator position
     * 
     * @param int $page - Page number (default: 1)
     * @param int $perPage - Items per page (default: 50, max: 100)
     * @param string $status - Filter by status: 'active', 'inactive', or 'all' (default: 'active')
     * @return array|null - Response with data, meta, links or null if endpoint not available
     */
    public function getResearchCoordinators($page = 1, $perPage = 50, $status = 'active') {
        try {
            debugLog("[HR_API] getResearchCoordinators: page=$page, per_page=$perPage, status=$status");
            
            $params = [
                'page' => $page,
                'per_page' => min($perPage, API_MAX_PER_PAGE),
                'status' => $status
            ];
            $endpoint = '/api/research/coordinators?' . http_build_query($params);
            $response = $this->makeRequest($endpoint);
            
            if ($response === null) {
                return null;
            }
            
            $data = $response['data'] ?? [];
            $meta = $response['meta'] ?? [];
            $links = $response['links'] ?? [];
            
            debugLog("[HR_API] getResearchCoordinators returned " . count($data) . " results");
            
            return [
                'data' => $data,
                'meta' => $meta,
                'links' => $links
            ];
        } catch (Exception $e) {
            debugLog("[HR_API] getResearchCoordinators not available: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Get Designations from HR API (RESEARCH_OFFICE_API_GUIDE)
     * Returns designations (unit + position assignments) with optional filters
     * 
     * @param string|null $positionCode - Filter by position code (e.g., RES_COORD)
     * @param int $page - Page number
     * @param int $perPage - Items per page
     * @return array|null - Response with data, meta, links or null if endpoint not available
     */
    public function getDesignations($positionCode = null, $page = 1, $perPage = 50) {
        try {
            debugLog("[HR_API] getDesignations: position_code=$positionCode, page=$page");
            $params = ['page' => $page, 'per_page' => min($perPage, API_MAX_PER_PAGE)];
            if ($positionCode) {
                $params['position_code'] = $positionCode;
            }
            $endpoint = '/api/designations?' . http_build_query($params);
            $response = $this->makeRequest($endpoint);
            if ($response === null) return null;
            $data = $response['data'] ?? [];
            $meta = $response['meta'] ?? [];
            $links = $response['links'] ?? [];
            return ['data' => $data, 'meta' => $meta, 'links' => $links];
        } catch (Exception $e) {
            debugLog("[HR_API] getDesignations not available: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Fetch Research Coordinators via Designations API (RESEARCH_OFFICE_API_GUIDE fallback)
     * Gets designations with position_code=RES_COORD and maps to employee format
     * 
     * @return array - Employees with Research Coordinator designation (unique by employee_id)
     */
    public function fetchCoordinatorsFromDesignations() {
        $allDesignations = [];
        $currentPage = 1;
        $hasMore = true;
        while ($hasMore) {
            $result = $this->getDesignations('RES_COORD', $currentPage, 50);
            if ($result === null) return [];
            if (!empty($result['data'])) {
                $allDesignations = array_merge($allDesignations, $result['data']);
            }
            $lastPage = $result['meta']['last_page'] ?? 1;
            $hasMore = $currentPage < $lastPage;
            $currentPage++;
            if ($hasMore) sleep(1);
        }
        if (empty($allDesignations)) return [];
        $seen = [];
        $employees = [];
        foreach ($allDesignations as $d) {
            $empId = $d['employee_id'] ?? null;
            if (!$empId || isset($seen[$empId])) continue;
            $seen[$empId] = true;
            $unit = $d['unit'] ?? [];
            $position = $d['position'] ?? [];
            $employees[] = [
                'id' => $empId,
                'name' => ['full_name' => $d['employee_name'] ?? ''],
                'contact' => ['email' => ''],
                'unit' => is_array($unit) ? $unit : [],
                'position' => is_array($position) ? $position : [],
                'sector' => $unit['sector'] ?? null
            ];
        }
        debugLog("[HR_API] fetchCoordinatorsFromDesignations: " . count($employees) . " unique coordinators");
        return $employees;
    }
    
    /**
     * Fetch all research coordinators across pages
     * 
     * @param string $status - Filter by status: 'active', 'inactive', or 'all'
     * @return array - All research coordinators or empty array if endpoint not available
     */
    public function fetchAllResearchCoordinators($status = 'active') {
        $allCoordinators = [];
        $currentPage = 1;
        $hasMore = true;
        
        while ($hasMore) {
            $result = $this->getResearchCoordinators($currentPage, 50, $status);
            
            if ($result === null) {
                return [];
            }
            
            if (!empty($result['data'])) {
                $allCoordinators = array_merge($allCoordinators, $result['data']);
            }
            
            $lastPage = $result['meta']['last_page'] ?? 1;
            $hasMore = $currentPage < $lastPage;
            $currentPage++;
            
            if ($hasMore) {
                sleep(1);
            }
        }
        
        debugLog("[HR_API] fetchAllResearchCoordinators: Total fetched " . count($allCoordinators));
        return $allCoordinators;
    }
    
    /**
     * Get employees in same parent unit as coordinator (RESEARCH_OFFICE_API_GUIDE)
     * Coordinator-only endpoint - HR returns employees in coordinator's parent unit based on their token
     * 
     * @param int $page - Page number (default: 1)
     * @param int $perPage - Items per page (default: 50, max: 100)
     * @return array|null - Response with data, meta, links or null if endpoint not available
     */
    public function getUnitEmployees($page = 1, $perPage = 50) {
        try {
            debugLog("[HR_API] getUnitEmployees: page=$page, per_page=$perPage");
            
            $params = [
                'page' => $page,
                'per_page' => min($perPage, API_MAX_PER_PAGE)
            ];
            $endpoint = '/api/research/unit-employees?' . http_build_query($params);
            $response = $this->makeRequest($endpoint);
            
            if ($response === null) {
                return null;
            }
            
            $data = $response['data'] ?? [];
            $meta = $response['meta'] ?? [];
            $links = $response['links'] ?? [];
            
            debugLog("[HR_API] getUnitEmployees returned " . count($data) . " results");
            
            return [
                'data' => $data,
                'meta' => $meta,
                'links' => $links
            ];
        } catch (Exception $e) {
            debugLog("[HR_API] getUnitEmployees not available: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Fetch all employees in coordinator's parent unit across pages
     * 
     * @return array - All unit employees or empty array if endpoint not available
     */
    public function fetchAllUnitEmployees() {
        $allEmployees = [];
        $currentPage = 1;
        $hasMore = true;
        
        while ($hasMore) {
            $result = $this->getUnitEmployees($currentPage, 50);
            
            if ($result === null) {
                return [];
            }
            
            if (!empty($result['data'])) {
                $allEmployees = array_merge($allEmployees, $result['data']);
            }
            
            $lastPage = $result['meta']['last_page'] ?? 1;
            $hasMore = $currentPage < $lastPage;
            $currentPage++;
            
            if ($hasMore) {
                sleep(1);
            }
        }
        
        debugLog("[HR_API] fetchAllUnitEmployees: Total fetched " . count($allEmployees));
        return $allEmployees;
    }
    
    /**
     * Fetch employees by parent unit ID (fallback when Research Office API not available)
     * Fetches all employees and filters by parent_unit_id
     * 
     * @param int $parentUnitId - Parent unit ID to filter by
     * @param string $status - Filter by status: 'active', 'inactive', or 'all'
     * @return array - Employees with matching parent unit
     */
    public function fetchEmployeesByParentUnit($parentUnitId, $status = 'active') {
        try {
            debugLog("[HR_API] fetchEmployeesByParentUnit: parent_unit_id=$parentUnitId");
            
            // Fetch all employees
            $allEmployees = $this->fetchAllEmployees($status);
            
            // Filter employees by parent unit
            // Check unit.parent_unit.id (from userinfo) first, then unit.parent_unit_id
            $filteredEmployees = [];
            $normalizedParentUnitId = (string)$parentUnitId;
            
            foreach ($allEmployees as $employee) {
                $unit = $employee['unit'] ?? null;
                if ($unit) {
                    $empParentUnitId = null;
                    
                    // Check unit.parent_unit.id (from userinfo designations)
                    if (isset($unit['parent_unit']['id'])) {
                        $empParentUnitId = $unit['parent_unit']['id'];
                    }
                    // Fallback to unit.parent_unit_id
                    elseif (isset($unit['parent_unit_id'])) {
                        $empParentUnitId = $unit['parent_unit_id'];
                    }
                    
                    // Check if employee's unit directly matches parent unit
                    $unitId = (string)($unit['id'] ?? '');
                    if ($unitId === $normalizedParentUnitId) {
                        $filteredEmployees[] = $employee;
                    }
                    // Check if parent unit matches
                    elseif ($empParentUnitId && (string)$empParentUnitId === $normalizedParentUnitId) {
                        $filteredEmployees[] = $employee;
                    }
                }
            }
            
            debugLog("[HR_API] fetchEmployeesByParentUnit: Found " . count($filteredEmployees) . " employees with parent_unit_id=$parentUnitId");
            return $filteredEmployees;
            
        } catch (Exception $e) {
            errorLog("[HR_API] fetchEmployeesByParentUnit error: " . $e->getMessage());
            return [];
        }
    }
    
    public function mapEmployeeData($hrEmployee) {
        if (empty($hrEmployee)) {
            errorLog("[HR_API] mapEmployeeData: Empty employee data");
            return null;
        }
        
        $name = $hrEmployee['name'] ?? [];
        $contact = $hrEmployee['contact'] ?? [];
        $employment = $hrEmployee['employment'] ?? [];
        $department = $hrEmployee['department'] ?? [];
        $position = $hrEmployee['position'] ?? [];
        $address = $hrEmployee['address']['residential'] ?? [];
        
        $employeeId = $hrEmployee['id'] ?? null;
        
        if (!$employeeId) {
            errorLog("[HR_API] Missing employee ID");
            return null;
        }
        
        if (empty($name['surname']) || empty($name['first_name'])) {
            errorLog("[HR_API] Missing name fields");
            return null;
        }
        
        $normalizedId = normalizeEmployeeId($employeeId);
        
        // Map employment_status from HR to database ENUM values
        // Database only accepts: 'Full-Time' or 'Part-Time'
        $hrEmploymentStatus = trim($employment['employment_status'] ?? '');
        $mappedEmploymentStatus = 'Full-Time'; // Default
        
        if (!empty($hrEmploymentStatus)) {
            $statusLower = strtolower($hrEmploymentStatus);
            // Map common HR status values to database ENUM
            if (in_array($statusLower, ['part-time', 'part time', 'parttime'])) {
                $mappedEmploymentStatus = 'Part-Time';
            } else {
                // Default to Full-Time for Regular, Contractual, Permanent, etc.
                $mappedEmploymentStatus = 'Full-Time';
            }
        }
        
        return [
            'hr_employee_id' => $normalizedId,
            'faculty_number' => $normalizedId,
            'last_name' => trim($name['surname']),
            'first_name' => trim($name['first_name']),
            'middle_name' => trim($name['middle_name'] ?? ''),
            'email' => trim($contact['email'] ?? ''),
            'telephone' => trim($contact['telephone'] ?? $contact['mobile'] ?? ''),
            'fax' => '',
            'faculty_rank' => trim($position['name'] ?? 'Not Specified'),
            'employment_status' => $mappedEmploymentStatus,
            'department' => trim($department['name'] ?? 'Not Specified'),
            'home_unit' => $this->getUnitName($hrEmployee),
            'home_address' => $this->formatAddress($address),
            'is_synced' => 1,
            'last_synced_at' => date('Y-m-d H:i:s'),
            'hr_data_json' => json_encode($hrEmployee)
        ];
    }
    
    private function formatAddress($address) {
        if (empty($address)) return '';
        
        $parts = array_filter([
            $address['house_no'] ?? '',
            $address['street'] ?? '',
            $address['subdivision'] ?? '',
            $address['barangay'] ?? '',
            $address['city'] ?? '',
            $address['province'] ?? ''
        ]);
        
        return implode(', ', $parts);
    }
    
    /**
     * Get unit name from employee data
     * Checks unit object first, then falls back to department structure
     * 
     * @param array $hrEmployee - Employee data from HR API
     * @return string - Unit name or empty string
     */
    private function getUnitName($hrEmployee) {
        // Check if unit object exists (new HR API structure)
        if (isset($hrEmployee['unit']) && is_array($hrEmployee['unit'])) {
            $unit = $hrEmployee['unit'];
            if (isset($unit['name']) && !empty($unit['name'])) {
                return trim($unit['name']);
            }
        }
        
        // Fallback to department structure (old structure)
        if (isset($hrEmployee['department']) && is_array($hrEmployee['department'])) {
            $department = $hrEmployee['department'];
            if (isset($department['faculty']['name']) && !empty($department['faculty']['name'])) {
                return trim($department['faculty']['name']);
            }
        }
        
        return '';
    }
    
    public function saveEmployeeToDatabase($employeeData, $createdBy) {
        if (empty($employeeData['hr_employee_id'])) {
            errorLog("[HR_API] Cannot save: missing hr_employee_id");
            return false;
        }
        
        $hrEmployeeId = $this->conn->real_escape_string($employeeData['hr_employee_id']);
        
        $this->conn->begin_transaction();
        
        try {
            $stmt = $this->conn->prepare("
                SELECT id, user_id 
                FROM faculty_researchers 
                WHERE hr_employee_id = ? 
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->bind_param("s", $hrEmployeeId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            // Create or update user record for imported researcher
            $userId = null;
            $email = $employeeData['email'] ?? null;
            $firstName = $employeeData['first_name'] ?? '';
            $lastName = $employeeData['last_name'] ?? '';
            $middleName = $employeeData['middle_name'] ?? '';
            $fullname = trim("$firstName $middleName $lastName");
            $username = $email ?: $hrEmployeeId;
            
            // Check if user already exists by employee_id or email
            $userStmt = $this->conn->prepare("
                SELECT id FROM users 
                WHERE (employee_id = ? OR email = ?) 
                LIMIT 1
            ");
            $userStmt->bind_param("ss", $hrEmployeeId, $email);
            $userStmt->execute();
            $existingUser = $userStmt->get_result()->fetch_assoc();
            $userStmt->close();
            
            if ($existingUser) {
                $userId = $existingUser['id'];
                // Update user record
                $updateUserFields = [];
                if (!empty($fullname)) $updateUserFields[] = "fullname = '" . $this->conn->real_escape_string($fullname) . "'";
                if (!empty($email)) $updateUserFields[] = "email = '" . $this->conn->real_escape_string($email) . "'";
                if (!empty($username)) $updateUserFields[] = "username = '" . $this->conn->real_escape_string($username) . "'";
                $updateUserFields[] = "employee_id = '" . $this->conn->real_escape_string($hrEmployeeId) . "'";
                $updateUserFields[] = "imported = 1";
                
                if (!empty($updateUserFields)) {
                    $updateUserSql = "UPDATE users SET " . implode(', ', $updateUserFields) . " WHERE id = $userId";
                    if (!$this->conn->query($updateUserSql)) {
                        throw new Exception("User update failed: " . $this->conn->error);
                    }
                }
            } else {
                // Create new user record
                $insertUserSql = "INSERT INTO users (username, fullname, email, employee_id, imported, user_role, password) VALUES (
                    '" . $this->conn->real_escape_string($username) . "',
                    " . (!empty($fullname) ? "'" . $this->conn->real_escape_string($fullname) . "'" : "NULL") . ",
                    " . (!empty($email) ? "'" . $this->conn->real_escape_string($email) . "'" : "NULL") . ",
                    '" . $this->conn->real_escape_string($hrEmployeeId) . "',
                    1,
                    'researcher',
                    ''
                )";
                
                if (!$this->conn->query($insertUserSql)) {
                    throw new Exception("User insert failed: " . $this->conn->error);
                }
                $userId = $this->conn->insert_id;
            }
            
            if ($existing) {
                $id = $existing['id'];
                
                debugLog("[HR_API] Updating faculty ID: $id");
                
                $updateFields = [];
                foreach ($employeeData as $key => $value) {
                    if ($key === 'hr_employee_id') continue;
                    if ($value === null) {
                        $updateFields[] = "`$key` = NULL";
                    } else {
                        $escapedValue = $this->conn->real_escape_string($value);
                        $updateFields[] = "`$key` = '$escapedValue'";
                    }
                }
                
                // Update user_id, created_by, and sync_status
                // If re-importing (sync_status was 'n/a'), reset to 'synced'
                // Also update created_by to the person doing the re-import so they can see it
                $updateFields[] = "user_id = $userId";
                $updateFields[] = "created_by = $createdBy";
                $updateFields[] = "sync_status = 'synced'";
                $updateFields[] = "is_synced = 1";
                $updateFields[] = "last_synced_at = NOW()";
                
                $sql = "UPDATE faculty_researchers SET " . 
                       implode(', ', $updateFields) . 
                       " WHERE id = $id";
                
                debugLog("[HR_API] UPDATE SQL for re-import", [
                    'faculty_id' => $id,
                    'created_by_value' => $createdBy,
                    'user_id_value' => $userId,
                    'sql_preview' => substr($sql, 0, 300)
                ]);
                
                if (!$this->conn->query($sql)) {
                    throw new Exception("Update failed: " . $this->conn->error);
                }
                
                // Verify the update worked
                $verifyStmt = $this->conn->prepare("SELECT created_by FROM faculty_researchers WHERE id = ?");
                $verifyStmt->bind_param("i", $id);
                $verifyStmt->execute();
                $verifyResult = $verifyStmt->get_result()->fetch_assoc();
                $verifyStmt->close();
                
                debugLog("[HR_API] Faculty updated and reactivated - VERIFIED", [
                    'faculty_id' => $id,
                    'hr_employee_id' => $hrEmployeeId,
                    'created_by_after_update' => $verifyResult['created_by'] ?? 'NULL',
                    'expected_created_by' => $createdBy,
                    'was_n_a' => true
                ]);
                
                $this->conn->commit();
                return $id;
                
            } else {
                debugLog("[HR_API] Inserting new faculty");
                
                // Ensure created_by and user_id are integers
                $createdByInt = (int)$createdBy;
                $userIdInt = (int)$userId;
                
                debugLog("[HR_API] INSERT - Setting created_by", [
                    'original_created_by' => $createdBy,
                    'cast_created_by' => $createdByInt,
                    'user_id' => $userIdInt
                ]);
                
                $employeeData['created_by'] = $createdByInt;
                $employeeData['user_id'] = $userIdInt;
                $employeeData['sync_status'] = 'synced';
                
                // Fields that should be stored as integers (no quotes)
                $integerFields = ['created_by', 'user_id', 'is_synced'];
                
                $columns = [];
                $values = [];
                
                foreach ($employeeData as $key => $value) {
                    $columns[] = "`$key`";
                    if ($value === null) {
                        $values[] = "NULL";
                    } elseif (in_array($key, $integerFields)) {
                        // Integer fields - no quotes
                        $values[] = (int)$value;
                    } else {
                        $values[] = "'" . $this->conn->real_escape_string($value) . "'";
                    }
                }
                
                $sql = "INSERT INTO faculty_researchers (" . 
                       implode(', ', $columns) . ") VALUES (" . 
                       implode(', ', $values) . ")";
                
                debugLog("[HR_API] Insert SQL", ['sql_preview' => substr($sql, 0, 500)]);
                
                if (!$this->conn->query($sql)) {
                    throw new Exception("Insert failed: " . $this->conn->error);
                }
                
                $id = $this->conn->insert_id;
                
                // Verify the INSERT worked correctly (like we do for UPDATE)
                $verifyStmt = $this->conn->prepare("SELECT created_by, user_id, department, home_unit FROM faculty_researchers WHERE id = ?");
                $verifyStmt->bind_param("i", $id);
                $verifyStmt->execute();
                $verifyResult = $verifyStmt->get_result()->fetch_assoc();
                $verifyStmt->close();
                
                debugLog("[HR_API] New faculty inserted - VERIFIED", [
                    'faculty_id' => $id,
                    'hr_employee_id' => $hrEmployeeId,
                    'created_by_expected' => $createdByInt,
                    'created_by_actual' => $verifyResult['created_by'] ?? 'NULL',
                    'created_by_match' => ($verifyResult['created_by'] == $createdByInt) ? 'YES' : 'NO',
                    'user_id_expected' => $userIdInt,
                    'user_id_actual' => $verifyResult['user_id'] ?? 'NULL',
                    'department' => $verifyResult['department'] ?? 'NULL',
                    'home_unit' => $verifyResult['home_unit'] ?? 'NULL'
                ]);
                
                // If verification fails, log an error
                if ($verifyResult['created_by'] != $createdByInt) {
                    errorLog("[HR_API] CRITICAL: created_by mismatch after INSERT!", [
                        'faculty_id' => $id,
                        'expected' => $createdByInt,
                        'actual' => $verifyResult['created_by']
                    ]);
                }
                
                $this->conn->commit();
                return $id;
            }
            
        } catch (Exception $e) {
            $this->conn->rollback();
            errorLog("[HR_API] Save failed: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function syncEmployee($hrEmployeeId, $createdBy) {
        try {
            debugLog("[HR_API] Syncing employee: $hrEmployeeId");
            
            $hrEmployee = $this->getEmployeeById($hrEmployeeId);
            
            if (empty($hrEmployee)) {
                return [
                    'success' => false,
                    'error' => 'Employee not found in HR System'
                ];
            }
            
            $mappedData = $this->mapEmployeeData($hrEmployee);
            
            if (empty($mappedData)) {
                return [
                    'success' => false,
                    'error' => 'Employee data validation failed'
                ];
            }
            
            $facultyId = $this->saveEmployeeToDatabase($mappedData, $createdBy);
            
            if ($facultyId) {
                return [
                    'success' => true,
                    'faculty_id' => $facultyId,
                    'data' => $mappedData
                ];
            }
            
            return ['success' => false, 'error' => 'Failed to save'];
            
        } catch (Exception $e) {
            errorLog("[HR_API] syncEmployee exception: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Sync/Import Personnel Researcher from HR System
     * Maps HR employee data to personnel_researchers table
     */
    public function syncPersonnelEmployee($hrEmployeeId, $createdBy) {
        try {
            debugLog("[HR_API] Syncing personnel employee: $hrEmployeeId");
            
            $hrEmployee = $this->getEmployeeById($hrEmployeeId);
            
            if (empty($hrEmployee)) {
                return [
                    'success' => false,
                    'error' => 'Employee not found in HR System'
                ];
            }
            
            $mappedData = $this->mapPersonnelData($hrEmployee);
            
            if (empty($mappedData)) {
                return [
                    'success' => false,
                    'error' => 'Personnel data validation failed'
                ];
            }
            
            $personnelId = $this->savePersonnelToDatabase($mappedData, $createdBy);
            
            if ($personnelId) {
                return [
                    'success' => true,
                    'personnel_id' => $personnelId,
                    'data' => $mappedData
                ];
            }
            
            return ['success' => false, 'error' => 'Failed to save personnel'];
            
        } catch (Exception $e) {
            errorLog("[HR_API] syncPersonnelEmployee exception: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Map HR API employee data to personnel_researchers table format
     */
    public function mapPersonnelData($employee) {
        if (empty($employee) || empty($employee['id'])) {
            return null;
        }
        
        $name = $employee['name'] ?? [];
        $contact = $employee['contact'] ?? [];
        $position = $employee['position'] ?? [];
        $department = $employee['department'] ?? $employee['unit'] ?? [];
        $sector = $employee['sector'] ?? [];
        $employmentStatus = $employee['employment_status'] ?? null;
        
        // Extract sector name
        $sectorName = '';
        if (is_array($sector)) {
            $sectorName = $sector['name'] ?? '';
        } elseif (is_string($sector)) {
            $sectorName = $sector;
        }
        
        // Map employment type
        $empType = 'Full-Time';
        if ($employmentStatus) {
            $statusName = is_array($employmentStatus) ? ($employmentStatus['name'] ?? '') : $employmentStatus;
            $normalizedStatus = strtolower(trim($statusName));
            if (strpos($normalizedStatus, 'part') !== false || strpos($normalizedStatus, 'part-time') !== false) {
                $empType = 'Part-Time';
            } elseif (strpos($normalizedStatus, 'contractual') !== false || strpos($normalizedStatus, 'contract') !== false) {
                $empType = 'Contractual';
            } elseif (strpos($normalizedStatus, 'casual') !== false) {
                $empType = 'Casual';
            }
        }
        
        return [
            'hr_employee_id' => $employee['id'],
            'employee_number' => $employee['id'], // Use HR ID as employee number if no separate field
            'last_name' => $name['surname'] ?? '',
            'first_name' => $name['first_name'] ?? '',
            'middle_name' => $name['middle_name'] ?? '',
            'home_address' => $contact['address'] ?? null,
            'telephone' => $contact['phone'] ?? null,
            'mobile' => $contact['mobile'] ?? null,
            'email' => $contact['email'] ?? null,
            'position' => $position['name'] ?? null,
            'employment_status' => $empType,
            'office_unit' => is_array($department) ? ($department['name'] ?? null) : null,
            'department' => is_array($department) ? ($department['name'] ?? null) : null,
            'sector' => $sectorName,
            'is_synced' => 1,
            'last_synced_at' => date('Y-m-d H:i:s'),
            'hr_data_json' => json_encode($employee)
        ];
    }
    
    /**
     * Save personnel data to database (insert or update)
     */
    public function savePersonnelToDatabase($personnelData, $createdBy) {
        if (empty($personnelData['hr_employee_id'])) {
            errorLog("[HR_API] Cannot save personnel: missing hr_employee_id");
            return false;
        }
        
        $hrEmployeeId = $this->conn->real_escape_string($personnelData['hr_employee_id']);
        
        $this->conn->begin_transaction();
        
        try {
            $stmt = $this->conn->prepare("
                SELECT id, user_id 
                FROM personnel_researchers 
                WHERE hr_employee_id = ? 
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->bind_param("s", $hrEmployeeId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            // Create or update user record for imported researcher
            $userId = null;
            $email = $personnelData['email'] ?? null;
            $firstName = $personnelData['first_name'] ?? '';
            $lastName = $personnelData['last_name'] ?? '';
            $middleName = $personnelData['middle_name'] ?? '';
            $fullname = trim("$firstName $middleName $lastName");
            $username = $email ?: $hrEmployeeId;
            
            // Check if user already exists by employee_id or email
            $userStmt = $this->conn->prepare("
                SELECT id FROM users 
                WHERE (employee_id = ? OR email = ?) 
                LIMIT 1
            ");
            $userStmt->bind_param("ss", $hrEmployeeId, $email);
            $userStmt->execute();
            $existingUser = $userStmt->get_result()->fetch_assoc();
            $userStmt->close();
            
            if ($existingUser) {
                $userId = $existingUser['id'];
                // Update user record
                $updateUserFields = [];
                if (!empty($fullname)) $updateUserFields[] = "fullname = '" . $this->conn->real_escape_string($fullname) . "'";
                if (!empty($email)) $updateUserFields[] = "email = '" . $this->conn->real_escape_string($email) . "'";
                if (!empty($username)) $updateUserFields[] = "username = '" . $this->conn->real_escape_string($username) . "'";
                $updateUserFields[] = "employee_id = '" . $this->conn->real_escape_string($hrEmployeeId) . "'";
                $updateUserFields[] = "imported = 1";
                
                if (!empty($updateUserFields)) {
                    $updateUserSql = "UPDATE users SET " . implode(', ', $updateUserFields) . " WHERE id = $userId";
                    if (!$this->conn->query($updateUserSql)) {
                        throw new Exception("User update failed: " . $this->conn->error);
                    }
                }
            } else {
                // Create new user record
                $insertUserSql = "INSERT INTO users (username, fullname, email, employee_id, imported, user_role, password) VALUES (
                    '" . $this->conn->real_escape_string($username) . "',
                    " . (!empty($fullname) ? "'" . $this->conn->real_escape_string($fullname) . "'" : "NULL") . ",
                    " . (!empty($email) ? "'" . $this->conn->real_escape_string($email) . "'" : "NULL") . ",
                    '" . $this->conn->real_escape_string($hrEmployeeId) . "',
                    1,
                    'researcher',
                    ''
                )";
                
                if (!$this->conn->query($insertUserSql)) {
                    throw new Exception("User insert failed: " . $this->conn->error);
                }
                $userId = $this->conn->insert_id;
            }
            
            if ($existing) {
                $id = $existing['id'];
                
                debugLog("[HR_API] Updating personnel ID: $id");
                
                $updateFields = [];
                foreach ($personnelData as $key => $value) {
                    if ($key === 'hr_employee_id') continue;
                    if ($value === null) {
                        $updateFields[] = "`$key` = NULL";
                    } else {
                        $escapedValue = $this->conn->real_escape_string($value);
                        $updateFields[] = "`$key` = '$escapedValue'";
                    }
                }
                
                // Update user_id, created_by, and sync_status
                // Also update created_by to the person doing the re-import so they can see it
                $updateFields[] = "user_id = $userId";
                $updateFields[] = "created_by = $createdBy";
                $updateFields[] = "sync_status = 'synced'";
                $updateFields[] = "is_synced = 1";
                $updateFields[] = "last_synced_at = NOW()";
                
                $sql = "UPDATE personnel_researchers SET " . 
                       implode(', ', $updateFields) . 
                       " WHERE id = $id";
                
                if (!$this->conn->query($sql)) {
                    throw new Exception("Update failed: " . $this->conn->error);
                }
                
                debugLog("[HR_API] Personnel updated and reactivated", [
                    'personnel_id' => $id,
                    'hr_employee_id' => $hrEmployeeId,
                    'created_by' => $createdBy
                ]);
                
                $this->conn->commit();
                return $id;
                
            } else {
                debugLog("[HR_API] Inserting new personnel");
                
                // Ensure created_by and user_id are integers
                $createdByInt = (int)$createdBy;
                $userIdInt = (int)$userId;
                
                $personnelData['created_by'] = $createdByInt;
                $personnelData['user_id'] = $userIdInt;
                $personnelData['sync_status'] = 'synced';
                
                // Fields that should be stored as integers (no quotes)
                $integerFields = ['created_by', 'user_id', 'is_synced'];
                
                $columns = [];
                $values = [];
                
                foreach ($personnelData as $key => $value) {
                    $columns[] = "`$key`";
                    if ($value === null) {
                        $values[] = "NULL";
                    } elseif (in_array($key, $integerFields)) {
                        // Integer fields - no quotes
                        $values[] = (int)$value;
                    } else {
                        $values[] = "'" . $this->conn->real_escape_string($value) . "'";
                    }
                }
                
                $sql = "INSERT INTO personnel_researchers (" . 
                       implode(', ', $columns) . ") VALUES (" . 
                       implode(', ', $values) . ")";
                
                if (!$this->conn->query($sql)) {
                    throw new Exception("Insert failed: " . $this->conn->error);
                }
                
                $id = $this->conn->insert_id;
                
                // Verify the INSERT worked correctly
                $verifyStmt = $this->conn->prepare("SELECT created_by, user_id FROM personnel_researchers WHERE id = ?");
                $verifyStmt->bind_param("i", $id);
                $verifyStmt->execute();
                $verifyResult = $verifyStmt->get_result()->fetch_assoc();
                $verifyStmt->close();
                
                debugLog("[HR_API] New personnel inserted - VERIFIED", [
                    'personnel_id' => $id,
                    'created_by_expected' => $createdByInt,
                    'created_by_actual' => $verifyResult['created_by'] ?? 'NULL',
                    'created_by_match' => ($verifyResult['created_by'] == $createdByInt) ? 'YES' : 'NO'
                ]);
                
                $this->conn->commit();
                return $id;
            }
            
        } catch (Exception $e) {
            $this->conn->rollback();
            errorLog("[HR_API] Save personnel failed: " . $e->getMessage());
            throw $e;
        }
    }
}