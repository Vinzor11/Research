<?php
/**
 * work_queue.php
 * 
 * Unified Work Queue / Review Inbox
 * Consolidates all actionable review items across the system into one inbox.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'UnifiedQueueService.php';
require_once 'spa_helper.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Only coordinators and admins can access
$userRole = $_SESSION['user_role'] ?? 'researcher';
if (!in_array($userRole, ['coordinator', 'admin'])) {
    header('Location: research.php');
    exit;
}

$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly (not via AJAX)
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$userId = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';
$employeeId = $_SESSION['employee_id'] ?? null;

// Get coordinator types for role display
$coordinatorTypes = [];
if ($userRole === 'coordinator' && $employeeId) {
    $typeStmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
    $typeStmt->bind_param("s", $employeeId);
    $typeStmt->execute();
    $typeResult = $typeStmt->get_result();
    while ($row = $typeResult->fetch_assoc()) {
        $coordinatorTypes[] = ucfirst($row['coordinator_type']);
    }
    $typeStmt->close();
}

$queueService = new UnifiedQueueService($conn, $userId);

// Get initial filter from URL (for sidebar badge links)
$initialType = $_GET['type'] ?? '';
$initialStatus = $_GET['status'] ?? '';
$initialSearch = $_GET['q'] ?? '';

// Get queue statistics
$stats = $queueService->getQueueStats();

// Get initial items
$filters = [];
if ($initialType) $filters['type'] = $initialType;
if ($initialStatus) $filters['status'] = $initialStatus;
if ($initialSearch) $filters['search'] = $initialSearch;

$page = max(1, (int)($_GET['page'] ?? 1));
$result = $queueService->getQueueItems($filters, $page, 20);
$items = $result['data'];
$pagination = $result['pagination'];

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   WORK QUEUE - UNIFIED DESIGN (Matching Unit Projects)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }
.role-badge.badge-faculty { background: #dbeafe; color: #1e40af; }
.role-badge.badge-student { background: #fef3c7; color: #92400e; }
.role-badge.badge-personnel { background: #e0e7ff; color: #5b21b6; }

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    cursor: pointer;
    transition: all 0.2s;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.proposal { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.progress { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }
.stat-icon.extension { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.output { background: linear-gradient(135deg, #ede9fe, #ddd6fe); color: #5b21b6; }
.stat-icon.completion { background: linear-gradient(135deg, #cffafe, #a5f3fc); color: #0e7490; }
.stat-icon.collaboration { background: linear-gradient(135deg, #fce7f3, #fbcfe8); color: #be185d; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header-left i { color: #064e1a; font-size: 18px; }

.filter-link {
    font-size: 13px;
    color: #064e1a;
    text-decoration: none;
    font-weight: 500;
}

.filter-link:hover {
    text-decoration: underline;
}

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

/* Column widths */
.queue-table th:nth-child(1) { width: 10%; }
.queue-table th:nth-child(2) { width: 35%; }
.queue-table th:nth-child(3) { width: 18%; text-align: center; }
.queue-table th:nth-child(4) { width: 12%; text-align: center; }
.queue-table th:nth-child(5) { width: 12%; text-align: center; }
.queue-table th:nth-child(6) { width: 13%; text-align: center; }

.queue-table td {
    padding: 14px 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
}

.queue-table td:nth-child(3),
.queue-table td:nth-child(4),
.queue-table td:nth-child(5),
.queue-table td:nth-child(6) {
    text-align: center;
    vertical-align: middle;
}

.queue-table tbody tr:hover {
    background: #f9fafb;
}

/* Type Badge */
.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.type-badge i { font-size: 12px; }

.type-proposal { background: #dbeafe; color: #1e40af; }
.type-progress { background: #d1fae5; color: #065f46; }
.type-extension { background: #fef3c7; color: #92400e; }
.type-output { background: #ede9fe; color: #5b21b6; }
.type-completion { background: #cffafe; color: #0e7490; }
.type-collaboration { background: #fce7f3; color: #be185d; }

/* Item Cell */
.item-cell { text-align: left; }

.item-title {
    font-weight: 600;
    font-size: 14px;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.item-subtitle {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 6px;
}

.item-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.ref-badge {
    font-size: 11px;
    color: #9ca3af;
    font-family: 'Consolas', monospace;
    display: inline-block;
    background: #f3f4f6;
    padding: 3px 8px;
    border-radius: 4px;
}

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
}

.researcher-type-badge.faculty { background: #dbeafe; color: #1e40af; }
.researcher-type-badge.student { background: #fef3c7; color: #92400e; }
.researcher-type-badge.personnel { background: #e0e7ff; color: #5b21b6; }

.researcher-name {
    font-size: 12px;
    color: #374151;
    display: flex;
    align-items: center;
    gap: 4px;
}

.researcher-name i { color: #9ca3af; font-size: 11px; }

/* Unit Cell */
.unit-cell {
    font-size: 13px;
    color: #374151;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-pending { background: #dbeafe; color: #1e40af; }
.status-reviewing { background: #fef3c7; color: #92400e; }
.status-endorsed { background: #ede9fe; color: #5b21b6; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }
.status-returned { background: #fee2e2; color: #991b1b; }
.status-default { background: #f3f4f6; color: #4b5563; }

/* Date Cell */
.date-cell {
    font-size: 13px;
    color: #6b7280;
}

/* Action Cell */
.action-cell { text-align: center; }

/* Review Button */
.btn-review {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-review:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

.btn-start-review {
    background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
}

.btn-start-review:hover {
    background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);
}

/* Pagination Container */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }
.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; }
.pagination .current { background: #064e1a; color: white; }

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Loading Overlay */
.loading-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255,255,255,0.8);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 10;
}

.loading-overlay.active {
    display: flex;
}

.loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #e5e7eb;
    border-top-color: #064e1a;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Responsive */
@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .page-header-banner {
        padding: 20px;
    }
    
    .header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .header-left {
        flex-direction: column;
    }
    
    .stats-row {
        flex-wrap: wrap;
    }
    
    .stat-card {
        min-width: calc(50% - 8px);
        flex: unset;
    }
    
    .filter-grid {
        grid-template-columns: 1fr;
    }
    
    .queue-table th:nth-child(3),
    .queue-table td:nth-child(3),
    .queue-table th:nth-child(5),
    .queue-table td:nth-child(5) {
        display: none;
    }
    
    .pagination-container {
        flex-direction: column;
        gap: 12px;
    }
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa fa-inbox header-icon"></i>
                <div>
                    <h1>Work Queue</h1>
                    <p>Review and process pending submissions, reports, and requests</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <?php if ($userRole === 'admin'): ?>
                    <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #065f46;">
                        <i class="fa fa-user-shield"></i> 
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        Admin
                    </span>
                <?php else: ?>
                    <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #064e1a;">
                        <i class="fa fa-user-tie"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        <?php if (!empty($coordinatorTypes)): ?>
                            <?= implode(' / ', array_map(function($t) { return ucfirst($t); }, $coordinatorTypes)) ?> Coordinator
                        <?php else: ?>
                            Coordinator
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <div class="stats-row">
        <div class="stat-card <?= empty($initialType) ? 'active' : '' ?>" onclick="filterByType('')" data-type="">
            <div class="stat-icon total"><i class="fa fa-layer-group"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-total"><?= $stats['total'] ?></div>
                <div class="stat-label">Total Items</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'proposal' ? 'active' : '' ?>" onclick="filterByType('proposal')" data-type="proposal">
            <div class="stat-icon proposal"><i class="fa fa-file-alt"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-proposals"><?= $stats['proposals'] ?></div>
                <div class="stat-label">Proposals</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'progress' ? 'active' : '' ?>" onclick="filterByType('progress')" data-type="progress">
            <div class="stat-icon progress"><i class="fa fa-chart-line"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-progress"><?= $stats['progress'] ?></div>
                <div class="stat-label">Progress</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'extension' ? 'active' : '' ?>" onclick="filterByType('extension')" data-type="extension">
            <div class="stat-icon extension"><i class="fa fa-calendar-plus"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-extensions"><?= $stats['extensions'] ?></div>
                <div class="stat-label">Extensions</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'output' ? 'active' : '' ?>" onclick="filterByType('output')" data-type="output">
            <div class="stat-icon output"><i class="fa fa-book"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-outputs"><?= $stats['outputs'] ?></div>
                <div class="stat-label">Outputs</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'completion' ? 'active' : '' ?>" onclick="filterByType('completion')" data-type="completion">
            <div class="stat-icon completion"><i class="fa fa-flag-checkered"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-completions"><?= $stats['completions'] ?></div>
                <div class="stat-label">Completions</div>
            </div>
        </div>
        <div class="stat-card <?= $initialType === 'collaboration' ? 'active' : '' ?>" onclick="filterByType('collaboration')" data-type="collaboration">
            <div class="stat-icon collaboration"><i class="fa fa-handshake"></i></div>
            <div class="stat-info">
                <div class="stat-number" id="stat-collaborations"><?= $stats['collaborations'] ?? 0 ?></div>
                <div class="stat-label">Collaborations</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <div class="filter-header-left">
                <i class="fa fa-filter"></i>
            </div>
            <a href="#" class="filter-link" onclick="clearFilters(); return false;">Filter Queue</a>
        </div>
        
        <div class="filter-grid">
            <div class="filter-group">
                <label>Item Type</label>
                <select id="filter-type" onchange="applyFilters()">
                    <option value="">All Types</option>
                    <option value="proposal" <?= $initialType === 'proposal' ? 'selected' : '' ?>>Proposals</option>
                    <option value="progress" <?= $initialType === 'progress' ? 'selected' : '' ?>>Progress Reports</option>
                    <option value="extension" <?= $initialType === 'extension' ? 'selected' : '' ?>>Extensions</option>
                    <option value="output" <?= $initialType === 'output' ? 'selected' : '' ?>>Outputs</option>
                    <option value="completion" <?= $initialType === 'completion' ? 'selected' : '' ?>>Completions</option>
                    <option value="collaboration" <?= $initialType === 'collaboration' ? 'selected' : '' ?>>Collaborations</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Status</label>
                <select id="filter-status" onchange="applyFilters()">
                    <option value="">All Statuses</option>
                    <option value="submitted" <?= $initialStatus === 'submitted' ? 'selected' : '' ?>>Pending Review</option>
                    <option value="under_coordinator_review" <?= $initialStatus === 'under_coordinator_review' ? 'selected' : '' ?>>Under Coordinator Review</option>
                    <option value="endorsed" <?= $initialStatus === 'endorsed' ? 'selected' : '' ?>>Endorsed</option>
                    <option value="under_ro_review" <?= $initialStatus === 'under_ro_review' ? 'selected' : '' ?>>Under RO Review</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Date From</label>
                <input type="date" id="filter-date-from" onchange="applyFilters()">
            </div>
            
            <div class="filter-group">
                <label>Date To</label>
                <input type="date" id="filter-date-to" onchange="applyFilters()">
            </div>
            
            <div class="filter-group">
                <label>Search</label>
                <input type="text" id="filter-search" placeholder="Search by reference, title, or requester..." value="<?= s($initialSearch) ?>">
            </div>
            
            <div class="filter-actions">
                <button type="button" class="clear-btn" onclick="clearFilters()" title="Clear Filters">
                    <i class="fa fa-times"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Queue Table -->
    <div class="queue-table-container" style="position: relative;">
        <div class="loading-overlay" id="loading-overlay">
            <div class="loading-spinner"></div>
        </div>
        
        <div id="queue-content">
            <?php if (empty($items)): ?>
                <div class="empty-state">
                    <i class="fa fa-check-circle"></i>
                    <h3>Queue is Empty</h3>
                    <p>No items are currently awaiting your review.</p>
                </div>
            <?php else: ?>
                <table class="queue-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Item</th>
                            <th>Unit</th>
                            <th>Status</th>
                            <th>Submitted</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <span class="type-badge <?= s($item['type_color']) ?>">
                                        <i class="fa <?= s($item['type_icon']) ?>"></i>
                                        <?= s($item['type_label']) ?>
                                    </span>
                                </td>
                                <td class="item-cell">
                                    <div class="item-title"><?= s($item['project_title']) ?></div>
                                    <?php if (!empty($item['item_subtitle'])): ?>
                                        <div class="item-subtitle"><?= s($item['item_subtitle']) ?></div>
                                    <?php endif; ?>
                                    <div class="item-badges">
                                        <?php if ($item['reference_number']): ?>
                                            <span class="ref-badge"><?= s($item['reference_number']) ?></span>
                                        <?php endif; ?>
                                        <span class="researcher-type-badge <?= s(strtolower($item['researcher_type'] ?? 'unknown')) ?>">
                                            <?= s(strtoupper($item['researcher_type'] ?? 'Unknown')) ?>
                                        </span>
                                    </div>
                                    <div class="researcher-name" style="margin-top: 6px;">
                                        <i class="fa fa-user"></i> <?= s($item['requester_name']) ?>
                                    </div>
                                </td>
                                <td class="unit-cell"><?= s($item['unit_name']) ?></td>
                                <td>
                                    <span class="status-badge <?= s($item['status_class']) ?>">
                                        <?= s($item['status_label']) ?>
                                    </span>
                                </td>
                                <td class="date-cell"><?= date('M d, Y', strtotime($item['submitted_at'])) ?></td>
                                <td>
                                    <div class="actions-cell">
                                        <?php if (in_array($item['status'], ['submitted', 'endorsed'])): ?>
                                            <button class="btn-review btn-start-review" 
                                                    onclick="startReview('<?= s($item['item_type']) ?>', <?= (int)$item['source_id'] ?>, <?= (int)$item['project_id'] ?>, '<?= s($item['status']) ?>')">
                                                <i class="fa fa-play"></i> Start Review
                                            </button>
                                        <?php elseif (!empty($item['review_url'])): ?>
                                            <a href="<?= s($item['review_url']) ?>" class="btn-review"
                                               onclick="event.preventDefault(); navigateToReview('<?= s($item['review_url']) ?>');">
                                                <i class="fa fa-eye"></i> View
                                            </a>
                                        <?php else: ?>
                                            <span class="btn-review" style="opacity: 0.5; cursor: not-allowed;" title="Review URL not available">
                                                <i class="fa fa-exclamation-triangle"></i> Error
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="pagination-container">
                    <div class="pagination-info">
                        Showing <?= count($items) ?> of <?= $pagination['total'] ?> items
                    </div>
                    
                    <?php if ($pagination['total_pages'] > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="#" onclick="goToPage(<?= $page - 1 ?>); return false;">
                                    <i class="fa fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($pagination['total_pages'], $page + 2); $i++): ?>
                                <?php if ($i === $page): ?>
                                    <span class="current"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="#" onclick="goToPage(<?= $i ?>); return false;"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $pagination['total_pages']): ?>
                                <a href="#" onclick="goToPage(<?= $page + 1 ?>); return false;">
                                    <i class="fa fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div><!-- End of .content -->

<!-- Output Review Modal -->
<div id="outputReviewModal" class="modal-overlay" style="display: none;">
    <div class="modal-container" style="max-width: 500px;">
        <div class="modal-header">
            <h3><i class="fa fa-check-circle"></i> Review Output</h3>
            <button class="modal-close" onclick="closeOutputReviewModal()">&times;</button>
        </div>
        <div class="modal-body">
            <p><strong>Output:</strong> <span id="outputReviewTitle"></span></p>
            <input type="hidden" id="outputReviewId">
            
            <div class="form-group" style="margin-top: 15px;">
                <label><strong>Decision:</strong></label>
                <div style="display: flex; gap: 10px; margin-top: 8px;">
                    <button type="button" class="btn-action btn-approve" onclick="submitOutputReview('verified')" style="flex: 1;">
                        <i class="fa fa-check"></i> Verify
                    </button>
                    <button type="button" class="btn-action btn-reject" onclick="submitOutputReview('rejected')" style="flex: 1;">
                        <i class="fa fa-times"></i> Reject
                    </button>
                </div>
            </div>
            
            <div class="form-group" style="margin-top: 15px;">
                <label for="outputReviewRemarks"><strong>Remarks (optional):</strong></label>
                <textarea id="outputReviewRemarks" rows="3" style="width: 100%; margin-top: 5px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"></textarea>
            </div>
        </div>
    </div>
</div>

<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}
.modal-container {
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    width: 90%;
    max-height: 90vh;
    overflow: auto;
}
.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    border-bottom: 1px solid #eee;
}
.modal-header h3 {
    margin: 0;
    font-size: 1.1rem;
    color: #1a1a2e;
}
.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #666;
}
.modal-close:hover { color: #333; }
.modal-body {
    padding: 20px;
}
.btn-action {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.btn-approve {
    background: #10b981;
    color: white;
}
.btn-approve:hover { background: #059669; }
.btn-reject {
    background: #ef4444;
    color: white;
}
.btn-reject:hover { background: #dc2626; }
</style>

<script>
// Current state - use window scope to avoid SPA re-declaration
window.queueCurrentPage = <?= $page ?>;
if (typeof window.queueSearchTimeout === 'undefined') {
    window.queueSearchTimeout = null;
}

// Debounced search input
const queueSearchInput = document.getElementById('filter-search');
if (queueSearchInput && !queueSearchInput.dataset.listenerAttached) {
    queueSearchInput.dataset.listenerAttached = 'true';
    queueSearchInput.addEventListener('input', function() {
        clearTimeout(window.queueSearchTimeout);
        window.queueSearchTimeout = setTimeout(() => {
            applyFilters();
        }, 350); // 350ms debounce
    });
}

// Filter by clicking stat cards
function filterByType(type) {
    document.getElementById('filter-type').value = type;
    
    // Update active state on cards
    document.querySelectorAll('.stat-card').forEach(card => {
        card.classList.remove('active');
        if (card.dataset.type === type) {
            card.classList.add('active');
        }
    });
    
    applyFilters();
}

// Apply all filters
function applyFilters() {
    window.queueCurrentPage = 1;
    loadQueueItems();
}

// Clear all filters
function clearFilters() {
    document.getElementById('filter-type').value = '';
    document.getElementById('filter-status').value = '';
    document.getElementById('filter-date-from').value = '';
    document.getElementById('filter-date-to').value = '';
    document.getElementById('filter-search').value = '';
    
    document.querySelectorAll('.stat-card').forEach(card => {
        card.classList.remove('active');
        if (card.dataset.type === '') {
            card.classList.add('active');
        }
    });
    
    window.queueCurrentPage = 1;
    loadQueueItems();
}

// Go to specific page
function goToPage(page) {
    window.queueCurrentPage = page;
    loadQueueItems();
}

// Load queue items via AJAX
async function loadQueueItems() {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.add('active');
    
    try {
        const params = new URLSearchParams({
            action: 'get_items',
            page: window.queueCurrentPage,
            type: document.getElementById('filter-type').value,
            status: document.getElementById('filter-status').value,
            date_from: document.getElementById('filter-date-from').value,
            date_to: document.getElementById('filter-date-to').value,
            q: document.getElementById('filter-search').value
        });
        
        const response = await fetch(`work_queue_api.php?${params}`);
        const result = await response.json();
        
        if (result.success) {
            renderQueueItems(result.data, result.pagination);
            updateFilterCount(result.pagination.total);
        } else {
            console.error('Error loading queue:', result.error);
        }
    } catch (error) {
        console.error('Error:', error);
    } finally {
        overlay.classList.remove('active');
    }
}

// Render queue items
function renderQueueItems(items, pagination) {
    const container = document.getElementById('queue-content');
    
    if (items.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fa fa-check-circle"></i>
                <h3>No Items Found</h3>
                <p>No items match your current filters.</p>
            </div>
        `;
        return;
    }
    
    let html = `
        <table class="queue-table">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Item</th>
                    <th>Unit</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    items.forEach(item => {
        const submittedDate = new Date(item.submitted_at).toLocaleDateString('en-US', { 
            month: 'short', day: 'numeric', year: 'numeric' 
        });
        
        html += `
            <tr>
                <td>
                    <span class="type-badge ${escapeHtml(item.type_color)}">
                        <i class="fa ${escapeHtml(item.type_icon)}"></i>
                        ${escapeHtml(item.type_label)}
                    </span>
                </td>
                <td class="item-cell">
                    <div class="item-title">${escapeHtml(item.project_title || '')}</div>
                    <div class="item-subtitle">${escapeHtml(item.item_subtitle || '')}</div>
                    <div class="item-meta">
                        ${item.reference_number ? `<span class="ref">${escapeHtml(item.reference_number)}</span>` : ''}
                        <span class="researcher-type-badge researcher-${escapeHtml(item.researcher_type || 'unknown')}">
                            ${escapeHtml((item.researcher_type || 'Unknown').charAt(0).toUpperCase() + (item.researcher_type || 'Unknown').slice(1))}
                        </span>
                        <span><i class="fa fa-user"></i> ${escapeHtml(item.requester_name || 'Unknown')}</span>
                    </div>
                </td>
                <td class="unit-cell">${escapeHtml(item.unit_name || '')}</td>
                <td>
                    <span class="status-badge ${escapeHtml(item.status_class)}">
                        ${escapeHtml(item.status_label)}
                    </span>
                </td>
                <td class="date-cell">${submittedDate}</td>
                <td>
                    <div class="actions-cell">
                        ${['submitted', 'endorsed'].includes(item.status) ? `
                            <button class="btn-review btn-start-review" 
                                    onclick="startReview('${escapeHtml(item.item_type)}', ${item.source_id}, ${item.project_id || item.source_id}, '${escapeHtml(item.status)}')">
                                <i class="fa fa-play"></i> Start Review
                            </button>
                        ` : (item.review_url ? `
                            <a href="${escapeHtml(item.review_url)}" class="btn-review"
                               onclick="event.preventDefault(); navigateToReview('${escapeHtml(item.review_url)}');">
                                <i class="fa fa-eye"></i> View
                            </a>
                        ` : `
                            <span class="btn-review" style="opacity: 0.5; cursor: not-allowed;" title="Review URL not available">
                                <i class="fa fa-exclamation-triangle"></i> Error
                            </span>
                        `)}
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += `
            </tbody>
        </table>
        <div class="table-footer">
            <div class="showing">
                Showing ${items.length} of ${pagination.total} items
            </div>
            ${renderPagination(pagination)}
        </div>
    `;
    
    container.innerHTML = html;
}

// Render pagination
function renderPagination(pagination) {
    if (pagination.total_pages <= 1) return '';
    
    let html = '<div class="pagination">';
    
    if (window.queueCurrentPage > 1) {
        html += `<a href="#" onclick="goToPage(${window.queueCurrentPage - 1}); return false;"><i class="fa fa-chevron-left"></i></a>`;
    }
    
    for (let i = Math.max(1, window.queueCurrentPage - 2); i <= Math.min(pagination.total_pages, window.queueCurrentPage + 2); i++) {
        if (i === window.queueCurrentPage) {
            html += `<span class="current">${i}</span>`;
        } else {
            html += `<a href="#" onclick="goToPage(${i}); return false;">${i}</a>`;
        }
    }
    
    if (window.queueCurrentPage < pagination.total_pages) {
        html += `<a href="#" onclick="goToPage(${window.queueCurrentPage + 1}); return false;"><i class="fa fa-chevron-right"></i></a>`;
    }
    
    html += '</div>';
    return html;
}

// Update filter count display
function updateFilterCount(total) {
    const countEl = document.getElementById('filter-count');
    if (total > 0) {
        countEl.textContent = `${total} item${total !== 1 ? 's' : ''} found`;
    } else {
        countEl.textContent = 'No items found';
    }
}

// Start Review - changes status to Under Review
function startReview(itemType, sourceId, projectId, itemStatus) {
    console.log('startReview called:', { itemType, sourceId, projectId, itemStatus });
    
    // For outputs, navigate directly to the output view page
    // Outputs go directly from submitted → verified/rejected without intermediate status
    if (itemType === 'output') {
        if (!confirm('Open this output for review?')) return;
        navigateToReview(`project_output_view.php?id=${sourceId}`);
        return;
    }
    
    if (!confirm('Start reviewing this item? It will be marked as "Under Review".')) return;
    
    let apiUrl, body;
    
    if (itemType === 'proposal') {
        apiUrl = 'submission_api.php';
        body = JSON.stringify({ action: 'start_review', submission_id: sourceId });
    } else if (itemType === 'progress') {
        apiUrl = 'project_api.php';
        // For endorsed progress reports, RO starts review; for submitted, coordinator starts review
        const progressAction = itemStatus === 'endorsed' ? 'start_ro_progress_review' : 'start_progress_review';
        body = JSON.stringify({ action: progressAction, report_id: sourceId });
    } else if (itemType === 'completion') {
        apiUrl = 'project_api.php';
        // For endorsed completion reports, RO starts review; for submitted, coordinator starts review
        const completionAction = itemStatus === 'endorsed' ? 'start_ro_completion_review' : 'start_completion_review';
        body = JSON.stringify({ action: completionAction, report_id: sourceId });
    } else if (itemType === 'extension') {
        apiUrl = 'project_api.php';
        // For endorsed extensions, RO starts review; for submitted, coordinator starts review
        const extensionAction = itemStatus === 'endorsed' ? 'start_ro_extension_review' : 'start_extension_review';
        body = JSON.stringify({ action: extensionAction, extension_id: sourceId });
    } else if (itemType === 'collaboration') {
        apiUrl = 'collaboration_api.php';
        // For endorsed collaborations, RO starts review; for submitted, coordinator starts review
        const collaborationAction = itemStatus === 'endorsed' ? 'start_ro_review' : 'start_review';
        body = JSON.stringify({ action: collaborationAction, id: sourceId });
    } else {
        // For unknown types, show error
        console.log('Unknown item type:', itemType);
        alert('Cannot start review: Unknown item type "' + itemType + '"');
        return;
    }
    
    console.log('Calling API:', { apiUrl, body });
    
    fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body
    })
    .then(r => {
        console.log('Response status:', r.status);
        return r.json();
    })
    .then(data => {
        console.log('API response:', data);
        if (data.success) {
            refreshQueuePage();
        } else {
            alert(data.error || 'Failed to start review');
        }
    })
    .catch(err => {
        console.error('Error starting review:', err);
        alert('Failed to start review: ' + err.message);
    });
}

// Properly refresh the queue page in SPA context
function refreshQueuePage() {
    if (window.SPA) {
        // Clear cache for work_queue.php before reloading to get fresh data
        if (window.SPA.cache) {
            window.SPA.cache.delete('work_queue.php');
        }
        window.SPA.loadPage('work_queue.php', false);
    } else {
        location.reload();
    }
}

// Output Review Modal Functions
function openOutputReviewModal(outputId, title) {
    document.getElementById('outputReviewId').value = outputId;
    document.getElementById('outputReviewTitle').textContent = title;
    document.getElementById('outputReviewRemarks').value = '';
    document.getElementById('outputReviewModal').style.display = 'flex';
}

function closeOutputReviewModal() {
    document.getElementById('outputReviewModal').style.display = 'none';
}

async function submitOutputReview(decision) {
    const outputId = document.getElementById('outputReviewId').value;
    const remarks = document.getElementById('outputReviewRemarks').value.trim();
    
    if (!outputId) {
        alert('Error: No output selected');
        return;
    }
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'review_output',
                output_id: parseInt(outputId),
                decision: decision,
                remarks: remarks
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            closeOutputReviewModal();
            refreshQueuePage();
        } else {
            alert(data.error || 'Failed to submit review');
        }
    } catch (err) {
        console.error('Error submitting output review:', err);
        alert('Failed to submit review: ' + err.message);
    }
}

// Close modal when clicking outside
document.getElementById('outputReviewModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeOutputReviewModal();
    }
});

// Navigate to review page
function navigateToReview(url) {
    // Validate URL before navigating
    if (!url || url.trim() === '') {
        alert('Error: Invalid review URL. Please refresh the page and try again.');
        console.error('navigateToReview called with empty URL');
        return;
    }
    
    // Additional validation: ensure view pages have proper ID parameters
    const viewPages = ['submission_view.php', 'project_extension_view.php', 'project_progress_view.php', 
                       'project_output_view.php', 'collaboration_view.php', 'project_view.php'];
    const isViewPage = viewPages.some(page => url.includes(page));
    
    if (isViewPage && !url.includes('id=')) {
        alert('Error: Missing ID parameter in URL. Please refresh the page and try again.');
        console.error('navigateToReview: View page URL missing id parameter:', url);
        return;
    }
    
    // Check for id=0 or id= (empty) which are also invalid
    const idMatch = url.match(/[?&]id=(\d*)/);
    if (isViewPage && idMatch && (!idMatch[1] || idMatch[1] === '0')) {
        alert('Error: Invalid ID in URL. Please refresh the page and try again.');
        console.error('navigateToReview: Invalid id value in URL:', url);
        return;
    }
    
    if (window.SPA && window.SPA.loadPage) {
        window.SPA.loadPage(url);
    } else {
        window.location.href = url;
    }
}

// Escape HTML for XSS prevention
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Refresh stats periodically
async function refreshStats() {
    try {
        const response = await fetch('work_queue_api.php?action=get_stats');
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('stat-total').textContent = result.stats.total;
            document.getElementById('stat-proposals').textContent = result.stats.proposals;
            document.getElementById('stat-progress').textContent = result.stats.progress;
            document.getElementById('stat-extensions').textContent = result.stats.extensions;
            document.getElementById('stat-outputs').textContent = result.stats.outputs;
            document.getElementById('stat-completions').textContent = result.stats.completions;
            document.getElementById('stat-collaborations').textContent = result.stats.collaborations || 0;
        }
    } catch (error) {
        console.error('Error refreshing stats:', error);
    }
}

// Refresh stats every 60 seconds
setInterval(refreshStats, 60000);
</script>
