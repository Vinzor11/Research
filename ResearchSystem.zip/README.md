# Research Management System - Setup Guide

This is a PHP-based Research Management System for Eastern Samar State University. Follow these steps to set up and run the system on your local device.

## Prerequisites

Before you begin, ensure you have the following installed:

1. **PHP 7.4 or higher** (with extensions: mysqli, mbstring, curl)
2. **MySQL 5.7+ or MariaDB 10.2+**
3. **Web Server** (choose one):
   - Apache with mod_rewrite enabled
   - Nginx
   - PHP Built-in Server (for development)

## Step 1: Database Setup

1. **Create a MySQL database:**
   ```sql
   CREATE DATABASE research_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. **Configure database connection:**
   - Copy `db.example.php` to `db.php`
   - Edit `db.php` and update with your database credentials:
   ```php
   $host = 'localhost';
   $user = 'your_db_username';
   $pass = 'your_db_password';
   $db   = 'research_management_system';
   ```

## Step 2: Configuration Setup

1. **Copy configuration template:**
   ```bash
   copy config.example.php config.php
   ```

2. **Edit `config.php`:**
   - Update OAuth settings if you plan to use SSO (Single Sign-On)
   - For local development without SSO, you can leave the default values or disable SSO

## Step 3: Set Up Upload Directory

1. **Run the setup script** (via browser):
   - Start your web server
   - Navigate to: `http://localhost/Research_Tracking_System/setup_uploads.php`
   - This will create the `uploads/research_outputs/` directory with proper permissions

   **OR manually create directories:**
   ```bash
   mkdir uploads
   mkdir uploads/research_outputs
   chmod 755 uploads uploads/research_outputs
   ```

## Step 4: Database Setup

1. **Create the database** (if not exists):
   ```sql
   CREATE DATABASE IF NOT EXISTS research_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   USE research_management_system;
   ```

2. **Import the schema and default data:**
   - Import `research_management_system.sql` (phpMyAdmin, MySQL CLI, or your DB tool).
   - This creates all tables (users, oauth_tokens, oauth_settings, faculty_researchers, etc.) and inserts a default admin user.

3. **Default admin (login without SSO):**
   - Username: `admin`
   - Password: `admin`
   - Change this password after first login.

## Step 5: Start the Web Server

### Option A: Using PHP Built-in Server (Easiest for Development)

```bash
cd C:\Users\arvin\Research\Research_Tracking_System
php -S localhost:8000
```

Then access the system at: `http://localhost:8000`

### Option B: Using XAMPP/WAMP/MAMP

1. **XAMPP (Windows):**
   - Install XAMPP from https://www.apachefriends.org/
   - Copy your project folder to `C:\xampp\htdocs\Research_Tracking_System`
   - Start Apache and MySQL from XAMPP Control Panel
   - Access: `http://localhost/Research_Tracking_System`

2. **WAMP (Windows):**
   - Install WAMP from https://www.wampserver.com/
   - Copy your project to `C:\wamp64\www\Research_Tracking_System`
   - Start WAMP services
   - Access: `http://localhost/Research_Tracking_System`

3. **MAMP (Mac):**
   - Install MAMP from https://www.mamp.info/
   - Copy your project to `/Applications/MAMP/htdocs/Research_Tracking_System`
   - Start MAMP services
   - Access: `http://localhost:8888/Research_Tracking_System`

### Option C: Using Apache/Nginx (Production)

Configure your web server to point to the project directory and set up virtual hosts.

## Step 6: Access the System

1. **Open your browser** and navigate to:
   - `http://localhost:8000/login.php` (if using PHP built-in server)
   - `http://localhost/Research_Tracking_System/login.php` (if using XAMPP/WAMP)

2. **Login with default credentials:**
   - Username: `admin`
   - Password: `admin`
   - **⚠️ IMPORTANT: Change this password immediately after first login!**

## Step 7: Post-Installation Tasks

1. **Change the admin password** (via the system or directly in database)
2. **Create additional users** as needed
3. **Configure OAuth/SSO** if you plan to integrate with HR system
4. **Review and adjust** configuration settings in `config.php`

## Troubleshooting

### Database Connection Errors
- Verify MySQL service is running
- Check database credentials in `db.php`
- Ensure database exists and user has proper permissions

### Permission Errors (File Uploads)
- Run `setup_uploads.php` to fix directory permissions
- On Windows, ensure the web server has write permissions to the `uploads` folder
- On Linux/Mac, use: `chmod -R 755 uploads`

### Session Errors
- Ensure PHP sessions are enabled
- Check `php.ini` for `session.save_path` configuration
- Verify write permissions for session directory

### OAuth/SSO Not Working
- SSO is optional - you can use regular login without it
- To disable SSO, ensure `OAUTH_CLIENT_ID` and `OAUTH_CLIENT_SECRET` are empty in `config.php`

## File Structure

```
Research_Tracking_System/
├── config.php          # OAuth/SSO configuration (create from config.example.php)
├── db.php              # Database configuration (create from db.example.php)
├── uploads/            # File uploads directory (created by setup_uploads.php)
│   └── research_outputs/
├── index.php           # Homepage (requires login)
├── login.php           # Login page
├── facultyresearcher.php    # Faculty management
├── studentresearcher.php    # Student management
└── ...                 # Other system files
```

## Security Notes

1. **Never commit** `db.php` or `config.php` to version control
2. **Change default passwords** immediately (default admin/admin)
3. **Use HTTPS** in production environments
5. **Restrict file permissions** appropriately

## Support

For issues or questions, refer to the system documentation or contact your system administrator.

---

**System Version:** Research Management System v1.0  
**Institution:** Eastern Samar State University
