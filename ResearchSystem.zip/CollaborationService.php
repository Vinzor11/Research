<?php
/**
 * CollaborationService.php
 * 
 * Core service class for Collaboration Management in the Research Management System.
 * 
 * DESIGN PRINCIPLES:
 * - Only collaboration REQUESTS (requiring approval) appear in Work Queue
 * - Collaboration RECORDS (informational) stay exclusively in My Projects
 * - Clear separation between actionable and informational items
 * - Immutable audit trail for all actions
 * 
 * @version 1.0
 * @date 2026-02-06
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/WorkflowAuditLogger.php';

class CollaborationService {
    private $conn;
    private $auditLogger;
    private $userId;
    private $userRole;
    private $employeeId;
    private $coordinatorTypes = [];
    
    // Status Constants
    const STATUS_DRAFT = 'draft';
    const STATUS_SUBMITTED = 'submitted';
    const STATUS_UNDER_COORDINATOR_REVIEW = 'under_coordinator_review';
    const STATUS_RETURNED_FOR_REVISION = 'returned_for_revision';
    const STATUS_ENDORSED = 'endorsed';
    const STATUS_UNDER_RO_REVIEW = 'under_ro_review';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    
    // Category Constants
    const CATEGORY_REQUEST = 'request';
    const CATEGORY_RECORD = 'record';
    
    // Handler Types
    const HANDLER_RESEARCHER = 'researcher';
    const HANDLER_COORDINATOR = 'coordinator';
    const HANDLER_RESEARCH_OFFICE = 'research_office';
    
    /**
     * Constructor
     */
    public function __construct($conn) {
        $this->conn = $conn;
        $this->auditLogger = new WorkflowAuditLogger($conn);
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? 'researcher';
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        
        $this->loadCoordinatorTypes();
    }
    
    /**
     * Load coordinator types for current user
     */
    private function loadCoordinatorTypes() {
        if (!$this->employeeId || $this->userRole !== 'coordinator') {
            return;
        }
        
        try {
            $stmt = $this->conn->prepare("
                SELECT coordinator_type FROM coordinator_assignments 
                WHERE employee_id = ? AND status = 'active'
            ");
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $this->coordinatorTypes[] = $row['coordinator_type'];
            }
            $stmt->close();
        } catch (Exception $e) {
            error_log("CollaborationService: Failed to load coordinator types: " . $e->getMessage());
        }
    }
    
    // ========================================
    // COLLABORATION TYPE METHODS
    // ========================================
    
    /**
     * Get all active collaboration types
     */
    public function getCollaborationTypes($category = null) {
        $sql = "SELECT * FROM collaboration_types WHERE is_active = 1";
        if ($category) {
            $sql .= " AND category = '" . $this->conn->real_escape_string($category) . "'";
        }
        $sql .= " ORDER BY display_order, type_name";
        
        $result = $this->conn->query($sql);
        $types = [];
        while ($row = $result->fetch_assoc()) {
            $types[] = $row;
        }
        return $types;
    }
    
    /**
     * Get collaboration type by ID
     */
    public function getCollaborationType($typeId) {
        $stmt = $this->conn->prepare("SELECT * FROM collaboration_types WHERE id = ?");
        $stmt->bind_param("i", $typeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // ========================================
    // COLLABORATION CRUD METHODS
    // ========================================
    
    /**
     * Create a new collaboration (request or record)
     */
    public function createCollaboration($data) {
        try {
            $this->conn->begin_transaction();
            
            // Get the collaboration type to determine category
            $collabType = $this->getCollaborationType($data['collaboration_type_id']);
            if (!$collabType) {
                return ['success' => false, 'error' => 'Invalid collaboration type'];
            }
            
            $category = $collabType['category'];
            
            // Determine researcher info
            $researcherInfo = $this->getResearcherInfo();
            if (!$researcherInfo) {
                return ['success' => false, 'error' => 'Researcher profile not found'];
            }
            
            // Prepare all values
            $projectId = !empty($data['project_id']) ? (int)$data['project_id'] : null;
            $researcherType = $researcherInfo['type'];
            $researcherId = (int)$researcherInfo['id'];
            $researcherUserId = (int)$this->userId;
            $unitId = $researcherInfo['unit_id'] ?? '';
            $unitName = $researcherInfo['unit_name'] ?? '';
            $typeId = (int)$data['collaboration_type_id'];
            $partnerName = $data['partner_name'] ?? '';
            $partnerType = $data['partner_type'] ?? 'other';
            $partnerCountry = $data['partner_country'] ?? 'Philippines';
            $partnerAddress = $data['partner_address'] ?? '';
            $partnerContact = $data['partner_contact_person'] ?? '';
            $partnerEmail = $data['partner_contact_email'] ?? '';
            $partnerPhone = $data['partner_contact_phone'] ?? '';
            $title = $data['title'] ?? '';
            $purpose = $data['purpose'] ?? '';
            $scopeOfWork = $data['scope_of_work'] ?? '';
            $expectedOutcomes = $data['expected_outcomes'] ?? '';
            $startDate = !empty($data['start_date']) ? $data['start_date'] : null;
            $endDate = !empty($data['end_date']) ? $data['end_date'] : null;
            $isOngoing = !empty($data['is_ongoing']) ? 1 : 0;
            $hasFinancial = !empty($data['has_financial_component']) ? 1 : 0;
            $financialDetails = $data['financial_details'] ?? '';
            $amount = !empty($data['amount_involved']) ? (float)$data['amount_involved'] : 0.00;
            $status = self::STATUS_DRAFT;
            $recordStatus = 'active';
            $isQueueItem = 0;
            $handlerType = self::HANDLER_RESEARCHER;
            $handlerId = (int)$this->userId;
            $createdBy = (int)$this->userId;
            
            // Use simple direct INSERT - let MySQL handle NULL
            $sql = "INSERT INTO project_collaborations (
                project_id, researcher_type, researcher_id, researcher_user_id,
                researcher_unit_id, researcher_unit_name, collaboration_type_id, collaboration_category,
                partner_name, partner_type, partner_country, partner_address, 
                partner_contact_person, partner_contact_email, partner_contact_phone,
                title, purpose, scope_of_work, expected_outcomes,
                start_date, end_date, is_ongoing, has_financial_component, 
                financial_details, amount_involved, status, record_status, 
                is_queue_item, current_handler_type, current_handler_id, created_by
            ) VALUES (
                " . ($projectId !== null ? $projectId : "NULL") . ",
                ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?
            )";
            
            $stmt = $this->conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $this->conn->error);
            }
            
            // 30 parameters (project_id handled directly in SQL)
            $stmt->bind_param(
                "siississssssssssssssiisd" . "ssisii",
                $researcherType, $researcherId, $researcherUserId,
                $unitId, $unitName, $typeId, $category,
                $partnerName, $partnerType, $partnerCountry, $partnerAddress,
                $partnerContact, $partnerEmail, $partnerPhone,
                $title, $purpose, $scopeOfWork, $expectedOutcomes,
                $startDate, $endDate, $isOngoing, $hasFinancial,
                $financialDetails, $amount, $status, $recordStatus,
                $isQueueItem, $handlerType, $handlerId, $createdBy
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create collaboration: " . $stmt->error);
            }
            
            $collaborationId = $this->conn->insert_id;
            $stmt->close();
            
            // Log creation
            $this->logAction($collaborationId, $category === self::CATEGORY_REQUEST ? 'created' : 'record_logged', [
                'comments' => "Created new collaboration " . ($category === self::CATEGORY_REQUEST ? 'request' : 'record')
            ]);
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'collaboration_id' => $collaborationId,
                'category' => $category,
                'message' => $category === self::CATEGORY_REQUEST 
                    ? 'Collaboration request created as draft' 
                    : 'Collaboration record logged successfully'
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("CollaborationService::createCollaboration error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Update a collaboration (draft or record only)
     */
    public function updateCollaboration($collaborationId, $data) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            // Check ownership for requests
            if ($collab['collaboration_category'] === self::CATEGORY_REQUEST) {
                if (!in_array($collab['status'], [self::STATUS_DRAFT, self::STATUS_RETURNED_FOR_REVISION])) {
                    return ['success' => false, 'error' => 'Cannot edit collaboration in current status'];
                }
                if ($collab['created_by'] != $this->userId && $this->userRole !== 'admin') {
                    return ['success' => false, 'error' => 'Not authorized to edit this collaboration'];
                }
            }
            
            // Build update query dynamically
            $updateFields = [];
            $params = [];
            $types = "";
            
            $allowedFields = [
                'partner_name' => 's', 'partner_type' => 's', 'partner_country' => 's',
                'partner_address' => 's', 'partner_contact_person' => 's', 
                'partner_contact_email' => 's', 'partner_contact_phone' => 's',
                'title' => 's', 'purpose' => 's', 'scope_of_work' => 's', 'expected_outcomes' => 's',
                'start_date' => 's', 'end_date' => 's', 'is_ongoing' => 'i',
                'has_financial_component' => 'i', 'financial_details' => 's', 'amount_involved' => 'd',
                'record_status' => 's'
            ];
            
            foreach ($allowedFields as $field => $type) {
                if (array_key_exists($field, $data)) {
                    $updateFields[] = "$field = ?";
                    $params[] = $data[$field];
                    $types .= $type;
                }
            }
            
            if (empty($updateFields)) {
                return ['success' => false, 'error' => 'No fields to update'];
            }
            
            $sql = "UPDATE project_collaborations SET " . implode(", ", $updateFields) . " WHERE id = ?";
            $params[] = $collaborationId;
            $types .= "i";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to update: " . $stmt->error);
            }
            $stmt->close();
            
            // Log update
            $this->logAction($collaborationId, $collab['collaboration_category'] === self::CATEGORY_REQUEST ? 'updated' : 'record_updated', [
                'comments' => 'Collaboration updated'
            ]);
            
            return ['success' => true, 'message' => 'Collaboration updated successfully'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::updateCollaboration error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get a single collaboration by ID
     */
    public function getCollaboration($id) {
        $stmt = $this->conn->prepare("
            SELECT pc.*,
                   ct.type_code, ct.type_name, ct.category as type_category,
                   ct.requires_moa_document, ct.icon_class, ct.color_class,
                   rs.title as project_title, rs.reference_number as project_reference
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            LEFT JOIN research_submissions rs ON pc.project_id = rs.id
            WHERE pc.id = ?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $collab = $result->fetch_assoc();
        $stmt->close();
        
        if ($collab) {
            // Add computed fields
            $collab['status_label'] = $this->getStatusLabel($collab['status']);
            $collab['status_class'] = $this->getStatusClass($collab['status']);
            $collab['can_edit'] = $this->canEdit($collab);
            $collab['can_submit'] = $this->canSubmit($collab);
            $collab['available_actions'] = $this->getAvailableActions($collab);
        }
        
        return $collab;
    }
    
    /**
     * Get collaborations for a researcher
     */
    public function getResearcherCollaborations($filters = [], $page = 1, $perPage = 20) {
        $researcherInfo = $this->getResearcherInfo();
        if (!$researcherInfo) {
            return ['data' => [], 'pagination' => $this->emptyPagination($page, $perPage)];
        }
        
        $where = ["pc.researcher_id = ? AND pc.researcher_type = ?"];
        $params = [$researcherInfo['id'], $researcherInfo['type']];
        $types = "is";
        
        // Apply filters
        if (!empty($filters['category'])) {
            $where[] = "pc.collaboration_category = ?";
            $params[] = $filters['category'];
            $types .= "s";
        }
        
        if (!empty($filters['status'])) {
            $where[] = "pc.status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }
        
        if (!empty($filters['project_id'])) {
            $where[] = "pc.project_id = ?";
            $params[] = $filters['project_id'];
            $types .= "i";
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(pc.title LIKE ? OR pc.partner_name LIKE ? OR pc.reference_number LIKE ?)";
            $search = "%" . $filters['search'] . "%";
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= "sss";
        }
        
        $whereClause = implode(" AND ", $where);
        
        // Count total
        $countSql = "SELECT COUNT(*) as total FROM project_collaborations pc WHERE $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        $countStmt->bind_param($types, ...$params);
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Get data
        $offset = ($page - 1) * $perPage;
        $sql = "
            SELECT pc.*,
                   ct.type_code, ct.type_name, ct.category as type_category,
                   ct.icon_class, ct.color_class,
                   rs.title as project_title
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            LEFT JOIN research_submissions rs ON pc.project_id = rs.id
            WHERE $whereClause
            ORDER BY pc.updated_at DESC
            LIMIT ?, ?
        ";
        
        $params[] = $offset;
        $params[] = $perPage;
        $types .= "ii";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $collaborations = [];
        while ($row = $result->fetch_assoc()) {
            $row['status_label'] = $this->getStatusLabel($row['status']);
            $row['status_class'] = $this->getStatusClass($row['status']);
            $collaborations[] = $row;
        }
        $stmt->close();
        
        return [
            'data' => $collaborations,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => ceil($total / $perPage)
            ]
        ];
    }
    
    /**
     * Get collaborations for a project
     */
    public function getProjectCollaborations($projectId) {
        $stmt = $this->conn->prepare("
            SELECT pc.*,
                   ct.type_code, ct.type_name, ct.category as type_category,
                   ct.icon_class, ct.color_class
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            WHERE pc.project_id = ?
            ORDER BY pc.created_at DESC
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $collaborations = [];
        while ($row = $result->fetch_assoc()) {
            $row['status_label'] = $this->getStatusLabel($row['status']);
            $row['status_class'] = $this->getStatusClass($row['status']);
            $collaborations[] = $row;
        }
        $stmt->close();
        
        return $collaborations;
    }
    
    // ========================================
    // WORKFLOW METHODS (for Requests Only)
    // ========================================
    
    /**
     * Submit a collaboration request (draft → submitted)
     * This creates/exposes a queue item
     */
    public function submit($collaborationId) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            // Only requests can be submitted
            if ($collab['collaboration_category'] !== self::CATEGORY_REQUEST) {
                return ['success' => false, 'error' => 'Only collaboration requests can be submitted for approval'];
            }
            
            // Validate status
            if (!in_array($collab['status'], [self::STATUS_DRAFT, self::STATUS_RETURNED_FOR_REVISION])) {
                return ['success' => false, 'error' => 'Cannot submit from current status'];
            }
            
            // Validate ownership
            if ($collab['created_by'] != $this->userId && $this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Not authorized to submit this collaboration'];
            }
            
            // Validate required fields
            $validation = $this->validateForSubmission($collab);
            if (!$validation['valid']) {
                return ['success' => false, 'error' => 'Validation failed', 'errors' => $validation['errors']];
            }
            
            $this->conn->begin_transaction();
            
            // Find coordinator
            $coordinator = $this->findCoordinator($collab);
            if (!$coordinator) {
                $this->conn->rollback();
                return ['success' => false, 'error' => 'No coordinator found for your unit. Please contact the Research Office.'];
            }
            
            $previousStatus = $collab['status'];
            $isRevision = $previousStatus === self::STATUS_RETURNED_FOR_REVISION;
            
            // Generate reference number if first submission
            $referenceNumber = $collab['reference_number'];
            if (!$referenceNumber) {
                $referenceNumber = $this->generateReferenceNumber();
            }
            
            // Update collaboration
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    reference_number = ?,
                    status = ?,
                    is_queue_item = 1,
                    current_handler_type = ?,
                    current_handler_id = ?,
                    assigned_coordinator_id = ?,
                    assigned_coordinator_employee_id = ?,
                    submitted_at = IF(submitted_at IS NULL, NOW(), submitted_at),
                    revision_count = IF(? = 1, revision_count + 1, revision_count),
                    last_revision_at = IF(? = 1, NOW(), last_revision_at),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_SUBMITTED;
            $handlerType = self::HANDLER_COORDINATOR;
            $isRevisionInt = $isRevision ? 1 : 0;
            
            $stmt->bind_param(
                "sssisisii",
                $referenceNumber,
                $newStatus,
                $handlerType,
                $coordinator['user_id'],
                $coordinator['user_id'],
                $coordinator['employee_id'],
                $isRevisionInt,
                $isRevisionInt,
                $collaborationId
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to submit: " . $stmt->error);
            }
            $stmt->close();
            
            // Log submission
            $this->logAction($collaborationId, $isRevision ? 'revision_submitted' : 'submitted', [
                'previous_status' => $previousStatus,
                'new_status' => $newStatus,
                'comments' => $isRevision ? 'Revision submitted' : 'Collaboration request submitted for review'
            ]);
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'reference_number' => $referenceNumber,
                'message' => 'Collaboration request submitted successfully'
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("CollaborationService::submit error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start review (submitted → under_coordinator_review)
     */
    public function startReview($collaborationId) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if ($collab['status'] !== self::STATUS_SUBMITTED) {
                return ['success' => false, 'error' => 'Cannot start review from current status'];
            }
            
            // Verify user is assigned coordinator
            if ($this->userRole !== 'coordinator' && $this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Not authorized'];
            }
            
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    coordinator_received_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_UNDER_COORDINATOR_REVIEW;
            $stmt->bind_param("si", $newStatus, $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to start review: " . $stmt->error);
            }
            $stmt->close();
            
            $this->logAction($collaborationId, 'coordinator_review_started', [
                'previous_status' => self::STATUS_SUBMITTED,
                'new_status' => $newStatus
            ]);
            
            return ['success' => true, 'message' => 'Review started'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::startReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start Research Office review (endorsed → under_ro_review)
     */
    public function startROReview($collaborationId) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if ($collab['status'] !== self::STATUS_ENDORSED) {
                return ['success' => false, 'error' => 'Cannot start review from current status'];
            }
            
            // Verify user is Research Office admin
            if ($this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Only Research Office Admin can start review'];
            }
            
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    assigned_ro_admin_id = ?,
                    ro_received_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_UNDER_RO_REVIEW;
            $stmt->bind_param("sii", $newStatus, $this->userId, $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to start RO review: " . $stmt->error);
            }
            $stmt->close();
            
            $this->logAction($collaborationId, 'ro_review_started', [
                'previous_status' => self::STATUS_ENDORSED,
                'new_status' => $newStatus
            ]);
            
            return ['success' => true, 'message' => 'Research Office review started'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::startROReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Endorse collaboration (coordinator → research office)
     */
    public function endorse($collaborationId, $endorsementData) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if (!in_array($collab['status'], [self::STATUS_SUBMITTED, self::STATUS_UNDER_COORDINATOR_REVIEW])) {
                return ['success' => false, 'error' => 'Cannot endorse from current status'];
            }
            
            if ($this->userRole !== 'coordinator' && $this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Not authorized to endorse'];
            }
            
            $this->conn->begin_transaction();
            
            // Update collaboration
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    current_handler_type = ?,
                    coordinator_endorsed_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_ENDORSED;
            $handlerType = self::HANDLER_RESEARCH_OFFICE;
            $stmt->bind_param("ssi", $newStatus, $handlerType, $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to endorse: " . $stmt->error);
            }
            $stmt->close();
            
            // Save endorsement summary
            $stmt = $this->conn->prepare("
                INSERT INTO collaboration_endorsement_summary 
                    (collaboration_id, coordinator_id, coordinator_employee_id,
                     partner_verified, documents_verified, scope_verified, compliance_verified,
                     endorsement_notes, endorsed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE
                    partner_verified = VALUES(partner_verified),
                    documents_verified = VALUES(documents_verified),
                    scope_verified = VALUES(scope_verified),
                    compliance_verified = VALUES(compliance_verified),
                    endorsement_notes = VALUES(endorsement_notes),
                    endorsed_at = NOW()
            ");
            
            $partnerVerified = $endorsementData['partner_verified'] ?? 0;
            $docsVerified = $endorsementData['documents_verified'] ?? 0;
            $scopeVerified = $endorsementData['scope_verified'] ?? 0;
            $complianceVerified = $endorsementData['compliance_verified'] ?? 0;
            $notes = $endorsementData['endorsement_notes'] ?? null;
            
            $stmt->bind_param(
                "iisiiiis",
                $collaborationId, $this->userId, $this->employeeId,
                $partnerVerified, $docsVerified, $scopeVerified, $complianceVerified,
                $notes
            );
            $stmt->execute();
            $stmt->close();
            
            $this->logAction($collaborationId, 'endorsed', [
                'previous_status' => $collab['status'],
                'new_status' => $newStatus,
                'comments' => $notes
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Collaboration endorsed and forwarded to Research Office'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("CollaborationService::endorse error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return for revision (coordinator → researcher)
     */
    public function returnForRevision($collaborationId, $reason) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if (!in_array($collab['status'], [self::STATUS_SUBMITTED, self::STATUS_UNDER_COORDINATOR_REVIEW])) {
                return ['success' => false, 'error' => 'Cannot return from current status'];
            }
            
            if ($this->userRole !== 'coordinator' && $this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Not authorized'];
            }
            
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    current_handler_type = ?,
                    current_handler_id = ?,
                    is_queue_item = 0,
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_RETURNED_FOR_REVISION;
            $handlerType = self::HANDLER_RESEARCHER;
            $stmt->bind_param("ssii", $newStatus, $handlerType, $collab['created_by'], $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to return: " . $stmt->error);
            }
            $stmt->close();
            
            // Add comment
            $this->addComment($collaborationId, 'revision_request', $reason, false);
            
            $this->logAction($collaborationId, 'returned_for_revision', [
                'previous_status' => $collab['status'],
                'new_status' => $newStatus,
                'return_reason' => $reason
            ]);
            
            return ['success' => true, 'message' => 'Collaboration returned for revision'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::returnForRevision error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve collaboration (research office)
     */
    public function approve($collaborationId, $remarks = null) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if (!in_array($collab['status'], [self::STATUS_ENDORSED, self::STATUS_UNDER_RO_REVIEW])) {
                return ['success' => false, 'error' => 'Cannot approve from current status'];
            }
            
            if ($this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Only Research Office Admin can approve'];
            }
            
            // Check if MOA required but not uploaded
            if ($collab['requires_moa_document'] && empty($collab['moa_document_path'])) {
                return ['success' => false, 'error' => 'MOA/MOU document is required before approval'];
            }
            
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    is_queue_item = 0,
                    assigned_ro_admin_id = ?,
                    approval_remarks = ?,
                    decision_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_APPROVED;
            $stmt->bind_param("sisi", $newStatus, $this->userId, $remarks, $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to approve: " . $stmt->error);
            }
            $stmt->close();
            
            $this->logAction($collaborationId, 'approved', [
                'previous_status' => $collab['status'],
                'new_status' => $newStatus,
                'comments' => $remarks
            ]);
            
            return ['success' => true, 'message' => 'Collaboration approved successfully'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::approve error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Reject collaboration (research office)
     */
    public function reject($collaborationId, $reason) {
        try {
            $collab = $this->getCollaboration($collaborationId);
            if (!$collab) {
                return ['success' => false, 'error' => 'Collaboration not found'];
            }
            
            if (!in_array($collab['status'], [self::STATUS_ENDORSED, self::STATUS_UNDER_RO_REVIEW])) {
                return ['success' => false, 'error' => 'Cannot reject from current status'];
            }
            
            if ($this->userRole !== 'admin') {
                return ['success' => false, 'error' => 'Only Research Office Admin can reject'];
            }
            
            $stmt = $this->conn->prepare("
                UPDATE project_collaborations SET
                    status = ?,
                    is_queue_item = 0,
                    assigned_ro_admin_id = ?,
                    rejection_reason = ?,
                    decision_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_REJECTED;
            $stmt->bind_param("sisi", $newStatus, $this->userId, $reason, $collaborationId);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to reject: " . $stmt->error);
            }
            $stmt->close();
            
            $this->logAction($collaborationId, 'rejected', [
                'previous_status' => $collab['status'],
                'new_status' => $newStatus,
                'comments' => $reason
            ]);
            
            return ['success' => true, 'message' => 'Collaboration rejected'];
            
        } catch (Exception $e) {
            error_log("CollaborationService::reject error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // QUEUE METHODS
    // ========================================
    
    /**
     * Get collaboration requests for work queue (Coordinator view)
     */
    public function getCoordinatorQueueItems($filters = []) {
        if (empty($this->coordinatorTypes)) {
            return [];
        }
        
        $types = "'" . implode("','", $this->coordinatorTypes) . "'";
        
        $statusCondition = "pc.status IN ('submitted', 'under_coordinator_review')";
        
        $sql = "
            SELECT 
                pc.id,
                pc.reference_number,
                pc.title,
                pc.partner_name,
                pc.status,
                pc.researcher_type,
                pc.created_by as requester_id,
                pc.submitted_at,
                pc.created_at,
                ct.type_name as collaboration_type,
                ct.icon_class,
                ct.color_class,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            LEFT JOIN faculty_researchers fr ON pc.researcher_id = fr.id AND pc.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON pc.researcher_id = sr.id AND pc.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON pc.researcher_id = pr.id AND pc.researcher_type = 'personnel'
            LEFT JOIN users u ON pc.created_by = u.id
            WHERE {$statusCondition}
            AND pc.is_queue_item = 1
            AND pc.researcher_type IN ({$types})
        ";
        
        // Apply filters
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (pc.reference_number LIKE '%{$search}%' OR pc.title LIKE '%{$search}%' OR pc.partner_name LIKE '%{$search}%')";
        }
        
        $sql .= " ORDER BY pc.submitted_at DESC";
        
        $result = $this->conn->query($sql);
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $this->normalizeQueueItem($row);
        }
        
        return $items;
    }
    
    /**
     * Get collaboration requests for work queue (Admin view)
     */
    public function getAdminQueueItems($filters = []) {
        $statusCondition = "pc.status IN ('endorsed', 'under_ro_review')";
        
        $sql = "
            SELECT 
                pc.id,
                pc.reference_number,
                pc.title,
                pc.partner_name,
                pc.status,
                pc.researcher_type,
                pc.created_by as requester_id,
                pc.submitted_at,
                pc.coordinator_endorsed_at,
                pc.created_at,
                ct.type_name as collaboration_type,
                ct.icon_class,
                ct.color_class,
                COALESCE(
                    CONCAT(fr.last_name, ', ', fr.first_name),
                    CONCAT(sr.last_name, ', ', sr.first_name),
                    CONCAT(pr.last_name, ', ', pr.first_name),
                    u.fullname
                ) as requester_name,
                COALESCE(fr.home_unit, sr.department, pr.office_unit) as unit_name
            FROM project_collaborations pc
            JOIN collaboration_types ct ON pc.collaboration_type_id = ct.id
            LEFT JOIN faculty_researchers fr ON pc.researcher_id = fr.id AND pc.researcher_type = 'faculty'
            LEFT JOIN student_researchers sr ON pc.researcher_id = sr.id AND pc.researcher_type = 'student'
            LEFT JOIN personnel_researchers pr ON pc.researcher_id = pr.id AND pc.researcher_type = 'personnel'
            LEFT JOIN users u ON pc.created_by = u.id
            WHERE {$statusCondition}
            AND pc.is_queue_item = 1
        ";
        
        // Apply filters
        if (!empty($filters['search'])) {
            $search = $this->conn->real_escape_string($filters['search']);
            $sql .= " AND (pc.reference_number LIKE '%{$search}%' OR pc.title LIKE '%{$search}%' OR pc.partner_name LIKE '%{$search}%')";
        }
        
        $sql .= " ORDER BY COALESCE(pc.coordinator_endorsed_at, pc.submitted_at) DESC";
        
        $result = $this->conn->query($sql);
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $this->normalizeQueueItem($row);
        }
        
        return $items;
    }
    
    /**
     * Get queue statistics for collaborations
     */
    public function getQueueStats() {
        $stats = ['coordinator' => 0, 'admin' => 0];
        
        // Coordinator stats
        if ($this->userRole === 'coordinator' && !empty($this->coordinatorTypes)) {
            $types = "'" . implode("','", $this->coordinatorTypes) . "'";
            $result = $this->conn->query("
                SELECT COUNT(*) as c FROM project_collaborations 
                WHERE status IN ('submitted', 'under_coordinator_review') 
                AND is_queue_item = 1 
                AND researcher_type IN ({$types})
            ");
            $stats['coordinator'] = $result->fetch_assoc()['c'];
        }
        
        // Admin stats
        if ($this->userRole === 'admin') {
            $result = $this->conn->query("
                SELECT COUNT(*) as c FROM project_collaborations 
                WHERE status IN ('endorsed', 'under_ro_review') 
                AND is_queue_item = 1
            ");
            $stats['admin'] = $result->fetch_assoc()['c'];
        }
        
        return $stats;
    }
    
    /**
     * Normalize queue item for display
     */
    private function normalizeQueueItem($row) {
        return [
            'queue_id' => "collaboration_{$row['id']}",
            'item_type' => 'collaboration',
            'source_table' => 'project_collaborations',
            'source_id' => $row['id'],
            'reference_number' => $row['reference_number'],
            'project_id' => null,
            'project_title' => $row['title'],
            'item_subtitle' => $row['collaboration_type'] . ' - ' . $row['partner_name'],
            'requester_id' => $row['requester_id'],
            'requester_name' => $row['requester_name'] ?? 'Unknown',
            'researcher_type' => $row['researcher_type'],
            'unit_name' => $row['unit_name'] ?? 'Unknown Unit',
            'status' => $row['status'],
            'status_label' => $this->getStatusLabel($row['status']),
            'status_class' => $this->getStatusClass($row['status']),
            'assigned_role' => $this->getAssignedRole($row['status']),
            'submitted_at' => $row['submitted_at'] ?? $row['created_at'],
            'review_url' => "collaboration_view.php?id={$row['id']}",
            'type_label' => 'Collaboration',
            'type_icon' => $row['icon_class'] ?? 'fa-handshake',
            'type_color' => 'type-collaboration'
        ];
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get researcher info for current user
     */
    private function getResearcherInfo() {
        // Try faculty - only use user_id to find user's own profile
        $stmt = $this->conn->prepare("
            SELECT id, 'faculty' as type, home_unit as unit_name, 
                   (SELECT unit_id FROM coordinator_scopes cs WHERE cs.unit_name COLLATE utf8mb4_general_ci = fr.home_unit COLLATE utf8mb4_general_ci LIMIT 1) as unit_id
            FROM faculty_researchers fr 
            WHERE user_id = ?
            LIMIT 1
        ");
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $stmt->close();
            return $row;
        }
        $stmt->close();
        
        // Try student - students use created_by (they don't have user accounts)
        $stmt = $this->conn->prepare("
            SELECT id, 'student' as type, department as unit_name, department as unit_id
            FROM student_researchers WHERE created_by = ? LIMIT 1
        ");
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $stmt->close();
            return $row;
        }
        $stmt->close();
        
        // Try personnel
        $stmt = $this->conn->prepare("
            SELECT id, 'personnel' as type, office_unit as unit_name, office_unit as unit_id
            FROM personnel_researchers WHERE user_id = ? LIMIT 1
        ");
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $stmt->close();
            return $row;
        }
        $stmt->close();
        
        return null;
    }
    
    /**
     * Find coordinator for routing
     */
    private function findCoordinator($collab) {
        $researcherType = $collab['researcher_type'];
        $unitName = $collab['researcher_unit_name'] ?? '';
        
        // Use COLLATE on employee_id fields to avoid collation mismatch between tables
        $researcherTypeEsc = $this->conn->real_escape_string($researcherType);
        $unitNameEsc = $this->conn->real_escape_string($unitName);
        
        // First try to find coordinator with unit scope
        $sql = "
            SELECT ca.employee_id, src.full_name, u.id as user_id
            FROM coordinator_assignments ca
            JOIN synced_research_coordinators src 
                ON ca.employee_id COLLATE utf8mb4_general_ci = src.employee_id COLLATE utf8mb4_general_ci
            LEFT JOIN users u 
                ON u.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci
            WHERE ca.coordinator_type = '$researcherTypeEsc'
            AND ca.status = 'active'
            AND (
                ca.scope_mode = 'all_units'
                OR ca.hr_unit_name = '$unitNameEsc'
            )
            LIMIT 1
        ";
        
        $result = $this->conn->query($sql);
        if (!$result) {
            throw new Exception($this->conn->error);
        }
        
        return $result->fetch_assoc();
    }
    
    /**
     * Generate reference number
     */
    private function generateReferenceNumber() {
        $year = date('Y');
        
        $result = $this->conn->query("
            SELECT COUNT(*) + 1 as seq FROM project_collaborations 
            WHERE YEAR(created_at) = {$year} AND reference_number IS NOT NULL
        ");
        $seq = $result->fetch_assoc()['seq'];
        
        return sprintf("COL-%s-%04d", $year, $seq);
    }
    
    /**
     * Validate collaboration for submission
     */
    private function validateForSubmission($collab) {
        $errors = [];
        
        if (empty($collab['partner_name'])) {
            $errors[] = 'Partner name is required';
        }
        if (empty($collab['title'])) {
            $errors[] = 'Title is required';
        }
        if (empty($collab['purpose'])) {
            $errors[] = 'Purpose is required';
        }
        
        // Check MOA requirement
        if ($collab['requires_moa_document'] && empty($collab['moa_document_path'])) {
            $errors[] = 'MOA/MOU document is required for this collaboration type';
        }
        
        return ['valid' => empty($errors), 'errors' => $errors];
    }
    
    /**
     * Check if user can edit collaboration
     */
    private function canEdit($collab) {
        if ($collab['collaboration_category'] === self::CATEGORY_RECORD) {
            return $collab['created_by'] == $this->userId || $this->userRole === 'admin';
        }
        
        // For requests, only editable in draft or returned status
        if (!in_array($collab['status'], [self::STATUS_DRAFT, self::STATUS_RETURNED_FOR_REVISION])) {
            return false;
        }
        
        return $collab['created_by'] == $this->userId || $this->userRole === 'admin';
    }
    
    /**
     * Check if user can submit collaboration
     */
    private function canSubmit($collab) {
        if ($collab['collaboration_category'] !== self::CATEGORY_REQUEST) {
            return false;
        }
        
        if (!in_array($collab['status'], [self::STATUS_DRAFT, self::STATUS_RETURNED_FOR_REVISION])) {
            return false;
        }
        
        return $collab['created_by'] == $this->userId || $this->userRole === 'admin';
    }
    
    /**
     * Get available actions for collaboration
     */
    private function getAvailableActions($collab) {
        $actions = [];
        $category = $collab['collaboration_category'];
        $status = $collab['status'];
        
        if ($category === self::CATEGORY_RECORD) {
            // Records can only be edited/deleted
            if ($this->canEdit($collab)) {
                $actions[] = 'edit';
                $actions[] = 'delete';
            }
            return $actions;
        }
        
        // Request actions based on status and role
        switch ($status) {
            case self::STATUS_DRAFT:
            case self::STATUS_RETURNED_FOR_REVISION:
                if ($collab['created_by'] == $this->userId) {
                    $actions[] = 'edit';
                    $actions[] = 'submit';
                    if ($status === self::STATUS_DRAFT) {
                        $actions[] = 'delete';
                    }
                }
                break;
                
            case self::STATUS_SUBMITTED:
            case self::STATUS_UNDER_COORDINATOR_REVIEW:
                if ($this->userRole === 'coordinator' || $this->userRole === 'admin') {
                    if ($status === self::STATUS_SUBMITTED) {
                        $actions[] = 'start_review';
                    }
                    $actions[] = 'endorse';
                    $actions[] = 'return';
                }
                break;
                
            case self::STATUS_ENDORSED:
            case self::STATUS_UNDER_RO_REVIEW:
                if ($this->userRole === 'admin') {
                    if ($status === self::STATUS_ENDORSED) {
                        $actions[] = 'start_ro_review';
                    }
                    $actions[] = 'approve';
                    $actions[] = 'reject';
                    $actions[] = 'return_to_coordinator';
                }
                break;
        }
        
        return $actions;
    }
    
    /**
     * Get status label
     */
    private function getStatusLabel($status) {
        $labels = [
            'draft' => 'Draft',
            'submitted' => 'Pending Review',
            'under_coordinator_review' => 'Under Review',
            'returned_for_revision' => 'Returned',
            'endorsed' => 'Endorsed',
            'under_ro_review' => 'RO Review',
            'approved' => 'Approved',
            'rejected' => 'Rejected'
        ];
        return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
    }
    
    /**
     * Get status CSS class
     */
    private function getStatusClass($status) {
        $classes = [
            'draft' => 'status-draft',
            'submitted' => 'status-pending',
            'under_coordinator_review' => 'status-reviewing',
            'returned_for_revision' => 'status-returned',
            'endorsed' => 'status-endorsed',
            'under_ro_review' => 'status-reviewing',
            'approved' => 'status-approved',
            'rejected' => 'status-rejected'
        ];
        return $classes[$status] ?? 'status-default';
    }
    
    /**
     * Get assigned role for status
     */
    private function getAssignedRole($status) {
        $coordinatorStatuses = ['submitted', 'under_coordinator_review'];
        $adminStatuses = ['endorsed', 'under_ro_review'];
        
        if (in_array($status, $coordinatorStatuses)) {
            return 'coordinator';
        } elseif (in_array($status, $adminStatuses)) {
            return 'research_office';
        }
        return 'none';
    }
    
    /**
     * Add comment to collaboration
     */
    public function addComment($collaborationId, $type, $text, $isInternal = false) {
        $stmt = $this->conn->prepare("
            INSERT INTO collaboration_comments 
                (collaboration_id, comment_type, comment_text, is_internal, created_by, created_by_role, created_by_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';
        $stmt->bind_param("issisis", $collaborationId, $type, $text, $isInternal, $this->userId, $this->userRole, $fullname);
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * Get comments for collaboration
     */
    public function getComments($collaborationId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM collaboration_comments 
            WHERE collaboration_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->bind_param("i", $collaborationId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $comments = [];
        while ($row = $result->fetch_assoc()) {
            // Filter visibility based on role
            if ($row['is_internal'] && $this->userRole === 'researcher') {
                continue;
            }
            $comments[] = $row;
        }
        $stmt->close();
        
        return $comments;
    }
    
    /**
     * Log action to audit log
     */
    private function logAction($collaborationId, $actionType, $data = []) {
        $stmt = $this->conn->prepare("
            INSERT INTO collaboration_audit_log 
                (collaboration_id, action_type, previous_status, new_status,
                 performed_by, performed_by_role, performed_by_name,
                 comments, return_reason, metadata, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'System';
        $metadata = !empty($data['metadata']) ? json_encode($data['metadata']) : null;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        // Store values in variables for bind_param (can't pass expressions by reference)
        $previousStatus = $data['previous_status'] ?? null;
        $newStatus = $data['new_status'] ?? null;
        $comments = $data['comments'] ?? null;
        $returnReason = $data['return_reason'] ?? null;
        
        $stmt->bind_param(
            "isssississss",
            $collaborationId,
            $actionType,
            $previousStatus,
            $newStatus,
            $this->userId,
            $this->userRole,
            $fullname,
            $comments,
            $returnReason,
            $metadata,
            $ipAddress,
            $userAgent
        );
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * Get audit log for collaboration
     */
    public function getAuditLog($collaborationId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM collaboration_audit_log 
            WHERE collaboration_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->bind_param("i", $collaborationId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $logs = [];
        while ($row = $result->fetch_assoc()) {
            $logs[] = $row;
        }
        $stmt->close();
        
        return $logs;
    }
    
    /**
     * Empty pagination helper
     */
    private function emptyPagination($page, $perPage) {
        return [
            'total' => 0,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => 0
        ];
    }
}
