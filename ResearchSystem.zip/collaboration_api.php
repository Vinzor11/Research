<?php
/**
 * collaboration_api.php
 * 
 * REST API for Collaboration Management
 * 
 * Handles all CRUD operations, workflow actions, and searches for:
 * - Collaboration Requests (approval-based, appear in Work Queue)
 * - Collaboration Records (informational, stay in My Projects)
 * 
 * AUTHORIZATION:
 * - Researchers: Can create/update own drafts, submit requests
 * - Coordinators: Can review/endorse/return submissions in their scope
 * - Admins: Can approve/reject endorsed requests
 * 
 * @version 1.0
 * @date 2026-02-06
 */

// Start output buffering first
ob_start();

// Suppress HTML error output
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Register shutdown function to catch fatal errors - must be before headers
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        // Clear any buffered output
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        // Send JSON response
        if (!headers_sent()) {
            header('Content-Type: application/json');
        }
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'error' => 'Server error: ' . $error['message'],
            'file' => basename($error['file']),
            'line' => $error['line']
        ]);
        exit;
    }
});

// Clear any initial buffer and set headers
ob_clean();
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/CollaborationService.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required']);
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';
$employeeId = $_SESSION['employee_id'] ?? null;

// Initialize service
$collaborationService = new CollaborationService($conn);

// Get request method and action
$method = $_SERVER['REQUEST_METHOD'];
$action = null;

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'list';
} else {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        $input = $_POST;
    }
    $action = $input['action'] ?? null;
}

try {
    switch ($action) {
        // ========================================
        // READ OPERATIONS
        // ========================================
        
        case 'list':
            // Get researcher's collaborations with filters
            $filters = [
                'category' => $_GET['category'] ?? null,
                'status' => $_GET['status'] ?? null,
                'project_id' => $_GET['project_id'] ?? null,
                'search' => $_GET['q'] ?? null
            ];
            $page = max(1, (int)($_GET['page'] ?? 1));
            $perPage = min(50, max(10, (int)($_GET['per_page'] ?? 20)));
            
            $result = $collaborationService->getResearcherCollaborations($filters, $page, $perPage);
            echo json_encode(['success' => true, 'data' => $result['data'], 'pagination' => $result['pagination']]);
            break;
            
        case 'get':
            // Get single collaboration
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $collaboration = $collaborationService->getCollaboration($id);
            if (!$collaboration) {
                throw new Exception('Collaboration not found');
            }
            
            // Get comments and audit log
            $comments = $collaborationService->getComments($id);
            $auditLog = $collaborationService->getAuditLog($id);
            
            echo json_encode([
                'success' => true, 
                'data' => $collaboration,
                'comments' => $comments,
                'audit_log' => $auditLog
            ]);
            break;
            
        case 'get_types':
            // Get collaboration types (optionally filtered by category)
            $category = $_GET['category'] ?? null;
            $types = $collaborationService->getCollaborationTypes($category);
            echo json_encode(['success' => true, 'data' => $types]);
            break;
            
        case 'get_project_collaborations':
            // Get collaborations for a specific project
            $projectId = (int)($_GET['project_id'] ?? 0);
            if (!$projectId) {
                throw new Exception('Project ID required');
            }
            
            $collaborations = $collaborationService->getProjectCollaborations($projectId);
            echo json_encode(['success' => true, 'data' => $collaborations]);
            break;
            
        case 'search_collaborators':
            // Search for potential collaborators across all units
            $query = $_GET['q'] ?? '';
            $type = $_GET['type'] ?? 'all'; // faculty, student, personnel, all
            
            if (strlen($query) < 2) {
                echo json_encode(['success' => true, 'data' => []]);
                break;
            }
            
            $collaborators = searchCollaborators($conn, $query, $type);
            echo json_encode(['success' => true, 'data' => $collaborators]);
            break;
            
        case 'get_queue_items':
            // Get collaboration requests for work queue (coordinators/admins)
            if (!in_array($userRole, ['coordinator', 'admin'])) {
                throw new Exception('Not authorized');
            }
            
            $filters = [
                'search' => $_GET['q'] ?? null
            ];
            
            if ($userRole === 'admin') {
                $items = $collaborationService->getAdminQueueItems($filters);
            } else {
                $items = $collaborationService->getCoordinatorQueueItems($filters);
            }
            
            echo json_encode(['success' => true, 'data' => $items]);
            break;
            
        case 'get_stats':
            // Get collaboration statistics
            $stats = $collaborationService->getQueueStats();
            echo json_encode(['success' => true, 'stats' => $stats]);
            break;
            
        // ========================================
        // CREATE / UPDATE OPERATIONS
        // ========================================
        
        case 'create':
            // Create new collaboration (request or record)
            error_log("Collaboration API create - Received input: " . json_encode($input));
            
            $requiredFields = ['collaboration_type_id', 'partner_name', 'partner_type', 'title', 'purpose'];
            foreach ($requiredFields as $field) {
                if (empty($input[$field])) {
                    error_log("Collaboration API create - Missing required field: $field");
                    throw new Exception("Field '$field' is required");
                }
            }
            
            error_log("Collaboration API create - Calling createCollaboration");
            $result = $collaborationService->createCollaboration($input);
            error_log("Collaboration API create - Result: " . json_encode($result));
            echo json_encode($result);
            break;
            
        case 'update':
            // Update collaboration
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $result = $collaborationService->updateCollaboration($id, $input);
            echo json_encode($result);
            break;
            
        case 'delete':
            // Delete draft collaboration
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            // Get collaboration to verify ownership and status
            $collab = $collaborationService->getCollaboration($id);
            if (!$collab) {
                throw new Exception('Collaboration not found');
            }
            
            if ($collab['status'] !== 'draft') {
                throw new Exception('Only draft collaborations can be deleted');
            }
            
            if ($collab['created_by'] != $userId && $userRole !== 'admin') {
                throw new Exception('Not authorized to delete this collaboration');
            }
            
            $stmt = $conn->prepare("DELETE FROM project_collaborations WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Collaboration deleted']);
            } else {
                throw new Exception('Failed to delete collaboration');
            }
            $stmt->close();
            break;
            
        // ========================================
        // WORKFLOW ACTIONS (Requests Only)
        // ========================================
        
        case 'submit':
            // Submit collaboration request for review
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $result = $collaborationService->submit($id);
            echo json_encode($result);
            break;
            
        case 'start_review':
            // Coordinator starts reviewing (submitted → under_coordinator_review)
            if (!in_array($userRole, ['coordinator', 'admin'])) {
                throw new Exception('Not authorized');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $result = $collaborationService->startReview($id);
            echo json_encode($result);
            break;
            
        case 'start_ro_review':
            // Research Office starts reviewing (endorsed → under_ro_review)
            if ($userRole !== 'admin') {
                throw new Exception('Only Research Office Admin can start review');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $result = $collaborationService->startROReview($id);
            echo json_encode($result);
            break;
            
        case 'endorse':
            // Coordinator endorses and forwards to Research Office
            if (!in_array($userRole, ['coordinator', 'admin'])) {
                throw new Exception('Not authorized');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $endorsementData = [
                'partner_verified' => $input['partner_verified'] ?? 0,
                'documents_verified' => $input['documents_verified'] ?? 0,
                'scope_verified' => $input['scope_verified'] ?? 0,
                'compliance_verified' => $input['compliance_verified'] ?? 0,
                'endorsement_notes' => $input['endorsement_notes'] ?? null
            ];
            
            $result = $collaborationService->endorse($id, $endorsementData);
            echo json_encode($result);
            break;
            
        case 'return_for_revision':
            // Coordinator returns to researcher for revision
            if (!in_array($userRole, ['coordinator', 'admin'])) {
                throw new Exception('Not authorized');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $reason = $input['reason'] ?? '';
            if (empty($reason)) {
                throw new Exception('Revision reason is required');
            }
            
            $result = $collaborationService->returnForRevision($id, $reason);
            echo json_encode($result);
            break;
            
        case 'approve':
            // Admin approves collaboration
            if ($userRole !== 'admin') {
                throw new Exception('Only Research Office Admin can approve');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $remarks = $input['remarks'] ?? null;
            $result = $collaborationService->approve($id, $remarks);
            echo json_encode($result);
            break;
            
        case 'reject':
            // Admin rejects collaboration
            if ($userRole !== 'admin') {
                throw new Exception('Only Research Office Admin can reject');
            }
            
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $reason = $input['reason'] ?? '';
            if (empty($reason)) {
                throw new Exception('Rejection reason is required');
            }
            
            $result = $collaborationService->reject($id, $reason);
            echo json_encode($result);
            break;
            
        // ========================================
        // COMMENTS
        // ========================================
        
        case 'add_comment':
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $text = $input['comment'] ?? '';
            if (empty($text)) {
                throw new Exception('Comment text is required');
            }
            
            $type = $input['comment_type'] ?? 'general';
            $isInternal = ($input['is_internal'] ?? false) && in_array($userRole, ['coordinator', 'admin']);
            
            $collaborationService->addComment($id, $type, $text, $isInternal);
            echo json_encode(['success' => true, 'message' => 'Comment added']);
            break;
            
        // ========================================
        // DOCUMENT UPLOAD
        // ========================================
        
        case 'upload_document':
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) {
                throw new Exception('Collaboration ID required');
            }
            
            $collab = $collaborationService->getCollaboration($id);
            if (!$collab) {
                throw new Exception('Collaboration not found');
            }
            
            // Verify permission
            if ($collab['created_by'] != $userId && !in_array($userRole, ['coordinator', 'admin'])) {
                throw new Exception('Not authorized');
            }
            
            if (empty($_FILES['document'])) {
                throw new Exception('No file uploaded');
            }
            
            $file = $_FILES['document'];
            $docType = $_POST['document_type'] ?? 'supporting'; // moa or supporting
            
            // Validate file
            $allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 
                           'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            if (!in_array($file['type'], $allowedTypes)) {
                throw new Exception('Invalid file type. Allowed: PDF, DOC, DOCX, JPG, PNG');
            }
            
            $maxSize = 10 * 1024 * 1024; // 10MB
            if ($file['size'] > $maxSize) {
                throw new Exception('File too large. Maximum size: 10MB');
            }
            
            // Create upload directory
            $uploadDir = __DIR__ . '/uploads/collaborations/' . $id . '/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            // Generate unique filename
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = $docType . '_' . time() . '.' . $ext;
            $filepath = $uploadDir . $filename;
            $relativePath = 'uploads/collaborations/' . $id . '/' . $filename;
            
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                throw new Exception('Failed to save file');
            }
            
            // Update database
            if ($docType === 'moa') {
                $stmt = $conn->prepare("UPDATE project_collaborations SET moa_document_path = ? WHERE id = ?");
                $stmt->bind_param("si", $relativePath, $id);
                $stmt->execute();
                $stmt->close();
            } else {
                // Add to supporting documents JSON array
                $docs = json_decode($collab['supporting_documents'] ?? '[]', true);
                $docs[] = ['path' => $relativePath, 'name' => $file['name'], 'uploaded_at' => date('Y-m-d H:i:s')];
                $docsJson = json_encode($docs);
                
                $stmt = $conn->prepare("UPDATE project_collaborations SET supporting_documents = ? WHERE id = ?");
                $stmt->bind_param("si", $docsJson, $id);
                $stmt->execute();
                $stmt->close();
            }
            
            echo json_encode(['success' => true, 'message' => 'Document uploaded', 'path' => $relativePath]);
            break;
            
        default:
            throw new Exception("Unknown action: $action");
    }
    
} catch (Exception $e) {
    error_log("Collaboration API error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} catch (Error $e) {
    error_log("Collaboration API fatal error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}

// Flush output buffer
if (ob_get_level() > 0) {
    ob_end_flush();
}

/**
 * Search for potential collaborators across all researcher tables
 * NOTE: This searches across ALL units (no unit restrictions for collaborators)
 */
function searchCollaborators($conn, $query, $type = 'all') {
    $results = [];
    $searchTerm = '%' . $conn->real_escape_string($query) . '%';
    
    // Search faculty researchers
    if ($type === 'all' || $type === 'faculty') {
        $sql = "SELECT 
                    id, 
                    CONCAT(first_name, ' ', last_name) as name,
                    email,
                    home_unit as unit,
                    'faculty' as researcher_type,
                    'Internal' as scope_label
                FROM faculty_researchers 
                WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)
                AND status = 'active'
                LIMIT 20";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
        $stmt->close();
    }
    
    // Search student researchers
    if ($type === 'all' || $type === 'student') {
        $sql = "SELECT 
                    id,
                    CONCAT(first_name, ' ', last_name) as name,
                    email,
                    department as unit,
                    'student' as researcher_type,
                    'Internal' as scope_label
                FROM student_researchers 
                WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)
                LIMIT 20";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
        $stmt->close();
    }
    
    // Search personnel researchers
    if ($type === 'all' || $type === 'personnel') {
        $sql = "SELECT 
                    id,
                    CONCAT(first_name, ' ', last_name) as name,
                    email,
                    office_unit as unit,
                    'personnel' as researcher_type,
                    'Internal' as scope_label
                FROM personnel_researchers 
                WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)
                LIMIT 20";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
        $stmt->close();
    }
    
    // Sort by name
    usort($results, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    
    return array_slice($results, 0, 30); // Return max 30 results
}
