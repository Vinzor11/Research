<?php
/**
 * Personnel Researchers Listing Page
 * Displays non-academic/administrative personnel researchers
 */

session_start();
require 'db.php';
require 'config.php';
require_once 'spa_helper.php';

// Access control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin','coordinator'])) {
    header("Location: login.php");
    exit;
}
$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get all coordinator types and scope info for the current user from coordinator_assignments table
$userCoordinatorTypes = [];
$coordinatorScopeMode = 'own_unit';
$coordinatorHrUnitName = null;
$coordinatorSpecificUnits = [];
$coordinatorEmployeeId = null;

if ($userRole === 'coordinator') {
    // Get employee_id for current user
    $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
    $empStmt->bind_param("i", $userId);
    $empStmt->execute();
    $empResult = $empStmt->get_result();
    if ($empRow = $empResult->fetch_assoc()) {
        $coordinatorEmployeeId = $empRow['employee_id'];
        if ($coordinatorEmployeeId) {
            // Get all active coordinator types and scope info for this employee
            $typeStmt = $conn->prepare("SELECT coordinator_type, scope_mode, hr_unit_id, hr_unit_name FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'");
            $typeStmt->bind_param("s", $coordinatorEmployeeId);
            $typeStmt->execute();
            $typeResult = $typeStmt->get_result();
            while ($typeRow = $typeResult->fetch_assoc()) {
                $userCoordinatorTypes[] = $typeRow['coordinator_type'];
                // Use scope info from personnel coordinator assignment
                if ($typeRow['coordinator_type'] === 'personnel' && !empty($typeRow['scope_mode'])) {
                    $coordinatorScopeMode = $typeRow['scope_mode'];
                    $coordinatorHrUnitName = $typeRow['hr_unit_name'];
                }
            }
            $typeStmt->close();
            
            // If scope_mode is specific_units, get the specific unit names
            if ($coordinatorScopeMode === 'specific_units') {
                $scopeStmt = $conn->prepare("SELECT unit_id, unit_name, unit_type FROM coordinator_scopes WHERE employee_id = ?");
                $scopeStmt->bind_param("s", $coordinatorEmployeeId);
                $scopeStmt->execute();
                $scopeResult = $scopeStmt->get_result();
                while ($scopeRow = $scopeResult->fetch_assoc()) {
                    $coordinatorSpecificUnits[] = $scopeRow['unit_name'];
                }
                $scopeStmt->close();
            }
        }
    }
    $empStmt->close();
}

// Determine visibility based on all assigned coordinator types
$isAdmin = ($userRole === 'admin');
$showFaculty = $isAdmin || in_array('faculty', $userCoordinatorTypes);
$showStudent = $isAdmin || in_array('student', $userCoordinatorTypes);
$showPersonnel = $isAdmin || in_array('personnel', $userCoordinatorTypes);

// Check if user has personnel coordinator access (via coordinator_assignments)
if ($userRole === 'coordinator' && !in_array('personnel', $userCoordinatorTypes)) {
    header("Location: research.php");
    exit;
}

// ============================================
// DELETE HANDLER
// ============================================
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    if ($userRole !== 'admin') {
        die("Unauthorized");
    }
    $delId = (int) $_GET['delete'];
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Get personnel name for logging
        $stmt = $conn->prepare("SELECT CONCAT(last_name, ', ', first_name) as name FROM personnel_researchers WHERE id = ?");
        $stmt->bind_param("i", $delId);
        $stmt->execute();
        $result = $stmt->get_result();
        $personnelInfo = $result->fetch_assoc();
        $personnelName = $personnelInfo['name'] ?? 'Unknown';
        $stmt->close();
        
        // Delete related records first (to avoid foreign key constraint errors)
        
        // 1. Delete personnel project team members
        $conn->query("DELETE ppt FROM personnel_project_team ppt 
                     INNER JOIN personnel_projects pp ON ppt.project_id = pp.id 
                     WHERE pp.personnel_id = $delId");
        
        // 2. Delete personnel project costs
        $conn->query("DELETE ppc FROM personnel_project_costs ppc 
                     INNER JOIN personnel_projects pp ON ppc.project_id = pp.id 
                     WHERE pp.personnel_id = $delId");
        
        // 3. Delete research outputs/publications
        $conn->query("DELETE pro FROM personnel_research_outputs pro
                     INNER JOIN personnel_projects pp ON pro.project_id = pp.id
                     WHERE pp.personnel_id = $delId");
        
        // 4. Delete projects
        $conn->query("DELETE FROM personnel_projects WHERE personnel_id = $delId");
        
        // 5. Delete education records
        $conn->query("DELETE FROM personnel_education WHERE personnel_id = $delId");
        
        // 6. Finally, delete the personnel researcher
        $stmt = $conn->prepare("DELETE FROM personnel_researchers WHERE id = ?");
        $stmt->bind_param("i", $delId);
        $stmt->execute();
        $stmt->close();
        
        // Commit transaction
        $conn->commit();
        
        // Log the deletion if ActivityLogger exists
        if (file_exists('ActivityLogger.php')) {
            require_once 'ActivityLogger.php';
            $logger = new ActivityLogger($conn, $_SESSION['user_id']);
            $logger->logDelete('personnel_researchers', $delId, 
                "Deleted personnel researcher: $personnelName and all related records (projects, team, costs, outputs, education)");
        }
        
        // Redirect with success message
        header("Location: personnelresearcher.php?deleted=1");
        exit;
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        error_log("Delete personnel error: " . $e->getMessage());
        die("Error deleting personnel: " . $e->getMessage());
    }
}

// Search
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

// Build WHERE clause for user access control based on coordinator scope
$accessControl = "";
$accessParams = [];
$accessTypes = "";
$scopeWhereClause = "";

if ($userRole === 'coordinator') {
    // Build scope-based WHERE clause
    // Coordinators see: researchers they created OR researchers in units within their scope
    
    if ($coordinatorScopeMode === 'all_units') {
        // Full access to all researchers
        $accessControl = "";
    } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorSpecificUnits)) {
        // Access to researchers in specific assigned units OR created by this coordinator
        $unitPlaceholders = implode(',', array_fill(0, count($coordinatorSpecificUnits), '?'));
        $accessControl = " WHERE (pr.created_by = ? OR pr.office_unit IN ($unitPlaceholders) OR pr.department IN ($unitPlaceholders))";
        $accessParams[] = $userId;
        $accessTypes = "i";
        // Add unit names twice (once for office_unit, once for department)
        foreach ($coordinatorSpecificUnits as $unitName) {
            $accessParams[] = $unitName;
            $accessTypes .= "s";
        }
        foreach ($coordinatorSpecificUnits as $unitName) {
            $accessParams[] = $unitName;
            $accessTypes .= "s";
        }
    } elseif ($coordinatorScopeMode === 'own_unit' && !empty($coordinatorHrUnitName)) {
        // Access to researchers in own HR unit OR created by this coordinator
        $accessControl = " WHERE (pr.created_by = ? OR pr.office_unit = ? OR pr.department = ?)";
        $accessParams = [$userId, $coordinatorHrUnitName, $coordinatorHrUnitName];
        $accessTypes = "iss";
    } else {
        // Fallback: only see own created researchers
        $accessControl = " WHERE pr.created_by = ?";
        $accessParams[] = $userId;
        $accessTypes = "i";
    }
    
    // Build a simpler scope clause for statistics queries
    if ($coordinatorScopeMode === 'all_units') {
        $scopeWhereClause = "1=1";
    } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorSpecificUnits)) {
        $escapedUnits = array_map(function($u) use ($conn) { return "'" . $conn->real_escape_string($u) . "'"; }, $coordinatorSpecificUnits);
        $scopeWhereClause = "(created_by = $userId OR office_unit IN (" . implode(',', $escapedUnits) . ") OR department IN (" . implode(',', $escapedUnits) . "))";
    } elseif ($coordinatorScopeMode === 'own_unit' && !empty($coordinatorHrUnitName)) {
        $escapedUnit = $conn->real_escape_string($coordinatorHrUnitName);
        $scopeWhereClause = "(created_by = $userId OR office_unit = '$escapedUnit' OR department = '$escapedUnit')";
    } else {
        $scopeWhereClause = "created_by = $userId";
    }
}
// Admin sees all personnel researchers (no WHERE clause needed)

// Get statistics with user access control (using scope-based filtering)
if ($userRole === 'coordinator') {
    $totalPersonnel = $conn->query("SELECT COUNT(*) as c FROM personnel_researchers WHERE $scopeWhereClause")->fetch_assoc()['c'];
    $totalProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects pp 
                                   INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
                                   WHERE $scopeWhereClause")->fetch_assoc()['c'];
    $ongoingProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects pp 
                                     INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
                                     WHERE $scopeWhereClause AND pp.project_status='on-going'")->fetch_assoc()['c'];
    $completedProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects pp 
                                       INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
                                       WHERE $scopeWhereClause AND pp.project_status='completed'")->fetch_assoc()['c'];
    $syncedPersonnel = $conn->query("SELECT COUNT(*) as c FROM personnel_researchers WHERE $scopeWhereClause AND is_synced = 1")->fetch_assoc()['c'];
} else {
    // Admin sees all statistics
    $totalPersonnel = $conn->query("SELECT COUNT(*) as c FROM personnel_researchers")->fetch_assoc()['c'];
    $totalProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects")->fetch_assoc()['c'];
    $ongoingProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects WHERE project_status='on-going'")->fetch_assoc()['c'];
    $completedProjects = $conn->query("SELECT COUNT(*) as c FROM personnel_projects WHERE project_status='completed'")->fetch_assoc()['c'];
    $syncedPersonnel = $conn->query("SELECT COUNT(*) as c FROM personnel_researchers WHERE is_synced = 1")->fetch_assoc()['c'];
}

// Fetch list with project count and user access control
$sql = "SELECT 
    pr.id, 
    pr.employee_number, 
    pr.last_name, 
    pr.first_name, 
    pr.middle_name, 
    pr.position, 
    pr.employment_status, 
    pr.department,
    pr.office_unit,
    pr.sector,
    pr.email,
    pr.telephone,
    pr.mobile,
    pr.created_by,
    pr.hr_employee_id,
    pr.is_synced,
    pr.last_synced_at,
    pr.sync_status,
    COUNT(pp.id) as project_count
FROM personnel_researchers pr
LEFT JOIN personnel_projects pp ON pr.id = pp.personnel_id";

$params = [];
$types = "";

// Apply access control based on coordinator scope
$hasWhereClause = false;
if ($userRole === 'coordinator') {
    if ($coordinatorScopeMode === 'all_units') {
        // Full access to all researchers (no WHERE clause)
        $hasWhereClause = false;
    } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorSpecificUnits)) {
        // Access to researchers in specific assigned units OR created by this coordinator
        $unitPlaceholders = implode(',', array_fill(0, count($coordinatorSpecificUnits), '?'));
        $sql .= " WHERE (pr.created_by = ? OR pr.office_unit IN ($unitPlaceholders) OR pr.department IN ($unitPlaceholders))";
        $params[] = $userId;
        $types = "i";
        // Add unit names twice (once for office_unit, once for department)
        foreach ($coordinatorSpecificUnits as $unitName) {
            $params[] = $unitName;
            $types .= "s";
        }
        foreach ($coordinatorSpecificUnits as $unitName) {
            $params[] = $unitName;
            $types .= "s";
        }
        $hasWhereClause = true;
    } elseif ($coordinatorScopeMode === 'own_unit' && !empty($coordinatorHrUnitName)) {
        // Access to researchers in own HR unit OR created by this coordinator
        $sql .= " WHERE (pr.created_by = ? OR pr.office_unit = ? OR pr.department = ?)";
        $params = [$userId, $coordinatorHrUnitName, $coordinatorHrUnitName];
        $types = "iss";
        $hasWhereClause = true;
    } else {
        // Fallback: only see own created researchers
        $sql .= " WHERE pr.created_by = ?";
        $params[] = $userId;
        $types = "i";
        $hasWhereClause = true;
    }
}

// Add search filter
if ($q !== '') {
    if ($hasWhereClause) {
        $sql .= " AND (pr.employee_number LIKE ? OR pr.last_name LIKE ? OR pr.first_name LIKE ? OR pr.position LIKE ? OR pr.office_unit LIKE ? OR pr.email LIKE ? OR pr.hr_employee_id LIKE ?)";
    } else {
        $sql .= " WHERE (pr.employee_number LIKE ? OR pr.last_name LIKE ? OR pr.first_name LIKE ? OR pr.position LIKE ? OR pr.office_unit LIKE ? OR pr.email LIKE ? OR pr.hr_employee_id LIKE ?)";
    }
    $like = "%$q%";
    $params = array_merge($params, [$like,$like,$like,$like,$like,$like,$like]);
    $types .= str_repeat('s', 7);
}

$sql .= " GROUP BY pr.id ORDER BY pr.id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$personnels = $result->fetch_all(MYSQLI_ASSOC);

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Personnel Researchers</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="facultyresearcherstyle.css">
<?php else: ?>
<!-- SPA Mode: Load required styles -->
<link rel="stylesheet" href="facultyresearcherstyle.css">
<?php endif; ?>
<style>
/* ============================================
   PERSONNEL RESEARCHERS - UNIFIED DESIGN (Unit Projects Style)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.header-right {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }


/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header-left i { color: #064e1a; font-size: 18px; }

.filter-link {
    font-size: 13px;
    color: #064e1a;
    text-decoration: none;
    font-weight: 500;
}

.filter-link:hover { text-decoration: underline; }

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Add Button */
.btn-add-new {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border: none;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.btn-add-new:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}


/* Sync Status Indicators */
.sync-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

.sync-indicator.sync-recent { background: #d1fae5; color: #065f46; }
.sync-indicator.sync-needs-sync { background: #fef3c7; color: #92400e; }
.sync-indicator.sync-never { background: #fee2e2; color: #991b1b; }
.sync-indicator.sync-n-a { background: #e5e7eb; color: #6b7280; }

.btn-sync {
    padding: 8px 12px;
    background: #3b82f6;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.btn-sync:hover { background: #2563eb; transform: translateY(-1px); }
.btn-sync:disabled { opacity: 0.5; cursor: not-allowed; }

.hr-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    background: #dbeafe;
    color: #1e40af;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 600;
}

.success-message {
    background: #d1fae5;
    color: #065f46;
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-left: 4px solid #10b981;
}


/* Responsive */
@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .page-header-banner { padding: 20px; }
    .header-content { flex-direction: column; text-align: center; }
    .header-left { flex-direction: column; }
    .stats-row { flex-wrap: wrap; }
    .stat-card { min-width: calc(50% - 8px); flex: unset; }
    .filter-grid { grid-template-columns: 1fr; }
}
</style>
<?php if (!$isSpa): ?>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <?php if ($showFaculty): ?>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php endif; ?>
        <?php if ($showStudent): ?>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <?php endif; ?>
        <?php if ($showPersonnel): ?>
            <a href="personnelresearcher.php" class="active"><i class="fa fa-user-tie"></i> Personnel</a>
        <?php endif; ?>
        <?php if ($isAdmin): ?>
            <a href="users.php"><i class="fa fa-users-gear"></i> User Management</a>
            <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
<?php endif; ?>
    <div class="content">
        <!-- Page Header Banner -->
        <div class="page-header-banner">
            <div class="header-content">
                <div class="header-left">
                    <i class="fa fa-briefcase header-icon"></i>
                    <div>
                        <h1>Personnel Researchers</h1>
                        <p>Manage non-academic staff research profiles and outputs</p>
                    </div>
                </div>
                <div class="header-right">
                    <a href="personnelresearcherform.php" class="btn-add-new">
                        <i class="fa fa-cloud-download-alt"></i> Import from HR
                    </a>
                    <span class="role-badge" style="background: rgba(255,255,255,0.95); color: <?= $userRole === 'admin' ? '#065f46' : '#3730a3' ?>;">
                        <i class="fa fa-<?= $userRole === 'admin' ? 'shield-halved' : 'user-tie' ?>"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        <?= $userRole === 'admin' ? 'Admin' : 'Personnel Coordinator' ?>
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Success Message -->
        <?php if (isset($_GET['deleted'])): ?>
        <div class="success-message">
            <i class="fa fa-check-circle" style="font-size: 20px;"></i>
            <div>
                <strong>Personnel Deleted Successfully!</strong>
                <p style="margin: 0; font-size: 13px; opacity: 0.9;">The personnel researcher and all related records have been removed.</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalPersonnel ?></div>
                        <div class="label"><?= $userRole === 'coordinator' ? 'My' : 'Total' ?> Personnel Researchers</div>
                    </div>
                    <div class="icon"><i class="fa fa-briefcase"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalProjects ?></div>
                        <div class="label"><?= $userRole === 'coordinator' ? 'My' : 'Total' ?> Research Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-flask"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $ongoingProjects ?></div>
                        <div class="label">On-going Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-spinner"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $completedProjects ?></div>
                        <div class="label">Completed Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $syncedPersonnel ?></div>
                        <div class="label">HR System Synced</div>
                    </div>
                    <div class="icon"><i class="fa fa-cloud"></i></div>
                </div>
            </div>
        </div>

        <!-- Filter Container -->
        <div class="filter-container">
            <div class="filter-header">
                <div class="filter-header-left">
                    <i class="fa fa-filter"></i>
                </div>
                <a href="personnelresearcher.php" class="filter-link">Filter Personnel</a>
            </div>
            
            <form id="filterForm" method="GET">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label>Office/Unit</label>
                        <select name="unit" onchange="this.form.submit()">
                            <option value="">All Units</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" onchange="this.form.submit()">
                    </div>
                    
                    <div class="filter-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" onchange="this.form.submit()">
                    </div>
                    
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="q" placeholder="Search by ID, name, office, position..." value="<?= s($q) ?>">
                    </div>
                    
                    <div class="filter-actions">
                        <?php if ($q): ?>
                            <a href="personnelresearcher.php" class="clear-btn" title="Clear Filters">
                                <i class="fa fa-times"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-wrapper">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Employee No.</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Employment</th>
                            <th>Office/Unit</th>
                            <th>Contact</th>
                            <th>Outputs</th>
                            <th>Last Synced</th>
                            <th>Sync Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($personnels)): ?>
                            <tr>
                                <td colspan="11">
                                    <div class="no-data">
                                        <i class="fa fa-inbox"></i>
                                        <p>No personnel records found.</p>
                                        <?php if (isHRIntegrationAvailable()): ?>
                                        <p style="font-size: 13px; color: #6b7280; margin-top: 8px;">
                                            Click "Import from HR System" to add personnel researchers from the HR database.
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php else: foreach($personnels as $p): 
                            $fullname = $p['last_name'] . ', ' . $p['first_name'] . ($p['middle_name'] ? ' '.$p['middle_name'] : '');
                            
                            // Determine sync status - use sync_status column if set to 'n/a', otherwise use existing logic
                            $syncStatus = 'never';
                            if (!empty($p['sync_status']) && $p['sync_status'] === 'n/a') {
                                $syncStatus = 'n/a';
                            } elseif ($p['is_synced'] && $p['last_synced_at']) {
                                if (needsHRSync($p['last_synced_at'])) {
                                    $syncStatus = 'needs-sync';
                                } else {
                                    $syncStatus = 'recent';
                                }
                            }
                        ?>
                        <tr>
                            <td><?= $p['id'] ?></td>
                            <td>
                                <strong><?= s($p['employee_number']) ?></strong>
                                <?php if ($p['is_synced']): ?>
                                    <br><span class="hr-badge"><i class="fa fa-cloud"></i> HR Synced</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:left; padding-left:16px;">
                                <?= s($fullname) ?>
                                <?php if (!empty($p['hr_employee_id'])): ?>
                                    <br><small style="color: #6b7280;"><i class="fa fa-id-card"></i> HR: <?= s($p['hr_employee_id']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= s($p['position'] ?: 'N/A') ?>
                            </td>
                            <td>
                                <span class="badge" style="background: #e0e7ff; color: #3730a3;">
                                    <?= s($p['employment_status'] ?: 'N/A') ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($p['office_unit'])): ?>
                                    <span style="color: #059669; font-weight: 500;"><i class="fa fa-building"></i> <?= s($p['office_unit']) ?></span>
                                    <?php if (!empty($p['sector'])): ?>
                                        <br><small style="color: #6b7280;"><?= s($p['sector']) ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span style="color: #9ca3af;">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($p['email'])): ?>
                                    <div style="font-size: 11px;">
                                        <i class="fa fa-envelope"></i> <?= s($p['email']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($p['telephone']) || !empty($p['mobile'])): ?>
                                    <div style="font-size: 11px; color: #6b7280;">
                                        <i class="fa fa-phone"></i> <?= s($p['telephone'] ?: $p['mobile']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (empty($p['email']) && empty($p['telephone']) && empty($p['mobile'])): ?>
                                    <span style="color: #9ca3af;">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge">
                                    <i class="fa fa-file-alt"></i>
                                    <?= $p['project_count'] ?> Outputs
                                </span>
                            </td>
                            <td class="sync-timestamp" style="font-size: 12px; color: #6b7280;">
                                <?php if ($p['is_synced']): ?>
                                    <?= timeAgo($p['last_synced_at']) ?>
                                <?php else: ?>
                                    <span style="color: var(--gray-400);">Never synced</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="sync-indicator sync-<?= $syncStatus ?>">
                                    <?php if ($syncStatus === 'recent'): ?>
                                        🟢 Synced
                                    <?php elseif ($syncStatus === 'needs-sync'): ?>
                                        🟡 Outdated
                                    <?php elseif ($syncStatus === 'n/a'): ?>
                                        ⚪ N/A
                                    <?php else: ?>
                                        🔴 Not synced
                                    <?php endif; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-view" onclick="location.href='personnelresearcherprofile.php?id=<?= $p['id'] ?>'">
                                        <i class="fa fa-eye"></i> View
                                    </button>
                                    
                                    <?php if ($p['is_synced'] && $p['hr_employee_id'] && $syncStatus !== 'n/a'): ?>
                                        <button class="btn-sync" onclick="syncPersonnel(<?= $p['id'] ?>)">
                                            <i class="fa fa-sync"></i> Sync
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// ========================================
// INLINE FUNCTIONS - GUARANTEED TO WORK
// ========================================

// Debounced search
let searchTimeout;
const searchInput = document.querySelector('input[name="q"]');
if (searchInput) {
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.getElementById('filterForm').submit();
        }, 400);
    });
}

/**
 * Sync personnel with HR System
 */
window.syncPersonnel = async function(personnelId) {
    if (!confirm('Sync this personnel data with HR System?\n\nThis will update their information with the latest data from HR.')) {
        return;
    }
    
    const btn = event.target.closest('.btn-sync');
    if (!btn) return;
    
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
    
    try {
        const formData = new FormData();
        formData.append('action', 'sync_personnel');
        formData.append('personnel_id', personnelId);
        
        const response = await fetch('fetch_employee.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Personnel data synced successfully!');
            setTimeout(() => location.reload(), 500);
        } else {
            throw new Error(data.error || 'Failed to sync');
        }
    } catch (error) {
        alert('❌ Sync failed: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    }
};

console.log('✅ Personnel functions loaded:', typeof syncPersonnel);
</script>

<?php if (!$isSpa): ?>
</body>
</html>
<?php endif; ?>
