<?php
/**
 * Personnel Researcher Profile Page (SPA Version)
 * 
 * Displays personnel researcher details and research projects
 * Uses ResearcherProfileAccess for scope-based access control
 * Designed to work within the SPA shell (app.php)
 * 
 * Access Rules:
 * - Admin: Full view (institution-wide), read-only for HR data
 * - Coordinator: Scoped view (unit + personnel coordinator type required)
 * - Researcher: Own profile only
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db.php';
require 'config.php';
require_once 'ResearcherProfileAccess.php';
require_once 'spa_helper.php';

// Initialize access control
$profileAccess = new ResearcherProfileAccess($conn);

// Check basic authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get personnel_id
if (!isset($_GET['id'])) {
    // For researchers, try to find their own profile
    if ($userRole === 'researcher') {
        $findStmt = $conn->prepare("SELECT id FROM personnel_researchers WHERE user_id = ? LIMIT 1");
        $findStmt->bind_param("i", $userId);
        $findStmt->execute();
        $findResult = $findStmt->get_result();
        if ($findResult && $findResult->num_rows > 0) {
            $findData = $findResult->fetch_assoc();
            echo "<script>window.SPA.loadPage('personnelresearcherprofile.php?id=" . $findData['id'] . "', true);</script>";
            exit;
        }
        $findStmt->close();
    }
    echo "<script>window.SPA.loadPage('personnelresearcher.php', true);</script>";
    exit;
}

$personnel_id = (int) $_GET['id'];

// ============================================
// ACCESS CONTROL CHECK (Using ResearcherProfileAccess)
// ============================================
$accessResult = $profileAccess->requireProfileAccess('personnel', $personnel_id, $isSpa);
$accessLevel = $accessResult['access_level'];
$isReadOnly = $accessResult['is_read_only'];
$accessSummary = $profileAccess->getAccessSummary();

// Handle AJAX operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    ob_clean();
    header('Content-Type: application/json');
    
    // Re-check write access for modifications
    $canWrite = ($userRole === 'admin') || 
                ($accessLevel === 'own_profile') ||
                ($accessLevel === 'scoped' && $userRole === 'coordinator');
    
    if (!$canWrite) {
        echo json_encode(['success' => false, 'error' => 'Write access denied. Profile is read-only.']);
        exit;
    }
    
    $action = $_POST['action'];
    
    switch ($action) {
        case 'add_project':
            $title = trim($_POST['title'] ?? '');
            $status = $_POST['project_status'] ?? 'on-going';
            $classification = trim($_POST['classification'] ?? '');
            $funding = trim($_POST['funding_source'] ?? '');
            $involvement = trim($_POST['nature_of_involvement'] ?? '');
            $start = $_POST['start_date'] ?? null;
            $end = $_POST['end_date'] ?? null;
            
            $stmt = $conn->prepare("INSERT INTO personnel_projects (personnel_id, title, project_status, classification, funding_source, nature_of_involvement, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isssssss", $personnel_id, $title, $status, $classification, $funding, $involvement, $start, $end);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'id' => $conn->insert_id]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->error]);
            }
            exit;
        
        case 'update_project':
            $project_id = (int)($_POST['project_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $status = $_POST['project_status'] ?? 'on-going';
            $classification = trim($_POST['classification'] ?? '');
            $funding = trim($_POST['funding_source'] ?? '');
            $involvement = trim($_POST['nature_of_involvement'] ?? '');
            $start = $_POST['start_date'] ?? null;
            $end = $_POST['end_date'] ?? null;
            
            $stmt = $conn->prepare("UPDATE personnel_projects SET title=?, project_status=?, classification=?, funding_source=?, nature_of_involvement=?, start_date=?, end_date=? WHERE id=? AND personnel_id=?");
            $stmt->bind_param("sssssssii", $title, $status, $classification, $funding, $involvement, $start, $end, $project_id, $personnel_id);
            echo json_encode(['success' => $stmt->execute()]);
            exit;
        
        case 'delete_project':
            $project_id = (int)($_POST['project_id'] ?? 0);
            
            $conn->begin_transaction();
            try {
                $conn->query("DELETE FROM personnel_project_team WHERE project_id = $project_id");
                $conn->query("DELETE FROM personnel_project_costs WHERE project_id = $project_id");
                $conn->query("DELETE FROM personnel_research_outputs WHERE project_id = $project_id");
                
                $stmt = $conn->prepare("DELETE FROM personnel_projects WHERE id = ? AND personnel_id = ?");
                $stmt->bind_param("ii", $project_id, $personnel_id);
                $stmt->execute();
                
                $conn->commit();
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
            exit;
    }
    
    exit;
}

// Fetch personnel data
$personnel = $conn->query("SELECT * FROM personnel_researchers WHERE id = $personnel_id")->fetch_assoc();
if (!$personnel) {
    echo '<div class="error-state"><i class="fa fa-exclamation-triangle"></i><p>Personnel researcher not found.</p></div>';
    exit;
}

// Filter restricted fields based on access level
$personnel = $profileAccess->filterResearcherData($personnel);

// Determine if user can edit
$canEdit = !$isReadOnly && (
    $userRole === 'admin' || 
    $accessLevel === 'own_profile' ||
    ($accessLevel === 'scoped' && $userRole === 'coordinator')
);

// Ensure personnel_projects table exists
try {
    $conn->query("CREATE TABLE IF NOT EXISTS personnel_projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personnel_id INT NOT NULL,
        title VARCHAR(500),
        project_status ENUM('on-going','completed','published','extended') DEFAULT 'on-going',
        classification VARCHAR(100),
        funding_source VARCHAR(255),
        nature_of_involvement VARCHAR(100),
        start_date DATE,
        end_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (personnel_id)
    )");
} catch (Exception $e) {}

// Fetch legacy projects (from personnel_projects table)
$legacyProjects = $conn->query("SELECT * FROM personnel_projects WHERE personnel_id = $personnel_id ORDER BY start_date DESC, id DESC")->fetch_all(MYSQLI_ASSOC);

// ============================================
// FETCH RMIS DATA (Research Submissions & Projects)
// ============================================

// Get the user_id linked to this personnel researcher
$personnelUserId = $personnel['user_id'] ?? null;
$submissions = [];
$rmisProjects = [];

if ($personnelUserId) {
    // Fetch research submissions
    try {
        $submissionStmt = $conn->prepare("
            SELECT rs.*, rst.type_name as submission_type_name, rst.code as submission_type_code
            FROM research_submissions rs
            LEFT JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE rs.created_by = ?
            ORDER BY rs.created_at DESC
        ");
        $submissionStmt->bind_param("i", $personnelUserId);
        $submissionStmt->execute();
        $submissions = $submissionStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $submissionStmt->close();
    } catch (Exception $e) {
        // Table may not exist
    }

    // Fetch RMIS projects (approved submissions with project status)
    try {
        $projectStmt = $conn->prepare("
            SELECT rs.*, rst.type_name as submission_type_name
            FROM research_submissions rs
            LEFT JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE rs.created_by = ? AND rs.status = 'approved' AND rs.project_status IS NOT NULL
            ORDER BY rs.elevated_to_project_at DESC
        ");
        $projectStmt->bind_param("i", $personnelUserId);
        $projectStmt->execute();
        $rmisProjects = $projectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $projectStmt->close();
    } catch (Exception $e) {
        // Table may not exist
    }
}

// Fetch research outputs linked to this personnel
$researchOutputs = [];
try {
    $outputStmt = $conn->prepare("
        SELECT ro.*, 'personnel_project' as source_type
        FROM personnel_research_outputs ro
        WHERE ro.personnel_id = ?
        ORDER BY ro.id DESC
    ");
    if ($outputStmt) {
        $outputStmt->bind_param("i", $personnel_id);
        $outputStmt->execute();
        $researchOutputs = $outputStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $outputStmt->close();
    }
} catch (Exception $e) {
    // Table may not exist
}

// Calculate comprehensive stats
$stats = [
    'total_legacy' => count($legacyProjects),
    'total_rmis' => count($rmisProjects),
    'total_submissions' => count($submissions),
    'total_outputs' => count($researchOutputs),
    'ongoing' => 0,
    'completed' => 0,
    'published' => 0,
    'pending_submissions' => 0,
    'approved_submissions' => 0
];

// Count legacy project statuses
foreach ($legacyProjects as $p) {
    if ($p['project_status'] == 'on-going') $stats['ongoing']++;
    if ($p['project_status'] == 'completed') $stats['completed']++;
    if ($p['project_status'] == 'published') $stats['published']++;
}

// Count RMIS project statuses
foreach ($rmisProjects as $p) {
    if (in_array($p['project_status'], ['on_going', 'extended'])) $stats['ongoing']++;
    if ($p['project_status'] == 'completed') $stats['completed']++;
}

// Count submission statuses
foreach ($submissions as $s) {
    if (in_array($s['status'], ['draft', 'submitted', 'under_review'])) $stats['pending_submissions']++;
    if ($s['status'] == 'approved') $stats['approved_submissions']++;
}

// Helper function
function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get initials for avatar
$initials = strtoupper(substr($personnel['first_name'] ?? '', 0, 1) . substr($personnel['last_name'] ?? '', 0, 1));
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
/* Personnel Profile - Dashboard Style */
.personnel-profile {
    padding: 20px;
    max-width: 1400px;
    margin: 0 auto;
}

.profile-header-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.profile-header-bar h1 {
    color: #1a5632;
    font-size: 24px;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.header-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.btn {
    padding: 10px 18px;
    border-radius: 8px;
    font-weight: 500;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
    cursor: pointer;
    border: none;
    font-size: 14px;
}

.btn-back {
    background: #f0f0f0;
    color: #333;
    border: 1px solid #ddd;
}

.btn-back:hover {
    background: #e5e5e5;
}

.btn-primary {
    background: linear-gradient(135deg, #1a5632, #2e7d4a);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #134025, #256b3d);
    transform: translateY(-1px);
}

.btn-secondary {
    background: white;
    color: #1a5632;
    border: 1px solid #1a5632;
}

.btn-secondary:hover {
    background: #f0f7f3;
}

.btn-danger {
    background: #dc2626;
    color: white;
}

.btn-danger:hover {
    background: #b91c1c;
}

/* Access Badges */
.access-badges {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.access-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.access-badge.institution { background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; }
.access-badge.scoped { background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; }
.access-badge.own { background: linear-gradient(135deg, #10b981, #059669); color: white; }
.access-badge.readonly { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; }

/* Profile Card */
.profile-card {
    background: linear-gradient(135deg, #1a5632 0%, #2e7d4a 50%, #3d9960 100%);
    border-radius: 16px;
    padding: 30px;
    color: white;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 25px;
    box-shadow: 0 4px 20px rgba(26, 86, 50, 0.3);
    position: relative;
    overflow: hidden;
}

.profile-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 60%;
    height: 200%;
    background: rgba(255,255,255,0.05);
    transform: rotate(-15deg);
}

.profile-avatar {
    width: 110px;
    height: 110px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 38px;
    font-weight: 600;
    border: 4px solid rgba(255,255,255,0.4);
    overflow: hidden;
    flex-shrink: 0;
    z-index: 1;
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-info {
    flex: 1;
    z-index: 1;
}

.profile-info h2 {
    margin: 0 0 5px 0;
    font-size: 28px;
    font-weight: 600;
}

.profile-info .position {
    font-size: 16px;
    opacity: 0.9;
    margin-bottom: 12px;
}

.profile-info .details {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    font-size: 14px;
    opacity: 0.9;
}

.profile-info .details span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.profile-badge {
    background: rgba(255,255,255,0.2);
    padding: 10px 20px;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    gap: 8px;
    z-index: 1;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    display: flex;
    align-items: center;
    gap: 15px;
    transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.12);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.stat-icon.blue { background: #dbeafe; color: #2563eb; }
.stat-icon.green { background: #d1fae5; color: #059669; }
.stat-icon.orange { background: #ffedd5; color: #ea580c; }
.stat-icon.purple { background: #f3e8ff; color: #9333ea; }
.stat-icon.teal { background: #ccfbf1; color: #0d9488; }
.stat-icon.pink { background: #fce7f3; color: #db2777; }

.stat-content h3 {
    font-size: 28px;
    font-weight: 700;
    margin: 0;
    color: #1f2937;
}

.stat-content p {
    margin: 2px 0 0 0;
    font-size: 13px;
    color: #6b7280;
}

/* Main Content Layout */
.content-main {
    display: grid;
    grid-template-columns: 320px 1fr;
    gap: 25px;
}

.content-sidebar {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.content-center {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

@media (max-width: 1024px) {
    .content-main {
        grid-template-columns: 1fr;
    }
}

/* View All Link */
.view-all-link {
    font-size: 13px;
    color: #1a5632;
    text-decoration: none;
    font-weight: 500;
}

.view-all-link:hover {
    text-decoration: underline;
}

/* Submission List */
.submission-list {
    display: flex;
    flex-direction: column;
}

.submission-item {
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.2s;
}

.submission-item:last-child {
    border-bottom: none;
}

.submission-item:hover {
    background: #f8fafc;
}

.submission-info h4 {
    margin: 0 0 6px 0;
    font-size: 14px;
    color: #1f2937;
    font-weight: 600;
}

.submission-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    font-size: 12px;
    color: #6b7280;
}

.submission-meta span {
    display: flex;
    align-items: center;
    gap: 4px;
}

/* Project List (clickable) */
.project-list {
    display: flex;
    flex-direction: column;
}

.project-item {
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.2s;
}

.project-item:last-child {
    border-bottom: none;
}

.project-item:hover {
    background: #f8fafc;
}

.project-info h4 {
    margin: 0 0 6px 0;
    font-size: 14px;
    color: #1f2937;
    font-weight: 600;
}

/* Status Badges */
.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    white-space: nowrap;
}

.status-draft { background: #f3f4f6; color: #4b5563; }
.status-submitted { background: #dbeafe; color: #1e40af; }
.status-under-review { background: #fef3c7; color: #92400e; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }
.status-on-going, .status-ongoing { background: #dbeafe; color: #1e40af; }
.status-extended { background: #fef3c7; color: #92400e; }
.status-completed { background: #d1fae5; color: #065f46; }
.status-published { background: #f3e8ff; color: #7c3aed; }

/* Small Button */
.btn-sm {
    padding: 6px 12px !important;
    font-size: 12px !important;
}

/* Empty State Small */
.empty-state-small {
    text-align: center;
    padding: 25px 15px;
    color: #9ca3af;
}

.empty-state-small i {
    font-size: 32px;
    margin-bottom: 10px;
    opacity: 0.5;
}

.empty-state-small p {
    margin: 0;
    font-size: 13px;
}

/* Content Cards */
.content-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    overflow: hidden;
}

.content-card-header {
    padding: 18px 20px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fafbfc;
}

.content-card-header h3 {
    margin: 0;
    font-size: 16px;
    color: #1f2937;
    display: flex;
    align-items: center;
    gap: 10px;
}

.content-card-header h3 i {
    color: #1a5632;
}

.content-card-body {
    padding: 20px;
}

/* Info List */
.info-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.info-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid #f3f4f6;
}

.info-item:last-child {
    border-bottom: none;
}

.info-item i {
    width: 20px;
    color: #6b7280;
    margin-top: 2px;
}

.info-item .label {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 2px;
}

.info-item .value {
    font-size: 14px;
    color: #1f2937;
    font-weight: 500;
}

/* Project Cards */
.project-card {
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 15px;
    transition: all 0.2s;
}

.project-card:hover {
    border-color: #1a5632;
    box-shadow: 0 4px 12px rgba(26, 86, 50, 0.1);
}

.project-card:last-child {
    margin-bottom: 0;
}

.project-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.project-card h4 {
    margin: 0;
    font-size: 16px;
    color: #1f2937;
    font-weight: 600;
    flex: 1;
    line-height: 1.4;
}

.project-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    white-space: nowrap;
    margin-left: 10px;
}

.status-ongoing, .status-on-going { background: #dbeafe; color: #1e40af; }
.status-completed { background: #d1fae5; color: #065f46; }
.status-published { background: #f3e8ff; color: #7c3aed; }
.status-extended { background: #fef3c7; color: #92400e; }

.project-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 12px;
}

.project-meta span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.project-actions {
    display: flex;
    gap: 8px;
    padding-top: 12px;
    border-top: 1px solid #f3f4f6;
}

.project-actions .btn {
    padding: 6px 12px;
    font-size: 12px;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #6b7280;
}

.empty-state i {
    font-size: 48px;
    color: #d1d5db;
    margin-bottom: 15px;
}

.empty-state p {
    margin: 0 0 15px 0;
    font-size: 14px;
}

/* Read-Only Banner */
.readonly-banner {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 1px solid #f59e0b;
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.readonly-banner i {
    color: #d97706;
    font-size: 18px;
}

.readonly-banner span {
    color: #92400e;
    font-weight: 500;
    font-size: 13px;
}

/* Modal Styles */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 9999;
    align-items: center;
    justify-content: center;
}

.modal-overlay.active {
    display: flex;
}

.modal {
    background: white;
    border-radius: 16px;
    width: 90%;
    max-width: 500px;
    max-height: 90vh;
    overflow: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.modal-header {
    padding: 20px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    margin: 0;
    font-size: 18px;
    color: #1f2937;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-header h3 i {
    color: #1a5632;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
    line-height: 1;
}

.modal-body {
    padding: 20px;
}

.form-group {
    margin-bottom: 16px;
}

.form-group label {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: #374151;
    margin-bottom: 6px;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #1a5632;
    box-shadow: 0 0 0 3px rgba(26, 86, 50, 0.1);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

/* Responsive */
@media (max-width: 768px) {
    .profile-card {
        flex-direction: column;
        text-align: center;
    }
    
    .profile-info .details {
        justify-content: center;
    }
    
    .profile-header-bar {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="personnel-profile">
    <!-- Header Bar -->
    <div class="profile-header-bar">
        <h1>
            <i class="fa fa-user-tie"></i>
            Personnel Researcher Profile
        </h1>
        <div class="header-actions">
            <div class="access-badges">
                <?php if ($accessLevel === 'institution_wide'): ?>
                    <span class="access-badge institution"><i class="fa fa-globe"></i> Institution-Wide</span>
                <?php elseif ($accessLevel === 'scoped'): ?>
                    <span class="access-badge scoped"><i class="fa fa-layer-group"></i> Scoped Access</span>
                <?php elseif ($accessLevel === 'own_profile'): ?>
                    <span class="access-badge own"><i class="fa fa-user-check"></i> Own Profile</span>
                <?php endif; ?>
                <?php if ($isReadOnly): ?>
                    <span class="access-badge readonly"><i class="fa fa-lock"></i> Read-Only</span>
                <?php endif; ?>
            </div>
            <?php if ($userRole !== 'researcher'): ?>
            <a href="personnelresearcher.php" class="btn btn-back" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('personnelresearcher.php',true)}">
                <i class="fa fa-arrow-left"></i> Back to List
            </a>
            <?php else: ?>
            <a href="researcher_dashboard.php" class="btn btn-back" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_dashboard.php',true)}">
                <i class="fa fa-arrow-left"></i> Back to Dashboard
            </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isReadOnly): ?>
    <div class="readonly-banner">
        <i class="fa fa-eye"></i>
        <span>Viewing in read-only mode. You can view this profile but cannot make changes.</span>
    </div>
    <?php endif; ?>

    <!-- Profile Card -->
    <div class="profile-card">
        <div class="profile-avatar">
            <?php if (!empty($personnel['profile_pic'])): ?>
                <img src="<?= s($personnel['profile_pic']) ?>" alt="Profile">
            <?php else: ?>
                <?= $initials ?>
            <?php endif; ?>
        </div>
        <div class="profile-info">
            <h2><?= s($personnel['first_name'] . ' ' . ($personnel['middle_name'] ? $personnel['middle_name'] . ' ' : '') . $personnel['last_name']) ?></h2>
            <div class="position"><?= s($personnel['position'] ?? 'Personnel Researcher') ?></div>
            <div class="details">
                <?php if (!empty($personnel['employee_number'])): ?>
                    <span><i class="fa fa-id-badge"></i> <?= s($personnel['employee_number']) ?></span>
                <?php endif; ?>
                <?php if (!empty($personnel['office_unit'])): ?>
                    <span><i class="fa fa-building"></i> <?= s($personnel['office_unit']) ?></span>
                <?php endif; ?>
                <?php if (!empty($personnel['email'])): ?>
                    <span><i class="fa fa-envelope"></i> <?= s($personnel['email']) ?></span>
                <?php endif; ?>
                <?php if (!empty($personnel['employment_status'])): ?>
                    <span><i class="fa fa-briefcase"></i> <?= s($personnel['employment_status']) ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="profile-badge">
            <i class="fa fa-user-tie"></i> Personnel
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fa fa-flask"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['total_rmis'] + $stats['total_legacy'] ?></h3>
                <p>Total Projects</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fa fa-spinner"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['ongoing'] ?></h3>
                <p>On-Going</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fa fa-check-circle"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['completed'] ?></h3>
                <p>Completed</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fa fa-file-lines"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['total_submissions'] ?></h3>
                <p>Submissions</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon teal">
                <i class="fa fa-clock"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['pending_submissions'] ?></h3>
                <p>Pending Review</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon pink">
                <i class="fa fa-book"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['total_outputs'] ?></h3>
                <p>Publications</p>
            </div>
        </div>
    </div>

    <!-- Main Content - Two Column Layout -->
    <div class="content-main">
        <!-- Left Sidebar: Profile Details -->
        <div class="content-sidebar">
            <!-- Contact Details -->
            <div class="content-card">
                <div class="content-card-header">
                    <h3><i class="fa fa-address-card"></i> Contact Details</h3>
                </div>
                <div class="content-card-body">
                    <div class="info-list">
                        <?php if (!empty($personnel['email'])): ?>
                        <div class="info-item">
                            <i class="fa fa-envelope"></i>
                            <div>
                                <div class="label">Email</div>
                                <div class="value"><?= s($personnel['email']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($personnel['mobile'])): ?>
                        <div class="info-item">
                            <i class="fa fa-phone"></i>
                            <div>
                                <div class="label">Mobile</div>
                                <div class="value"><?= s($personnel['mobile']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($personnel['telephone'])): ?>
                        <div class="info-item">
                            <i class="fa fa-phone-flip"></i>
                            <div>
                                <div class="label">Telephone</div>
                                <div class="value"><?= s($personnel['telephone']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if ($userRole === 'admin' && !empty($personnel['home_address'])): ?>
                        <div class="info-item">
                            <i class="fa fa-home"></i>
                            <div>
                                <div class="label">Address</div>
                                <div class="value"><?= s($personnel['home_address']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($personnel['sector'])): ?>
                        <div class="info-item">
                            <i class="fa fa-sitemap"></i>
                            <div>
                                <div class="label">Sector</div>
                                <div class="value"><?= s($personnel['sector']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if (!empty($personnel['is_synced'])): ?>
            <!-- HR Sync Status -->
            <div class="content-card">
                <div class="content-card-header">
                    <h3><i class="fa fa-cloud"></i> HR Integration</h3>
                </div>
                <div class="content-card-body">
                    <div class="info-list">
                        <div class="info-item">
                            <i class="fa fa-check-circle" style="color: #10b981;"></i>
                            <div>
                                <div class="label">Status</div>
                                <div class="value">Synced with HRIS</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Center: Main Content Area -->
        <div class="content-center">
            <!-- Research Submissions Section -->
            <?php if (!empty($submissions)): ?>
            <div class="content-card">
                <div class="content-card-header">
                    <h3><i class="fa fa-paper-plane"></i> Research Submissions</h3>
                    <a href="researcher_submissions.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_submissions.php',true)}" class="view-all-link">View All</a>
                </div>
                <div class="content-card-body" style="padding: 0;">
                    <div class="submission-list">
                        <?php foreach (array_slice($submissions, 0, 5) as $sub): ?>
                        <div class="submission-item" onclick="if(window.SPA){window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                            <div class="submission-info">
                                <h4><?= s($sub['title']) ?></h4>
                                <div class="submission-meta">
                                    <?php if (!empty($sub['reference_number'])): ?>
                                    <span><i class="fa fa-hashtag"></i> <?= s($sub['reference_number']) ?></span>
                                    <?php endif; ?>
                                    <span><i class="fa fa-folder"></i> <?= s($sub['submission_type_name'] ?? 'Unknown Type') ?></span>
                                    <span><i class="fa fa-calendar"></i> <?= date('M d, Y', strtotime($sub['created_at'])) ?></span>
                                </div>
                            </div>
                            <span class="status-badge status-<?= strtolower(str_replace('_', '-', $sub['status'])) ?>">
                                <?= ucwords(str_replace('_', ' ', $sub['status'])) ?>
                            </span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- RMIS Active Projects Section -->
            <?php if (!empty($rmisProjects)): ?>
            <div class="content-card">
                <div class="content-card-header">
                    <h3><i class="fa fa-flask"></i> Active RMIS Projects</h3>
                    <a href="researcher_projects.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_projects.php',true)}" class="view-all-link">View All</a>
                </div>
                <div class="content-card-body" style="padding: 0;">
                    <div class="project-list">
                        <?php foreach (array_slice($rmisProjects, 0, 5) as $rp): ?>
                        <div class="project-item" onclick="if(window.SPA){window.SPA.loadPage('project_view.php?id=<?= $rp['id'] ?>',true)}">
                            <div class="project-info">
                                <h4><?= s($rp['title']) ?></h4>
                                <div class="project-meta">
                                    <?php if (!empty($rp['project_code'])): ?>
                                    <span><i class="fa fa-hashtag"></i> <?= s($rp['project_code']) ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($rp['current_end_date'])): ?>
                                    <span><i class="fa fa-calendar"></i> Due: <?= date('M d, Y', strtotime($rp['current_end_date'])) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <span class="status-badge status-<?= strtolower(str_replace('_', '-', $rp['project_status'] ?? 'on-going')) ?>">
                                <?= ucwords(str_replace('_', ' ', $rp['project_status'] ?? 'On-Going')) ?>
                            </span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Historical/Legacy Projects -->
            <div class="content-card">
                <div class="content-card-header">
                    <h3><i class="fa fa-history"></i> Research Projects (Records)</h3>
                    <?php if ($canEdit): ?>
                    <button class="btn btn-primary btn-sm" onclick="showProjectModal()">
                        <i class="fa fa-plus"></i> Add
                    </button>
                    <?php endif; ?>
                </div>
                <div class="content-card-body">
                    <?php if (!empty($legacyProjects)): ?>
                        <?php foreach ($legacyProjects as $project): ?>
                        <div class="project-card" data-project-id="<?= $project['id'] ?>">
                            <div class="project-card-header">
                                <h4><?= s($project['title']) ?></h4>
                                <span class="project-status status-<?= str_replace('-', '', strtolower($project['project_status'])) ?>">
                                    <?= ucfirst(str_replace('-', ' ', $project['project_status'])) ?>
                                </span>
                            </div>
                            <div class="project-meta">
                                <?php if (!empty($project['classification'])): ?>
                                <span><i class="fa fa-tag"></i> <?= s($project['classification']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($project['funding_source'])): ?>
                                <span><i class="fa fa-university"></i> <?= s($project['funding_source']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($project['nature_of_involvement'])): ?>
                                <span><i class="fa fa-user"></i> <?= s($project['nature_of_involvement']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($project['start_date'])): ?>
                                <span><i class="fa fa-calendar"></i> <?= date('M Y', strtotime($project['start_date'])) ?><?= !empty($project['end_date']) ? ' - ' . date('M Y', strtotime($project['end_date'])) : ' - Present' ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if ($canEdit): ?>
                            <div class="project-actions">
                                <button class="btn btn-secondary" onclick='editProject(<?= json_encode($project) ?>)'>
                                    <i class="fa fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-danger" onclick="deleteProject(<?= $project['id'] ?>)">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fa fa-flask"></i>
                            <p>No research projects added yet.</p>
                            <?php if ($canEdit): ?>
                            <button class="btn btn-primary" onclick="showProjectModal()">
                                <i class="fa fa-plus"></i> Add First Project
                            </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Project Modal -->
<div class="modal-overlay" id="projectModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="projectModalTitle"><i class="fa fa-flask"></i> Add Project</h3>
            <button class="modal-close" onclick="closeModal('projectModal')">&times;</button>
        </div>
        <form id="projectForm" method="POST" onsubmit="submitProject(event); return false;">
            <input type="hidden" name="project_id" id="projectId">
            <div class="modal-body">
                <div class="form-group">
                    <label>Project Title *</label>
                    <input type="text" name="title" id="projectTitle" required placeholder="Enter project title">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Status</label>
                        <select name="project_status" id="projectStatus">
                            <option value="on-going">On-going</option>
                            <option value="completed">Completed</option>
                            <option value="published">Published</option>
                            <option value="extended">Extended</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Classification</label>
                        <input type="text" name="classification" id="projectClassification" placeholder="e.g., Basic Research">
                    </div>
                </div>
                <div class="form-group">
                    <label>Funding Source</label>
                    <input type="text" name="funding_source" id="projectFunding" placeholder="e.g., University Fund">
                </div>
                <div class="form-group">
                    <label>Nature of Involvement</label>
                    <select name="nature_of_involvement" id="projectInvolvement">
                        <option value="">Select...</option>
                        <option value="Project Leader">Project Leader</option>
                        <option value="Co-Project Leader">Co-Project Leader</option>
                        <option value="Study Leader">Study Leader</option>
                        <option value="Co-Study Leader">Co-Study Leader</option>
                        <option value="Researcher">Researcher</option>
                        <option value="Consultant">Consultant</option>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" name="start_date" id="projectStart">
                    </div>
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" name="end_date" id="projectEnd">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-back" onclick="closeModal('projectModal')">Cancel</button>
                <button type="submit" class="btn btn-primary" id="projectSubmitBtn">Save Project</button>
            </div>
        </form>
    </div>
</div>

<script>
const personnelId = <?= $personnel_id ?>;
const canEdit = <?= $canEdit ? 'true' : 'false' ?>;

function showProjectModal() {
    if (!canEdit) return;
    document.getElementById('projectForm').reset();
    document.getElementById('projectId').value = '';
    document.getElementById('projectModalTitle').innerHTML = '<i class="fa fa-flask"></i> Add Project';
    document.getElementById('projectSubmitBtn').textContent = 'Save Project';
    document.getElementById('projectModal').classList.add('active');
}

function editProject(project) {
    if (!canEdit) return;
    document.getElementById('projectId').value = project.id;
    document.getElementById('projectTitle').value = project.title || '';
    document.getElementById('projectStatus').value = project.project_status || 'on-going';
    document.getElementById('projectClassification').value = project.classification || '';
    document.getElementById('projectFunding').value = project.funding_source || '';
    document.getElementById('projectInvolvement').value = project.nature_of_involvement || '';
    document.getElementById('projectStart').value = project.start_date || '';
    document.getElementById('projectEnd').value = project.end_date || '';
    document.getElementById('projectModalTitle').innerHTML = '<i class="fa fa-flask"></i> Edit Project';
    document.getElementById('projectSubmitBtn').textContent = 'Update Project';
    document.getElementById('projectModal').classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

async function submitProject(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const projectId = document.getElementById('projectId').value;
    
    formData.append('action', projectId ? 'update_project' : 'add_project');
    
    try {
        const response = await fetch(`personnelresearcherprofile.php?id=${personnelId}&spa=1`, {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            closeModal('projectModal');
            if (window.SPA) {
                window.SPA.loadPage(`personnelresearcherprofile.php?id=${personnelId}`, false);
            } else {
                location.reload();
            }
        } else {
            alert('Error: ' + (result.error || 'Failed to save project'));
        }
    } catch (error) {
        alert('Error saving project');
    }
}

async function deleteProject(projectId) {
    if (!confirm('Are you sure you want to delete this project? This will also remove all associated data.')) return;
    
    const formData = new FormData();
    formData.append('action', 'delete_project');
    formData.append('project_id', projectId);
    
    try {
        const response = await fetch(`personnelresearcherprofile.php?id=${personnelId}&spa=1`, {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            if (window.SPA) {
                window.SPA.loadPage(`personnelresearcherprofile.php?id=${personnelId}`, false);
            } else {
                location.reload();
            }
        } else {
            alert('Error: ' + (result.error || 'Failed to delete project'));
        }
    } catch (error) {
        alert('Error deleting project');
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});
</script>
