<?php
/**
 * Research Proposal Submission Form
 * 
 * This is the entry point for researchers to submit NEW research proposals.
 * Only Research Proposals can be created from this page.
 * 
 * For project-based submissions (Progress Reports, Extension Requests, 
 * Output/Publication Reports, Completion Reports), users must go to 
 * "My Projects" and select the relevant project.
 * 
 * This design follows the RMIS/OOM lifecycle where:
 * - Research Proposal = new research request for approval
 * - All other submission types = linked to an existing approved project
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'auth_check.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? '';
$fullname = $_SESSION['fullname'] ?? '';
$isSpa = isSpaRequest();

$service = new SubmissionService($conn);
$workflow = new WorkflowEngine($conn);

// Handle form submission BEFORE SPA redirect check
$formMessage = '';
$formError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        // Prepare data
        $data = [
            'submission_type_id' => intval($_POST['submission_type_id'] ?? 0),
            'project_id' => !empty($_POST['project_id']) ? intval($_POST['project_id']) : null,
            'researcher_type' => $_POST['researcher_type'] ?? '',
            'researcher_id' => intval($_POST['researcher_id'] ?? 0),
            'title' => trim($_POST['title'] ?? ''),
            'abstract' => trim($_POST['abstract'] ?? ''),
            'objectives' => trim($_POST['objectives'] ?? ''),
            'methodology' => trim($_POST['methodology'] ?? ''),
            'expected_outcomes' => trim($_POST['expected_outcomes'] ?? ''),
            'proposed_start_date' => !empty($_POST['proposed_start_date']) ? $_POST['proposed_start_date'] : null,
            'proposed_end_date' => !empty($_POST['proposed_end_date']) ? $_POST['proposed_end_date'] : null,
            'total_budget' => floatval($_POST['total_budget'] ?? 0)
        ];
        
        if ($action === 'create') {
            $result = $service->create($data);
        } else {
            $submissionId = intval($_POST['submission_id'] ?? 0);
            $result = $service->update($submissionId, $data);
        }
        
        if ($result['success']) {
            $newSubmissionId = $result['submission_id'] ?? $submissionId;
            
            // Handle file uploads
            if (!empty($_FILES['attachments']) && $_FILES['attachments']['error'][0] !== UPLOAD_ERR_NO_FILE) {
                foreach ($_FILES['attachments']['name'] as $key => $filename) {
                    if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                        // Create a single file array for the addAttachment method
                        $singleFile = [
                            'name' => $_FILES['attachments']['name'][$key],
                            'type' => $_FILES['attachments']['type'][$key],
                            'tmp_name' => $_FILES['attachments']['tmp_name'][$key],
                            'error' => $_FILES['attachments']['error'][$key],
                            'size' => $_FILES['attachments']['size'][$key]
                        ];
                        
                        $service->addAttachment($newSubmissionId, $singleFile, 'supporting_document');
                    }
                }
            }
            
            // Auto-submit if requested
            $submitAction = $_POST['submit_action'] ?? 'draft';
            if ($submitAction === 'submit') {
                $submitResult = $workflow->submit($newSubmissionId);
                if ($submitResult['success']) {
                    $_SESSION['flash_message'] = 'Submission successfully sent to your coordinator for review!';
                    $_SESSION['flash_type'] = 'success';
                } else {
                    $_SESSION['flash_message'] = 'Saved as draft. Could not submit: ' . ($submitResult['error'] ?? 'Unknown error');
                    $_SESSION['flash_type'] = 'warning';
                }
            } else {
                $_SESSION['flash_message'] = 'Submission saved as draft successfully!';
                $_SESSION['flash_type'] = 'success';
            }
            
            // Redirect to submissions list (works both in SPA and direct mode)
            header('Location: app.php?page=submissions');
            exit;
        } else {
            // Store error in session and redirect back
            $_SESSION['flash_message'] = $result['error'] ?? 'Failed to save submission. Please try again.';
            $_SESSION['flash_type'] = 'danger';
            header('Location: app.php?load=submission_create.php');
            exit;
        }
    }
}

// Redirect to SPA shell if accessed directly (after POST processing)
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get submission types
$submissionTypes = $service->getSubmissionTypes();

// Define which submission types require an approved project
// Project-independent: Research Proposal
// Project-based: Progress Report, Extension Request, Output Report, Completion Report, Amendment Request
// All submission types except 'proposal' require an approved project
// These must be created from My Projects page, not here
$projectBasedTypeCodes = ['ongoing', 'extension', 'output', 'completed', 'completion', 'amendment', 'progress'];
$projectIndependentTypeCodes = ['proposal'];

// Determine researcher type and ID based on logged-in user
$researcherType = null;
$researcherId = null;
$researcherInfo = null;

// Check if user has a researcher profile
// IMPORTANT: Only use user_id to find the researcher's OWN profile
// Do NOT use created_by - that shows who added the record, not who the researcher is
$checkFaculty = $conn->prepare("SELECT id, CONCAT(last_name, ', ', first_name) as name, home_unit, email FROM faculty_researchers WHERE user_id = ? LIMIT 1");
$checkFaculty->bind_param("i", $userId);
$checkFaculty->execute();
$facultyResult = $checkFaculty->get_result()->fetch_assoc();
$checkFaculty->close();

if ($facultyResult) {
    $researcherType = 'faculty';
    $researcherId = $facultyResult['id'];
    $researcherInfo = $facultyResult;
}

// Check student researcher - students use created_by (they don't have user accounts)
if (!$researcherInfo) {
    $checkStudent = $conn->prepare("SELECT id, CONCAT(last_name, ', ', first_name) as name, department as home_unit, email FROM student_researchers WHERE created_by = ? LIMIT 1");
    $checkStudent->bind_param("i", $userId);
    $checkStudent->execute();
    $studentResult = $checkStudent->get_result()->fetch_assoc();
    $checkStudent->close();
    
    if ($studentResult) {
        $researcherType = 'student';
        $researcherId = $studentResult['id'];
        $researcherInfo = $studentResult;
    }
}

// Check personnel researcher
if (!$researcherInfo) {
    $checkPersonnel = $conn->prepare("SELECT id, CONCAT(last_name, ', ', first_name) as name, office_unit as home_unit, email FROM personnel_researchers WHERE user_id = ? LIMIT 1");
    $checkPersonnel->bind_param("i", $userId);
    $checkPersonnel->execute();
    $personnelResult = $checkPersonnel->get_result()->fetch_assoc();
    $checkPersonnel->close();
    
    if ($personnelResult) {
        $researcherType = 'personnel';
        $researcherId = $personnelResult['id'];
        $researcherInfo = $personnelResult;
    }
}

// =====================================================
// COORDINATOR SUBMISSION ROUTING PREVIEW
// Determine routing path for display before submission
// =====================================================
$isCoordinatorSubmitter = false;
$routingPreview = [
    'type' => 'standard',
    'target' => 'coordinator',
    'target_name' => ucfirst($researcherType ?? 'Faculty') . ' Research Coordinator',
    'message' => 'Your submission will be automatically routed to the appropriate <strong>' . ucfirst($researcherType ?? 'Faculty') . ' Research Coordinator</strong> based on your unit assignment.',
    'peer_coordinator_name' => null,
    'escalated' => false
];

// Check if current user is a coordinator
$submitterCoordInfo = $workflow->isCurrentUserCoordinator();
if ($submitterCoordInfo) {
    $isCoordinatorSubmitter = true;
    
    // Preview routing - build mock submission for peer coordinator lookup
    if ($researcherInfo) {
        $mockSubmission = [
            'researcher_type' => $researcherType,
            'researcher_unit_id' => $researcherInfo['home_unit'] ?? '',
            'researcher_unit_name' => $researcherInfo['home_unit'] ?? ''
        ];
        
        $peerCoordinators = $workflow->findPeerCoordinators($mockSubmission, $submitterCoordInfo['employee_id']);
        
        if (!empty($peerCoordinators)) {
            // Option 1: Will route to peer coordinator
            $routingPreview = [
                'type' => 'peer_coordinator',
                'target' => 'coordinator',
                'target_name' => $peerCoordinators[0]['full_name'],
                'message' => '<strong><i class="fa fa-shield-halved"></i> Segregation of Duties Applied</strong><br>Since you are a Research Coordinator, your submission will be routed to a <strong>peer coordinator</strong> for review to maintain audit integrity.',
                'peer_coordinator_name' => $peerCoordinators[0]['full_name'],
                'escalated' => false,
                'available_peers' => count($peerCoordinators)
            ];
        } else {
            // Option 2: Will escalate to Research Office
            $routingPreview = [
                'type' => 'escalated_to_ro',
                'target' => 'research_office',
                'target_name' => 'Research Office',
                'message' => '<strong><i class="fa fa-shield-halved"></i> Segregation of Duties Applied</strong><br>Since you are the only Research Coordinator for your unit, your submission will be <strong>escalated directly to the Research Office</strong> for endorsement-equivalent review.',
                'peer_coordinator_name' => null,
                'escalated' => true,
                'available_peers' => 0
            ];
        }
    }
}

// Handle edit mode if submission ID is provided
$editMode = false;
$submission = null;
$submissionId = isset($_GET['id']) ? intval($_GET['id']) : null;

if ($submissionId) {
    $submission = $service->getById($submissionId);
    if ($submission && in_array('edit', $submission['allowed_actions'] ?? [])) {
        $editMode = true;
    } elseif ($submission) {
        // User can view but not edit
        header("Location: submission_view.php?id=$submissionId");
        exit;
    }
}

$pageTitle = $editMode ? 'Edit Submission' : 'New Research Proposal';
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* Page Header */
.submission-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.submission-title {
    display: flex;
    align-items: center;
    gap: 12px;
}

.submission-title i {
    font-size: 28px;
    color: #064e1a;
}

.submission-title h1 {
    font-size: 24px;
    color: #1f2937;
    margin: 0;
}

/* Step Indicator */
.step-indicator {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0;
    padding: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin-bottom: 25px;
}

.step-indicator .step {
    display: flex;
    align-items: center;
    color: #9ca3af;
    font-size: 14px;
    font-weight: 500;
}

.step-indicator .step.active {
    color: #064e1a;
}

.step-indicator .step.completed {
    color: #10b981;
}

.step-indicator .step-number {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: 2px solid currentColor;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    margin-right: 8px;
    font-size: 14px;
}

.step-indicator .step.completed .step-number {
    background: #10b981;
    border-color: #10b981;
    color: white;
}

.step-indicator .step.active .step-number {
    background: #064e1a;
    border-color: #064e1a;
    color: white;
}

.step-indicator .step-line {
    width: 50px;
    height: 2px;
    background: #e5e7eb;
    margin: 0 12px;
}

.step-indicator .step-line.completed {
    background: #10b981;
}

/* Form Cards */
.form-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin-bottom: 20px;
    overflow: hidden;
}

.form-card-header {
    background: #f8fafc;
    padding: 16px 20px;
    border-bottom: 1px solid #e2e8f0;
}

.form-card-header h5 {
    margin: 0;
    color: #1f2937;
    font-size: 16px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-card-header h5 i {
    color: #064e1a;
}

.form-card-body {
    padding: 20px;
}

/* Submission Type Card - Single Proposal */
.submission-type-card {
    border: 2px solid #e5e7eb;
    border-radius: 12px;
    padding: 24px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: white;
    display: flex;
    align-items: flex-start;
    gap: 16px;
}

.submission-type-card:hover {
    border-color: #064e1a;
    background: #f0fdf4;
}

.submission-type-card.selected {
    border-color: #064e1a;
    background: #f0fdf4;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.15);
}

.submission-type-card .type-icon {
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, #064e1a, #0a7c2e);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.submission-type-card .type-icon i {
    font-size: 24px;
    color: white;
}

.submission-type-card .type-content h6 {
    font-size: 18px;
    font-weight: 600;
    color: #1f2937;
    margin: 0 0 6px 0;
}

.submission-type-card .type-content p {
    font-size: 14px;
    color: #6b7280;
    margin: 0 0 12px 0;
    line-height: 1.5;
}

.submission-type-card .type-features {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.submission-type-card .feature-tag {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    background: #e0f2fe;
    color: #0369a1;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
}

.submission-type-card .feature-tag i {
    font-size: 10px;
}

.submission-type-card.selected .feature-tag {
    background: #dcfce7;
    color: #166534;
}

/* Helper Panel */
.helper-panel {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}

.helper-panel-content {
    display: flex;
    align-items: flex-start;
    gap: 16px;
}

.helper-panel-icon {
    width: 44px;
    height: 44px;
    background: #fef3c7;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.helper-panel-icon i {
    font-size: 20px;
    color: #d97706;
}

.helper-panel-text h6 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0 0 6px 0;
}

.helper-panel-text p {
    font-size: 13px;
    color: #6b7280;
    margin: 0 0 12px 0;
    line-height: 1.5;
}

.helper-panel-text p strong {
    color: #1f2937;
}

.helper-panel .btn-link-projects {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: #064e1a;
    color: white;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    text-decoration: none;
    transition: background 0.2s;
}

.helper-panel .btn-link-projects:hover {
    background: #053d15;
    color: white;
}

/* Researcher Info Card */
.researcher-info-card {
    background: linear-gradient(135deg, #f0fdf4, #dcfce7);
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    padding: 20px;
}

.researcher-info-card .info-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.researcher-info-card .info-item .label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #166534;
    font-weight: 600;
    margin-bottom: 4px;
}

.researcher-info-card .info-item .value {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
}

.routing-info {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #bbf7d0;
    font-size: 13px;
    color: #166534;
    line-height: 1.5;
}

.routing-info i {
    margin-right: 6px;
}

/* Coordinator Submission Routing Styles */
.routing-info.routing-peer {
    background: linear-gradient(135deg, #eff6ff 0%, #e0f2fe 100%);
    border: 1px solid #93c5fd;
    border-radius: 8px;
    padding: 14px 16px;
    border-top: none;
    margin-top: 16px;
    color: #1e40af;
}

.routing-info.routing-peer i.fa-shield-halved {
    color: #2563eb;
}

.routing-info.routing-escalated {
    background: linear-gradient(135deg, #fef3c7 0%, #fef9c3 100%);
    border: 1px solid #fcd34d;
    border-radius: 8px;
    padding: 14px 16px;
    border-top: none;
    margin-top: 16px;
    color: #92400e;
}

.routing-info.routing-escalated i.fa-shield-halved {
    color: #d97706;
}

/* Form Controls */
.form-group {
    margin-bottom: 24px;
}

.form-label {
    display: block;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 8px;
    font-size: 14px;
}

.form-label.required::after {
    content: ' *';
    color: #dc2626;
}

.form-text {
    font-size: 13px;
    color: #6b7280;
    margin-top: 6px;
}

.form-control, .form-select {
    display: block;
    width: 100%;
    border-radius: 8px;
    border: 1px solid #d1d5db;
    padding: 12px 14px;
    font-size: 14px;
    color: #1f2937;
    background: white;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.form-control:focus, .form-select:focus {
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
    outline: none;
}

.form-control::placeholder {
    color: #9ca3af;
}

textarea.form-control {
    min-height: 120px;
    resize: none;
    overflow: hidden;
    transition: height 0.15s ease;
}

textarea.form-control.auto-expand {
    height: auto;
}

.input-group {
    display: flex;
}

.input-group .input-group-text {
    background: #f3f4f6;
    border: 1px solid #d1d5db;
    border-right: none;
    border-radius: 8px 0 0 8px;
    padding: 12px 14px;
    font-size: 14px;
    color: #6b7280;
    font-weight: 500;
}

.input-group .form-control {
    border-radius: 0 8px 8px 0;
}

/* Form Row for Side-by-Side Fields */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

/* Buttons */
.btn-primary {
    background: #064e1a;
    border: none;
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 500;
    font-size: 14px;
}

.btn-primary:hover {
    background: #053d15;
}

.btn-primary:disabled {
    background: #9ca3af;
}

.btn-outline-secondary {
    background: #064e1a;
    border: none;
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 500;
    font-size: 14px;
}

.btn-outline-secondary:hover {
    background: #053d15;
}

/* Form Sections */
.form-section {
    display: none;
}

.form-section.active {
    display: block;
}

/* Attachment Requirements */
.attachment-requirements {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    padding: 16px 20px;
    margin-bottom: 24px;
}

.attachment-requirements .requirements-header {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 600;
    color: #1e40af;
    margin-bottom: 12px;
    font-size: 14px;
}

.attachment-requirements .requirements-header i {
    font-size: 18px;
}

.attachment-requirements ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

.attachment-requirements ul li {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    font-size: 13px;
    color: #3b82f6;
    border-bottom: 1px solid #dbeafe;
}

.attachment-requirements ul li:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.attachment-requirements ul li i {
    color: #60a5fa;
    width: 18px;
    text-align: center;
}

/* Attachment Dropzone */
.attachment-dropzone {
    border: 2px dashed #d1d5db;
    border-radius: 12px;
    padding: 48px 24px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    background: #fafafa;
}

.attachment-dropzone:hover,
.attachment-dropzone.dragover {
    border-color: #064e1a;
    background: #f0fdf4;
}

.attachment-dropzone .dropzone-icon {
    margin-bottom: 16px;
}

.attachment-dropzone .dropzone-icon i {
    font-size: 48px;
    color: #9ca3af;
    transition: color 0.3s;
}

.attachment-dropzone:hover .dropzone-icon i {
    color: #064e1a;
}

.attachment-dropzone .dropzone-text {
    margin-bottom: 16px;
}

.attachment-dropzone .dropzone-text p {
    font-size: 16px;
    font-weight: 600;
    color: #374151;
    margin: 0 0 8px 0;
}

.attachment-dropzone .dropzone-text span {
    font-size: 13px;
    color: #9ca3af;
    display: block;
    margin-bottom: 12px;
}

.attachment-dropzone .btn-browse {
    background: #064e1a;
    color: white;
    border: none;
    padding: 10px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
}

.attachment-dropzone .btn-browse:hover {
    background: #053d15;
}

.attachment-dropzone .dropzone-hint {
    font-size: 12px;
    color: #9ca3af;
    margin-top: 0;
}

/* Attachment List */
.attachment-list {
    margin-top: 20px;
}

.attachment-item {
    display: flex;
    align-items: center;
    padding: 14px 16px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    margin-bottom: 10px;
    transition: all 0.2s;
}

.attachment-item:hover {
    border-color: #cbd5e1;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.attachment-item .file-icon-wrapper {
    width: 44px;
    height: 44px;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 14px;
    flex-shrink: 0;
}

.attachment-item .file-icon-wrapper i {
    font-size: 20px;
    color: white;
}

.attachment-item .file-info {
    flex: 1;
    min-width: 0;
}

.attachment-item .file-name {
    font-weight: 600;
    font-size: 14px;
    color: #1f2937;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.attachment-item .file-size {
    font-size: 12px;
    color: #6b7280;
    margin-top: 2px;
}

.attachment-item .btn-remove-file {
    width: 32px;
    height: 32px;
    border: none;
    background: #fee2e2;
    color: #dc2626;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    flex-shrink: 0;
}

.attachment-item .btn-remove-file:hover {
    background: #fecaca;
}

/* No Researcher Warning */
.no-researcher-warning {
    background: #fef3c7;
    border: 1px solid #fcd34d;
    border-radius: 12px;
    padding: 32px;
    text-align: center;
}

.no-researcher-warning i {
    font-size: 48px;
    color: #d97706;
    display: block;
    margin-bottom: 16px;
}

.no-researcher-warning h5 {
    color: #92400e;
    margin-bottom: 8px;
}

.no-researcher-warning p {
    color: #a16207;
    margin-bottom: 0;
}

/* Alert Info Custom */
.alert-info-custom {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 8px;
    color: #166534;
    padding: 14px 16px;
    font-size: 14px;
}

/* Card Actions */
.card-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
}

/* Review Summary */
.review-summary {
    display: flex;
    flex-direction: column;
    gap: 0;
}

.review-section {
    padding: 20px 0;
    border-bottom: 1px solid #e5e7eb;
}

.review-section:first-child {
    padding-top: 0;
}

.review-section:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.review-section-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    font-weight: 600;
    font-size: 15px;
    color: #064e1a;
}

.review-section-header i {
    font-size: 16px;
}

.review-grid {
    display: grid;
    gap: 16px;
}

.review-grid.two-col {
    grid-template-columns: 1fr 1fr;
}

@media (max-width: 768px) {
    .review-grid.two-col {
        grid-template-columns: 1fr;
    }
}

.review-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.review-label {
    font-size: 12px;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 500;
}

.review-value {
    font-size: 15px;
    color: #1f2937;
    font-weight: 500;
}

.review-attachments {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.review-attachments .no-attachments {
    color: #9ca3af;
    font-size: 14px;
    font-style: italic;
}

.review-attachments .attachment-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    background: #f3f4f6;
    border-radius: 8px;
    font-size: 13px;
    color: #374151;
}

.review-attachments .attachment-badge i {
    color: #064e1a;
}

/* Routing Notice */
.routing-notice {
    display: flex;
    align-items: flex-start;
    gap: 16px;
    background: linear-gradient(135deg, #f0fdf4, #dcfce7);
    border: 1px solid #bbf7d0;
    border-radius: 12px;
    padding: 20px;
    margin-top: 24px;
}

.routing-notice .routing-icon {
    width: 44px;
    height: 44px;
    background: #166534;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.routing-notice .routing-icon i {
    color: white;
    font-size: 18px;
}

.routing-notice .routing-content {
    flex: 1;
}

.routing-notice .routing-content strong {
    display: block;
    font-size: 15px;
    color: #166534;
    margin-bottom: 6px;
}

.routing-notice .routing-content p {
    font-size: 13px;
    color: #15803d;
    margin: 0;
    line-height: 1.6;
}

.routing-notice .routing-content p strong {
    display: inline;
    color: #166534;
}

/* Coordinator Submission Routing Notice Styles */
.routing-notice.routing-peer {
    background: linear-gradient(135deg, #eff6ff 0%, #e0f2fe 100%);
    border: 1px solid #93c5fd;
}

.routing-notice.routing-peer .routing-icon {
    background: #2563eb;
}

.routing-notice.routing-peer .routing-content strong {
    color: #1e40af;
}

.routing-notice.routing-peer .routing-content p {
    color: #1e40af;
}

.routing-notice.routing-peer .routing-content p strong {
    color: #1d4ed8;
}

.routing-notice.routing-peer .routing-content p em {
    font-size: 12px;
    color: #3b82f6;
}

.routing-notice.routing-escalated {
    background: linear-gradient(135deg, #fef3c7 0%, #fef9c3 100%);
    border: 1px solid #fcd34d;
}

.routing-notice.routing-escalated .routing-icon {
    background: #d97706;
}

.routing-notice.routing-escalated .routing-content strong {
    color: #92400e;
}

.routing-notice.routing-escalated .routing-content p {
    color: #92400e;
}

.routing-notice.routing-escalated .routing-content p strong {
    color: #b45309;
}

.routing-notice.routing-escalated .routing-content p em {
    font-size: 12px;
    color: #d97706;
}

/* Submit Actions */
.submit-actions {
    display: flex;
    gap: 12px;
}

.btn-success {
    background: linear-gradient(135deg, #059669, #047857);
    border: none;
    color: white;
    padding: 10px 24px;
    border-radius: 8px;
    font-weight: 500;
    font-size: 14px;
    transition: all 0.2s;
}

.btn-success:hover {
    background: linear-gradient(135deg, #047857, #065f46);
    box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
}

/* Card Actions - Navigation Buttons */
.card-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    background: #f8fafc;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    margin-top: 20px;
}

@media (max-width: 768px) {
    .researcher-info-card .info-row {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .step-indicator {
        flex-wrap: wrap;
        gap: 8px;
    }
    
    .step-indicator .step-line {
        display: none;
    }
}
</style>

<div class="content">
    <!-- Page Header -->
    <div class="submission-header">
        <div class="submission-title">
            <i class="fa-solid fa-file-circle-plus"></i>
            <div>
                <h1><?php echo $pageTitle; ?></h1>
                <p style="margin: 0; color: #6b7280; font-size: 14px;">
                    Submit a new research proposal for review and approval
                </p>
            </div>
        </div>
    </div>

    <div class="container pb-5">
        <?php 
        // Display flash messages
        if (isset($_SESSION['flash_message'])): 
            $flashType = $_SESSION['flash_type'] ?? 'info';
            $flashMsg = $_SESSION['flash_message'];
            unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        ?>
        <div class="alert alert-<?php echo $flashType; ?> alert-dismissible fade show" role="alert">
            <i class="fa fa-<?php echo $flashType === 'success' ? 'check-circle' : ($flashType === 'danger' ? 'exclamation-triangle' : 'info-circle'); ?>" style="margin-right: 8px;"></i>
            <?php echo htmlspecialchars($flashMsg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($formError): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fa fa-exclamation-triangle" style="margin-right: 8px;"></i><?php echo htmlspecialchars($formError); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($formMessage): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fa fa-check-circle" style="margin-right: 8px;"></i><?php echo htmlspecialchars($formMessage); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if (!$researcherInfo): ?>
        <!-- No researcher profile warning -->
        <div class="no-researcher-warning">
            <i class="fa fa-exclamation-triangle"></i>
            <h5>Researcher Profile Required</h5>
            <p>You need a researcher profile to create submissions. Please create your researcher profile first.</p>
            <div style="display: flex; justify-content: center; gap: 10px; margin-top: 16px;">
                <a href="facultyresearcherform.php" class="btn btn-primary">
                    <i class="fa fa-user-plus" style="margin-right: 6px;"></i>Create Faculty Profile
                </a>
                <a href="studentresearcherform.php" class="btn btn-outline-secondary">
                    <i class="fa fa-user-graduate" style="margin-right: 6px;"></i>Create Student Profile
                </a>
                <a href="personnelresearcherform.php" class="btn btn-outline-secondary">
                    <i class="fa fa-briefcase" style="margin-right: 6px;"></i>Create Personnel Profile
                </a>
            </div>
        </div>
        <?php else: ?>
        
        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step active" id="step1-indicator">
                <div class="step-number">1</div>
                <span>Type</span>
            </div>
            <div class="step-line" id="line1"></div>
            <div class="step" id="step2-indicator">
                <div class="step-number">2</div>
                <span>Details</span>
            </div>
            <div class="step-line" id="line2"></div>
            <div class="step" id="step3-indicator">
                <div class="step-number">3</div>
                <span>Attachments</span>
            </div>
            <div class="step-line" id="line3"></div>
            <div class="step" id="step4-indicator">
                <div class="step-number">4</div>
                <span>Review</span>
            </div>
        </div>

        <form id="submissionForm" method="POST" enctype="multipart/form-data" data-no-spa="true" action="submission_create.php">
            <input type="hidden" name="action" value="<?php echo $editMode ? 'update' : 'create'; ?>">
            <?php if ($editMode): ?>
            <input type="hidden" name="submission_id" value="<?php echo $submissionId; ?>">
            <?php endif; ?>
            <input type="hidden" name="researcher_type" value="<?php echo $researcherType; ?>">
            <input type="hidden" name="researcher_id" value="<?php echo $researcherId; ?>">
            
            <!-- STEP 1: Submission Type -->
            <div class="form-section active" id="step1">
                <div class="form-card">
                    <div class="form-card-header">
                        <h5><i class="fa fa-list-check"></i> Select Submission Type</h5>
                    </div>
                    <div class="form-card-body">
                        <?php 
                        // Only show Research Proposal type on this page
                        // Project-based submissions must be created from My Projects
                        foreach ($submissionTypes as $type): 
                            // Skip project-based types - they are accessed from My Projects
                            if (in_array($type['type_code'], $projectBasedTypeCodes)) {
                                continue;
                            }
                            $cardClass = ($editMode && $submission['submission_type_id'] == $type['id']) ? 'selected' : '';
                        ?>
                        <div class="submission-type-card <?php echo $cardClass; ?>" 
                             data-type-id="<?php echo $type['id']; ?>"
                             data-type-code="<?php echo $type['type_code']; ?>"
                             data-requires-project="0"
                             data-requires-ethics="<?php echo $type['requires_ethics_clearance']; ?>"
                             data-requires-budget="<?php echo $type['requires_budget']; ?>"
                             data-requires-timeline="<?php echo $type['requires_timeline']; ?>">
                            <div class="type-icon">
                                <i class="fa fa-lightbulb"></i>
                            </div>
                            <div class="type-content">
                                <h6><?php echo htmlspecialchars($type['type_name']); ?></h6>
                                <p><?php echo htmlspecialchars($type['description'] ?? 'Submit a new research proposal for review and approval by your coordinator and the Research Office.'); ?></p>
                                <div class="type-features">
                                    <span class="feature-tag"><i class="fa fa-check"></i> Timeline Required</span>
                                    <span class="feature-tag"><i class="fa fa-check"></i> Budget Optional</span>
                                    <span class="feature-tag"><i class="fa fa-check"></i> Methodology Required</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <!-- Helper Panel for Project-Based Submissions -->
                        <div class="helper-panel">
                            <div class="helper-panel-content">
                                <div class="helper-panel-icon">
                                    <i class="fa fa-folder-open"></i>
                                </div>
                                <div class="helper-panel-text">
                                    <h6>Looking for other submission types?</h6>
                                    <p>To submit <strong>Progress Reports</strong>, <strong>Output/Publication Reports</strong>, <strong>Extension Requests</strong>, or <strong>Completion Reports</strong>, go to <strong>My Projects</strong> and select the project you want to report on.</p>
                                    <a href="researcher_projects.php" class="btn-link-projects" onclick="event.preventDefault(); window.SPA && window.SPA.loadPage ? window.SPA.loadPage('researcher_projects.php') : window.location.href='researcher_projects.php';">
                                        <i class="fa fa-arrow-right"></i> Go to My Projects
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <input type="hidden" name="submission_type_id" id="submission_type_id" 
                               value="<?php echo $editMode ? $submission['submission_type_id'] : ''; ?>" required>
                    </div>
                </div>
                
                <!-- Researcher Info -->
                <div class="form-card">
                    <div class="form-card-header">
                        <h5><i class="fa fa-user-check"></i> Researcher Information</h5>
                    </div>
                    <div class="form-card-body">
                        <div class="researcher-info-card">
                            <div class="info-row">
                                <div class="info-item">
                                    <div class="label">Researcher Name</div>
                                    <div class="value"><?php echo htmlspecialchars($researcherInfo['name']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="label">Category</div>
                                    <div class="value">
                                        <?php 
                                        $typeLabels = ['faculty' => 'Faculty Researcher', 'student' => 'Student Researcher', 'personnel' => 'Personnel Researcher'];
                                        echo $typeLabels[$researcherType] ?? ucfirst($researcherType);
                                        ?>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <div class="label">Unit/College</div>
                                    <div class="value"><?php echo htmlspecialchars($researcherInfo['home_unit'] ?? 'Not specified'); ?></div>
                                </div>
                            </div>
                            <div class="routing-info <?php echo $routingPreview['escalated'] ? 'routing-escalated' : ($isCoordinatorSubmitter ? 'routing-peer' : ''); ?>">
                                <?php if ($isCoordinatorSubmitter): ?>
                                    <i class="fa fa-shield-halved"></i>
                                <?php else: ?>
                                    <i class="fa fa-route"></i>
                                <?php endif; ?>
                                <?php echo $routingPreview['message']; ?>
                            </div>
                            <?php if ($isCoordinatorSubmitter): ?>
                            <input type="hidden" name="is_coordinator_submission" value="1">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="card-actions">
                    <div></div>
                    <button type="button" class="btn btn-primary" id="nextStep1" disabled>
                        Next <i class="fa fa-arrow-right" style="margin-left: 6px;"></i>
                    </button>
                </div>
            </div>
            

            <!-- STEP 2: Submission Details -->
            <div class="form-section" id="step2">
                <div class="form-card">
                    <div class="form-card-header">
                        <h5><i class="fa fa-file-lines"></i> Research Details</h5>
                    </div>
                    <div class="form-card-body">
                        <!-- Title -->
                        <div class="form-group">
                            <label for="title" class="form-label required">Research Title</label>
                            <input type="text" class="form-control" id="title" name="title" 
                                   value="<?php echo $editMode ? htmlspecialchars($submission['title']) : ''; ?>"
                                   placeholder="Enter the complete title of your research project" required>
                            <div class="form-text">Provide a clear, descriptive title for your research project.</div>
                        </div>
                        
                        <!-- Abstract -->
                        <div class="form-group">
                            <label for="abstract" class="form-label">Abstract / Summary</label>
                            <textarea class="form-control auto-expand" id="abstract" name="abstract" rows="5"
                                      placeholder="Provide a brief summary of your research including the problem, objectives, methodology, and expected outcomes..."><?php echo $editMode ? htmlspecialchars($submission['abstract'] ?? '') : ''; ?></textarea>
                            <div class="form-text">A concise overview of the research (200-300 words recommended).</div>
                        </div>
                        
                        <!-- Objectives -->
                        <div class="form-group">
                            <label for="objectives" class="form-label required">Research Objectives</label>
                            <textarea class="form-control auto-expand" id="objectives" name="objectives" rows="5"
                                      placeholder="General Objective:&#10;• State the main goal of the research&#10;&#10;Specific Objectives:&#10;• Objective 1&#10;• Objective 2&#10;• Objective 3" required><?php echo $editMode ? htmlspecialchars($submission['objectives'] ?? '') : ''; ?></textarea>
                            <div class="form-text">State the general and specific objectives of the research.</div>
                        </div>
                        
                        <!-- Methodology (for proposals) -->
                        <div class="form-group" id="methodologySection">
                            <label for="methodology" class="form-label">Methodology</label>
                            <textarea class="form-control auto-expand" id="methodology" name="methodology" rows="5"
                                      placeholder="Describe your research methodology including:&#10;• Research design&#10;• Data collection methods&#10;• Sampling techniques&#10;• Data analysis procedures"><?php echo $editMode ? htmlspecialchars($submission['methodology'] ?? '') : ''; ?></textarea>
                            <div class="form-text">Describe the research design, data collection, and analysis methods.</div>
                        </div>
                        
                        <!-- Expected Outcomes -->
                        <div class="form-group" id="outcomesSection" style="margin-bottom: 0;">
                            <label for="expected_outcomes" class="form-label">Expected Outcomes</label>
                            <textarea class="form-control auto-expand" id="expected_outcomes" name="expected_outcomes" rows="4"
                                      placeholder="List the expected outputs and outcomes:&#10;• Research output (paper, patent, etc.)&#10;• Potential impact on the field&#10;• Practical applications"><?php echo $editMode ? htmlspecialchars($submission['expected_outcomes'] ?? '') : ''; ?></textarea>
                            <div class="form-text">What do you expect to achieve or produce from this research?</div>
                        </div>
                    </div>
                </div>
                
                <!-- Timeline Section -->
                <div class="form-card" id="timelineCard">
                    <div class="form-card-header">
                        <h5><i class="fa fa-calendar-days"></i> Project Timeline</h5>
                    </div>
                    <div class="form-card-body">
                        <div class="form-row">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="proposed_start_date" class="form-label">Proposed Start Date</label>
                                <input type="date" class="form-control" id="proposed_start_date" name="proposed_start_date"
                                       value="<?php echo $editMode ? ($submission['proposed_start_date'] ?? '') : ''; ?>">
                                <div class="form-text">When do you plan to start the research?</div>
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="proposed_end_date" class="form-label">Proposed End Date</label>
                                <input type="date" class="form-control" id="proposed_end_date" name="proposed_end_date"
                                       value="<?php echo $editMode ? ($submission['proposed_end_date'] ?? '') : ''; ?>">
                                <div class="form-text">Expected completion date of the research.</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Budget Section -->
                <div class="form-card" id="budgetCard">
                    <div class="form-card-header">
                        <h5><i class="fa fa-money-bill-wave"></i> Budget Information</h5>
                    </div>
                    <div class="form-card-body">
                        <div class="form-group" style="margin-bottom: 0; max-width: 400px;">
                            <label for="total_budget" class="form-label">Declared Total Budget</label>
                            <div class="input-group">
                                <span class="input-group-text">₱</span>
                                <input type="number" class="form-control" id="total_budget" name="total_budget" 
                                       step="0.01" min="0"
                                       value="<?php echo $editMode ? ($submission['total_budget'] ?? '') : ''; ?>"
                                       placeholder="0.00">
                            </div>
                            <div class="form-text">Enter the estimated total budget for the research project (optional).</div>
                        </div>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button type="button" class="btn btn-outline-secondary" id="prevStep2">
                        <i class="fa fa-arrow-left" style="margin-right: 6px;"></i>Previous
                    </button>
                    <button type="button" class="btn btn-primary" id="nextStep2">
                        Next <i class="fa fa-arrow-right" style="margin-left: 6px;"></i>
                    </button>
                </div>
            </div>

            <!-- STEP 3: Attachments -->
            <div class="form-section" id="step3">
                <div class="form-card">
                    <div class="form-card-header">
                        <h5><i class="fa fa-paperclip"></i> Supporting Documents</h5>
                    </div>
                    <div class="form-card-body">
                        <!-- Required Attachments Info -->
                        <div class="attachment-requirements" id="attachmentRequirements">
                            <div class="requirements-header">
                                <i class="fa fa-clipboard-list"></i>
                                <span>Required Documents</span>
                            </div>
                            <ul id="requiredAttachmentsList">
                                <li><i class="fa fa-file-pdf"></i> Research Proposal Document (PDF format recommended)</li>
                                <li><i class="fa fa-file-alt"></i> Supporting documents (if any)</li>
                            </ul>
                        </div>
                        
                        <!-- Upload Dropzone -->
                        <div class="attachment-dropzone" id="dropzone">
                            <div class="dropzone-icon">
                                <i class="fa fa-cloud-arrow-up"></i>
                            </div>
                            <div class="dropzone-text">
                                <p>Drag and drop files here</p>
                                <span>or</span>
                                <button type="button" class="btn-browse">Browse Files</button>
                            </div>
                            <div class="dropzone-hint">
                                Supported: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, JPG, PNG (Max 50MB per file)
                            </div>
                            <input type="file" id="fileInput" name="attachments[]" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png" style="display: none;">
                        </div>
                        
                        <!-- Attachment List -->
                        <div class="attachment-list" id="attachmentList">
                            <?php if ($editMode && !empty($submission['attachments'])): ?>
                            <?php foreach ($submission['attachments'] as $attachment): ?>
                            <div class="attachment-item existing" data-id="<?php echo $attachment['id']; ?>">
                                <div class="file-icon-wrapper">
                                    <i class="fa fa-file-pdf"></i>
                                </div>
                                <div class="file-info">
                                    <div class="file-name"><?php echo htmlspecialchars($attachment['original_name']); ?></div>
                                    <div class="file-size"><?php echo number_format($attachment['file_size'] / 1024, 2); ?> KB</div>
                                </div>
                                <button type="button" class="btn-remove-file remove-attachment" data-id="<?php echo $attachment['id']; ?>">
                                    <i class="fa fa-times"></i>
                                </button>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button type="button" class="btn btn-outline-secondary" id="prevStep3">
                        <i class="fa fa-arrow-left" style="margin-right: 6px;"></i>Previous
                    </button>
                    <button type="button" class="btn btn-primary" id="nextStep3">
                        Next <i class="fa fa-arrow-right" style="margin-left: 6px;"></i>
                    </button>
                </div>
            </div>

            <!-- STEP 4: Review & Submit -->
            <div class="form-section" id="step4">
                <div class="form-card">
                    <div class="form-card-header">
                        <h5><i class="fa fa-check-double"></i> Review & Submit</h5>
                    </div>
                    <div class="form-card-body">
                        <!-- Review Summary -->
                        <div class="review-summary">
                            <div class="review-section">
                                <div class="review-section-header">
                                    <i class="fa fa-file-lines"></i>
                                    <span>Submission Details</span>
                                </div>
                                <div class="review-grid">
                                    <div class="review-item">
                                        <span class="review-label">Submission Type</span>
                                        <span class="review-value" id="reviewType">Research Proposal</span>
                                    </div>
                                    <div class="review-item">
                                        <span class="review-label">Research Title</span>
                                        <span class="review-value" id="reviewTitle">-</span>
                                    </div>
                                </div>
                            </div>

                            <div class="review-section">
                                <div class="review-section-header">
                                    <i class="fa fa-user"></i>
                                    <span>Researcher Information</span>
                                </div>
                                <div class="review-grid two-col">
                                    <div class="review-item">
                                        <span class="review-label">Researcher</span>
                                        <span class="review-value"><?php echo htmlspecialchars($researcherInfo['name']); ?></span>
                                    </div>
                                    <div class="review-item">
                                        <span class="review-label">Unit / Department</span>
                                        <span class="review-value"><?php echo htmlspecialchars($researcherInfo['home_unit'] ?? 'Not specified'); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="review-section">
                                <div class="review-section-header">
                                    <i class="fa fa-calendar-days"></i>
                                    <span>Timeline & Budget</span>
                                </div>
                                <div class="review-grid two-col">
                                    <div class="review-item">
                                        <span class="review-label">Proposed Timeline</span>
                                        <span class="review-value" id="reviewTimeline">-</span>
                                    </div>
                                    <div class="review-item">
                                        <span class="review-label">Declared Budget</span>
                                        <span class="review-value" id="reviewBudget">-</span>
                                    </div>
                                </div>
                            </div>

                            <div class="review-section">
                                <div class="review-section-header">
                                    <i class="fa fa-paperclip"></i>
                                    <span>Attachments</span>
                                </div>
                                <div class="review-attachments" id="reviewAttachments">
                                    <span class="no-attachments">No files attached</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Routing Info -->
                        <div class="routing-notice <?php echo $routingPreview['escalated'] ? 'routing-escalated' : ($isCoordinatorSubmitter ? 'routing-peer' : ''); ?>">
                            <div class="routing-icon">
                                <?php if ($isCoordinatorSubmitter): ?>
                                <i class="fa fa-shield-halved"></i>
                                <?php else: ?>
                                <i class="fa fa-route"></i>
                                <?php endif; ?>
                            </div>
                            <div class="routing-content">
                                <strong>Workflow Routing</strong>
                                <?php if ($isCoordinatorSubmitter && $routingPreview['escalated']): ?>
                                <p>Upon submission, your proposal will be <strong>escalated directly to the Research Office</strong> for endorsement-equivalent review. <em>(No peer coordinator available in your unit)</em></p>
                                <?php elseif ($isCoordinatorSubmitter): ?>
                                <p>Upon submission, your proposal will be routed to <strong><?php echo htmlspecialchars($routingPreview['peer_coordinator_name']); ?></strong> (peer coordinator) for validation and endorsement. <em>(Self-endorsement is not allowed)</em></p>
                                <?php else: ?>
                                <p>Upon submission, your proposal will be automatically routed to the <strong><?php echo ucfirst($researcherType); ?> Research Coordinator</strong> assigned to your unit for validation and endorsement.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if ($isCoordinatorSubmitter): ?>
                        <!-- Coordinator Submission Notice -->
                        <div class="coordinator-submission-notice" style="margin-top: 16px; padding: 12px 16px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; font-size: 13px; color: #0369a1;">
                            <i class="fa fa-info-circle" style="margin-right: 8px;"></i>
                            <strong>Segregation of Duties:</strong> As a Research Coordinator, you cannot endorse your own submissions. This ensures audit integrity and RMIS compliance.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button type="button" class="btn btn-outline-secondary" id="prevStep4">
                        <i class="fa fa-arrow-left" style="margin-right: 6px;"></i>Previous
                    </button>
                    <div class="submit-actions">
                        <button type="submit" name="save_draft" class="btn btn-outline-secondary" id="saveDraft">
                            <i class="fa fa-save" style="margin-right: 6px;"></i>Save as Draft
                        </button>
                        <button type="submit" name="submit_now" class="btn btn-success" id="submitNow">
                            <i class="fa fa-paper-plane" style="margin-right: 6px;"></i>
                            <?php echo $routingPreview['escalated'] ? 'Submit to Research Office' : 'Submit for Review'; ?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
        
        <?php endif; ?>
    </div>

    <script>
    // Initialize function - works both for direct load and SPA injection
    (function initSubmissionForm() {
        // Form elements
        const form = document.getElementById('submissionForm');
        const steps = document.querySelectorAll('.form-section');
        const stepIndicators = document.querySelectorAll('.step-indicator .step');
        const stepLines = document.querySelectorAll('.step-indicator .step-line');
        let currentStep = 1;
        
        // Auto-expand textareas
        function autoExpand(textarea) {
            // Reset height to auto to get the correct scrollHeight
            textarea.style.height = 'auto';
            // Set height to scrollHeight (content height)
            const minHeight = 120; // minimum height in pixels
            const newHeight = Math.max(textarea.scrollHeight, minHeight);
            textarea.style.height = newHeight + 'px';
        }
        
        // Initialize auto-expand for all textareas with the class
        const autoExpandTextareas = document.querySelectorAll('textarea.auto-expand');
        autoExpandTextareas.forEach(textarea => {
            // Set initial height based on content
            autoExpand(textarea);
            
            // Add event listeners for input and paste
            textarea.addEventListener('input', () => autoExpand(textarea));
            textarea.addEventListener('paste', () => {
                setTimeout(() => autoExpand(textarea), 0);
            });
        });
        
        // Submission type selection
        const typeCards = document.querySelectorAll('.submission-type-card');
        const typeInput = document.getElementById('submission_type_id');
        const nextStep1 = document.getElementById('nextStep1');
        
        typeCards.forEach(card => {
            card.addEventListener('click', function(e) {
                e.preventDefault();
                
                typeCards.forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
                typeInput.value = this.dataset.typeId;
                
                // Enable continue button
                nextStep1.disabled = false;
                
                // Update form requirements based on type
                updateFormRequirements(this.dataset);
            });
        });
        
        function updateFormRequirements(typeData) {
            const timelineCard = document.getElementById('timelineCard');
            const budgetCard = document.getElementById('budgetCard');
            const methodologySection = document.getElementById('methodologySection');
            
            // Show/hide sections based on submission type
            if (typeData.typeCode === 'proposal') {
                methodologySection.style.display = 'block';
                timelineCard.style.display = 'block';
                budgetCard.style.display = 'block';
            } else if (typeData.typeCode === 'extension') {
                methodologySection.style.display = 'none';
                timelineCard.style.display = 'block';
                budgetCard.style.display = 'block';
            } else if (typeData.typeCode === 'output') {
                methodologySection.style.display = 'none';
                timelineCard.style.display = 'none';
                budgetCard.style.display = 'none';
            } else {
                methodologySection.style.display = 'block';
                timelineCard.style.display = 'block';
                budgetCard.style.display = 'none';
            }
            
            // Update attachment requirements
            updateAttachmentRequirements(typeData.typeCode);
        }
        
        function updateAttachmentRequirements(typeCode) {
            const list = document.getElementById('requiredAttachmentsList');
            let requirements = [];
            
            switch(typeCode) {
                case 'proposal':
                    requirements = ['Proposal Document (PDF)', 'Ethics Clearance (if applicable)', 'Budget Plan'];
                    break;
                case 'ongoing':
                    requirements = ['Progress Report', 'Financial Report (if applicable)'];
                    break;
                case 'completed':
                    requirements = ['Final Report', 'Financial Report', 'Research Output/Publication'];
                    break;
                case 'extension':
                    requirements = ['Extension Request Letter', 'Justification Document', 'Revised Timeline'];
                    break;
                case 'output':
                    requirements = ['Publication/Output Document', 'Certificate/Award (if applicable)'];
                    break;
                default:
                    requirements = ['Supporting Document'];
            }
            
            list.innerHTML = requirements.map(r => `<li>${r}</li>`).join('');
        }
        
        // Step navigation
        function showStep(step) {
            steps.forEach((s, index) => {
                s.classList.toggle('active', index === step - 1);
            });
            
            stepIndicators.forEach((indicator, index) => {
                indicator.classList.remove('active', 'completed');
                if (index < step - 1) {
                    indicator.classList.add('completed');
                } else if (index === step - 1) {
                    indicator.classList.add('active');
                }
            });
            
            stepLines.forEach((line, index) => {
                line.classList.toggle('completed', index < step - 1);
            });
            
            currentStep = step;
            window.scrollTo(0, 0);
        }
        
        // Navigation buttons
        document.getElementById('nextStep1')?.addEventListener('click', () => showStep(2));
        document.getElementById('prevStep2')?.addEventListener('click', () => showStep(1));
        document.getElementById('nextStep2')?.addEventListener('click', () => {
            if (validateStep2()) showStep(3);
        });
        document.getElementById('prevStep3')?.addEventListener('click', () => showStep(2));
        document.getElementById('nextStep3')?.addEventListener('click', () => {
            updateReviewSummary();
            showStep(4);
        });
        document.getElementById('prevStep4')?.addEventListener('click', () => showStep(3));
        
        function validateStep2() {
            const title = document.getElementById('title');
            const objectives = document.getElementById('objectives');
            
            if (!title.value.trim()) {
                alert('Please enter a research title.');
                title.focus();
                return false;
            }
            
            if (!objectives.value.trim()) {
                alert('Please enter research objectives.');
                objectives.focus();
                return false;
            }
            
            return true;
        }
        
        function updateReviewSummary() {
            const selectedType = document.querySelector('.submission-type-card.selected h6');
            document.getElementById('reviewType').textContent = selectedType ? selectedType.textContent : 'Research Proposal';
            document.getElementById('reviewTitle').textContent = document.getElementById('title').value || '-';
            
            const startDate = document.getElementById('proposed_start_date').value;
            const endDate = document.getElementById('proposed_end_date').value;
            if (startDate && endDate) {
                const startFormatted = new Date(startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                const endFormatted = new Date(endDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                document.getElementById('reviewTimeline').textContent = `${startFormatted} - ${endFormatted}`;
            } else {
                document.getElementById('reviewTimeline').textContent = 'Not specified';
            }
            
            const budget = document.getElementById('total_budget').value;
            document.getElementById('reviewBudget').textContent = 
                budget ? `₱${parseFloat(budget).toLocaleString('en-PH', {minimumFractionDigits: 2})}` : 'Not specified';
            
            // Update attachments section with badges
            const attachmentItems = document.querySelectorAll('#attachmentList .attachment-item');
            const reviewAttachments = document.getElementById('reviewAttachments');
            
            if (attachmentItems.length === 0) {
                reviewAttachments.innerHTML = '<span class="no-attachments">No files attached</span>';
            } else {
                let badgesHtml = '';
                attachmentItems.forEach(item => {
                    const fileName = item.querySelector('.file-name')?.textContent || 'Unknown file';
                    const shortName = fileName.length > 25 ? fileName.substring(0, 22) + '...' : fileName;
                    badgesHtml += `<span class="attachment-badge"><i class="fa fa-file"></i>${shortName}</span>`;
                });
                reviewAttachments.innerHTML = badgesHtml;
            }
        }
        
        // File upload handling
        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('fileInput');
        const attachmentList = document.getElementById('attachmentList');
        const browseBtn = dropzone?.querySelector('.btn-browse');
        
        // Handle dropzone click (exclude browse button to avoid double trigger)
        dropzone?.addEventListener('click', (e) => {
            if (e.target !== browseBtn && !browseBtn?.contains(e.target)) {
                fileInput.click();
            }
        });
        
        // Handle browse button click
        browseBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            fileInput.click();
        });
        
        dropzone?.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        
        dropzone?.addEventListener('dragleave', () => {
            dropzone.classList.remove('dragover');
        });
        
        dropzone?.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });
        
        fileInput?.addEventListener('change', () => {
            handleFiles(fileInput.files);
        });
        
        function handleFiles(files) {
            Array.from(files).forEach(file => {
                if (file.size > 52428800) { // 50MB
                    alert(`File "${file.name}" exceeds 50MB limit.`);
                    return;
                }
                
                // Determine file icon based on extension
                const ext = file.name.split('.').pop().toLowerCase();
                let iconClass = 'fa-file';
                let iconBg = 'linear-gradient(135deg, #6b7280, #4b5563)';
                
                if (['pdf'].includes(ext)) {
                    iconClass = 'fa-file-pdf';
                    iconBg = 'linear-gradient(135deg, #ef4444, #dc2626)';
                } else if (['doc', 'docx'].includes(ext)) {
                    iconClass = 'fa-file-word';
                    iconBg = 'linear-gradient(135deg, #3b82f6, #2563eb)';
                } else if (['xls', 'xlsx'].includes(ext)) {
                    iconClass = 'fa-file-excel';
                    iconBg = 'linear-gradient(135deg, #22c55e, #16a34a)';
                } else if (['ppt', 'pptx'].includes(ext)) {
                    iconClass = 'fa-file-powerpoint';
                    iconBg = 'linear-gradient(135deg, #f97316, #ea580c)';
                } else if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
                    iconClass = 'fa-file-image';
                    iconBg = 'linear-gradient(135deg, #8b5cf6, #7c3aed)';
                }
                
                const item = document.createElement('div');
                item.className = 'attachment-item';
                item.innerHTML = `
                    <div class="file-icon-wrapper" style="background: ${iconBg}">
                        <i class="fa ${iconClass}"></i>
                    </div>
                    <div class="file-info">
                        <div class="file-name">${file.name}</div>
                        <div class="file-size">${(file.size / 1024).toFixed(2)} KB</div>
                    </div>
                    <button type="button" class="btn-remove-file remove-new-attachment">
                        <i class="fa fa-times"></i>
                    </button>
                `;
                
                item.querySelector('.remove-new-attachment').addEventListener('click', () => {
                    item.remove();
                });
                
                attachmentList.appendChild(item);
            });
        }
        
        // Remove existing attachment
        document.querySelectorAll('.remove-attachment').forEach(btn => {
            btn.addEventListener('click', function() {
                if (confirm('Remove this attachment?')) {
                    this.closest('.attachment-item').remove();
                }
            });
        });
        
        // Form submission
        form?.addEventListener('submit', function(e) {
            const submitType = e.submitter.name;
            
            if (submitType === 'submit_now') {
                if (!confirm('Submit this record to your coordinator for review? You will not be able to edit it once submitted.')) {
                    e.preventDefault();
                    return;
                }
            }
            
            // Add action input
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'submit_action';
            actionInput.value = submitType === 'submit_now' ? 'submit' : 'draft';
            form.appendChild(actionInput);
        });
        
        // Auto-select type if in edit mode
        const selectedCard = document.querySelector('.submission-type-card.selected');
        if (selectedCard) {
            updateFormRequirements(selectedCard.dataset);
            nextStep1.disabled = false;
        }
    })();
    </script>
