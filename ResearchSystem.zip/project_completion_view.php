<?php
/**
 * project_completion_view.php
 * 
 * Unified completion report view page for:
 * - Researchers: View their completion report details, submit drafts
 * - Coordinators: Review, endorse, or return for revision
 * - Admins: Final approval/rejection to complete the project
 * 
 * Displays:
 * - Completion report details
 * - Project summary
 * - Workflow status and timeline
 * - Available actions based on role and status
 * - Comments and audit history
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$employeeId = $_SESSION['employee_id'] ?? null;
$isSpa = isSpaRequest();

// Get completion report ID
$reportId = (int)($_GET['id'] ?? 0);
if (!$reportId) {
    if ($isSpa) {
        echo '<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> Invalid Completion Report ID - No report ID was provided in the URL.</div>';
        exit;
    }
    header("Location: researcher_projects.php");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Initialize service
$projectService = new ProjectService($conn);
$report = $projectService->getCompletionReport($reportId);

if (!$report) {
    echo '<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> Completion report not found.</div>';
    exit;
}

// Get project details
$project = $projectService->getProject($report['project_id']);
if (!$project) {
    echo '<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> Associated project not found.</div>';
    exit;
}

// Access verification
$isOwner = ($project['created_by'] == $userId || $project['researcher_user_id'] == $userId);
$canView = false;

if ($isOwner) {
    $canView = true;
} elseif ($userRole === 'admin') {
    $canView = true;
} elseif ($userRole === 'coordinator') {
    $canView = in_array($report['status'], ['submitted', 'under_coordinator_review', 'endorsed', 'under_ro_review', 'approved', 'rejected']);
}

if (!$canView) {
    echo '<div class="alert alert-danger"><i class="fa fa-lock"></i> You are not authorized to view this completion report.</div>';
    exit;
}

// Get audit log from workflow_history
$auditLog = [];
$auditQuery = $conn->prepare("
    SELECT wh.*, wh.performed_by_name
    FROM workflow_history wh
    WHERE wh.submission_id = ? AND wh.action_type LIKE '%completion%'
    ORDER BY wh.created_at DESC
    LIMIT 20
");
$auditQuery->bind_param("i", $report['project_id']);
$auditQuery->execute();
$auditResult = $auditQuery->get_result();
while ($row = $auditResult->fetch_assoc()) {
    $auditLog[] = $row;
}
$auditQuery->close();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

function formatStatusLabel($status) {
    $labels = [
        'draft' => 'Draft',
        'submitted' => 'Submitted',
        'under_coordinator_review' => 'Under Review',
        'endorsed' => 'Endorsed',
        'under_ro_review' => 'RO Review',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
        'returned_for_revision' => 'Returned'
    ];
    return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
}

// Status timeline configuration
$statusTimeline = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'color' => '#6b7280'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'color' => '#3b82f6'],
    'under_coordinator_review' => ['label' => 'Coordinator Review', 'icon' => 'fa-user-tie', 'color' => '#f59e0b'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'color' => '#8b5cf6'],
    'under_ro_review' => ['label' => 'RO Review', 'icon' => 'fa-building', 'color' => '#ec4899'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-thumbs-up', 'color' => '#10b981'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'color' => '#ef4444'],
    'returned_for_revision' => ['label' => 'Returned', 'icon' => 'fa-undo', 'color' => '#f97316']
];

$currentStatusConfig = $statusTimeline[$report['status']] ?? ['label' => 'Unknown', 'icon' => 'fa-question', 'color' => '#6b7280'];

// Determine available actions
$canSubmit = $isOwner && $report['status'] === 'draft';
$canCoordinatorAct = ($userRole === 'coordinator') && in_array($report['status'], ['submitted', 'under_coordinator_review']);
$canAdminAct = ($userRole === 'admin') && in_array($report['status'], ['endorsed', 'under_ro_review']);
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   COMPLETION VIEW - UNIFIED DESIGN
   ============================================ */

.completion-header-banner {
    background: linear-gradient(135deg, #059669 0%, #10b981 50%, #34d399 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(5, 150, 105, 0.3);
}

.completion-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.completion-header-left {
    flex: 1;
}

.completion-header-left h1 {
    font-size: 24px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.3;
}

.completion-header-left .ref-number {
    font-family: 'Consolas', monospace;
    font-size: 13px;
    color: rgba(255,255,255,0.9);
    background: rgba(255,255,255,0.15);
    padding: 4px 10px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 12px;
}

.completion-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.completion-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255,255,255,0.2);
    color: white;
}

.completion-header-right {
    text-align: right;
}

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted, .status-pending { color: #2563eb; }
.status-reviewing, .status-under_coordinator_review, .status-under_ro_review { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-rejected { color: #dc2626; }
.status-returned, .status-returned_for_revision { color: #ea580c; }

/* Content Layout */
.completion-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.completion-main { display: flex; flex-direction: column; gap: 24px; }
.completion-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: #059669; }

.section-body { padding: 20px; }

/* Detail Rows */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.5;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

.detail-value.text-muted { color: #9ca3af; }

/* Status Timeline */
.status-timeline {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 16px 20px;
    background: #f9fafb;
    border-radius: 8px;
    overflow-x: auto;
}

.timeline-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    min-width: 80px;
    flex: 1;
    position: relative;
}

.timeline-step::after {
    content: '';
    position: absolute;
    top: 16px;
    right: -50%;
    width: 100%;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
}

.timeline-step:last-child::after { display: none; }

.timeline-step.completed::after { background: #10b981; }
.timeline-step.current::after { background: linear-gradient(90deg, #10b981 50%, #e5e7eb 50%); }

.timeline-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    color: #9ca3af;
    font-size: 12px;
    position: relative;
    z-index: 1;
}

.timeline-step.completed .timeline-icon { background: #d1fae5; color: #059669; }
.timeline-step.current .timeline-icon { background: #dbeafe; color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2); }
.timeline-step.rejected .timeline-icon { background: #fee2e2; color: #dc2626; }

.timeline-label {
    font-size: 10px;
    color: #6b7280;
    text-align: center;
    white-space: nowrap;
}

.timeline-step.current .timeline-label { color: #1f2937; font-weight: 600; }

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.action-btn i { font-size: 14px; }

.btn-primary-action {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    color: white;
}
.btn-primary-action:hover {
    background: linear-gradient(135deg, #047857 0%, #059669 100%);
    transform: translateY(-1px);
}

.btn-submit { background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); color: white; }
.btn-submit:hover { background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); }

.btn-endorse { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%); color: white; }
.btn-endorse:hover { background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%); }

.btn-approve { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-approve:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-return { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.btn-return:hover { background: #fde68a; }

.btn-reject { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.btn-reject:hover { background: #fecaca; }

.btn-back { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }
.btn-back:hover { background: #e5e7eb; }

/* Project Info Card */
.project-link-card {
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
    border: 1px solid #bbf7d0;
    border-radius: 10px;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    color: inherit;
}

.project-link-card:hover {
    background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
}

.project-link-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    background: #059669;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.project-link-info {
    flex: 1;
}

.project-link-label {
    font-size: 11px;
    color: #6b7280;
    text-transform: uppercase;
    font-weight: 600;
}

.project-link-title {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    margin-top: 2px;
}

/* Audit Log */
.audit-list {
    max-height: 300px;
    overflow-y: auto;
}

.audit-item {
    display: flex;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #f3f4f6;
}

.audit-item:last-child { border-bottom: none; }

.audit-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    color: #6b7280;
    font-size: 12px;
    flex-shrink: 0;
}

.audit-content { flex: 1; }

.audit-action {
    font-size: 13px;
    color: #1f2937;
    font-weight: 500;
}

.audit-meta {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 2px;
}

/* Review Notes */
.review-notes {
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 8px;
    padding: 16px;
    margin-top: 16px;
}

.review-notes h4 {
    font-size: 13px;
    font-weight: 600;
    color: #92400e;
    margin: 0 0 8px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.review-notes p {
    font-size: 13px;
    color: #78350f;
    margin: 0;
    line-height: 1.5;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-header.bg-primary { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%); }
.modal-header.bg-primary h3 { color: white; }
.modal-header.bg-success { background: linear-gradient(135deg, #059669 0%, #10b981 100%); }
.modal-header.bg-success h3 { color: white; }
.modal-header.bg-warning { background: #fef3c7; }
.modal-header.bg-danger { background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); }
.modal-header.bg-danger h3 { color: white; }

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-header.bg-primary .modal-close,
.modal-header.bg-success .modal-close,
.modal-header.bg-danger .modal-close { color: rgba(255,255,255,0.8); }

.modal-body { padding: 24px; }
.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

/* Modal Buttons */
.modal-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s ease;
}

.modal-btn i { font-size: 13px; }

.modal-btn-secondary {
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
}
.modal-btn-secondary:hover {
    background: #e5e7eb;
    border-color: #9ca3af;
}

.modal-btn-primary {
    background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(124, 58, 237, 0.3);
}
.modal-btn-primary:hover {
    background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4);
}

.modal-btn-success {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(5, 150, 105, 0.3);
}
.modal-btn-success:hover {
    background: linear-gradient(135deg, #047857 0%, #059669 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(5, 150, 105, 0.4);
}

.modal-btn-warning {
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(217, 119, 6, 0.3);
}
.modal-btn-warning:hover {
    background: linear-gradient(135deg, #b45309 0%, #d97706 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(217, 119, 6, 0.4);
}

.modal-btn-danger {
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
}
.modal-btn-danger:hover {
    background: linear-gradient(135deg, #b91c1c 0%, #dc2626 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
}

/* Validation Checklist */
.validation-checklist {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 20px;
}

.validation-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: #f9fafb;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s;
}

.validation-item:hover { background: #f3f4f6; }

.validation-item input[type="checkbox"] {
    width: 20px;
    height: 20px;
    accent-color: #059669;
}

.validation-item label {
    font-size: 14px;
    color: #374151;
    cursor: pointer;
    flex: 1;
}

/* Responsive */
@media (max-width: 1024px) {
    .completion-content {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .completion-header-content {
        flex-direction: column;
    }
    
    .completion-header-right {
        text-align: left;
    }
    
    .detail-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="content">
    <!-- Header Banner -->
    <div class="completion-header-banner">
        <div class="completion-header-content">
            <div class="completion-header-left">
                <?php if ($project['reference_number']): ?>
                    <span class="ref-number"><?= s($project['reference_number']) ?></span>
                <?php endif; ?>
                <h1><i class="fa fa-flag-checkered"></i> Completion Report</h1>
                <div class="completion-header-badges">
                    <span class="completion-badge">
                        <i class="fa fa-project-diagram"></i>
                        <?= s($project['title']) ?>
                    </span>
                    <span class="completion-badge">
                        <i class="fa fa-calendar"></i>
                        <?= date('M d, Y', strtotime($report['actual_completion_date'])) ?>
                    </span>
                </div>
            </div>
            <div class="completion-header-right">
                <span class="status-badge-large status-<?= s($report['status']) ?>">
                    <i class="fa <?= $currentStatusConfig['icon'] ?>"></i>
                    <?= formatStatusLabel($report['status']) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Status Timeline -->
    <div class="section-card" style="margin-bottom: 24px;">
        <div class="status-timeline">
            <?php
            $workflowSteps = [
                'draft' => 'Draft',
                'submitted' => 'Submitted',
                'under_coordinator_review' => 'Coord. Review',
                'endorsed' => 'Endorsed',
                'under_ro_review' => 'RO Review',
                'approved' => 'Completed'
            ];
            
            $currentFound = false;
            $isRejected = $report['status'] === 'rejected';
            $isReturned = $report['status'] === 'returned_for_revision';
            
            foreach ($workflowSteps as $stepKey => $stepLabel):
                $stepClass = '';
                if ($isRejected && $stepKey === 'approved') {
                    $stepClass = 'rejected';
                    $stepLabel = 'Rejected';
                } elseif (!$currentFound) {
                    if ($stepKey === $report['status']) {
                        $stepClass = 'current';
                        $currentFound = true;
                    } elseif ($isReturned && $stepKey === 'draft') {
                        $stepClass = 'current';
                        $currentFound = true;
                        $stepLabel = 'Returned';
                    } else {
                        $stepClass = 'completed';
                    }
                }
            ?>
            <div class="timeline-step <?= $stepClass ?>">
                <div class="timeline-icon">
                    <i class="fa <?= $stepClass === 'completed' ? 'fa-check' : ($stepClass === 'rejected' ? 'fa-times' : ($statusTimeline[$stepKey]['icon'] ?? 'fa-circle')) ?>"></i>
                </div>
                <span class="timeline-label"><?= $stepLabel ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="completion-content">
        <!-- Main Content -->
        <div class="completion-main">
            <!-- Executive Summary -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-file-alt"></i> Executive Summary</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value" style="line-height: 1.7;">
                        <?= nl2br(s($report['executive_summary'])) ?>
                    </div>
                </div>
            </div>

            <!-- Key Findings -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-lightbulb"></i> Key Findings</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value" style="line-height: 1.7;">
                        <?= nl2br(s($report['key_findings'])) ?>
                    </div>
                </div>
            </div>

            <!-- Deliverables -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-box-open"></i> Deliverables Produced</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value" style="line-height: 1.7;">
                        <?= nl2br(s($report['deliverables_produced'])) ?>
                    </div>
                </div>
            </div>

            <!-- Additional Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-info-circle"></i> Report Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Actual Completion Date</span>
                            <span class="detail-value"><?= date('F d, Y', strtotime($report['actual_completion_date'])) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Date Submitted</span>
                            <span class="detail-value"><?= date('F d, Y', strtotime($report['created_at'])) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Submitted By</span>
                            <span class="detail-value"><?= s($report['submitted_by_name'] ?? 'Unknown') ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Report Status</span>
                            <span class="detail-value">
                                <span class="report-status status-<?= s($report['status']) ?>" style="font-size: 12px;">
                                    <?= formatStatusLabel($report['status']) ?>
                                </span>
                            </span>
                        </div>
                        <?php if ($report['coordinator_reviewed_by']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Coordinator Review</span>
                            <span class="detail-value">
                                <?= s($report['coordinator_name'] ?? 'Coordinator') ?>
                                <?php if ($report['coordinator_reviewed_at']): ?>
                                    <br><small style="color: #6b7280;"><?= date('M d, Y h:i A', strtotime($report['coordinator_reviewed_at'])) ?></small>
                                <?php endif; ?>
                            </span>
                        </div>
                        <?php endif; ?>
                        <?php if ($report['ro_reviewed_by']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Research Office Review</span>
                            <span class="detail-value">
                                <?= s($report['ro_reviewer_name'] ?? 'Research Office') ?>
                                <?php if ($report['ro_reviewed_at']): ?>
                                    <br><small style="color: #6b7280;"><?= date('M d, Y h:i A', strtotime($report['ro_reviewed_at'])) ?></small>
                                <?php endif; ?>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($report['coordinator_remarks'])): ?>
                    <div class="review-notes" style="margin-top: 20px;">
                        <h4><i class="fa fa-comment"></i> Coordinator Remarks</h4>
                        <p><?= nl2br(s($report['coordinator_remarks'])) ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($report['ro_remarks'])): ?>
                    <div class="review-notes" style="margin-top: 16px; background: #f0fdf4; border-color: #bbf7d0;">
                        <h4 style="color: #065f46;"><i class="fa fa-comment"></i> Research Office Remarks</h4>
                        <p style="color: #047857;"><?= nl2br(s($report['ro_remarks'])) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="completion-sidebar">
            <!-- Actions Panel -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if ($canSubmit): ?>
                            <button onclick="submitCompletion(<?= $reportId ?>)" class="action-btn btn-submit">
                                <i class="fa fa-paper-plane"></i> Submit for Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($canCoordinatorAct): ?>
                            <button onclick="openModal('endorseModal')" class="action-btn btn-endorse">
                                <i class="fa fa-check-double"></i> Endorse to Research Office
                            </button>
                            <button onclick="openModal('returnModal')" class="action-btn btn-return">
                                <i class="fa fa-undo"></i> Return for Revision
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($canAdminAct): ?>
                            <button onclick="openModal('approveModal')" class="action-btn btn-approve">
                                <i class="fa fa-check-circle"></i> Approve & Complete Project
                            </button>
                            <button onclick="openModal('rejectModal')" class="action-btn btn-reject">
                                <i class="fa fa-times-circle"></i> Reject
                            </button>
                        <?php endif; ?>
                        
                        <a href="project_view.php?id=<?= $project['id'] ?>&tab=completion" class="action-btn btn-back"
                           onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $project['id'] ?>&tab=completion',true)}">
                            <i class="fa fa-arrow-left"></i> Back to Project
                        </a>
                    </div>
                </div>
            </div>

            <!-- Project Info -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-project-diagram"></i> Project</h3>
                </div>
                <div class="section-body">
                    <a href="project_view.php?id=<?= $project['id'] ?>" class="project-link-card"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $project['id'] ?>',true)}">
                        <div class="project-link-icon">
                            <i class="fa fa-flask"></i>
                        </div>
                        <div class="project-link-info">
                            <div class="project-link-label">Parent Project</div>
                            <div class="project-link-title"><?= s($project['title']) ?></div>
                        </div>
                        <i class="fa fa-chevron-right" style="color: #9ca3af;"></i>
                    </a>
                    
                    <div class="detail-grid" style="margin-top: 16px;">
                        <div class="detail-row">
                            <span class="detail-label">Project Code</span>
                            <span class="detail-value"><?= s($project['project_code'] ?? 'N/A') ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Status</span>
                            <span class="detail-value"><?= ucfirst(str_replace('_', ' ', $project['project_status'] ?? 'N/A')) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Activity Log -->
            <?php if (!empty($auditLog)): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-history"></i> Activity</h3>
                </div>
                <div class="section-body">
                    <div class="audit-list">
                        <?php foreach ($auditLog as $log): ?>
                        <div class="audit-item">
                            <div class="audit-icon">
                                <i class="fa fa-circle"></i>
                            </div>
                            <div class="audit-content">
                                <div class="audit-action"><?= s(ucfirst(str_replace('_', ' ', $log['action_type']))) ?></div>
                                <div class="audit-meta">
                                    <?= s($log['performed_by_name'] ?? 'System') ?> • 
                                    <?= date('M d, Y h:i A', strtotime($log['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header bg-primary">
            <h3><i class="fa fa-check-double"></i> Endorse Completion Report</h3>
            <button class="modal-close" onclick="closeModal('endorseModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="endorseCompletion(event); return false;">
            <div class="modal-body">
                <p style="color: #6b7280; margin-bottom: 20px;">
                    Please verify the following before endorsing this completion report to the Research Office.
                </p>
                
                <div class="validation-checklist">
                    <div class="validation-item">
                        <input type="checkbox" id="chk_summary" name="summary_complete" value="1" required>
                        <label for="chk_summary">Executive summary is complete and accurate</label>
                    </div>
                    <div class="validation-item">
                        <input type="checkbox" id="chk_findings" name="findings_valid" value="1" required>
                        <label for="chk_findings">Key findings are properly documented</label>
                    </div>
                    <div class="validation-item">
                        <input type="checkbox" id="chk_deliverables" name="deliverables_verified" value="1" required>
                        <label for="chk_deliverables">Deliverables have been verified</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Remarks (Optional)</label>
                    <textarea id="endorse_remarks" rows="3" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                              placeholder="Add any notes for the Research Office..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('endorseModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-primary">
                    <i class="fa fa-check-double"></i> Endorse
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header bg-warning">
            <h3><i class="fa fa-undo"></i> Return for Revision</h3>
            <button class="modal-close" onclick="closeModal('returnModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="returnCompletion(event); return false;">
            <div class="modal-body">
                <div class="alert-box warning" style="background: #fef3c7; border: 1px solid #fde68a; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                    <i class="fa fa-exclamation-triangle" style="color: #d97706;"></i>
                    <span style="color: #92400e; margin-left: 8px;">This will return the completion report to the researcher for revision.</span>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Reason for Return <span style="color: #dc2626;">*</span></label>
                    <textarea id="return_reason" rows="4" required style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                              placeholder="Please explain what needs to be revised..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('returnModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-warning">
                    <i class="fa fa-undo"></i> Return for Revision
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header bg-success">
            <h3><i class="fa fa-check-circle"></i> Approve Completion Report</h3>
            <button class="modal-close" onclick="closeModal('approveModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="approveCompletion(event); return false;">
            <div class="modal-body">
                <div class="alert-box success" style="background: #d1fae5; border: 1px solid #a7f3d0; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                    <i class="fa fa-info-circle" style="color: #059669;"></i>
                    <span style="color: #065f46; margin-left: 8px;">Approving this report will mark the project as <strong>COMPLETED</strong>.</span>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Approval Notes (Optional)</label>
                    <textarea id="approve_notes" rows="3" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                              placeholder="Add any final notes..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('approveModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-success">
                    <i class="fa fa-check-circle"></i> Approve & Complete Project
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header bg-danger">
            <h3><i class="fa fa-times-circle"></i> Reject Completion Report</h3>
            <button class="modal-close" onclick="closeModal('rejectModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="rejectCompletion(event); return false;">
            <div class="modal-body">
                <div class="alert-box danger" style="background: #fee2e2; border: 1px solid #fecaca; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                    <i class="fa fa-exclamation-circle" style="color: #dc2626;"></i>
                    <span style="color: #991b1b; margin-left: 8px;">This action is final. The completion report will be rejected.</span>
                </div>
                
                <div class="form-group">
                    <label style="font-weight: 600; color: #374151; margin-bottom: 8px; display: block;">Reason for Rejection <span style="color: #dc2626;">*</span></label>
                    <textarea id="reject_reason" rows="4" required style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; resize: vertical;"
                              placeholder="Please explain why this completion report is being rejected..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('rejectModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-danger">
                    <i class="fa fa-times-circle"></i> Reject
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const reportId = <?= $reportId ?>;
const projectId = <?= $project['id'] ?>;

function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

// Close modal when clicking outside
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
});

async function submitCompletion(id) {
    if (!confirm('Submit this completion report? It will be sent to your coordinator for review.')) return;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'submit_completion',
                report_id: id
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report submitted successfully!');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

async function endorseCompletion(event) {
    event.preventDefault();
    
    const validationData = {
        summary_complete: document.getElementById('chk_summary').checked ? 1 : 0,
        findings_valid: document.getElementById('chk_findings').checked ? 1 : 0,
        deliverables_verified: document.getElementById('chk_deliverables').checked ? 1 : 0
    };
    const remarks = document.getElementById('endorse_remarks').value;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'endorse_completion',
                report_id: reportId,
                validation_data: validationData,
                remarks: remarks
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report endorsed successfully!');
            closeModal('endorseModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to endorse'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

async function returnCompletion(event) {
    event.preventDefault();
    
    const reason = document.getElementById('return_reason').value;
    if (!reason.trim()) {
        alert('Please provide a reason for returning the report.');
        return;
    }
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'return_completion',
                report_id: reportId,
                reason: reason
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report returned for revision.');
            closeModal('returnModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to return'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

async function approveCompletion(event) {
    event.preventDefault();
    
    const notes = document.getElementById('approve_notes').value;
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'approve_completion',
                report_id: reportId,
                notes: notes
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report approved! Project is now marked as completed.');
            closeModal('approveModal');
            if (window.SPA) {
                window.SPA.loadPage('project_view.php?id=' + projectId, true);
            } else {
                window.location.href = 'project_view.php?id=' + projectId;
            }
        } else {
            alert('Error: ' + (result.error || 'Failed to approve'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}

async function rejectCompletion(event) {
    event.preventDefault();
    
    const reason = document.getElementById('reject_reason').value;
    if (!reason.trim()) {
        alert('Please provide a reason for rejection.');
        return;
    }
    
    try {
        const response = await fetch('project_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'reject_completion',
                report_id: reportId,
                reason: reason
            })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Completion report rejected.');
            closeModal('rejectModal');
            window.location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to reject'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred');
    }
}
</script>
