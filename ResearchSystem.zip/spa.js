/**
 * SPA Router for Research Management System
 * Handles dynamic page loading without full page reloads
 */

(function() {
    'use strict';

    const SPA = {
        mainContent: null,
        loadingBar: null,
        currentPage: null,
        cache: new Map(),
        cacheTimeout: 5 * 60 * 1000, // 5 minutes cache

        init: function() {
            this.mainContent = document.getElementById('mainContent');
            this.loadingBar = document.getElementById('loadingBar');
            
            if (!this.mainContent) {
                console.warn('SPA: mainContent element not found');
                return;
            }

            this.setupLinkHandlers();
            this.setupPopState();
            this.setupFormHandlers();
        },

        setupLinkHandlers: function() {
            document.addEventListener('click', (e) => {
                // Handle sidebar spa-link clicks
                const spaLink = e.target.closest('a.spa-link');
                if (spaLink) {
                    const href = spaLink.getAttribute('href');
                    if (!href || href === '#' || href.startsWith('javascript:')) return;
                    
                    // Skip external links and special pages
                    if (href.includes('logout.php') || href.includes('index.php') || href.startsWith('http')) {
                        return;
                    }

                    e.preventDefault();
                    this.loadPage(href, true);
                    return;
                }
                
                // Handle internal links within loaded content (for SPA navigation)
                const internalLink = e.target.closest('a');
                if (internalLink && this.mainContent && this.mainContent.contains(internalLink)) {
                    let href = internalLink.getAttribute('href');
                    if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('http')) return;
                    
                    // Skip form pages, logout, and external links (but allow profile pages via SPA)
                    const skipPatterns = ['logout.php', 'index.php', 'studentresearcherform.php'];
                    for (const pattern of skipPatterns) {
                        if (href.includes(pattern)) return;
                    }
                    
                    // Handle relative URLs (like ?page=2)
                    if (href.startsWith('?')) {
                        // Get current page base and append the query string
                        const currentBase = this.currentPage ? this.currentPage.split('?')[0] : 'research.php';
                        href = currentBase + href;
                    }
                    
                    // Check if it's an internal PHP page or has query parameters
                    if (href.includes('.php') || href.startsWith('?')) {
                        e.preventDefault();
                        this.loadPage(href, true);
                    }
                }
            });
        },

        setupPopState: function() {
            window.addEventListener('popstate', (e) => {
                if (e.state && e.state.url) {
                    this.loadPage(e.state.url, false);
                }
            });
        },

        setupFormHandlers: function() {
            // Intercept form submissions for AJAX handling
            document.addEventListener('submit', (e) => {
                const form = e.target;
                
                // Handle forms with spa-form class
                if (form.classList.contains('spa-form')) {
                    e.preventDefault();
                    this.submitForm(form);
                    return;
                }
                
                // Handle search forms and other GET forms within main content
                if (this.mainContent && this.mainContent.contains(form)) {
                    const method = (form.method || 'GET').toUpperCase();
                    const action = form.action || window.location.href;
                    
                    // Skip forms that should do full page loads
                    if (form.hasAttribute('data-no-spa')) return;
                    
                    // Handle GET forms (like search) via SPA
                    if (method === 'GET') {
                        e.preventDefault();
                        const formData = new FormData(form);
                        const params = new URLSearchParams(formData).toString();
                        const baseAction = action.split('?')[0];
                        const url = params ? `${baseAction}?${params}` : baseAction;
                        
                        // Extract just the filename
                        const filename = url.split('/').pop();
                        this.loadPage(filename, true);
                    }
                }
            });
        },

        showLoading: function() {
            if (this.loadingBar) {
                this.loadingBar.classList.add('active');
            }
            if (this.mainContent) {
                this.mainContent.classList.add('loading');
            }
        },

        hideLoading: function() {
            if (this.loadingBar) {
                this.loadingBar.classList.remove('active');
            }
            if (this.mainContent) {
                this.mainContent.classList.remove('loading');
            }
        },

        updateActiveNav: function(url) {
            // Remove active class from all nav links
            document.querySelectorAll('.sidebar-nav a').forEach(link => {
                link.classList.remove('active');
            });

            // Extract base filename without query string for comparison
            const baseUrl = url.split('?')[0];
            
            // Find and activate the matching link
            let found = false;
            document.querySelectorAll('.sidebar-nav a').forEach(link => {
                const href = link.getAttribute('href');
                if (!href) return;
                
                const baseHref = href.split('?')[0];
                
                // Exact match or base filename match
                if (href === url || baseHref === baseUrl || baseUrl.includes(baseHref)) {
                    link.classList.add('active');
                    found = true;
                }
            });
            
            // If no match found, try to match by page content type
            if (!found) {
                const pageMapping = {
                    'research.php': 'dashboard',
                    'facultyresearcher.php': 'faculty',
                    'facultyresearcherprofile.php': 'faculty',
                    'studentresearcher.php': 'students',
                    'studentresearcherprofile.php': 'students',
                    'personnelresearcher.php': 'personnel',
                    'personnelresearcherprofile.php': 'personnel',
                    'users.php': 'users',
                    'oauth_settings.php': 'oauth',
                    'assign_coordinators.php': 'coordinators',
                    'activity_logs.php': 'logs'
                };
                
                for (const [page, dataPage] of Object.entries(pageMapping)) {
                    if (url.includes(page)) {
                        const link = document.querySelector(`.sidebar-nav a[data-page="${dataPage}"]`);
                        if (link) {
                            link.classList.add('active');
                            break;
                        }
                    }
                }
            }
        },

        loadPage: async function(url, pushState = true) {
            // Decode URL if needed
            url = decodeURIComponent(url);
            
            // If URL is just a filename (e.g., studentresearcher.php?search=test), use it as-is
            // If it starts with http or /, extract just the filename and query
            if (url.startsWith('http') || url.startsWith('/')) {
                try {
                    const urlObj = new URL(url, window.location.origin);
                    const filename = urlObj.pathname.split('/').pop();
                    url = filename + urlObj.search;
                } catch (e) {
                    // If URL parsing fails, try to extract filename
                    const parts = url.split('/');
                    url = parts[parts.length - 1];
                }
            }
            
            // Check if it's a form page that needs full page load
            // Note: Profile pages now work within SPA
            const fullPagePatterns = [
                'studentresearcherform.php'
            ];
            
            for (const pattern of fullPagePatterns) {
                if (url.includes(pattern)) {
                    // These pages load as full pages (not SPA)
                    window.location.href = url;
                    return;
                }
            }

            this.showLoading();
            this.currentPage = url;

            try {
                // Don't cache pages with action/dynamic parameters or the dashboard
                const noCacheParams = ['sync=', 'delete=', 'action=', 'remove=', 'assign=', 'unit=', 'page=', 'search='];
                // Don't cache view pages that depend on ID parameters (they should always be fresh)
                const noCachePages = ['research.php', 'researcher_dashboard.php', 'work_queue.php', 
                                      'project_extension_view.php', 'project_progress_view.php', 
                                      'project_output_view.php', 'collaboration_view.php', 
                                      'project_view.php', 'submission_view.php'];
                const shouldCache = !noCacheParams.some(param => url.includes(param)) && 
                                   !noCachePages.some(page => url.includes(page));
                
                // Check cache first (only for non-action URLs)
                // Use full URL as cache key to properly handle query parameters
                const cacheKey = url;
                if (shouldCache) {
                    const cached = this.cache.get(cacheKey);
                    if (cached && (Date.now() - cached.timestamp < this.cacheTimeout)) {
                        this.renderContent(cached.html, url, pushState);
                        return;
                    }
                } else {
                    // Clear cache for this page when doing an action
                    this.cache.delete(cacheKey);
                }

                // Add SPA header to request
                const separator = url.includes('?') ? '&' : '?';
                const fetchUrl = `${url}${separator}spa=1`;
                
                const response = await fetch(fetchUrl, {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-SPA-Request': '1'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const html = await response.text();
                
                // Cache the response (only for non-action URLs)
                if (shouldCache) {
                    this.cache.set(cacheKey, {
                        html: html,
                        timestamp: Date.now()
                    });
                }

                this.renderContent(html, url, pushState);

            } catch (error) {
                console.error('SPA load error:', error);
                this.showError('Failed to load page. Please try again.');
                
                // Fallback to full page load
                setTimeout(() => {
                    window.location.href = url;
                }, 2000);
            }
        },

        renderContent: function(html, url, pushState) {
            if (!this.mainContent) return;

            // Update the content
            this.mainContent.innerHTML = html;
            this.mainContent.classList.add('page-enter');
            
            // Remove animation class after it completes
            setTimeout(() => {
                this.mainContent.classList.remove('page-enter');
            }, 300);

            // Update URL
            if (pushState) {
                const pageTitle = this.extractTitle(html) || 'Research Management';
                history.pushState({ url: url }, pageTitle, url);
                document.title = pageTitle;
            }

            // Update active nav
            this.updateActiveNav(url);

            // Hide loading
            this.hideLoading();

            // Execute any inline scripts
            this.executeScripts();

            // Scroll to top
            window.scrollTo(0, 0);

            // Reinitialize any components (charts, etc.)
            this.reinitializeComponents();
        },

        extractTitle: function(html) {
            const match = html.match(/<title[^>]*>([^<]+)<\/title>/i);
            return match ? match[1] : null;
        },

        executeScripts: function() {
            const scripts = this.mainContent.querySelectorAll('script');
            const inlineScripts = [];
            const externalScripts = [];
            
            // Separate inline and external scripts
            scripts.forEach(script => {
                if (script.src) {
                    externalScripts.push(script);
                } else {
                    inlineScripts.push(script);
                }
            });
            
            // Execute inline scripts first (synchronously)
            inlineScripts.forEach(oldScript => {
                const newScript = document.createElement('script');
                Array.from(oldScript.attributes).forEach(attr => {
                    newScript.setAttribute(attr.name, attr.value);
                });
                newScript.textContent = oldScript.textContent;
                oldScript.parentNode.replaceChild(newScript, oldScript);
            });
            
            // Then load external scripts with cache-busting
            externalScripts.forEach(oldScript => {
                const newScript = document.createElement('script');
                Array.from(oldScript.attributes).forEach(attr => {
                    if (attr.name === 'src') {
                        // Add cache-busting parameter to force re-execution
                        const separator = attr.value.includes('?') ? '&' : '?';
                        newScript.setAttribute('src', attr.value + separator + '_spa=' + Date.now());
                    } else {
                        newScript.setAttribute(attr.name, attr.value);
                    }
                });
                newScript.textContent = oldScript.textContent;
                oldScript.parentNode.replaceChild(newScript, oldScript);
            });
        },

        reinitializeComponents: function() {
            // Trigger custom event for components to reinitialize
            document.dispatchEvent(new CustomEvent('spa:pageload', {
                detail: { url: this.currentPage }
            }));

            // Reinitialize Charts if Chart.js is loaded and dashboardData exists
            if (window.Chart && window.dashboardData) {
                this.initializeCharts();
            }
        },

        initializeCharts: function() {
            // This will be called after dashboard loads
            // Call the dashboard's own initialization function if available
            if (typeof window.initializeDashboardCharts === 'function') {
                console.log('SPA: Calling initializeDashboardCharts...');
                setTimeout(function() {
                    window.initializeDashboardCharts();
                }, 200);
            }
        },

        submitForm: async function(form) {
            this.showLoading();

            try {
                const formData = new FormData(form);
                const response = await fetch(form.action, {
                    method: form.method || 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-SPA-Request': '1'
                    }
                });

                const html = await response.text();

                // Clear cache for this page
                this.cache.delete(form.action);

                this.renderContent(html, form.action, true);

            } catch (error) {
                console.error('Form submit error:', error);
                this.showError('Failed to submit form. Please try again.');
            }
        },

        showError: function(message) {
            this.hideLoading();
            
            const errorHtml = `
                <div class="header">
                    <div class="header-title">
                        <i class="fa fa-exclamation-triangle" style="color: #dc2626;"></i>
                        <span>Error</span>
                    </div>
                </div>
                <div class="content">
                    <div style="text-align: center; padding: 60px 20px;">
                        <i class="fa fa-exclamation-circle" style="font-size: 64px; color: #dc2626; margin-bottom: 20px;"></i>
                        <h2 style="color: #1f2937; margin-bottom: 10px;">Something went wrong</h2>
                        <p style="color: #6b7280; margin-bottom: 20px;">${message}</p>
                        <button onclick="window.location.reload()" class="btn btn-primary" style="padding: 12px 24px; background: #064e1a; color: white; border: none; border-radius: 8px; cursor: pointer;">
                            <i class="fa fa-refresh"></i> Reload Page
                        </button>
                    </div>
                </div>
            `;

            if (this.mainContent) {
                this.mainContent.innerHTML = errorHtml;
            }
        },

        clearCache: function() {
            this.cache.clear();
        },

        // Navigate programmatically
        navigate: function(url) {
            this.loadPage(url, true);
        },

        // Refresh current page
        refresh: function() {
            if (this.currentPage) {
                this.cache.delete(this.currentPage);
                this.loadPage(this.currentPage, false);
            }
        }
    };

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => SPA.init());
    } else {
        SPA.init();
    }

    // Expose globally
    window.SPA = SPA;

})();
