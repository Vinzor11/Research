<?php
/**
 * get_version_history.php
 * Retrieves all versions of a research output for display in version history modal
 */
session_start();
require 'db.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "Unauthorized"]);
    exit;
}

$userRole = $_SESSION['user_role'] ?? null;
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$coordinatorTypes = $_SESSION['coordinator_types'] ?? [];

// Helper: check if user has faculty coordinator type (checks both single and array)
$hasFacultyCoordinator = $coordinatorType === 'faculty' || in_array('faculty', $coordinatorTypes);

// Only allow admin or faculty coordinator
if (!($userRole === 'admin' || ($userRole === 'coordinator' && $hasFacultyCoordinator))) {
    echo json_encode(["success" => false, "error" => "Unauthorized access"]);
    exit;
}

header('Content-Type: application/json');

$output_id = isset($_GET['output_id']) ? (int)$_GET['output_id'] : 0;
$project_id = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;

if (!$output_id || !$project_id) {
    echo json_encode(["success" => false, "error" => "Invalid parameters"]);
    exit;
}

try {
    // Get the parent output ID (the original upload)
    $parentCheck = $conn->query("
        SELECT parent_output_id 
        FROM faculty_research_outputs 
        WHERE id = $output_id
    ")->fetch_assoc();
    
    $parent_id = $parentCheck['parent_output_id'] ?? $output_id;
    
    // If this output is itself a parent (not a revision), use its ID
    if (!$parent_id) {
        $parent_id = $output_id;
    }
    
    // Fetch all versions: the original and all its revisions
    $query = "
        SELECT 
            fro.id,
            fro.output_title,
            fro.output_type,
            fro.file_name,
            fro.file_path,
            fro.file_size,
            fro.output_status,
            fro.version,
            fro.is_latest_version,
            fro.upload_date,
            fro.review_date,
            fro.review_comments,
            CONCAT(fr.first_name, ' ', fr.last_name) as uploader_name,
            u.username as reviewer_name
        FROM faculty_research_outputs fro
        LEFT JOIN faculty_researchers fr ON fro.uploaded_by = fr.id
        LEFT JOIN users u ON fro.reviewer_id = u.id
        WHERE (fro.id = $parent_id OR fro.parent_output_id = $parent_id)
        AND fro.project_id = $project_id
        ORDER BY fro.version DESC
    ";
    
    $result = $conn->query($query);
    
    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }
    
    $versions = [];
    while ($row = $result->fetch_assoc()) {
        $versions[] = $row;
    }
    
    echo json_encode([
        "success" => true,
        "versions" => $versions,
        "total_versions" => count($versions)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
?>
