// researchScript.js - Enhanced Chart configurations for Research Dashboard

// Chart.js Global Configuration
Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.padding = 15;

// Color Palette
const colors = {
    faculty: 'rgba(6, 78, 26, 0.8)',
    facultyBorder: 'rgb(6, 78, 26)',
    student: 'rgba(139, 92, 246, 0.8)',
    studentBorder: 'rgb(139, 92, 246)',
    ongoing: 'rgba(245, 158, 11, 0.85)',
    completed: 'rgba(16, 185, 129, 0.85)',
    published: 'rgba(37, 99, 235, 0.85)',
    pending: 'rgba(156, 163, 175, 0.85)',
    accepted: 'rgba(16, 185, 129, 0.85)',
    needs_revision: 'rgba(245, 158, 11, 0.85)',
    rejected: 'rgba(239, 68, 68, 0.85)',
    gradient: [
        'rgba(6, 78, 26, 0.9)',
        'rgba(11, 106, 36, 0.9)',
        'rgba(46, 139, 87, 0.9)',
        'rgba(60, 179, 113, 0.9)',
        'rgba(102, 205, 170, 0.9)',
        'rgba(143, 188, 143, 0.9)',
        'rgba(144, 238, 144, 0.9)',
        'rgba(152, 251, 152, 0.9)'
    ]
};

// Animation Configuration
const animationConfig = {
    duration: 1500,
    easing: 'easeInOutQuart',
    delay: (context) => {
        let delay = 0;
        if (context.type === 'data' && context.mode === 'default') {
            delay = context.dataIndex * 100;
        }
        return delay;
    }
};

// Common tooltip configuration
const tooltipConfig = {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    padding: 12,
    titleFont: { size: 14, weight: 'bold' },
    bodyFont: { size: 13 },
    cornerRadius: 8
};

// Helper function to show "No data" message in chart container
function showNoDataMessage(ctx, message) {
    const container = ctx.parentElement;
    if (container) {
        container.innerHTML = `
            <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%; min-height: 200px; color: #9ca3af;">
                <i class="fa fa-chart-pie" style="font-size: 48px; margin-bottom: 15px; opacity: 0.5;"></i>
                <p style="font-size: 14px; font-weight: 500;">${message}</p>
            </div>
        `;
    }
}

// Project Status Distribution Chart (from research_submissions)
function createProjectStatusChart(data) {
    const ctx = document.getElementById('projectStatusChart');
    if (!ctx) return;
    
    const chartData = [
        data.on_going_projects || 0,
        data.extended_projects || 0,
        data.completed_projects || 0
    ];
    
    const total = chartData.reduce((a, b) => a + b, 0);
    if (total === 0) {
        showNoDataMessage(ctx, 'No approved projects yet');
        return;
    }
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['On-Going', 'Extended', 'Completed'],
            datasets: [{
                data: chartData,
                backgroundColor: [
                    'rgba(14, 165, 233, 0.85)',  // Sky blue for on-going
                    'rgba(249, 115, 22, 0.85)',  // Orange for extended
                    'rgba(34, 197, 94, 0.85)'    // Green for completed
                ],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Submission Status Chart (from research_submissions)
function createSubmissionStatusChart(data) {
    const ctx = document.getElementById('submissionStatusChart');
    if (!ctx) return;
    
    const pending = data.pending_submissions || 0;
    const approved = data.approved_submissions || 0;
    const total = data.total_submissions || 0;
    const other = Math.max(0, total - pending - approved);
    
    if (total === 0) {
        showNoDataMessage(ctx, 'No submissions yet');
        return;
    }
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Review', 'Approved', 'Other'],
            datasets: [{
                data: [pending, approved, other],
                backgroundColor: [
                    'rgba(139, 92, 246, 0.85)',  // Purple for pending
                    'rgba(16, 185, 129, 0.85)',  // Green for approved
                    'rgba(156, 163, 175, 0.85)'  // Gray for other
                ],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Faculty Research Outputs Status Chart
function createFacultyOutputsChart(data) {
    const ctx = document.getElementById('facultyOutputsChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Review', 'Accepted', 'Needs Revision', 'Rejected'],
            datasets: [{
                data: [data.pending, data.accepted, data.needs_revision, data.rejected],
                backgroundColor: [colors.pending, colors.accepted, colors.needs_revision, colors.rejected],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Student Research Outputs Status Chart
function createStudentOutputsChart(data) {
    const ctx = document.getElementById('studentOutputsChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pending Review', 'Accepted', 'Needs Revision', 'Rejected'],
            datasets: [{
                data: [data.pending, data.accepted, data.needs_revision, data.rejected],
                backgroundColor: [colors.pending, colors.accepted, colors.needs_revision, colors.rejected],
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            }
        }
    });
}

// Funding Distribution Chart
function createFundingChart(data) {
    const ctx = document.getElementById('fundingChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Institution Fund', 'Government Fund', 'Private Fund', 'Foreign Fund', 'Other Sources'],
            datasets: [{
                data: [data.institution, data.government, data.private, data.foreign, data.other],
                backgroundColor: colors.gradient,
                borderWidth: 3,
                borderColor: '#fff',
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 15, font: { size: 12, weight: '600' } }
                },
                tooltip: {
                    ...tooltipConfig,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) label += ': ';
                            label += '₱' + context.parsed.toLocaleString('en-US', {
                                minimumFractionDigits: 2, 
                                maximumFractionDigits: 2
                            });
                            return label;
                        }
                    }
                }
            }
        }
    });
}

// Research Category Distribution Chart
function createCategoryChart(labels, data) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Number of Projects',
                data: data,
                backgroundColor: colors.gradient,
                borderWidth: 0,
                borderRadius: 8,
                barThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: animationConfig,
            plugins: {
                legend: { display: false },
                tooltip: tooltipConfig
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                x: {
                    ticks: { font: { size: 12, weight: '600' } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Global chart instance
let trendChartInstance = null;
let currentTimeRange = '30days';

// Enhanced Trend Chart with Interactive Features
function createEnhancedTrendChart(labels, facultyData, studentData, facultyOutputsData, studentOutputsData, showFaculty, showStudent, personnelData, personnelOutputsData, showPersonnel, submissionData, approvedData, showSubmissions) {
    const ctx = document.getElementById('trendChart');
    if (!ctx) {
        console.error('Trend chart canvas not found');
        return;
    }
    
    // Destroy existing chart
    if (trendChartInstance) {
        trendChartInstance.destroy();
        trendChartInstance = null;
    }
    
    const datasets = [];
    
    // Submissions data (modern workflow) - show first as it's the primary data source
    if (showSubmissions) {
        datasets.push({
            label: 'New Submissions',
            data: submissionData || [],
            borderColor: 'rgb(37, 99, 235)',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(37, 99, 235)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Approved Projects',
            data: approvedData || [],
            borderColor: 'rgb(16, 185, 129)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(16, 185, 129)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    // Legacy faculty data
    if (showFaculty) {
        datasets.push({
            label: 'Faculty Research',
            data: facultyData,
            borderColor: 'rgb(6, 78, 26)',
            backgroundColor: 'rgba(6, 78, 26, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(6, 78, 26)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Faculty Outputs',
            data: facultyOutputsData,
            borderColor: 'rgb(16, 185, 129)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(16, 185, 129)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    // Legacy student data
    if (showStudent) {
        datasets.push({
            label: 'Student Research',
            data: studentData,
            borderColor: 'rgb(139, 92, 246)',
            backgroundColor: 'rgba(139, 92, 246, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(139, 92, 246)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Student Outputs',
            data: studentOutputsData,
            borderColor: 'rgb(245, 158, 11)',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(245, 158, 11)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    if (showPersonnel) {
        datasets.push({
            label: 'Personnel Research',
            data: personnelData || [],
            borderColor: 'rgb(99, 102, 241)',
            backgroundColor: 'rgba(99, 102, 241, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(99, 102, 241)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3
        });
        
        datasets.push({
            label: 'Personnel Outputs',
            data: personnelOutputsData || [],
            borderColor: 'rgb(236, 72, 153)',
            backgroundColor: 'rgba(236, 72, 153, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 8,
            pointBackgroundColor: 'rgb(236, 72, 153)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            borderWidth: 3,
            borderDash: [5, 5]
        });
    }
    
    // If no datasets, show an empty chart with a message
    if (datasets.length === 0) {
        // Add a placeholder dataset
        datasets.push({
            label: 'No data available',
            data: labels.map(() => 0),
            borderColor: 'rgba(156, 163, 175, 0.5)',
            backgroundColor: 'rgba(156, 163, 175, 0.1)',
            tension: 0.4,
            fill: true,
            pointRadius: 0,
            borderWidth: 2
        });
    }
    
    trendChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 1500, easing: 'easeInOutQuart' },
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { padding: 20, font: { size: 13, weight: '600' } }
                },
                tooltip: tooltipConfig
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        stepSize: 1, 
                        font: { size: 13, weight: '600' },
                        callback: function(value) {
                            return Number.isInteger(value) ? value : '';
                        }
                    },
                    title: { 
                        display: true, 
                        text: 'Number of Research Items', 
                        font: { size: 14, weight: 'bold' } 
                    },
                    grid: { color: 'rgba(0, 0, 0, 0.06)' }
                },
                x: {
                    ticks: { font: { size: 12, weight: '600' } },
                    title: { 
                        display: true, 
                        text: 'Time Period', 
                        font: { size: 14, weight: 'bold' } 
                    },
                    grid: { display: false }
                }
            }
        }
    });
}

// Load trend data via AJAX
function loadTrendData(timeRange) {
    const chartContainer = document.querySelector('#trendChart');
    if (!chartContainer) return;
    
    const parentContainer = chartContainer.parentElement;
    const loadingElement = document.querySelector('.chart-loading');
    
    // Show loading state
    parentContainer.classList.add('loading');
    if (loadingElement) loadingElement.classList.add('active');
    
    // Update active button
    document.querySelectorAll('.time-filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    const activeBtn = document.querySelector(`[data-range="${timeRange}"]`);
    if (activeBtn) activeBtn.classList.add('active');
    
    fetch(`get_trend_data.php?range=${timeRange}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }
            return response.text();
        })
        .then(text => {
            console.log('Raw response (first 200 chars):', text.substring(0, 200));
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error('JSON Parse Error:', e);
                console.error('Full response:', text);
                throw new Error('Invalid JSON from server');
            }
            
            // Update statistics
            updateStatistics(data.statistics);
            
            // Check what data is available
            const showFaculty = data.faculty && data.faculty.some(val => val > 0);
            const showStudent = data.student && data.student.some(val => val > 0);
            const showPersonnel = data.personnel && data.personnel.some(val => val > 0);
            const showSubmissions = data.submissions && data.submissions.some(val => val > 0);
            const showApproved = data.approvedProjects && data.approvedProjects.some(val => val > 0);
            
            console.log('Trend data visibility:', { showFaculty, showStudent, showPersonnel, showSubmissions, showApproved });
            
            createEnhancedTrendChart(
                data.labels,
                data.faculty || [],
                data.student || [],
                data.facultyOutputs || [],
                data.studentOutputs || [],
                showFaculty,
                showStudent,
                data.personnel || [],
                data.personnelOutputs || [],
                showPersonnel,
                data.submissions || [],
                data.approvedProjects || [],
                showSubmissions || showApproved
            );
            
            // Hide loading state
            parentContainer.classList.remove('loading');
            if (loadingElement) loadingElement.classList.remove('active');
        })
        .catch(error => {
            console.error('Error loading trend data:', error);
            parentContainer.classList.remove('loading');
            if (loadingElement) loadingElement.classList.remove('active');
            
            const statsContainer = document.querySelector('.trend-statistics');
            if (statsContainer) {
                statsContainer.innerHTML = `
                    <div class="trend-stat-item" style="grid-column: 1/-1; background: #fee2e2; color: #991b1b;">
                        <div class="trend-stat-icon"><i class="fa fa-exclamation-triangle"></i></div>
                        <div class="trend-stat-label">Failed to load data. Check browser console.</div>
                    </div>
                `;
            }
        });
}

// Update statistics display
function updateStatistics(stats) {
    const statsContainer = document.querySelector('.trend-statistics');
    if (!statsContainer) return;
    
    let html = '';
    
    // Show submission statistics first (modern workflow)
    if (stats.submissions && (stats.submissions.total > 0 || stats.submissions.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-file-lines"></i></div>
                <div class="trend-stat-value">${stats.submissions.total}</div>
                <div class="trend-stat-label">Total Submissions</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.submissions.pending}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.submissions.approved}</div>
                <div class="trend-stat-label">Approved</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-spinner"></i></div>
                <div class="trend-stat-value">${stats.submissions.active}</div>
                <div class="trend-stat-label">Active Projects</div>
            </div>
        `;
    }
    
    // Legacy faculty data
    if (stats.faculty && (stats.faculty.total > 0 || stats.faculty.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-chalkboard-teacher"></i></div>
                <div class="trend-stat-value">${stats.faculty.total}</div>
                <div class="trend-stat-label">Faculty Projects</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.faculty.pending}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.faculty.accepted}</div>
                <div class="trend-stat-label">Accepted</div>
            </div>
        `;
    }
    
    // Legacy student data
    if (stats.student && (stats.student.total > 0 || stats.student.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-user-graduate"></i></div>
                <div class="trend-stat-value">${stats.student.total}</div>
                <div class="trend-stat-label">Student Research</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.student.pending}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.student.accepted}</div>
                <div class="trend-stat-label">Accepted</div>
            </div>
        `;
    }
    
    // Legacy personnel data
    if (stats.personnel && (stats.personnel.total > 0 || stats.personnel.pending > 0)) {
        html += `
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-briefcase"></i></div>
                <div class="trend-stat-value">${stats.personnel.total}</div>
                <div class="trend-stat-label">Personnel Projects</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-clock"></i></div>
                <div class="trend-stat-value">${stats.personnel.pending || 0}</div>
                <div class="trend-stat-label">Pending Review</div>
            </div>
            <div class="trend-stat-item">
                <div class="trend-stat-icon"><i class="fa fa-check-circle"></i></div>
                <div class="trend-stat-value">${stats.personnel.accepted || 0}</div>
                <div class="trend-stat-label">Accepted</div>
            </div>
        `;
    }
    
    if (html === '') {
        html = '<div class="trend-stat-item"><div class="trend-stat-label">No data for this time range</div></div>';
    }
    
    statsContainer.innerHTML = html;
}

// Overall Status Chart
function createOverallStatusChart(ongoing, completed, published) {
    console.log('Creating Overall Status Chart with:', ongoing, completed, published);
    const ctx = document.getElementById('overallStatusChart');
    if (!ctx) {
        console.log('  - Canvas overallStatusChart not found');
        return;
    }
    
    const total = (ongoing || 0) + (completed || 0) + (published || 0);
    console.log('  - Total:', total);
    
    // Show "No data" if all values are zero
    if (total === 0) {
        showNoDataMessage(ctx, 'No research data available');
        return;
    }
    
    try {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['On-going', 'Completed', 'Published'],
                datasets: [{
                    data: [ongoing, completed, published],
                    backgroundColor: [colors.ongoing, colors.completed, colors.published],
                    borderWidth: 3,
                    borderColor: '#fff',
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: animationConfig,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 20, font: { size: 13, weight: '600' } }
                    },
                    tooltip: tooltipConfig
                }
            }
        });
        console.log('  - Chart created successfully');
    } catch (e) {
        console.error('  - Error creating chart:', e);
    }
}

// Faculty Status Chart
function createFacultyStatusChart(ongoing, completed, published) {
    console.log('Creating Faculty Status Chart with:', ongoing, completed, published);
    const ctx = document.getElementById('facultyStatusChart');
    if (!ctx) {
        console.log('  - Canvas facultyStatusChart not found');
        return;
    }
    
    const total = (ongoing || 0) + (completed || 0) + (published || 0);
    console.log('  - Total:', total);
    
    if (total === 0) {
        showNoDataMessage(ctx, 'No faculty research data');
        return;
    }
    
    try {
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['On-going', 'Completed', 'Published'],
                datasets: [{
                    data: [ongoing, completed, published],
                    backgroundColor: [colors.ongoing, colors.completed, colors.published],
                    borderWidth: 3,
                    borderColor: '#fff',
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: animationConfig,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 20, font: { size: 13, weight: '600' } }
                    },
                    tooltip: tooltipConfig
                }
            }
        });
        console.log('  - Chart created successfully');
    } catch (e) {
        console.error('  - Error creating chart:', e);
    }
}

// Student Status Chart
function createStudentStatusChart(ongoing, completed, published) {
    console.log('Creating Student Status Chart with:', ongoing, completed, published);
    const ctx = document.getElementById('studentStatusChart');
    if (!ctx) {
        console.log('  - Canvas studentStatusChart not found');
        return;
    }
    
    const total = (ongoing || 0) + (completed || 0) + (published || 0);
    console.log('  - Total:', total);
    
    if (total === 0) {
        showNoDataMessage(ctx, 'No student research data');
        return;
    }
    
    try {
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['On-going', 'Completed', 'Published'],
                datasets: [{
                    data: [ongoing, completed, published],
                    backgroundColor: [colors.ongoing, colors.completed, colors.published],
                    borderWidth: 3,
                    borderColor: '#fff',
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: animationConfig,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 20, font: { size: 13, weight: '600' } }
                    },
                    tooltip: tooltipConfig
                }
            }
        });
        console.log('  - Chart created successfully');
    } catch (e) {
        console.error('  - Error creating chart:', e);
    }
}

// Faculty by Department Chart
function createFacultyDeptChart(labels, data) {
    console.log('Creating Faculty Dept Chart with:', labels, data);
    const ctx = document.getElementById('facultyDeptChart');
    if (!ctx) {
        console.log('  - Canvas facultyDeptChart not found');
        return;
    }
    
    if (!labels || labels.length === 0) {
        showNoDataMessage(ctx, 'No faculty department data');
        return;
    }
    
    try {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Faculty Count',
                    data: data,
                    backgroundColor: colors.faculty,
                    borderRadius: 8,
                    barThickness: 30
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                animation: animationConfig,
                plugins: {
                    legend: { display: false },
                    tooltip: tooltipConfig
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                        grid: { color: 'rgba(0, 0, 0, 0.05)' }
                    },
                    y: {
                        ticks: { font: { size: 11, weight: '600' } },
                        grid: { display: false }
                    }
                }
            }
        });
        console.log('  - Chart created successfully');
    } catch (e) {
        console.error('  - Error creating chart:', e);
    }
}

// Students by Department Chart
function createStudentDeptChart(labels, data) {
    console.log('Creating Student Dept Chart with:', labels, data);
    const ctx = document.getElementById('studentDeptChart');
    if (!ctx) {
        console.log('  - Canvas studentDeptChart not found');
        return;
    }
    
    if (!labels || labels.length === 0) {
        showNoDataMessage(ctx, 'No student department data');
        return;
    }
    
    try {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Student Count',
                    data: data,
                    backgroundColor: colors.student,
                    borderRadius: 8,
                    barThickness: 30
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                animation: animationConfig,
                plugins: {
                    legend: { display: false },
                    tooltip: tooltipConfig
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: { stepSize: 1, font: { size: 12, weight: '600' } },
                        grid: { color: 'rgba(0, 0, 0, 0.05)' }
                    },
                    y: {
                        ticks: { font: { size: 11, weight: '600' } },
                        grid: { display: false }
                    }
                }
            }
        });
        console.log('  - Chart created successfully');
    } catch (e) {
        console.error('  - Error creating chart:', e);
    }
}

// Export chart
function exportTrendChart() {
    if (trendChartInstance) {
        const url = trendChartInstance.toBase64Image();
        const link = document.createElement('a');
        link.download = `research-trends-${currentTimeRange}-${new Date().toISOString().split('T')[0]}.png`;
        link.href = url;
        link.click();
    }
}

// Track if initialization has already run
let dashboardInitialized = false;

// Main initialization function
function initializeDashboard() {
    // Check if we're on the dashboard page
    if (!document.getElementById('overallStatusChart') && !document.getElementById('facultyStatusChart') && !document.getElementById('trendChart')) {
        console.log('ℹ️ Not on dashboard page - skipping initialization');
        return;
    }
    
    console.log('🚀 Initializing Research Dashboard...');
    
    // Destroy any existing charts to prevent duplicates
    if (typeof Chart !== 'undefined' && Chart.instances) {
        // Get all chart instances and destroy them
        const chartInstances = Object.values(Chart.instances);
        chartInstances.forEach(instance => {
            if (instance && instance.destroy) {
                instance.destroy();
            }
        });
    }
    
    // Reset trend chart instance
    if (trendChartInstance) {
        trendChartInstance.destroy();
        trendChartInstance = null;
    }
    
    // Time filter buttons
    document.querySelectorAll('.time-filter-btn').forEach(btn => {
        // Remove old listeners by cloning
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', function() {
            currentTimeRange = this.getAttribute('data-range');
            loadTrendData(currentTimeRange);
        });
    });
    
    // Load trend chart
    if (document.getElementById('trendChart')) {
        loadTrendData(currentTimeRange);
    }
    
    // Initialize other charts
    if (typeof window.dashboardData === 'undefined') {
        console.log('⚠️ window.dashboardData not defined - waiting...');
        // Try again after a short delay
        setTimeout(function() {
            if (typeof window.dashboardData !== 'undefined') {
                initializeChartsWithData(window.dashboardData);
            } else {
                console.error('❌ Dashboard data still not available');
            }
        }, 500);
        return;
    }
    
    const data = window.dashboardData;
    console.log('📊 Dashboard data:', data);
    initializeChartsWithData(data);
}

// Separate function to initialize charts with data
function initializeChartsWithData(data) {
    if (!data) {
        console.error('❌ No data provided for charts');
        return;
    }
    
    console.log('📈 Initializing charts with data:', data);
    console.log('  - userRole:', data.userRole);
    console.log('  - showFaculty:', data.showFaculty);
    console.log('  - showStudent:', data.showStudent);
    console.log('  - totalOngoing/Completed/Published:', data.totalOngoing, data.totalCompleted, data.totalPublished);
    console.log('  - facultyStats:', data.facultyStats);
    console.log('  - studentStats:', data.studentStats);
    console.log('  - facultyByDept:', data.facultyByDept);
    console.log('  - studentByDept:', data.studentByDept);
    
    // New submission-based charts (primary data source)
    if (data.hasSubmissionData && data.submissionStats) {
        // Project Status Distribution (only if there are approved projects)
        if (data.submissionStats.approved_submissions > 0) {
            createProjectStatusChart(data.submissionStats);
        }
        // Submission Status
        createSubmissionStatusChart(data.submissionStats);
    }
    
    // Legacy charts (only shown if there's data in legacy tables)
    if (data.showFaculty && data.facultyOutputsStats) {
        const total = Object.values(data.facultyOutputsStats).reduce((a, b) => a + b, 0);
        if (total > 0) createFacultyOutputsChart(data.facultyOutputsStats);
    }
    
    if (data.showStudent && data.studentOutputsStats) {
        const total = Object.values(data.studentOutputsStats).reduce((a, b) => a + b, 0);
        if (total > 0) createStudentOutputsChart(data.studentOutputsStats);
    }
    
    if (data.showFaculty && data.fundingTotal > 0) {
        createFundingChart(data.fundingAllocated);
    }
    
    if (data.showFaculty && data.researchCategories?.length > 0) {
        const labels = data.researchCategories.map(i => i.classification);
        const counts = data.researchCategories.map(i => i.count);
        createCategoryChart(labels, counts);
    }
    
    if (data.showFaculty && data.facultyByDept?.length > 0) {
        const labels = data.facultyByDept.map(i => i.department);
        const counts = data.facultyByDept.map(i => i.count);
        createFacultyDeptChart(labels, counts);
    }
    
    if (data.showStudent && data.studentByDept?.length > 0) {
        const labels = data.studentByDept.map(i => i.department);
        const counts = data.studentByDept.map(i => i.count);
        createStudentDeptChart(labels, counts);
    }
    
    dashboardInitialized = true;
    console.log('✅ Dashboard charts initialized');
}

// Initialize on DOMContentLoaded (for direct page load)
document.addEventListener('DOMContentLoaded', initializeDashboard);

// Initialize on SPA page load (for AJAX navigation)
document.addEventListener('spa:pageload', function(e) {
    // Check if we're on the dashboard page
    if (e.detail && e.detail.url && (e.detail.url.includes('research.php') || e.detail.url === 'dashboard')) {
        // Small delay to ensure DOM is updated and scripts have run
        setTimeout(initializeDashboard, 100);
    }
});

// Also initialize if the script is loaded after DOMContentLoaded (for SPA)
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    // Small delay to ensure window.dashboardData is set
    setTimeout(initializeDashboard, 100);
}

// Expose initialization function globally for SPA to call
window.initializeDashboardCharts = initializeDashboard;
