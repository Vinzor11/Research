<?php
/**
 * maintenance.php
 * System Health Dashboard for Admins
 * Shows token status, sync history, orphaned files, etc.
 */

session_start();
require 'db.php';
require 'config.php';

// Admin only
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    die("⛔ Access Denied: Admin access required");
}

require_once 'TokenManager.php';
require_once 'FileUploadHelper.php';

// Handle actions
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'cleanup_tokens':
                $deleted = TokenManager::cleanupExpiredTokens($conn);
                $message = "✅ Cleaned up $deleted expired tokens";
                break;
                
            case 'cleanup_orphans':
                // This would require implementation in FileUploadHelper
                $message = "ℹ️ Orphaned file cleanup requires manual review";
                break;
        }
    }
}

// Get statistics
$stats = [];

// Token stats
$tokenStats = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN expires_at > NOW() THEN 1 ELSE 0 END) as valid,
        SUM(CASE WHEN expires_at <= NOW() THEN 1 ELSE 0 END) as expired
    FROM oauth_tokens
")->fetch_assoc();

$stats['tokens'] = $tokenStats;

// Sync history stats
$syncStats = $conn->query("
    SELECT 
        COUNT(*) as total,
        COUNT(DISTINCT faculty_id) as unique_faculty,
        MAX(synced_at) as last_sync
    FROM hr_sync_history
")->fetch_assoc();

$stats['sync'] = $syncStats;

// Faculty sync status
$facultyStats = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN is_synced = 1 THEN 1 ELSE 0 END) as synced,
        SUM(CASE WHEN last_synced_at IS NOT NULL AND last_synced_at < DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as outdated
    FROM faculty_researchers
")->fetch_assoc();

$stats['faculty'] = $facultyStats;

// Recent sync activity
$recentSyncs = $conn->query("
    SELECT 
        sh.*,
        u.username,
        CONCAT(fr.first_name, ' ', fr.last_name) as faculty_name
    FROM hr_sync_history sh
    LEFT JOIN users u ON sh.synced_by = u.id
    LEFT JOIN faculty_researchers fr ON sh.faculty_id = fr.id
    ORDER BY sh.synced_at DESC
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

// Active tokens
$activeTokens = $conn->query("
    SELECT 
        ot.*,
        u.username,
        u.user_role,
        u.coordinator_type
    FROM oauth_tokens ot
    LEFT JOIN users u ON ot.user_id = u.id
    WHERE ot.expires_at > NOW()
    ORDER BY ot.expires_at ASC
")->fetch_all(MYSQLI_ASSOC);

// System health checks
$health = [];

// Check if TokenManager table exists
$health['token_table'] = $conn->query("SHOW TABLES LIKE 'oauth_tokens'")->num_rows > 0;

// Check if sync history table exists
$health['sync_table'] = $conn->query("SHOW TABLES LIKE 'hr_sync_history'")->num_rows > 0;

// Check upload directory
$health['upload_dir'] = is_dir(UPLOAD_DIR) && is_writable(UPLOAD_DIR);

// Check for UNIQUE constraint
$uniqueCheck = $conn->query("SHOW INDEX FROM faculty_researchers WHERE Key_name = 'unique_hr_employee_id'");
$health['unique_constraint'] = $uniqueCheck->num_rows > 0;

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>System Maintenance Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #f9fafb 0%, #e0e7ff 100%);
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);
            color: white;
            padding: 30px;
            border-radius: 16px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header p {
            opacity: 0.9;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #6b7280;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
        .stat-card .number {
            font-size: 32px;
            font-weight: 700;
            color: #064e1a;
            margin-bottom: 5px;
        }
        .stat-card .detail {
            font-size: 13px;
            color: #9ca3af;
        }
        .health-check {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .health-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #f3f4f6;
        }
        .health-item:last-child {
            border-bottom: none;
        }
        .health-status {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .health-ok {
            background: #d1fae5;
            color: #065f46;
        }
        .health-error {
            background: #fee2e2;
            color: #991b1b;
        }
        .section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .section h2 {
            font-size: 18px;
            margin-bottom: 20px;
            color: #1f2937;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: left;
            padding: 12px;
            background: #f9fafb;
            font-size: 12px;
            text-transform: uppercase;
            color: #6b7280;
            font-weight: 600;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #f3f4f6;
            font-size: 14px;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #064e1a;
            color: white;
        }
        .btn-primary:hover {
            background: #0b6a24;
        }
        .btn-danger {
            background: #ef4444;
            color: white;
        }
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            background: #d1fae5;
            color: #065f46;
        }
        .back-link {
            display: inline-block;
            padding: 10px 20px;
            background: white;
            color: #064e1a;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to System
    </a>
    
    <div class="header">
        <h1><i class="fa fa-tools"></i> System Maintenance Dashboard</h1>
        <p>Monitor system health, tokens, and sync operations</p>
    </div>
    
    <?php if ($message): ?>
        <div class="message">
            <?= $message ?>
        </div>
    <?php endif; ?>
    
    <!-- Health Check -->
    <div class="health-check">
        <h2>🏥 System Health</h2>
        <div class="health-item">
            <span>OAuth Tokens Table</span>
            <span class="health-status <?= $health['token_table'] ? 'health-ok' : 'health-error' ?>">
                <?= $health['token_table'] ? '✅ OK' : '❌ Missing' ?>
            </span>
        </div>
        <div class="health-item">
            <span>Sync History Table</span>
            <span class="health-status <?= $health['sync_table'] ? 'health-ok' : 'health-error' ?>">
                <?= $health['sync_table'] ? '✅ OK' : '❌ Missing' ?>
            </span>
        </div>
        <div class="health-item">
            <span>Upload Directory</span>
            <span class="health-status <?= $health['upload_dir'] ? 'health-ok' : 'health-error' ?>">
                <?= $health['upload_dir'] ? '✅ Writable' : '❌ Not Writable' ?>
            </span>
        </div>
        <div class="health-item">
            <span>Duplicate Prevention (UNIQUE Constraint)</span>
            <span class="health-status <?= $health['unique_constraint'] ? 'health-ok' : 'health-error' ?>">
                <?= $health['unique_constraint'] ? '✅ Active' : '❌ Missing' ?>
            </span>
        </div>
    </div>
    
    <!-- Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <h3>OAuth Tokens</h3>
            <div class="number"><?= $stats['tokens']['total'] ?></div>
            <div class="detail">
                <?= $stats['tokens']['valid'] ?> valid, 
                <?= $stats['tokens']['expired'] ?> expired
            </div>
        </div>
        <div class="stat-card">
            <h3>Sync Operations</h3>
            <div class="number"><?= $stats['sync']['total'] ?></div>
            <div class="detail">
                <?= $stats['sync']['unique_faculty'] ?> unique faculty
            </div>
        </div>
        <div class="stat-card">
            <h3>Faculty Status</h3>
            <div class="number"><?= $stats['faculty']['synced'] ?>/<?= $stats['faculty']['total'] ?></div>
            <div class="detail">
                Synced (<?= $stats['faculty']['outdated'] ?> outdated)
            </div>
        </div>
        <div class="stat-card">
            <h3>Last Sync</h3>
            <div class="number">
                <?php if ($stats['sync']['last_sync']): ?>
                    <?= timeAgo($stats['sync']['last_sync']) ?>
                <?php else: ?>
                    Never
                <?php endif; ?>
            </div>
            <div class="detail">System-wide</div>
        </div>
    </div>
    
    <!-- Maintenance Actions -->
    <div class="section">
        <h2>🔧 Maintenance Actions</h2>
        <form method="POST" style="display: flex; gap: 10px;">
            <input type="hidden" name="action" value="cleanup_tokens">
            <button type="submit" class="btn btn-primary">
                <i class="fa fa-broom"></i> Clean Up Expired Tokens
            </button>
        </form>
    </div>
    
    <!-- Active Tokens -->
    <div class="section">
        <h2>🔑 Active OAuth Tokens (<?= count($activeTokens) ?>)</h2>
        <?php if (empty($activeTokens)): ?>
            <p style="color: #9ca3af;">No active tokens</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Expires At</th>
                        <th>Time Until Expiry</th>
                        <th>Has Refresh Token</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($activeTokens as $token): 
                        $expiresIn = strtotime($token['expires_at']) - time();
                        $hours = floor($expiresIn / 3600);
                        $mins = floor(($expiresIn % 3600) / 60);
                    ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($token['username']) ?></strong></td>
                            <td>
                                <?php 
                                if ($token['user_role'] === 'admin') {
                                    echo 'Admin';
                                } else {
                                    echo ucfirst($token['coordinator_type']) . ' Coordinator';
                                }
                                ?>
                            </td>
                            <td><?= date('M d, Y H:i', strtotime($token['expires_at'])) ?></td>
                            <td><?= $hours ?>h <?= $mins ?>m</td>
                            <td>
                                <?= !empty($token['refresh_token']) ? '✅ Yes' : '❌ No' ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Recent Sync Activity -->
    <div class="section">
        <h2>📊 Recent Sync Activity (Last 10)</h2>
        <?php if (empty($recentSyncs)): ?>
            <p style="color: #9ca3af;">No sync history</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Date/Time</th>
                        <th>Action</th>
                        <th>Faculty</th>
                        <th>HR Employee ID</th>
                        <th>Synced By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentSyncs as $sync): ?>
                        <tr>
                            <td><?= date('M d, Y H:i', strtotime($sync['synced_at'])) ?></td>
                            <td>
                                <span style="padding: 4px 8px; border-radius: 8px; font-size: 12px; font-weight: 600; 
                                             background: <?= $sync['action_type'] === 'import' ? '#dbeafe' : '#fef3c7' ?>; 
                                             color: <?= $sync['action_type'] === 'import' ? '#1e40af' : '#92400e' ?>;">
                                    <?= ucfirst($sync['action_type']) ?>
                                </span>
                            </td>
                            <td><strong><?= htmlspecialchars($sync['faculty_name']) ?></strong></td>
                            <td><code><?= htmlspecialchars($sync['hr_employee_id']) ?></code></td>
                            <td><?= htmlspecialchars($sync['username']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

</body>
</html>