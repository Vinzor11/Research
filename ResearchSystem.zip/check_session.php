<?php
session_start();
echo "<pre>";
echo "=== SESSION DEBUG ===\n";
echo "Session ID: " . session_id() . "\n";
echo "User ID: " . ($_SESSION['user_id'] ?? 'not set') . "\n";
echo "Username: " . ($_SESSION['username'] ?? 'not set') . "\n";
echo "Auth Method: " . ($_SESSION['auth_method'] ?? 'not set') . "\n";
echo "HR System URL: " . ($_SESSION['hr_system_url'] ?? 'not set') . "\n";
echo "HR Access Token: " . (isset($_SESSION['hr_access_token']) ? 'EXISTS (length: ' . strlen($_SESSION['hr_access_token']) . ')' : 'NOT SET') . "\n";
echo "HR Employee ID: " . ($_SESSION['hr_employee_id'] ?? 'not set') . "\n";
echo "\nFull Session:\n";
print_r($_SESSION);
echo "</pre>";