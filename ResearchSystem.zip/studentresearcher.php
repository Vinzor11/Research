<?php
/**
 * ============================================================================
 * Student Researcher Management Page
 * ============================================================================
 * FIXED: Added coordinator type check to prevent faculty coordinators from accessing
 * ============================================================================
 */

session_start();

// STEP 1: Basic authentication check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';
require_once 'spa_helper.php';

// Access control
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get all coordinator types for the current user from coordinator_assignments table
$userCoordinatorTypes = [];
if ($userRole === 'coordinator') {
    // Get employee_id for current user
    $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
    $empStmt->bind_param("i", $userId);
    $empStmt->execute();
    $empResult = $empStmt->get_result();
    if ($empRow = $empResult->fetch_assoc()) {
        $employeeId = $empRow['employee_id'];
        if ($employeeId) {
            // Get all active coordinator types for this employee
            $typeStmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'");
            $typeStmt->bind_param("s", $employeeId);
            $typeStmt->execute();
            $typeResult = $typeStmt->get_result();
            while ($typeRow = $typeResult->fetch_assoc()) {
                $userCoordinatorTypes[] = $typeRow['coordinator_type'];
            }
            $typeStmt->close();
        }
    }
    $empStmt->close();
}

// Determine visibility based on all assigned coordinator types
$isAdmin = ($userRole === 'admin');
$showFaculty = $isAdmin || in_array('faculty', $userCoordinatorTypes);
$showStudent = $isAdmin || in_array('student', $userCoordinatorTypes);

/**
 * ============================================================================
 * CRITICAL FIX: Add coordinator type check
 * ============================================================================
 * Check if user has student coordinator access (via coordinator_assignments)
 */
if ($userRole === 'coordinator' && !in_array('student', $userCoordinatorTypes)) {
    header("Location: research.php");
    exit;
}

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Delete functionality
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delId = (int) $_GET['delete'];
    
    // Check permissions: admin can delete any, coordinators only their own
    $checkQuery = "SELECT id, created_by, CONCAT(last_name, ', ', first_name) as name 
                   FROM student_researchers WHERE id = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("i", $delId);
    $checkStmt->execute();
    $studentInfo = $checkStmt->get_result()->fetch_assoc();
    
    if (!$studentInfo) {
        die("Student not found");
    }
    
    // Authorization check
    if ($userRole !== 'admin' && $studentInfo['created_by'] != $userId) {
        die("Unauthorized: You can only delete student researchers you created");
    }
    
    $studentName = $studentInfo['name'];
    
    $stmt = $conn->prepare("DELETE FROM student_researchers WHERE id = ?");
    $stmt->bind_param("i", $delId);
    $stmt->execute();
    
    // Optional: Log the deletion
    // logActivity($conn, $userId, 'delete', 'student_researchers', $delId, "Deleted student researcher: $studentName");
    
    header("Location: studentresearcher.php");
    exit;
}

// Build WHERE clause based on user role
$whereConditions = [];
$params = [];
$types = "";

// Role-based filtering
if ($userRole !== 'admin') {
    // Coordinators only see their own students
    $whereConditions[] = "sr.created_by = ?";
    $params[] = $userId;
    $types .= "i";
}

// Search filtering
if ($search !== '') {
    $searchCondition = "(sr.student_number LIKE ? OR sr.last_name LIKE ? OR sr.first_name LIKE ? OR sr.middle_name LIKE ? OR sr.course_year_section LIKE ? OR sr.department LIKE ?)";
    $whereConditions[] = $searchCondition;
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like, $like, $like]);
    $types .= "ssssss";
}

// Get statistics with role-based filtering
$statsWhere = "";
$statsParams = [];
$statsTypes = "";

if ($userRole !== 'admin') {
    $statsWhere = " WHERE created_by = ?";
    $statsParams = [$userId];
    $statsTypes = "i";
}

// Total students
$totalQuery = "SELECT COUNT(*) as c FROM student_researchers" . $statsWhere;
$stmt = $conn->prepare($totalQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$totalStudents = $stmt->get_result()->fetch_assoc()['c'];

// Total research outputs (only for user's students)
$totalResearchQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                       INNER JOIN student_researchers sr ON ro.student_id = sr.id" . $statsWhere;
$stmt = $conn->prepare($totalResearchQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$totalResearch = $stmt->get_result()->fetch_assoc()['c'];

// On-going research
$ongoingQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                 INNER JOIN student_researchers sr ON ro.student_id = sr.id 
                 WHERE ro.status='on-going'" . ($statsWhere ? " AND sr.created_by = ?" : "");
$stmt = $conn->prepare($ongoingQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$ongoingResearch = $stmt->get_result()->fetch_assoc()['c'];

// Completed research
$completedQuery = "SELECT COUNT(*) as c FROM research_outputs ro 
                   INNER JOIN student_researchers sr ON ro.student_id = sr.id 
                   WHERE ro.status='completed'" . ($statsWhere ? " AND sr.created_by = ?" : "");
$stmt = $conn->prepare($completedQuery);
if ($userRole !== 'admin') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$completedResearch = $stmt->get_result()->fetch_assoc()['c'];

// Fetch list with research count
$query = "SELECT 
    sr.id, 
    sr.student_number, 
    sr.last_name, 
    sr.first_name, 
    sr.middle_name, 
    sr.course_year_section, 
    sr.department,
    sr.created_by,
    COUNT(ro.id) as research_count
FROM student_researchers sr
LEFT JOIN research_outputs ro ON sr.id = ro.student_id";

if (!empty($whereConditions)) {
    $query .= " WHERE " . implode(" AND ", $whereConditions);
}

$query .= " GROUP BY sr.id ORDER BY sr.id DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Researchers</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.css">
<link rel="stylesheet" href="studentresearcherstyle.css">
<?php else: ?>
<!-- SPA Mode: Load required styles -->
<link rel="stylesheet" href="studentresearcherstyle.css">
<?php endif; ?>
<style>
/* ============================================
   STUDENT RESEARCHERS - UNIFIED DESIGN (Unit Projects Style)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.header-right {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }


/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header-left i { color: #064e1a; font-size: 18px; }

.filter-link {
    font-size: 13px;
    color: #064e1a;
    text-decoration: none;
    font-weight: 500;
}

.filter-link:hover { text-decoration: underline; }

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Add Button */
.btn-add-new {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border: none;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.btn-add-new:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}


/* Responsive */
@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .page-header-banner { padding: 20px; }
    .header-content { flex-direction: column; text-align: center; }
    .header-left { flex-direction: column; }
    .stats-row { flex-wrap: wrap; }
    .stat-card-new { min-width: calc(50% - 8px); flex: unset; }
    .filter-grid { grid-template-columns: 1fr; }
}
</style>
<?php if (!$isSpa): ?>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <?php if ($showFaculty): ?>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php endif; ?>
        <?php if ($showStudent): ?>
            <a href="studentresearcher.php" class="active"><i class="fa fa-user-graduate"></i> Students</a>
        <?php endif; ?>
        <?php if ($isAdmin): ?>
            <a href="users.php"><i class="fa fa-users-gear"></i> User Management</a>
            <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
<?php endif; ?>
    <div class="content">
        <!-- Page Header Banner -->
        <div class="page-header-banner">
            <div class="header-content">
                <div class="header-left">
                    <i class="fa fa-user-graduate header-icon"></i>
                    <div>
                        <h1>Student Researchers</h1>
                        <p>Manage student research profiles and outputs</p>
                    </div>
                </div>
                <div class="header-right">
                    <a href="studentresearcherform.php" class="btn-add-new">
                        <i class="fa fa-plus"></i> Add New Student
                    </a>
                    <span class="role-badge" style="background: rgba(255,255,255,0.95); color: <?= $userRole === 'admin' ? '#065f46' : '#92400e' ?>;">
                        <i class="fa fa-<?= $userRole === 'admin' ? 'shield-halved' : 'user-tie' ?>"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        <?= $userRole === 'admin' ? 'Admin' : 'Student Coordinator' ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalStudents ?></div>
                        <div class="label"><?= $userRole !== 'admin' ? 'My' : 'Total' ?> Student Researchers</div>
                    </div>
                    <div class="icon"><i class="fa fa-users"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $totalResearch ?></div>
                        <div class="label"><?= $userRole !== 'admin' ? 'My' : 'Total' ?> Research Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-flask"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $ongoingResearch ?></div>
                        <div class="label">On-going Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-spinner"></i></div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $completedResearch ?></div>
                        <div class="label">Completed Outputs</div>
                    </div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
        </div>

        <!-- Filter Container -->
        <div class="filter-container">
            <div class="filter-header">
                <div class="filter-header-left">
                    <i class="fa fa-filter"></i>
                </div>
                <a href="studentresearcher.php" class="filter-link">Filter Students</a>
            </div>
            
            <form id="filterForm" method="GET">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label>Department</label>
                        <select name="department" onchange="this.form.submit()">
                            <option value="">All Departments</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Course</label>
                        <select name="course" onchange="this.form.submit()">
                            <option value="">All Courses</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="search" placeholder="Search by ID, name, course, department..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    
                    <div class="filter-actions">
                        <?php if ($search): ?>
                            <a href="studentresearcher.php" class="clear-btn" title="Clear Filters">
                                <i class="fa fa-times"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-wrapper">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student Number</th>
                            <th>Name</th>
                            <th>Course & Year</th>
                            <th>Department</th>
                            <th>Outputs</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($students)): ?>
                            <tr>
                                <td colspan="7">
                                    <div class="no-data">
                                        <i class="fa fa-inbox"></i>
                                        <p>No student records found.</p>
                                        <?php if ($userRole !== 'admin'): ?>
                                            <p style="font-size: 0.9em; color: #666;">You can only see students you've added to the system.</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php else: foreach($students as $s): 
                            $fullname = $s['last_name'] . ', ' . $s['first_name'] . ($s['middle_name'] ? ' '.$s['middle_name'] : '');
                            $canDelete = ($userRole === 'admin') || ($s['created_by'] == $userId);
                        ?>
                        <tr>
                            <td><?= $s['id'] ?></td>
                            <td><strong><?= htmlspecialchars($s['student_number']) ?></strong></td>
                            <td style="text-align:left; padding-left:16px;"><?= htmlspecialchars($fullname) ?></td>
                            <td><?= htmlspecialchars($s['course_year_section']) ?></td>
                            <td><?= htmlspecialchars($s['department']) ?></td>
                            <td>
                                <span class="badge">
                                    <i class="fa fa-file-alt"></i>
                                    <?= $s['research_count'] ?> Outputs
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-view" onclick="viewProfile(<?= $s['id'] ?>)">
                                        <i class="fa fa-eye"></i> View
                                    </button>
                                    <?php if ($canDelete): ?>
                                        <button class="btn-delete" onclick="confirmDelete(<?= $s['id'] ?>, '<?= htmlspecialchars($fullname, ENT_QUOTES) ?>')">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php if (!$isSpa): ?>
</div>
<?php endif; ?>

<script>
// Debounced search
let searchTimeout;
const searchInput = document.querySelector('input[name="search"]');
if (searchInput) {
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.getElementById('filterForm').submit();
        }, 400);
    });
}

// View profile function
function viewProfile(id) {
    window.location.href = 'studentresearcherprofile.php?id=' + id;
}

// Confirm delete function
function confirmDelete(id, name) {
    if (confirm('Are you sure you want to delete student "' + name + '"?\n\nThis will also delete all their research outputs.')) {
        window.location.href = 'studentresearcher.php?delete=' + id;
    }
}
</script>

<?php if (!$isSpa): ?>
</body>
</html>
<?php endif; ?>
