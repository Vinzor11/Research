<?php
/**
 * SPA Helper Functions
 * Provides utilities for Single Page Application functionality
 */

/**
 * Check if the current request is an SPA (AJAX) request
 * @return bool
 */
function isSpaRequest() {
    return (
        isset($_GET['spa']) && $_GET['spa'] === '1'
    ) || (
        isset($_SERVER['HTTP_X_SPA_REQUEST']) && $_SERVER['HTTP_X_SPA_REQUEST'] === '1'
    ) || (
        isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
    );
}

/**
 * Start SPA content output
 * If SPA request, output only the content without full HTML structure
 * @param string $pageTitle - The page title
 */
function spaContentStart($pageTitle = '') {
    if (isSpaRequest()) {
        // For SPA requests, we'll capture output and return only the main content
        ob_start();
        return true;
    }
    return false;
}

/**
 * Get the opening HTML for non-SPA requests
 * Returns empty string for SPA requests
 */
function getSpaHeader($pageTitle, $extraHead = '') {
    if (isSpaRequest()) {
        return '';
    }
    
    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$pageTitle}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    {$extraHead}
</head>
<body>
HTML;
}

/**
 * Get the sidebar HTML for non-SPA requests
 * Returns empty string for SPA requests
 */
function getSpaSidebar($activePage = '', $userRole = 'admin', $coordinatorType = null) {
    if (isSpaRequest()) {
        return '';
    }
    
    $showFaculty = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'faculty');
    $showStudent = ($userRole === 'admin') || ($userRole === 'coordinator' && $coordinatorType === 'student');
    $isAdmin = ($userRole === 'admin');
    
    $dashboardActive = $activePage === 'dashboard' ? 'class="active"' : '';
    $facultyActive = $activePage === 'faculty' ? 'class="active"' : '';
    $studentsActive = $activePage === 'students' ? 'class="active"' : '';
    $usersActive = $activePage === 'users' ? 'class="active"' : '';
    $oauthActive = $activePage === 'oauth' ? 'class="active"' : '';
    $coordinatorsActive = $activePage === 'coordinators' ? 'class="active"' : '';
    $logsActive = $activePage === 'logs' ? 'class="active"' : '';
    
    $facultyLink = $showFaculty ? "<a href=\"facultyresearcher.php\" {$facultyActive}><i class=\"fa fa-chalkboard-teacher\"></i> Faculty</a>" : '';
    $studentsLink = $showStudent ? "<a href=\"studentresearcher.php\" {$studentsActive}><i class=\"fa fa-user-graduate\"></i> Students</a>" : '';
    $adminLinks = '';
    
    if ($isAdmin) {
        $adminLinks = <<<HTML
            <a href="users.php" {$usersActive}><i class="fa fa-users-gear"></i> User Management</a>
            <a href="oauth_settings.php" {$oauthActive}><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php" {$coordinatorsActive}><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="activity_logs.php" {$logsActive}><i class="fa fa-history"></i> Activity Logs</a>
HTML;
    }
    
    return <<<HTML
<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php" {$dashboardActive}><i class="fa fa-dashboard"></i> Dashboard</a>
        {$facultyLink}
        {$studentsLink}
        {$adminLinks}
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>
HTML;
}

/**
 * Get the main content wrapper start for non-SPA requests
 * For SPA requests, returns only the inner content wrapper
 */
function getSpaMainStart() {
    if (isSpaRequest()) {
        return '';
    }
    return '<div class="main">';
}

/**
 * Get the main content wrapper end for non-SPA requests
 */
function getSpaMainEnd() {
    if (isSpaRequest()) {
        return '';
    }
    return '</div>';
}

/**
 * Get the footer HTML for non-SPA requests
 * Returns empty string for SPA requests
 */
function getSpaFooter($extraScripts = '') {
    if (isSpaRequest()) {
        return $extraScripts; // Still include scripts for SPA
    }
    
    return <<<HTML
    {$extraScripts}
</body>
</html>
HTML;
}

/**
 * Redirect to SPA app shell if not an SPA request
 * This ensures all pages are accessed through the single sidebar shell
 * @param string $targetUrl - The actual PHP file to load in the SPA
 */
function redirectToSpa($targetUrl) {
    if (!isSpaRequest()) {
        // Redirect to app.php with the target URL
        header("Location: app.php?load=" . urlencode($targetUrl));
        exit;
    }
}
