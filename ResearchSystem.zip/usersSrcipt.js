let deleteUserIdGlobal = null;

function openEditModal(user) {
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editUsername').value = user.username;
    document.getElementById('editRole').value = user.role;
    document.getElementById('editPassword').value = '';
    
    if (user.role === 'coordinator') {
        document.getElementById('editCoordinatorTypeGroup').style.display = 'block';
        document.getElementById('editCoordinatorType').value = user.coordinator_type || '';
        document.getElementById('editCoordinatorType').required = true;
    } else {
        document.getElementById('editCoordinatorTypeGroup').style.display = 'none';
        document.getElementById('editCoordinatorType').required = false;
    }
    
    document.getElementById('editModal').classList.add('active');
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('active');
}

function toggleEditCoordinatorType() {
    const role = document.getElementById('editRole').value;
    const coordGroup = document.getElementById('editCoordinatorTypeGroup');
    const coordType = document.getElementById('editCoordinatorType');
    
    if (role === 'coordinator') {
        coordGroup.style.display = 'block';
        coordType.required = true;
    } else {
        coordGroup.style.display = 'none';
        coordType.required = false;
        coordType.value = '';
    }
}

function confirmDelete(userId, username) {
    deleteUserIdGlobal = userId;
    document.getElementById('confirmMessage').innerHTML = 
        `Are you sure you want to delete user <strong>"${username}"</strong>?<br><br>` +
        `This action cannot be undone and will permanently remove the user from the system.`;
    document.getElementById('confirmDialog').classList.add('active');
}

function closeConfirmDialog() {
    document.getElementById('confirmDialog').classList.remove('active');
    deleteUserIdGlobal = null;
}

function executeDelete() {
    if (deleteUserIdGlobal) {
        document.getElementById('deleteUserId').value = deleteUserIdGlobal;
        document.getElementById('deleteForm').submit();
    }
}

// Initialize event listeners when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing event listeners...');
    
    // Edit button listeners
    const editButtons = document.querySelectorAll('.btn-edit');
    console.log('Found edit buttons:', editButtons.length);
    
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            console.log('Edit button clicked');
            const user = {
                id: this.getAttribute('data-id'),
                username: this.getAttribute('data-username'),
                role: this.getAttribute('data-role'),
                coordinator_type: this.getAttribute('data-coordinator-type')
            };
            console.log('User data:', user);
            openEditModal(user);
        });
    });

    // Delete button listeners
    const deleteButtons = document.querySelectorAll('.btn-delete');
    console.log('Found delete buttons:', deleteButtons.length);
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            console.log('Delete button clicked');
            const userId = parseInt(this.getAttribute('data-id'));
            const username = this.getAttribute('data-username');
            console.log('Delete user:', userId, username);
            confirmDelete(userId, username);
        });
    });

    // Close edit modal buttons
    document.querySelectorAll('.close-edit-modal').forEach(button => {
        button.addEventListener('click', function() {
            console.log('Close edit modal clicked');
            closeEditModal();
        });
    });

    // Close confirm dialog buttons
    document.querySelectorAll('.close-confirm-dialog').forEach(button => {
        button.addEventListener('click', function() {
            console.log('Close confirm dialog clicked');
            closeConfirmDialog();
        });
    });

    // Execute delete button
    document.querySelectorAll('.execute-delete').forEach(button => {
        button.addEventListener('click', function() {
            console.log('Execute delete clicked');
            executeDelete();
        });
    });

    // Role change listener
    document.getElementById('editRole').addEventListener('change', function() {
        console.log('Role changed to:', this.value);
        toggleEditCoordinatorType();
    });

    // Close dialogs when clicking outside
    document.getElementById('confirmDialog').addEventListener('click', function(e) {
        if (e.target === this) {
            console.log('Clicked outside confirm dialog');
            closeConfirmDialog();
        }
    });

    document.getElementById('editModal').addEventListener('click', function(e) {
        if (e.target === this) {
            console.log('Clicked outside edit modal');
            closeEditModal();
        }
    });

    // Keyboard support
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            console.log('Escape key pressed');
            closeConfirmDialog();
            closeEditModal();
        }
    });

    // Auto-dismiss success/error messages after 5 seconds
    setTimeout(function() {
        const alert = document.querySelector('.alert');
        if (alert) {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }
    }, 5000);

    // Focus styling for inputs
    document.querySelectorAll('input, select').forEach(element => {
        element.addEventListener('focus', function() {
            this.style.borderColor = 'var(--primary)';
            this.style.outline = 'none';
        });
        element.addEventListener('blur', function() {
            this.style.borderColor = 'var(--gray-200)';
        });
    });
    
    console.log('All event listeners initialized!');
});
