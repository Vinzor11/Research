# OAuth Prompt Parameter Guide

This guide explains how to use the OpenID Connect `prompt` parameter to handle re-authentication scenarios, particularly after access denied errors.

## Table of Contents

1. [Overview](#overview)
2. [The Problem](#the-problem)
3. [The Solution](#the-solution)
4. [Supported Prompt Values](#supported-prompt-values)
5. [Implementation Examples](#implementation-examples)
6. [Best Practices](#best-practices)

## Overview

The HR System OAuth provider supports the OpenID Connect `prompt` parameter, which allows client applications to control the authentication behavior. This is particularly useful when a user needs to sign in with a different account.

**Discovery Endpoint:** `/.well-known/openid-configuration`

The configuration now includes:
```json
{
  "prompt_values_supported": ["none", "login", "consent"]
}
```

## The Problem

When a user attempts to sign in via SSO but is denied access (e.g., their position/unit is not authorized for your system), they see an error like:

```
Access denied: Your account is not authorized to access this system.
Please contact your HR administrator to request access.
```

If the user clicks "Sign in with HR System (SSO)" again, the following happens:

1. User is redirected to HR System's `/oauth/authorize`
2. HR System sees the user is already logged in
3. HR System shows the consent screen (or auto-approves)
4. User is redirected back to your system
5. Your system calls `/oauth/userinfo` and gets rejected again
6. **User is stuck in a loop!**

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Your System    │────▶│   HR System     │────▶│  Your System    │
│  (Access Error) │     │  (Auto-login)   │     │  (Access Error) │
└─────────────────┘     └─────────────────┘     └─────────────────┘
         │                                               │
         └───────────────── Loop ────────────────────────┘
```

## The Solution

Add `prompt=login` to your authorization URL when redirecting users after an access denied error. This forces the HR System to:

1. Log out the currently authenticated user
2. Show the login page
3. Allow the user to sign in with a different account

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Your System    │────▶│   HR System     │────▶│  Your System    │
│  (Access Error) │     │  (Login Page)   │     │  (Success!)     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                        User signs in with
                        authorized account
```

## Supported Prompt Values

| Value | Behavior | Use Case |
|-------|----------|----------|
| `login` | Forces re-authentication. Logs out current user and shows login page. | After access denied errors, or when user wants to switch accounts |
| `consent` | Always shows the consent screen, even if previously approved. | When you need explicit user consent again |
| `none` | Silent authentication. Returns error if user not logged in. | Background token refresh, checking login status |

### prompt=login

Forces the user to re-authenticate, even if they have an active session.

**Authorization URL:**
```
https://hr.example.com/oauth/authorize?
  client_id=YOUR_CLIENT_ID&
  redirect_uri=https://your-system.com/callback&
  response_type=code&
  scope=openid profile email&
  state=abc123&
  prompt=login
```

**Behavior:**
- If user is logged in → Log them out, redirect to login page
- If user is not logged in → Show login page normally

### prompt=consent

Always shows the consent screen, even if the user previously approved access.

**Authorization URL:**
```
https://hr.example.com/oauth/authorize?
  client_id=YOUR_CLIENT_ID&
  redirect_uri=https://your-system.com/callback&
  response_type=code&
  scope=openid profile email&
  state=abc123&
  prompt=consent
```

### prompt=none

Attempts silent authentication without any user interaction.

**Authorization URL:**
```
https://hr.example.com/oauth/authorize?
  client_id=YOUR_CLIENT_ID&
  redirect_uri=https://your-system.com/callback&
  response_type=code&
  scope=openid profile email&
  state=abc123&
  prompt=none
```

**Behavior:**
- If user is logged in → Redirect back with authorization code
- If user is not logged in → Redirect back with error:
  ```
  https://your-system.com/callback?
    error=login_required&
    error_description=User+is+not+authenticated&
    state=abc123
  ```

## Implementation Examples

### Handling Access Denied Errors

When your system receives an access denied error from the HR System userinfo endpoint, modify your "Sign in with HR" button to include `prompt=login`:

#### JavaScript/TypeScript

```typescript
// Normal SSO login (no prompt parameter)
function getLoginUrl(): string {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'openid profile email',
    state: generateState(),
  });
  return `${HR_SYSTEM_URL}/oauth/authorize?${params}`;
}

// SSO login after access denied (with prompt=login)
function getReloginUrl(): string {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'openid profile email',
    state: generateState(),
    prompt: 'login',  // Force re-authentication
  });
  return `${HR_SYSTEM_URL}/oauth/authorize?${params}`;
}

// In your login page component
function LoginPage({ error }: { error?: string }) {
  const isAccessDenied = error === 'access_denied';
  
  // Use prompt=login if user was previously denied access
  const ssoUrl = isAccessDenied ? getReloginUrl() : getLoginUrl();
  
  return (
    <div>
      {isAccessDenied && (
        <div className="error">
          Access denied: Your account is not authorized to access this system.
          Please sign in with a different account.
        </div>
      )}
      
      <a href={ssoUrl}>
        Sign in with HR System (SSO)
      </a>
    </div>
  );
}
```

#### PHP (Laravel)

```php
<?php

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $error = $request->query('error');
        $isAccessDenied = $error === 'access_denied';
        
        // Build OAuth authorization URL
        $params = [
            'client_id' => config('services.hr.client_id'),
            'redirect_uri' => config('services.hr.redirect_uri'),
            'response_type' => 'code',
            'scope' => 'openid profile email',
            'state' => Str::random(40),
        ];
        
        // Add prompt=login if user was denied access
        if ($isAccessDenied) {
            $params['prompt'] = 'login';
        }
        
        $ssoUrl = config('services.hr.base_url') . '/oauth/authorize?' . http_build_query($params);
        
        return view('auth.login', [
            'ssoUrl' => $ssoUrl,
            'error' => $error,
            'isAccessDenied' => $isAccessDenied,
        ]);
    }
}
```

```blade
{{-- resources/views/auth/login.blade.php --}}
@if($isAccessDenied)
    <div class="alert alert-danger">
        Access denied: Your account is not authorized to access this system.
        Please sign in with a different account.
    </div>
@endif

<a href="{{ $ssoUrl }}" class="btn btn-primary">
    Sign in with HR System (SSO)
</a>
```

#### Python (Flask)

```python
from flask import Flask, redirect, request, render_template, session
from urllib.parse import urlencode
import secrets

app = Flask(__name__)

HR_SYSTEM_URL = 'https://hr.example.com'
CLIENT_ID = 'your-client-id'
REDIRECT_URI = 'https://your-system.com/callback'

@app.route('/login')
def login():
    error = request.args.get('error')
    is_access_denied = error == 'access_denied'
    
    # Build OAuth authorization URL
    params = {
        'client_id': CLIENT_ID,
        'redirect_uri': REDIRECT_URI,
        'response_type': 'code',
        'scope': 'openid profile email',
        'state': secrets.token_urlsafe(32),
    }
    
    # Add prompt=login if user was denied access
    if is_access_denied:
        params['prompt'] = 'login'
    
    sso_url = f"{HR_SYSTEM_URL}/oauth/authorize?{urlencode(params)}"
    
    return render_template('login.html', 
        sso_url=sso_url, 
        error=error,
        is_access_denied=is_access_denied
    )
```

### Detecting Access Denied from UserInfo

When calling the userinfo endpoint, handle the 403 response:

```typescript
async function getUserInfo(accessToken: string): Promise<UserInfo> {
  const response = await fetch(`${HR_SYSTEM_URL}/oauth/userinfo`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/json',
    },
  });

  if (response.status === 403) {
    const error = await response.json();
    // error = { error: 'access_denied', error_description: 'Your unit or position does not have access...' }
    
    // Redirect to login with error parameter
    // Your login page should then use prompt=login for the SSO button
    window.location.href = '/login?error=access_denied';
    throw new Error('Access denied');
  }

  if (!response.ok) {
    throw new Error(`UserInfo failed: ${response.status}`);
  }

  return await response.json();
}
```

### Adding a "Switch Account" Button

You can also provide a dedicated "Switch Account" or "Sign in with different account" button:

```html
<!-- Always uses prompt=login to force re-authentication -->
<a href="https://hr.example.com/oauth/authorize?client_id=...&prompt=login">
  Sign in with a different account
</a>
```

## Best Practices

### 1. Always Use prompt=login After Access Denied

When a user is denied access, always add `prompt=login` to subsequent SSO attempts:

```typescript
// Store access denied state
if (error === 'access_denied') {
  sessionStorage.setItem('sso_access_denied', 'true');
}

// Check when building SSO URL
const wasAccessDenied = sessionStorage.getItem('sso_access_denied') === 'true';
if (wasAccessDenied) {
  params.append('prompt', 'login');
}
```

### 2. Clear the Flag After Successful Login

Once the user successfully authenticates, clear the access denied flag:

```typescript
// In your OAuth callback handler
async function handleCallback(code: string) {
  const tokens = await exchangeCodeForTokens(code);
  const userInfo = await getUserInfo(tokens.access_token);
  
  // Success! Clear the flag
  sessionStorage.removeItem('sso_access_denied');
  
  // Continue with login...
}
```

### 3. Show Clear Error Messages

Help users understand why they need to use a different account:

```html
<div class="error-message">
  <h3>Access Denied</h3>
  <p>
    Your HR System account (<strong>john.doe@example.com</strong>) is not 
    authorized to access this application.
  </p>
  <p>
    This may be because your position or department does not have access.
    Please try signing in with a different account, or contact your 
    HR administrator to request access.
  </p>
  <a href="/login?prompt=login" class="button">
    Sign in with a different account
  </a>
</div>
```

### 4. Provide Contact Information

Include instructions for users who need access:

```html
<div class="help-text">
  <p>Need access? Contact your HR administrator or submit a request at:</p>
  <a href="mailto:hr@example.com">hr@example.com</a>
</div>
```

## Summary

| Scenario | Solution |
|----------|----------|
| Normal SSO login | No `prompt` parameter needed |
| After access denied | Add `prompt=login` to force re-authentication |
| User wants to switch accounts | Add `prompt=login` |
| Silent token refresh | Use `prompt=none` |
| Re-request consent | Use `prompt=consent` |

## Support

For questions about OAuth integration:

1. Check the [Employees API Guide](./EMPLOYEES_API_GUIDE.md) for general API documentation
2. Check the [API Sync Strategy](./API_SYNC_STRATEGY.md) for data synchronization
3. Contact the HR System administrator for:
   - OAuth client registration
   - Access permissions configuration
   - Technical support
