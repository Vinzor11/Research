<?php
session_start();

// STRICT ADMIN-ONLY ACCESS CHECK
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    if (isset($_SESSION['user_id'])) {
        header("Location: research.php");
    } else {
        header("Location: login.php");
    }
    exit;
}

require 'db.php';
require 'ActivityLogger.php';
require_once 'spa_helper.php';

$isSpa = isSpaRequest();
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'Admin';

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$logger = new ActivityLogger($conn, $_SESSION['user_id']);
$logger->logView('users', null, 'Accessed user management page');

// Fetch users with employee_id for coordinator assignment lookup
$users = [];
$result = $conn->query("SELECT id, username, user_role, coordinator_type, employee_id, created_at FROM users ORDER BY created_at DESC");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

// Build a map of employee_id -> coordinator types from coordinator_assignments
$coordinatorTypesMap = [];
$caResult = $conn->query("SELECT employee_id, coordinator_type FROM coordinator_assignments WHERE status = 'active'");
if ($caResult) {
    while ($row = $caResult->fetch_assoc()) {
        $empId = $row['employee_id'];
        if (!isset($coordinatorTypesMap[$empId])) {
            $coordinatorTypesMap[$empId] = [];
        }
        $coordinatorTypesMap[$empId][] = $row['coordinator_type'];
    }
}

// Statistics - count based on coordinator_assignments for accurate multi-type counting
$totalUsers = count($users);
$adminCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'admin'")->fetch_assoc()['c'];
$coordinatorCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'coordinator'")->fetch_assoc()['c'];

// Count coordinators by type from coordinator_assignments (more accurate for multi-type)
$facultyCoordCount = $conn->query("SELECT COUNT(DISTINCT employee_id) as c FROM coordinator_assignments WHERE coordinator_type = 'faculty' AND status = 'active'")->fetch_assoc()['c'] ?? 0;
$studentCoordCount = $conn->query("SELECT COUNT(DISTINCT employee_id) as c FROM coordinator_assignments WHERE coordinator_type = 'student' AND status = 'active'")->fetch_assoc()['c'] ?? 0;
$personnelCoordCount = $conn->query("SELECT COUNT(DISTINCT employee_id) as c FROM coordinator_assignments WHERE coordinator_type = 'personnel' AND status = 'active'")->fetch_assoc()['c'] ?? 0;

// Count researchers
$researcherCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE user_role = 'researcher'")->fetch_assoc()['c'] ?? 0;
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="usersStyle.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <a href="users.php" class="active"><i class="fa fa-users-gear"></i> User Management</a>
        <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
        <a href="assign_coordinators.php"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
        <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
<?php else: ?>
<!-- SPA Mode: Load required styles -->
<link rel="stylesheet" href="usersStyle.css">
<?php endif; ?>
<link rel="stylesheet" href="page-common.css">
<style>
/* Page-specific filter grid override */
.filter-container .filter-grid {
    grid-template-columns: 1fr 1fr 2fr auto;
}
@media (max-width: 768px) {
    .filter-container .filter-grid { grid-template-columns: 1fr; }
}
</style>

    <div class="content">
        <!-- Page Header Banner -->
        <div class="page-header-banner">
            <div class="header-content">
                <div class="header-left">
                    <i class="fa fa-users-gear header-icon"></i>
                    <div>
                        <h1>User Management</h1>
                        <p>Manage system users and their roles</p>
                    </div>
                </div>
                <div class="header-right">
                    <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #065f46;">
                        <i class="fa fa-shield-halved"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        Admin
                    </span>
                </div>
            </div>
        </div>
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $totalUsers ?></div>
                        <div class="label">Total Users</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);">
                        <i class="fa fa-users"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $adminCount ?></div>
                        <div class="label">Administrators</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--accent) 0%, #34d399 100%);">
                        <i class="fa fa-shield-halved"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $facultyCoordCount ?></div>
                        <div class="label">Faculty Coord</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--warning) 0%, #fbbf24 100%);">
                        <i class="fa fa-chalkboard-user"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $studentCoordCount ?></div>
                        <div class="label">Student Coord</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, var(--purple) 0%, #a78bfa 100%);">
                        <i class="fa fa-user-graduate"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $researcherCount ?></div>
                        <div class="label">Researchers</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%);">
                        <i class="fa fa-flask"></i>
                    </div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-content">
                    <div class="stat-info">
                        <div class="number"><?= $personnelCoordCount ?></div>
                        <div class="label">Personnel Coord</div>
                    </div>
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%);">
                        <i class="fa fa-building-user"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Container -->
        <div class="filter-container">
            <div class="filter-header">
                <div class="filter-header-left">
                    <i class="fa fa-filter"></i>
                    <span style="font-weight: 600; color: #374151;">Filter Users</span>
                </div>
                <a href="users.php" class="filter-link">Clear Filters</a>
            </div>
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Role</label>
                    <select id="filter-role" onchange="filterUsers()">
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="coordinator">Coordinator</option>
                        <option value="researcher">Researcher</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Coordinator Type</label>
                    <select id="filter-coord-type" onchange="filterUsers()">
                        <option value="">All Types</option>
                        <option value="faculty">Faculty</option>
                        <option value="student">Student</option>
                        <option value="personnel">Personnel</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" id="filter-search" placeholder="Search by username..." oninput="debounceSearch()">
                </div>
                <a href="users.php" class="clear-btn" title="Clear Filters">
                    <i class="fa fa-times"></i>
                </a>
            </div>
        </div>

        <!-- Users Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-title">
                    <i class="fa fa-list"></i>
                    All System Users
                </div>
            </div>
            <div class="table-container">
                <?php if (empty($users)): ?>
                    <div class="empty-state">
                        <i class="fa fa-users-slash"></i>
                        <p>No users found in the system</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Role</th>
                                <th>Coordinator Type</th>
                                <th>Created Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div class="user-cell">
                                            <div class="user-avatar-small">
                                                <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                            </div>
                                            <div class="user-details">
                                                <div class="username"><?= htmlspecialchars($user['username']) ?></div>
                                                <div class="user-id">ID: <?= $user['id'] ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <!-- FIXED: Changed $user['role'] to $user['user_role'] -->
                                        <span class="badge badge-<?= $user['user_role'] ?>">
                                            <i class="fa fa-<?= $user['user_role'] === 'admin' ? 'shield-halved' : 'user-tie' ?>"></i>
                                            <?= ucfirst($user['user_role']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['user_role'] === 'coordinator'): ?>
                                            <?php 
                                            // Get all coordinator types from coordinator_assignments
                                            $userCoordTypes = [];
                                            if (!empty($user['employee_id']) && isset($coordinatorTypesMap[$user['employee_id']])) {
                                                $userCoordTypes = $coordinatorTypesMap[$user['employee_id']];
                                            }
                                            ?>
                                            <?php if (!empty($userCoordTypes)): ?>
                                                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                                <?php foreach ($userCoordTypes as $cType): ?>
                                                    <span class="badge badge-<?= $cType ?>">
                                                        <i class="fa fa-<?= $cType === 'faculty' ? 'chalkboard-user' : ($cType === 'student' ? 'user-graduate' : 'building') ?>"></i>
                                                        <?= ucfirst($cType) ?>
                                                    </span>
                                                <?php endforeach; ?>
                                                </div>
                                            <?php elseif ($user['coordinator_type']): ?>
                                                <span class="badge badge-<?= $user['coordinator_type'] ?>">
                                                    <i class="fa fa-<?= $user['coordinator_type'] === 'faculty' ? 'chalkboard-user' : ($user['coordinator_type'] === 'student' ? 'user-graduate' : 'building') ?>"></i>
                                                    <?= ucfirst($user['coordinator_type']) ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color: var(--gray-400);">Not Set</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span style="color: var(--gray-400);">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('M d, Y - g:i A', strtotime($user['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
<script>
// Debounce for search input
let searchTimeout;
function debounceSearch() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(filterUsers, 300);
}

// Filter users client-side
function filterUsers() {
    const roleFilter = document.getElementById('filter-role').value.toLowerCase();
    const coordTypeFilter = document.getElementById('filter-coord-type').value.toLowerCase();
    const searchFilter = document.getElementById('filter-search').value.toLowerCase();
    
    const rows = document.querySelectorAll('.table-section tbody tr');
    
    rows.forEach(row => {
        const roleCell = row.querySelector('td:nth-child(2)');
        const coordTypeCell = row.querySelector('td:nth-child(3)');
        const usernameCell = row.querySelector('.username');
        
        const role = roleCell ? roleCell.textContent.toLowerCase() : '';
        const coordType = coordTypeCell ? coordTypeCell.textContent.toLowerCase() : '';
        const username = usernameCell ? usernameCell.textContent.toLowerCase() : '';
        
        let showRow = true;
        
        // Filter by role
        if (roleFilter && !role.includes(roleFilter)) {
            showRow = false;
        }
        
        // Filter by coordinator type
        if (coordTypeFilter && !coordType.includes(coordTypeFilter)) {
            showRow = false;
        }
        
        // Filter by search
        if (searchFilter && !username.includes(searchFilter)) {
            showRow = false;
        }
        
        row.style.display = showRow ? '' : 'none';
    });
}
</script>
<?php if (!$isSpa): ?>
</div>

</body>
</html>
<?php endif; ?>