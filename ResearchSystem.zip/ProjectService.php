<?php
/**
 * ProjectService.php
 * Post-Approval Operations for Research Projects
 * 
 * Handles the lifecycle of approved research proposals that have been
 * elevated to official On-Going Research Projects.
 * 
 * SERVICES PROVIDED:
 * - Progress Report Management
 * - Extension/Amendment Requests
 * - Completion Report Submission
 * - Research Output Reporting
 * - Field Change Requests (for locked proposal fields)
 * 
 * DESIGN PRINCIPLES:
 * - Researchers can only modify their own projects
 * - Locked fields require formal amendment process
 * - All changes logged to immutable audit trail
 * - RMIS Form compliance (D1 for On-Going, D for Completed)
 * 
 * @version 1.0
 * @date 2026-02-05
 */

require_once __DIR__ . '/WorkflowEngine.php';
require_once __DIR__ . '/WorkflowAuditLogger.php';

class ProjectService {
    private $conn;
    private $workflowEngine;
    private $auditLogger;
    private $userId;
    private $userRole;
    private $employeeId;
    
    /**
     * Constructor
     */
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        $this->workflowEngine = new WorkflowEngine($dbConnection);
        $this->auditLogger = new WorkflowAuditLogger($dbConnection);
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->employeeId = $_SESSION['employee_id'] ?? null;
    }
    
    /**
     * Get workflow engine instance
     */
    public function getWorkflowEngine() {
        return $this->workflowEngine;
    }
    
    // ========================================
    // PROJECT RETRIEVAL
    // ========================================
    
    /**
     * Get project by ID (approved submission with project data)
     */
    public function getProject($projectId) {
        $stmt = $this->conn->prepare("
            SELECT 
                rs.*,
                rst.type_code,
                rst.type_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE rs.id = ? AND rs.status = 'approved'
        ");
        
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $project = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($project) {
            // Add computed fields
            $project['project_status_label'] = WorkflowEngine::getProjectStatusLabel($project['project_status']);
            $project['project_status_class'] = WorkflowEngine::getProjectStatusClass($project['project_status']);
            $project['is_locked'] = (bool)$project['is_proposal_locked'];
            $project['locked_fields'] = WorkflowEngine::getLockedFields();
            
            // Get progress reports count
            $project['progress_reports_count'] = $this->getProgressReportsCount($projectId);
            
            // Get extensions count
            $project['extensions_count'] = $this->getExtensionsCount($projectId);
            
            // Get outputs count
            $project['outputs_count'] = $this->getOutputsCount($projectId);
            
            // Decode JSON fields
            if (!empty($project['budget_breakdown'])) {
                $project['budget_breakdown'] = json_decode($project['budget_breakdown'], true);
            }
            
            // Get project actions with availability status and reasons
            $project['actions'] = $this->workflowEngine->getProjectActions($project);
            
            // Calculate timeline info
            $project['timeline_info'] = $this->calculateTimelineInfo($project);
        }
        
        return $project;
    }
    
    /**
     * Get researcher's projects
     */
    public function getResearcherProjects($filters = [], $page = 1, $perPage = 15) {
        $where = ["rs.status = 'approved'", "(rs.created_by = ? OR rs.researcher_user_id = ?)"];
        $params = [$this->userId, $this->userId];
        $types = "ii";
        
        if (!empty($filters['project_status'])) {
            $where[] = "rs.project_status = ?";
            $params[] = $filters['project_status'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'sss';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Count
        $countSql = "SELECT COUNT(*) as total FROM research_submissions rs $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        $countStmt->bind_param($types, ...$params);
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Data
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.project_code,
                rs.title,
                rs.project_status,
                rs.rmis_form_mapping,
                rs.proposed_start_date,
                rs.current_end_date,
                rs.elevated_to_project_at,
                rs.completed_at,
                rs.extension_count,
                rst.type_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            $whereClause
            ORDER BY rs.elevated_to_project_at DESC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        foreach ($data as &$row) {
            $row['project_status_label'] = WorkflowEngine::getProjectStatusLabel($row['project_status']);
            $row['project_status_class'] = WorkflowEngine::getProjectStatusClass($row['project_status']);
            
            // Get full project to compute actions
            $fullProject = $this->getProject($row['id']);
            if ($fullProject) {
                $row['actions'] = $fullProject['actions'];
                $row['timeline_info'] = $fullProject['timeline_info'];
                $row['progress_reports_count'] = $fullProject['progress_reports_count'];
            }
        }
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    // ========================================
    // PROGRESS REPORTS
    // ========================================
    
    /**
     * Create progress report
     */
    public function createProgressReport($projectId, $data) {
        $project = $this->getProject($projectId);
        
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        if (!$this->workflowEngine->canSubmitProgressReport($project)) {
            return ['success' => false, 'error' => 'You cannot submit progress reports for this project'];
        }
        
        // Validate required fields
        $required = ['report_period', 'period_start_date', 'period_end_date', 'activities_conducted'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['success' => false, 'error' => ucfirst(str_replace('_', ' ', $field)) . ' is required'];
            }
        }
        
        // Validate dates are within project period
        $projectStart = $project['proposed_start_date'];
        $projectEnd = $project['current_end_date'] ?? $project['proposed_end_date'];
        $periodStart = $data['period_start_date'];
        $periodEnd = $data['period_end_date'];
        
        if ($periodStart < $projectStart) {
            return ['success' => false, 'error' => 'Period start date cannot be before the project start date (' . date('M d, Y', strtotime($projectStart)) . ')'];
        }
        
        if ($periodStart > $projectEnd) {
            return ['success' => false, 'error' => 'Period start date cannot be after the project end date (' . date('M d, Y', strtotime($projectEnd)) . ')'];
        }
        
        if ($periodEnd < $projectStart) {
            return ['success' => false, 'error' => 'Period end date cannot be before the project start date (' . date('M d, Y', strtotime($projectStart)) . ')'];
        }
        
        if ($periodEnd > $projectEnd) {
            return ['success' => false, 'error' => 'Period end date cannot be after the project end date (' . date('M d, Y', strtotime($projectEnd)) . ')'];
        }
        
        if ($periodEnd < $periodStart) {
            return ['success' => false, 'error' => 'Period end date must be on or after the period start date'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_progress_reports (
                    project_id,
                    report_period,
                    period_start_date,
                    period_end_date,
                    activities_conducted,
                    accomplishments,
                    milestones_achieved,
                    challenges_encountered,
                    remedial_actions,
                    completion_percentage,
                    is_on_track,
                    deviation_remarks,
                    budget_utilized,
                    budget_remaining,
                    financial_remarks,
                    next_period_plans,
                    assistance_needed,
                    status,
                    submitted_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)
            ");
            
            $isOnTrack = isset($data['is_on_track']) ? (int)$data['is_on_track'] : 1;
            $completionPct = isset($data['completion_percentage']) ? (int)$data['completion_percentage'] : 0;
            
            $stmt->bind_param(
                "issssssssiisddsssi",
                $projectId,
                $data['report_period'],
                $data['period_start_date'],
                $data['period_end_date'],
                $data['activities_conducted'],
                $data['accomplishments'],
                $data['milestones_achieved'],
                $data['challenges_encountered'],
                $data['remedial_actions'],
                $completionPct,
                $isOnTrack,
                $data['deviation_remarks'],
                $data['budget_utilized'],
                $data['budget_remaining'],
                $data['financial_remarks'],
                $data['next_period_plans'],
                $data['assistance_needed'],
                $this->userId
            );
            
            $stmt->execute();
            $reportId = $this->conn->insert_id;
            $stmt->close();
            
            return [
                'success' => true,
                'message' => 'Progress report created as draft',
                'report_id' => $reportId
            ];
            
        } catch (Exception $e) {
            error_log("ProjectService::createProgressReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Submit progress report for review
     */
    public function submitProgressReport($reportId) {
        $report = $this->getProgressReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['submitted_by'] != $this->userId) {
            return ['success' => false, 'error' => 'You can only submit your own reports'];
        }
        
        if ($report['status'] !== 'draft') {
            return ['success' => false, 'error' => 'Only draft reports can be submitted'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = 'submitted',
                    submitted_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($report['project_id'], 'progress_report_submitted', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => [
                    'report_id' => $reportId,
                    'report_period' => $report['report_period']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Progress report submitted for review'];
            
        } catch (Exception $e) {
            error_log("ProjectService::submitProgressReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get progress report by ID
     */
    public function getProgressReport($reportId) {
        $stmt = $this->conn->prepare("
            SELECT ppr.*, rs.title as project_title, rs.reference_number, rs.project_code
            FROM project_progress_reports ppr
            JOIN research_submissions rs ON ppr.project_id = rs.id
            WHERE ppr.id = ?
        ");
        $stmt->bind_param("i", $reportId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Get progress reports for a project
     */
    public function getProgressReports($projectId, $status = null) {
        $sql = "
            SELECT ppr.*, u.fullname as submitted_by_name
            FROM project_progress_reports ppr
            LEFT JOIN users u ON ppr.submitted_by = u.id
            WHERE ppr.project_id = ?
        ";
        $params = [$projectId];
        $types = "i";
        
        if ($status) {
            $sql .= " AND ppr.status = ?";
            $params[] = $status;
            $types .= "s";
        }
        
        $sql .= " ORDER BY ppr.period_end_date DESC";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $result;
    }
    
    /**
     * Start coordinator review of progress report (submitted → reviewed)
     * Note: Progress reports use a simpler workflow where 'reviewed' indicates review in progress
     */
    public function startProgressReportReview($reportId) {
        $report = $this->getProgressReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'submitted') {
            return ['success' => false, 'error' => 'Cannot start review from current status'];
        }
        
        // Check permission - must be coordinator for this researcher type
        $project = $this->getProject($report['project_id']);
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'You are not assigned to review this report'];
        }
        
        // Check for self-review (cannot review your own progress report)
        if ($report['submitted_by'] == $this->userId) {
            return ['success' => false, 'error' => 'You cannot review a progress report you submitted'];
        }
        
        try {
            // Progress reports use 'reviewed' status to indicate review is in progress/complete
            // The reviewer can then accept or return the report
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = 'reviewed',
                    reviewed_by = ?,
                    reviewed_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $this->userId, $reportId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($report['project_id'], 'progress_report_review_started', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => [
                    'report_id' => $reportId,
                    'report_period' => $report['report_period']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Progress report review started'];
            
        } catch (Exception $e) {
            error_log("ProjectService::startProgressReportReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Review progress report (Coordinator/RO action)
     */
    public function reviewProgressReport($reportId, $decision, $comments = null) {
        $report = $this->getProgressReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($decision, ['accepted', 'returned'])) {
            return ['success' => false, 'error' => 'Invalid decision'];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        $isROAdmin = $this->workflowEngine->isResearchOfficeAdmin();
        
        if (!$isCoordinator && !$isROAdmin) {
            return ['success' => false, 'error' => 'You do not have permission to review this report'];
        }
        
        try {
            $newStatus = $decision === 'accepted' ? 'accepted' : 'returned';
            
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW(),
                    review_comments = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sisi", $newStatus, $this->userId, $comments, $reportId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($report['project_id'], 'progress_report_reviewed', [
                'performed_by' => $this->userId,
                'performed_by_role' => $isROAdmin ? 'research_office' : 'coordinator',
                'metadata' => [
                    'report_id' => $reportId,
                    'decision' => $decision,
                    'comments' => $comments
                ]
            ]);
            
            return ['success' => true, 'message' => 'Progress report ' . $decision];
            
        } catch (Exception $e) {
            error_log("ProjectService::reviewProgressReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // UNIFIED WORKFLOW - PROGRESS REPORTS
    // Status lifecycle: draft → submitted → under_coordinator_review → 
    //   [returned_for_revision] → endorsed → under_ro_review → approved/rejected
    // ========================================
    
    /**
     * Endorse progress report (Coordinator → Research Office)
     * Status: under_coordinator_review → endorsed
     */
    public function endorseProgressReport($reportId, $validationData = [], $remarks = null) {
        $report = $this->getProgressReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        // Allow endorsement from either submitted or under_coordinator_review (unified and legacy statuses)
        if (!in_array($report['status'], ['submitted', 'under_coordinator_review', 'reviewed'])) {
            return ['success' => false, 'error' => 'Cannot endorse from current status: ' . $report['status']];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to endorse'];
        }
        
        try {
            $previousStatus = $report['status'];
            $newStatus = 'endorsed';
            
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = ?,
                    coordinator_reviewed_by = ?,
                    coordinator_reviewed_at = NOW(),
                    coordinator_remarks = ?,
                    endorsed_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("sisi", $newStatus, $this->userId, $remarks, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'progress_report_endorsed', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => [
                    'report_id' => $reportId,
                    'previous_status' => $previousStatus,
                    'validation_data' => $validationData
                ]
            ]);
            
            return ['success' => true, 'message' => 'Progress report endorsed and forwarded to Research Office'];
            
        } catch (Exception $e) {
            error_log("ProjectService::endorseProgressReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return progress report for revision (Coordinator → Researcher)
     * Status: under_coordinator_review → returned_for_revision
     */
    public function returnProgressReport($reportId, $reason) {
        $report = $this->getProgressReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($report['status'], ['submitted', 'under_coordinator_review', 'reviewed'])) {
            return ['success' => false, 'error' => 'Cannot return from current status'];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to return'];
        }
        
        try {
            $newStatus = 'returned_for_revision';
            
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = ?,
                    coordinator_reviewed_by = ?,
                    coordinator_reviewed_at = NOW(),
                    return_reason = ?,
                    review_comments = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sissi", $newStatus, $this->userId, $reason, $reason, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'progress_report_returned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => ['report_id' => $reportId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Progress report returned for revision'];
            
        } catch (Exception $e) {
            error_log("ProjectService::returnProgressReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start RO review of progress report (endorsed → under_ro_review)
     */
    public function startROProgressReview($reportId) {
        $report = $this->getProgressReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'endorsed') {
            return ['success' => false, 'error' => 'Can only start RO review on endorsed reports'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can start RO review'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = 'under_ro_review',
                    ro_reviewed_by = ?,
                    ro_reviewed_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $this->userId, $reportId);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'message' => 'RO review started'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve progress report (Research Office - FINAL)
     * Status: endorsed/under_ro_review → approved
     */
    public function approveProgressReport($reportId, $remarks = null) {
        $report = $this->getProgressReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        // Allow approval from endorsed or under_ro_review
        if (!in_array($report['status'], ['endorsed', 'under_ro_review', 'reviewed', 'accepted'])) {
            return ['success' => false, 'error' => 'Cannot approve from current status'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can approve'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = 'approved',
                    ro_reviewed_by = ?,
                    ro_reviewed_at = NOW(),
                    ro_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $remarks, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'progress_report_approved', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return ['success' => true, 'message' => 'Progress report approved'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Reject progress report (Research Office - FINAL)
     * Status: endorsed/under_ro_review → rejected
     */
    public function rejectProgressReport($reportId, $reason) {
        $report = $this->getProgressReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($report['status'], ['endorsed', 'under_ro_review'])) {
            return ['success' => false, 'error' => 'Cannot reject from current status'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can reject'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_progress_reports SET
                    status = 'rejected',
                    ro_reviewed_by = ?,
                    ro_reviewed_at = NOW(),
                    ro_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'progress_report_rejected', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['report_id' => $reportId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Progress report rejected'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Calculate timeline information for a project
     */
    private function calculateTimelineInfo($project) {
        $info = [
            'start_date' => $project['proposed_start_date'] ?? null,
            'original_end_date' => $project['proposed_end_date'] ?? null,
            'current_end_date' => $project['current_end_date'] ?? $project['proposed_end_date'] ?? null,
            'progress_percent' => 0,
            'days_remaining' => null,
            'days_overdue' => null,
            'status' => 'not_started',  // not_started, in_progress, near_deadline, overdue, completed
            'status_label' => 'Not Started'
        ];
        
        if ($project['project_status'] === 'completed') {
            $info['status'] = 'completed';
            $info['status_label'] = 'Completed';
            $info['progress_percent'] = 100;
            return $info;
        }
        
        $startDate = $info['start_date'];
        $endDate = $info['current_end_date'];
        
        if (!$startDate || !$endDate) {
            return $info;
        }
        
        $startTimestamp = strtotime($startDate);
        $endTimestamp = strtotime($endDate);
        $now = time();
        
        if ($now < $startTimestamp) {
            $daysUntilStart = ceil(($startTimestamp - $now) / 86400);
            $info['status'] = 'not_started';
            $info['status_label'] = "Starts in {$daysUntilStart} days";
            $info['progress_percent'] = 0;
        } elseif ($now >= $endTimestamp) {
            $daysOverdue = floor(($now - $endTimestamp) / 86400);
            $info['days_overdue'] = $daysOverdue;
            $info['status'] = 'overdue';
            $info['status_label'] = $daysOverdue > 0 ? "{$daysOverdue} days overdue" : "Due today";
            $info['progress_percent'] = 100;
        } else {
            $totalDuration = $endTimestamp - $startTimestamp;
            $elapsed = $now - $startTimestamp;
            $progressPercent = min(100, round(($elapsed / $totalDuration) * 100));
            $daysRemaining = ceil(($endTimestamp - $now) / 86400);
            
            $info['days_remaining'] = $daysRemaining;
            $info['progress_percent'] = $progressPercent;
            
            if ($daysRemaining <= 7) {
                $info['status'] = 'near_deadline';
                $info['status_label'] = "{$daysRemaining} days remaining";
            } elseif ($daysRemaining <= 30) {
                $info['status'] = 'near_deadline';
                $info['status_label'] = "{$daysRemaining} days remaining";
            } else {
                $info['status'] = 'in_progress';
                $info['status_label'] = "{$daysRemaining} days remaining";
            }
        }
        
        return $info;
    }
    
    private function getProgressReportsCount($projectId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM project_progress_reports WHERE project_id = ?");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result['count'];
    }
    
    // ========================================
    // EXTENSION REQUESTS
    // ========================================
    
    /**
     * Create extension request
     */
    public function createExtensionRequest($projectId, $data) {
        $project = $this->getProject($projectId);
        
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        if (!$this->workflowEngine->canRequestExtension($project)) {
            return ['success' => false, 'error' => 'You cannot request an extension for this project at this time'];
        }
        
        // Validate required fields
        if (empty($data['extension_type'])) {
            return ['success' => false, 'error' => 'Extension type is required'];
        }
        
        if (empty($data['justification'])) {
            return ['success' => false, 'error' => 'Justification is required'];
        }
        
        // Validate based on extension type
        if (in_array($data['extension_type'], ['timeline', 'timeline_budget'])) {
            if (empty($data['requested_end_date'])) {
                return ['success' => false, 'error' => 'Requested end date is required for timeline extension'];
            }
        }
        
        // Validate date format (YYYY-MM-DD) for any non-empty date
        if (!empty($data['requested_end_date'])) {
            // Trim whitespace
            $data['requested_end_date'] = trim($data['requested_end_date']);
            
            // Strict validation for YYYY-MM-DD format
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['requested_end_date'])) {
                return ['success' => false, 'error' => 'Invalid date format. Please use the date picker to select a date (YYYY-MM-DD format required). Received: ' . substr($data['requested_end_date'], 0, 20)];
            }
            
            // Additional validation - verify it's a valid date
            $dateParts = explode('-', $data['requested_end_date']);
            if (!checkdate((int)$dateParts[1], (int)$dateParts[2], (int)$dateParts[0])) {
                return ['success' => false, 'error' => 'Invalid date. Please select a valid date.'];
            }
        } else {
            // Ensure empty/null for non-timeline extensions
            $data['requested_end_date'] = null;
        }
        
        if (in_array($data['extension_type'], ['budget', 'timeline_budget'])) {
            if (empty($data['requested_additional_budget'])) {
                return ['success' => false, 'error' => 'Requested additional budget is required'];
            }
        }
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_extensions (
                    project_id,
                    extension_type,
                    original_end_date,
                    original_budget,
                    requested_end_date,
                    requested_additional_budget,
                    scope_changes,
                    justification,
                    status,
                    requested_by,
                    requested_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, NOW())
            ");
            
            $stmt->bind_param(
                "issssdssi",
                $projectId,
                $data['extension_type'],
                $project['current_end_date'],
                $project['total_budget'],
                $data['requested_end_date'],
                $data['requested_additional_budget'],
                $data['scope_changes'],
                $data['justification'],
                $this->userId
            );
            
            $stmt->execute();
            $extensionId = $this->conn->insert_id;
            $stmt->close();
            
            return [
                'success' => true,
                'message' => 'Extension request created as draft',
                'extension_id' => $extensionId
            ];
            
        } catch (Exception $e) {
            error_log("ProjectService::createExtensionRequest error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Submit extension request
     */
    public function submitExtensionRequest($extensionId) {
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if ($extension['requested_by'] != $this->userId) {
            return ['success' => false, 'error' => 'You can only submit your own extension requests'];
        }
        
        if ($extension['status'] !== 'draft') {
            return ['success' => false, 'error' => 'Only draft requests can be submitted'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'submitted'
                WHERE id = ?
            ");
            $stmt->bind_param("i", $extensionId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($extension['project_id'], 'extension_requested', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request submitted'];
            
        } catch (Exception $e) {
            error_log("ProjectService::submitExtensionRequest error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get extension request by ID
     */
    public function getExtensionRequest($extensionId) {
        $stmt = $this->conn->prepare("
            SELECT pe.*, rs.title as project_title, rs.reference_number, rs.project_code
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            WHERE pe.id = ?
        ");
        $stmt->bind_param("i", $extensionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Get extension requests for a project
     */
    public function getExtensions($projectId) {
        $stmt = $this->conn->prepare("
            SELECT pe.*, u.fullname as requested_by_name
            FROM project_extensions pe
            LEFT JOIN users u ON pe.requested_by = u.id
            WHERE pe.project_id = ?
            ORDER BY pe.created_at DESC
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $result;
    }
    
    private function getExtensionsCount($projectId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM project_extensions WHERE project_id = ?");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result['count'];
    }
    
    // ========================================
    // COMPLETION REPORTS
    // ========================================
    
    /**
     * Create completion report
     * RMIS-Compliant: Enforces hard gate rules before allowing completion
     */
    public function createCompletionReport($projectId, $data) {
        $project = $this->getProject($projectId);
        
        if (!$project) {
            $this->logCompletionAttempt($projectId, false, 'Project not found');
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        // Use detailed eligibility check for better error messages
        $eligibility = $this->workflowEngine->checkCompletionEligibility($project);
        
        if (!$eligibility['allowed']) {
            // Log blocked attempt
            $this->logCompletionAttempt($projectId, false, $eligibility['reason'], $eligibility['missing'] ?? []);
            return ['success' => false, 'error' => $eligibility['reason']];
        }
        
        // Validate required fields
        $required = ['actual_completion_date', 'executive_summary', 'objectives_achieved', 'key_findings', 'deliverables_produced'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['success' => false, 'error' => ucfirst(str_replace('_', ' ', $field)) . ' is required'];
            }
        }
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_completion_reports (
                    project_id,
                    actual_completion_date,
                    executive_summary,
                    objectives_achieved,
                    objectives_achievement_rate,
                    key_findings,
                    conclusions,
                    recommendations,
                    deliverables_produced,
                    publications,
                    patents_filed,
                    technologies_developed,
                    beneficiaries,
                    social_impact,
                    economic_impact,
                    policy_contributions,
                    total_budget_utilized,
                    budget_variance,
                    financial_remarks,
                    lessons_learned,
                    future_research_directions,
                    status,
                    submitted_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)
            ");
            
            $achievementRate = isset($data['objectives_achievement_rate']) ? (int)$data['objectives_achievement_rate'] : null;
            
            $stmt->bind_param(
                "isssisssssssssssddsssi",
                $projectId,
                $data['actual_completion_date'],
                $data['executive_summary'],
                $data['objectives_achieved'],
                $achievementRate,
                $data['key_findings'],
                $data['conclusions'],
                $data['recommendations'],
                $data['deliverables_produced'],
                $data['publications'],
                $data['patents_filed'],
                $data['technologies_developed'],
                $data['beneficiaries'],
                $data['social_impact'],
                $data['economic_impact'],
                $data['policy_contributions'],
                $data['total_budget_utilized'],
                $data['budget_variance'],
                $data['financial_remarks'],
                $data['lessons_learned'],
                $data['future_research_directions'],
                $this->userId
            );
            
            $stmt->execute();
            $reportId = $this->conn->insert_id;
            $stmt->close();
            
            // Log successful completion report creation
            $this->logCompletionAttempt($projectId, true, 'Completion report created successfully');
            
            $this->auditLogger->log($projectId, 'completion_report_created', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return [
                'success' => true,
                'message' => 'Completion report created as draft',
                'report_id' => $reportId
            ];
            
        } catch (Exception $e) {
            error_log("ProjectService::createCompletionReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Submit completion report for review
     */
    public function submitCompletionReport($reportId) {
        $report = $this->getCompletionReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['submitted_by'] != $this->userId) {
            return ['success' => false, 'error' => 'You can only submit your own reports'];
        }
        
        if ($report['status'] !== 'draft') {
            return ['success' => false, 'error' => 'Only draft reports can be submitted'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'submitted',
                    submitted_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_submitted', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return ['success' => true, 'message' => 'Completion report submitted for review'];
            
        } catch (Exception $e) {
            error_log("ProjectService::submitCompletionReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start coordinator review of completion report (submitted → under_coordinator_review)
     */
    public function startCompletionReview($reportId) {
        $report = $this->getCompletionReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'submitted') {
            return ['success' => false, 'error' => 'Cannot start review from current status'];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'You are not assigned to review this report'];
        }
        
        // Check for self-review
        if ($report['submitted_by'] == $this->userId) {
            return ['success' => false, 'error' => 'You cannot review a completion report you submitted'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'under_coordinator_review',
                    coordinator_reviewed_by = ?
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $this->userId, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_review_started', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return ['success' => true, 'message' => 'Completion report review started'];
            
        } catch (Exception $e) {
            error_log("ProjectService::startCompletionReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve completion report (RO action) - marks project as completed
     */
    public function approveCompletionReport($reportId, $notes = null) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can approve completion reports'];
        }
        
        $report = $this->getCompletionReport($reportId);
        
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'endorsed' && $report['status'] !== 'under_ro_review') {
            return ['success' => false, 'error' => 'Report must be endorsed/under RO review to approve'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            // Update completion report
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'approved',
                    ro_reviewed_by = ?,
                    ro_reviewed_at = NOW(),
                    ro_remarks = ?,
                    decision_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $notes, $reportId);
            $stmt->execute();
            $stmt->close();
            
            // Mark project as completed using WorkflowEngine
            $result = $this->workflowEngine->markProjectCompleted($report['project_id'], $reportId, $notes);
            
            if (!$result['success']) {
                throw new Exception($result['error']);
            }
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Completion report approved. Project marked as completed.'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("ProjectService::approveCompletionReport error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // UNIFIED WORKFLOW - COMPLETION REPORTS
    // Status lifecycle: draft → submitted → under_coordinator_review → 
    //   [returned_for_revision] → endorsed → under_ro_review → approved/rejected
    // ========================================
    
    /**
     * Endorse completion report (Coordinator → Research Office)
     * Status: under_coordinator_review → endorsed
     */
    public function endorseCompletionReport($reportId, $validationData = [], $remarks = null) {
        $report = $this->getCompletionReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($report['status'], ['submitted', 'under_coordinator_review'])) {
            return ['success' => false, 'error' => 'Cannot endorse from current status: ' . $report['status']];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to endorse'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'endorsed',
                    coordinator_reviewed_by = ?,
                    coordinator_reviewed_at = NOW(),
                    coordinator_remarks = ?,
                    coordinator_endorsed_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $remarks, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_report_endorsed', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return ['success' => true, 'message' => 'Completion report endorsed and forwarded to Research Office'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return completion report for revision (Coordinator → Researcher)
     * Status: under_coordinator_review → returned_for_revision
     */
    public function returnCompletionReport($reportId, $reason) {
        $report = $this->getCompletionReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($report['status'], ['submitted', 'under_coordinator_review'])) {
            return ['success' => false, 'error' => 'Cannot return from current status'];
        }
        
        // Check permission
        $project = $this->getProject($report['project_id']);
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($project);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to return'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'returned_for_revision',
                    coordinator_reviewed_by = ?,
                    coordinator_reviewed_at = NOW(),
                    return_reason = ?
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_report_returned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => ['report_id' => $reportId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Completion report returned for revision'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start RO review of completion report (endorsed → under_ro_review)
     */
    public function startROCompletionReview($reportId) {
        $report = $this->getCompletionReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'endorsed') {
            return ['success' => false, 'error' => 'Can only start RO review on endorsed reports'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can start RO review'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'under_ro_review',
                    ro_received_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'message' => 'RO review started'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Reject completion report (Research Office - FINAL)
     * Status: endorsed/under_ro_review → rejected
     */
    public function rejectCompletionReport($reportId, $reason) {
        $report = $this->getCompletionReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if (!in_array($report['status'], ['endorsed', 'under_ro_review'])) {
            return ['success' => false, 'error' => 'Cannot reject from current status'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can reject'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'rejected',
                    ro_reviewed_by = ?,
                    ro_reviewed_at = NOW(),
                    ro_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_report_rejected', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['report_id' => $reportId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Completion report rejected'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Resubmit completion report after revision
     * Status: returned_for_revision → submitted
     */
    public function resubmitCompletionReport($reportId, $updatedData = []) {
        $report = $this->getCompletionReport($reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        if ($report['status'] !== 'returned_for_revision') {
            return ['success' => false, 'error' => 'Can only resubmit returned reports'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_completion_reports SET
                    status = 'submitted',
                    submitted_at = NOW(),
                    revision_count = revision_count + 1,
                    return_reason = NULL
                WHERE id = ?
            ");
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($report['project_id'], 'completion_report_resubmitted', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => ['report_id' => $reportId]
            ]);
            
            return ['success' => true, 'message' => 'Completion report resubmitted'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get completion report by ID
     */
    public function getCompletionReport($reportId) {
        $stmt = $this->conn->prepare("
            SELECT pcr.*, 
                   rs.title as project_title, 
                   rs.reference_number, 
                   rs.project_code,
                   u.fullname as submitted_by_name,
                   coord.fullname as coordinator_name,
                   ro.fullname as ro_reviewer_name
            FROM project_completion_reports pcr
            JOIN research_submissions rs ON pcr.project_id = rs.id
            LEFT JOIN users u ON pcr.submitted_by = u.id
            LEFT JOIN users coord ON pcr.coordinator_reviewed_by = coord.id
            LEFT JOIN users ro ON pcr.ro_reviewed_by = ro.id
            WHERE pcr.id = ?
        ");
        $stmt->bind_param("i", $reportId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Get completion report for a project
     */
    public function getProjectCompletionReport($projectId) {
        $stmt = $this->conn->prepare("
            SELECT pcr.*, u.fullname as submitted_by_name
            FROM project_completion_reports pcr
            LEFT JOIN users u ON pcr.submitted_by = u.id
            WHERE pcr.project_id = ?
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Log completion attempt for audit trail
     * RMIS-Compliant: All completion attempts must be logged
     * 
     * @param int $projectId
     * @param bool $allowed
     * @param string|null $reason
     * @param array $missingRequirements
     */
    private function logCompletionAttempt($projectId, $allowed, $reason = null, $missingRequirements = []) {
        try {
            $actionType = $allowed ? 'completion_attempt_allowed' : 'completion_attempt_blocked';
            
            $metadata = [
                'allowed' => $allowed,
                'reason' => $reason,
                'missing_requirements' => $missingRequirements,
                'timestamp' => date('Y-m-d H:i:s'),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
            ];
            
            $this->auditLogger->log($projectId, $actionType, [
                'performed_by' => $this->userId,
                'performed_by_role' => $this->userRole,
                'metadata' => $metadata
            ]);
            
            // Also log to project lifecycle if blocked
            if (!$allowed) {
                $stmt = $this->conn->prepare("
                    INSERT INTO project_lifecycle_log (
                        project_id, 
                        previous_project_status, 
                        new_project_status, 
                        trigger_action, 
                        trigger_source_type, 
                        performed_by, 
                        performed_by_role, 
                        notes, 
                        metadata
                    ) VALUES (?, 
                        (SELECT project_status FROM research_submissions WHERE id = ?),
                        (SELECT project_status FROM research_submissions WHERE id = ?),
                        'completion_blocked',
                        'completion_attempt',
                        ?,
                        ?,
                        ?,
                        ?
                    )
                ");
                $notes = "Completion attempt blocked: " . $reason;
                $metadataJson = json_encode($metadata);
                $stmt->bind_param("iiissss", 
                    $projectId, $projectId, $projectId, 
                    $this->userId, $this->userRole, $notes, $metadataJson
                );
                $stmt->execute();
                $stmt->close();
            }
        } catch (Exception $e) {
            error_log("ProjectService::logCompletionAttempt error: " . $e->getMessage());
        }
    }
    
    // ========================================
    // RESEARCH OUTPUTS
    // ========================================
    
    /**
     * Report research output
     */
    public function reportOutput($projectId, $data) {
        $project = $this->getProject($projectId);
        
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        if (!$this->workflowEngine->canReportOutput($project)) {
            return ['success' => false, 'error' => 'You cannot report outputs for this project'];
        }
        
        // Validate required fields
        $required = ['output_type', 'title', 'authors'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['success' => false, 'error' => ucfirst(str_replace('_', ' ', $field)) . ' is required'];
            }
        }
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_outputs (
                    project_id,
                    output_type,
                    title,
                    authors,
                    publication_venue,
                    publication_date,
                    indexing_status,
                    doi,
                    isbn_issn,
                    award_received,
                    award_date,
                    awarding_body,
                    status,
                    reported_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted', ?)
            ");
            
            $stmt->bind_param(
                "isssssssssssi",
                $projectId,
                $data['output_type'],
                $data['title'],
                $data['authors'],
                $data['publication_venue'],
                $data['publication_date'],
                $data['indexing_status'],
                $data['doi'],
                $data['isbn_issn'],
                $data['award_received'],
                $data['award_date'],
                $data['awarding_body'],
                $this->userId
            );
            
            $stmt->execute();
            $outputId = $this->conn->insert_id;
            $stmt->close();
            
            return [
                'success' => true,
                'message' => 'Research output reported',
                'output_id' => $outputId
            ];
            
        } catch (Exception $e) {
            error_log("ProjectService::reportOutput error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get project outputs
     */
    public function getOutputs($projectId) {
        $stmt = $this->conn->prepare("
            SELECT po.*, u.fullname as reported_by_name
            FROM project_outputs po
            LEFT JOIN users u ON po.reported_by = u.id
            WHERE po.project_id = ?
            ORDER BY po.created_at DESC
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $result;
    }
    
    /**
     * Verify research output (Coordinator or RO action)
     */
    public function verifyOutput($outputId, $verified, $remarks = null) {
        // Get output first to check permissions
        $stmt = $this->conn->prepare("
            SELECT po.*, 
                   rs.researcher_type, 
                   rs.id as project_id,
                   rs.assigned_coordinator_id,
                   rs.assigned_coordinator_employee_id,
                   rs.created_by as project_owner
            FROM project_outputs po
            JOIN research_submissions rs ON po.project_id = rs.id
            WHERE po.id = ?
        ");
        $stmt->bind_param("i", $outputId);
        $stmt->execute();
        $output = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$output) {
            return ['success' => false, 'error' => 'Output not found'];
        }
        
        // Check permissions - coordinator or RO admin can verify
        $isROAdmin = $this->workflowEngine->isResearchOfficeAdmin();
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($output);
        
        if (!$isROAdmin && !$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'You are not authorized to verify this output'];
        }
        
        // Check for self-review
        if ($output['reported_by'] == $this->userId) {
            return ['success' => false, 'error' => 'You cannot verify an output you reported'];
        }
        
        $newStatus = $verified ? 'verified' : 'rejected';
        $reviewerRole = $isROAdmin ? 'research_office' : 'coordinator';
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_outputs SET
                    status = ?,
                    verified_by = ?,
                    verified_at = NOW(),
                    verification_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sisi", $newStatus, $this->userId, $remarks, $outputId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($output['project_id'], 'output_verified', [
                'performed_by' => $this->userId,
                'performed_by_role' => $reviewerRole,
                'metadata' => [
                    'output_id' => $outputId,
                    'verified' => $verified,
                    'title' => $output['title']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Output ' . $newStatus];
            
        } catch (Exception $e) {
            error_log("ProjectService::verifyOutput error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // UNIFIED WORKFLOW - OUTPUTS
    // Status lifecycle: draft → submitted → [under_review] → endorsed → verified/rejected
    // Note: Outputs may skip coordinator review based on workflow_settings
    // ========================================
    
    /**
     * Get output by ID
     */
    public function getOutput($outputId) {
        $stmt = $this->conn->prepare("
            SELECT po.*, 
                   rs.researcher_type, 
                   rs.id as project_id,
                   rs.assigned_coordinator_id,
                   rs.assigned_coordinator_employee_id,
                   rs.created_by as project_owner
            FROM project_outputs po
            JOIN research_submissions rs ON po.project_id = rs.id
            WHERE po.id = ?
        ");
        $stmt->bind_param("i", $outputId);
        $stmt->execute();
        $output = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $output;
    }
    
    /**
     * Submit output for verification (Researcher action)
     * Status: draft → submitted
     */
    public function submitOutput($outputId) {
        $output = $this->getOutput($outputId);
        if (!$output) {
            return ['success' => false, 'error' => 'Output not found'];
        }
        
        if ($output['status'] !== 'draft') {
            return ['success' => false, 'error' => 'Can only submit draft outputs'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_outputs SET
                    status = 'submitted',
                    submitted_at = NOW(),
                    submitted_by = ?
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $this->userId, $outputId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($output['project_id'], 'output_submitted', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => ['output_id' => $outputId, 'title' => $output['title']]
            ]);
            
            return ['success' => true, 'message' => 'Output submitted for verification'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Endorse output (Coordinator action)
     * Status: submitted/under_review → endorsed
     */
    public function endorseOutput($outputId, $remarks = null) {
        $output = $this->getOutput($outputId);
        if (!$output) {
            return ['success' => false, 'error' => 'Output not found'];
        }
        
        if (!in_array($output['status'], ['submitted', 'under_review'])) {
            return ['success' => false, 'error' => 'Cannot endorse from current status'];
        }
        
        // Check permission
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($output);
        if (!$isCoordinator && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to endorse'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_outputs SET
                    status = 'endorsed',
                    coordinator_verified_by = ?,
                    coordinator_verified_at = NOW(),
                    coordinator_remarks = ?,
                    endorsed_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $remarks, $outputId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($output['project_id'], 'output_endorsed', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => ['output_id' => $outputId]
            ]);
            
            return ['success' => true, 'message' => 'Output endorsed and forwarded to Research Office'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return output for revision (Coordinator/RO action)
     * Status: submitted/under_review/endorsed → returned
     */
    public function returnOutput($outputId, $reason) {
        $output = $this->getOutput($outputId);
        if (!$output) {
            return ['success' => false, 'error' => 'Output not found'];
        }
        
        if (!in_array($output['status'], ['submitted', 'under_review', 'endorsed'])) {
            return ['success' => false, 'error' => 'Cannot return from current status'];
        }
        
        // Check permission
        $isCoordinator = $this->workflowEngine->isAssignedCoordinator($output);
        $isROAdmin = $this->workflowEngine->isResearchOfficeAdmin();
        if (!$isCoordinator && !$isROAdmin && $this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Not authorized to return'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_outputs SET
                    status = 'returned',
                    return_reason = ?
                WHERE id = ?
            ");
            $stmt->bind_param("si", $reason, $outputId);
            $stmt->execute();
            $stmt->close();
            
            $role = $isROAdmin ? 'research_office' : 'coordinator';
            $this->auditLogger->log($output['project_id'], 'output_returned', [
                'performed_by' => $this->userId,
                'performed_by_role' => $role,
                'metadata' => ['output_id' => $outputId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Output returned for revision'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Reject output (RO action - FINAL)
     * Status: endorsed → rejected
     */
    public function rejectOutput($outputId, $reason) {
        $output = $this->getOutput($outputId);
        if (!$output) {
            return ['success' => false, 'error' => 'Output not found'];
        }
        
        if (!in_array($output['status'], ['submitted', 'endorsed'])) {
            return ['success' => false, 'error' => 'Cannot reject from current status'];
        }
        
        if ($this->userRole !== 'admin') {
            return ['success' => false, 'error' => 'Only Research Office can reject'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_outputs SET
                    status = 'rejected',
                    verified_by = ?,
                    verified_at = NOW(),
                    verification_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $outputId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($output['project_id'], 'output_rejected', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['output_id' => $outputId, 'reason' => $reason]
            ]);
            
            return ['success' => true, 'message' => 'Output rejected'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function getOutputsCount($projectId) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM project_outputs WHERE project_id = ?");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result['count'];
    }
    
    // ========================================
    // COORDINATOR PROJECTS (Scoped View)
    // ========================================
    
    /**
     * Get projects within coordinator's scope
     * Coordinator sees projects where:
     * 1. Project's researcher_type matches coordinator's type (faculty/student/personnel)
     * 2. Project's unit is within coordinator's assigned scope
     */
    public function getCoordinatorProjects($filters = [], $page = 1, $perPage = 15) {
        // Get coordinator types and scope
        $coordinatorTypes = $this->getCoordinatorTypes();
        $scopeMode = $this->getCoordinatorScopeMode();
        $allowedUnits = $this->getCoordinatorAllowedUnits();
        
        if (empty($coordinatorTypes)) {
            return [
                'data' => [],
                'total' => 0,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => 0
            ];
        }
        
        // Build WHERE clause for coordinator scope
        $where = ["rs.status = 'approved'"];
        $params = [];
        $types = "";
        
        // Filter by researcher type (coordinator type)
        $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
        $where[] = "rs.researcher_type IN ($typePlaceholders)";
        $params = array_merge($params, $coordinatorTypes);
        $types .= str_repeat('s', count($coordinatorTypes));
        
        // Apply scope filtering (unless all_units)
        if ($scopeMode !== 'all_units' && !empty($allowedUnits)) {
            $unitPlaceholders = implode(',', array_fill(0, count($allowedUnits), '?'));
            $where[] = "(rs.researcher_unit_id IN ($unitPlaceholders) OR rs.researcher_unit_name IN ($unitPlaceholders))";
            $params = array_merge($params, $allowedUnits, $allowedUnits);
            $types .= str_repeat('s', count($allowedUnits) * 2);
        }
        
        // Apply filters
        if (!empty($filters['project_status'])) {
            $where[] = "rs.project_status = ?";
            $params[] = $filters['project_status'];
            $types .= 's';
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['unit'])) {
            $where[] = "(rs.researcher_unit_id = ? OR rs.researcher_unit_name LIKE ?)";
            $params[] = $filters['unit'];
            $params[] = '%' . $filters['unit'] . '%';
            $types .= 'ss';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'sss';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Count
        $countSql = "SELECT COUNT(*) as total FROM research_submissions rs $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Data
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.project_code,
                rs.title,
                rs.researcher_type,
                rs.researcher_id,
                rs.researcher_unit_name,
                rs.project_status,
                rs.rmis_form_mapping,
                rs.proposed_start_date,
                rs.current_end_date,
                rs.total_budget,
                rs.research_program,
                rs.funding_source,
                rs.fiscal_year,
                rs.elevated_to_project_at,
                rs.completed_at,
                rs.extension_count,
                rst.type_name,
                u.fullname as created_by_name,
                CASE 
                    WHEN rs.researcher_type = 'faculty' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM faculty_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'student' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM student_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'personnel' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM personnel_researchers WHERE id = rs.researcher_id)
                    ELSE 'Unknown'
                END as researcher_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            LEFT JOIN users u ON rs.created_by = u.id
            $whereClause
            ORDER BY rs.elevated_to_project_at DESC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Add computed fields
        foreach ($data as &$row) {
            $row['project_status_label'] = WorkflowEngine::getProjectStatusLabel($row['project_status']);
            $row['project_status_class'] = WorkflowEngine::getProjectStatusClass($row['project_status']);
            $row = $this->addTimelineStatus($row);
        }
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    /**
     * Get coordinator's project statistics within their scope
     */
    public function getCoordinatorProjectStatistics() {
        $coordinatorTypes = $this->getCoordinatorTypes();
        $scopeMode = $this->getCoordinatorScopeMode();
        $allowedUnits = $this->getCoordinatorAllowedUnits();
        
        if (empty($coordinatorTypes)) {
            return [
                'on_going' => 0,
                'extended' => 0,
                'completed' => 0,
                'overdue' => 0,
                'total' => 0
            ];
        }
        
        // Build WHERE clause
        $where = ["status = 'approved'"];
        $params = [];
        $types = "";
        
        // Filter by researcher type
        $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
        $where[] = "researcher_type IN ($typePlaceholders)";
        $params = array_merge($params, $coordinatorTypes);
        $types .= str_repeat('s', count($coordinatorTypes));
        
        // Apply scope
        if ($scopeMode !== 'all_units' && !empty($allowedUnits)) {
            $unitPlaceholders = implode(',', array_fill(0, count($allowedUnits), '?'));
            $where[] = "(researcher_unit_id IN ($unitPlaceholders) OR researcher_unit_name IN ($unitPlaceholders))";
            $params = array_merge($params, $allowedUnits, $allowedUnits);
            $types .= str_repeat('s', count($allowedUnits) * 2);
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "
            SELECT 
                COUNT(CASE WHEN project_status = 'on_going' THEN 1 END) as on_going,
                COUNT(CASE WHEN project_status = 'extended' THEN 1 END) as extended,
                COUNT(CASE WHEN project_status = 'completed' THEN 1 END) as completed,
                COUNT(CASE WHEN project_status IN ('on_going', 'extended') 
                      AND current_end_date < CURDATE() THEN 1 END) as overdue,
                COUNT(*) as total
            FROM research_submissions
            WHERE $whereClause
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get pending items for coordinator review on projects
     */
    public function getCoordinatorPendingItems() {
        $coordinatorTypes = $this->getCoordinatorTypes();
        
        if (empty($coordinatorTypes)) {
            return [
                'progress_reports' => 0,
                'extensions' => 0,
                'completions' => 0
            ];
        }
        
        $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
        
        // Progress reports pending review
        $sql = "
            SELECT COUNT(*) as count 
            FROM project_progress_reports ppr
            JOIN research_submissions rs ON ppr.project_id = rs.id
            WHERE ppr.status = 'submitted' AND rs.researcher_type IN ($typePlaceholders)
        ";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(str_repeat('s', count($coordinatorTypes)), ...$coordinatorTypes);
        $stmt->execute();
        $progressReports = $stmt->get_result()->fetch_assoc()['count'];
        $stmt->close();
        
        // Extensions pending review
        $sql = "
            SELECT COUNT(*) as count 
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            WHERE pe.status IN ('submitted', 'under_coordinator_review') AND rs.researcher_type IN ($typePlaceholders)
        ";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(str_repeat('s', count($coordinatorTypes)), ...$coordinatorTypes);
        $stmt->execute();
        $extensions = $stmt->get_result()->fetch_assoc()['count'];
        $stmt->close();
        
        // Completions pending review
        $sql = "
            SELECT COUNT(*) as count 
            FROM project_completion_reports pcr
            JOIN research_submissions rs ON pcr.project_id = rs.id
            WHERE pcr.status IN ('submitted', 'under_coordinator_review') AND rs.researcher_type IN ($typePlaceholders)
        ";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(str_repeat('s', count($coordinatorTypes)), ...$coordinatorTypes);
        $stmt->execute();
        $completions = $stmt->get_result()->fetch_assoc()['count'];
        $stmt->close();
        
        return [
            'progress_reports' => $progressReports,
            'extensions' => $extensions,
            'completions' => $completions
        ];
    }
    
    // ========================================
    // ADMIN PROJECTS (Institution-Wide View)
    // ========================================
    
    /**
     * Get all projects for Research Office Admin (no scope restriction)
     */
    public function getAdminProjects($filters = [], $page = 1, $perPage = 15) {
        $where = ["rs.status = 'approved'"];
        $params = [];
        $types = "";
        
        // Apply filters
        if (!empty($filters['project_status'])) {
            $where[] = "rs.project_status = ?";
            $params[] = $filters['project_status'];
            $types .= 's';
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['unit'])) {
            $where[] = "(rs.researcher_unit_id = ? OR rs.researcher_unit_name LIKE ?)";
            $params[] = $filters['unit'];
            $params[] = '%' . $filters['unit'] . '%';
            $types .= 'ss';
        }
        
        if (!empty($filters['research_program'])) {
            $where[] = "rs.research_program = ?";
            $params[] = $filters['research_program'];
            $types .= 's';
        }
        
        if (!empty($filters['funding_source'])) {
            $where[] = "rs.funding_source = ?";
            $params[] = $filters['funding_source'];
            $types .= 's';
        }
        
        if (!empty($filters['fiscal_year'])) {
            $where[] = "rs.fiscal_year = ?";
            $params[] = $filters['fiscal_year'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ? OR rs.researcher_name LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'ssss';
        }
        
        if (!empty($filters['overdue'])) {
            $where[] = "rs.project_status IN ('on_going', 'extended') AND rs.current_end_date < CURDATE()";
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(rs.elevated_to_project_at) >= ?";
            $params[] = $filters['date_from'];
            $types .= 's';
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(rs.elevated_to_project_at) <= ?";
            $params[] = $filters['date_to'];
            $types .= 's';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Count
        $countSql = "SELECT COUNT(*) as total FROM research_submissions rs $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Data
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.project_code,
                rs.title,
                rs.researcher_type,
                rs.researcher_id,
                rs.researcher_unit_name,
                rs.project_status,
                rs.rmis_form_mapping,
                rs.proposed_start_date,
                rs.current_end_date,
                rs.total_budget,
                rs.research_program,
                rs.funding_source,
                rs.fiscal_year,
                rs.elevated_to_project_at,
                rs.completed_at,
                rs.extension_count,
                rst.type_name,
                u.fullname as created_by_name,
                CASE 
                    WHEN rs.researcher_type = 'faculty' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM faculty_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'student' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM student_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'personnel' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM personnel_researchers WHERE id = rs.researcher_id)
                    ELSE 'Unknown'
                END as researcher_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            LEFT JOIN users u ON rs.created_by = u.id
            $whereClause
            ORDER BY rs.elevated_to_project_at DESC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        if (!empty($types)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Add computed fields
        foreach ($data as &$row) {
            $row['project_status_label'] = WorkflowEngine::getProjectStatusLabel($row['project_status']);
            $row['project_status_class'] = WorkflowEngine::getProjectStatusClass($row['project_status']);
            $row = $this->addTimelineStatus($row);
        }
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    /**
     * Get institution-wide project statistics for admin dashboard
     */
    public function getAdminProjectStatistics() {
        $sql = "
            SELECT 
                COUNT(CASE WHEN status = 'approved' AND project_status = 'on_going' THEN 1 END) as on_going,
                COUNT(CASE WHEN status = 'approved' AND project_status = 'extended' THEN 1 END) as extended,
                COUNT(CASE WHEN status = 'approved' AND project_status = 'completed' THEN 1 END) as completed,
                COUNT(CASE WHEN status = 'approved' AND project_status IN ('on_going', 'extended') 
                      AND current_end_date < CURDATE() THEN 1 END) as overdue,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as total_approved,
                -- By researcher type
                COUNT(CASE WHEN status = 'approved' AND researcher_type = 'faculty' THEN 1 END) as faculty_projects,
                COUNT(CASE WHEN status = 'approved' AND researcher_type = 'student' THEN 1 END) as student_projects,
                COUNT(CASE WHEN status = 'approved' AND researcher_type = 'personnel' THEN 1 END) as personnel_projects,
                -- Budget summary
                SUM(CASE WHEN status = 'approved' THEN total_budget END) as total_budget
            FROM research_submissions
        ";
        
        $result = $this->conn->query($sql);
        return $result->fetch_assoc();
    }
    
    /**
     * Get pending items for RO admin
     */
    public function getAdminPendingItems() {
        // Progress reports pending RO review
        $progressReports = $this->conn->query("
            SELECT COUNT(*) as count FROM project_progress_reports 
            WHERE status = 'submitted' OR status = 'endorsed'
        ")->fetch_assoc()['count'];
        
        // Extensions pending RO review
        $extensions = $this->conn->query("
            SELECT COUNT(*) as count FROM project_extensions 
            WHERE status IN ('submitted', 'endorsed', 'under_ro_review')
        ")->fetch_assoc()['count'];
        
        // Completions pending RO review
        $completions = $this->conn->query("
            SELECT COUNT(*) as count FROM project_completion_reports 
            WHERE status IN ('submitted', 'endorsed', 'under_ro_review')
        ")->fetch_assoc()['count'];
        
        // Outputs pending verification
        $outputs = $this->conn->query("
            SELECT COUNT(*) as count FROM project_outputs WHERE status = 'submitted'
        ")->fetch_assoc()['count'];
        
        return [
            'progress_reports' => $progressReports,
            'extensions' => $extensions,
            'completions' => $completions,
            'outputs' => $outputs
        ];
    }
    
    /**
     * Get distinct units with projects for filtering
     */
    public function getProjectUnits() {
        $result = $this->conn->query("
            SELECT DISTINCT researcher_unit_name 
            FROM research_submissions 
            WHERE status = 'approved' AND researcher_unit_name IS NOT NULL AND researcher_unit_name != ''
            ORDER BY researcher_unit_name
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get distinct research programs for filtering
     */
    public function getResearchPrograms() {
        $result = $this->conn->query("
            SELECT DISTINCT research_program 
            FROM research_submissions 
            WHERE research_program IS NOT NULL AND research_program != ''
            ORDER BY research_program
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get distinct funding sources for filtering
     */
    public function getFundingSources() {
        $result = $this->conn->query("
            SELECT DISTINCT funding_source 
            FROM research_submissions 
            WHERE funding_source IS NOT NULL AND funding_source != ''
            ORDER BY funding_source
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get coordinator types for current user
     */
    private function getCoordinatorTypes() {
        if (!$this->employeeId || $this->userRole !== 'coordinator') {
            return [];
        }
        
        $types = [];
        $stmt = $this->conn->prepare("
            SELECT coordinator_type FROM coordinator_assignments 
            WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $types[] = $row['coordinator_type'];
        }
        $stmt->close();
        
        return $types;
    }
    
    /**
     * Get coordinator's scope mode
     */
    private function getCoordinatorScopeMode() {
        if (!$this->employeeId) {
            return 'own_unit';
        }
        
        $stmt = $this->conn->prepare("
            SELECT scope_mode FROM coordinator_assignments 
            WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active' 
            LIMIT 1
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result['scope_mode'] ?? 'own_unit';
    }
    
    /**
     * Get coordinator's allowed units
     */
    private function getCoordinatorAllowedUnits() {
        if (!$this->employeeId) {
            return [];
        }
        
        $scopeMode = $this->getCoordinatorScopeMode();
        
        if ($scopeMode === 'all_units') {
            return []; // No filtering needed
        }
        
        if ($scopeMode === 'own_unit') {
            // Get HR unit from coordinator assignment
            $stmt = $this->conn->prepare("
                SELECT hr_unit_id, hr_unit_name FROM coordinator_assignments 
                WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active' 
                LIMIT 1
            ");
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            $units = [];
            if (!empty($result['hr_unit_id'])) $units[] = $result['hr_unit_id'];
            if (!empty($result['hr_unit_name'])) $units[] = $result['hr_unit_name'];
            return $units;
        }
        
        // specific_units mode
        $stmt = $this->conn->prepare("
            SELECT unit_id, unit_name FROM coordinator_scopes 
            WHERE employee_id COLLATE utf8mb4_general_ci = ?
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $units = [];
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['unit_id'])) $units[] = $row['unit_id'];
            if (!empty($row['unit_name'])) $units[] = $row['unit_name'];
        }
        $stmt->close();
        
        return array_unique($units);
    }
    
    /**
     * Add timeline status calculation to project row
     */
    private function addTimelineStatus($row) {
        if (empty($row['proposed_start_date']) || empty($row['current_end_date'])) {
            $row['timeline_status'] = 'unknown';
            $row['progress_percent'] = 0;
            $row['days_info'] = 'Timeline not set';
            return $row;
        }
        
        $start = strtotime($row['proposed_start_date']);
        $end = strtotime($row['current_end_date']);
        $now = time();
        
        if ($row['project_status'] === 'completed') {
            $row['timeline_status'] = 'completed';
            $row['progress_percent'] = 100;
            $row['days_info'] = 'Completed';
            return $row;
        }
        
        if ($now >= $end) {
            $row['timeline_status'] = 'overdue';
            $row['days_overdue'] = floor(($now - $end) / 86400);
            $row['days_info'] = $row['days_overdue'] . ' days overdue';
            $row['progress_percent'] = 100;
        } elseif ($now <= $start) {
            $row['timeline_status'] = 'not_started';
            $row['days_info'] = 'Not yet started';
            $row['progress_percent'] = 0;
        } else {
            $total = $end - $start;
            $elapsed = $now - $start;
            $row['progress_percent'] = min(100, round(($elapsed / $total) * 100));
            $daysRemaining = ceil(($end - $now) / 86400);
            $row['days_info'] = $daysRemaining . ' days remaining';
            
            if ($daysRemaining <= 30) {
                $row['timeline_status'] = 'near_due';
            } else {
                $row['timeline_status'] = 'in_progress';
            }
        }
        
        return $row;
    }
    
    // ========================================
    // FIELD CHANGE REQUESTS (Locked Fields)
    // ========================================
    
    /**
     * Request change to locked field
     */
    public function requestFieldChange($projectId, $fieldName, $currentValue, $requestedValue, $reason) {
        $project = $this->getProject($projectId);
        
        if (!$project) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        // Verify this is a locked field
        $lockedFields = WorkflowEngine::getLockedFields();
        if (!isset($lockedFields[$fieldName])) {
            return ['success' => false, 'error' => 'This field does not require a change request'];
        }
        
        // Verify ownership
        if ($project['created_by'] != $this->userId && $project['researcher_user_id'] != $this->userId) {
            return ['success' => false, 'error' => 'You do not have permission to request changes to this project'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_field_change_requests 
                (project_id, field_name, current_value, requested_value, change_reason, requested_by)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("issssi", $projectId, $fieldName, $currentValue, $requestedValue, $reason, $this->userId);
            $stmt->execute();
            $requestId = $this->conn->insert_id;
            $stmt->close();
            
            $this->auditLogger->log($projectId, 'field_change_requested', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => [
                    'request_id' => $requestId,
                    'field_name' => $fieldName,
                    'field_label' => $lockedFields[$fieldName]
                ]
            ]);
            
            return [
                'success' => true,
                'message' => 'Change request submitted for ' . $lockedFields[$fieldName],
                'request_id' => $requestId
            ];
            
        } catch (Exception $e) {
            error_log("ProjectService::requestFieldChange error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve field change request (RO action)
     */
    public function approveFieldChange($requestId, $approved, $remarks = null) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can approve field changes'];
        }
        
        $stmt = $this->conn->prepare("SELECT * FROM project_field_change_requests WHERE id = ?");
        $stmt->bind_param("i", $requestId);
        $stmt->execute();
        $request = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$request) {
            return ['success' => false, 'error' => 'Change request not found'];
        }
        
        if ($request['status'] !== 'pending') {
            return ['success' => false, 'error' => 'This request has already been processed'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            $newStatus = $approved ? 'approved' : 'rejected';
            
            // Update request
            $stmt = $this->conn->prepare("
                UPDATE project_field_change_requests SET
                    status = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW(),
                    review_remarks = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sisi", $newStatus, $this->userId, $remarks, $requestId);
            $stmt->execute();
            $stmt->close();
            
            // If approved, update the actual field
            if ($approved) {
                $fieldName = $request['field_name'];
                $newValue = $request['requested_value'];
                $projectId = $request['project_id'];
                
                $stmt = $this->conn->prepare("UPDATE research_submissions SET $fieldName = ?, updated_at = NOW() WHERE id = ?");
                $stmt->bind_param("si", $newValue, $projectId);
                $stmt->execute();
                $stmt->close();
            }
            
            // Log the action
            $this->auditLogger->log($request['project_id'], $approved ? 'field_change_approved' : 'field_change_rejected', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'request_id' => $requestId,
                    'field_name' => $request['field_name'],
                    'old_value' => $request['current_value'],
                    'new_value' => $approved ? $request['requested_value'] : null
                ]
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Field change ' . $newStatus];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("ProjectService::approveFieldChange error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get pending field change requests for a project
     */
    public function getPendingFieldChanges($projectId) {
        $stmt = $this->conn->prepare("
            SELECT pfcr.*, u.fullname as requested_by_name
            FROM project_field_change_requests pfcr
            LEFT JOIN users u ON pfcr.requested_by = u.id
            WHERE pfcr.project_id = ? AND pfcr.status = 'pending'
            ORDER BY pfcr.created_at DESC
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $result;
    }
    
    // ========================================
    // EXTENSION REQUEST QUEUE MANAGEMENT
    // ========================================
    
    /**
     * Get extension requests for coordinator queue
     * Scoped by coordinator's researcher types and units
     */
    public function getCoordinatorExtensionQueue($filters = [], $page = 1, $perPage = 15) {
        $coordinatorTypes = $this->getCoordinatorTypes();
        
        if (empty($coordinatorTypes)) {
            return ['data' => [], 'pagination' => ['total' => 0, 'page' => $page, 'per_page' => $perPage, 'total_pages' => 0]];
        }
        
        $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
        
        $where = ["pe.status IN ('submitted', 'under_coordinator_review', 'returned_for_revision')"];
        $where[] = "rs.researcher_type IN ($typePlaceholders)";
        $params = $coordinatorTypes;
        $types = str_repeat('s', count($coordinatorTypes));
        
        // Apply unit scope
        $allowedUnits = $this->getCoordinatorAllowedUnits();
        if (!empty($allowedUnits)) {
            $unitPlaceholders = implode(',', array_fill(0, count($allowedUnits), '?'));
            $where[] = "(rs.researcher_unit_id IN ($unitPlaceholders) OR rs.researcher_unit_name IN ($unitPlaceholders))";
            $params = array_merge($params, $allowedUnits, $allowedUnits);
            $types .= str_repeat('s', count($allowedUnits) * 2);
        }
        
        // Apply filters
        if (!empty($filters['status'])) {
            $where[] = "pe.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }
        
        if (!empty($filters['extension_type'])) {
            $where[] = "pe.extension_type = ?";
            $params[] = $filters['extension_type'];
            $types .= 's';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'sss';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Count
        $countSql = "
            SELECT COUNT(*) as total 
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            $whereClause
        ";
        $countStmt = $this->conn->prepare($countSql);
        $countStmt->bind_param($types, ...$params);
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Data
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        
        $sql = "
            SELECT 
                pe.*,
                rs.title as project_title,
                rs.reference_number,
                rs.project_code,
                rs.researcher_type,
                rs.researcher_id,
                rs.researcher_unit_name,
                rs.current_end_date as project_current_end_date,
                rs.total_budget as project_budget,
                u.fullname as requested_by_name,
                CASE 
                    WHEN rs.researcher_type = 'faculty' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM faculty_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'student' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM student_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'personnel' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM personnel_researchers WHERE id = rs.researcher_id)
                    ELSE 'Unknown'
                END as researcher_name
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            LEFT JOIN users u ON pe.requested_by = u.id
            $whereClause
            ORDER BY 
                CASE pe.status 
                    WHEN 'submitted' THEN 1 
                    WHEN 'under_coordinator_review' THEN 2 
                    ELSE 3 
                END,
                pe.created_at ASC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return [
            'data' => $data,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => ceil($total / $perPage)
            ]
        ];
    }
    
    /**
     * Get extension requests for Research Office queue
     * Shows all endorsed extensions pending RO review
     */
    public function getROExtensionQueue($filters = [], $page = 1, $perPage = 15) {
        $where = ["pe.status IN ('endorsed', 'under_ro_review')"];
        $params = [];
        $types = "";
        
        // Apply filters
        if (!empty($filters['status'])) {
            $where[] = "pe.status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }
        
        if (!empty($filters['extension_type'])) {
            $where[] = "pe.extension_type = ?";
            $params[] = $filters['extension_type'];
            $types .= 's';
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['unit'])) {
            $where[] = "(rs.researcher_unit_id = ? OR rs.researcher_unit_name LIKE ?)";
            $params[] = $filters['unit'];
            $params[] = '%' . $filters['unit'] . '%';
            $types .= 'ss';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'sss';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Count
        $countSql = "
            SELECT COUNT(*) as total 
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            $whereClause
        ";
        $countStmt = $this->conn->prepare($countSql);
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Data
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        
        $sql = "
            SELECT 
                pe.*,
                rs.title as project_title,
                rs.reference_number,
                rs.project_code,
                rs.researcher_type,
                rs.researcher_id,
                rs.researcher_unit_name,
                rs.current_end_date as project_current_end_date,
                rs.total_budget as project_budget,
                rs.project_status,
                u.fullname as requested_by_name,
                cu.fullname as coordinator_name,
                CASE 
                    WHEN rs.researcher_type = 'faculty' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM faculty_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'student' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM student_researchers WHERE id = rs.researcher_id)
                    WHEN rs.researcher_type = 'personnel' THEN (SELECT CONCAT(last_name, ', ', first_name) FROM personnel_researchers WHERE id = rs.researcher_id)
                    ELSE 'Unknown'
                END as researcher_name
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            LEFT JOIN users u ON pe.requested_by = u.id
            LEFT JOIN users cu ON pe.coordinator_reviewed_by = cu.id
            $whereClause
            ORDER BY 
                CASE pe.status 
                    WHEN 'endorsed' THEN 1 
                    WHEN 'under_ro_review' THEN 2 
                    ELSE 3 
                END,
                pe.coordinator_reviewed_at ASC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return [
            'data' => $data,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'total_pages' => ceil($total / $perPage)
            ]
        ];
    }
    
    /**
     * Get extension queue statistics for coordinator
     */
    public function getCoordinatorExtensionStats() {
        $coordinatorTypes = $this->getCoordinatorTypes();
        
        if (empty($coordinatorTypes)) {
            return ['submitted' => 0, 'under_review' => 0, 'total' => 0];
        }
        
        $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
        
        $sql = "
            SELECT 
                SUM(CASE WHEN pe.status = 'submitted' THEN 1 ELSE 0 END) as submitted,
                SUM(CASE WHEN pe.status = 'under_coordinator_review' THEN 1 ELSE 0 END) as under_review,
                COUNT(*) as total
            FROM project_extensions pe
            JOIN research_submissions rs ON pe.project_id = rs.id
            WHERE pe.status IN ('submitted', 'under_coordinator_review')
            AND rs.researcher_type IN ($typePlaceholders)
        ";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param(str_repeat('s', count($coordinatorTypes)), ...$coordinatorTypes);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get extension queue statistics for Research Office
     */
    public function getROExtensionStats() {
        $sql = "
            SELECT 
                SUM(CASE WHEN status = 'endorsed' THEN 1 ELSE 0 END) as endorsed,
                SUM(CASE WHEN status = 'under_ro_review' THEN 1 ELSE 0 END) as under_review,
                SUM(CASE WHEN status IN ('endorsed', 'under_ro_review') THEN 1 ELSE 0 END) as total,
                SUM(CASE WHEN status = 'approved' AND DATE(ro_reviewed_at) = CURDATE() THEN 1 ELSE 0 END) as approved_today,
                SUM(CASE WHEN status = 'rejected' AND DATE(ro_reviewed_at) = CURDATE() THEN 1 ELSE 0 END) as rejected_today
            FROM project_extensions
        ";
        
        $result = $this->conn->query($sql);
        return $result->fetch_assoc();
    }
    
    /**
     * Start coordinator review of extension request
     * Status: submitted → under_coordinator_review
     */
    public function startExtensionReview($extensionId) {
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if ($extension['status'] !== 'submitted') {
            return ['success' => false, 'error' => 'Extension request is not in submitted status'];
        }
        
        // Verify coordinator authorization
        $coordinatorTypes = $this->getCoordinatorTypes();
        $project = $this->getProject($extension['project_id']);
        
        if (!in_array($project['researcher_type'], $coordinatorTypes)) {
            return ['success' => false, 'error' => 'You are not authorized to review this extension request'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'under_coordinator_review',
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_review_started', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Review started'];
            
        } catch (Exception $e) {
            error_log("ProjectService::startExtensionReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return extension request for revision
     * Status: under_coordinator_review → returned_for_revision
     */
    public function returnExtensionForRevision($extensionId, $reason) {
        if (empty($reason)) {
            return ['success' => false, 'error' => 'Return reason is required'];
        }
        
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if ($extension['status'] !== 'under_coordinator_review') {
            return ['success' => false, 'error' => 'Extension request must be under review to return'];
        }
        
        // Verify coordinator authorization
        $coordinatorTypes = $this->getCoordinatorTypes();
        $project = $this->getProject($extension['project_id']);
        
        if (!in_array($project['researcher_type'], $coordinatorTypes)) {
            return ['success' => false, 'error' => 'You are not authorized to return this extension request'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'returned_for_revision',
                    coordinator_reviewed_by = ?,
                    coordinator_remarks = ?,
                    coordinator_reviewed_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_returned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type'],
                    'return_reason' => $reason
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request returned for revision'];
            
        } catch (Exception $e) {
            error_log("ProjectService::returnExtensionForRevision error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Endorse extension request to Research Office
     * Status: under_coordinator_review → endorsed
     */
    public function endorseExtension($extensionId, $validationData, $remarks = null) {
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        // Allow endorsement from submitted or under_coordinator_review status
        if (!in_array($extension['status'], ['submitted', 'under_coordinator_review'])) {
            return ['success' => false, 'error' => 'Extension request must be submitted or under review to endorse'];
        }
        
        // Verify coordinator authorization
        $coordinatorTypes = $this->getCoordinatorTypes();
        $project = $this->getProject($extension['project_id']);
        
        if (!in_array($project['researcher_type'], $coordinatorTypes)) {
            return ['success' => false, 'error' => 'You are not authorized to endorse this extension request'];
        }
        
        // Validate checklist items
        $requiredChecks = ['justification_valid', 'timeline_reasonable', 'documents_complete'];
        foreach ($requiredChecks as $check) {
            if (empty($validationData[$check])) {
                return ['success' => false, 'error' => 'All validation items must be checked'];
            }
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'endorsed',
                    coordinator_reviewed_by = ?,
                    coordinator_remarks = ?,
                    coordinator_reviewed_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $remarks, $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_endorsed', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type'],
                    'validation_data' => $validationData,
                    'remarks' => $remarks
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request endorsed to Research Office'];
            
        } catch (Exception $e) {
            error_log("ProjectService::endorseExtension error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Start RO review of extension request
     * Status: endorsed → under_ro_review
     */
    public function startROExtensionReview($extensionId) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can perform this action'];
        }
        
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if ($extension['status'] !== 'endorsed') {
            return ['success' => false, 'error' => 'Extension request is not in endorsed status'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'under_ro_review',
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_ro_review_started', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Review started'];
            
        } catch (Exception $e) {
            error_log("ProjectService::startROExtensionReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve extension request (RO action)
     * Status: under_ro_review → approved
     * Also updates the project's current_end_date and/or budget
     */
    public function approveExtensionRequest($extensionId, $approvalData, $remarks = null) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can approve extensions'];
        }
        
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if (!in_array($extension['status'], ['endorsed', 'under_ro_review'])) {
            return ['success' => false, 'error' => 'Extension request cannot be approved from current status'];
        }
        
        // Determine approved values
        $approvedEndDate = $approvalData['approved_end_date'] ?? $extension['requested_end_date'];
        $approvedBudget = $approvalData['approved_additional_budget'] ?? $extension['requested_additional_budget'];
        
        // Validate date format if timeline extension
        if (in_array($extension['extension_type'], ['timeline', 'timeline_budget']) && $approvedEndDate) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $approvedEndDate)) {
                return ['success' => false, 'error' => 'Invalid date format. Please use the date picker to select a date (YYYY-MM-DD format required).'];
            }
        }
        
        try {
            $this->conn->begin_transaction();
            
            // Update extension record
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'approved',
                    ro_reviewed_by = ?,
                    ro_remarks = ?,
                    ro_reviewed_at = NOW(),
                    decision_at = NOW(),
                    approved_end_date = ?,
                    approved_additional_budget = ?,
                    approval_conditions = ?
                WHERE id = ?
            ");
            $conditions = $approvalData['conditions'] ?? null;
            $stmt->bind_param("issdsi", 
                $this->userId, 
                $remarks, 
                $approvedEndDate, 
                $approvedBudget,
                $conditions,
                $extensionId
            );
            $stmt->execute();
            $stmt->close();
            
            // Update project based on extension type
            $projectId = $extension['project_id'];
            $updateFields = [];
            $updateParams = [];
            $updateTypes = "";
            
            // Timeline extension
            if (in_array($extension['extension_type'], ['timeline', 'timeline_budget']) && $approvedEndDate) {
                $updateFields[] = "current_end_date = ?";
                $updateParams[] = $approvedEndDate;
                $updateTypes .= "s";
                
                $updateFields[] = "extension_count = extension_count + 1";
                $updateFields[] = "project_status = 'extended'";
            }
            
            // Budget extension
            if (in_array($extension['extension_type'], ['budget', 'timeline_budget']) && $approvedBudget) {
                $updateFields[] = "total_budget = total_budget + ?";
                $updateParams[] = $approvedBudget;
                $updateTypes .= "d";
            }
            
            if (!empty($updateFields)) {
                $updateParams[] = $projectId;
                $updateTypes .= "i";
                
                $sql = "UPDATE research_submissions SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = ?";
                $stmt = $this->conn->prepare($sql);
                $stmt->bind_param($updateTypes, ...$updateParams);
                $stmt->execute();
                $stmt->close();
            }
            
            // Log the action
            $this->auditLogger->log($projectId, 'extension_approved', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type'],
                    'original_end_date' => $extension['original_end_date'],
                    'approved_end_date' => $approvedEndDate,
                    'original_budget' => $extension['original_budget'],
                    'approved_additional_budget' => $approvedBudget,
                    'remarks' => $remarks
                ]
            ]);
            
            $this->conn->commit();
            
            return [
                'success' => true, 
                'message' => 'Extension request approved',
                'approved_end_date' => $approvedEndDate,
                'approved_additional_budget' => $approvedBudget
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("ProjectService::approveExtensionRequest error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Reject extension request (RO action)
     * Status: under_ro_review → rejected
     */
    public function rejectExtensionRequest($extensionId, $reason) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can reject extensions'];
        }
        
        if (empty($reason)) {
            return ['success' => false, 'error' => 'Rejection reason is required'];
        }
        
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if (!in_array($extension['status'], ['endorsed', 'under_ro_review'])) {
            return ['success' => false, 'error' => 'Extension request cannot be rejected from current status'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'rejected',
                    ro_reviewed_by = ?,
                    ro_remarks = ?,
                    ro_reviewed_at = NOW(),
                    decision_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("isi", $this->userId, $reason, $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_rejected', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type'],
                    'rejection_reason' => $reason
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request rejected'];
            
        } catch (Exception $e) {
            error_log("ProjectService::rejectExtensionRequest error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Return extension to coordinator (RO action)
     * Status: under_ro_review → endorsed (back to coordinator for re-review)
     */
    public function returnExtensionToCoordinator($extensionId, $reason) {
        if (!$this->workflowEngine->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can perform this action'];
        }
        
        if (empty($reason)) {
            return ['success' => false, 'error' => 'Return reason is required'];
        }
        
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if (!in_array($extension['status'], ['endorsed', 'under_ro_review'])) {
            return ['success' => false, 'error' => 'Extension request is not in a status that can be returned to coordinator'];
        }
        
        try {
            // Return to under_coordinator_review so coordinator can re-review
            $stmt = $this->conn->prepare("
                UPDATE project_extensions SET
                    status = 'under_coordinator_review',
                    ro_remarks = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("si", $reason, $extensionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_returned_to_coordinator', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type'],
                    'return_reason' => $reason
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request returned to coordinator'];
            
        } catch (Exception $e) {
            error_log("ProjectService::returnExtensionToCoordinator error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Resubmit extension request after revision
     * Status: returned_for_revision → submitted
     */
    public function resubmitExtension($extensionId, $updatedData = []) {
        $extension = $this->getExtensionRequest($extensionId);
        
        if (!$extension) {
            return ['success' => false, 'error' => 'Extension request not found'];
        }
        
        if ($extension['status'] !== 'returned_for_revision') {
            return ['success' => false, 'error' => 'Extension request is not in returned status'];
        }
        
        // Verify ownership
        if ($extension['requested_by'] != $this->userId) {
            return ['success' => false, 'error' => 'You are not authorized to resubmit this extension request'];
        }
        
        try {
            $updateFields = ["status = 'submitted'", "updated_at = NOW()"];
            $params = [];
            $types = "";
            
            // Allow updating justification and requested values
            if (!empty($updatedData['justification'])) {
                $updateFields[] = "justification = ?";
                $params[] = $updatedData['justification'];
                $types .= "s";
            }
            
            if (isset($updatedData['requested_end_date']) && !empty($updatedData['requested_end_date'])) {
                // Validate date format (YYYY-MM-DD)
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $updatedData['requested_end_date'])) {
                    return ['success' => false, 'error' => 'Invalid date format. Please use the date picker to select a date (YYYY-MM-DD format required).'];
                }
                $updateFields[] = "requested_end_date = ?";
                $params[] = $updatedData['requested_end_date'];
                $types .= "s";
            }
            
            if (isset($updatedData['requested_additional_budget'])) {
                $updateFields[] = "requested_additional_budget = ?";
                $params[] = $updatedData['requested_additional_budget'];
                $types .= "d";
            }
            
            $params[] = $extensionId;
            $types .= "i";
            
            $sql = "UPDATE project_extensions SET " . implode(', ', $updateFields) . " WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $this->auditLogger->log($extension['project_id'], 'extension_resubmitted', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'metadata' => [
                    'extension_id' => $extensionId,
                    'extension_type' => $extension['extension_type']
                ]
            ]);
            
            return ['success' => true, 'message' => 'Extension request resubmitted'];
            
        } catch (Exception $e) {
            error_log("ProjectService::resubmitExtension error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
