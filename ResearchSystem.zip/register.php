<?php
// Registration is disabled. Users must use SSO login or existing accounts.
header("Location: login.php?error=" . urlencode("Registration is disabled. Please use SSO login or contact administrator."));
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMS - Register</title>
    <link rel="stylesheet" href ="registerstyle.css">

</head>
<body>
    <div class="register-wrapper">
        <div class="logo-container">
            <img src="essu.png" alt="University Logo" class="logo">
            <div class="university-name">Eastern Samar State University</div>
            <div class="system-subtitle">Research Management System</div>
        </div>

        <div class="register-container">
            <div class="form-title">Create Account</div>
            <div class="form-subtitle">Register to access the research management system</div>
            
            <?php if ($error): ?>
                <div class="error-message">
                    <strong>⚠️ <?= htmlspecialchars($error) ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success-message">
                    <strong>✓ <?= htmlspecialchars($success) ?></strong>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="input-group">
                    <label for="username">Username <span class="required">*</span></label>
                    <input type="text" id="username" name="username" placeholder="Choose a unique username" required autofocus>
                    <div class="info-text">Username must be unique</div>
                </div>
                
                <div class="input-group">
                    <label for="password">Password <span class="required">*</span></label>
                    <input type="password" id="password" name="password" placeholder="Create a strong password" required>
                    <div class="info-text">Minimum 8 characters recommended</div>
                </div>

                <div class="input-group">
                    <label for="role">Account Role <span class="required">*</span></label>
                    <select id="role" name="role" onchange="toggleCoordinatorType()" required>
                        <option value="coordinator" selected>Coordinator</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>

                <div id="coordinatorTypeField" class="input-group">
                    <label for="coordinator_type">Coordinator Type <span class="required">*</span></label>
                    <select id="coordinator_type" name="coordinator_type">
                        <option value="student">Student Coordinator</option>
                        <option value="faculty">Faculty Coordinator</option>
                    </select>
                    <div class="info-text">Select the type of research you will coordinate</div>
                </div>

                <div class="form-buttons">
                    <button type="button" class="btn btn-back" onclick="window.location.href='login.php'">Back to Login</button>
                    <button type="submit" class="btn btn-submit">Create Account</button>
                </div>
            </form>

            <div class="footer-text">
                © <?php echo date("Y"); ?> ESSU. All rights reserved.
            </div>
        </div>
    </div>

    <script>
        function toggleCoordinatorType() {
            const role = document.querySelector('select[name="role"]').value;
            const typeField = document.getElementById('coordinatorTypeField');
            const coordinatorTypeSelect = document.getElementById('coordinator_type');
            
            if (role === 'coordinator') {
                typeField.style.display = 'block';
                coordinatorTypeSelect.required = true;
            } else {
                typeField.style.display = 'none';
                coordinatorTypeSelect.required = false;
            }
        }

        // Initialize on page load
        toggleCoordinatorType();
    </script>
</body>
</html>
