<?php
/**
 * Output View Page
 * Unified design matching collaboration_view.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'ProjectService.php';
require_once 'spa_helper.php';

// Authentication check
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$isSpa = isSpaRequest();
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';

// Get output ID
$outputId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$outputId) {
    if ($isSpa) {
        echo '<div class="error-state" style="padding: 40px; text-align: center;">
            <h3><i class="fa fa-exclamation-triangle" style="color: #f59e0b;"></i> Invalid Output ID</h3>
            <p>No output ID was provided in the URL.</p>
            <p style="color: #6b7280; font-size: 14px; margin-top: 16px;">
                This may happen if you accessed this page via an invalid link.<br>
                Please go back to the <a href="work_queue.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'work_queue.php\',true)}">Work Queue</a> 
                or <a href="research.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage(\'research.php\',true)}">My Projects</a> and try again.
            </p>
        </div>';
    } else {
        header('Location: research.php');
    }
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$projectService = new ProjectService($conn);

// Fetch output with project info
$stmt = $conn->prepare("
    SELECT po.*, 
           rs.title as project_title,
           rs.project_code,
           rs.reference_number as project_reference,
           rs.created_by as project_owner,
           rs.researcher_type,
           u.fullname as reported_by_name,
           u.email as reporter_email,
           v.fullname as verified_by_name
    FROM project_outputs po
    JOIN research_submissions rs ON po.project_id = rs.id
    LEFT JOIN users u ON po.reported_by = u.id
    LEFT JOIN users v ON po.verified_by = v.id
    WHERE po.id = ?
");
$stmt->bind_param("i", $outputId);
$stmt->execute();
$output = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$output) {
    echo '<div class="error-state"><h3>Output Not Found</h3><p>The requested output could not be found.</p></div>';
    exit;
}

// Get project details for access check
$project = $projectService->getProject($output['project_id']);

// Check access permission
$isOwner = ($project['created_by'] == $userId);
$isAdmin = ($userRole === 'admin');
$isCoordinator = ($userRole === 'coordinator');

if (!$isOwner && !$isAdmin && !$isCoordinator) {
    echo '<div class="error-state"><h3>Access Denied</h3><p>You do not have permission to view this output.</p></div>';
    exit;
}

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Type configuration
$typeConfig = [
    'journal_article' => ['icon' => 'newspaper', 'color' => '#3b82f6', 'label' => 'Journal Article'],
    'conference_paper' => ['icon' => 'users', 'color' => '#8b5cf6', 'label' => 'Conference Paper'],
    'book' => ['icon' => 'book', 'color' => '#10b981', 'label' => 'Book'],
    'book_chapter' => ['icon' => 'book-open', 'color' => '#059669', 'label' => 'Book Chapter'],
    'patent' => ['icon' => 'lightbulb', 'color' => '#f59e0b', 'label' => 'Patent'],
    'thesis' => ['icon' => 'graduation-cap', 'color' => '#6366f1', 'label' => 'Thesis/Dissertation'],
    'report' => ['icon' => 'file-alt', 'color' => '#64748b', 'label' => 'Technical Report'],
    'presentation' => ['icon' => 'presentation', 'color' => '#ec4899', 'label' => 'Presentation'],
    'other' => ['icon' => 'file', 'color' => '#9ca3af', 'label' => 'Other Output']
];
$typeData = $typeConfig[$output['output_type']] ?? ['icon' => 'file', 'color' => '#64748b', 'label' => ucfirst(str_replace('_', ' ', $output['output_type']))];

// Status configuration
$statusConfig = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'class' => 'status-draft'],
    'reported' => ['label' => 'Reported', 'icon' => 'fa-file-alt', 'class' => 'status-submitted'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'class' => 'status-submitted'],
    'reviewed' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_review' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'class' => 'status-endorsed'],
    'verified' => ['label' => 'Verified', 'icon' => 'fa-check-circle', 'class' => 'status-approved'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-check-circle', 'class' => 'status-approved'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'class' => 'status-rejected']
];
$currentStatus = $statusConfig[$output['status'] ?? ''] ?? ['label' => ucfirst(str_replace('_', ' ', $output['status'] ?? 'pending')), 'icon' => 'fa-clock', 'class' => 'status-draft'];
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   OUTPUT VIEW - UNIFIED DESIGN
   ============================================ */

.output-header-banner {
    background: linear-gradient(135deg, <?= $typeData['color'] ?> 0%, <?= adjustBrightness($typeData['color'], -40) ?> 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.output-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.output-header-left { flex: 1; }

.output-header-left h1 {
    font-size: 22px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.4;
}

.output-header-left .project-link {
    font-size: 14px;
    color: rgba(255,255,255,0.9);
    margin-bottom: 12px;
}

.output-header-left .project-link a {
    color: white;
    text-decoration: none;
}

.output-header-left .project-link a:hover {
    text-decoration: underline;
}

.output-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.output-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255,255,255,0.2);
    color: white;
}

.output-header-right { text-align: right; }

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted { color: #2563eb; }
.status-reviewing { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-rejected { color: #dc2626; }

/* Content Layout */
.output-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.output-main { display: flex; flex-direction: column; gap: 24px; }
.output-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: <?= $typeData['color'] ?>; }

.section-body { padding: 20px; }

/* Detail Grid */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.5;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

/* Prevent layout break from long text */
.section-card {
    min-width: 0;
    overflow: hidden;
}

.section-body {
    overflow-wrap: break-word;
    word-break: break-word;
}

.output-main, .output-sidebar {
    min-width: 0;
}

.detail-value a {
    color: <?= $typeData['color'] ?>;
    text-decoration: none;
}

.detail-value a:hover { text-decoration: underline; }

/* Index Badge */
.index-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}

.index-badge.scopus { background: #fef3c7; color: #92400e; }
.index-badge.wos { background: #dbeafe; color: #1e40af; }
.index-badge.isi { background: #d1fae5; color: #065f46; }
.index-badge.none { background: #f3f4f6; color: #6b7280; }

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.btn-verify { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-verify:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-reject { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.btn-reject:hover { background: #fecaca; }

/* Info List */
.info-list { display: flex; flex-direction: column; gap: 12px; }
.info-item { display: flex; flex-direction: column; gap: 2px; }
.info-label { font-size: 11px; color: #6b7280; text-transform: uppercase; }
.info-value { font-size: 14px; color: #1f2937; font-weight: 500; }

.researcher-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    background: #dbeafe;
    color: #1e40af;
}

/* Verification Section */
.verification-card {
    background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
    border: 1px solid #6ee7b7;
}

.verification-card .section-header {
    background: transparent;
    border-bottom-color: rgba(16, 185, 129, 0.3);
}

.verification-card .section-header h3 i { color: #059669 !important; }

/* Rejection Section */
.rejection-card {
    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
    border: 1px solid #fca5a5;
}

.rejection-card .section-header {
    background: transparent;
    border-bottom-color: rgba(239, 68, 68, 0.3);
}

.rejection-card .section-header h3 i { color: #dc2626 !important; }

/* Award Badge */
.award-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 1px solid #f59e0b;
    border-radius: 8px;
    color: #92400e;
    font-weight: 600;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 { font-size: 18px; color: #1f2937; margin: 0; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #6b7280; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e5e7eb; display: flex; justify-content: flex-end; gap: 12px; }

/* Modal Buttons */
.modal-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600;
    cursor: pointer; border: none; transition: all 0.2s ease;
}
.modal-btn i { font-size: 13px; }
.modal-btn-secondary { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; }
.modal-btn-secondary:hover { background: #e5e7eb; border-color: #9ca3af; }
.modal-btn-danger {
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); color: white;
    box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
}
.modal-btn-danger:hover {
    background: linear-gradient(135deg, #b91c1c 0%, #dc2626 100%);
    transform: translateY(-1px); box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
}

.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
.form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    min-height: 100px;
    resize: vertical;
}

/* Responsive */
@media (max-width: 1024px) {
    .output-content { grid-template-columns: 1fr; }
    .output-sidebar { order: -1; }
}

@media (max-width: 768px) {
    .output-header-content { flex-direction: column; }
    .output-header-right { text-align: left; }
    .detail-grid { grid-template-columns: 1fr; }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>

<div class="content">
    <!-- Header Banner -->
    <div class="output-header-banner">
        <div class="output-header-content">
            <div class="output-header-left">
                <div class="project-link">
                    <i class="fa fa-folder"></i>
                    <a href="project_view.php?id=<?= $output['project_id'] ?>" 
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $output['project_id'] ?>',true)}">
                        <?= s($output['project_title']) ?>
                    </a>
                    <?php if ($output['project_code']): ?>
                        <span style="opacity: 0.7;">(<?= s($output['project_code']) ?>)</span>
                    <?php endif; ?>
                </div>
                <h1><?= s($output['title']) ?></h1>
                <div class="output-header-badges">
                    <span class="output-badge">
                        <i class="fa fa-<?= $typeData['icon'] ?>"></i>
                        <?= $typeData['label'] ?>
                    </span>
                    <?php if (!empty($output['publication_date'])): ?>
                    <span class="output-badge">
                        <i class="fa fa-calendar"></i>
                        Published <?= date('M Y', strtotime($output['publication_date'])) ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="output-header-right">
                <span class="status-badge-large <?= $currentStatus['class'] ?>">
                    <i class="fa <?= $currentStatus['icon'] ?>"></i>
                    <?= $currentStatus['label'] ?>
                </span>
            </div>
        </div>
    </div>

    <div class="output-content">
        <!-- Main Content -->
        <div class="output-main">
            <!-- Publication Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-<?= $typeData['icon'] ?>"></i> Publication Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row full-width">
                            <span class="detail-label">Title</span>
                            <span class="detail-value" style="font-weight: 600; font-size: 16px;"><?= s($output['title']) ?></span>
                        </div>
                        
                        <?php if (!empty($output['authors'])): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Authors</span>
                            <span class="detail-value"><?= s($output['authors']) ?></span>
                        </div>
                        <?php endif; ?>

                        <div class="detail-row">
                            <span class="detail-label">Output Type</span>
                            <span class="detail-value"><?= $typeData['label'] ?></span>
                        </div>

                        <?php if (!empty($output['publication_venue'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Publication Venue</span>
                            <span class="detail-value"><?= s($output['publication_venue']) ?></span>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($output['publication_date'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Publication Date</span>
                            <span class="detail-value"><?= date('F d, Y', strtotime($output['publication_date'])) ?></span>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($output['indexing_status'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Indexing Status</span>
                            <span class="detail-value">
                                <?php
                                $indexClass = strtolower($output['indexing_status']);
                                if (strpos($indexClass, 'scopus') !== false) $indexClass = 'scopus';
                                elseif (strpos($indexClass, 'wos') !== false || strpos($indexClass, 'web of science') !== false) $indexClass = 'wos';
                                elseif (strpos($indexClass, 'isi') !== false) $indexClass = 'isi';
                                else $indexClass = 'none';
                                ?>
                                <span class="index-badge <?= $indexClass ?>"><?= s($output['indexing_status']) ?></span>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Identifiers -->
            <?php if (!empty($output['doi']) || !empty($output['isbn_issn'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-fingerprint"></i> Identifiers</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <?php if (!empty($output['doi'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">DOI</span>
                            <span class="detail-value">
                                <a href="https://doi.org/<?= s($output['doi']) ?>" target="_blank">
                                    <i class="fa fa-external-link-alt"></i> <?= s($output['doi']) ?>
                                </a>
                            </span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($output['isbn_issn'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">ISBN/ISSN</span>
                            <span class="detail-value"><?= s($output['isbn_issn']) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Award Information -->
            <?php if (!empty($output['award_received'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-trophy"></i> Award Information</h3>
                </div>
                <div class="section-body">
                    <div class="award-badge">
                        <i class="fa fa-award"></i>
                        <?= s($output['award_received']) ?>
                    </div>
                    <?php if (!empty($output['awarding_body'])): ?>
                    <div style="margin-top: 12px;">
                        <span class="detail-label">Awarding Body</span>
                        <div class="detail-value"><?= s($output['awarding_body']) ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Verification Status -->
            <?php if (($output['status'] ?? '') === 'verified' && $output['verified_by']): ?>
            <div class="section-card verification-card">
                <div class="section-header">
                    <h3><i class="fa fa-check-circle"></i> Verification Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row">
                            <span class="detail-label">Verified By</span>
                            <span class="detail-value"><?= s($output['verified_by_name']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Verified On</span>
                            <span class="detail-value"><?= $output['verified_at'] ? date('M d, Y \a\t g:i A', strtotime($output['verified_at'])) : 'N/A' ?></span>
                        </div>
                        <?php if (!empty($output['verification_notes'])): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Notes</span>
                            <span class="detail-value"><?= nl2br(s($output['verification_notes'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php elseif (($output['status'] ?? '') === 'rejected'): ?>
            <div class="section-card rejection-card">
                <div class="section-header">
                    <h3><i class="fa fa-times-circle"></i> Rejection Details</h3>
                </div>
                <div class="section-body">
                    <?php if (!empty($output['rejection_reason'])): ?>
                    <div class="detail-row full-width">
                        <span class="detail-label">Reason for Rejection</span>
                        <span class="detail-value"><?= nl2br(s($output['rejection_reason'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="output-sidebar">
            <!-- Actions -->
            <?php 
            // Coordinator can act on submitted/reported status
            $coordinatorCanAct = $isCoordinator && in_array($output['status'] ?? '', ['reported', 'submitted']);
            // Admin can act on endorsed status
            $adminCanAct = $isAdmin && in_array($output['status'] ?? '', ['endorsed']);
            // Both can verify directly for submitted (simple workflow) - admin always sees verify option
            $canDirectVerify = $isAdmin && in_array($output['status'] ?? '', ['reported', 'submitted', 'endorsed']);
            ?>
            <?php if ($coordinatorCanAct || $adminCanAct || $canDirectVerify): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if ($coordinatorCanAct): ?>
                            <!-- Coordinator Actions -->
                            <button onclick="endorseOutput()" class="action-btn btn-verify" style="background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);">
                                <i class="fa fa-check"></i> Endorse to Research Office
                            </button>
                            <button onclick="showRejectModal()" class="action-btn btn-reject">
                                <i class="fa fa-times"></i> Reject
                            </button>
                        <?php elseif ($canDirectVerify): ?>
                            <!-- Research Office Actions -->
                            <button onclick="verifyOutput()" class="action-btn btn-verify">
                                <i class="fa fa-check"></i> Verify Output
                            </button>
                            <button onclick="showRejectModal()" class="action-btn btn-reject">
                                <i class="fa fa-times"></i> Reject
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Reporter Info -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-user"></i> Reporter</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Researcher Type</span>
                            <span class="researcher-badge"><?= strtoupper($output['researcher_type'] ?? 'FACULTY') ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Reported By</span>
                            <span class="info-value"><?= s($output['reported_by_name']) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Reported</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($output['created_at'])) ?></span>
                        </div>
                        <?php if ($output['verified_at']): ?>
                        <div class="info-item">
                            <span class="info-label">Verified</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($output['verified_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Back Button -->
            <div class="section-card">
                <div class="section-body" style="padding: 12px 20px;">
                    <?php if ($isCoordinator || $isAdmin): ?>
                    <a href="work_queue.php" class="action-btn" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('work_queue.php',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Work Queue
                    </a>
                    <?php else: ?>
                    <a href="project_view.php?id=<?= $output['project_id'] ?>&tab=outputs" class="action-btn" style="background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb;"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $output['project_id'] ?>&tab=outputs',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Project
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-times-circle"></i> Reject Output</h3>
            <button class="modal-close" onclick="closeRejectModal()">&times;</button>
        </div>
        <form id="rejectForm" method="POST" onsubmit="return false;">
            <div class="modal-body">
                <div class="form-group">
                    <label>Reason for Rejection</label>
                    <textarea name="reason" required placeholder="Explain why this output is being rejected..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeRejectModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-danger">
                    <i class="fa fa-times-circle"></i> Reject Output
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const outputId = <?= $outputId ?>;
const isCoordinatorUser = <?= $isCoordinator ? 'true' : 'false' ?>;
const isAdminUser = <?= $isAdmin ? 'true' : 'false' ?>;

// Coordinator: Endorse output to Research Office
function endorseOutput() {
    if (!confirm('Endorse this research output to the Research Office?')) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'endorse_output',
            output_id: outputId
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Output endorsed successfully!');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to endorse'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

// Research Office: Verify output
function verifyOutput() {
    if (!confirm('Verify this research output?')) return;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'verify_output',
            output_id: outputId,
            verified: true
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Output verified successfully!');
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to verify'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

function showRejectModal() {
    document.getElementById('rejectModal').classList.add('active');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.remove('active');
}

document.getElementById('rejectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const reason = this.reason.value;
    
    fetch('project_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'reject_output',
            output_id: outputId,
            reason: reason
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert('Output rejected.');
            closeRejectModal();
            if (window.SPA) {
                window.SPA.loadPage('work_queue.php', true);
            } else {
                window.location.href = 'work_queue.php';
            }
        } else {
            alert('Error: ' + (data.error || 'Failed to reject'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
});
</script>
