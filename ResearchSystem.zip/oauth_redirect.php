<?php
/**
 * OAuth Redirect Handler
 * 
 * Supports the OpenID Connect prompt parameter for handling re-authentication scenarios.
 * 
 * Query Parameters:
 * - prompt=login : Forces re-authentication (use after access denied errors)
 * - prompt=consent : Always shows consent screen
 * - prompt=none : Silent authentication (returns error if not logged in)
 * 
 * @see OAUTH_PROMPT_GUIDE.md for detailed documentation
 */

require 'db.php';
require 'config.php';
session_start();

$config = getOAuthConfig($conn);
$enabled = !empty($config['enabled']) && !empty($config['client_id']) && !empty($config['client_secret']) && !empty($config['provider_url']) && !empty($config['redirect_uri']);
if (!$enabled) {
    header("Location: login.php?error=" . urlencode("SSO is not enabled or not properly configured. Please contact administrator."));
    exit;
}

$state = generateOAuthState();
$_SESSION['oauth_state'] = $state;

$params = [
    'client_id' => $config['client_id'],
    'redirect_uri' => $config['redirect_uri'],
    'response_type' => 'code',
    'scope' => $config['scopes'],
    'state' => $state,
];

// Support OpenID Connect prompt parameter
// Valid values: 'login', 'consent', 'none'
// See OAUTH_PROMPT_GUIDE.md for documentation
$promptParam = isset($_GET['prompt']) ? strtolower(trim($_GET['prompt'])) : null;
$validPromptValues = ['login', 'consent', 'none'];

if ($promptParam && in_array($promptParam, $validPromptValues)) {
    $params['prompt'] = $promptParam;
    
    // Log the prompt parameter usage for debugging
    debugLog("OAuth redirect with prompt parameter", [
        'prompt' => $promptParam,
        'reason' => $promptParam === 'login' ? 'Force re-authentication (possibly after access denied)' : 'User requested'
    ]);
}

// Clear access denied flag from session when initiating new OAuth flow
// (will be set again if access is denied)
if (isset($_SESSION['sso_access_denied'])) {
    unset($_SESSION['sso_access_denied']);
}

$authUrl = $config['authorize_url'] . '?' . http_build_query($params);

header("Location: " . $authUrl);
exit;
