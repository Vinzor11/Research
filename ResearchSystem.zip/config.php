<?php
/**
 * Configuration File Template for Research Management System
 * 
 * Copy this file to config.php and update with your actual OAuth credentials
 */

// ============================================
// OAuth SSO Configuration
// ============================================

// OAuth Provider URL (Your HR System SSO endpoint)
define('OAUTH_PROVIDER_URL', getenv('OAUTH_PROVIDER_URL') ?: 'https://hr-production-eaf1.up.railway.app');

// OAuth Client ID (Get this from your HR system administrator)
define('OAUTH_CLIENT_ID', getenv('OAUTH_CLIENT_ID') ?: '019b02aa-fae7-72a9-9eea-b80ce018d26b');

// OAuth Client Secret (Get this from your HR system administrator)
// IMPORTANT: Never commit this to version control!
define('OAUTH_CLIENT_SECRET', getenv('OAUTH_CLIENT_SECRET') ?: '7WCyIzt6ngaOycPjob09CzuFEg424PXSzWiKUHsQ');

// OAuth Redirect URI (Callback URL after SSO login)
define('OAUTH_REDIRECT_URI', getenv('OAUTH_REDIRECT_URI') ?: 'https://erp-rms.42web.io/oauth_callback.php');

// OAuth Scopes (Permissions requested from SSO provider)
define('OAUTH_SCOPES', 'openid profile email');

// ============================================
// OAuth Endpoints (Auto-generated from provider URL)
// ============================================

define('OAUTH_AUTHORIZE_URL', OAUTH_PROVIDER_URL . '/oauth/authorize');
define('OAUTH_TOKEN_URL', OAUTH_PROVIDER_URL . '/oauth/token');
define('OAUTH_USERINFO_URL', OAUTH_PROVIDER_URL . '/oauth/userinfo');
define('OAUTH_OPENID_CONFIG_URL', OAUTH_PROVIDER_URL . '/.well-known/openid-configuration');

// ============================================
// SSO Feature Toggle
// ============================================

define('SSO_ENABLED', !empty(OAUTH_CLIENT_ID) && !empty(OAUTH_CLIENT_SECRET));

// ============================================
// Access Control Settings
// ============================================

define('ALLOWED_DEPARTMENT', getenv('ALLOWED_DEPARTMENT') ?: 'Research Office');

// ============================================
// Security Settings
// ============================================

define('OAUTH_STATE_LENGTH', 32);
define('SESSION_TIMEOUT', 1800);

// ============================================
// HR API Configuration
// ============================================

// HR API Base URL (same as OAuth Provider URL for API endpoints)
define('HR_API_BASE_URL', OAUTH_PROVIDER_URL);

// API Rate Limiting
define('API_RATE_LIMIT', 60); // requests per window
define('API_RATE_WINDOW', 60); // seconds
define('API_TIMEOUT', 30); // seconds
define('API_MAX_PER_PAGE', 100);

// Token Settings
define('TOKEN_EXPIRY_BUFFER', 300); // 5 minutes buffer before expiry
define('TOKEN_DEFAULT_LIFETIME', 3600); // 1 hour default

// Debug Mode (set to false in production)
if (!defined('DEBUG_MODE')) {
    define('DEBUG_MODE', true); // Set to false for production
}

// ============================================
// Helper Functions
// ============================================

function isSSOConfigured() {
    return !empty(OAUTH_CLIENT_ID) && 
           !empty(OAUTH_CLIENT_SECRET) && 
           !empty(OAUTH_PROVIDER_URL) &&
           !empty(OAUTH_REDIRECT_URI);
}

/**
 * Get effective OAuth config: from oauth_settings table if present, else from constants/env.
 * Used by Admin UI and by redirect/callback so settings can be changed without editing config.
 *
 * @param mysqli|null $conn
 * @return array{provider_url:string, client_id:string, client_secret:string, redirect_uri:string, enabled:bool, token_url:string, userinfo_url:string, authorize_url:string}
 */
function getOAuthConfig($conn = null) {
    $out = [
        'provider_url' => defined('OAUTH_PROVIDER_URL') ? OAUTH_PROVIDER_URL : '',
        'client_id' => defined('OAUTH_CLIENT_ID') ? OAUTH_CLIENT_ID : '',
        'client_secret' => defined('OAUTH_CLIENT_SECRET') ? OAUTH_CLIENT_SECRET : '',
        'redirect_uri' => defined('OAUTH_REDIRECT_URI') ? OAUTH_REDIRECT_URI : '',
        'enabled' => defined('SSO_ENABLED') && SSO_ENABLED,
    ];
    if ($conn && $conn instanceof mysqli) {
        try {
            $stmt = $conn->prepare("SELECT `key`, value FROM oauth_settings WHERE `key` IN ('provider_url','client_id','client_secret','redirect_uri','enabled')");
            if ($stmt) {
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_assoc()) {
                    $k = $row['key'];
                    $v = $row['value'] ?? '';
                    if ($k === 'enabled') {
                        $out['enabled'] = ($v === '1' || $v === 'true' || $v === 'yes');
                        continue;
                    }
                    if ($v !== '' && $v !== null) {
                        $out[$k] = $v;
                    }
                }
                $stmt->close();
            }
        } catch (Exception $e) {
            // Table may not exist yet
        }
    }
    $base = rtrim($out['provider_url'], '/');
    $out['token_url'] = $base ? $base . '/oauth/token' : '';
    $out['userinfo_url'] = $base ? $base . '/oauth/userinfo' : '';
    $out['authorize_url'] = $base ? $base . '/oauth/authorize' : '';
    $out['scopes'] = defined('OAUTH_SCOPES') ? OAUTH_SCOPES : 'openid profile email';
    return $out;
}

function getOAuthAuthorizationUrl($state, $forceLogin = false) {
    $params = [
        'client_id' => OAUTH_CLIENT_ID,
        'redirect_uri' => OAUTH_REDIRECT_URI,
        'response_type' => 'code',
        'scope' => OAUTH_SCOPES,
        'state' => $state,
    ];
    
    // Force login page to show (useful for testing or when user wants to switch accounts)
    if ($forceLogin) {
        $params['prompt'] = 'login';
    }
    
    return OAUTH_AUTHORIZE_URL . '?' . http_build_query($params);
}

function generateOAuthState() {
    return bin2hex(random_bytes(OAUTH_STATE_LENGTH / 2));
}

/**
 * Debug logging function
 * Logs debug messages (only in development/debug mode)
 * 
 * @param string $message - Debug message
 * @param array|null $context - Optional context data to include
 */
function debugLog($message, $context = null) {
    // Only log if debug mode is enabled (you can control this via a constant or environment variable)
    $debugEnabled = defined('DEBUG_MODE') ? DEBUG_MODE : true; // Default to true for now
    
    if (!$debugEnabled) {
        return;
    }
    
    $logMessage = "[DEBUG] " . $message;
    
    if ($context !== null && is_array($context)) {
        $logMessage .= " | Context: " . json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
    
    error_log($logMessage);
}

/**
 * Error logging function
 * Logs error messages (always enabled)
 * 
 * @param string $message - Error message
 * @param array|null $context - Optional context data to include
 */
function errorLog($message, $context = null) {
    $logMessage = "[ERROR] " . $message;
    
    if ($context !== null && is_array($context)) {
        $logMessage .= " | Context: " . json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
    
    error_log($logMessage);
}

// ============================================
// HR Integration Helper Functions
// ============================================

/**
 * Check if HR integration is available
 * Returns true if SSO is enabled and configured
 * 
 * @return bool
 */
function isHRIntegrationAvailable() {
    return defined('SSO_ENABLED') && SSO_ENABLED && 
           !empty(OAUTH_PROVIDER_URL) && 
           !empty(OAUTH_CLIENT_ID) && 
           !empty(OAUTH_CLIENT_SECRET);
}

/**
 * Get HR access token from session or database
 * 
 * @return string|null - Access token or null if not available
 */
function getHRAccessToken() {
    if (!isset($_SESSION)) {
        session_start();
    }
    
    // First check session
    if (isset($_SESSION['hr_access_token']) && isset($_SESSION['hr_token_expires_at'])) {
        $expiresAt = strtotime($_SESSION['hr_token_expires_at']);
        $buffer = defined('TOKEN_EXPIRY_BUFFER') ? TOKEN_EXPIRY_BUFFER : 300; // 5 minute buffer default
        
        // If token is still valid (with buffer), return it
        if (time() < ($expiresAt - $buffer)) {
            return $_SESSION['hr_access_token'];
        }
    }
    
    // Try to get from database if user is logged in
    if (isset($_SESSION['user_id'])) {
        // Try to get connection from global scope (db.php should be included before config.php)
        global $conn;
        
        if (isset($conn) && $conn instanceof mysqli) {
            try {
                require_once __DIR__ . '/TokenManager.php';
                $tokenManager = new TokenManager($conn, $_SESSION['user_id']);
                $token = $tokenManager->getValidToken();
                
                if ($token) {
                    // Update session for faster access next time
                    $_SESSION['hr_access_token'] = $token;
                    return $token;
                }
            } catch (Exception $e) {
                errorLog("Failed to get HR access token from TokenManager", ['error' => $e->getMessage()]);
            }
        }
    }
    
    return null;
}

/**
 * Check if a faculty record needs HR sync based on last sync time
 * 
 * @param string|null $lastSyncedAt - Last sync timestamp (DATETIME format)
 * @param int $daysThreshold - Number of days before sync is needed (default: 30 days)
 * @return bool - True if sync is needed, false otherwise
 */
function needsHRSync($lastSyncedAt, $daysThreshold = 30) {
    if (empty($lastSyncedAt)) {
        return true; // Never synced, needs sync
    }
    
    $lastSyncTime = strtotime($lastSyncedAt);
    if ($lastSyncTime === false) {
        return true; // Invalid date, needs sync
    }
    
    $thresholdTime = time() - ($daysThreshold * 24 * 60 * 60);
    
    // If last sync is older than threshold, needs sync
    return $lastSyncTime < $thresholdTime;
}

/**
 * Normalize employee ID for consistent comparison
 * Converts to uppercase and trims whitespace
 * 
 * @param string|null $employeeId - Employee ID to normalize
 * @return string - Normalized employee ID (uppercase, trimmed)
 */
function normalizeEmployeeId($employeeId) {
    if (empty($employeeId)) {
        return '';
    }
    
    // Convert to string, trim whitespace, and convert to uppercase
    return strtoupper(trim((string)$employeeId));
}

/**
 * Convert timestamp to human-readable "time ago" format
 * 
 * @param string|null $datetime - Datetime string (MySQL format)
 * @return string - Human-readable time ago (e.g., "2 hours ago", "3 days ago")
 */
function timeAgo($datetime) {
    if (empty($datetime)) {
        return 'Never';
    }
    
    try {
        $timestamp = strtotime($datetime);
        if ($timestamp === false) {
            return 'Invalid date';
        }
        
        $diff = time() - $timestamp;
        
        if ($diff < 60) {
            return 'Just now';
        } elseif ($diff < 3600) {
            $minutes = floor($diff / 60);
            return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 86400) {
            $hours = floor($diff / 3600);
            return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 604800) {
            $days = floor($diff / 86400);
            return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 2592000) {
            $weeks = floor($diff / 604800);
            return $weeks . ' week' . ($weeks > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 31536000) {
            $months = floor($diff / 2592000);
            return $months . ' month' . ($months > 1 ? 's' : '') . ' ago';
        } else {
            $years = floor($diff / 31536000);
            return $years . ' year' . ($years > 1 ? 's' : '') . ' ago';
        }
    } catch (Exception $e) {
        return 'Invalid date';
    }
}