<?php
/**
 * Research Office Extension Request Queue
 * 
 * Centralized queue for Research Office administrators to review, approve, or reject
 * extension requests that have been endorsed by coordinators.
 * 
 * Workflow: endorsed → under_ro_review → approved/rejected
 * 
 * RO Admin can: Approve (apply changes), Reject (with reason), Return to Coordinator
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';
require_once 'WorkflowEngine.php';

// Access control - RO Admin or System Admin only
$userId = $_SESSION['user_id'] ?? null;
$userRole = $_SESSION['user_role'] ?? '';

if (!$userId) {
    header("Location: login.php");
    exit;
}

// Check if user is RO Admin
$isROAdmin = false;
if ($userRole === 'admin') {
    $isROAdmin = true;
} else {
    $roStmt = $conn->prepare("SELECT id FROM research_office_admins WHERE user_id = ? AND status = 'active'");
    $roStmt->bind_param("i", $userId);
    $roStmt->execute();
    $isROAdmin = $roStmt->get_result()->num_rows > 0;
    $roStmt->close();
}

if (!$isROAdmin) {
    header("Location: app.php");
    exit;
}

$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Initialize service
$projectService = new ProjectService($conn);

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$typeFilter = $_GET['type'] ?? '';
$researcherTypeFilter = $_GET['researcher_type'] ?? '';
$unitFilter = $_GET['unit'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get extension queue
$filters = [
    'status' => $statusFilter ?: null,
    'extension_type' => $typeFilter ?: null,
    'researcher_type' => $researcherTypeFilter ?: null,
    'unit' => $unitFilter ?: null,
    'search' => $searchQuery ?: null
];
$queueResult = $projectService->getROExtensionQueue($filters, $page, 15);
$extensions = $queueResult['data'];
$pagination = $queueResult['pagination'];

// Get queue statistics
$stats = $projectService->getROExtensionStats();

// Get units for filter dropdown
$units = $projectService->getProjectUnits();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

function getExtensionTypeLabel($type) {
    $labels = [
        'timeline' => 'Time Extension',
        'budget' => 'Budget Extension',
        'timeline_budget' => 'Time & Budget',
        'scope' => 'Scope Change'
    ];
    return $labels[$type] ?? ucfirst($type);
}

function getStatusBadgeClass($status) {
    $classes = [
        'endorsed' => 'status-endorsed',
        'under_ro_review' => 'status-review',
        'approved' => 'status-approved',
        'rejected' => 'status-rejected'
    ];
    return $classes[$status] ?? 'status-default';
}

function getStatusLabel($status) {
    $labels = [
        'endorsed' => 'Pending RO Review',
        'under_ro_review' => 'Under Review',
        'approved' => 'Approved',
        'rejected' => 'Rejected'
    ];
    return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
}
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* Research Office Extension Queue Styles - Matching RO Queue Design */
.ro-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.ro-title {
    display: flex;
    align-items: center;
    gap: 12px;
}

.ro-title i {
    font-size: 28px;
    color: #064e1a;
}

.ro-title h1 {
    font-size: 24px;
    color: #1f2937;
    margin: 0;
}

.ro-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);
    color: white;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    text-transform: capitalize;
}

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.status-endorsed { background: #e0e7ff; color: #5b21b6; }
.status-review { background: #fef3c7; color: #92400e; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }

/* Extension Type Badge */
.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.type-timeline { background: #e0e7ff; color: #4338ca; }
.type-budget { background: #dcfce7; color: #166534; }
.type-timeline_budget { background: #fef3c7; color: #92400e; }
.type-scope { background: #f3e8ff; color: #7c3aed; }

/* Researcher Type Badges */
.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.type-faculty { background: #dbeafe; color: #1e40af; }
.type-student { background: #fef3c7; color: #92400e; }
.type-personnel { background: #e0e7ff; color: #5b21b6; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: center;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
    white-space: nowrap;
}

.queue-table th:nth-child(1) { width: 28%; text-align: left; }
.queue-table th:nth-child(2) { width: 14%; }
.queue-table th:nth-child(3) { width: 10%; }
.queue-table th:nth-child(4) { width: 10%; }
.queue-table th:nth-child(5) { width: 10%; }
.queue-table th:nth-child(6) { width: 10%; }
.queue-table th:nth-child(7) { width: 18%; }

.queue-table td {
    padding: 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
    text-align: center;
}

.queue-table td:nth-child(1) {
    text-align: left;
}

.queue-table tr:hover {
    background: #f9fafb;
}

/* Extension Title Cell */
.extension-title-cell {
    text-align: left !important;
}

.extension-title-link {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.extension-title-link:hover {
    color: #064e1a;
}

.extension-meta {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
    color: #6b7280;
    flex-wrap: wrap;
}

.extension-meta i {
    color: #9ca3af;
}

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

/* Unit Cell */
.unit-cell {
    font-size: 12px;
    color: #374151;
}

/* Date Cell */
.date-cell {
    font-size: 12px;
    color: #6b7280;
}

/* Actions Cell */
.actions-cell {
    display: inline-flex;
    justify-content: center;
    gap: 6px;
    flex-wrap: wrap;
}

.actions-cell .btn {
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.btn-view { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }
.btn-view:hover { background: #e5e7eb; }

.btn-start { background: #fef3c7; color: #92400e; }
.btn-start:hover { background: #fde68a; }

.btn-return { background: #fee2e2; color: #991b1b; }
.btn-return:hover { background: #fecaca; }

.btn-reject { background: #dc2626; color: white; }
.btn-reject:hover { background: #b91c1c; }

.btn-approve { background: #064e1a; color: white; }
.btn-approve:hover { background: #053615; }

/* Table Footer */
.table-footer {
    padding: 12px 16px;
    background: #f9fafb;
    border-top: 1px solid #e5e7eb;
    font-size: 13px;
    color: #6b7280;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.filter-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header h3 i {
    color: #064e1a;
}

.filter-grid {
    display: flex;
    gap: 16px;
    align-items: flex-end;
}

.filter-grid .filter-group {
    flex: 1;
    min-width: 120px;
}

.filter-grid .filter-group:nth-child(4) {
    flex: 1.5;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.filter-group select,
.filter-group input[type="text"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input[type="text"]:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-buttons {
    flex: 0 0 auto !important;
}

.btn-group {
    display: flex;
    gap: 8px;
    align-items: center;
}

.filter-btn {
    padding: 10px 20px;
    background: linear-gradient(135deg, #064e1a 0%, #0a7c2e 100%);
    color: white;
    border: none;
    border-radius: 8px;
    white-space: nowrap;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
}

.filter-btn:hover {
    background: linear-gradient(135deg, #053d15 0%, #086324 100%);
}

.clear-filters {
    padding: 10px 12px;
    background: white;
    color: #6b7280;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
}

.clear-filters:hover {
    background: #f3f4f6;
    color: #374151;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.empty-state i {
    font-size: 48px;
    color: #d1d5db;
    margin-bottom: 16px;
}

.empty-state h3 {
    font-size: 18px;
    color: #6b7280;
    margin: 0 0 8px 0;
}

.empty-state p {
    font-size: 14px;
    color: #9ca3af;
    margin: 0;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-content {
    transform: scale(1);
}

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 20px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
}

.form-group input, .form-group textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
}

.form-group textarea {
    min-height: 100px;
    resize: vertical;
}

/* Approval Summary */
.approval-summary {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 20px;
}

.approval-summary h4 {
    font-size: 14px;
    color: #166534;
    margin: 0 0 12px 0;
}

.approval-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #bbf7d0;
}

.approval-row:last-child {
    border-bottom: none;
}

.approval-row .label {
    color: #4b5563;
}

.approval-row .value {
    font-weight: 600;
    color: #1f2937;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 30px;
}

.pagination a, .pagination span {
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 14px;
    text-decoration: none;
}

.pagination a {
    background: white;
    color: #374151;
    border: 1px solid #e5e7eb;
}

.pagination a:hover { background: #f3f4f6; }

.pagination .current {
    background: #064e1a;
    color: white;
    border: 1px solid #064e1a;
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner" style="background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%); border-radius: 16px; padding: 28px 32px; margin-bottom: 24px; box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 16px;">
                <i class="fa fa-calendar-plus" style="font-size: 32px; color: rgba(255, 255, 255, 0.9);"></i>
                <div>
                    <h1 style="font-size: 26px; font-weight: 700; color: white; margin: 0 0 4px 0;">Extension Queue</h1>
                    <p style="font-size: 14px; color: rgba(255, 255, 255, 0.8); margin: 0;">Review and approve extension requests from projects</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; background: rgba(255, 255, 255, 0.95); color: #065f46; border-radius: 25px; font-size: 13px; font-weight: 700; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);">
                    <i class="fa fa-shield-alt"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    Admin
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <style>
        .stats-row-ext { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
        .stat-card-ext { 
            background: white; 
            border: 1px solid #e5e7eb; 
            border-radius: 12px; 
            padding: 20px 24px; 
            display: flex; 
            align-items: center; 
            gap: 16px; 
            flex: 1; 
            min-width: 140px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            cursor: default;
        }
        .stat-card-ext:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        }
        .stat-card-ext:hover > div:first-child {
            transform: rotate(-10deg) scale(1.1);
        }
        .stat-card-ext > div:first-child {
            transition: transform 0.3s ease;
        }
        .stat-card-ext.active { 
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); 
            border: 2px solid #064e1a; 
        }
    </style>
    <?php $totalItems = ($stats['endorsed'] ?? 0) + ($stats['under_review'] ?? 0); ?>
    <div class="stats-row-ext">
        <div class="stat-card-ext active">
            <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af;">
                <i class="fa fa-layer-group"></i>
            </div>
            <div>
                <div style="font-size: 28px; font-weight: 700; color: #1f2937; line-height: 1;"><?= $totalItems ?></div>
                <div style="font-size: 12px; color: #6b7280; margin-top: 4px; font-weight: 500;">Total Items</div>
            </div>
        </div>
        <div class="stat-card-ext">
            <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; background: linear-gradient(135deg, #e0e7ff, #c7d2fe); color: #5b21b6;">
                <i class="fa fa-check-double"></i>
            </div>
            <div>
                <div style="font-size: 28px; font-weight: 700; color: #1f2937; line-height: 1;"><?= $stats['endorsed'] ?? 0 ?></div>
                <div style="font-size: 12px; color: #6b7280; margin-top: 4px; font-weight: 500;">Endorsed</div>
            </div>
        </div>
        <div class="stat-card-ext">
            <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e;">
                <i class="fa fa-eye"></i>
            </div>
            <div>
                <div style="font-size: 28px; font-weight: 700; color: #1f2937; line-height: 1;"><?= $stats['under_review'] ?? 0 ?></div>
                <div style="font-size: 12px; color: #6b7280; margin-top: 4px; font-weight: 500;">Under Review</div>
            </div>
        </div>
        <div class="stat-card-ext">
            <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46;">
                <i class="fa fa-check-circle"></i>
            </div>
            <div>
                <div style="font-size: 28px; font-weight: 700; color: #1f2937; line-height: 1;"><?= $stats['approved_today'] ?? 0 ?></div>
                <div style="font-size: 12px; color: #6b7280; margin-top: 4px; font-weight: 500;">Approved Today</div>
            </div>
        </div>
    </div>
    
    <!-- Filter Container -->
    <div class="filter-container">
        <form method="GET">
            <div class="filter-header">
                <h3><i class="fa fa-filter"></i> Filter Extensions</h3>
            </div>
            
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Items</option>
                        <option value="endorsed" <?= $statusFilter === 'endorsed' ? 'selected' : '' ?>>Endorsed (Pending)</option>
                        <option value="under_ro_review" <?= $statusFilter === 'under_ro_review' ? 'selected' : '' ?>>Under Review</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Extension Type</label>
                    <select name="type">
                        <option value="">All Types</option>
                        <option value="timeline" <?= $typeFilter === 'timeline' ? 'selected' : '' ?>>Time Extension</option>
                        <option value="budget" <?= $typeFilter === 'budget' ? 'selected' : '' ?>>Budget Extension</option>
                        <option value="timeline_budget" <?= $typeFilter === 'timeline_budget' ? 'selected' : '' ?>>Time & Budget</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Researcher Type</label>
                    <select name="researcher_type">
                        <option value="">All Types</option>
                        <option value="faculty" <?= $researcherTypeFilter === 'faculty' ? 'selected' : '' ?>>Faculty</option>
                        <option value="student" <?= $researcherTypeFilter === 'student' ? 'selected' : '' ?>>Student</option>
                        <option value="personnel" <?= $researcherTypeFilter === 'personnel' ? 'selected' : '' ?>>Personnel</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by title..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-group filter-buttons">
                    <label>&nbsp;</label>
                    <div class="btn-group">
                        <?php if ($statusFilter || $typeFilter || $researcherTypeFilter || $searchQuery): ?>
                            <a href="research_office_extension_queue.php" class="clear-filters"><i class="fa fa-times"></i></a>
                        <?php endif; ?>
                        <button type="submit" class="filter-btn"><i class="fa fa-search"></i> Apply Filters</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Extension Queue Table -->
    <div class="queue-table-container">
        <?php if (empty($extensions)): ?>
            <div class="empty-state">
                <i class="fa fa-calendar-check"></i>
                <h3>No Extension Requests</h3>
                <p>There are no extension requests pending Research Office review at this time.</p>
            </div>
        <?php else: ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Extension Request</th>
                        <th>Unit</th>
                        <th>Type</th>
                        <th>Researcher</th>
                        <th>Status</th>
                        <th>Endorsed</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($extensions as $ext): ?>
                        <tr>
                            <td class="extension-title-cell">
                                <a href="project_view.php?id=<?= $ext['project_id'] ?>" class="extension-title-link"
                                   onclick="event.preventDefault(); window.SPA && window.SPA.loadPage ? window.SPA.loadPage('project_view.php?id=<?= $ext['project_id'] ?>') : window.location.href=this.href;">
                                    <?= s($ext['project_title']) ?>
                                </a>
                                <div class="extension-meta">
                                    <span><i class="fa fa-hashtag"></i> <?= s($ext['reference_number'] ?: $ext['project_code']) ?></span>
                                </div>
                            </td>
                            <td class="unit-cell"><?= s($ext['researcher_unit_name']) ?></td>
                            <td>
                                <span class="type-badge type-<?= s($ext['extension_type']) ?>">
                                    <?= getExtensionTypeLabel($ext['extension_type']) ?>
                                </span>
                            </td>
                            <td>
                                <span class="researcher-type-badge type-<?= s($ext['researcher_type']) ?>">
                                    <?= s(ucfirst($ext['researcher_type'])) ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge <?= getStatusBadgeClass($ext['status']) ?>">
                                    <?= getStatusLabel($ext['status']) ?>
                                </span>
                            </td>
                            <td class="date-cell"><?= $ext['coordinator_reviewed_at'] ? date('M d, Y', strtotime($ext['coordinator_reviewed_at'])) : date('M d, Y', strtotime($ext['created_at'])) ?></td>
                            <td>
                                <div class="actions-cell">
                                    <a href="project_view.php?id=<?= $ext['project_id'] ?>" class="btn btn-view"
                                       onclick="event.preventDefault(); window.SPA && window.SPA.loadPage ? window.SPA.loadPage('project_view.php?id=<?= $ext['project_id'] ?>') : window.location.href=this.href;">
                                        <i class="fa fa-eye"></i> View
                                    </a>
                                    
                                    <?php if ($ext['status'] === 'endorsed'): ?>
                                        <button class="btn btn-start" onclick="startROReview(<?= $ext['id'] ?>)">
                                            <i class="fa fa-play"></i>
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if ($ext['status'] === 'under_ro_review'): ?>
                                        <button class="btn btn-return" onclick="openReturnModal(<?= $ext['id'] ?>, '<?= s(addslashes($ext['project_title'])) ?>')">
                                            <i class="fa fa-undo"></i>
                                        </button>
                                        <button class="btn btn-reject" onclick="openRejectModal(<?= $ext['id'] ?>, '<?= s(addslashes($ext['project_title'])) ?>')">
                                            <i class="fa fa-times"></i>
                                        </button>
                                        <button class="btn btn-approve" onclick="openApproveModal(<?= $ext['id'] ?>, '<?= s(addslashes($ext['project_title'])) ?>', '<?= s($ext['extension_type']) ?>', '<?= s($ext['requested_end_date']) ?>', '<?= s($ext['requested_additional_budget']) ?>')">
                                            <i class="fa fa-check"></i> Approve
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="table-footer">
                Showing <?= count($extensions) ?> of <?= $pagination['total'] ?> extension requests
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Pagination -->
    <?php if (!empty($extensions) && $pagination['total_pages'] > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&unit=<?= s($unitFilter) ?>&q=<?= s($searchQuery) ?>">
                    <i class="fa fa-chevron-left"></i> Prev
                </a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($pagination['total_pages'], $page + 2); $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&unit=<?= s($unitFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $pagination['total_pages']): ?>
                <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&unit=<?= s($unitFilter) ?>&q=<?= s($searchQuery) ?>">
                    Next <i class="fa fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Return to Coordinator Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header" style="background: #fef3c7;">
            <h2 style="color: #92400e;"><i class="fa fa-undo"></i> Return to Coordinator</h2>
            <button class="modal-close" onclick="closeModal('returnModal')">&times;</button>
        </div>
        <div class="modal-body">
            <p id="returnProjectTitle" style="font-weight: 600; margin-bottom: 16px;"></p>
            <input type="hidden" id="returnExtensionId">
            <div class="form-group">
                <label>Reason for Return <span style="color: #dc2626;">*</span></label>
                <textarea id="returnReason" placeholder="Explain why this request is being returned to the coordinator..." required></textarea>
                <small style="color: #6b7280;">The coordinator will need to re-review and potentially return to the researcher.</small>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-view" onclick="closeModal('returnModal')">Cancel</button>
            <button class="btn btn-return" style="background: #f59e0b; color: white;" onclick="submitReturn()">
                <i class="fa fa-undo"></i> Return to Coordinator
            </button>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header" style="background: #fee2e2;">
            <h2 style="color: #991b1b;"><i class="fa fa-times-circle"></i> Reject Extension Request</h2>
            <button class="modal-close" onclick="closeModal('rejectModal')">&times;</button>
        </div>
        <div class="modal-body">
            <p id="rejectProjectTitle" style="font-weight: 600; margin-bottom: 16px;"></p>
            <input type="hidden" id="rejectExtensionId">
            <div class="form-group">
                <label>Rejection Reason <span style="color: #dc2626;">*</span></label>
                <textarea id="rejectReason" placeholder="Provide a clear reason for rejecting this extension request..." required></textarea>
                <small style="color: #6b7280;">This message will be visible to the researcher and coordinator.</small>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-view" onclick="closeModal('rejectModal')">Cancel</button>
            <button class="btn btn-reject" onclick="submitReject()">
                <i class="fa fa-times"></i> Reject Extension
            </button>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header" style="background: linear-gradient(135deg, #064e1a, #0b6a24); color: white;">
            <h2 style="color: white;"><i class="fa fa-check-circle"></i> Approve Extension Request</h2>
            <button class="modal-close" style="color: white;" onclick="closeModal('approveModal')">&times;</button>
        </div>
        <div class="modal-body">
            <p id="approveProjectTitle" style="font-weight: 600; margin-bottom: 16px;"></p>
            <input type="hidden" id="approveExtensionId">
            <input type="hidden" id="approveExtensionType">
            
            <div class="approval-summary">
                <h4><i class="fa fa-clipboard-check"></i> Approval Details</h4>
                <div id="timelineApproval" style="display: none;">
                    <div class="form-group">
                        <label>Approved End Date</label>
                        <input type="date" id="approvedEndDate" min="<?= date('Y-m-d') ?>">
                        <small style="color: #6b7280;">You may adjust the approved end date if needed.</small>
                    </div>
                </div>
                <div id="budgetApproval" style="display: none;">
                    <div class="form-group">
                        <label>Approved Additional Budget (₱)</label>
                        <input type="number" id="approvedBudget" step="0.01" min="0">
                        <small style="color: #6b7280;">You may adjust the approved budget if needed.</small>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>Conditions (Optional)</label>
                <textarea id="approvalConditions" placeholder="Add any conditions or notes for approval..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Remarks (Optional)</label>
                <textarea id="approvalRemarks" placeholder="Additional remarks..."></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-view" onclick="closeModal('approveModal')">Cancel</button>
            <button class="btn btn-approve" style="background: #064e1a;" onclick="submitApproval()">
                <i class="fa fa-check"></i> Approve Extension
            </button>
        </div>
    </div>
</div>

<script>
(function() {
    // Modal functions
    window.openModal = function(modalId) {
        document.getElementById(modalId).classList.add('active');
    };
    
    window.closeModal = function(modalId) {
        document.getElementById(modalId).classList.remove('active');
    };
    
    // Start RO review
    window.startROReview = async function(extensionId) {
        if (!confirm('Start reviewing this extension request?')) return;
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'start_ro_extension_review',
                    extension_id: extensionId
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Review started!');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to start review'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Return to coordinator modal
    window.openReturnModal = function(extensionId, projectTitle) {
        document.getElementById('returnExtensionId').value = extensionId;
        document.getElementById('returnProjectTitle').textContent = 'Project: ' + projectTitle;
        document.getElementById('returnReason').value = '';
        openModal('returnModal');
    };
    
    window.submitReturn = async function() {
        const extensionId = document.getElementById('returnExtensionId').value;
        const reason = document.getElementById('returnReason').value.trim();
        
        if (!reason) {
            alert('❌ Please provide a reason for return.');
            return;
        }
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'return_extension_to_coordinator',
                    extension_id: extensionId,
                    reason: reason
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Extension request returned to coordinator.');
                closeModal('returnModal');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to return'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Reject modal
    window.openRejectModal = function(extensionId, projectTitle) {
        document.getElementById('rejectExtensionId').value = extensionId;
        document.getElementById('rejectProjectTitle').textContent = 'Project: ' + projectTitle;
        document.getElementById('rejectReason').value = '';
        openModal('rejectModal');
    };
    
    window.submitReject = async function() {
        const extensionId = document.getElementById('rejectExtensionId').value;
        const reason = document.getElementById('rejectReason').value.trim();
        
        if (!reason) {
            alert('❌ Please provide a rejection reason.');
            return;
        }
        
        if (!confirm('Are you sure you want to reject this extension request? This action cannot be undone.')) {
            return;
        }
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'reject_extension',
                    extension_id: extensionId,
                    reason: reason
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Extension request rejected.');
                closeModal('rejectModal');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to reject'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Approve modal
    window.openApproveModal = function(extensionId, projectTitle, extensionType, requestedEndDate, requestedBudget) {
        document.getElementById('approveExtensionId').value = extensionId;
        document.getElementById('approveExtensionType').value = extensionType;
        document.getElementById('approveProjectTitle').textContent = 'Project: ' + projectTitle;
        document.getElementById('approvalConditions').value = '';
        document.getElementById('approvalRemarks').value = '';
        
        // Show/hide fields based on extension type
        const timelineApproval = document.getElementById('timelineApproval');
        const budgetApproval = document.getElementById('budgetApproval');
        
        if (extensionType === 'timeline' || extensionType === 'timeline_budget') {
            timelineApproval.style.display = 'block';
            document.getElementById('approvedEndDate').value = requestedEndDate || '';
        } else {
            timelineApproval.style.display = 'none';
        }
        
        if (extensionType === 'budget' || extensionType === 'timeline_budget') {
            budgetApproval.style.display = 'block';
            document.getElementById('approvedBudget').value = requestedBudget || '';
        } else {
            budgetApproval.style.display = 'none';
        }
        
        openModal('approveModal');
    };
    
    window.submitApproval = async function() {
        const extensionId = document.getElementById('approveExtensionId').value;
        const extensionType = document.getElementById('approveExtensionType').value;
        const conditions = document.getElementById('approvalConditions').value.trim();
        const remarks = document.getElementById('approvalRemarks').value.trim();
        
        const approvalData = { conditions: conditions };
        
        if (extensionType === 'timeline' || extensionType === 'timeline_budget') {
            approvalData.approved_end_date = document.getElementById('approvedEndDate').value;
            if (!approvalData.approved_end_date) {
                alert('❌ Please provide the approved end date.');
                return;
            }
        }
        
        if (extensionType === 'budget' || extensionType === 'timeline_budget') {
            approvalData.approved_additional_budget = parseFloat(document.getElementById('approvedBudget').value) || 0;
        }
        
        if (!confirm('Are you sure you want to approve this extension request? This will update the project accordingly.')) {
            return;
        }
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'approve_extension',
                    extension_id: extensionId,
                    approval_data: approvalData,
                    remarks: remarks
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                let message = '✅ Extension request approved!\n\n';
                if (result.approved_end_date) {
                    message += 'New End Date: ' + result.approved_end_date + '\n';
                }
                if (result.approved_additional_budget) {
                    message += 'Additional Budget: ₱' + parseFloat(result.approved_additional_budget).toLocaleString();
                }
                alert(message);
                closeModal('approveModal');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to approve'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Close modal on outside click
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });
})();
</script>
