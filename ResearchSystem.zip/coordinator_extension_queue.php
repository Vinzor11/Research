<?php
/**
 * Coordinator Extension Request Queue
 * 
 * Centralized queue for coordinators to review extension requests
 * from projects within their assigned scope.
 * 
 * Workflow: submitted → under_coordinator_review → (return/endorse) → endorsed
 * 
 * IMPORTANT: Coordinators CANNOT approve/reject extensions - only validate and endorse
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';

// Access control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'coordinator'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$employeeId = $_SESSION['employee_id'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get coordinator types for current user
$coordinatorTypes = [];
if ($employeeId) {
    $stmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $coordinatorTypes[] = $row['coordinator_type'];
    }
    $stmt->close();
}

// Initialize service
$projectService = new ProjectService($conn);

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$typeFilter = $_GET['type'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get extension queue
$filters = [
    'status' => $statusFilter ?: null,
    'extension_type' => $typeFilter ?: null,
    'search' => $searchQuery ?: null
];
$queueResult = $projectService->getCoordinatorExtensionQueue($filters, $page, 15);
$extensions = $queueResult['data'];
$pagination = $queueResult['pagination'];

// Get queue statistics
$stats = $projectService->getCoordinatorExtensionStats();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

function getExtensionTypeLabel($type) {
    $labels = [
        'timeline' => 'Time Extension',
        'budget' => 'Budget Extension',
        'timeline_budget' => 'Time & Budget',
        'scope' => 'Scope Change'
    ];
    return $labels[$type] ?? ucfirst($type);
}

function getStatusBadgeClass($status) {
    $classes = [
        'submitted' => 'status-submitted',
        'under_coordinator_review' => 'status-review',
        'returned_for_revision' => 'status-returned',
        'endorsed' => 'status-endorsed'
    ];
    return $classes[$status] ?? 'status-default';
}

function getStatusLabel($status) {
    $labels = [
        'submitted' => 'Pending Review',
        'under_coordinator_review' => 'Under Review',
        'returned_for_revision' => 'Returned',
        'endorsed' => 'Endorsed'
    ];
    return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
}
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   EXTENSION QUEUE - UNIFIED DESIGN SYSTEM
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.header-right {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }
.role-badge.badge-faculty { background: #dbeafe; color: #1e40af; }
.role-badge.badge-student { background: #fef3c7; color: #92400e; }
.role-badge.badge-personnel { background: #e0e7ff; color: #5b21b6; }

/* Stats Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    transition: all 0.3s ease;
    cursor: default;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-pending { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-review { background: linear-gradient(135deg, #e0e7ff, #c7d2fe); color: #5b21b6; }
.stat-icon.icon-endorsed { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }
.stat-icon.icon-returned { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.filter-header i { color: #064e1a; font-size: 16px; }
.filter-header h3 { font-size: 15px; font-weight: 600; color: #374151; margin: 0; }

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

.queue-table th:nth-child(1) { width: 10%; text-align: center; }
.queue-table th:nth-child(2) { width: 32%; }
.queue-table th:nth-child(3) { width: 18%; text-align: center; }
.queue-table th:nth-child(4) { width: 12%; text-align: center; }
.queue-table th:nth-child(5) { width: 12%; text-align: center; }
.queue-table th:nth-child(6) { width: 16%; text-align: center; }

.queue-table td {
    padding: 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
}

.queue-table tr:hover { background: #f9fafb; }

/* Type Badge */
.type-cell { text-align: center; }

.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.type-badge i { font-size: 12px; }
.type-extension { background: #fee2e2; color: #991b1b; }

/* Item Cell */
.item-cell { text-align: left; }

.item-title {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
}

.item-title:hover { color: #064e1a; }

.item-meta { font-size: 12px; color: #6b7280; margin-bottom: 6px; }

.item-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.ref-badge { font-size: 11px; color: #6b7280; font-family: monospace; }

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
}

.researcher-type-badge.faculty { background: #dbeafe; color: #1e40af; }
.researcher-type-badge.student { background: #fef3c7; color: #92400e; }
.researcher-type-badge.personnel { background: #e0e7ff; color: #5b21b6; }

.researcher-name {
    font-size: 12px;
    color: #374151;
    display: flex;
    align-items: center;
    gap: 4px;
}

.researcher-name i { color: #9ca3af; font-size: 11px; }

/* Other cells */
.unit-cell { font-size: 13px; color: #374151; text-align: center; }
.status-cell { text-align: center; }
.date-cell { font-size: 13px; color: #6b7280; text-align: center; }
.action-cell { text-align: center; }

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-submitted { background: #dbeafe; color: #1e40af; }
.status-review { background: #fef3c7; color: #92400e; }
.status-returned { background: #fee2e2; color: #991b1b; }
.status-endorsed { background: #d1fae5; color: #065f46; }

/* Review Button */
.btn-review {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-review:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }

.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; }
.pagination .current { background: #064e1a; color: white; }

/* Legacy filter-container override - these replace old styles */
.old-filter-container {
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.filter-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header h3 i {
    color: #064e1a;
}

.filter-grid {
    display: flex;
    gap: 16px;
    align-items: flex-end;
}

.filter-grid .filter-group {
    flex: 1;
    min-width: 140px;
}

.filter-grid .filter-group:nth-child(3) {
    flex: 2;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="search"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input[type="text"]:focus,
.filter-group input[type="search"]:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-buttons {
    flex: 0 0 auto !important;
}

.btn-group {
    display: flex;
    gap: 8px;
    align-items: center;
}

.filter-btn {
    padding: 10px 20px;
    background: linear-gradient(135deg, #064e1a 0%, #0a7c2e 100%);
    color: white;
    border: none;
    border-radius: 8px;
    white-space: nowrap;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
}

.filter-btn:hover {
    background: linear-gradient(135deg, #053d15 0%, #086324 100%);
}

.clear-filters {
    padding: 10px 12px;
    background: white;
    color: #6b7280;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
}

.clear-filters:hover {
    background: #f3f4f6;
    color: #374151;
}

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
}

.status-submitted { background: #dbeafe; color: #1e40af; }
.status-review { background: #fef3c7; color: #92400e; }
.status-returned { background: #fee2e2; color: #991b1b; }
.status-endorsed { background: #dcfce7; color: #166534; }

/* Extension Type Badge */
.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.type-timeline { background: #e0e7ff; color: #4338ca; }
.type-budget { background: #dcfce7; color: #166534; }
.type-timeline_budget { background: #fef3c7; color: #92400e; }
.type-scope { background: #f3e8ff; color: #7c3aed; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: center;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
    white-space: nowrap;
}

.queue-table th:nth-child(1) { width: 30%; text-align: left; }
.queue-table th:nth-child(2) { width: 15%; }
.queue-table th:nth-child(3) { width: 12%; }
.queue-table th:nth-child(4) { width: 10%; }
.queue-table th:nth-child(5) { width: 12%; }
.queue-table th:nth-child(6) { width: 21%; }

.queue-table td {
    padding: 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
    text-align: center;
}

.queue-table td:nth-child(1) {
    text-align: left;
}

.queue-table tr:hover {
    background: #f9fafb;
}

/* Extension Title Cell */
.extension-title-cell {
    text-align: left !important;
}

.extension-title-link {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.extension-title-link:hover {
    color: #064e1a;
}

.extension-meta {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
    color: #6b7280;
    flex-wrap: wrap;
}

.extension-meta i {
    color: #9ca3af;
}

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.type-faculty { background: #dbeafe; color: #1e40af; }
.type-student { background: #fef3c7; color: #92400e; }
.type-personnel { background: #e0e7ff; color: #5b21b6; }

/* Unit Cell */
.unit-cell {
    font-size: 12px;
    color: #374151;
}

/* Date Cell */
.date-cell {
    font-size: 12px;
    color: #6b7280;
}

/* Actions Cell */
.actions-cell {
    display: inline-flex;
    justify-content: center;
    gap: 6px;
    flex-wrap: wrap;
}

.actions-cell .btn {
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.btn-view { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }
.btn-view:hover { background: #e5e7eb; }

.btn-start { background: #fef3c7; color: #92400e; }
.btn-start:hover { background: #fde68a; }

.btn-return { background: #fee2e2; color: #991b1b; }
.btn-return:hover { background: #fecaca; }

.btn-endorse { background: #064e1a; color: white; }
.btn-endorse:hover { background: #053615; }

/* Table Footer */
.table-footer {
    padding: 12px 16px;
    background: #f9fafb;
    border-top: 1px solid #e5e7eb;
    font-size: 13px;
    color: #6b7280;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.empty-state i {
    font-size: 48px;
    color: #d1d5db;
    margin-bottom: 16px;
}

.empty-state h3 {
    font-size: 18px;
    color: #6b7280;
    margin: 0 0 8px 0;
}

.empty-state p {
    font-size: 14px;
    color: #9ca3af;
    margin: 0;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-content {
    transform: scale(1);
}

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 20px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
}

.form-group textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    min-height: 100px;
    resize: vertical;
}

/* Validation Checklist */
.validation-checklist {
    background: #f9fafb;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 20px;
}

.validation-checklist h4 {
    font-size: 14px;
    color: #374151;
    margin: 0 0 12px 0;
}

.checklist-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #e5e7eb;
}

.checklist-item:last-child {
    border-bottom: none;
}

.checklist-item input[type="checkbox"] {
    width: 18px;
    height: 18px;
    accent-color: #064e1a;
}

.checklist-item label {
    font-size: 14px;
    color: #4b5563;
    cursor: pointer;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 25px;
}

.pagination a, .pagination span {
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 14px;
    text-decoration: none;
}

.pagination a {
    background: white;
    color: #374151;
    border: 1px solid #e5e7eb;
}

.pagination a:hover {
    background: #f3f4f6;
}

.pagination span.current {
    background: #064e1a;
    color: white;
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa fa-calendar-plus header-icon"></i>
                <div>
                    <h1>Extension Queue</h1>
                    <p>Review and process extension requests from projects</p>
                </div>
            </div>
            <div class="header-right" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #064e1a;">
                    <i class="fa fa-user-tie"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    <?php if (!empty($coordinatorTypes)): ?>
                        <?= implode(' / ', array_map(function($t) { return ucfirst($t); }, $coordinatorTypes)) ?> Coordinator
                    <?php else: ?>
                        Coordinator
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <?php $totalItems = ($stats['submitted'] ?? 0) + ($stats['under_review'] ?? 0); ?>
    <div class="stats-row">
        <div class="stat-card active">
            <div class="stat-icon icon-total">
                <i class="fa fa-layer-group"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
                <div class="stat-label">Total Items</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-pending">
                <i class="fa fa-inbox"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['submitted'] ?? 0 ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-review">
                <i class="fa fa-eye"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['under_review'] ?? 0 ?></div>
                <div class="stat-label">Under Review</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-endorsed">
                <i class="fa fa-check-double"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Endorsed</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <i class="fa fa-filter"></i>
            <h3>Filter Queue</h3>
        </div>
        <form method="GET">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="submitted" <?= $statusFilter === 'submitted' ? 'selected' : '' ?>>Pending Review</option>
                        <option value="under_coordinator_review" <?= $statusFilter === 'under_coordinator_review' ? 'selected' : '' ?>>Under Review</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Extension Type</label>
                    <select name="type">
                        <option value="">All Types</option>
                        <option value="timeline" <?= $typeFilter === 'timeline' ? 'selected' : '' ?>>Time Extension</option>
                        <option value="budget" <?= $typeFilter === 'budget' ? 'selected' : '' ?>>Budget Extension</option>
                        <option value="timeline_budget" <?= $typeFilter === 'timeline_budget' ? 'selected' : '' ?>>Time & Budget</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?= s($_GET['date_from'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?= s($_GET['date_to'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by project title..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-group filter-actions">
                    <label>&nbsp;</label>
                    <?php if ($statusFilter || $typeFilter || $searchQuery): ?>
                        <a href="coordinator_extension_queue.php" class="clear-btn" title="Clear filters"><i class="fa fa-times"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Queue Table -->
    <div class="queue-table-container">
        <?php if (empty($extensions)): ?>
            <div class="empty-state">
                <i class="fa fa-inbox"></i>
                <h3>No Extension Requests</h3>
                <p>There are no extension requests pending your review at this time.</p>
            </div>
        <?php else: ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Item</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($extensions as $ext): ?>
                        <tr>
                            <!-- TYPE -->
                            <td class="type-cell">
                                <span class="type-badge type-extension">
                                    <i class="fa fa-calendar-plus"></i> EXTENSION
                                </span>
                            </td>
                            
                            <!-- ITEM -->
                            <td class="item-cell">
                                <a href="project_view.php?id=<?= $ext['project_id'] ?>" class="item-title"
                                   onclick="event.preventDefault(); window.SPA && window.SPA.loadPage ? window.SPA.loadPage('project_view.php?id=<?= $ext['project_id'] ?>') : window.location.href=this.href;">
                                    <?= s($ext['project_title']) ?>
                                </a>
                                <div class="item-meta"><?= getExtensionTypeLabel($ext['extension_type']) ?></div>
                                <div class="item-badges">
                                    <span class="ref-badge"><?= s($ext['reference_number'] ?: $ext['project_code']) ?></span>
                                    <span class="researcher-type-badge <?= s($ext['researcher_type']) ?>">
                                        <?= s(strtoupper($ext['researcher_type'])) ?>
                                    </span>
                                    <span class="researcher-name">
                                        <i class="fa fa-user"></i> <?= s($ext['researcher_name'] ?? 'Unknown') ?>
                                    </span>
                                </div>
                            </td>
                            
                            <!-- UNIT -->
                            <td class="unit-cell"><?= s($ext['researcher_unit_name'] ?? '—') ?></td>
                            
                            <!-- STATUS -->
                            <td class="status-cell">
                                <span class="status-badge <?= getStatusBadgeClass($ext['status']) ?>">
                                    <?= getStatusLabel($ext['status']) ?>
                                </span>
                            </td>
                            
                            <!-- SUBMITTED -->
                            <td class="date-cell"><?= date('M d, Y', strtotime($ext['created_at'])) ?></td>
                            
                            <!-- ACTION -->
                            <td class="action-cell">
                                <a href="project_view.php?id=<?= $ext['project_id'] ?>" class="btn-review"
                                   onclick="event.preventDefault(); window.SPA && window.SPA.loadPage ? window.SPA.loadPage('project_view.php?id=<?= $ext['project_id'] ?>') : window.location.href=this.href;">
                                    <i class="fa fa-eye"></i> Review
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="table-footer">
                Showing <?= count($extensions) ?> of <?= $pagination['total'] ?> extension requests
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Pagination -->
    <?php if (!empty($extensions) && $pagination['total_pages'] > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>">
                    <i class="fa fa-chevron-left"></i> Prev
                </a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($pagination['total_pages'], $page + 2); $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $pagination['total_pages']): ?>
                <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>">
                    Next <i class="fa fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Return Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header" style="background: #fee2e2;">
            <h2 style="color: #991b1b;"><i class="fa fa-undo"></i> Return for Revision</h2>
            <button class="modal-close" onclick="closeModal('returnModal')">&times;</button>
        </div>
        <div class="modal-body">
            <p id="returnProjectTitle" style="font-weight: 600; margin-bottom: 16px;"></p>
            <input type="hidden" id="returnExtensionId">
            <div class="form-group">
                <label>Reason for Return <span style="color: #dc2626;">*</span></label>
                <textarea id="returnReason" placeholder="Explain why this extension request needs revision..." required></textarea>
                <small style="color: #6b7280;">This message will be visible to the researcher.</small>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-view" onclick="closeModal('returnModal')">Cancel</button>
            <button class="btn btn-return" onclick="submitReturn()">
                <i class="fa fa-undo"></i> Return for Revision
            </button>
        </div>
    </div>
</div>

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header" style="background: linear-gradient(135deg, #064e1a, #0a7c2e); color: white;">
            <h2 style="color: white;"><i class="fa fa-check-double"></i> Endorse to Research Office</h2>
            <button class="modal-close" style="color: white;" onclick="closeModal('endorseModal')">&times;</button>
        </div>
        <div class="modal-body">
            <p id="endorseProjectTitle" style="font-weight: 600; margin-bottom: 16px;"></p>
            <input type="hidden" id="endorseExtensionId">
            
            <div class="validation-checklist">
                <h4><i class="fa fa-clipboard-check"></i> Validation Checklist</h4>
                <div class="checklist-item">
                    <input type="checkbox" id="check_justification" name="justification_valid">
                    <label for="check_justification">Justification is valid and clearly explained</label>
                </div>
                <div class="checklist-item">
                    <input type="checkbox" id="check_timeline" name="timeline_reasonable">
                    <label for="check_timeline">Requested timeline/budget is reasonable</label>
                </div>
                <div class="checklist-item">
                    <input type="checkbox" id="check_documents" name="documents_complete">
                    <label for="check_documents">Supporting documents are complete (if any)</label>
                </div>
            </div>
            
            <div class="form-group">
                <label>Endorsement Notes (Optional)</label>
                <textarea id="endorseNotes" placeholder="Add any notes for the Research Office..."></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-view" onclick="closeModal('endorseModal')">Cancel</button>
            <button class="btn btn-endorse" id="endorseSubmitBtn" onclick="submitEndorsement()" disabled style="opacity: 0.5; cursor: not-allowed;">
                <i class="fa fa-paper-plane"></i> Endorse to Research Office
            </button>
        </div>
    </div>
</div>

<script>
(function() {
    // Modal functions
    window.openModal = function(modalId) {
        document.getElementById(modalId).classList.add('active');
    };
    
    window.closeModal = function(modalId) {
        document.getElementById(modalId).classList.remove('active');
    };
    
    // Start review
    window.startReview = async function(extensionId) {
        if (!confirm('Start reviewing this extension request?')) return;
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'start_extension_review',
                    extension_id: extensionId
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Review started!');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to start review'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Return modal
    window.openReturnModal = function(extensionId, projectTitle) {
        document.getElementById('returnExtensionId').value = extensionId;
        document.getElementById('returnProjectTitle').textContent = 'Project: ' + projectTitle;
        document.getElementById('returnReason').value = '';
        openModal('returnModal');
    };
    
    window.submitReturn = async function() {
        const extensionId = document.getElementById('returnExtensionId').value;
        const reason = document.getElementById('returnReason').value.trim();
        
        if (!reason) {
            alert('❌ Please provide a reason for return.');
            return;
        }
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'return_extension',
                    extension_id: extensionId,
                    reason: reason
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Extension request returned for revision.');
                closeModal('returnModal');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to return'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Update endorse button state based on checkboxes
    function updateEndorseButtonState() {
        const justificationValid = document.getElementById('check_justification').checked;
        const timelineReasonable = document.getElementById('check_timeline').checked;
        const documentsComplete = document.getElementById('check_documents').checked;
        const btn = document.getElementById('endorseSubmitBtn');
        
        if (justificationValid && timelineReasonable && documentsComplete) {
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        } else {
            btn.disabled = true;
            btn.style.opacity = '0.5';
            btn.style.cursor = 'not-allowed';
        }
    }
    
    // Add event listeners to checkboxes
    document.getElementById('check_justification').addEventListener('change', updateEndorseButtonState);
    document.getElementById('check_timeline').addEventListener('change', updateEndorseButtonState);
    document.getElementById('check_documents').addEventListener('change', updateEndorseButtonState);
    
    // Endorse modal
    window.openEndorseModal = function(extensionId, projectTitle) {
        document.getElementById('endorseExtensionId').value = extensionId;
        document.getElementById('endorseProjectTitle').textContent = 'Project: ' + projectTitle;
        document.getElementById('endorseNotes').value = '';
        // Reset checkboxes
        document.getElementById('check_justification').checked = false;
        document.getElementById('check_timeline').checked = false;
        document.getElementById('check_documents').checked = false;
        updateEndorseButtonState();
        openModal('endorseModal');
    };
    
    window.submitEndorsement = async function() {
        const extensionId = document.getElementById('endorseExtensionId').value;
        const notes = document.getElementById('endorseNotes').value.trim();
        
        // Validate checklist
        const justificationValid = document.getElementById('check_justification').checked;
        const timelineReasonable = document.getElementById('check_timeline').checked;
        const documentsComplete = document.getElementById('check_documents').checked;
        
        if (!justificationValid || !timelineReasonable || !documentsComplete) {
            alert('❌ Please complete all validation items before endorsing.');
            return;
        }
        
        try {
            const response = await fetch('project_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'endorse_extension',
                    extension_id: extensionId,
                    validation_data: {
                        justification_valid: justificationValid,
                        timeline_reasonable: timelineReasonable,
                        documents_complete: documentsComplete
                    },
                    remarks: notes
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Extension request endorsed to Research Office!');
                closeModal('endorseModal');
                window.location.reload();
            } else {
                alert('❌ Error: ' + (result.error || 'Failed to endorse'));
            }
        } catch (error) {
            alert('❌ Error: ' + error.message);
        }
    };
    
    // Close modal on outside click
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });
})();
</script>
