<?php
/**
 * Coordinator Assignment API
 * 
 * Handles coordinator type assignment, scope management, and audit logging.
 * Follows the principle of least privilege - no implicit access.
 * 
 * Actions:
 * - assign_type: Assign a coordinator type (faculty/student/personnel)
 * - remove_type: Remove a coordinator type
 * - update_scope: Update scope mode and unit assignments
 * - get_scopes: Get current scope assignments for an employee
 * - get_units: Fetch available units from HR (filtered by type)
 */

// Ensure clean JSON output - suppress any stray errors/warnings
error_reporting(0);
ob_start();

// Set JSON header early
header('Content-Type: application/json');

// Custom error handler to return JSON errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // Clear any output
    ob_clean();
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $errstr
    ]);
    exit;
});

// Exception handler
set_exception_handler(function($e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'error' => 'Exception: ' . $e->getMessage()
    ]);
    exit;
});

session_start();
require 'db.php';
require 'config.php';

// Load HR API helper - but don't fail if it has issues
try {
    require_once 'hr_api_helper.php';
} catch (Exception $e) {
    // Will handle missing HR API in the get_units action
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Normalize employee ID format (only declare if not already defined in config.php)
 */
if (!function_exists('normalizeEmployeeId')) {
    function normalizeEmployeeId($id) {
        return trim(strtoupper($id));
    }
}

/**
 * Log assignment action for audit
 */
function logAssignmentAction($conn, $employeeId, $actionType, $data = []) {
    try {
        $performedBy = $_SESSION['user_id'] ?? 0;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt = $conn->prepare("
            INSERT INTO coordinator_assignment_logs 
            (employee_id, action_type, coordinator_type, scope_mode, unit_id, old_value, new_value, performed_by, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $coordinatorType = $data['coordinator_type'] ?? null;
        $scopeMode = $data['scope_mode'] ?? null;
        $unitId = $data['unit_id'] ?? null;
        $oldValue = isset($data['old_value']) ? json_encode($data['old_value']) : null;
        $newValue = isset($data['new_value']) ? json_encode($data['new_value']) : null;
        
        $stmt->bind_param("sssssssiss", 
            $employeeId, $actionType, $coordinatorType, $scopeMode, $unitId, 
            $oldValue, $newValue, $performedBy, $ipAddress, $userAgent
        );
        $stmt->execute();
        $stmt->close();
        
        debugLog("Assignment audit logged", [
            'employee_id' => $employeeId,
            'action' => $actionType,
            'performed_by' => $performedBy
        ]);
    } catch (Exception $e) {
        errorLog("Failed to log assignment action", ['error' => $e->getMessage()]);
    }
}

/**
 * Update users.coordinator_type for the user with the given employee_id.
 * When user has multiple coordinator assignments, prioritize: faculty > student > personnel
 */
function updateUserCoordinatorType($conn, $employeeId) {
    $hasEmployeeId = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'")->num_rows > 0;
    $hasCoordType = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'")->num_rows > 0;
    if (!$hasEmployeeId || !$hasCoordType) return;
    
    $normalizedId = normalizeEmployeeId($employeeId);
    
    // Get highest priority active coordinator type
    $stmt = $conn->prepare("
        SELECT coordinator_type 
        FROM coordinator_assignments 
        WHERE employee_id = ? AND status = 'active' 
        ORDER BY FIELD(coordinator_type, 'faculty', 'student', 'personnel') 
        LIMIT 1
    ");
    $stmt->bind_param("s", $normalizedId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    $newType = $row ? $row['coordinator_type'] : null;
    
    if ($newType === null) {
        $updateStmt = $conn->prepare("UPDATE users SET coordinator_type = NULL WHERE employee_id = ?");
        $updateStmt->bind_param("s", $normalizedId);
    } else {
        $updateStmt = $conn->prepare("UPDATE users SET coordinator_type = ? WHERE employee_id = ?");
        $updateStmt->bind_param("ss", $newType, $normalizedId);
    }
    $updateStmt->execute();
    $updateStmt->close();
}

/**
 * Get current assignment state for an employee (for audit old_value)
 */
function getCurrentAssignmentState($conn, $employeeId) {
    $state = [
        'types' => [],
        'scope_modes' => [],
        'scopes' => []
    ];
    
    // Get types and scope modes
    $stmt = $conn->prepare("
        SELECT coordinator_type, scope_mode, hr_unit_id, hr_unit_name 
        FROM coordinator_assignments 
        WHERE employee_id = ? AND status = 'active'
    ");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $state['types'][] = $row['coordinator_type'];
        $state['scope_modes'][$row['coordinator_type']] = $row['scope_mode'];
        $state['hr_unit'] = [
            'id' => $row['hr_unit_id'],
            'name' => $row['hr_unit_name']
        ];
    }
    $stmt->close();
    
    // Get specific unit scopes
    $stmt = $conn->prepare("
        SELECT unit_id, unit_name, unit_type 
        FROM coordinator_scopes 
        WHERE employee_id = ?
    ");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $state['scopes'][] = $row;
    }
    $stmt->close();
    
    return $state;
}

// ============================================================================
// AUTHORIZATION CHECK
// ============================================================================

if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? null) !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized - Admin access required']);
    exit;
}

$userId = (int)$_SESSION['user_id'];
if ($userId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid user session']);
    exit;
}

// ============================================================================
// ENSURE SCHEMA IS UP TO DATE
// ============================================================================

// Add scope_mode column if not exists
$checkScopeMode = $conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'scope_mode'");
if ($checkScopeMode && $checkScopeMode->num_rows === 0) {
    $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN scope_mode ENUM('own_unit', 'specific_units', 'all_units') DEFAULT 'own_unit' AFTER coordinator_type");
}

// Add hr_unit_id column if not exists
$checkHrUnit = $conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'hr_unit_id'");
if ($checkHrUnit && $checkHrUnit->num_rows === 0) {
    $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN hr_unit_id VARCHAR(100) DEFAULT NULL AFTER scope_mode");
}

// Add hr_unit_name column if not exists
$checkHrUnitName = $conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'hr_unit_name'");
if ($checkHrUnitName && $checkHrUnitName->num_rows === 0) {
    $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN hr_unit_name VARCHAR(255) DEFAULT NULL AFTER hr_unit_id");
}

// Create coordinator_scopes table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS coordinator_scopes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(100) NOT NULL,
    unit_id VARCHAR(100) NOT NULL,
    unit_name VARCHAR(255) DEFAULT '',
    unit_type VARCHAR(50) DEFAULT '',
    assigned_by INT NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_employee_unit (employee_id, unit_id),
    INDEX idx_employee_id (employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Create audit log table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS coordinator_assignment_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(100) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    coordinator_type VARCHAR(20) DEFAULT NULL,
    scope_mode VARCHAR(20) DEFAULT NULL,
    unit_id VARCHAR(100) DEFAULT NULL,
    old_value TEXT DEFAULT NULL,
    new_value TEXT DEFAULT NULL,
    performed_by INT NOT NULL,
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    INDEX idx_employee_id (employee_id),
    INDEX idx_performed_at (performed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============================================================================
// PROCESS REQUEST
// ============================================================================

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$employeeId = $_POST['employee_id'] ?? $_GET['employee_id'] ?? '';

if (empty($action)) {
    echo json_encode(['success' => false, 'error' => 'Missing action parameter']);
    exit;
}

try {
    switch ($action) {
        
        // ====================================================================
        // ASSIGN COORDINATOR TYPE
        // ====================================================================
        case 'assign_type':
            $coordinatorType = $_POST['coordinator_type'] ?? '';
            $scopeMode = $_POST['scope_mode'] ?? 'own_unit';
            $hrUnitId = $_POST['hr_unit_id'] ?? null;
            $hrUnitName = $_POST['hr_unit_name'] ?? null;
            $scopeUnits = isset($_POST['scope_units']) ? json_decode($_POST['scope_units'], true) : [];
            
            if (empty($employeeId) || empty($coordinatorType)) {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
                exit;
            }
            
            if (!in_array($coordinatorType, ['faculty', 'student', 'personnel'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid coordinator type']);
                exit;
            }
            
            if (!in_array($scopeMode, ['own_unit', 'specific_units', 'all_units'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid scope mode']);
                exit;
            }
            
            // Restrict 'all_units' to prevent accidental full access
            // In production, add additional authorization check here
            
            $employeeId = normalizeEmployeeId($employeeId);
            $oldState = getCurrentAssignmentState($conn, $employeeId);
            
            // Check if already assigned
            $checkStmt = $conn->prepare("
                SELECT id, scope_mode FROM coordinator_assignments 
                WHERE employee_id = ? AND coordinator_type = ? AND status = 'active'
            ");
            $checkStmt->bind_param("ss", $employeeId, $coordinatorType);
            $checkStmt->execute();
            $existing = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            
            if ($existing) {
                // Update existing assignment
                $updateStmt = $conn->prepare("
                    UPDATE coordinator_assignments 
                    SET scope_mode = ?, hr_unit_id = ?, hr_unit_name = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");
                $updateStmt->bind_param("sssi", $scopeMode, $hrUnitId, $hrUnitName, $existing['id']);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                // Try to reactivate existing inactive assignment
                $updateStmt = $conn->prepare("
                    UPDATE coordinator_assignments 
                    SET status = 'active', scope_mode = ?, hr_unit_id = ?, hr_unit_name = ?,
                        assigned_by = ?, assigned_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                    WHERE employee_id = ? AND coordinator_type = ? AND status = 'inactive'
                ");
                $updateStmt->bind_param("sssiss", $scopeMode, $hrUnitId, $hrUnitName, $userId, $employeeId, $coordinatorType);
                $updateStmt->execute();
                $affectedRows = $updateStmt->affected_rows;
                $updateStmt->close();
                
                if ($affectedRows === 0) {
                    // Insert new assignment
                    $insertStmt = $conn->prepare("
                        INSERT INTO coordinator_assignments 
                        (employee_id, coordinator_type, scope_mode, hr_unit_id, hr_unit_name, assigned_by, status)
                        VALUES (?, ?, ?, ?, ?, ?, 'active')
                    ");
                    $insertStmt->bind_param("sssssi", $employeeId, $coordinatorType, $scopeMode, $hrUnitId, $hrUnitName, $userId);
                    $insertStmt->execute();
                    $insertStmt->close();
                }
            }
            
            // Handle specific_units scope - save unit assignments
            if ($scopeMode === 'specific_units' && !empty($scopeUnits)) {
                // First validate that units are not already assigned to OTHER coordinators
                $conflictingUnits = [];
                $checkConflictStmt = $conn->prepare("
                    SELECT cs.unit_id, cs.unit_name, cs.employee_id, src.full_name as coordinator_name
                    FROM coordinator_scopes cs
                    LEFT JOIN synced_research_coordinators src ON cs.employee_id = src.employee_id
                    WHERE cs.unit_id = ? AND cs.employee_id != ?
                ");
                
                foreach ($scopeUnits as $unit) {
                    $unitId = $unit['id'] ?? '';
                    if (!empty($unitId)) {
                        $checkConflictStmt->bind_param("ss", $unitId, $employeeId);
                        $checkConflictStmt->execute();
                        $conflictResult = $checkConflictStmt->get_result();
                        if ($conflict = $conflictResult->fetch_assoc()) {
                            $conflictingUnits[] = [
                                'unit_name' => $conflict['unit_name'] ?: ($unit['name'] ?? $unitId),
                                'assigned_to' => $conflict['coordinator_name'] ?: $conflict['employee_id']
                            ];
                        }
                    }
                }
                $checkConflictStmt->close();
                
                // If there are conflicts, return error
                if (!empty($conflictingUnits)) {
                    $conflictMessages = array_map(function($c) {
                        return '"' . $c['unit_name'] . '" (assigned to ' . $c['assigned_to'] . ')';
                    }, $conflictingUnits);
                    
                    echo json_encode([
                        'success' => false,
                        'error' => 'The following unit(s) are already assigned to other coordinators: ' . implode(', ', $conflictMessages),
                        'conflicts' => $conflictingUnits
                    ]);
                    exit;
                }
                
                // Remove existing scopes for this employee (will re-add selected ones)
                $deleteStmt = $conn->prepare("DELETE FROM coordinator_scopes WHERE employee_id = ?");
                $deleteStmt->bind_param("s", $employeeId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                // Add new scopes
                $insertScopeStmt = $conn->prepare("
                    INSERT INTO coordinator_scopes (employee_id, unit_id, unit_name, unit_type, assigned_by)
                    VALUES (?, ?, ?, ?, ?)
                ");
                foreach ($scopeUnits as $unit) {
                    $unitId = $unit['id'] ?? '';
                    $unitName = $unit['name'] ?? '';
                    $unitType = $unit['type'] ?? '';
                    if (!empty($unitId)) {
                        $insertScopeStmt->bind_param("ssssi", $employeeId, $unitId, $unitName, $unitType, $userId);
                        $insertScopeStmt->execute();
                    }
                }
                $insertScopeStmt->close();
            }
            
            // Update user's coordinator_type
            updateUserCoordinatorType($conn, $employeeId);
            
            // Log the action
            $newState = getCurrentAssignmentState($conn, $employeeId);
            logAssignmentAction($conn, $employeeId, 'assign_type', [
                'coordinator_type' => $coordinatorType,
                'scope_mode' => $scopeMode,
                'old_value' => $oldState,
                'new_value' => $newState
            ]);
            
            echo json_encode([
                'success' => true, 
                'message' => ucfirst($coordinatorType) . ' coordinator assigned successfully'
            ]);
            break;
            
        // ====================================================================
        // REMOVE COORDINATOR TYPE
        // ====================================================================
        case 'remove_type':
            $coordinatorType = $_POST['coordinator_type'] ?? '';
            
            if (empty($employeeId) || empty($coordinatorType)) {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
                exit;
            }
            
            $employeeId = normalizeEmployeeId($employeeId);
            $oldState = getCurrentAssignmentState($conn, $employeeId);
            
            // Deactivate assignment
            $stmt = $conn->prepare("
                UPDATE coordinator_assignments 
                SET status = 'inactive', updated_at = CURRENT_TIMESTAMP
                WHERE employee_id = ? AND coordinator_type = ?
            ");
            $stmt->bind_param("ss", $employeeId, $coordinatorType);
            $stmt->execute();
            $stmt->close();
            
            // Update user's coordinator_type
            updateUserCoordinatorType($conn, $employeeId);
            
            // Log the action
            $newState = getCurrentAssignmentState($conn, $employeeId);
            logAssignmentAction($conn, $employeeId, 'remove_type', [
                'coordinator_type' => $coordinatorType,
                'old_value' => $oldState,
                'new_value' => $newState
            ]);
            
            echo json_encode([
                'success' => true, 
                'message' => ucfirst($coordinatorType) . ' coordinator removed successfully'
            ]);
            break;
            
        // ====================================================================
        // UPDATE SCOPE (Change scope mode and/or units)
        // ====================================================================
        case 'update_scope':
            $coordinatorType = $_POST['coordinator_type'] ?? '';
            $scopeMode = $_POST['scope_mode'] ?? 'own_unit';
            $scopeUnits = isset($_POST['scope_units']) ? json_decode($_POST['scope_units'], true) : [];
            
            if (empty($employeeId) || empty($coordinatorType)) {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
                exit;
            }
            
            $employeeId = normalizeEmployeeId($employeeId);
            $oldState = getCurrentAssignmentState($conn, $employeeId);
            
            // Update scope mode
            $updateStmt = $conn->prepare("
                UPDATE coordinator_assignments 
                SET scope_mode = ?, updated_at = CURRENT_TIMESTAMP
                WHERE employee_id = ? AND coordinator_type = ? AND status = 'active'
            ");
            $updateStmt->bind_param("sss", $scopeMode, $employeeId, $coordinatorType);
            $updateStmt->execute();
            $updateStmt->close();
            
            // Update unit scopes if specific_units mode
            if ($scopeMode === 'specific_units') {
                // First validate that units are not already assigned to OTHER coordinators
                if (!empty($scopeUnits)) {
                    $conflictingUnits = [];
                    $checkConflictStmt = $conn->prepare("
                        SELECT cs.unit_id, cs.unit_name, cs.employee_id, src.full_name as coordinator_name
                        FROM coordinator_scopes cs
                        LEFT JOIN synced_research_coordinators src ON cs.employee_id = src.employee_id
                        WHERE cs.unit_id = ? AND cs.employee_id != ?
                    ");
                    
                    foreach ($scopeUnits as $unit) {
                        $unitId = $unit['id'] ?? '';
                        if (!empty($unitId)) {
                            $checkConflictStmt->bind_param("ss", $unitId, $employeeId);
                            $checkConflictStmt->execute();
                            $conflictResult = $checkConflictStmt->get_result();
                            if ($conflict = $conflictResult->fetch_assoc()) {
                                $conflictingUnits[] = [
                                    'unit_name' => $conflict['unit_name'] ?: ($unit['name'] ?? $unitId),
                                    'assigned_to' => $conflict['coordinator_name'] ?: $conflict['employee_id']
                                ];
                            }
                        }
                    }
                    $checkConflictStmt->close();
                    
                    // If there are conflicts, return error
                    if (!empty($conflictingUnits)) {
                        $conflictMessages = array_map(function($c) {
                            return '"' . $c['unit_name'] . '" (assigned to ' . $c['assigned_to'] . ')';
                        }, $conflictingUnits);
                        
                        echo json_encode([
                            'success' => false,
                            'error' => 'The following unit(s) are already assigned to other coordinators: ' . implode(', ', $conflictMessages),
                            'conflicts' => $conflictingUnits
                        ]);
                        exit;
                    }
                }
                
                // Clear existing scopes
                $deleteStmt = $conn->prepare("DELETE FROM coordinator_scopes WHERE employee_id = ?");
                $deleteStmt->bind_param("s", $employeeId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                // Add new scopes
                if (!empty($scopeUnits)) {
                    $insertStmt = $conn->prepare("
                        INSERT INTO coordinator_scopes (employee_id, unit_id, unit_name, unit_type, assigned_by)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    foreach ($scopeUnits as $unit) {
                        $unitId = $unit['id'] ?? '';
                        $unitName = $unit['name'] ?? '';
                        $unitType = $unit['type'] ?? '';
                        if (!empty($unitId)) {
                            $insertStmt->bind_param("ssssi", $employeeId, $unitId, $unitName, $unitType, $userId);
                            $insertStmt->execute();
                        }
                    }
                    $insertStmt->close();
                }
            }
            
            // Log the action
            $newState = getCurrentAssignmentState($conn, $employeeId);
            logAssignmentAction($conn, $employeeId, 'set_scope_mode', [
                'coordinator_type' => $coordinatorType,
                'scope_mode' => $scopeMode,
                'old_value' => $oldState,
                'new_value' => $newState
            ]);
            
            echo json_encode([
                'success' => true, 
                'message' => 'Scope updated successfully'
            ]);
            break;
            
        // ====================================================================
        // BULK UPDATE (Full assignment update from modal)
        // Saves MULTIPLE coordinator types to coordinator_assignments table
        // ====================================================================
        case 'bulk_update':
            // Safely decode types array - handle both JSON string and array
            $types = [];
            if (isset($_POST['types'])) {
                if (is_array($_POST['types'])) {
                    $types = $_POST['types'];
                } else {
                    $decoded = json_decode($_POST['types'], true);
                    if (is_array($decoded)) {
                        $types = $decoded;
                    }
                }
            }
            
            // Filter to valid types only
            $validTypes = ['faculty', 'student', 'personnel'];
            $types = array_values(array_filter($types, function($t) use ($validTypes) {
                return in_array($t, $validTypes);
            }));
            
            $scopeMode = $_POST['scope_mode'] ?? 'own_unit';
            $scopeUnits = [];
            if (isset($_POST['scope_units'])) {
                if (is_array($_POST['scope_units'])) {
                    $scopeUnits = $_POST['scope_units'];
                } else {
                    $decoded = json_decode($_POST['scope_units'], true);
                    if (is_array($decoded)) {
                        $scopeUnits = $decoded;
                    }
                }
            }
            $hrUnitId = $_POST['hr_unit_id'] ?? null;
            $hrUnitName = $_POST['hr_unit_name'] ?? null;
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Missing employee_id']);
                exit;
            }
            
            $employeeId = normalizeEmployeeId($employeeId);
            $oldState = getCurrentAssignmentState($conn, $employeeId);
            
            debugLog("bulk_update: Processing coordinator types", [
                'employee_id' => $employeeId,
                'types_requested' => $types,
                'types_count' => count($types),
                'scope_mode' => $scopeMode,
                'raw_post_types' => $_POST['types'] ?? 'NOT SET'
            ]);
            
            // Extra debug: log raw POST data
            error_log("bulk_update RAW POST: " . print_r($_POST, true));
            
            // Get currently active types
            $currentTypes = [];
            $stmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'");
            $stmt->bind_param("s", $employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $currentTypes[] = $row['coordinator_type'];
            }
            $stmt->close();
            
            // Determine types to add and remove
            $typesToRemove = array_diff($currentTypes, $types);
            $typesAdded = [];
            $typesUpdated = [];
            $typesRemoved = [];
            
            // Remove types no longer selected
            foreach ($typesToRemove as $type) {
                $stmt = $conn->prepare("UPDATE coordinator_assignments SET status = 'inactive', updated_at = CURRENT_TIMESTAMP WHERE employee_id = ? AND coordinator_type = ?");
                $stmt->bind_param("ss", $employeeId, $type);
                $stmt->execute();
                if ($stmt->affected_rows > 0) {
                    $typesRemoved[] = $type;
                }
                $stmt->close();
            }
            
            // Add/update ALL selected types (creates one row per type in coordinator_assignments)
            foreach ($types as $type) {
                // Check if assignment already exists for this employee + type combination
                $checkStmt = $conn->prepare("SELECT id, status FROM coordinator_assignments WHERE employee_id = ? AND coordinator_type = ?");
                $checkStmt->bind_param("ss", $employeeId, $type);
                $checkStmt->execute();
                $existing = $checkStmt->get_result()->fetch_assoc();
                $checkStmt->close();
                
                if ($existing) {
                    // Update existing assignment
                    $updateStmt = $conn->prepare("
                        UPDATE coordinator_assignments 
                        SET status = 'active', scope_mode = ?, hr_unit_id = ?, hr_unit_name = ?, 
                            assigned_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ");
                    $updateStmt->bind_param("sssii", $scopeMode, $hrUnitId, $hrUnitName, $userId, $existing['id']);
                    $updateStmt->execute();
                    $updateStmt->close();
                    $typesUpdated[] = $type;
                } else {
                    // Insert NEW assignment row for this type
                    $insertStmt = $conn->prepare("
                        INSERT INTO coordinator_assignments 
                        (employee_id, coordinator_type, scope_mode, hr_unit_id, hr_unit_name, assigned_by, status)
                        VALUES (?, ?, ?, ?, ?, ?, 'active')
                    ");
                    $insertStmt->bind_param("sssssi", $employeeId, $type, $scopeMode, $hrUnitId, $hrUnitName, $userId);
                    $insertStmt->execute();
                    $insertStmt->close();
                    $typesAdded[] = $type;
                }
            }
            
            // Handle specific_units scope
            // First, validate that requested units are not already assigned to OTHER coordinators
            $conflictingUnits = [];
            if ($scopeMode === 'specific_units' && !empty($scopeUnits)) {
                // Check each unit for conflicts
                $checkConflictStmt = $conn->prepare("
                    SELECT cs.unit_id, cs.unit_name, cs.employee_id, src.full_name as coordinator_name
                    FROM coordinator_scopes cs
                    LEFT JOIN synced_research_coordinators src ON cs.employee_id = src.employee_id
                    WHERE cs.unit_id = ? AND cs.employee_id != ?
                ");
                
                foreach ($scopeUnits as $unit) {
                    $unitId = $unit['id'] ?? '';
                    if (!empty($unitId)) {
                        $checkConflictStmt->bind_param("ss", $unitId, $employeeId);
                        $checkConflictStmt->execute();
                        $conflictResult = $checkConflictStmt->get_result();
                        if ($conflict = $conflictResult->fetch_assoc()) {
                            $conflictingUnits[] = [
                                'unit_name' => $conflict['unit_name'] ?: ($unit['name'] ?? $unitId),
                                'assigned_to' => $conflict['coordinator_name'] ?: $conflict['employee_id']
                            ];
                        }
                    }
                }
                $checkConflictStmt->close();
                
                // If there are conflicts, return error with details
                if (!empty($conflictingUnits)) {
                    $conflictMessages = array_map(function($c) {
                        return '"' . $c['unit_name'] . '" (assigned to ' . $c['assigned_to'] . ')';
                    }, $conflictingUnits);
                    
                    echo json_encode([
                        'success' => false,
                        'error' => 'The following unit(s) are already assigned to other coordinators: ' . implode(', ', $conflictMessages),
                        'conflicts' => $conflictingUnits
                    ]);
                    exit;
                }
            }
            
            // Clear existing scopes for this employee
            $deleteStmt = $conn->prepare("DELETE FROM coordinator_scopes WHERE employee_id = ?");
            $deleteStmt->bind_param("s", $employeeId);
            $deleteStmt->execute();
            $deleteStmt->close();
            
            if ($scopeMode === 'specific_units' && !empty($scopeUnits)) {
                $insertScopeStmt = $conn->prepare("
                    INSERT INTO coordinator_scopes (employee_id, unit_id, unit_name, unit_type, assigned_by)
                    VALUES (?, ?, ?, ?, ?)
                ");
                foreach ($scopeUnits as $unit) {
                    $unitId = $unit['id'] ?? '';
                    $unitName = $unit['name'] ?? '';
                    $unitType = $unit['type'] ?? '';
                    if (!empty($unitId)) {
                        $insertScopeStmt->bind_param("ssssi", $employeeId, $unitId, $unitName, $unitType, $userId);
                        $insertScopeStmt->execute();
                    }
                }
                $insertScopeStmt->close();
            }
            
            // Update user's coordinator_type (stores highest priority type for backwards compatibility)
            updateUserCoordinatorType($conn, $employeeId);
            
            // Verify what was actually saved to coordinator_assignments
            $savedTypes = [];
            $verifyStmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id = ? AND status = 'active' ORDER BY coordinator_type");
            $verifyStmt->bind_param("s", $employeeId);
            $verifyStmt->execute();
            $verifyResult = $verifyStmt->get_result();
            while ($row = $verifyResult->fetch_assoc()) {
                $savedTypes[] = $row['coordinator_type'];
            }
            $verifyStmt->close();
            
            // Log the action
            $newState = getCurrentAssignmentState($conn, $employeeId);
            logAssignmentAction($conn, $employeeId, 'bulk_update', [
                'old_value' => $oldState,
                'new_value' => $newState
            ]);
            
            debugLog("bulk_update: Completed", [
                'employee_id' => $employeeId,
                'types_added' => $typesAdded,
                'types_updated' => $typesUpdated,
                'types_removed' => $typesRemoved,
                'final_saved_types' => $savedTypes
            ]);
            
            // Return detailed response
            $typeCount = count($savedTypes);
            $message = $typeCount === 0 
                ? 'All coordinator assignments removed'
                : ($typeCount === 1 
                    ? ucfirst($savedTypes[0]) . ' coordinator assigned successfully'
                    : $typeCount . ' coordinator types assigned: ' . implode(', ', array_map('ucfirst', $savedTypes)));
            
            echo json_encode([
                'success' => true, 
                'message' => $message,
                'data' => [
                    'employee_id' => $employeeId,
                    'saved_types' => $savedTypes,
                    'types_added' => $typesAdded,
                    'types_updated' => $typesUpdated,
                    'types_removed' => $typesRemoved,
                    'scope_mode' => $scopeMode
                ]
            ]);
            break;
            
        // ====================================================================
        // GET SCOPES (Fetch current assignment state)
        // ====================================================================
        case 'get_scopes':
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Missing employee_id']);
                exit;
            }
            
            $employeeId = normalizeEmployeeId($employeeId);
            
            // Get assignments
            $assignments = [];
            $stmt = $conn->prepare("
                SELECT coordinator_type, scope_mode, hr_unit_id, hr_unit_name 
                FROM coordinator_assignments 
                WHERE employee_id = ? AND status = 'active'
            ");
            $stmt->bind_param("s", $employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $assignments[$row['coordinator_type']] = [
                    'scope_mode' => $row['scope_mode'] ?? 'own_unit',
                    'hr_unit_id' => $row['hr_unit_id'],
                    'hr_unit_name' => $row['hr_unit_name']
                ];
            }
            $stmt->close();
            
            // Get specific unit scopes
            $scopes = [];
            $stmt = $conn->prepare("
                SELECT unit_id, unit_name, unit_type 
                FROM coordinator_scopes 
                WHERE employee_id = ?
            ");
            $stmt->bind_param("s", $employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $scopes[] = [
                    'id' => $row['unit_id'],
                    'name' => $row['unit_name'],
                    'type' => $row['unit_type']
                ];
            }
            $stmt->close();
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'assignments' => $assignments,
                    'scopes' => $scopes
                ]
            ]);
            break;
            
        // ====================================================================
        // GET UNITS (Fetch available units from HR per UNITS_SYNC_GUIDE.md)
        // API: GET /api/units?sector_id=X&unit_type=X&search=X
        // Response: { data: [{ id, name, code, unit_type, sector, parent_unit_id }] }
        // 
        // IMPORTANT: Units already assigned to OTHER coordinators are excluded
        // to prevent multiple coordinators from managing the same unit.
        // ====================================================================
        case 'get_units':
            $unitType = $_GET['unit_type'] ?? null; // college, program, office, institute, center
            $sectorId = $_GET['sector_id'] ?? null;
            $search = $_GET['search'] ?? null;
            $source = $_GET['source'] ?? 'auto'; // auto, hr, local
            $forEmployeeId = $_GET['for_employee_id'] ?? null; // Current coordinator being edited
            
            $units = [];
            $hrError = null;
            
            // Get units already assigned to OTHER coordinators (to exclude them)
            $assignedUnitIds = [];
            $assignedUnitDetails = []; // Track which coordinator has each unit
            try {
                $query = "SELECT cs.unit_id, cs.unit_name, cs.employee_id, src.full_name as coordinator_name
                          FROM coordinator_scopes cs
                          LEFT JOIN synced_research_coordinators src ON cs.employee_id = src.employee_id";
                
                // If editing a specific coordinator, exclude their own units from the "taken" list
                if (!empty($forEmployeeId)) {
                    $forEmployeeId = normalizeEmployeeId($forEmployeeId);
                    $query .= " WHERE cs.employee_id != ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("s", $forEmployeeId);
                } else {
                    $stmt = $conn->prepare($query);
                }
                
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $assignedUnitIds[] = $row['unit_id'];
                    $assignedUnitDetails[$row['unit_id']] = [
                        'employee_id' => $row['employee_id'],
                        'coordinator_name' => $row['coordinator_name'] ?? 'Unknown Coordinator',
                        'unit_name' => $row['unit_name']
                    ];
                }
                $stmt->close();
            } catch (Exception $e) {
                // Log but don't fail - continue without filtering
                errorLog("Error fetching assigned units", ['error' => $e->getMessage()]);
            }
            
            // Try HR API first (unless explicitly requesting local)
            if ($source !== 'local') {
                try {
                    // Check if HRSystemAPI class exists
                    if (!class_exists('HRSystemAPI')) {
                        $hrError = 'HR API module not loaded';
                    }
                    // Check if HR integration is available
                    elseif (!function_exists('isHRIntegrationAvailable') || !isHRIntegrationAvailable()) {
                        $hrError = 'HR integration not configured - using local data';
                    }
                    else {
                        // Try to create HR API instance - this may throw if no token available
                        try {
                            $hrAPI = new HRSystemAPI($conn, $userId);
                            
                            // Call getUnits with parameters per UNITS_SYNC_GUIDE
                            $result = $hrAPI->getUnits($sectorId, $unitType, $search);
                            
                            // Map response per UNITS_SYNC_GUIDE response format
                            if (!empty($result['data'])) {
                                $units = array_map(function($unit) {
                                    return [
                                        'id' => (string)($unit['id'] ?? ''),
                                        'name' => $unit['name'] ?? '',
                                        'code' => $unit['code'] ?? '',
                                        'type' => $unit['unit_type'] ?? '',
                                        'description' => $unit['description'] ?? '',
                                        'sector_id' => $unit['sector']['id'] ?? null,
                                        'sector_name' => $unit['sector']['name'] ?? '',
                                        'parent_unit_id' => $unit['parent_unit_id'] ?? null
                                    ];
                                }, $result['data']);
                            }
                        } catch (Exception $hrEx) {
                            // HR API failed (likely no valid token) - will use local fallback
                            $hrError = $hrEx->getMessage();
                        }
                    }
                } catch (Exception $e) {
                    $hrError = $e->getMessage();
                }
            }
            
            // Fallback: Load unique units from local database
            if (empty($units) && ($source === 'local' || $source === 'auto')) {
                try {
                    $localUnits = [];
                    
                    // Get units from synced_research_coordinators
                    $checkUnitId = $conn->query("SHOW COLUMNS FROM synced_research_coordinators LIKE 'unit_id'");
                    $hasUnitId = $checkUnitId && $checkUnitId->num_rows > 0;
                    
                    $selectCols = $hasUnitId 
                        ? "unit_name, unit_type, unit_id, sector_name" 
                        : "unit_name, unit_type, sector_name";
                    
                    $result = $conn->query("
                        SELECT DISTINCT {$selectCols}
                        FROM synced_research_coordinators 
                        WHERE unit_name IS NOT NULL AND unit_name != ''
                        ORDER BY unit_name
                    ");
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $unitId = ($hasUnitId && !empty($row['unit_id'])) 
                                ? $row['unit_id'] 
                                : 'local_' . md5($row['unit_name']);
                            $localUnits[$unitId] = [
                                'id' => $unitId,
                                'name' => $row['unit_name'],
                                'code' => '',
                                'type' => $row['unit_type'] ?: 'unit',
                                'sector_name' => $row['sector_name'] ?? ''
                            ];
                        }
                    }
                    
                    // Get units from faculty_researchers
                    $result = $conn->query("
                        SELECT DISTINCT home_unit, department 
                        FROM faculty_researchers 
                        WHERE (home_unit IS NOT NULL AND home_unit != '') 
                           OR (department IS NOT NULL AND department != '')
                    ");
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            if (!empty($row['home_unit'])) {
                                $unitId = 'local_' . md5($row['home_unit']);
                                if (!isset($localUnits[$unitId])) {
                                    $localUnits[$unitId] = [
                                        'id' => $unitId,
                                        'name' => $row['home_unit'],
                                        'code' => '',
                                        'type' => 'college'
                                    ];
                                }
                            }
                            if (!empty($row['department'])) {
                                $unitId = 'local_' . md5($row['department']);
                                if (!isset($localUnits[$unitId])) {
                                    $localUnits[$unitId] = [
                                        'id' => $unitId,
                                        'name' => $row['department'],
                                        'code' => '',
                                        'type' => 'program'
                                    ];
                                }
                            }
                        }
                    }
                    
                    // Get units from student_researchers
                    $result = $conn->query("
                        SELECT DISTINCT department 
                        FROM student_researchers 
                        WHERE department IS NOT NULL AND department != ''
                    ");
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $unitId = 'local_' . md5($row['department']);
                            if (!isset($localUnits[$unitId])) {
                                $localUnits[$unitId] = [
                                    'id' => $unitId,
                                    'name' => $row['department'],
                                    'code' => '',
                                    'type' => 'program'
                                ];
                            }
                        }
                    }
                    
                    $units = array_values($localUnits);
                    
                    // Apply search filter
                    if (!empty($search)) {
                        $searchLower = strtolower($search);
                        $units = array_values(array_filter($units, function($u) use ($searchLower) {
                            return strpos(strtolower($u['name']), $searchLower) !== false ||
                                   strpos(strtolower($u['code'] ?? ''), $searchLower) !== false;
                        }));
                    }
                    
                    // Apply type filter
                    if (!empty($unitType)) {
                        $units = array_values(array_filter($units, function($u) use ($unitType) {
                            return strcasecmp($u['type'], $unitType) === 0;
                        }));
                    }
                    
                } catch (Exception $e) {
                    // Silently ignore local errors
                }
            }
            
            // Filter out units already assigned to OTHER coordinators
            if (!empty($assignedUnitIds)) {
                $originalCount = count($units);
                $units = array_values(array_filter($units, function($unit) use ($assignedUnitIds) {
                    return !in_array($unit['id'], $assignedUnitIds);
                }));
                $filteredCount = $originalCount - count($units);
                
                debugLog("Units filtered", [
                    'original_count' => $originalCount,
                    'filtered_out' => $filteredCount,
                    'remaining' => count($units),
                    'for_employee' => $forEmployeeId ?? 'none'
                ]);
            }
            
            // Sort by name
            usort($units, function($a, $b) {
                return strcasecmp($a['name'], $b['name']);
            });
            
            echo json_encode([
                'success' => true,
                'data' => $units,
                'count' => count($units),
                'source' => empty($hrError) ? 'hr' : 'local',
                'hr_error' => $hrError,
                'excluded_units' => count($assignedUnitIds),
                'excluded_details' => $assignedUnitDetails // Include details for UI feedback
            ]);
            break;
            
        // ====================================================================
        // GET SECTORS (Fetch sectors from HR per UNITS_SYNC_GUIDE.md)
        // API: GET /api/sectors
        // Response: { data: [{ id, name, code, description, units_count }] }
        // ====================================================================
        case 'get_sectors':
            $search = $_GET['search'] ?? null;
            
            try {
                if (function_exists('isHRIntegrationAvailable') && isHRIntegrationAvailable()) {
                    $hrAPI = new HRSystemAPI($conn, $userId);
                    $result = $hrAPI->getSectors($search);
                    
                    $sectors = array_map(function($sector) {
                        return [
                            'id' => (string)($sector['id'] ?? ''),
                            'name' => $sector['name'] ?? '',
                            'code' => $sector['code'] ?? '',
                            'description' => $sector['description'] ?? '',
                            'units_count' => $sector['units_count'] ?? 0
                        ];
                    }, $result['data'] ?? []);
                    
                    echo json_encode([
                        'success' => true,
                        'data' => $sectors,
                        'count' => count($sectors)
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'error' => 'HR integration not configured'
                    ]);
                }
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false,
                    'error' => 'Failed to fetch sectors: ' . $e->getMessage()
                ]);
            }
            break;
            
        // ====================================================================
        // GET ASSIGNMENT LOGS (Audit trail)
        // ====================================================================
        case 'get_logs':
            $limit = min((int)($_GET['limit'] ?? 50), 100);
            $offset = (int)($_GET['offset'] ?? 0);
            
            $query = "
                SELECT l.*, u.username as performed_by_username
                FROM coordinator_assignment_logs l
                LEFT JOIN users u ON l.performed_by = u.id
            ";
            $params = [];
            $types = "";
            
            if (!empty($employeeId)) {
                $query .= " WHERE l.employee_id = ?";
                $params[] = normalizeEmployeeId($employeeId);
                $types .= "s";
            }
            
            $query .= " ORDER BY l.performed_at DESC LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            $types .= "ii";
            
            $stmt = $conn->prepare($query);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            
            $logs = [];
            while ($row = $result->fetch_assoc()) {
                $row['old_value'] = $row['old_value'] ? json_decode($row['old_value'], true) : null;
                $row['new_value'] = $row['new_value'] ? json_decode($row['new_value'], true) : null;
                $logs[] = $row;
            }
            $stmt->close();
            
            echo json_encode([
                'success' => true,
                'data' => $logs
            ]);
            break;
            
        // ====================================================================
        // LEGACY ACTIONS (Backward compatibility)
        // ====================================================================
        case 'assign':
            // Redirect to assign_type for backward compatibility
            $_POST['action'] = 'assign_type';
            $_POST['scope_mode'] = 'own_unit';
            include __FILE__;
            break;
            
        case 'remove':
            // Redirect to remove_type for backward compatibility
            $_POST['action'] = 'remove_type';
            include __FILE__;
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action: ' . $action]);
    }
    
} catch (Exception $e) {
    errorLog("Coordinator Assignment Error", ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
