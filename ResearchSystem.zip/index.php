<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eastern Samar State University - Research Management System</title>
  <link rel="stylesheet" href="indexstyle.css">
</head>
<body>
  <header>
    <div class="logo">
      <img src="essu.png" alt="ESSU Logo">
      <h3>Eastern Samar State University</h3>
    </div>
    <nav>
      <a href="#home">Home</a>
      <a href="#about">About</a>
      <a href="#services">Services</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <section id="home">
    <div class="slideshow-container">
      <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1519452635265-7b1fbfd1e4e0?w=1920')"></div>
    </div>
    <div class="content-wrapper">
      <h1>Welcome to the Research Management System</h1>
      <p>Empowering academic excellence through innovative research tracking and management solutions</p>
      <a href="research.php" class="btn">Access Research Portal</a>
    </div>
    <div class="slide-indicators">
      <span class="indicator active" data-slide="0"></span>
      <span class="indicator" data-slide="1"></span>
      <span class="indicator" data-slide="2"></span>
    </div>
  </section>

  <section id="about">
    <div class="slideshow-container">
      <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1543269865-cbf427effbad?w=1920')"></div>
    </div>
    <div class="content-wrapper">
      <h2>About Our System</h2>
      <p>The Research Management System is designed to streamline the entire research lifecycle at Eastern Samar State University. Our platform provides comprehensive tools for research departments to efficiently manage, track, and monitor research outputs from both student researchers and faculty members. With an intuitive interface and powerful features, we make research administration effortless and productive.</p>
    </div>
    <div class="slide-indicators">
      <span class="indicator active" data-slide="0"></span>
      <span class="indicator" data-slide="1"></span>
      <span class="indicator" data-slide="2"></span>
    </div>
  </section>

  <section id="services">
    <div class="slideshow-container">
      <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1551434678-e076c223a692?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1552664730-d307ca884978?w=1920')"></div>
      <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=1920')"></div>
    </div>
    <div class="content-wrapper">
      <h2>Our Services</h2>
      <p>We provide comprehensive research management solutions to support academic excellence</p>
      <div class="feature-grid">
        <div class="feature-card">
          <h3>Track Research</h3>
          <p>Monitor research outputs presented and published by students and faculty</p>
        </div>
        <div class="feature-card">
          <h3>Manage Data</h3>
          <p>Organize and maintain comprehensive research databases efficiently</p>
        </div>
        <div class="feature-card">
          <h3>Generate Reports</h3>
          <p>Create detailed analytics and reports on research productivity</p>
        </div>
      </div>
    </div>
    <div class="slide-indicators">
      <span class="indicator active" data-slide="0"></span>
      <span class="indicator" data-slide="1"></span>
      <span class="indicator" data-slide="2"></span>
    </div>
  </section>

  <footer>
    &copy; <?php echo date("Y"); ?> Eastern Samar State University. All Rights Reserved.
  </footer>

  <script>
    // Slideshow functionality for each section
    function initSlideshow(sectionId) {
      const section = document.querySelector(sectionId);
      const slides = section.querySelectorAll('.slide');
      const indicators = section.querySelectorAll('.indicator');
      let currentSlide = 0;

      function showSlide(index) {
        slides.forEach(slide => slide.classList.remove('active'));
        indicators.forEach(ind => ind.classList.remove('active'));
        
        slides[index].classList.add('active');
        indicators[index].classList.add('active');
      }

      function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
      }

      // Auto advance slides
      setInterval(nextSlide, 5000);

      // Click indicators to change slides
      indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
          currentSlide = index;
          showSlide(currentSlide);
        });
      });
    }

    // Initialize slideshows for each section
    initSlideshow('#home');
    initSlideshow('#about');
    initSlideshow('#services');

    // Smooth scroll with offset for fixed header
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          window.scrollTo({
            top: target.offsetTop - 80,
            behavior: 'smooth'
          });
        }
      });
    });
  </script>
</body>
</html>
