<?php
/**
 * Login Page
 * 
 * Supports OAuth prompt parameter for handling access denied scenarios.
 * When a user is denied access via SSO, they can use "Sign in with a different account"
 * which adds prompt=login to force re-authentication.
 * 
 * @see OAUTH_PROMPT_GUIDE.md for detailed documentation
 */

require 'db.php';
require 'config.php';
session_start();
$ssoConfig = getOAuthConfig($conn);
$ssoEnabled = !empty($ssoConfig['enabled']) && !empty($ssoConfig['client_id']) && !empty($ssoConfig['client_secret']) && !empty($ssoConfig['provider_url']) && !empty($ssoConfig['redirect_uri']);
$error = "";
$errorType = "";
$isAccessDenied = false;

if (isset($_GET['error'])) {
    $error = $_GET['error'];
    
    // Detect access denied errors to show appropriate UI with prompt=login option
    // These errors indicate the user should try signing in with a different account
    $accessDeniedPatterns = [
        'access denied',
        'access_denied',
        'not authorized',
        'unauthorized',
        'restricted to',
        'position or department does not have access',
        'unit information not available'
    ];
    
    $errorLower = strtolower($error);
    foreach ($accessDeniedPatterns as $pattern) {
        if (strpos($errorLower, $pattern) !== false) {
            $isAccessDenied = true;
            $errorType = 'access_denied';
            // Store in session so subsequent SSO attempts use prompt=login
            $_SESSION['sso_access_denied'] = true;
            break;
        }
    }
}

// Check if session has access denied flag (for cases where user navigates back)
if (!$isAccessDenied && isset($_SESSION['sso_access_denied']) && $_SESSION['sso_access_denied'] === true) {
    $isAccessDenied = true;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    // Check which role column exists (user_role is preferred, role is legacy)
    $checkRoleColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'");
    $hasUserRoleColumn = $checkRoleColumn->num_rows > 0;
    $roleColumn = $hasUserRoleColumn ? 'user_role' : 'role';
    
    // Check if fullname column exists
    $checkFullnameColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'fullname'");
    $hasFullnameColumn = $checkFullnameColumn->num_rows > 0;
    $fullnameSelect = $hasFullnameColumn ? ', fullname' : '';
    
    $stmt = $conn->prepare("SELECT id, password, $roleColumn, coordinator_type$fullnameSelect FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    if ($user) {
        if (password_verify($password, $user['password'])) {
            // Check if user is a coordinator whose position has changed in HR
            if ($user[$roleColumn] === 'coordinator' && !empty($user['coordinator_type'])) {
                // Check employee_id and hr_status
                $checkHrStatus = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'");
                if ($checkHrStatus->num_rows > 0) {
                    $empIdStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
                    $empIdStmt->bind_param("i", $user['id']);
                    $empIdStmt->execute();
                    $empIdResult = $empIdStmt->get_result()->fetch_assoc();
                    $empIdStmt->close();
                    
                    if (!empty($empIdResult['employee_id'])) {
                        $hrStatusStmt = $conn->prepare("SELECT hr_status FROM synced_research_coordinators WHERE employee_id = ?");
                        $hrStatusStmt->bind_param("s", $empIdResult['employee_id']);
                        $hrStatusStmt->execute();
                        $hrStatusResult = $hrStatusStmt->get_result()->fetch_assoc();
                        $hrStatusStmt->close();
                        
                        if ($hrStatusResult && $hrStatusResult['hr_status'] === 'position_changed') {
                            $error = "Your coordinator access has been deactivated because you are no longer designated as Research Coordinator in HR. Please contact the administrator.";
                            goto login_error;
                        }
                    }
                }
            }
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['fullname'] = $user['fullname'] ?? $username;
            $_SESSION['user_role'] = $user[$roleColumn];
            $_SESSION['coordinator_type'] = $user['coordinator_type'];
            $_SESSION['employee_id'] = $user['employee_id'] ?? null;
            
            // Load ALL coordinator types from coordinator_assignments table
            $_SESSION['coordinator_types'] = [];
            if (!empty($user['employee_id']) && $user[$roleColumn] === 'coordinator') {
                $allTypesStmt = $conn->prepare("
                    SELECT coordinator_type 
                    FROM coordinator_assignments 
                    WHERE employee_id = ? AND status = 'active'
                ");
                $allTypesStmt->bind_param("s", $user['employee_id']);
                $allTypesStmt->execute();
                $allTypesResult = $allTypesStmt->get_result();
                while ($typeRow = $allTypesResult->fetch_assoc()) {
                    $_SESSION['coordinator_types'][] = $typeRow['coordinator_type'];
                }
                $allTypesStmt->close();
                
                // Set primary coordinator_type to highest priority if we found types
                if (!empty($_SESSION['coordinator_types'])) {
                    if (in_array('faculty', $_SESSION['coordinator_types'])) {
                        $_SESSION['coordinator_type'] = 'faculty';
                    } elseif (in_array('student', $_SESSION['coordinator_types'])) {
                        $_SESSION['coordinator_type'] = 'student';
                    } elseif (in_array('personnel', $_SESSION['coordinator_types'])) {
                        $_SESSION['coordinator_type'] = 'personnel';
                    }
                }
            }
            
            // Check if user is an imported researcher and redirect to their profile
            $checkImported = $conn->query("SELECT imported FROM users WHERE id = " . $user['id'] . " LIMIT 1");
            if ($checkImported && $checkImported->num_rows > 0) {
                $userData = $checkImported->fetch_assoc();
                if (!empty($userData['imported']) && $userData['imported'] == 1) {
                    // User is an imported researcher - find their faculty_researcher record
                    $facultyStmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
                    $facultyStmt->bind_param("i", $user['id']);
                    $facultyStmt->execute();
                    $facultyResult = $facultyStmt->get_result();
                    
                    if ($facultyResult && $facultyResult->num_rows > 0) {
                        $facultyData = $facultyResult->fetch_assoc();
                        $facultyId = $facultyData['id'];
                        $facultyStmt->close();
                        
                        // Redirect to researcher dashboard
                        header("Location: researcher_dashboard.php");
                        exit;
                    }
                    $facultyStmt->close();
                }
            }
            
            header("Location: index.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
    login_error:
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMS - Login</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="logo-container">
            <img src="essu.png" alt="University Logo" class="logo">
            <div class="university-name">Eastern Samar State University</div>
            <div class="system-subtitle">Research Management System</div>
        </div>

        <div class="login-container">
            <div class="form-title">Welcome Back</div>
            <div class="form-subtitle">Sign in to continue to your account</div>
            
            <?php if ($error): ?>
                <?php if ($isAccessDenied): ?>
                    <div class="error-message access-denied-error">
                        <span class="error-icon">🚫</span>
                        <span class="error-title">Access Denied</span>
                        <div class="error-details"><?= htmlspecialchars($error) ?></div>
                    </div>
                <?php else: ?>
                    <div class="error-message">
                        <strong>⚠️ <?= htmlspecialchars($error) ?></strong>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <form method="POST">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required autofocus>
                </div>
                
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <div class="form-buttons">
                    <button type="submit" class="btn btn-login" style="width: 100%;">Login</button>
                </div>
            </form>

            <!-- SSO Login Option (from Admin → SSO Settings or config) -->
            <?php if ($ssoEnabled): ?>
            <div class="sso-section">
                <div class="divider">
                    <span>OR</span>
                </div>
                
                <?php if ($isAccessDenied): ?>
                    <!-- Access denied: Show "Sign in with different account" button with prompt=login -->
                    <div class="sso-buttons">
                        <a href="oauth_redirect.php?prompt=login" class="btn-sso btn-sso-primary">
                            🔄 Sign in with Different Account
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Normal SSO login (no prompt parameter) -->
                    <a href="oauth_redirect.php" class="btn-sso">
                        🔐 Sign in with HR System (SSO)
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="footer-text">
                © <?php echo date("Y"); ?> ESSU. All rights reserved.
            </div>
        </div>
    </div>
</body>
</html>
