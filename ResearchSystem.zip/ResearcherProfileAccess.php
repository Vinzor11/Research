<?php
/**
 * ResearcherProfileAccess.php
 * 
 * Centralized access control for Researcher Profile viewing in the RMIS.
 * Implements the OOM (Office of Management) model for profile visibility.
 * 
 * POLICY STATEMENT:
 * "Researcher profiles may be viewed by authorized coordinators within their 
 * assigned scope and by Research Office administrators institution-wide, 
 * strictly for research management and RMIS reporting purposes."
 * 
 * PROFILE DEFINITION:
 * A Researcher Profile is a research-focused view including:
 * - Name, category (Faculty/Student/Non-Academic), Unit/College/Office
 * - Research projects, outputs, publications, awards
 * - RMIS-related records (Forms D, D1, E mappings)
 * 
 * PROFILE EXCLUDES (HR-only data):
 * - Salary and compensation
 * - Personal address and private contact details
 * - HR disciplinary or employment-only records
 * 
 * ACCESS RULES:
 * - Coordinator: Scoped view (unit + coordinator type match) - READ ONLY
 * - Admin (RDO): Institution-wide view - READ ONLY for HR data
 * - Researcher: Own profile only
 */

class ResearcherProfileAccess {
    private $conn;
    private $userId;
    private $userRole;
    private $employeeId;
    private $coordinatorData = null;
    private $auditEnabled = true;
    
    // Researcher categories
    const CATEGORY_FACULTY = 'faculty';
    const CATEGORY_STUDENT = 'student';
    const CATEGORY_PERSONNEL = 'personnel';
    
    // Access levels
    const ACCESS_NONE = 'none';
    const ACCESS_OWN_PROFILE = 'own_profile';
    const ACCESS_SCOPED = 'scoped';
    const ACCESS_INSTITUTION_WIDE = 'institution_wide';
    
    // Error codes
    const ERROR_NOT_AUTHENTICATED = 'NOT_AUTHENTICATED';
    const ERROR_PROFILE_NOT_FOUND = 'PROFILE_NOT_FOUND';
    const ERROR_INSUFFICIENT_SCOPE = 'INSUFFICIENT_SCOPE';
    const ERROR_CATEGORY_MISMATCH = 'CATEGORY_MISMATCH';
    const ERROR_UNIT_OUT_OF_SCOPE = 'UNIT_OUT_OF_SCOPE';
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        
        $this->loadCoordinatorData();
    }
    
    /**
     * Load coordinator assignments and scope data
     */
    private function loadCoordinatorData() {
        if (!$this->userId || $this->userRole !== 'coordinator') {
            return;
        }
        
        // Get employee_id if not in session
        if (!$this->employeeId) {
            $stmt = $this->conn->prepare("SELECT employee_id FROM users WHERE id = ?");
            $stmt->bind_param("i", $this->userId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $this->employeeId = $row['employee_id'];
            }
            $stmt->close();
        }
        
        if (!$this->employeeId) {
            return;
        }
        
        $this->coordinatorData = [
            'types' => [],
            'scope_mode' => 'own_unit',
            'hr_unit_id' => null,
            'hr_unit_name' => null,
            'allowed_units' => []
        ];
        
        // Get coordinator types and scope info
        $stmt = $this->conn->prepare("
            SELECT coordinator_type, scope_mode, hr_unit_id, hr_unit_name 
            FROM coordinator_assignments 
            WHERE employee_id = ? AND status = 'active'
        ");
        $stmt->bind_param("s", $this->employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $this->coordinatorData['types'][] = $row['coordinator_type'];
            // Take scope info from first assignment with scope data
            if (!empty($row['scope_mode']) && empty($this->coordinatorData['hr_unit_id'])) {
                $this->coordinatorData['scope_mode'] = $row['scope_mode'];
                $this->coordinatorData['hr_unit_id'] = $row['hr_unit_id'];
                $this->coordinatorData['hr_unit_name'] = $row['hr_unit_name'];
            }
        }
        $stmt->close();
        
        // Load specific units if applicable
        if ($this->coordinatorData['scope_mode'] === 'specific_units') {
            $stmt = $this->conn->prepare("
                SELECT unit_id, unit_name, unit_type 
                FROM coordinator_scopes 
                WHERE employee_id = ?
            ");
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $this->coordinatorData['allowed_units'][] = [
                    'id' => $row['unit_id'],
                    'name' => $row['unit_name'],
                    'type' => $row['unit_type']
                ];
            }
            $stmt->close();
        }
    }
    
    /**
     * Check if current user can view a researcher profile
     * 
     * @param string $category - 'faculty', 'student', or 'personnel'
     * @param int $researcherId - The researcher's ID in their respective table
     * @return array ['allowed' => bool, 'access_level' => string, 'error_code' => string|null, 'message' => string]
     */
    public function canViewProfile($category, $researcherId) {
        // Check authentication
        if (!$this->userId) {
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_NOT_AUTHENTICATED, 
                'Authentication required to view researcher profiles.');
        }
        
        // Get researcher data
        $researcher = $this->getResearcherData($category, $researcherId);
        if (!$researcher) {
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_PROFILE_NOT_FOUND,
                'Researcher profile not found.');
        }
        
        // ===== ACCESS LOGIC =====
        
        // 1. Admin (Research Office Admin) - Institution-wide view
        if ($this->userRole === 'admin') {
            return $this->buildResult(true, self::ACCESS_INSTITUTION_WIDE, null,
                'Access granted: Research Office Administrator');
        }
        
        // 2. Researcher viewing own profile
        if ($this->userRole === 'researcher') {
            if ($this->isOwnProfile($category, $researcher)) {
                return $this->buildResult(true, self::ACCESS_OWN_PROFILE, null,
                    'Access granted: Viewing own profile');
            }
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_INSUFFICIENT_SCOPE,
                'Researchers may only view their own profile.');
        }
        
        // 3. Coordinator - Scoped view
        if ($this->userRole === 'coordinator') {
            return $this->checkCoordinatorAccess($category, $researcher);
        }
        
        // Default deny
        return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_INSUFFICIENT_SCOPE,
            'Your role does not have permission to view researcher profiles.');
    }
    
    /**
     * Check coordinator access with scope enforcement
     */
    private function checkCoordinatorAccess($category, $researcher) {
        if (!$this->coordinatorData) {
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_INSUFFICIENT_SCOPE,
                'No coordinator assignment found.');
        }
        
        // Check 1: Coordinator type must match researcher category
        if (!in_array($category, $this->coordinatorData['types'])) {
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_CATEGORY_MISMATCH,
                "Your coordinator type does not include {$category} researchers.");
        }
        
        // Check 2: Researcher's unit must be in coordinator's scope
        if (!$this->isUnitInScope($researcher)) {
            return $this->buildResult(false, self::ACCESS_NONE, self::ERROR_UNIT_OUT_OF_SCOPE,
                'This researcher is outside your assigned unit scope.');
        }
        
        return $this->buildResult(true, self::ACCESS_SCOPED, null,
            'Access granted: Coordinator with matching scope');
    }
    
    /**
     * Check if researcher's unit is within coordinator's scope
     */
    private function isUnitInScope($researcher) {
        $scopeMode = $this->coordinatorData['scope_mode'];
        
        switch ($scopeMode) {
            case 'all_units':
                return true;
                
            case 'own_unit':
                $hrUnitName = $this->coordinatorData['hr_unit_name'];
                if (!$hrUnitName) {
                    // Fallback to created_by check for legacy data
                    return isset($researcher['created_by']) && $researcher['created_by'] == $this->userId;
                }
                // Check if researcher's unit matches coordinator's unit
                $researcherUnit = $researcher['home_unit'] ?? $researcher['department'] ?? '';
                return $this->unitsMatch($researcherUnit, $hrUnitName);
                
            case 'specific_units':
                $researcherUnit = $researcher['home_unit'] ?? $researcher['department'] ?? '';
                foreach ($this->coordinatorData['allowed_units'] as $allowedUnit) {
                    if ($this->unitsMatch($researcherUnit, $allowedUnit['name']) ||
                        $this->unitsMatch($researcherUnit, $allowedUnit['id'])) {
                        return true;
                    }
                }
                return false;
                
            default:
                return false;
        }
    }
    
    /**
     * Compare unit names with flexibility for variations
     */
    private function unitsMatch($unit1, $unit2) {
        if (empty($unit1) || empty($unit2)) {
            return false;
        }
        
        $u1 = strtolower(trim($unit1));
        $u2 = strtolower(trim($unit2));
        
        return $u1 === $u2 || 
               strpos($u1, $u2) !== false || 
               strpos($u2, $u1) !== false;
    }
    
    /**
     * Check if researcher profile belongs to current user
     */
    private function isOwnProfile($category, $researcher) {
        // Check if researcher has linked user_id
        if (isset($researcher['user_id']) && $researcher['user_id'] == $this->userId) {
            return true;
        }
        
        // Check via employee_id linkage
        if ($this->employeeId && isset($researcher['employee_id'])) {
            return $researcher['employee_id'] === $this->employeeId;
        }
        
        return false;
    }
    
    /**
     * Get researcher data from appropriate table
     */
    private function getResearcherData($category, $researcherId) {
        $table = $this->getTableName($category);
        if (!$table) {
            return null;
        }
        
        $stmt = $this->conn->prepare("SELECT * FROM {$table} WHERE id = ?");
        $stmt->bind_param("i", $researcherId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get table name for researcher category
     */
    private function getTableName($category) {
        $tables = [
            self::CATEGORY_FACULTY => 'faculty_researchers',
            self::CATEGORY_STUDENT => 'student_researchers',
            self::CATEGORY_PERSONNEL => 'personnel_researchers'
        ];
        return $tables[$category] ?? null;
    }
    
    /**
     * Build result array
     */
    private function buildResult($allowed, $accessLevel, $errorCode, $message) {
        return [
            'allowed' => $allowed,
            'access_level' => $accessLevel,
            'error_code' => $errorCode,
            'message' => $message,
            'is_read_only' => true // Always read-only for profile viewing
        ];
    }
    
    /**
     * Log profile access for audit
     */
    public function logProfileAccess($category, $researcherId, $accessResult) {
        if (!$this->auditEnabled) {
            return;
        }
        
        // Check if audit table exists, create if not
        $this->ensureAuditTable();
        
        $stmt = $this->conn->prepare("
            INSERT INTO researcher_profile_access_logs 
            (user_id, user_role, employee_id, researcher_category, researcher_id, 
             access_granted, access_level, error_code, scope_context, ip_address, user_agent, accessed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $scopeContext = json_encode([
            'coordinator_types' => $this->coordinatorData['types'] ?? [],
            'scope_mode' => $this->coordinatorData['scope_mode'] ?? null,
            'hr_unit_name' => $this->coordinatorData['hr_unit_name'] ?? null,
            'allowed_units' => $this->coordinatorData['allowed_units'] ?? []
        ]);
        
        $accessGranted = $accessResult['allowed'] ? 1 : 0;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt->bind_param("isssiisssss",
            $this->userId,
            $this->userRole,
            $this->employeeId,
            $category,
            $researcherId,
            $accessGranted,
            $accessResult['access_level'],
            $accessResult['error_code'],
            $scopeContext,
            $ipAddress,
            $userAgent
        );
        
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * Ensure audit table exists
     */
    private function ensureAuditTable() {
        $this->conn->query("
            CREATE TABLE IF NOT EXISTS researcher_profile_access_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                user_role VARCHAR(50),
                employee_id VARCHAR(100),
                researcher_category ENUM('faculty', 'student', 'personnel') NOT NULL,
                researcher_id INT NOT NULL,
                access_granted TINYINT(1) NOT NULL,
                access_level VARCHAR(50),
                error_code VARCHAR(50),
                scope_context JSON,
                ip_address VARCHAR(45),
                user_agent TEXT,
                accessed_at DATETIME NOT NULL,
                INDEX idx_user (user_id),
                INDEX idx_researcher (researcher_category, researcher_id),
                INDEX idx_accessed_at (accessed_at),
                INDEX idx_access_granted (access_granted)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            COMMENT='Immutable audit log for researcher profile access'
        ");
    }
    
    /**
     * Require profile access or show access denied page
     */
    public function requireProfileAccess($category, $researcherId, $isSpa = false) {
        $result = $this->canViewProfile($category, $researcherId);
        
        // Log the access attempt
        $this->logProfileAccess($category, $researcherId, $result);
        
        if (!$result['allowed']) {
            $this->denyAccess($result, $isSpa);
        }
        
        return $result;
    }
    
    /**
     * Display access denied page
     */
    private function denyAccess($result, $isSpa = false) {
        http_response_code(403);
        
        // JSON response for AJAX/API requests
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => $result['message'],
                'error_code' => $result['error_code']
            ]);
            exit;
        }
        
        // HTML response
        $errorIcon = 'fa-shield-alt';
        $errorTitle = 'Insufficient Scope';
        
        switch ($result['error_code']) {
            case self::ERROR_CATEGORY_MISMATCH:
                $errorIcon = 'fa-user-tag';
                $errorTitle = 'Category Mismatch';
                break;
            case self::ERROR_UNIT_OUT_OF_SCOPE:
                $errorIcon = 'fa-building';
                $errorTitle = 'Unit Out of Scope';
                break;
            case self::ERROR_NOT_AUTHENTICATED:
                $errorIcon = 'fa-sign-in-alt';
                $errorTitle = 'Authentication Required';
                break;
            case self::ERROR_PROFILE_NOT_FOUND:
                $errorIcon = 'fa-user-slash';
                $errorTitle = 'Profile Not Found';
                break;
        }
        
        echo "<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Access Denied - Insufficient Scope</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .access-denied-container {
                    background: white;
                    border-radius: 20px;
                    padding: 50px 40px;
                    max-width: 520px;
                    width: 100%;
                    text-align: center;
                    box-shadow: 0 25px 80px rgba(0,0,0,0.4);
                }
                .icon-wrapper {
                    width: 100px;
                    height: 100px;
                    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 30px;
                }
                .icon-wrapper i {
                    font-size: 48px;
                    color: #dc2626;
                }
                h1 {
                    color: #1f2937;
                    font-size: 28px;
                    margin-bottom: 15px;
                    font-weight: 700;
                }
                .error-code {
                    display: inline-block;
                    background: #fef3c7;
                    color: #92400e;
                    padding: 6px 14px;
                    border-radius: 20px;
                    font-size: 12px;
                    font-weight: 600;
                    margin-bottom: 20px;
                }
                .message {
                    color: #4b5563;
                    font-size: 16px;
                    line-height: 1.7;
                    margin-bottom: 30px;
                }
                .info-box {
                    background: #f3f4f6;
                    border-radius: 12px;
                    padding: 20px;
                    margin-bottom: 30px;
                    text-align: left;
                }
                .info-box h3 {
                    color: #374151;
                    font-size: 14px;
                    margin-bottom: 10px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .info-box p {
                    color: #6b7280;
                    font-size: 13px;
                    line-height: 1.6;
                }
                .btn-back {
                    display: inline-flex;
                    align-items: center;
                    gap: 10px;
                    padding: 14px 28px;
                    background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);
                    color: white;
                    text-decoration: none;
                    border-radius: 10px;
                    font-weight: 600;
                    transition: all 0.3s ease;
                }
                .btn-back:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 25px rgba(6, 78, 26, 0.3);
                }
            </style>
        </head>
        <body>
            <div class='access-denied-container'>
                <div class='icon-wrapper'>
                    <i class='fas {$errorIcon}'></i>
                </div>
                <h1>{$errorTitle}</h1>
                <span class='error-code'>" . htmlspecialchars($result['error_code']) . "</span>
                <p class='message'>" . htmlspecialchars($result['message']) . "</p>
                <div class='info-box'>
                    <h3><i class='fas fa-info-circle'></i> Access Policy</h3>
                    <p>Researcher profiles may only be viewed by authorized coordinators within their assigned scope and by Research Office administrators. If you need access to this profile, please contact your administrator.</p>
                </div>
                <a href='javascript:history.back()' class='btn-back'>
                    <i class='fas fa-arrow-left'></i> Go Back
                </a>
            </div>
        </body>
        </html>";
        exit;
    }
    
    /**
     * Get user's access summary for UI display
     */
    public function getAccessSummary() {
        return [
            'user_id' => $this->userId,
            'user_role' => $this->userRole,
            'employee_id' => $this->employeeId,
            'is_admin' => $this->userRole === 'admin',
            'is_coordinator' => $this->userRole === 'coordinator',
            'is_researcher' => $this->userRole === 'researcher',
            'coordinator_types' => $this->coordinatorData['types'] ?? [],
            'scope_mode' => $this->coordinatorData['scope_mode'] ?? null,
            'hr_unit_name' => $this->coordinatorData['hr_unit_name'] ?? null,
            'allowed_units' => $this->coordinatorData['allowed_units'] ?? [],
            'can_view_faculty' => $this->userRole === 'admin' || 
                                  ($this->userRole === 'coordinator' && in_array('faculty', $this->coordinatorData['types'] ?? [])),
            'can_view_students' => $this->userRole === 'admin' || 
                                   ($this->userRole === 'coordinator' && in_array('student', $this->coordinatorData['types'] ?? [])),
            'can_view_personnel' => $this->userRole === 'admin' || 
                                    ($this->userRole === 'coordinator' && in_array('personnel', $this->coordinatorData['types'] ?? []))
        ];
    }
    
    /**
     * Get fields that should be hidden/restricted for non-admin users
     * These are HR-only fields that should not be exposed
     */
    public static function getRestrictedFields() {
        return [
            'salary',
            'compensation',
            'bank_account',
            'tin',
            'sss',
            'philhealth',
            'pagibig',
            'personal_address',
            'emergency_contact_phone',
            'disciplinary_records'
        ];
    }
    
    /**
     * Filter researcher data to remove restricted fields
     */
    public function filterResearcherData($data) {
        if ($this->userRole === 'admin') {
            // Admins see everything except truly sensitive HR data
            $restrictedForAll = ['salary', 'compensation', 'bank_account'];
            foreach ($restrictedForAll as $field) {
                unset($data[$field]);
            }
            return $data;
        }
        
        // Remove all restricted fields for non-admin users
        foreach (self::getRestrictedFields() as $field) {
            unset($data[$field]);
        }
        
        return $data;
    }
    
    /**
     * Check if current access is read-only (always true for profile viewing)
     */
    public function isReadOnly() {
        return true;
    }
    
    /**
     * Disable audit logging (for testing)
     */
    public function disableAudit() {
        $this->auditEnabled = false;
    }
}
