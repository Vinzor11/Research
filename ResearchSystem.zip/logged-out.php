<?php
/**
 * Post-Logout Redirect Handler
 * Handles the redirect back from HR System after SSO logout
 */
session_start();

// Clear any remaining session data
session_unset();
session_destroy();

// Start a new session for the success message
session_start();

error_log("Post-logout redirect handled - User successfully logged out from both systems");

// Redirect to login page with success message
header("Location: login.php?message=" . urlencode("You have been logged out successfully from all systems"));
exit;
