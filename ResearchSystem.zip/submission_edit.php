<?php
/**
 * Submission Edit Page
 * 
 * Allows researchers to edit their draft or returned-for-revision submissions.
 * Only editable when status is 'draft' or 'returned_for_revision'.
 */

session_start();
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get submission ID
$submissionId = $_GET['id'] ?? null;
if (!$submissionId) {
    echo '<div class="content"><div class="alert-danger"><i class="fa fa-exclamation-circle"></i> Submission ID is required.</div></div>';
    exit;
}

// Initialize services
$submissionService = new SubmissionService($conn);
$workflowEngine = $submissionService->getWorkflowEngine();

// Get submission
$submission = $submissionService->getById($submissionId);
if (!$submission) {
    echo '<div class="content"><div class="alert-danger"><i class="fa fa-exclamation-circle"></i> Submission not found.</div></div>';
    exit;
}

// Check if user can edit
if (!$workflowEngine->canEdit($submission)) {
    echo '<div class="content"><div class="alert-danger"><i class="fa fa-lock"></i> You cannot edit this submission at its current status.</div></div>';
    exit;
}

// Get submission types
$submissionTypes = $submissionService->getSubmissionTypes();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
.edit-container {
    max-width: 900px;
    margin: 0 auto;
    padding: 20px;
}

.edit-header {
    background: white;
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.edit-title {
    font-size: 22px;
    font-weight: 700;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.edit-title i {
    color: #064e1a;
}

.status-badge {
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
}

.status-draft { background: #f3f4f6; color: #6b7280; }
.status-returned_for_revision { background: #fee2e2; color: #991b1b; }

.form-card {
    background: white;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

.form-card-header {
    padding: 16px 24px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    font-weight: 600;
    color: #1f2937;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-card-header i {
    color: #064e1a;
}

.form-card-body {
    padding: 24px;
}

.form-group {
    margin-bottom: 24px;
}

.form-group:last-child {
    margin-bottom: 0;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
    font-size: 14px;
}

.form-group label .required {
    color: #ef4444;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.form-group textarea {
    min-height: 120px;
    resize: vertical;
}

.form-group .hint {
    font-size: 12px;
    color: #6b7280;
    margin-top: 6px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.action-bar {
    display: flex;
    gap: 12px;
    justify-content: space-between;
    align-items: center;
    padding: 20px 0;
}

.btn {
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
    text-decoration: none;
}

.btn-back {
    background: #f3f4f6;
    color: #374151;
}

.btn-back:hover {
    background: #e5e7eb;
}

.btn-save {
    background: #3b82f6;
    color: white;
}

.btn-save:hover {
    background: #2563eb;
}

.btn-submit {
    background: #064e1a;
    color: white;
}

.btn-submit:hover {
    background: #053615;
}

.btn-group {
    display: flex;
    gap: 12px;
}

/* Alert Messages */
.alert-danger {
    background: #fee2e2;
    color: #991b1b;
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-warning {
    background: #fef3c7;
    color: #92400e;
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* File Upload Section */
.attachments-section {
    margin-top: 20px;
}

.attachment-upload-area {
    border: 2px dashed #e5e7eb;
    border-radius: 8px;
    padding: 30px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s ease;
    margin-bottom: 20px;
}

.attachment-upload-area:hover {
    border-color: #064e1a;
    background: #f0fdf4;
}

.attachment-upload-area i {
    font-size: 36px;
    color: #9ca3af;
    margin-bottom: 10px;
}

.attachment-upload-area p {
    color: #6b7280;
    margin: 0;
}

.attachment-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.attachment-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: #f9fafb;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.attachment-item .info {
    flex: 1;
}

.attachment-item .info .name {
    font-weight: 500;
    color: #1f2937;
}

.attachment-item .info .meta {
    font-size: 12px;
    color: #6b7280;
}

.attachment-item .btn-remove {
    padding: 6px 12px;
    background: #fee2e2;
    color: #991b1b;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}
</style>

<div class="content edit-container">
    <!-- Header -->
    <div class="edit-header">
        <h1 class="edit-title">
            <i class="fa fa-edit"></i>
            Edit Submission
        </h1>
        <span class="status-badge status-<?= s($submission['status']) ?>">
            <?= s($submission['status_label']) ?>
        </span>
    </div>

    <?php if ($submission['status'] === 'returned_for_revision'): ?>
        <div class="alert-warning">
            <i class="fa fa-exclamation-triangle"></i>
            <div>
                <strong>Revision Required:</strong> This submission was returned for revision. Please address the feedback before resubmitting.
            </div>
        </div>
    <?php endif; ?>

    <form id="editForm" method="POST" onsubmit="saveSubmission(event); return false;">
        <input type="hidden" name="id" value="<?= $submission['id'] ?>">

        <!-- Basic Information -->
        <div class="form-card">
            <div class="form-card-header">
                <i class="fa fa-file-alt"></i> Basic Information
            </div>
            <div class="form-card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Submission Type <span class="required">*</span></label>
                        <select name="submission_type_id" required disabled>
                            <?php foreach ($submissionTypes as $type): ?>
                                <option value="<?= $type['id'] ?>" <?= $submission['submission_type_id'] == $type['id'] ? 'selected' : '' ?>>
                                    <?= s($type['type_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="hint">Submission type cannot be changed</div>
                    </div>
                    <div class="form-group">
                        <label>Reference Number</label>
                        <input type="text" value="<?= s($submission['reference_number'] ?? 'Pending') ?>" disabled>
                        <div class="hint">Assigned upon approval</div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Research Title <span class="required">*</span></label>
                    <input type="text" name="title" value="<?= s($submission['title']) ?>" required placeholder="Enter the title of your research">
                </div>

                <div class="form-group">
                    <label>Abstract</label>
                    <textarea name="abstract" placeholder="Provide a brief summary of your research"><?= s($submission['abstract']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Research Details -->
        <div class="form-card">
            <div class="form-card-header">
                <i class="fa fa-flask"></i> Research Details
            </div>
            <div class="form-card-body">
                <div class="form-group">
                    <label>Objectives</label>
                    <textarea name="objectives" placeholder="What are the objectives of this research?"><?= s($submission['objectives']) ?></textarea>
                </div>

                <div class="form-group">
                    <label>Methodology</label>
                    <textarea name="methodology" placeholder="Describe your research methodology"><?= s($submission['methodology']) ?></textarea>
                </div>

                <div class="form-group">
                    <label>Expected Outcomes</label>
                    <textarea name="expected_outcomes" placeholder="What outcomes do you expect from this research?"><?= s($submission['expected_outcomes']) ?></textarea>
                </div>
            </div>
        </div>

        <!-- Timeline & Budget -->
        <div class="form-card">
            <div class="form-card-header">
                <i class="fa fa-calendar-alt"></i> Timeline & Budget
            </div>
            <div class="form-card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Proposed Start Date</label>
                        <input type="date" name="proposed_start_date" value="<?= s($submission['proposed_start_date']) ?>">
                    </div>
                    <div class="form-group">
                        <label>Proposed End Date</label>
                        <input type="date" name="proposed_end_date" value="<?= s($submission['proposed_end_date']) ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label>Total Budget (PHP)</label>
                    <input type="number" name="total_budget" step="0.01" min="0" value="<?= $submission['total_budget'] ?>" placeholder="0.00">
                </div>
            </div>
        </div>

        <!-- Attachments -->
        <div class="form-card">
            <div class="form-card-header">
                <i class="fa fa-paperclip"></i> Attachments
            </div>
            <div class="form-card-body">
                <div class="attachment-upload-area" onclick="document.getElementById('fileInput').click()">
                    <i class="fa fa-cloud-upload-alt"></i>
                    <p>Click to upload or drag files here</p>
                    <p style="font-size: 12px; color: #9ca3af;">PDF, DOC, DOCX, XLS, XLSX (max 50MB)</p>
                </div>
                <input type="file" id="fileInput" style="display: none;" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx">

                <div class="attachment-list" id="attachmentList">
                    <?php foreach ($submission['attachments'] as $att): ?>
                        <div class="attachment-item" data-id="<?= $att['id'] ?>">
                            <i class="fa fa-file" style="font-size: 24px; color: #6b7280;"></i>
                            <div class="info">
                                <div class="name"><?= s($att['original_name']) ?></div>
                                <div class="meta"><?= number_format($att['file_size'] / 1024, 1) ?> KB &bull; <?= ucwords(str_replace('_', ' ', $att['attachment_type'])) ?></div>
                            </div>
                            <button type="button" class="btn-remove" onclick="removeAttachment(<?= $att['id'] ?>)">
                                <i class="fa fa-times"></i> Remove
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-bar">
            <a href="researcher_submissions.php" class="btn btn-back">
                <i class="fa fa-arrow-left"></i> Back to List
            </a>
            <div class="btn-group">
                <button type="submit" class="btn btn-save">
                    <i class="fa fa-save"></i> Save Draft
                </button>
                <button type="button" class="btn btn-submit" onclick="submitForReview()">
                    <i class="fa fa-paper-plane"></i> Submit for Review
                </button>
            </div>
        </div>
    </form>
</div>

<script>
const submissionId = <?= $submission['id'] ?>;

// Save submission
async function saveSubmission(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const data = {
        action: 'update',
        id: submissionId
    };
    
    formData.forEach((value, key) => {
        if (value && key !== 'id') {
            data[key] = value;
        }
    });
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Submission saved successfully!');
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to save'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while saving');
    }
}

// Submit for review
async function submitForReview() {
    // First save the current changes
    const form = document.getElementById('editForm');
    const formData = new FormData(form);
    
    const updateData = {
        action: 'update',
        id: submissionId
    };
    
    formData.forEach((value, key) => {
        if (value && key !== 'id') {
            updateData[key] = value;
        }
    });
    
    try {
        // Save first
        const saveResponse = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
        });
        
        const saveResult = await saveResponse.json();
        
        if (!saveResult.success) {
            alert('❌ Error saving: ' + (saveResult.error || 'Failed to save'));
            return;
        }
        
        // Then confirm and submit
        if (!confirm('Submit this research to your coordinator for review?\n\nOnce submitted, you will not be able to edit it unless it is returned for revision.')) {
            return;
        }
        
        const submitResponse = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'submit', id: submissionId })
        });
        
        const submitResult = await submitResponse.json();
        
        if (submitResult.success) {
            alert('✅ ' + (submitResult.message || 'Submission sent to coordinator!'));
            window.location.href = 'researcher_submissions.php';
        } else {
            alert('❌ Error: ' + (submitResult.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Remove attachment
async function removeAttachment(attachmentId) {
    if (!confirm('Remove this attachment?')) {
        return;
    }
    
    try {
        const response = await fetch('submission_api.php?action=remove_attachment&attachment_id=' + attachmentId, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            document.querySelector(`.attachment-item[data-id="${attachmentId}"]`).remove();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to remove attachment'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// File upload handler
document.getElementById('fileInput').addEventListener('change', async function(e) {
    const files = e.target.files;
    
    for (const file of files) {
        const formData = new FormData();
        formData.append('action', 'upload_attachment');
        formData.append('id', submissionId);
        formData.append('file', file);
        formData.append('attachment_type', 'supporting_document');
        
        try {
            const response = await fetch('submission_api.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Reload page to show new attachment
                window.location.reload();
            } else {
                alert('❌ Error uploading ' + file.name + ': ' + (result.error || 'Upload failed'));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('❌ Error uploading ' + file.name);
        }
    }
});
</script>
