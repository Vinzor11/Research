<?php
/**
 * Researcher Dashboard
 * 
 * A dedicated dashboard for imported researchers showing:
 * - Profile overview
 * - Research statistics
 * - Recent projects
 * - Quick actions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';

// Access control - must be authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get researcher information
$researcherType = null;
$researcherData = null;
$researcherId = null;
$projects = [];
$submissions = [];
$stats = [
    'total_projects' => 0,
    'ongoing_projects' => 0,
    'completed_projects' => 0,
    'total_submissions' => 0,
    'pending_submissions' => 0,
    'approved_submissions' => 0
];

// Check if user is a faculty researcher
$facultyStmt = $conn->prepare("SELECT * FROM faculty_researchers WHERE user_id = ? LIMIT 1");
$facultyStmt->bind_param("i", $userId);
$facultyStmt->execute();
$facultyResult = $facultyStmt->get_result();

if ($facultyResult && $facultyResult->num_rows > 0) {
    $researcherType = 'faculty';
    $researcherData = $facultyResult->fetch_assoc();
    $researcherId = $researcherData['id'];
    
    // Get faculty projects
    $projectStmt = $conn->prepare("SELECT * FROM faculty_projects WHERE faculty_id = ? ORDER BY created_at DESC LIMIT 5");
    $projectStmt->bind_param("i", $researcherId);
    $projectStmt->execute();
    $projects = $projectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $projectStmt->close();
    
    // Get project statistics
    $stats['total_projects'] = $conn->query("SELECT COUNT(*) as c FROM faculty_projects WHERE faculty_id = $researcherId")->fetch_assoc()['c'];
    $stats['ongoing_projects'] = $conn->query("SELECT COUNT(*) as c FROM faculty_projects WHERE faculty_id = $researcherId AND project_status = 'on-going'")->fetch_assoc()['c'];
    $stats['completed_projects'] = $conn->query("SELECT COUNT(*) as c FROM faculty_projects WHERE faculty_id = $researcherId AND project_status = 'completed'")->fetch_assoc()['c'];
}
$facultyStmt->close();

// If not faculty, check if personnel researcher
if (!$researcherData) {
    $personnelStmt = $conn->prepare("SELECT * FROM personnel_researchers WHERE user_id = ? LIMIT 1");
    $personnelStmt->bind_param("i", $userId);
    $personnelStmt->execute();
    $personnelResult = $personnelStmt->get_result();
    
    if ($personnelResult && $personnelResult->num_rows > 0) {
        $researcherType = 'personnel';
        $researcherData = $personnelResult->fetch_assoc();
        $researcherId = $researcherData['id'];
        
        // Get personnel projects
        $projectStmt = $conn->prepare("SELECT * FROM personnel_projects WHERE personnel_id = ? ORDER BY created_at DESC LIMIT 5");
        $projectStmt->bind_param("i", $researcherId);
        $projectStmt->execute();
        $projects = $projectStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $projectStmt->close();
        
        // Get project statistics
        $stats['total_projects'] = $conn->query("SELECT COUNT(*) as c FROM personnel_projects WHERE personnel_id = $researcherId")->fetch_assoc()['c'];
        $stats['ongoing_projects'] = $conn->query("SELECT COUNT(*) as c FROM personnel_projects WHERE personnel_id = $researcherId AND project_status = 'on-going'")->fetch_assoc()['c'];
        $stats['completed_projects'] = $conn->query("SELECT COUNT(*) as c FROM personnel_projects WHERE personnel_id = $researcherId AND project_status = 'completed'")->fetch_assoc()['c'];
    }
    $personnelStmt->close();
}

// Get submission statistics (wrapped in try-catch in case table doesn't exist)
try {
    $submissionStmt = $conn->prepare("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status IN ('draft', 'submitted', 'under_review') THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved
        FROM research_submissions WHERE created_by = ?");
    if ($submissionStmt) {
        $submissionStmt->bind_param("i", $userId);
        $submissionStmt->execute();
        $submissionStats = $submissionStmt->get_result()->fetch_assoc();
        $stats['total_submissions'] = $submissionStats['total'] ?? 0;
        $stats['pending_submissions'] = $submissionStats['pending'] ?? 0;
        $stats['approved_submissions'] = $submissionStats['approved'] ?? 0;
        $submissionStmt->close();
    }
} catch (Exception $e) {
    // Table may not exist yet - leave defaults
}

// Get project statistics from approved submissions
$projectStats = [
    'on_going' => 0,
    'extended' => 0,
    'completed' => 0,
    'overdue' => 0
];
try {
    $projectStatsStmt = $conn->prepare("SELECT 
        SUM(CASE WHEN project_status = 'on_going' AND (current_end_date IS NULL OR current_end_date >= CURDATE()) THEN 1 ELSE 0 END) as on_going,
        SUM(CASE WHEN project_status = 'extended' THEN 1 ELSE 0 END) as extended,
        SUM(CASE WHEN project_status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN project_status IN ('on_going', 'extended') AND current_end_date < CURDATE() THEN 1 ELSE 0 END) as overdue
        FROM research_submissions WHERE created_by = ? AND status = 'approved' AND project_status IS NOT NULL");
    if ($projectStatsStmt) {
        $projectStatsStmt->bind_param("i", $userId);
        $projectStatsStmt->execute();
        $result = $projectStatsStmt->get_result()->fetch_assoc();
        $projectStats['on_going'] = intval($result['on_going'] ?? 0);
        $projectStats['extended'] = intval($result['extended'] ?? 0);
        $projectStats['completed'] = intval($result['completed'] ?? 0);
        $projectStats['overdue'] = intval($result['overdue'] ?? 0);
        $projectStatsStmt->close();
    }
} catch (Exception $e) {
    // Columns may not exist yet - leave defaults
}

// Get recent projects (from approved submissions)
$recentProjects = [];
try {
    $recentProjectsStmt = $conn->prepare("
        SELECT rs.id, rs.title, rs.project_status, rs.project_code, rs.reference_number,
               rs.proposed_start_date, rs.current_end_date, rst.type_name as submission_type
        FROM research_submissions rs
        LEFT JOIN research_submission_types rst ON rs.submission_type_id = rst.id
        WHERE rs.created_by = ? AND rs.status = 'approved' AND rs.project_status IS NOT NULL
        ORDER BY rs.elevated_to_project_at DESC LIMIT 5
    ");
    if ($recentProjectsStmt) {
        $recentProjectsStmt->bind_param("i", $userId);
        $recentProjectsStmt->execute();
        $recentProjects = $recentProjectsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $recentProjectsStmt->close();
    }
} catch (Exception $e) {
    // Columns may not exist yet - leave empty
}

// Get recent submissions (wrapped in try-catch in case table doesn't exist)
try {
    $recentSubmissionsStmt = $conn->prepare("
        SELECT rs.id, rs.title, rs.status, rs.created_at, rst.type_name as submission_type
        FROM research_submissions rs
        LEFT JOIN research_submission_types rst ON rs.submission_type_id = rst.id
        WHERE rs.created_by = ? 
        ORDER BY rs.created_at DESC LIMIT 5
    ");
    if ($recentSubmissionsStmt) {
        $recentSubmissionsStmt->bind_param("i", $userId);
        $recentSubmissionsStmt->execute();
        $submissions = $recentSubmissionsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $recentSubmissionsStmt->close();
    }
} catch (Exception $e) {
    // Table may not exist yet - leave empty array
}

// Helper function
function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get profile picture or initials
$profilePic = $researcherData['profile_pic'] ?? null;
$initials = '';
if ($researcherData) {
    $firstName = $researcherData['first_name'] ?? '';
    $lastName = $researcherData['last_name'] ?? '';
    $initials = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
}
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
.researcher-dashboard {
    padding: 20px;
    max-width: 1400px;
    margin: 0 auto;
}

.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 15px;
}

.dashboard-header h1 {
    color: #1a5632;
    font-size: 28px;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.dashboard-header h1 i {
    color: #2e7d4a;
}

.quick-actions {
    display: flex;
    gap: 10px;
}

.quick-actions .btn {
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 500;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s;
    cursor: pointer;
    border: none;
}

.btn-primary {
    background: linear-gradient(135deg, #1a5632, #2e7d4a);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #134025, #256b3d);
    transform: translateY(-1px);
}

.btn-secondary {
    background: #f0f0f0;
    color: #333;
    border: 1px solid #ddd;
}

.btn-secondary:hover {
    background: #e5e5e5;
}

/* Profile Card */
.profile-card {
    background: linear-gradient(135deg, #1a5632 0%, #2e7d4a 50%, #3d9960 100%);
    border-radius: 16px;
    padding: 30px;
    color: white;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 25px;
    box-shadow: 0 4px 20px rgba(26, 86, 50, 0.3);
}

.profile-avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    font-weight: 600;
    border: 4px solid rgba(255,255,255,0.4);
    overflow: hidden;
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-info {
    flex: 1;
}

.profile-info h2 {
    margin: 0 0 5px 0;
    font-size: 26px;
    font-weight: 600;
}

.profile-info .position {
    font-size: 16px;
    opacity: 0.9;
    margin-bottom: 10px;
}

.profile-info .details {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    font-size: 14px;
    opacity: 0.85;
}

.profile-info .details span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.profile-badge {
    background: rgba(255,255,255,0.2);
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    display: flex;
    align-items: center;
    gap: 15px;
    transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.12);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.stat-icon.blue { background: #e3f2fd; color: #1976d2; }
.stat-icon.green { background: #e8f5e9; color: #388e3c; }
.stat-icon.orange { background: #fff3e0; color: #f57c00; }
.stat-icon.purple { background: #f3e5f5; color: #7b1fa2; }
.stat-icon.teal { background: #e0f2f1; color: #00897b; }
.stat-icon.red { background: #ffebee; color: #d32f2f; }

.stat-content h3 {
    font-size: 28px;
    font-weight: 700;
    margin: 0;
    color: #1a1a2e;
}

.stat-content p {
    margin: 2px 0 0 0;
    font-size: 13px;
    color: #6c757d;
}

/* Content Grid */
.content-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 25px;
}

.content-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
    overflow: hidden;
}

.content-card-header {
    padding: 18px 20px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fafbfc;
}

.content-card-header h3 {
    margin: 0;
    font-size: 16px;
    color: #1a1a2e;
    display: flex;
    align-items: center;
    gap: 10px;
}

.content-card-header h3 i {
    color: #1a5632;
}

.content-card-header a {
    font-size: 13px;
    color: #1a5632;
    text-decoration: none;
    font-weight: 500;
}

.content-card-header a:hover {
    text-decoration: underline;
}

.content-card-body {
    padding: 0;
}

/* Project List */
.project-list {
    list-style: none;
    margin: 0;
    padding: 0;
}

.project-item {
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background 0.2s;
}

.project-item:last-child {
    border-bottom: none;
}

.project-item:hover {
    background: #f8f9fa;
}

.project-info h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #1a1a2e;
    font-weight: 500;
}

.project-info p {
    margin: 0;
    font-size: 12px;
    color: #6c757d;
}

.project-status {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.status-ongoing { background: #dbeafe; color: #1e40af; }
.status-on-going { background: #dbeafe; color: #1e40af; }
.status-onging { background: #dbeafe; color: #1e40af; }
.status-extended { background: #fef3c7; color: #92400e; }
.status-completed { background: #d1fae5; color: #065f46; }
.status-draft { background: #e3f2fd; color: #1976d2; }
.status-submitted { background: #f3e5f5; color: #7b1fa2; }
.status-approved { background: #e8f5e9; color: #388e3c; }
.status-rejected { background: #ffebee; color: #d32f2f; }
.status-under_review { background: #fff8e1; color: #ff8f00; }

/* Submission List */
.submission-item {
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background 0.2s;
    cursor: pointer;
}

.submission-item:last-child {
    border-bottom: none;
}

.submission-item:hover {
    background: #f8f9fa;
}

.submission-info h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #1a1a2e;
    font-weight: 500;
}

.submission-info p {
    margin: 0;
    font-size: 12px;
    color: #6c757d;
}

.submission-meta {
    text-align: right;
}

.submission-type {
    font-size: 11px;
    color: #6c757d;
    margin-bottom: 5px;
    text-transform: capitalize;
}

/* Empty State */
.empty-state {
    padding: 40px 20px;
    text-align: center;
    color: #6c757d;
}

.empty-state i {
    font-size: 40px;
    color: #dee2e6;
    margin-bottom: 15px;
}

.empty-state p {
    margin: 0;
    font-size: 14px;
}

/* Quick Links */
.quick-links-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    padding: 20px;
}

.quick-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    text-decoration: none;
    color: #333;
    transition: all 0.2s;
    border: 1px solid #e9ecef;
}

.quick-link:hover {
    background: #e9ecef;
    transform: translateX(5px);
}

.quick-link i {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.quick-link span {
    font-size: 14px;
    font-weight: 500;
}

/* Responsive */
@media (max-width: 768px) {
    .profile-card {
        flex-direction: column;
        text-align: center;
    }
    
    .profile-info .details {
        justify-content: center;
    }
    
    .content-grid {
        grid-template-columns: 1fr;
    }
    
    .dashboard-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

<div class="researcher-dashboard">
    <!-- Flash Messages -->
    <?php if (isset($_SESSION['flash_message'])): 
        $flashType = $_SESSION['flash_type'] ?? 'info';
        $flashMsg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    ?>
    <div class="alert alert-<?php echo $flashType === 'success' ? 'success' : ($flashType === 'danger' ? 'danger' : 'info'); ?>" style="margin-bottom: 20px; padding: 15px; border-radius: 8px; display: flex; align-items: center; gap: 10px;">
        <i class="fa fa-<?php echo $flashType === 'success' ? 'check-circle' : ($flashType === 'danger' ? 'exclamation-triangle' : 'info-circle'); ?>"></i>
        <?php echo htmlspecialchars($flashMsg); ?>
        <button type="button" onclick="this.parentElement.remove()" style="margin-left: auto; background: none; border: none; cursor: pointer; font-size: 18px;">&times;</button>
    </div>
    <?php endif; ?>
    
    <!-- Header -->
    <div class="dashboard-header">
        <h1>
            <i class="fa fa-home"></i>
            Researcher Dashboard
        </h1>
        <?php if ($researcherData): ?>
        <div class="quick-actions">
            <a href="researcher_projects.php" class="btn btn-secondary" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_projects.php',true)}">
                <i class="fa fa-flask"></i> My Projects
            </a>
            <a href="researcher_submissions.php" class="btn btn-secondary" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_submissions.php',true)}">
                <i class="fa fa-file-alt"></i> My Submissions
            </a>
            <a href="submission_create.php" class="btn btn-primary" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_create.php',true)}">
                <i class="fa fa-plus"></i> New Submission
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($researcherData): ?>
    <!-- Profile Card -->
    <div class="profile-card">
        <div class="profile-avatar">
            <?php if ($profilePic): ?>
                <img src="<?= s($profilePic) ?>" alt="Profile">
            <?php else: ?>
                <?= $initials ?>
            <?php endif; ?>
        </div>
        <div class="profile-info">
            <h2><?= s($researcherData['first_name'] . ' ' . ($researcherData['middle_name'] ? $researcherData['middle_name'] . ' ' : '') . $researcherData['last_name']) ?></h2>
            <div class="position">
                <?php if ($researcherType === 'faculty'): ?>
                    <?= s($researcherData['faculty_rank'] ?? 'Faculty Researcher') ?>
                <?php else: ?>
                    <?= s($researcherData['position'] ?? 'Personnel Researcher') ?>
                <?php endif; ?>
            </div>
            <div class="details">
                <?php if ($researcherType === 'faculty'): ?>
                    <?php if (!empty($researcherData['home_unit'])): ?>
                        <span><i class="fa fa-building"></i> <?= s($researcherData['home_unit']) ?></span>
                    <?php elseif (!empty($researcherData['department'])): ?>
                        <span><i class="fa fa-building"></i> <?= s($researcherData['department']) ?></span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if (!empty($researcherData['office_unit'])): ?>
                        <span><i class="fa fa-building"></i> <?= s($researcherData['office_unit']) ?></span>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (!empty($researcherData['email'])): ?>
                    <span><i class="fa fa-envelope"></i> <?= s($researcherData['email']) ?></span>
                <?php endif; ?>
                <?php if (!empty($researcherData['employee_number'] ?? $researcherData['faculty_number'])): ?>
                    <span><i class="fa fa-id-badge"></i> <?= s($researcherData['employee_number'] ?? $researcherData['faculty_number']) ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="profile-badge">
            <i class="fa fa-user-graduate"></i> <?= ucfirst($researcherType) ?> Researcher
        </div>
    </div>
    <?php else: ?>
    <!-- No Researcher Profile -->
    <div class="profile-card">
        <div class="profile-avatar">
            <?= strtoupper(substr($fullname, 0, 2)) ?>
        </div>
        <div class="profile-info">
            <h2><?= s($fullname) ?></h2>
            <div class="position">Researcher</div>
            <div class="details">
                <span><i class="fa fa-info-circle"></i> Your researcher profile is not yet set up. Please contact the Research Office to complete your profile registration.</span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($researcherData): ?>

    <!-- Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fa fa-flask"></i>
            </div>
            <div class="stat-content">
                <h3><?= $projectStats['on_going'] + $projectStats['extended'] ?></h3>
                <p>Active Projects</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fa fa-spinner"></i>
            </div>
            <div class="stat-content">
                <h3><?= $projectStats['on_going'] ?></h3>
                <p>On-Going Projects</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fa fa-check-circle"></i>
            </div>
            <div class="stat-content">
                <h3><?= $projectStats['completed'] ?></h3>
                <p>Completed Projects</p>
            </div>
        </div>
        <?php if ($projectStats['overdue'] > 0): ?>
        <div class="stat-card">
            <div class="stat-icon red">
                <i class="fa fa-exclamation-triangle"></i>
            </div>
            <div class="stat-content">
                <h3><?= $projectStats['overdue'] ?></h3>
                <p>Overdue</p>
            </div>
        </div>
        <?php endif; ?>
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fa fa-file-alt"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['total_submissions'] ?></h3>
                <p>Total Submissions</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon teal">
                <i class="fa fa-clock"></i>
            </div>
            <div class="stat-content">
                <h3><?= $stats['pending_submissions'] ?></h3>
                <p>Pending Review</p>
            </div>
        </div>
    </div>

    <!-- Content Grid -->
    <div class="content-grid">
        <!-- Recent RMIS Projects (From Approved Submissions) -->
        <div class="content-card">
            <div class="content-card-header">
                <h3><i class="fa fa-flask"></i> Active Research Projects</h3>
                <a href="researcher_projects.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_projects.php',true)}">View All</a>
            </div>
            <div class="content-card-body">
                <?php if (!empty($recentProjects)): ?>
                    <ul class="project-list">
                        <?php foreach ($recentProjects as $rp): ?>
                            <li class="project-item" onclick="if(window.SPA){window.SPA.loadPage('project_view.php?id=<?= $rp['id'] ?>',true)}else{window.location.href='project_view.php?id=<?= $rp['id'] ?>'}" style="cursor: pointer;">
                                <div class="project-info">
                                    <h4><?= s($rp['title']) ?></h4>
                                    <p>
                                        <?php if (!empty($rp['project_code'])): ?>
                                            <i class="fa fa-hashtag"></i> <?= s($rp['project_code']) ?>
                                        <?php endif; ?>
                                        <?php if (!empty($rp['current_end_date'])): ?>
                                            &nbsp;&bull;&nbsp; Due: <?= date('M d, Y', strtotime($rp['current_end_date'])) ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <span class="project-status status-<?= strtolower(str_replace('_', '', $rp['project_status'] ?? 'on_going')) ?>">
                                    <?= ucwords(str_replace('_', '-', $rp['project_status'] ?? 'on-going')) ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fa fa-flask"></i>
                        <p>No active projects yet. <a href="researcher_submissions.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_submissions.php',true)}">Submit a research proposal</a> to get started.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Legacy Projects (From Faculty/Personnel Records) -->
        <?php if (!empty($projects)): ?>
        <div class="content-card">
            <div class="content-card-header">
                <h3><i class="fa fa-history"></i> Historical Research Projects</h3>
                <?php if ($researcherType === 'faculty'): ?>
                    <a href="facultyresearcherprofile.php?id=<?= $researcherId ?>" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('facultyresearcherprofile.php?id=<?= $researcherId ?>',true)}">View Profile</a>
                <?php elseif ($researcherType === 'personnel'): ?>
                    <a href="personnelresearcherprofile.php?id=<?= $researcherId ?>" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('personnelresearcherprofile.php?id=<?= $researcherId ?>',true)}">View Profile</a>
                <?php endif; ?>
            </div>
            <div class="content-card-body">
                <ul class="project-list">
                    <?php foreach ($projects as $project): ?>
                        <li class="project-item">
                            <div class="project-info">
                                <h4><?= s($project['project_title'] ?? $project['title'] ?? 'Untitled Project') ?></h4>
                                <p>
                                    <?php if (!empty($project['funding_agency'])): ?>
                                        <i class="fa fa-university"></i> <?= s($project['funding_agency']) ?>
                                    <?php endif; ?>
                                    <?php if (!empty($project['start_date'])): ?>
                                        &nbsp;&bull;&nbsp; Started: <?= date('M Y', strtotime($project['start_date'])) ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <span class="project-status status-<?= strtolower(str_replace(' ', '', $project['project_status'] ?? 'draft')) ?>">
                                <?= s($project['project_status'] ?? 'Draft') ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>

        <!-- Recent Submissions -->
        <div class="content-card">
            <div class="content-card-header">
                <h3><i class="fa fa-paper-plane"></i> Recent Submissions</h3>
                <a href="researcher_submissions.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_submissions.php',true)}">View All</a>
            </div>
            <div class="content-card-body">
                <?php if (!empty($submissions)): ?>
                    <?php foreach ($submissions as $sub): ?>
                        <div class="submission-item" onclick="if(window.SPA){window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}else{window.location.href='submission_view.php?id=<?= $sub['id'] ?>'}">
                            <div class="submission-info">
                                <h4><?= s($sub['title']) ?></h4>
                                <p><i class="fa fa-calendar"></i> <?= date('M d, Y', strtotime($sub['created_at'])) ?></p>
                            </div>
                            <div class="submission-meta">
                                <div class="submission-type"><?= s(str_replace('_', ' ', $sub['submission_type'])) ?></div>
                                <span class="project-status status-<?= strtolower($sub['status']) ?>">
                                    <?= s(ucfirst(str_replace('_', ' ', $sub['status']))) ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fa fa-paper-plane"></i>
                        <p>No submissions yet. <a href="submission_create.php" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_create.php',true)}">Create your first submission</a></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="content-card">
            <div class="content-card-header">
                <h3><i class="fa fa-link"></i> Quick Links</h3>
            </div>
            <div class="content-card-body">
                <div class="quick-links-grid">
                    <a href="submission_create.php" class="quick-link" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_create.php',true)}">
                        <i class="fa fa-plus-circle" style="background: #e8f5e9; color: #388e3c;"></i>
                        <span>New Submission</span>
                    </a>
                    <a href="researcher_submissions.php" class="quick-link" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_submissions.php',true)}">
                        <i class="fa fa-list" style="background: #e3f2fd; color: #1976d2;"></i>
                        <span>My Submissions</span>
                    </a>
                    <a href="researcher_projects.php" class="quick-link" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_projects.php',true)}">
                        <i class="fa fa-flask" style="background: #dbeafe; color: #2563eb;"></i>
                        <span>My Projects</span>
                    </a>
                    <?php if ($researcherType === 'faculty' && $researcherId): ?>
                    <a href="facultyresearcherprofile.php?id=<?= $researcherId ?>" class="quick-link" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('facultyresearcherprofile.php?id=<?= $researcherId ?>',true)}">
                        <i class="fa fa-user" style="background: #f3e5f5; color: #7b1fa2;"></i>
                        <span>My Profile</span>
                    </a>
                    <?php elseif ($researcherType === 'personnel' && $researcherId): ?>
                    <a href="personnelresearcherprofile.php?id=<?= $researcherId ?>" class="quick-link" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('personnelresearcherprofile.php?id=<?= $researcherId ?>',true)}">
                        <i class="fa fa-user" style="background: #f3e5f5; color: #7b1fa2;"></i>
                        <span>My Profile</span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
