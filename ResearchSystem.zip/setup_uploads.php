<?php
/**
 * Setup Uploads Directory
 * Run this script once to create the uploads directory with proper permissions
 * Access: http://yourdomain.com/ResearchManagementSystem/setup_uploads.php
 */

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Uploads Directory</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            max-width: 800px; 
            margin: 50px auto; 
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { color: #064e1a; }
        .success { 
            background: #d4edda; 
            color: #155724; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 10px 0;
            border-left: 4px solid #28a745;
        }
        .error { 
            background: #f8d7da; 
            color: #721c24; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 10px 0;
            border-left: 4px solid #dc3545;
        }
        .warning { 
            background: #fff3cd; 
            color: #856404; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 10px 0;
            border-left: 4px solid #ffc107;
        }
        .info {
            background: #d1ecf1;
            color: #0c5460;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #17a2b8;
        }
        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
        .btn {
            background: #064e1a;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
        }
        .btn:hover {
            background: #0b6a24;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>📁 Setup Uploads Directory</h1>";

$base_dir = __DIR__;
$uploads_dir = $base_dir . '/uploads';
$research_outputs_dir = $uploads_dir . '/research_outputs';

$messages = [];
$errors = [];

// Check current permissions
echo "<div class='info'>
        <strong>Current Directory:</strong> " . htmlspecialchars($base_dir) . "<br>
        <strong>Target Directory:</strong> " . htmlspecialchars($research_outputs_dir) . "
      </div>";

// Step 1: Create uploads directory
if (!is_dir($uploads_dir)) {
    if (@mkdir($uploads_dir, 0755, true)) {
        @chmod($uploads_dir, 0755);
        $messages[] = "✓ Created 'uploads' directory";
    } else {
        $errors[] = "✗ Failed to create 'uploads' directory";
        $errors[] = "Manual command: <code>mkdir -p " . htmlspecialchars($uploads_dir) . " && chmod 755 " . htmlspecialchars($uploads_dir) . "</code>";
    }
} else {
    $messages[] = "✓ 'uploads' directory already exists";
}

// Step 2: Create research_outputs subdirectory
if (!is_dir($research_outputs_dir)) {
    if (@mkdir($research_outputs_dir, 0755, true)) {
        @chmod($research_outputs_dir, 0755);
        $messages[] = "✓ Created 'uploads/research_outputs' directory";
    } else {
        $errors[] = "✗ Failed to create 'uploads/research_outputs' directory";
        $errors[] = "Manual command: <code>mkdir -p " . htmlspecialchars($research_outputs_dir) . " && chmod 755 " . htmlspecialchars($research_outputs_dir) . "</code>";
    }
} else {
    $messages[] = "✓ 'uploads/research_outputs' directory already exists";
}

// Step 3: Check permissions
$uploads_writable = is_writable($uploads_dir);
$research_writable = is_writable($research_outputs_dir);

if ($uploads_writable && $research_writable) {
    $messages[] = "✓ All directories are writable";
} else {
    if (!$uploads_writable) {
        $errors[] = "✗ 'uploads' directory is not writable";
        $errors[] = "Manual command: <code>chmod 755 " . htmlspecialchars($uploads_dir) . "</code>";
    }
    if (!$research_writable) {
        $errors[] = "✗ 'uploads/research_outputs' directory is not writable";
        $errors[] = "Manual command: <code>chmod 755 " . htmlspecialchars($research_outputs_dir) . "</code>";
    }
}

// Step 4: Check web server user
$web_user = function_exists('posix_getpwuid') ? posix_getpwuid(posix_geteuid())['name'] : 'unknown';
echo "<div class='info'><strong>Web Server User:</strong> " . htmlspecialchars($web_user) . "</div>";

if ($web_user !== 'unknown') {
    echo "<div class='warning'>
            <strong>Note:</strong> If you created directories manually via SSH, you may need to change ownership:<br>
            <code>sudo chown -R " . htmlspecialchars($web_user) . ":" . htmlspecialchars($web_user) . " " . htmlspecialchars($uploads_dir) . "</code>
          </div>";
}

// Display results
foreach ($messages as $msg) {
    echo "<div class='success'>" . htmlspecialchars($msg) . "</div>";
}

foreach ($errors as $err) {
    echo "<div class='error'>" . $err . "</div>";
}

// Step 5: Test file creation
if (empty($errors)) {
    $test_file = $research_outputs_dir . '/test_' . time() . '.txt';
    if (@file_put_contents($test_file, 'Test file created at ' . date('Y-m-d H:i:s'))) {
        $messages[] = "✓ Test file creation successful";
        @unlink($test_file); // Clean up test file
        echo "<div class='success'>
                <strong>🎉 SUCCESS!</strong> All directories are set up correctly and writable.<br>
                You can now upload research outputs.
              </div>";
        echo "<a href='facultyresearcher.php' class='btn'>Go to Faculty Researchers</a>";
    } else {
        $errors[] = "✗ Test file creation failed";
        echo "<div class='error'>
                <strong>Test Failed:</strong> Unable to create test file in the directory.
              </div>";
    }
}

// Display directory structure
echo "<h2>📂 Directory Structure</h2>";
echo "<div class='info'>";
echo "<pre>";
echo "ResearchManagementSystem/\n";
echo "├── uploads/\n";
echo "│   └── research_outputs/\n";
echo "│       └── (uploaded files will be stored here)\n";
echo "</pre>";
echo "</div>";

// Final instructions
if (!empty($errors)) {
    echo "<h2>🔧 Manual Setup Instructions</h2>";
    echo "<div class='warning'>";
    echo "<p><strong>If automatic setup failed, run these commands via SSH:</strong></p>";
    echo "<ol>";
    echo "<li>Navigate to your project directory:<br><code>cd /var/www/html/ResearchManagementSystem</code></li>";
    echo "<li>Create directories:<br><code>mkdir -p uploads/research_outputs</code></li>";
    echo "<li>Set permissions:<br><code>chmod 755 uploads uploads/research_outputs</code></li>";
    echo "<li>Set owner (replace www-data if needed):<br><code>sudo chown -R www-data:www-data uploads</code></li>";
    echo "</ol>";
    echo "</div>";
}

echo "
        <div style='margin-top: 30px; padding-top: 20px; border-top: 2px solid #ddd;'>
            <p><strong>Security Note:</strong> The script only checks permissions. For production environments, ensure proper security measures are in place.</p>
            <p><strong>Tip:</strong> You can delete this <code>setup_uploads.php</code> file after successful setup.</p>
        </div>
    </div>
</body>
</html>";
?>
