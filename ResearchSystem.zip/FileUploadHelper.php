<?php
/**
 * FileUploadHelper.php
 * Safe file upload handling with automatic cleanup on failure
 */

require_once 'config.php';

class FileUploadHelper {
    private $uploadDir;
    private $allowedExtensions;
    private $maxFileSize;
    private $uploadedFiles = []; // Track uploaded files for cleanup
    
    public function __construct($uploadDir = null) {
        $this->uploadDir = $uploadDir ?? UPLOAD_DIR;
        $this->allowedExtensions = ALLOWED_FILE_EXTENSIONS;
        $this->maxFileSize = MAX_UPLOAD_SIZE;
        
        // Ensure upload directory exists
        $this->ensureDirectoryExists();
    }
    
    /**
     * Ensure upload directory exists with proper permissions
     */
    private function ensureDirectoryExists() {
        if (!is_dir($this->uploadDir)) {
            if (!mkdir($this->uploadDir, 0755, true)) {
                throw new Exception("Failed to create upload directory: " . $this->uploadDir);
            }
            debugLog("[FileUpload] Created upload directory", ['dir' => $this->uploadDir]);
        }
        
        if (!is_writable($this->uploadDir)) {
            throw new Exception("Upload directory is not writable: " . $this->uploadDir);
        }
    }
    
    /**
     * Validate uploaded file
     */
    public function validateFile($file) {
        return validateFileUpload($file);
    }
    
    /**
     * Upload file with automatic cleanup on failure
     * 
     * @param array $file $_FILES array
     * @param string $prefix Filename prefix (e.g., 'output_123_')
     * @return array ['success' => bool, 'path' => string, 'filename' => string, 'error' => string]
     */
    public function uploadFile($file, $prefix = '') {
        try {
            // Validate file
            $validation = $this->validateFile($file);
            
            if (!$validation['valid']) {
                return [
                    'success' => false,
                    'error' => implode('; ', $validation['errors'])
                ];
            }
            
            // Generate unique filename
            $extension = $validation['extension'];
            $originalFilename = $file['name'];
            $safeFilename = $this->generateSafeFilename($prefix, $extension);
            
            $fullPath = $this->uploadDir . $safeFilename;
            $relativePath = 'uploads/research_outputs/' . $safeFilename;
            
            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
                throw new Exception("Failed to move uploaded file");
            }
            
            // Track uploaded file for potential cleanup
            $this->uploadedFiles[] = $fullPath;
            
            debugLog("[FileUpload] File uploaded successfully", [
                'original' => $originalFilename,
                'saved_as' => $safeFilename
            ]);
            
            return [
                'success' => true,
                'path' => $fullPath,
                'relative_path' => $relativePath,
                'filename' => $safeFilename,
                'original_filename' => $originalFilename,
                'size' => $file['size']
            ];
            
        } catch (Exception $e) {
            errorLog("[FileUpload] Upload failed", ['error' => $e->getMessage()]);
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Generate safe filename
     */
    private function generateSafeFilename($prefix, $extension) {
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        
        // Sanitize prefix
        $prefix = preg_replace('/[^a-zA-Z0-9_-]/', '_', $prefix);
        
        return $prefix . $timestamp . '_' . $random . '.' . $extension;
    }
    
    /**
     * Delete file safely
     */
    public function deleteFile($filePath) {
        try {
            // Security check - ensure file is in upload directory
            $realPath = realpath($filePath);
            $realUploadDir = realpath($this->uploadDir);
            
            if (!$realPath || !$realUploadDir) {
                throw new Exception("Invalid file path");
            }
            
            if (strpos($realPath, $realUploadDir) !== 0) {
                throw new Exception("File is outside upload directory");
            }
            
            if (file_exists($realPath)) {
                if (unlink($realPath)) {
                    debugLog("[FileUpload] File deleted", ['path' => $filePath]);
                    return true;
                } else {
                    throw new Exception("Failed to delete file");
                }
            }
            
            return true; // File doesn't exist, consider it deleted
            
        } catch (Exception $e) {
            errorLog("[FileUpload] Delete failed", ['path' => $filePath, 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    /**
     * Cleanup all tracked uploaded files (call on transaction rollback)
     */
    public function cleanupUploads() {
        $cleanedCount = 0;
        
        foreach ($this->uploadedFiles as $filePath) {
            if ($this->deleteFile($filePath)) {
                $cleanedCount++;
            }
        }
        
        if ($cleanedCount > 0) {
            debugLog("[FileUpload] Cleaned up uploaded files", ['count' => $cleanedCount]);
        }
        
        $this->uploadedFiles = [];
        return $cleanedCount;
    }
    
    /**
     * Commit uploads (clear tracking, keeping files)
     */
    public function commitUploads() {
        $count = count($this->uploadedFiles);
        $this->uploadedFiles = [];
        
        if ($count > 0) {
            debugLog("[FileUpload] Committed uploads", ['count' => $count]);
        }
        
        return $count;
    }
    
    /**
     * Get file info
     */
    public function getFileInfo($filePath) {
        $realPath = realpath($filePath);
        
        if (!$realPath || !file_exists($realPath)) {
            return null;
        }
        
        return [
            'path' => $realPath,
            'filename' => basename($realPath),
            'size' => filesize($realPath),
            'extension' => pathinfo($realPath, PATHINFO_EXTENSION),
            'mime_type' => mime_content_type($realPath),
            'modified' => filemtime($realPath)
        ];
    }
    
    /**
     * Clean up old files (maintenance function)
     */
    public static function cleanupOldFiles($uploadDir, $daysOld = 90) {
        $cutoffTime = time() - ($daysOld * 86400);
        $deletedCount = 0;
        
        if (!is_dir($uploadDir)) {
            return 0;
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploadDir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if ($file->isFile() && $file->getMTime() < $cutoffTime) {
                // Check if file is referenced in database
                // This requires database connection - implement based on your needs
                
                // For now, just log old files
                debugLog("[FileUpload] Old file found", [
                    'path' => $file->getPathname(),
                    'age_days' => floor((time() - $file->getMTime()) / 86400)
                ]);
            }
        }
        
        return $deletedCount;
    }
    
    /**
     * Find orphaned files (files not in database)
     */
    public static function findOrphanedFiles($conn, $uploadDir) {
        $orphaned = [];
        
        if (!is_dir($uploadDir)) {
            return $orphaned;
        }
        
        // Get all file paths from database
        $dbFiles = [];
        
        // Faculty research outputs
        $result = $conn->query("SELECT file_path FROM faculty_research_outputs");
        while ($row = $result->fetch_assoc()) {
            $dbFiles[] = basename($row['file_path']);
        }
        
        // Student research outputs
        $result = $conn->query("SELECT file_path FROM student_research_outputs");
        while ($row = $result->fetch_assoc()) {
            $dbFiles[] = basename($row['file_path']);
        }
        
        // Check files in upload directory
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploadDir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if ($file->isFile()) {
                $filename = $file->getFilename();
                
                if (!in_array($filename, $dbFiles)) {
                    $orphaned[] = [
                        'path' => $file->getPathname(),
                        'filename' => $filename,
                        'size' => $file->getSize(),
                        'modified' => date('Y-m-d H:i:s', $file->getMTime())
                    ];
                }
            }
        }
        
        return $orphaned;
    }
}

/**
 * Usage Example with Transaction Safety:
 * 
 * $fileHelper = new FileUploadHelper();
 * $conn->begin_transaction();
 * 
 * try {
 *     // Upload file
 *     $upload = $fileHelper->uploadFile($_FILES['file'], 'project_123_');
 *     
 *     if (!$upload['success']) {
 *         throw new Exception($upload['error']);
 *     }
 *     
 *     // Insert database record
 *     $stmt = $conn->prepare("INSERT INTO outputs (file_path, ...) VALUES (?, ...)");
 *     $stmt->execute(...);
 *     
 *     // Commit both database and file
 *     $conn->commit();
 *     $fileHelper->commitUploads();
 *     
 * } catch (Exception $e) {
 *     // Rollback database
 *     $conn->rollback();
 *     
 *     // Cleanup uploaded files
 *     $fileHelper->cleanupUploads();
 *     
 *     echo "Error: " . $e->getMessage();
 * }
 */