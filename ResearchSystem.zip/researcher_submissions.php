<?php
/**
 * Researcher Submissions Dashboard
 * 
 * This page allows researchers (Faculty, Student, Personnel) to:
 * - View their research submissions
 * - Create new submissions
 * - Edit draft/returned submissions
 * - Submit to coordinator for review
 * - Track submission status
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Access control - must be authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Check if user is a researcher or coordinator (can create submissions)
// Pure admins cannot create submissions - they only manage the system
$isCoordinator = ($userRole === 'coordinator');
$isAdmin = ($userRole === 'admin');
$canAccessSubmissions = $isCoordinator; // Coordinators can always submit

if (!$canAccessSubmissions && !$isAdmin) {
    // Check if user has researcher record linked to their account
    // faculty/personnel use user_id, students use created_by (students don't have user accounts)
    $researcherCheck = $conn->prepare("
        SELECT 'faculty' as type FROM faculty_researchers WHERE user_id = ?
        UNION
        SELECT 'student' as type FROM student_researchers WHERE created_by = ?
        UNION  
        SELECT 'personnel' as type FROM personnel_researchers WHERE user_id = ?
        LIMIT 1
    ");
    $researcherCheck->bind_param("iii", $userId, $userId, $userId);
    $researcherCheck->execute();
    $canAccessSubmissions = $researcherCheck->get_result()->num_rows > 0;
    $researcherCheck->close();
}

// If user is a pure admin (not a researcher), redirect them
if ($isAdmin && !$canAccessSubmissions) {
    if ($isSpa) {
        echo '<div class="alert alert-warning"><i class="fa fa-exclamation-triangle me-2"></i>Administrators manage the system but do not create research submissions. Please use <strong>All Submissions</strong> to review and manage submissions from researchers.</div>';
        exit;
    }
    header("Location: app.php?page=ro_queue");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Initialize services
$submissionService = new SubmissionService($conn);
$workflowEngine = $submissionService->getWorkflowEngine();

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$typeFilter = $_GET['type'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Determine researcher type for badge display
// faculty/personnel use user_id, students use created_by (students don't have user accounts)
$researcherType = 'Researcher';
$researcherTypeQuery = $conn->prepare("
    SELECT 'Faculty' as type FROM faculty_researchers WHERE user_id = ?
    UNION
    SELECT 'Student' as type FROM student_researchers WHERE created_by = ?
    UNION  
    SELECT 'Personnel' as type FROM personnel_researchers WHERE user_id = ?
    LIMIT 1
");
$researcherTypeQuery->bind_param("iii", $userId, $userId, $userId);
$researcherTypeQuery->execute();
$typeResult = $researcherTypeQuery->get_result();
if ($typeRow = $typeResult->fetch_assoc()) {
    $researcherType = $typeRow['type'];
}
$researcherTypeQuery->close();

// Get submissions
$filters = [
    'status' => $statusFilter ?: null,
    'type_id' => $typeFilter ?: null,
    'search' => $searchQuery ?: null
];
$submissions = $submissionService->getResearcherSubmissions($filters, $page, 15);

// Get statistics
$stats = $submissionService->getStatistics('researcher');

// Get submission types for dropdown
$submissionTypes = $submissionService->getSubmissionTypes();

// Determine researcher type based on user role and linked records
function getResearcherType($conn, $userId) {
    // Check if user has a faculty record linked to their account
    $stmt = $conn->prepare("SELECT id FROM faculty_researchers WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        return 'faculty';
    }
    $stmt->close();
    
    // Check for student record - students use created_by (no user accounts)
    $stmt = $conn->prepare("SELECT id FROM student_researchers WHERE created_by = ? LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        return 'student';
    }
    $stmt->close();
    
    // Check for personnel record
    $stmt = $conn->prepare("SELECT id FROM personnel_researchers WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        return 'personnel';
    }
    $stmt->close();
    
    return null;
}

$researcherType = getResearcherType($conn, $userId);

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   MY SUBMISSIONS - UNIFIED DESIGN (Unit Projects Style)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }

.btn-new-submission {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border: none;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.btn-new-submission:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    cursor: pointer;
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-draft { background: linear-gradient(135deg, #f3f4f6, #e5e7eb); color: #6b7280; }
.stat-icon.icon-review { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-revision { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }
.stat-icon.icon-approved { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header-left i { color: #064e1a; font-size: 18px; }

.filter-link {
    font-size: 13px;
    color: #064e1a;
    text-decoration: none;
    font-weight: 500;
}

.filter-link:hover {
    text-decoration: underline;
}

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Submissions Table */
.submissions-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.submissions-table {
    width: 100%;
    border-collapse: collapse;
}

.submissions-table thead th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

/* Column widths */
.submissions-table thead th:nth-child(1) { width: 30%; }
.submissions-table thead th:nth-child(2) { width: 15%; text-align: center; }
.submissions-table thead th:nth-child(3) { width: 12%; text-align: center; }
.submissions-table thead th:nth-child(4) { width: 13%; text-align: center; }
.submissions-table thead th:nth-child(5) { width: 12%; text-align: center; }
.submissions-table thead th:nth-child(6) { width: 18%; text-align: center; }

.submissions-table tbody td {
    padding: 14px 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
}

.submissions-table tbody td:nth-child(2),
.submissions-table tbody td:nth-child(3),
.submissions-table tbody td:nth-child(4),
.submissions-table tbody td:nth-child(5),
.submissions-table tbody td:nth-child(6) {
    text-align: center;
    vertical-align: middle;
}

.submissions-table tbody tr:hover {
    background: #f9fafb;
}

/* Title Cell */
.title-cell { text-align: left; }

.submission-title-link {
    font-weight: 600;
    font-size: 14px;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 6px;
    line-height: 1.4;
}

.submission-title-link:hover { color: #064e1a; }

.submission-code {
    font-size: 11px;
    color: #9ca3af;
    font-family: 'Consolas', monospace;
    display: inline-block;
    background: #f3f4f6;
    padding: 3px 8px;
    border-radius: 4px;
}

/* Submission Info Cell */
.submission-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.meta-ref {
    font-family: 'Consolas', monospace;
    font-size: 11px;
    color: #047857;
    background: #ecfdf5;
    padding: 4px 10px;
    border-radius: 4px;
    font-weight: 600;
    border: 1px solid #a7f3d0;
}

.meta-date {
    font-size: 11px;
    color: #6b7280;
}

/* Type Badge */
.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    background: #f1f5f9;
    color: #475569;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-draft { background: #f3f4f6; color: #6b7280; }
.status-submitted { background: #dbeafe; color: #1e40af; }
.status-review { background: #fef3c7; color: #92400e; }
.status-revision { background: #fee2e2; color: #991b1b; }
.status-endorsed { background: #e0e7ff; color: #5b21b6; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fecaca; color: #991b1b; }

/* Progress Dots */
.progress-dots {
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.p-dot {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 9px;
    background: #f1f5f9;
    color: #94a3b8;
    border: 2px solid #e2e8f0;
}

.p-dot.done {
    background: #ecfdf5;
    color: #047857;
    border-color: #10b981;
}

.p-dot.current {
    background: #fef3c7;
    color: #b45309;
    border-color: #f59e0b;
}

.p-line {
    width: 8px;
    height: 2px;
    background: #e2e8f0;
}

.p-line.done {
    background: #10b981;
}

/* Action Buttons */
.action-btns {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
}

.action-btns .btn {
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
    transition: all 0.15s ease;
    white-space: nowrap;
}

.btn-view { background: #f3f4f6; color: #374151; }
.btn-view:hover { background: #e5e7eb; }

.btn-edit {
    background: #eff6ff;
    color: #1e40af;
    border: 1px solid #bfdbfe;
}
.btn-edit:hover { background: #dbeafe; }

.btn-submit {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
}
.btn-submit:hover { 
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

.btn-project {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
}
.btn-project:hover { 
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
}

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }
.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; }
.pagination .current { background: #064e1a; color: white; }

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Flash Messages */
.flash-message {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: fadeIn 0.3s ease;
}

.flash-message.success {
    background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
    border: 1px solid #10b981;
    color: #065f46;
}

.flash-message.warning {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 1px solid #f59e0b;
    color: #92400e;
}

.flash-message.error,
.flash-message.danger {
    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
    border: 1px solid #ef4444;
    color: #991b1b;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Responsive */
@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 768px) {
    .page-header-banner { padding: 20px; }
    .header-content { flex-direction: column; text-align: center; }
    .header-left { flex-direction: column; }
    .stats-row { flex-wrap: wrap; }
    .stat-card { min-width: calc(50% - 8px); flex: unset; }
    .filter-grid { grid-template-columns: 1fr; }
    .submissions-table thead th:nth-child(3),
    .submissions-table tbody td:nth-child(3),
    .submissions-table thead th:nth-child(5),
    .submissions-table tbody td:nth-child(5) { display: none; }
    .pagination-container { flex-direction: column; gap: 12px; }
}
</style>

<?php
// Display flash messages
if (isset($_SESSION['flash_message'])) {
    $flashType = $_SESSION['flash_type'] ?? 'success';
    $flashIcon = $flashType === 'success' ? 'fa-check-circle' : (($flashType === 'warning') ? 'fa-exclamation-triangle' : 'fa-times-circle');
    echo '<div class="flash-message ' . s($flashType) . '">';
    echo '<i class="fa ' . $flashIcon . '"></i>';
    echo '<span>' . s($_SESSION['flash_message']) . '</span>';
    echo '</div>';
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);
}
?>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa fa-file-lines header-icon"></i>
                <div>
                    <h1>My Submissions</h1>
                    <p>Track and manage your research proposals and reports</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                <span class="role-badge">
                    <i class="fa fa-user-graduate"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    <?= s($researcherType) ?> Researcher
                </span>
                <a href="submission_create.php" class="btn-new-submission">
                    <i class="fa fa-plus"></i> New Submission
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <div class="stats-row">
        <div class="stat-card" onclick="filterByStatus('')">
            <div class="stat-icon icon-total"><i class="fa fa-layer-group"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
                <div class="stat-label">Total</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('draft')">
            <div class="stat-icon icon-draft"><i class="fa fa-edit"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['draft'] ?? 0 ?></div>
                <div class="stat-label">Drafts</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('under_coordinator_review')">
            <div class="stat-icon icon-review"><i class="fa fa-clock"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= ($stats['pending_coordinator'] ?? 0) + ($stats['pending_ro'] ?? 0) ?></div>
                <div class="stat-label">Under Review</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('returned_for_revision')">
            <div class="stat-icon icon-revision"><i class="fa fa-exclamation-triangle"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['returned'] ?? 0 ?></div>
                <div class="stat-label">Revision</div>
            </div>
        </div>
        <div class="stat-card" onclick="filterByStatus('approved')">
            <div class="stat-icon icon-approved"><i class="fa fa-check-circle"></i></div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['approved'] ?? 0 ?></div>
                <div class="stat-label">Approved</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <div class="filter-header-left">
                <i class="fa fa-filter"></i>
            </div>
            <a href="researcher_submissions.php" class="filter-link">Filter Submissions</a>
        </div>
        
        <form id="filterForm" method="GET">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status" onchange="this.form.submit()">
                        <option value="">All Statuses</option>
                        <option value="draft" <?= $statusFilter === 'draft' ? 'selected' : '' ?>>Draft</option>
                        <option value="submitted" <?= $statusFilter === 'submitted' ? 'selected' : '' ?>>Submitted</option>
                        <option value="under_coordinator_review" <?= $statusFilter === 'under_coordinator_review' ? 'selected' : '' ?>>Under Review</option>
                        <option value="returned_for_revision" <?= $statusFilter === 'returned_for_revision' ? 'selected' : '' ?>>Returned</option>
                        <option value="endorsed" <?= $statusFilter === 'endorsed' ? 'selected' : '' ?>>Endorsed</option>
                        <option value="approved" <?= $statusFilter === 'approved' ? 'selected' : '' ?>>Approved</option>
                        <option value="rejected" <?= $statusFilter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Type</label>
                    <select name="type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <?php foreach ($submissionTypes as $type): ?>
                            <option value="<?= $type['id'] ?>" <?= $typeFilter == $type['id'] ? 'selected' : '' ?>>
                                <?= s($type['type_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by title, reference..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-actions">
                    <?php if ($statusFilter || $typeFilter || $searchQuery): ?>
                        <a href="researcher_submissions.php" class="clear-btn" title="Clear Filters">
                            <i class="fa fa-times"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Submissions Table -->
    <div class="submissions-table-container">
        <?php if (empty($submissions['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-inbox"></i>
                <h3>No Submissions Found</h3>
                <p>You haven't created any research submissions yet.</p>
            </div>
        <?php else: ?>
            <table class="submissions-table">
                <thead>
                    <tr>
                        <th>Submission</th>
                        <th>Reference</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Progress</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions['data'] as $sub): ?>
                        <?php
                        // Workflow states
                        $step1 = in_array($sub['status'], ['submitted', 'under_coordinator_review', 'endorsed', 'under_ro_review', 'approved', 'rejected']) ? 'done' : ($sub['status'] === 'draft' ? 'current' : '');
                        $step2 = in_array($sub['status'], ['endorsed', 'under_ro_review', 'approved', 'rejected']) ? 'done' : (in_array($sub['status'], ['submitted', 'under_coordinator_review']) ? 'current' : '');
                        $step3 = in_array($sub['status'], ['approved', 'rejected']) ? 'done' : (in_array($sub['status'], ['endorsed', 'under_ro_review']) ? 'current' : '');
                        $step4 = $sub['status'] === 'approved' ? 'done' : '';
                        ?>
                        <tr>
                            <!-- Column 1: Title -->
                            <td class="title-cell">
                                <a href="submission_view.php?id=<?= $sub['id'] ?>" class="submission-title-link"><?= s($sub['title']) ?></a>
                                <span class="submission-code"><?= date('M d, Y', strtotime($sub['created_at'])) ?></span>
                            </td>
                            
                            <!-- Column 2: Reference -->
                            <td>
                                <div class="submission-info">
                                    <?php if (!empty($sub['reference_number'])): ?>
                                        <span class="meta-ref"><?= s($sub['reference_number']) ?></span>
                                    <?php else: ?>
                                        <span style="color: #9ca3af;">—</span>
                                    <?php endif; ?>
                                    <?php if ($sub['revision_count'] > 0): ?>
                                        <span class="meta-date"><i class="fa fa-history"></i> <?= $sub['revision_count'] ?> rev</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            
                            <!-- Column 3: Type -->
                            <td>
                                <span class="type-badge"><?= s($sub['type_name']) ?></span>
                            </td>
                            
                            <!-- Column 4: Status -->
                            <td>
                                <span class="status-badge <?= s($sub['status_class']) ?>"><?= s($sub['status_label']) ?></span>
                            </td>
                            
                            <!-- Column 5: Progress -->
                            <td>
                                <div class="progress-dots">
                                    <span class="p-dot <?= $step1 ?>" title="Draft"><i class="fa fa-file"></i></span>
                                    <span class="p-line <?= $step1 === 'done' ? 'done' : '' ?>"></span>
                                    <span class="p-dot <?= $step2 ?>" title="Coordinator"><i class="fa fa-user"></i></span>
                                    <span class="p-line <?= $step2 === 'done' ? 'done' : '' ?>"></span>
                                    <span class="p-dot <?= $step3 ?>" title="RO"><i class="fa fa-building"></i></span>
                                    <span class="p-line <?= $step3 === 'done' ? 'done' : '' ?>"></span>
                                    <span class="p-dot <?= $step4 ?>" title="Done"><i class="fa fa-check"></i></span>
                                </div>
                            </td>
                            
                            <!-- Column 6: Actions -->
                            <td>
                                <div class="action-btns">
                                    <?php if (in_array($sub['status'], ['draft', 'returned_for_revision'])): ?>
                                        <a href="submission_edit.php?id=<?= $sub['id'] ?>" class="btn btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                        <button class="btn btn-submit" onclick="submitToCoordinator(<?= $sub['id'] ?>)"><i class="fa fa-paper-plane"></i></button>
                                    <?php elseif ($sub['status'] === 'approved' && !empty($sub['project_status'])): ?>
                                        <a href="project_view.php?id=<?= $sub['id'] ?>" class="btn btn-project" onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $sub['id'] ?>',true)}"><i class="fa fa-eye"></i> View</a>
                                    <?php else: ?>
                                        <a href="submission_view.php?id=<?= $sub['id'] ?>" class="btn btn-view"><i class="fa fa-eye"></i> View</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <div class="pagination-container">
                <div class="pagination-info">
                    Showing <?= count($submissions['data']) ?> of <?= $submissions['total'] ?? count($submissions['data']) ?> submissions
                </div>
                
                <?php if ($submissions['total_pages'] > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>">
                                <i class="fa fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($submissions['total_pages'], $page + 2); $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $submissions['total_pages']): ?>
                            <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&type=<?= s($typeFilter) ?>&q=<?= s($searchQuery) ?>">
                                <i class="fa fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Filter by clicking stat cards
function filterByStatus(status) {
    const form = document.getElementById('filterForm');
    const statusSelect = form.querySelector('select[name="status"]');
    statusSelect.value = status;
    form.submit();
}

// Debounce search input
let searchTimeout = null;
document.querySelector('input[name="q"]').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        document.getElementById('filterForm').submit();
    }, 500);
});

// Submit to coordinator
async function submitToCoordinator(submissionId) {
    if (!confirm('Submit this research to your coordinator for review?\n\nOnce submitted, you will not be able to edit it unless it is returned for revision.')) {
        return;
    }
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'submit',
                id: submissionId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ ' + (result.message || 'Submission sent to coordinator!'));
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred while submitting');
    }
}
</script>
