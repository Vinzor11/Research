<?php
/**
 * Admin UI: OAuth / SSO Settings
 * Manage OAuth credentials and SSO toggle without editing config or .env.
 */
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    if (isset($_SESSION['user_id'])) {
        header("Location: research.php");
    } else {
        header("Location: login.php");
    }
    exit;
}

require 'db.php';
require 'config.php';
require_once 'spa_helper.php';

$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'Admin';

// Handle form save BEFORE SPA redirect check (POST must be processed first!)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $provider_url = trim($_POST['provider_url'] ?? '');
    $client_id = trim($_POST['client_id'] ?? '');
    $client_secret = trim($_POST['client_secret'] ?? '');
    $redirect_uri = trim($_POST['redirect_uri'] ?? '');
    $enabled = isset($_POST['enabled']) ? '1' : '0';

    $errors = [];
    if (empty($provider_url)) {
        $errors[] = 'OAuth Provider URL is required.';
    } elseif (!preg_match('#^https?://#', $provider_url)) {
        $errors[] = 'OAuth Provider URL must start with http:// or https://';
    }
    if (empty($client_id)) {
        $errors[] = 'Client ID is required.';
    }
    if (empty($redirect_uri)) {
        $errors[] = 'Redirect URI is required.';
    } elseif (!preg_match('#^https?://#', $redirect_uri)) {
        $errors[] = 'Redirect URI must start with http:// or https://';
    }

    if (!empty($errors)) {
        $_SESSION['oauth_flash_message'] = implode(' ', $errors);
        $_SESSION['oauth_flash_type'] = 'error';
    } else {
        try {
            $update = $conn->prepare("INSERT INTO oauth_settings (`key`, value, is_secret) VALUES (?, ?, 0) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = CURRENT_TIMESTAMP");
            $update->bind_param("ss", $k, $v);

            $k = 'provider_url'; $v = $provider_url; $update->execute();
            $k = 'client_id'; $v = $client_id; $update->execute();
            $k = 'redirect_uri'; $v = $redirect_uri; $update->execute();
            $k = 'enabled'; $v = $enabled; $update->execute();
            $update->close();

            if ($client_secret !== '') {
                $stmt = $conn->prepare("INSERT INTO oauth_settings (`key`, value, is_secret) VALUES ('client_secret', ?, 1) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = CURRENT_TIMESTAMP");
                $stmt->bind_param("s", $client_secret);
                $stmt->execute();
                $stmt->close();
            }

            $_SESSION['oauth_flash_message'] = 'SSO settings saved successfully. Changes apply to the next login.';
            $_SESSION['oauth_flash_type'] = 'success';
        } catch (Exception $e) {
            $_SESSION['oauth_flash_message'] = 'Failed to save settings: ' . htmlspecialchars($e->getMessage());
            $_SESSION['oauth_flash_type'] = 'error';
        }
    }
    
    // Redirect to prevent form resubmission and ensure SPA loads properly
    header('Location: app.php?load=oauth_settings.php');
    exit;
}

// Now check for SPA mode (after POST handling)
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly (GET requests only at this point)
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$message = '';
$messageType = '';

// Check for flash messages from previous request (after redirect)
if (isset($_SESSION['oauth_flash_message'])) {
    $message = $_SESSION['oauth_flash_message'];
    $messageType = $_SESSION['oauth_flash_type'] ?? 'success';
    unset($_SESSION['oauth_flash_message'], $_SESSION['oauth_flash_type']);
}

// Load current settings (from DB or constants)
$settings = getOAuthConfig($conn);
// Never expose client_secret in UI; use placeholder for form
$settingsDisplay = $settings;
$settingsDisplay['client_secret'] = ''; // Always show empty; "leave blank to keep current"
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SSO Settings - Research Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="usersStyle.css">
<?php else: ?>
<!-- SPA Mode: Load required styles -->
<link rel="stylesheet" href="usersStyle.css">
<?php endif; ?>
    <style>
        /* OAuth settings page: layout and form */
        .oauth-content { max-width: 720px; margin: 0 auto; }
        .table-section.oauth-card { border-radius: 16px; overflow: visible; }
        .table-section.oauth-card .table-header { padding: 28px 36px 24px; border-bottom: 2px solid var(--gray-100); }
        .table-section.oauth-card .table-title { font-size: 18px; font-weight: 700; }
        .settings-form-body { padding: 32px 36px 40px; }
        .settings-form .form-group { margin-bottom: 26px; }
        .settings-form .form-group:last-of-type { margin-bottom: 0; }
        .settings-form .form-group.checkbox-group { margin-bottom: 28px; padding-top: 4px; }
        .settings-form .form-actions { margin-top: 32px; padding-top: 24px; border-top: 1px solid var(--gray-100); }
        .settings-form label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; color: var(--gray-700); }
        .settings-form input[type="text"],
        .settings-form input[type="password"],
        .settings-form input[type="url"] {
            width: 100%; padding: 12px 14px; border: 2px solid var(--gray-200); border-radius: 10px;
            font-size: 14px; transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .settings-form input[type="text"]:focus,
        .settings-form input[type="password"]:focus,
        .settings-form input[type="url"]:focus {
            outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.12);
        }
        .settings-form .help { font-size: 13px; color: var(--gray-500); margin-top: 6px; line-height: 1.45; }
        .settings-form .checkbox-group { display: flex; align-items: center; gap: 12px; }
        .settings-form .checkbox-group label { margin-bottom: 0; font-weight: 500; cursor: pointer; }
        .settings-form input[type="checkbox"] { width: 20px; height: 20px; flex-shrink: 0; cursor: pointer; accent-color: var(--primary); }
        .settings-form .btn-save {
            padding: 14px 28px; background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white; border: none; border-radius: 10px; font-weight: 600; font-size: 14px; cursor: pointer;
            display: inline-flex; align-items: center; gap: 10px; box-shadow: var(--shadow);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .settings-form .btn-save:hover { transform: translateY(-2px); box-shadow: var(--shadow-lg); opacity: 1; }
        .msg { padding: 14px 18px; border-radius: 10px; margin-bottom: 24px; font-size: 14px; border: 2px solid; }
        .msg.success { background: #d1fae5; color: #065f46; border-color: #34d399; }
        .msg.error { background: #fee2e2; color: #991b1b; border-color: #f87171; }
    </style>
</style>
<link rel="stylesheet" href="page-common.css">
<?php if (!$isSpa): ?>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <a href="users.php"><i class="fa fa-users-gear"></i> User Management</a>
        <a href="oauth_settings.php" class="active"><i class="fa fa-key"></i> SSO Settings</a>
        <a href="assign_coordinators.php"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
        <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>

<div class="main">
<?php endif; ?>

    <div class="content">
        <!-- Page Header Banner -->
        <div class="page-header-banner">
            <div class="header-content">
                <div class="header-left">
                    <i class="fa fa-key header-icon"></i>
                    <div>
                        <h1>SSO / OAuth Settings</h1>
                        <p>Configure Single Sign-On integration with HR System</p>
                    </div>
                </div>
                <div class="header-right">
                    <span class="role-badge-new" style="background: rgba(255,255,255,0.95); color: #065f46;">
                        <i class="fa fa-shield-halved"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        Admin
                    </span>
                </div>
            </div>
        </div>
        <div class="oauth-content">
            <?php if ($message): ?>
                <div class="msg <?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <div class="table-section oauth-card">
                <div class="table-header">
                    <div class="table-title"><i class="fa fa-cog"></i> OAuth Configuration</div>
                </div>
                <div class="settings-form-body">
                    <form method="post" action="oauth_settings.php" class="settings-form" data-no-spa="true">
                        <div class="form-group">
                            <label for="provider_url">OAuth Provider URL</label>
                            <input type="url" id="provider_url" name="provider_url" value="<?= htmlspecialchars($settingsDisplay['provider_url']) ?>" placeholder="https://hr.example.com" required>
                            <div class="help">Base URL of your HR system (e.g. https://hr-production-eaf1.up.railway.app)</div>
                        </div>
                        <div class="form-group">
                            <label for="client_id">Client ID</label>
                            <input type="text" id="client_id" name="client_id" value="<?= htmlspecialchars($settingsDisplay['client_id']) ?>" required>
                            <div class="help">From HR admin → OAuth clients</div>
                        </div>
                        <div class="form-group">
                            <label for="client_secret">Client Secret</label>
                            <input type="password" id="client_secret" name="client_secret" value="" placeholder="Leave blank to keep current" autocomplete="new-password">
                            <div class="help">Never shown after save. Leave blank to keep the existing secret.</div>
                        </div>
                        <div class="form-group">
                            <label for="redirect_uri">Redirect URI (Callback URL)</label>
                            <input type="url" id="redirect_uri" name="redirect_uri" value="<?= htmlspecialchars($settingsDisplay['redirect_uri']) ?>" placeholder="https://your-domain.com/oauth_callback.php" required>
                            <div class="help">Must match exactly what is registered in the HR OAuth client</div>
                        </div>
                        <div class="form-group checkbox-group">
                            <input type="checkbox" id="enabled" name="enabled" value="1" <?= $settingsDisplay['enabled'] ? 'checked' : '' ?>>
                            <label for="enabled">Enable "Sign in with HR System" on login page</label>
                        </div>
                        <div class="form-group form-actions">
                            <button type="submit" class="btn-save"><i class="fa fa-save"></i> Save OAuth Settings</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php if (!$isSpa): ?>
</div>
<?php endif; ?>

<?php if (!$isSpa): ?>
</body>
</html>
<?php endif; ?>
