<?php
/**
 * admin_management.php
 * 
 * Research Office Admin Management Interface
 * Manages Director, Assistant Director, and authorized RMIS staff
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Only super admin or director can access this page
$userRole = $_SESSION['user_role'] ?? '';
if (!in_array($userRole, ['admin', 'research_director'])) {
    header('HTTP/1.1 403 Forbidden');
    echo 'Access denied. Only system administrators can manage Research Office staff.';
    exit;
}

// $conn is already available from db.php
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_admin':
            $userId = intval($_POST['user_id'] ?? 0);
            $adminRole = trim($_POST['admin_role'] ?? '');
            $canApprove = isset($_POST['can_approve']) ? 1 : 0;
            $canReject = isset($_POST['can_reject']) ? 1 : 0;
            $canClassify = isset($_POST['can_classify']) ? 1 : 0;
            $canGenerateReports = isset($_POST['can_generate_reports']) ? 1 : 0;
            
            if (!$userId || !$adminRole) {
                $error = 'User and role are required.';
            } else {
                // Check if user exists
                $checkUser = $conn->prepare("SELECT id, full_name FROM users WHERE id = ?");
                $checkUser->bind_param("i", $userId);
                $checkUser->execute();
                $userResult = $checkUser->get_result()->fetch_assoc();
                
                if (!$userResult) {
                    $error = 'User not found.';
                } else {
                    // Check if already an admin
                    $checkAdmin = $conn->prepare("SELECT id FROM research_office_admins WHERE user_id = ?");
                    $checkAdmin->bind_param("i", $userId);
                    $checkAdmin->execute();
                    
                    if ($checkAdmin->get_result()->num_rows > 0) {
                        $error = 'This user is already a Research Office administrator.';
                    } else {
                        // Insert new admin
                        $stmt = $conn->prepare("
                            INSERT INTO research_office_admins 
                            (user_id, role, can_approve, can_reject, can_classify, can_generate_reports, assigned_by, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                        ");
                        $assignedBy = $_SESSION['user_id'];
                        $stmt->bind_param("isiiiis", $userId, $adminRole, $canApprove, $canReject, $canClassify, $canGenerateReports, $assignedBy);
                        
                        if ($stmt->execute()) {
                            $message = "Successfully added {$userResult['full_name']} as Research Office administrator.";
                            
                            // Log the action
                            $logStmt = $conn->prepare("
                                INSERT INTO activity_log (user_id, action, details, created_at)
                                VALUES (?, 'add_ro_admin', ?, NOW())
                            ");
                            $details = json_encode(['added_user_id' => $userId, 'role' => $adminRole]);
                            $logStmt->bind_param("is", $_SESSION['user_id'], $details);
                            $logStmt->execute();
                        } else {
                            $error = 'Failed to add administrator. Please try again.';
                        }
                    }
                }
            }
            break;
            
        case 'update_admin':
            $adminId = intval($_POST['admin_id'] ?? 0);
            $adminRole = trim($_POST['admin_role'] ?? '');
            $canApprove = isset($_POST['can_approve']) ? 1 : 0;
            $canReject = isset($_POST['can_reject']) ? 1 : 0;
            $canClassify = isset($_POST['can_classify']) ? 1 : 0;
            $canGenerateReports = isset($_POST['can_generate_reports']) ? 1 : 0;
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            
            if (!$adminId) {
                $error = 'Administrator ID is required.';
            } else {
                $stmt = $conn->prepare("
                    UPDATE research_office_admins 
                    SET role = ?, can_approve = ?, can_reject = ?, can_classify = ?, 
                        can_generate_reports = ?, is_active = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->bind_param("siiiiii", $adminRole, $canApprove, $canReject, $canClassify, $canGenerateReports, $isActive, $adminId);
                
                if ($stmt->execute()) {
                    $message = 'Administrator permissions updated successfully.';
                } else {
                    $error = 'Failed to update administrator.';
                }
            }
            break;
            
        case 'remove_admin':
            $adminId = intval($_POST['admin_id'] ?? 0);
            
            if (!$adminId) {
                $error = 'Administrator ID is required.';
            } else {
                // Soft delete - just deactivate
                $stmt = $conn->prepare("UPDATE research_office_admins SET is_active = 0, updated_at = NOW() WHERE id = ?");
                $stmt->bind_param("i", $adminId);
                
                if ($stmt->execute()) {
                    $message = 'Administrator has been deactivated.';
                } else {
                    $error = 'Failed to remove administrator.';
                }
            }
            break;
    }
}

// Fetch current admins
$admins = [];
$adminQuery = $conn->query("
    SELECT roa.*, u.full_name, u.email, u.profile_picture,
           assigned.full_name as assigned_by_name
    FROM research_office_admins roa
    JOIN users u ON roa.user_id = u.id
    LEFT JOIN users assigned ON roa.assigned_by = assigned.id
    ORDER BY 
        CASE roa.role 
            WHEN 'director' THEN 1 
            WHEN 'assistant_director' THEN 2 
            ELSE 3 
        END,
        roa.created_at DESC
");
while ($row = $adminQuery->fetch_assoc()) {
    $admins[] = $row;
}

// Fetch available users (not already admins)
$availableUsers = [];
$userQuery = $conn->query("
    SELECT u.id, u.full_name, u.email, u.role 
    FROM users u
    WHERE u.id NOT IN (SELECT user_id FROM research_office_admins WHERE is_active = 1)
    AND u.status = 'active'
    ORDER BY u.full_name
");
while ($row = $userQuery->fetch_assoc()) {
    $availableUsers[] = $row;
}

// Statistics
$stats = [
    'total_admins' => 0,
    'active_admins' => 0,
    'pending_submissions' => 0,
    'approved_this_month' => 0
];

$result = $conn->query("SELECT COUNT(*) as count FROM research_office_admins");
$stats['total_admins'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM research_office_admins WHERE is_active = 1");
$stats['active_admins'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM research_submissions WHERE status = 'endorsed'");
$stats['pending_submissions'] = $result->fetch_assoc()['count'] ?? 0;

$result = $conn->query("
    SELECT COUNT(*) as count FROM research_submissions 
    WHERE status = 'approved' 
    AND approved_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
");
$stats['approved_this_month'] = $result->fetch_assoc()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Research Office Admin Management - RMIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1a472a;
            --secondary-color: #2d5a3d;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            position: fixed;
            width: 280px;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 2rem;
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stat-card .icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .admin-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: box-shadow 0.2s;
        }
        
        .admin-card:hover {
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .admin-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .role-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .role-director {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .role-assistant_director {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .role-staff {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .permission-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
            display: inline-block;
        }
        
        .permission-active {
            background: #d4edda;
            color: #155724;
        }
        
        .permission-inactive {
            background: #f8d7da;
            color: #721c24;
            text-decoration: line-through;
        }
        
        .form-section {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-white">
            <h5 class="mb-1">
                <i class="bi bi-mortarboard-fill me-2"></i>ESSU
            </h5>
            <small>Research Management System</small>
        </div>
        <hr class="text-white-50 mx-3">
        <nav class="px-3">
            <a href="researcher_dashboard.php" class="btn btn-outline-light w-100 text-start mb-2">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
            <a href="research_office_queue.php" class="btn btn-outline-light w-100 text-start mb-2">
                <i class="bi bi-inbox me-2"></i>Submissions Queue
            </a>
            <a href="rmis_reports.php" class="btn btn-outline-light w-100 text-start mb-2">
                <i class="bi bi-file-earmark-text me-2"></i>RMIS Reports
            </a>
            <a href="admin_management.php" class="btn btn-light w-100 text-start mb-2">
                <i class="bi bi-people me-2"></i>Admin Management
            </a>
            <a href="logout.php" class="btn btn-outline-danger w-100 text-start mt-4">
                <i class="bi bi-box-arrow-right me-2"></i>Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="mb-1">Research Office Administration</h2>
                    <p class="text-muted mb-0">Manage Research Office staff and permissions</p>
                </div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                    <i class="bi bi-person-plus me-2"></i>Add Administrator
                </button>
            </div>

            <!-- Alerts -->
            <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="row g-4 mb-4">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="icon bg-primary bg-opacity-10 text-primary me-3">
                                <i class="bi bi-people"></i>
                            </div>
                            <div>
                                <h3 class="mb-0"><?= $stats['active_admins'] ?></h3>
                                <small class="text-muted">Active Administrators</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="icon bg-warning bg-opacity-10 text-warning me-3">
                                <i class="bi bi-hourglass-split"></i>
                            </div>
                            <div>
                                <h3 class="mb-0"><?= $stats['pending_submissions'] ?></h3>
                                <small class="text-muted">Pending Review</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="icon bg-success bg-opacity-10 text-success me-3">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <div>
                                <h3 class="mb-0"><?= $stats['approved_this_month'] ?></h3>
                                <small class="text-muted">Approved (This Month)</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="icon bg-info bg-opacity-10 text-info me-3">
                                <i class="bi bi-person-badge"></i>
                            </div>
                            <div>
                                <h3 class="mb-0"><?= $stats['total_admins'] ?></h3>
                                <small class="text-muted">Total Staff Records</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Role Hierarchy Explanation -->
            <div class="form-section mb-4">
                <h5 class="mb-3"><i class="bi bi-diagram-3 me-2"></i>Role Hierarchy</h5>
                <div class="row">
                    <div class="col-md-4">
                        <div class="d-flex align-items-start">
                            <span class="role-badge role-director me-2">Director</span>
                            <small class="text-muted">Full authority over all submissions. Can approve, reject, classify, and generate official RMIS reports. Manages all staff.</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-start">
                            <span class="role-badge role-assistant_director me-2">Asst. Director</span>
                            <small class="text-muted">Can approve, reject, and classify submissions. May generate reports. Acts in Director's absence.</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex align-items-start">
                            <span class="role-badge role-staff me-2">RMIS Staff</span>
                            <small class="text-muted">Authorized staff with configurable permissions. Typically can classify and prepare submissions for final approval.</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Administrator List -->
            <div class="form-section">
                <h5 class="mb-4"><i class="bi bi-person-lines-fill me-2"></i>Research Office Administrators</h5>
                
                <?php if (empty($admins)): ?>
                <div class="text-center text-muted py-5">
                    <i class="bi bi-people display-4"></i>
                    <p class="mt-3">No administrators configured yet.</p>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                        <i class="bi bi-person-plus me-2"></i>Add First Administrator
                    </button>
                </div>
                <?php else: ?>
                
                <?php foreach ($admins as $admin): ?>
                <div class="admin-card <?= !$admin['is_active'] ? 'opacity-50' : '' ?>">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <?php if ($admin['profile_picture']): ?>
                            <img src="<?= htmlspecialchars($admin['profile_picture']) ?>" class="admin-avatar" alt="">
                            <?php else: ?>
                            <div class="admin-avatar">
                                <?= strtoupper(substr($admin['full_name'], 0, 1)) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col">
                            <div class="d-flex align-items-center mb-1">
                                <h5 class="mb-0 me-2"><?= htmlspecialchars($admin['full_name']) ?></h5>
                                <span class="role-badge role-<?= htmlspecialchars($admin['role']) ?>">
                                    <?= ucwords(str_replace('_', ' ', $admin['role'])) ?>
                                </span>
                                <?php if (!$admin['is_active']): ?>
                                <span class="badge bg-secondary ms-2">Inactive</span>
                                <?php endif; ?>
                            </div>
                            <p class="text-muted mb-2">
                                <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($admin['email']) ?>
                            </p>
                            <div class="permissions">
                                <span class="permission-badge <?= $admin['can_approve'] ? 'permission-active' : 'permission-inactive' ?>">
                                    <i class="bi bi-check-lg me-1"></i>Approve
                                </span>
                                <span class="permission-badge <?= $admin['can_reject'] ? 'permission-active' : 'permission-inactive' ?>">
                                    <i class="bi bi-x-lg me-1"></i>Reject
                                </span>
                                <span class="permission-badge <?= $admin['can_classify'] ? 'permission-active' : 'permission-inactive' ?>">
                                    <i class="bi bi-tags me-1"></i>Classify
                                </span>
                                <span class="permission-badge <?= $admin['can_generate_reports'] ? 'permission-active' : 'permission-inactive' ?>">
                                    <i class="bi bi-file-earmark-text me-1"></i>Reports
                                </span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <small class="text-muted d-block mb-2">
                                Added by <?= htmlspecialchars($admin['assigned_by_name'] ?? 'System') ?><br>
                                <?= date('M d, Y', strtotime($admin['created_at'])) ?>
                            </small>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-primary" 
                                        onclick="editAdmin(<?= htmlspecialchars(json_encode($admin)) ?>)">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <?php if ($admin['is_active'] && $admin['user_id'] != $_SESSION['user_id']): ?>
                                <button class="btn btn-sm btn-outline-danger" 
                                        onclick="confirmRemove(<?= $admin['id'] ?>, '<?= htmlspecialchars($admin['full_name']) ?>')">
                                    <i class="bi bi-person-dash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Admin Modal -->
    <div class="modal fade" id="addAdminModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add Research Office Administrator</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_admin">
                        
                        <div class="mb-3">
                            <label class="form-label">Select User <span class="text-danger">*</span></label>
                            <select class="form-select" name="user_id" required>
                                <option value="">-- Select User --</option>
                                <?php foreach ($availableUsers as $user): ?>
                                <option value="<?= $user['id'] ?>">
                                    <?= htmlspecialchars($user['full_name']) ?> (<?= htmlspecialchars($user['email']) ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Only active users not already assigned as administrators are shown.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" name="admin_role" required onchange="updateDefaultPermissions(this)">
                                <option value="">-- Select Role --</option>
                                <option value="director">Director</option>
                                <option value="assistant_director">Assistant Director</option>
                                <option value="staff">RMIS Staff</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Permissions</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_approve" id="canApprove">
                                        <label class="form-check-label" for="canApprove">Can Approve</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_reject" id="canReject">
                                        <label class="form-check-label" for="canReject">Can Reject</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_classify" id="canClassify">
                                        <label class="form-check-label" for="canClassify">Can Classify</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_generate_reports" id="canGenerateReports">
                                        <label class="form-check-label" for="canGenerateReports">Can Generate Reports</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-person-plus me-2"></i>Add Administrator
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Admin Modal -->
    <div class="modal fade" id="editAdminModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Administrator</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update_admin">
                        <input type="hidden" name="admin_id" id="editAdminId">
                        
                        <div class="mb-3">
                            <label class="form-label">Administrator</label>
                            <input type="text" class="form-control" id="editAdminName" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" name="admin_role" id="editAdminRole" required>
                                <option value="director">Director</option>
                                <option value="assistant_director">Assistant Director</option>
                                <option value="staff">RMIS Staff</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Permissions</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_approve" id="editCanApprove">
                                        <label class="form-check-label" for="editCanApprove">Can Approve</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_reject" id="editCanReject">
                                        <label class="form-check-label" for="editCanReject">Can Reject</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_classify" id="editCanClassify">
                                        <label class="form-check-label" for="editCanClassify">Can Classify</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="can_generate_reports" id="editCanGenerateReports">
                                        <label class="form-check-label" for="editCanGenerateReports">Can Generate Reports</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" id="editIsActive">
                                <label class="form-check-label" for="editIsActive">Active</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-lg me-2"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Remove Confirmation Modal -->
    <div class="modal fade" id="removeAdminModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-danger me-2"></i>Confirm Deactivation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="remove_admin">
                        <input type="hidden" name="admin_id" id="removeAdminId">
                        <p>Are you sure you want to deactivate <strong id="removeAdminName"></strong> as a Research Office administrator?</p>
                        <p class="text-muted small">This will revoke their access to approve, reject, and classify submissions. This action can be reversed.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-person-dash me-2"></i>Deactivate
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateDefaultPermissions(select) {
            const role = select.value;
            const canApprove = document.getElementById('canApprove');
            const canReject = document.getElementById('canReject');
            const canClassify = document.getElementById('canClassify');
            const canGenerateReports = document.getElementById('canGenerateReports');
            
            if (role === 'director') {
                canApprove.checked = true;
                canReject.checked = true;
                canClassify.checked = true;
                canGenerateReports.checked = true;
            } else if (role === 'assistant_director') {
                canApprove.checked = true;
                canReject.checked = true;
                canClassify.checked = true;
                canGenerateReports.checked = true;
            } else if (role === 'staff') {
                canApprove.checked = false;
                canReject.checked = false;
                canClassify.checked = true;
                canGenerateReports.checked = false;
            }
        }
        
        function editAdmin(admin) {
            document.getElementById('editAdminId').value = admin.id;
            document.getElementById('editAdminName').value = admin.full_name + ' (' + admin.email + ')';
            document.getElementById('editAdminRole').value = admin.role;
            document.getElementById('editCanApprove').checked = admin.can_approve == 1;
            document.getElementById('editCanReject').checked = admin.can_reject == 1;
            document.getElementById('editCanClassify').checked = admin.can_classify == 1;
            document.getElementById('editCanGenerateReports').checked = admin.can_generate_reports == 1;
            document.getElementById('editIsActive').checked = admin.is_active == 1;
            
            new bootstrap.Modal(document.getElementById('editAdminModal')).show();
        }
        
        function confirmRemove(adminId, adminName) {
            document.getElementById('removeAdminId').value = adminId;
            document.getElementById('removeAdminName').textContent = adminName;
            
            new bootstrap.Modal(document.getElementById('removeAdminModal')).show();
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>
