// ============================================
// MODAL MANAGEMENT FUNCTIONS
// ============================================

/**
 * Open the modal for adding a new research output
 * 
 * Usage Example:
 * <button onclick="openAddResearchModal()">Add Research</button>
 */
function openAddResearchModal() {
    document.getElementById('addResearchModal').style.display = 'block';
}

/**
 * Open the modal for editing an existing research output
 * Populates form fields with current research data
 * 
 * @param {Object} research - Research object containing all research details
 * 
 * Usage Example:
 * const researchData = { id: 1, title: "AI Research", status: "on-going" };
 * openEditResearchModal(researchData);
 * 
 * Or from PHP:
 * <button onclick='openEditResearchModal(<?= json_encode($research) ?>)'>Edit</button>
 */
function openEditResearchModal(research) {
    document.getElementById('edit_id').value = research.id;
    document.getElementById('edit_title').value = research.title || '';
    document.getElementById('edit_project_leader').value = research.project_leader || '';
    document.getElementById('edit_status').value = research.status || 'on-going';
    document.getElementById('edit_project_start').value = research.project_start || '';
    document.getElementById('edit_project_end').value = research.project_end || '';
    document.getElementById('edit_isbn').value = research.isbn || '';
    document.getElementById('edit_tracking_number').value = research.tracking_number || '';
    document.getElementById('editResearchModal').style.display = 'block';
}

/**
 * Open the modal for adding a team member to a research project
 * 
 * @param {number} researchId - ID of the research project
 * 
 * Usage Example:
 * <button onclick="openTeamModal(5)">Add Team Member</button>
 */
function openTeamModal(researchId) {
    document.getElementById('team_research_id').value = researchId;
    document.getElementById('search_student').value = '';
    document.getElementById('teamModal').style.display = 'block';
}

/**
 * Close all open modals
 * 
 * Usage Example:
 * <button onclick="closeModals()">Cancel</button>
 * 
 * Or call programmatically:
 * closeModals(); // Close all modals
 */
function closeModals() {
    document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
}

/**
 * Close modal when clicking outside of modal content
 * Automatically attached to window click event
 * 
 * Usage Example:
 * This function is automatically triggered when user clicks outside modal
 * No manual invocation needed
 */
window.onclick = function(e) {
    if (e.target.classList.contains('modal')) {
        closeModals();
    }
}

// ============================================
// TAB SWITCHING FUNCTION
// ============================================

/**
 * Switch between tabs in project cards
 * Activates the clicked tab and displays corresponding content
 * 
 * @param {Event} event - The click event
 * @param {string} tabId - ID of the tab content to display
 * 
 * Usage Example:
 * <button class="tab" onclick="switchTab(event, 'team-123')">Team</button>
 * <div id="team-123" class="tab-content">Team content here...</div>
 */
function switchTab(event, tabId) {
    const parent = event.target.closest('.project-card');
    
    // Remove active class from all tabs and tab contents
    parent.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    parent.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));
    
    // Add active class to clicked tab and corresponding content
    event.target.classList.add('active');
    document.getElementById(tabId).classList.add('active');
}

// ============================================
// AJAX HELPER FUNCTION
// ============================================

/**
 * Generic AJAX form submission helper
 * Handles form data submission and response parsing
 * 
 * @param {HTMLFormElement} form - The form element to submit
 * @param {Function} callback - Callback function to handle response
 * 
 * Usage Example:
 * const myForm = document.getElementById('myForm');
 * ajaxForm(myForm, function(response) {
 *     if (response.success) {
 *         alert('Success!');
 *     } else {
 *         alert('Error: ' + response.error);
 *     }
 * });
 */
function ajaxForm(form, callback) {
    const formData = new FormData(form);
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(text => {
        console.log('Server response:', text);
        try {
            // Parse JSON response
            const data = JSON.parse(text);
            callback(data);
        } catch (e) {
            // Handle JSON parse errors
            console.error('JSON parse error:', e);
            console.error('Response text:', text);
            alert('Error: Server returned invalid response. Check console for details.');
        }
    })
    .catch(error => {
        // Handle network errors
        console.error('Error:', error);
        alert('Error: ' + error.message);
    });
}

// ============================================
// FORM SUBMISSION HANDLERS
// ============================================

/**
 * Handle add research form submission
 * Validates and submits new research output via AJAX
 * 
 * Usage Example:
 * This is automatically triggered when the form is submitted
 * <form id="addResearchForm">
 *     <input name="title" required>
 *     <button type="submit">Save</button>
 * </form>
 */
document.getElementById('addResearchForm').onsubmit = function(e) {
    e.preventDefault();
    
    // Validate title
    const title = this.title.value.trim();
    if (!title) {
        alert('Please enter a research title.');
        return false;
    }
    
    // Submit form via AJAX
    ajaxForm(this, function(data) {
        if (data.success) {
            alert('Research output added successfully!');
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error'));
        }
    });
    
    return false;
};

/**
 * Handle edit research form submission
 * Updates existing research output via AJAX
 * 
 * Usage Example:
 * This is automatically triggered when the edit form is submitted
 * Form data is populated by openEditResearchModal() function
 */
document.getElementById('editResearchForm').onsubmit = function(e) {
    e.preventDefault();
    
    // Submit form via AJAX
    ajaxForm(this, function(data) {
        if (data.success) {
            alert('Research output updated successfully!');
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error'));
        }
    });
    
    return false;
};

/**
 * Handle add team member form submission
 * Searches for student and adds them to the research team
 * 
 * Usage Example:
 * This is automatically triggered when the team form is submitted
 * User enters student number, email, or name to search
 * Example searches: "2024-00001", "john@email.com", "Juan Dela Cruz"
 */
document.getElementById('teamForm').onsubmit = function(e) {
    e.preventDefault();
    
    // Validate search input
    const searchValue = document.getElementById('search_student').value.trim();
    if (!searchValue) {
        alert('Please enter a student number, name, or email to search');
        return false;
    }
    
    // Submit form via AJAX
    ajaxForm(this, function(data) {
        if (data.success) {
            alert(data.message || 'Team member added successfully and research linked to their profile!');
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Unknown error'));
        }
    });
    
    return false;
};

// ============================================
// DELETE FUNCTIONS
// ============================================

/**
 * Delete a research output
 * Shows confirmation dialog before deletion
 * Also deletes all associated team members
 * 
 * @param {number} id - ID of the research output to delete
 * 
 * Usage Example:
 * <button onclick="deleteResearch(123)">Delete</button>
 * 
 * Or from PHP:
 * <button onclick="deleteResearch(<?= $research['id'] ?>)">Delete</button>
 */
function deleteResearch(id) {
    if (confirm('Are you sure you want to delete this research output?\n\nThis will also delete all team members associated with this research.')) {
        // Prepare form data
        const formData = new FormData();
        formData.append('action', 'delete_research');
        formData.append('id', id);
        
        // Send AJAX request to delete research
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Research output deleted successfully!');
                location.reload();
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error: ' + error.message);
        });
    }
}

/**
 * Delete a team member from a research project
 * Shows confirmation dialog before deletion
 * Also removes the research from the team member's profile
 * 
 * @param {number} id - ID of the team member to delete
 * @param {number} researchId - ID of the research project
 * 
 * Usage Example:
 * <button onclick="deleteTeam(45, 123)">Remove Member</button>
 * 
 * Or from PHP:
 * <button onclick="deleteTeam(<?= $team['id'] ?>, <?= $research['id'] ?>)">Remove</button>
 */
function deleteTeam(id, researchId) {
    if (confirm('Are you sure you want to remove this team member?\n\nThis will also remove the research from their profile.')) {
        // Prepare form data
        const formData = new FormData();
        formData.append('action', 'delete_team');
        formData.append('id', id);
        formData.append('research_id', researchId);
        
        // Send AJAX request to delete team member
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Team member removed successfully!');
                location.reload();
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error: ' + error.message);
        });
    }
}
