<?php
/**
 * RMISFormGenerator.php
 * 
 * Generates official RMIS Forms (A-E) from validated system data
 * 
 * RMIS Forms:
 * - Form A: HEI Profile (Institutional data)
 * - Form B: Research Units (Unit configuration)
 * - Form C: Research Programs (Program aggregation)
 * - Form D: Completed Research Projects
 * - Form D1: Ongoing Research Projects
 * - Form E: Faculty Researchers Profile
 * 
 * These forms are reporting artifacts generated from system data,
 * NOT user input forms.
 * 
 * @version 1.0
 */

class RMISFormGenerator {
    private $conn;
    private $userId;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        if (!isset($_SESSION)) {
            session_start();
        }
        $this->userId = $_SESSION['user_id'] ?? null;
    }
    
    // ========================================
    // FORM A: HEI Profile
    // ========================================
    
    /**
     * Get HEI Profile data for Form A
     */
    public function getFormAData($fiscalYear = null) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        $stmt = $this->conn->prepare("
            SELECT * FROM rmis_hei_profile 
            WHERE fiscal_year = ? OR is_current = 1
            ORDER BY is_current DESC, fiscal_year DESC
            LIMIT 1
        ");
        $stmt->bind_param("s", $fiscalYear);
        $stmt->execute();
        $hei = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$hei) {
            // Return default structure
            $hei = [
                'hei_name' => 'Eastern Samar State University',
                'hei_code' => 'ESSU',
                'hei_type' => 'SUC',
                'region' => 'Region VIII',
                'province' => 'Eastern Samar',
                'municipality' => 'Borongan City',
                'fiscal_year' => $fiscalYear
            ];
        }
        
        // Add summary statistics
        $hei['statistics'] = $this->getHEIStatistics($fiscalYear);
        
        return [
            'form' => 'A',
            'title' => 'HEI Research Profile',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'data' => $hei
        ];
    }
    
    /**
     * Get HEI statistics
     */
    private function getHEIStatistics($fiscalYear) {
        $stats = [];
        
        // Total faculty researchers
        $result = $this->conn->query("SELECT COUNT(*) as count FROM faculty_researchers");
        $stats['total_faculty_researchers'] = $result->fetch_assoc()['count'];
        
        // Total student researchers
        $result = $this->conn->query("SELECT COUNT(*) as count FROM student_researchers");
        $stats['total_student_researchers'] = $result->fetch_assoc()['count'];
        
        // Total approved submissions
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as count FROM research_submissions 
            WHERE status = 'approved' AND fiscal_year LIKE ?
        ");
        $fyPattern = "%$fiscalYear%";
        $stmt->bind_param("s", $fyPattern);
        $stmt->execute();
        $stats['approved_submissions'] = $stmt->get_result()->fetch_assoc()['count'];
        $stmt->close();
        
        // Total research outputs
        $result = $this->conn->query("
            SELECT COUNT(*) as count FROM faculty_research_outputs 
            WHERE output_status = 'accepted'
        ");
        $stats['total_outputs'] = $result->fetch_assoc()['count'];
        
        return $stats;
    }
    
    // ========================================
    // FORM B: Research Units
    // ========================================
    
    /**
     * Get Research Units data for Form B
     */
    public function getFormBData($fiscalYear = null) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        // Get all research units
        $result = $this->conn->query("
            SELECT u.*, 
                   p.unit_name as parent_name,
                   (SELECT COUNT(*) FROM research_submissions rs 
                    WHERE rs.researcher_unit_id = u.hr_unit_id 
                    AND rs.status = 'approved') as approved_count,
                   (SELECT COUNT(*) FROM research_submissions rs 
                    WHERE rs.researcher_unit_id = u.hr_unit_id 
                    AND rs.status IN ('endorsed', 'under_ro_review', 'approved')) as total_submissions
            FROM rmis_research_units u
            LEFT JOIN rmis_research_units p ON u.parent_unit_id = p.id
            WHERE u.is_active = 1
            ORDER BY u.unit_type, u.display_order, u.unit_name
        ");
        
        $units = $result->fetch_all(MYSQLI_ASSOC);
        
        // Group by type
        $grouped = [];
        foreach ($units as $unit) {
            $type = $unit['unit_type'];
            if (!isset($grouped[$type])) {
                $grouped[$type] = [];
            }
            $grouped[$type][] = $unit;
        }
        
        return [
            'form' => 'B',
            'title' => 'Research Units Registry',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'data' => [
                'units' => $units,
                'grouped_by_type' => $grouped,
                'total_units' => count($units)
            ]
        ];
    }
    
    // ========================================
    // FORM C: Research Programs
    // ========================================
    
    /**
     * Get Research Programs data for Form C
     */
    public function getFormCData($fiscalYear = null) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        // Get research programs with aggregated data
        $result = $this->conn->query("
            SELECT rp.*,
                   u.unit_name,
                   (SELECT COUNT(*) FROM research_submissions rs 
                    WHERE rs.research_program = rp.program_name 
                    AND rs.status = 'approved') as project_count,
                   (SELECT COALESCE(SUM(rs.total_budget), 0) FROM research_submissions rs 
                    WHERE rs.research_program = rp.program_name 
                    AND rs.status = 'approved') as total_budget
            FROM rmis_research_programs rp
            LEFT JOIN rmis_research_units u ON rp.unit_id = u.id
            WHERE rp.is_active = 1
            ORDER BY rp.display_order, rp.program_name
        ");
        
        $programs = $result->fetch_all(MYSQLI_ASSOC);
        
        // Calculate totals
        $totalBudget = array_sum(array_column($programs, 'total_budget'));
        $totalProjects = array_sum(array_column($programs, 'project_count'));
        
        return [
            'form' => 'C',
            'title' => 'Research Programs Summary',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'data' => [
                'programs' => $programs,
                'summary' => [
                    'total_programs' => count($programs),
                    'total_projects' => $totalProjects,
                    'total_budget' => $totalBudget
                ]
            ]
        ];
    }
    
    // ========================================
    // FORM D: Completed Research Projects
    // ========================================
    
    /**
     * Get Completed Projects data for Form D
     */
    public function getFormDData($fiscalYear = null, $filters = []) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        $where = ["rs.status = 'approved'"];
        $params = [];
        $types = "";
        
        // Filter by fiscal year if provided
        if ($fiscalYear) {
            $where[] = "rs.fiscal_year LIKE ?";
            $params[] = "%$fiscalYear%";
            $types .= "s";
        }
        
        // Filter by researcher type
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= "s";
        }
        
        // Filter by unit
        if (!empty($filters['unit_id'])) {
            $where[] = "rs.researcher_unit_id = ?";
            $params[] = $filters['unit_id'];
            $types .= "s";
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.title,
                rs.abstract,
                rs.researcher_type,
                rs.researcher_unit_name,
                rs.research_program,
                rs.funding_source,
                rs.fiscal_year,
                rs.total_budget,
                rs.proposed_start_date,
                rs.proposed_end_date,
                rs.actual_start_date,
                rs.actual_end_date,
                rs.decision_at as approved_at,
                rst.type_name as submission_type
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE $whereClause
            ORDER BY rs.decision_at DESC
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $projects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Get researcher info for each project
        foreach ($projects as &$project) {
            $project['researchers'] = $this->getProjectResearchers($project['id'], $project['researcher_type']);
        }
        
        // Calculate summary
        $totalBudget = array_sum(array_column($projects, 'total_budget'));
        
        // Group by funding source
        $byFundingSource = [];
        foreach ($projects as $p) {
            $source = $p['funding_source'] ?: 'Unspecified';
            if (!isset($byFundingSource[$source])) {
                $byFundingSource[$source] = ['count' => 0, 'budget' => 0];
            }
            $byFundingSource[$source]['count']++;
            $byFundingSource[$source]['budget'] += $p['total_budget'] ?? 0;
        }
        
        return [
            'form' => 'D',
            'title' => 'Completed Research Projects (RMIS Form D)',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'filters' => $filters,
            'data' => [
                'projects' => $projects,
                'summary' => [
                    'total_projects' => count($projects),
                    'total_budget' => $totalBudget,
                    'by_funding_source' => $byFundingSource
                ]
            ]
        ];
    }
    
    // ========================================
    // FORM D1: Ongoing Research Projects
    // ========================================
    
    /**
     * Get Ongoing Projects data for Form D1
     */
    public function getFormD1Data($fiscalYear = null, $filters = []) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        // Ongoing = approved but submission_type is 'ongoing' or 'proposal' with active dates
        $where = ["rs.status = 'approved'", "rst.type_code IN ('proposal', 'ongoing')"];
        $params = [];
        $types = "";
        
        if ($fiscalYear) {
            $where[] = "rs.fiscal_year LIKE ?";
            $params[] = "%$fiscalYear%";
            $types .= "s";
        }
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= "s";
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.title,
                rs.abstract,
                rs.researcher_type,
                rs.researcher_unit_name,
                rs.research_program,
                rs.funding_source,
                rs.fiscal_year,
                rs.total_budget,
                rs.proposed_start_date,
                rs.proposed_end_date,
                rs.actual_start_date,
                rs.decision_at as approved_at,
                rst.type_name as submission_type,
                DATEDIFF(COALESCE(rs.proposed_end_date, CURDATE()), rs.proposed_start_date) as duration_days
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE $whereClause
            ORDER BY rs.proposed_end_date ASC
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $projects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        foreach ($projects as &$project) {
            $project['researchers'] = $this->getProjectResearchers($project['id'], $project['researcher_type']);
            
            // Calculate progress
            if ($project['proposed_start_date'] && $project['proposed_end_date']) {
                $start = strtotime($project['proposed_start_date']);
                $end = strtotime($project['proposed_end_date']);
                $now = time();
                
                if ($now >= $end) {
                    $project['progress_percent'] = 100;
                    $project['status'] = 'overdue';
                } elseif ($now <= $start) {
                    $project['progress_percent'] = 0;
                    $project['status'] = 'not_started';
                } else {
                    $total = $end - $start;
                    $elapsed = $now - $start;
                    $project['progress_percent'] = min(100, round(($elapsed / $total) * 100));
                    $project['status'] = 'in_progress';
                }
            }
        }
        
        return [
            'form' => 'D1',
            'title' => 'Ongoing Research Projects (RMIS Form D1)',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'filters' => $filters,
            'data' => [
                'projects' => $projects,
                'summary' => [
                    'total_projects' => count($projects),
                    'total_budget' => array_sum(array_column($projects, 'total_budget')),
                    'overdue_count' => count(array_filter($projects, fn($p) => ($p['status'] ?? '') === 'overdue'))
                ]
            ]
        ];
    }
    
    // ========================================
    // FORM E: Faculty Researchers Profile
    // ========================================
    
    /**
     * Get Faculty Researchers data for Form E
     */
    public function getFormEData($fiscalYear = null, $filters = []) {
        $fiscalYear = $fiscalYear ?? date('Y');
        
        $where = ['1=1'];
        $params = [];
        $types = "";
        
        if (!empty($filters['unit'])) {
            $where[] = "(fr.home_unit LIKE ? OR fr.department LIKE ?)";
            $unitPattern = "%" . $filters['unit'] . "%";
            $params[] = $unitPattern;
            $params[] = $unitPattern;
            $types .= "ss";
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "
            SELECT 
                fr.id,
                fr.hr_employee_id,
                fr.faculty_number,
                fr.last_name,
                fr.first_name,
                fr.middle_name,
                fr.email,
                fr.faculty_rank,
                fr.employment_status,
                fr.home_unit,
                fr.department,
                (SELECT COUNT(*) FROM faculty_projects fp WHERE fp.faculty_id = fr.id) as project_count,
                (SELECT COUNT(*) FROM faculty_projects fp WHERE fp.faculty_id = fr.id AND fp.project_status = 'completed') as completed_count,
                (SELECT COUNT(*) FROM faculty_research_outputs fro 
                 JOIN faculty_projects fp ON fro.project_id = fp.id 
                 WHERE fp.faculty_id = fr.id AND fro.output_status = 'accepted') as output_count
            FROM faculty_researchers fr
            WHERE $whereClause
            ORDER BY fr.last_name, fr.first_name
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $researchers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Get education for each researcher
        foreach ($researchers as &$researcher) {
            $researcher['education'] = $this->getResearcherEducation($researcher['id']);
            $researcher['full_name'] = $researcher['last_name'] . ', ' . $researcher['first_name'] . 
                                       ($researcher['middle_name'] ? ' ' . $researcher['middle_name'] : '');
        }
        
        // Group by unit
        $byUnit = [];
        foreach ($researchers as $r) {
            $unit = $r['home_unit'] ?: $r['department'] ?: 'Unassigned';
            if (!isset($byUnit[$unit])) {
                $byUnit[$unit] = [];
            }
            $byUnit[$unit][] = $r;
        }
        
        return [
            'form' => 'E',
            'title' => 'Faculty Researchers Profile (RMIS Form E)',
            'fiscal_year' => $fiscalYear,
            'generated_at' => date('Y-m-d H:i:s'),
            'filters' => $filters,
            'data' => [
                'researchers' => $researchers,
                'by_unit' => $byUnit,
                'summary' => [
                    'total_researchers' => count($researchers),
                    'total_projects' => array_sum(array_column($researchers, 'project_count')),
                    'total_outputs' => array_sum(array_column($researchers, 'output_count'))
                ]
            ]
        ];
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get researchers for a project submission
     */
    private function getProjectResearchers($submissionId, $researcherType) {
        // Get main researcher from submission
        $stmt = $this->conn->prepare("
            SELECT researcher_id, researcher_type FROM research_submissions WHERE id = ?
        ");
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $sub = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$sub) return [];
        
        $researchers = [];
        $table = '';
        
        switch ($sub['researcher_type']) {
            case 'faculty':
                $table = 'faculty_researchers';
                break;
            case 'student':
                $table = 'student_researchers';
                break;
            case 'personnel':
                $table = 'personnel_researchers';
                break;
        }
        
        if ($table) {
            $stmt = $this->conn->prepare("
                SELECT id, CONCAT(last_name, ', ', first_name) as name, email
                FROM $table WHERE id = ?
            ");
            $stmt->bind_param("i", $sub['researcher_id']);
            $stmt->execute();
            $researcher = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($researcher) {
                $researcher['role'] = 'Project Leader';
                $researchers[] = $researcher;
            }
        }
        
        return $researchers;
    }
    
    /**
     * Get researcher education records
     */
    private function getResearcherEducation($facultyId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM faculty_education 
            WHERE faculty_id = ? 
            ORDER BY year_graduated DESC
        ");
        $stmt->bind_param("i", $facultyId);
        $stmt->execute();
        $education = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $education;
    }
    
    /**
     * Generate report and log it
     */
    public function generateAndLog($formType, $fiscalYear = null, $filters = []) {
        $formType = strtolower($formType);
        $data = null;
        
        switch ($formType) {
            case 'a':
            case 'form_a':
                $data = $this->getFormAData($fiscalYear);
                break;
            case 'b':
            case 'form_b':
                $data = $this->getFormBData($fiscalYear);
                break;
            case 'c':
            case 'form_c':
                $data = $this->getFormCData($fiscalYear);
                break;
            case 'd':
            case 'form_d':
                $data = $this->getFormDData($fiscalYear, $filters);
                break;
            case 'd1':
            case 'form_d1':
                $data = $this->getFormD1Data($fiscalYear, $filters);
                break;
            case 'e':
            case 'form_e':
                $data = $this->getFormEData($fiscalYear, $filters);
                break;
            default:
                return ['success' => false, 'error' => 'Invalid form type'];
        }
        
        if (!$data) {
            return ['success' => false, 'error' => 'Failed to generate report'];
        }
        
        // Log the generation
        $this->logGeneration($formType, $fiscalYear, $filters, $data);
        
        return ['success' => true, 'data' => $data];
    }
    
    /**
     * Log report generation
     */
    private function logGeneration($formType, $fiscalYear, $filters, $data) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO rmis_report_generations 
                (report_type, fiscal_year, parameters, record_count, generated_by)
                VALUES (?, ?, ?, ?, ?)
            ");
            
            $params = json_encode($filters);
            $recordCount = 0;
            
            // Count records based on form type
            if (isset($data['data']['projects'])) {
                $recordCount = count($data['data']['projects']);
            } elseif (isset($data['data']['researchers'])) {
                $recordCount = count($data['data']['researchers']);
            } elseif (isset($data['data']['units'])) {
                $recordCount = count($data['data']['units']);
            } elseif (isset($data['data']['programs'])) {
                $recordCount = count($data['data']['programs']);
            }
            
            $stmt->bind_param("sssii", $formType, $fiscalYear, $params, $recordCount, $this->userId);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            error_log("RMISFormGenerator: Failed to log generation - " . $e->getMessage());
        }
    }
    
    /**
     * Get generation history
     */
    public function getGenerationHistory($formType = null, $limit = 50) {
        $where = '';
        $params = [];
        $types = '';
        
        if ($formType) {
            $where = 'WHERE report_type = ?';
            $params[] = $formType;
            $types .= 's';
        }
        
        $sql = "
            SELECT rg.*, u.fullname as generated_by_name
            FROM rmis_report_generations rg
            LEFT JOIN users u ON rg.generated_by = u.id
            $where
            ORDER BY rg.generated_at DESC
            LIMIT ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $limit;
        $types .= 'i';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $result;
    }
}
