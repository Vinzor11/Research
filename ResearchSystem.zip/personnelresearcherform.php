<?php
/**
 * Personnel Researcher Form - HR System Import
 * Imports non-academic/administrative employees from HR System
 */

session_start();
require 'db.php';
require 'config.php';
require_once 'spa_helper.php';

// Check if this is an SPA request
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly (not via AJAX)
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Access control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin','coordinator'])) {
    header("Location: login.php");
    exit;
}

$userRole = $_SESSION['user_role'];
$userId = $_SESSION['user_id'];
$coordinatorType = $_SESSION['coordinator_type'] ?? null;

// Get all coordinator types and scope info for the current user
$userCoordinatorTypes = [];
$coordinatorScopeMode = 'own_unit';
$coordinatorSpecificScopes = [];
$coordinatorEmployeeId = null;

if ($userRole === 'coordinator') {
    $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
    $empStmt->bind_param("i", $userId);
    $empStmt->execute();
    $empResult = $empStmt->get_result();
    if ($empRow = $empResult->fetch_assoc()) {
        $coordinatorEmployeeId = $empRow['employee_id'];
        if ($coordinatorEmployeeId) {
            // Get coordinator types and scope mode
            $typeStmt = $conn->prepare("SELECT coordinator_type, scope_mode FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'");
            $typeStmt->bind_param("s", $coordinatorEmployeeId);
            $typeStmt->execute();
            $typeResult = $typeStmt->get_result();
            while ($typeRow = $typeResult->fetch_assoc()) {
                $userCoordinatorTypes[] = $typeRow['coordinator_type'];
                // Use the scope_mode from the personnel coordinator assignment
                if ($typeRow['coordinator_type'] === 'personnel' && !empty($typeRow['scope_mode'])) {
                    $coordinatorScopeMode = $typeRow['scope_mode'];
                }
            }
            $typeStmt->close();
            
            // If scope_mode is specific_units, get the specific unit scopes
            if ($coordinatorScopeMode === 'specific_units') {
                $scopeStmt = $conn->prepare("SELECT unit_id, unit_name, unit_type FROM coordinator_scopes WHERE employee_id = ?");
                $scopeStmt->bind_param("s", $coordinatorEmployeeId);
                $scopeStmt->execute();
                $scopeResult = $scopeStmt->get_result();
                while ($scopeRow = $scopeResult->fetch_assoc()) {
                    $coordinatorSpecificScopes[] = [
                        'id' => $scopeRow['unit_id'],
                        'name' => $scopeRow['unit_name'],
                        'type' => $scopeRow['unit_type']
                    ];
                }
                $scopeStmt->close();
            }
        }
    }
    $empStmt->close();
}

// Check if user has personnel coordinator access
if ($userRole === 'coordinator' && !in_array('personnel', $userCoordinatorTypes)) {
    header("Location: research.php");
    exit;
}

// Check if HR Integration is available
if (!isHRIntegrationAvailable()) {
    die("HR System integration is not configured. Please contact administrator.");
}

// Check if we have access token
$token = getHRAccessToken();
if (!$token) {
    die("
    <div style='font-family: Arial; max-width: 600px; margin: 100px auto; padding: 30px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
        <h2 style='color: #dc3545;'><i class='fa fa-exclamation-triangle'></i> HR System Access Token Not Available</h2>
        <p><strong>The HR System access token is not available in your session.</strong></p>
        <p>This usually happens because:</p>
        <ul>
            <li>You didn't login via SSO (Single Sign-On)</li>
            <li>Your session expired</li>
            <li>The access token wasn't stored during login</li>
        </ul>
        <h3>Solution:</h3>
        <ol>
            <li>Click the button below to logout</li>
            <li>Login again using <strong>\"Sign in with HR System (SSO)\"</strong></li>
            <li>After successful login, try importing personnel again</li>
        </ol>
        <a href='logout.php' style='display: inline-block; margin-top: 20px; padding: 12px 24px; background: #dc3545; color: white; text-decoration: none; border-radius: 5px;'>
            <i class='fa fa-sign-out-alt'></i> Logout and Login via SSO
        </a>
    </div>
    ");
}

function s($v){ return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Get list of already imported personnel (excluding those with n/a status for re-import)
$importedEmployeeIds = [];
$importedResult = $conn->query("SELECT hr_employee_id FROM personnel_researchers WHERE sync_status != 'n/a' OR sync_status IS NULL");
while ($row = $importedResult->fetch_assoc()) {
    if (!empty($row['hr_employee_id'])) {
        $importedEmployeeIds[] = normalizeEmployeeId($row['hr_employee_id']);
    }
}

$debugInfo = [];
$adminAllEmployees = [];
$adminUnitsList = [];

// Variables for coordinator unit selection
$coordinatorUnitsList = [];
$coordinatorSelectedUnitIndex = null;
$coordinatorSelectAllUnits = false;
$coordinatorShowDropdown = false;
$coordinatorAvailableToImport = [];
$coordinatorDisplayUnitName = '';

// Fetch all employees and filter for administrative/non-academic sector
if ($userRole === 'admin' || $userRole === 'coordinator') {
    try {
        require 'hr_api_helper.php';
        $hrAPI = new HRSystemAPI($conn, $userId);
        
        // Fetch all active employees
        debugLog("Admin Personnel - Fetching all employees for unit grouping");
        $adminAllEmployees = $hrAPI->fetchAllEmployees('active');
        debugLog("Admin Personnel - Fetched " . count($adminAllEmployees) . " employees");
        
        // Group employees by office/administrative unit
        // Filter to only include administrative units (exclude academic - colleges, programs)
        $unitsMap = [];
        foreach ($adminAllEmployees as $emp) {
            $empUnit = $emp['unit'] ?? null;
            if (!$empUnit) continue;
            
            // Check if employee belongs to administrative (non-academic) sector
            $empSector = $emp['sector'] ?? null;
            $isAdministrative = false;
            
            if ($empSector) {
                $sectorName = is_array($empSector) ? ($empSector['name'] ?? '') : (is_string($empSector) ? $empSector : '');
                $sectorCode = is_array($empSector) ? ($empSector['code'] ?? '') : '';
                
                // Check if sector is NOT Academic (administrative, support services, etc.)
                $normalizedSectorName = strtolower(trim($sectorName));
                $normalizedSectorCode = strtolower(trim($sectorCode));
                
                // Include if NOT academic
                if ($normalizedSectorName !== 'academic' && $normalizedSectorCode !== 'acad') {
                    $isAdministrative = true;
                }
            } else {
                // If no sector info, check unit_type - include offices and administrative units
                $unitType = $empUnit['unit_type'] ?? null;
                $normalizedUnitType = strtolower(trim($unitType ?? ''));
                
                // Include if it's an office or administrative (not college or program)
                if (in_array($normalizedUnitType, ['office', 'administrative', 'admin']) || 
                    !in_array($normalizedUnitType, ['college', 'program'])) {
                    $isAdministrative = true;
                }
            }
            
            // Skip if academic
            if (!$isAdministrative) {
                continue;
            }
            
            $unitName = $empUnit['name'] ?? null;
            $unitId = $empUnit['id'] ?? null;
            $unitType = $empUnit['unit_type'] ?? null;
            
            if (empty($unitName) || empty($unitId)) continue;
            
            // Create unique key for the unit
            $unitKey = $unitName . '|' . $unitId;
            
            if (!isset($unitsMap[$unitKey])) {
                $unitsMap[$unitKey] = [
                    'name' => $unitName,
                    'id' => $unitId,
                    'type' => $unitType,
                    'employees' => []
                ];
            }
            
            $unitsMap[$unitKey]['employees'][] = $emp;
        }
        
        debugLog("Admin Personnel - Grouping complete", [
            'total_employees' => count($adminAllEmployees),
            'administrative_units_found' => count($unitsMap)
        ]);
        
        // Convert to indexed array and sort by unit name
        $adminUnitsList = array_values($unitsMap);
        usort($adminUnitsList, function($a, $b) {
            return strcmp($a['name'], $b['name']);
        });
        
        // Add employee count
        foreach ($adminUnitsList as &$unit) {
            $unit['total_employee_count'] = count($unit['employees'] ?? []);
        }
        
        // For coordinators, filter units based on their scope
        if ($userRole === 'coordinator') {
            $coordinatorSelectedUnitIndex = isset($_GET['unit']) && $_GET['unit'] !== '' ? $_GET['unit'] : null;
            $coordinatorSelectAllUnits = ($coordinatorSelectedUnitIndex === 'all');
            
            if ($coordinatorScopeMode === 'all_units') {
                // Coordinator has access to all units
                $coordinatorShowDropdown = true;
                $coordinatorUnitsList = $adminUnitsList;
            } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorSpecificScopes)) {
                // Coordinator has access to specific units only
                $coordinatorShowDropdown = count($coordinatorSpecificScopes) > 1;
                
                // Filter adminUnitsList to only include units in coordinator's scope
                $scopeUnitIds = array_map(function($s) { return (string)$s['id']; }, $coordinatorSpecificScopes);
                
                foreach ($adminUnitsList as $unit) {
                    if (in_array((string)$unit['id'], $scopeUnitIds)) {
                        $coordinatorUnitsList[] = $unit;
                    }
                }
                
                // If only one unit, auto-select it
                if (count($coordinatorUnitsList) === 1 && $coordinatorSelectedUnitIndex === null) {
                    $coordinatorSelectedUnitIndex = '0';
                }
            } else {
                // own_unit mode - try to find coordinator's own unit in the list
                $coordinatorShowDropdown = false;
                
                // Get coordinator's own unit from HR
                if ($coordinatorEmployeeId) {
                    $coordInfo = $hrAPI->getEmployeeById($coordinatorEmployeeId);
                    if ($coordInfo && isset($coordInfo['unit']['id'])) {
                        $coordUnitId = (string)$coordInfo['unit']['id'];
                        foreach ($adminUnitsList as $unit) {
                            if ((string)$unit['id'] === $coordUnitId) {
                                $coordinatorUnitsList[] = $unit;
                                $coordinatorSelectedUnitIndex = '0';
                                $coordinatorDisplayUnitName = $unit['name'];
                                break;
                            }
                        }
                    }
                }
            }
            
            // Get employees for selected unit
            if ($coordinatorSelectedUnitIndex !== null && !empty($coordinatorUnitsList)) {
                if ($coordinatorSelectAllUnits) {
                    $coordinatorDisplayUnitName = 'All Units';
                    foreach ($coordinatorUnitsList as $unit) {
                        foreach ($unit['employees'] ?? [] as $emp) {
                            $empId = $emp['id'] ?? '';
                            if (!in_array(normalizeEmployeeId($empId), $importedEmployeeIds)) {
                                $coordinatorAvailableToImport[] = $emp;
                            }
                        }
                    }
                } elseif (isset($coordinatorUnitsList[(int)$coordinatorSelectedUnitIndex])) {
                    $selectedUnit = $coordinatorUnitsList[(int)$coordinatorSelectedUnitIndex];
                    $coordinatorDisplayUnitName = $selectedUnit['name'];
                    foreach ($selectedUnit['employees'] ?? [] as $emp) {
                        $empId = $emp['id'] ?? '';
                        if (!in_array(normalizeEmployeeId($empId), $importedEmployeeIds)) {
                            $coordinatorAvailableToImport[] = $emp;
                        }
                    }
                }
            }
        }
        
    } catch (Exception $e) {
        $debugInfo['admin_error'] = 'Exception while fetching employees: ' . $e->getMessage();
        errorLog("Admin Personnel - Exception: " . $e->getMessage());
    }
}
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Import Personnel from HR System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<?php endif; ?>
<style>
:root {
    --primary: #064e1a;
    --primary-light: #0b6a24;
    --primary-dark: #053d15;
    --success: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --info: #3b82f6;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-500: #6b7280;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

/* Note: Base styles from researchStyle.css apply via app.php */

.form-page-container {
    font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif;
}

.form-header {
    background: white;
    padding: 20px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.08);
    margin-bottom: 0;
}

.form-header-title {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 24px;
    font-weight: 700;
    color: #1a1a1a;
}

.form-header-title i {
    color: var(--primary);
}

.form-content {
    padding: 30px;
    max-width: 1000px;
    margin: 0 auto;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
    padding: 8px 16px;
    background: white;
    border-radius: 8px;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
    font-size: 14px;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
}

.back-link:hover {
    transform: translateX(-5px);
    box-shadow: var(--shadow-lg);
}

.main-card {
    background: white;
    border-radius: 16px;
    box-shadow: var(--shadow-lg);
    overflow: hidden;
}

.card-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    color: white;
    padding: 30px;
}

.card-header h1 {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.card-header p {
    opacity: 0.9;
    font-size: 14px;
}

.card-body {
    padding: 40px;
}

.search-section {
    margin-bottom: 30px;
}

.search-input {
    width: 100%;
    padding: 16px 50px 16px 20px;
    border: 2px solid var(--gray-200);
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.1);
}

.employee-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    max-height: 500px;
    overflow-y: auto;
    padding: 10px;
    background: var(--gray-50);
    border-radius: 8px;
}

.employee-card {
    background: white;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border-left: 4px solid var(--primary);
    transition: all 0.3s ease;
    cursor: pointer;
}

.employee-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.employee-card.selectable.selected {
    border-left-color: var(--primary);
    background: #eff6ff;
}

.employee-card.importing {
    border-left-color: var(--info);
    background: #dbeafe;
}

.employee-card.success {
    border-left-color: var(--success);
    background: #d1fae5;
}

.employee-card.error {
    border-left-color: var(--danger);
    background: #fee2e2;
}

.employee-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--gray-200);
}

.employee-checkbox {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.employee-checkbox input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    margin-right: 8px;
}

.employee-number {
    font-weight: 600;
    color: var(--gray-500);
    font-size: 12px;
}

.employee-card-body h4 {
    margin: 0 0 10px 0;
    color: var(--gray-800);
    font-size: 16px;
}

.employee-card-body p {
    margin: 5px 0;
    font-size: 13px;
    color: var(--gray-600);
}

.employee-id {
    font-family: monospace;
    background: var(--gray-100);
    padding: 4px 8px;
    border-radius: 4px;
    display: inline-block;
}

.selection-controls {
    display: flex;
    align-items: center;
    gap: 10px;
}

.btn {
    padding: 12px 24px;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
    color: white;
    box-shadow: var(--shadow);
}

.btn-primary:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: var(--shadow-lg);
}

.btn-secondary {
    background: var(--gray-200);
    color: var(--gray-700);
}

.btn-secondary:hover {
    background: var(--gray-300);
}

.form-actions {
    margin-top: 30px;
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}

.alert {
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.alert i {
    font-size: 20px;
}

.alert-info {
    background: #dbeafe;
    color: #1e40af;
    border-left: 4px solid var(--info);
}

.alert-success {
    background: #d1fae5;
    color: #065f46;
    border-left: 4px solid var(--success);
}

.alert-warning {
    background: #fef3c7;
    color: #92400e;
    border-left: 4px solid var(--warning);
}

.import-progress {
    margin-top: 20px;
    padding: 20px;
    background: var(--gray-50);
    border-radius: 8px;
}

.progress-bar {
    width: 100%;
    height: 24px;
    background: var(--gray-200);
    border-radius: 12px;
    overflow: hidden;
    margin-bottom: 10px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--success), #059669);
    transition: width 0.3s ease;
    border-radius: 12px;
}

.progress-text {
    text-align: center;
    font-size: 14px;
    color: var(--gray-700);
    font-weight: 500;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--gray-500);
}

.empty-state i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
}

.employee-grid::-webkit-scrollbar {
    width: 8px;
}

.employee-grid::-webkit-scrollbar-track {
    background: var(--gray-100);
    border-radius: 4px;
}

.employee-grid::-webkit-scrollbar-thumb {
    background: var(--gray-300);
    border-radius: 4px;
}

.employee-grid::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}
</style>
<?php if (!$isSpa): ?>
</head>
<body>
<?php endif; ?>

<div class="form-page-container">
    <div class="form-header">
        <div class="form-header-title">
            <i class="fa fa-cloud-download-alt"></i>
            <span>Import Personnel from HR System</span>
        </div>
        <a href="personnelresearcher.php" class="back-link">
            <i class="fa fa-arrow-left"></i> Back to Personnel List
        </a>
    </div>

    <div class="form-content">
        <div class="main-card">
            <div class="card-header">
                <h1>
                    <i class="fa fa-building"></i>
                    <?php if ($userRole === 'coordinator'): ?>
                        <?php if ($coordinatorShowDropdown): ?>
                            Select Office/Unit to Import From
                        <?php else: ?>
                            Select Employees from Your Unit
                        <?php endif; ?>
                    <?php else: ?>
                        Select Office/Unit to Import From
                    <?php endif; ?>
                </h1>
                <p>
                    <?php if ($userRole === 'coordinator' && !$coordinatorShowDropdown && !empty($coordinatorDisplayUnitName)): ?>
                        Select employees from <?= s($coordinatorDisplayUnitName) ?> to import as personnel researchers
                    <?php else: ?>
                        Import administrative/non-academic employees as personnel researchers
                    <?php endif; ?>
                </p>
            </div>

        <div class="card-body">
            <?php if ($userRole === 'coordinator'): ?>
            <!-- Coordinator Section -->
            <?php if ($coordinatorShowDropdown): ?>
            <!-- Coordinator Unit Selection Dropdown -->
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                <div>
                    <strong>HR Integration:</strong> Personnel data is fetched directly from the HR System.
                    <br><strong>Select Office/Unit:</strong> Choose an administrative unit from the dropdown to view and import employees.
                    <?php if ($coordinatorScopeMode === 'all_units'): ?>
                        <em>(You have access to all administrative units)</em>
                    <?php elseif ($coordinatorScopeMode === 'specific_units'): ?>
                        <em>(You have access to <?= count($coordinatorUnitsList) ?> assigned unit(s))</em>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="search-section" style="margin-bottom: 30px;">
                <label for="coordUnitSelect" style="display: block; font-weight: 600; margin-bottom: 10px; color: var(--gray-700);">
                    <i class="fa fa-building"></i> Select Office/Unit:
                </label>
                <?php if (!empty($coordinatorUnitsList)): ?>
                <select id="coordUnitSelect" class="search-input" style="cursor: pointer; padding-right: 40px;">
                    <option value="">-- Select a unit to view employees --</option>
                    <?php if ($coordinatorScopeMode === 'all_units'): ?>
                    <option value="all" <?= $coordinatorSelectAllUnits ? 'selected' : '' ?>>📋 All Units (<?= array_sum(array_map(function($u) { return $u['total_employee_count'] ?? count($u['employees']); }, $coordinatorUnitsList)) ?> employees)</option>
                    <?php endif; ?>
                    <?php foreach ($coordinatorUnitsList as $index => $unit): ?>
                        <option value="<?= $index ?>" <?= $coordinatorSelectedUnitIndex === (string)$index ? 'selected' : '' ?>>
                            <?= s($unit['name']) ?> (<?= ($unit['total_employee_count'] ?? count($unit['employees'])) ?> employee<?= ($unit['total_employee_count'] ?? count($unit['employees'])) !== 1 ? 's' : '' ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>No units available.</strong>
                        <p>No administrative units are assigned to your coordinator scope. Please contact the administrator.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($coordinatorSelectedUnitIndex !== null && !empty($coordinatorUnitsList)): ?>
                <?php if (!empty($coordinatorAvailableToImport)): ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>Found <?= count($coordinatorAvailableToImport) ?> employee(s) from <?= s($coordinatorDisplayUnitName) ?> available to import.</strong>
                        <p>Select the employees you want to import as personnel researchers.</p>
                    </div>
                </div>
                
                <!-- Selection Controls -->
                <div class="selection-controls" style="margin-bottom: 20px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                    <button type="button" class="btn btn-secondary" onclick="selectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-check-square"></i> Select All
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="deselectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-square"></i> Deselect All
                    </button>
                    <span id="selectedCount" style="font-weight: 600; color: var(--primary);">
                        0 selected
                    </span>
                </div>
                
                <!-- Employee List Display -->
                <div class="employee-list-display">
                    <h3 style="margin-bottom: 15px; color: var(--gray-700);">
                        <i class="fa fa-users"></i> Available Employees (<?= count($coordinatorAvailableToImport) ?>)
                    </h3>
                    <div class="employee-grid">
                        <?php foreach ($coordinatorAvailableToImport as $index => $emp): 
                            $empId = $emp['id'] ?? 'N/A';
                            $name = $emp['name'] ?? [];
                            $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                            if (empty($fullName)) $fullName = 'N/A';
                            $position = $emp['position']['name'] ?? 'N/A';
                            $unit = $emp['unit']['name'] ?? 'N/A';
                            $email = $emp['contact']['email'] ?? 'N/A';
                        ?>
                            <div class="employee-card selectable" data-employee-id="<?= s($empId) ?>">
                                <div class="employee-card-header">
                                    <label class="employee-checkbox">
                                        <input type="checkbox" class="employee-select" value="<?= s($empId) ?>" data-employee-index="<?= $index ?>">
                                        <span class="checkmark"></span>
                                    </label>
                                    <span class="employee-number">#<?= $index + 1 ?></span>
                                </div>
                                <div class="employee-card-body">
                                    <h4><?= s($fullName) ?></h4>
                                    <p class="employee-id"><strong>ID:</strong> <?= s($empId) ?></p>
                                    <p><strong>Position:</strong> <?= s($position) ?></p>
                                    <p><strong>Unit:</strong> <?= s($unit) ?></p>
                                    <p><strong>Email:</strong> <?= s($email) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Import Button -->
                <div class="form-actions" style="margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="if(window.SPA){window.SPA.loadPage('personnelresearcher.php',true)}else{window.location.href='personnelresearcher.php'}">
                        <i class="fa fa-arrow-left"></i> Back to Personnel List
                    </button>
                    <button type="button" class="btn btn-primary" id="importSelectedBtn" onclick="importSelectedEmployees()" disabled>
                        <i class="fa fa-download"></i> Import Selected (<span id="importCount">0</span>)
                    </button>
                </div>
                
                <!-- Progress Display -->
                <div id="importProgress" class="import-progress" style="display: none; margin-top: 20px;">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    </div>
                    <p class="progress-text" id="progressText">Preparing to import...</p>
                </div>
                <?php else: ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>All employees from <?= s($coordinatorDisplayUnitName) ?> have already been imported.</strong>
                        <p>There are no additional employees available to import at this time.</p>
                    </div>
                </div>
                
                <div class="form-actions" style="margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="if(window.SPA){window.SPA.loadPage('personnelresearcher.php',true)}else{window.location.href='personnelresearcher.php'}">
                        <i class="fa fa-arrow-left"></i> Back to Personnel List
                    </button>
                </div>
                <?php endif; ?>
            <?php elseif (empty($coordinatorSelectedUnitIndex) && !empty($coordinatorUnitsList)): ?>
                <div class="empty-state">
                    <i class="fa fa-building"></i>
                    <h3>Select a Unit</h3>
                    <p>Choose a unit from the dropdown above to view and import employees</p>
                </div>
            <?php endif; ?>
            
            <?php elseif (!$coordinatorShowDropdown && !empty($coordinatorUnitsList)): ?>
            <!-- Coordinator own_unit mode - auto-fetch -->
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                <div>
                    <strong>HR Integration:</strong> Personnel data is fetched directly from the HR System.
                    <br><strong>Your Unit:</strong> Showing employees from <?= s($coordinatorDisplayUnitName) ?>. Employees already added as personnel researchers are not shown.
                </div>
            </div>
            
            <?php if (!empty($coordinatorAvailableToImport)): ?>
            <div class="alert alert-success">
                <i class="fa fa-check-circle"></i>
                <div>
                    <strong>Found <?= count($coordinatorAvailableToImport) ?> employee(s) from <?= s($coordinatorDisplayUnitName) ?> available to import.</strong>
                    <p>Select the employees you want to import as personnel researchers.</p>
                </div>
            </div>
            
            <!-- Selection Controls -->
            <div class="selection-controls" style="margin-bottom: 20px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                <button type="button" class="btn btn-secondary" onclick="selectAllEmployees()" style="margin-right: 10px;">
                    <i class="fa fa-check-square"></i> Select All
                </button>
                <button type="button" class="btn btn-secondary" onclick="deselectAllEmployees()" style="margin-right: 10px;">
                    <i class="fa fa-square"></i> Deselect All
                </button>
                <span id="selectedCount" style="font-weight: 600; color: var(--primary);">
                    0 selected
                </span>
            </div>
            
            <!-- Employee List Display -->
            <div class="employee-list-display">
                <h3 style="margin-bottom: 15px; color: var(--gray-700);">
                    <i class="fa fa-users"></i> Available Employees (<?= count($coordinatorAvailableToImport) ?>)
                </h3>
                <div class="employee-grid">
                    <?php foreach ($coordinatorAvailableToImport as $index => $emp): 
                        $empId = $emp['id'] ?? 'N/A';
                        $name = $emp['name'] ?? [];
                        $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                        if (empty($fullName)) $fullName = 'N/A';
                        $position = $emp['position']['name'] ?? 'N/A';
                        $unit = $emp['unit']['name'] ?? 'N/A';
                        $email = $emp['contact']['email'] ?? 'N/A';
                    ?>
                        <div class="employee-card selectable" data-employee-id="<?= s($empId) ?>">
                            <div class="employee-card-header">
                                <label class="employee-checkbox">
                                    <input type="checkbox" class="employee-select" value="<?= s($empId) ?>" data-employee-index="<?= $index ?>">
                                    <span class="checkmark"></span>
                                </label>
                                <span class="employee-number">#<?= $index + 1 ?></span>
                            </div>
                            <div class="employee-card-body">
                                <h4><?= s($fullName) ?></h4>
                                <p class="employee-id"><strong>ID:</strong> <?= s($empId) ?></p>
                                <p><strong>Position:</strong> <?= s($position) ?></p>
                                <p><strong>Unit:</strong> <?= s($unit) ?></p>
                                <p><strong>Email:</strong> <?= s($email) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Import Button -->
            <div class="form-actions" style="margin-top: 30px;">
                <button type="button" class="btn btn-secondary" onclick="if(window.SPA){window.SPA.loadPage('personnelresearcher.php',true)}else{window.location.href='personnelresearcher.php'}">
                    <i class="fa fa-arrow-left"></i> Back to Personnel List
                </button>
                <button type="button" class="btn btn-primary" id="importSelectedBtn" onclick="importSelectedEmployees()" disabled>
                    <i class="fa fa-download"></i> Import Selected (<span id="importCount">0</span>)
                </button>
            </div>
            
            <!-- Progress Display -->
            <div id="importProgress" class="import-progress" style="display: none; margin-top: 20px;">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                </div>
                <p class="progress-text" id="progressText">Preparing to import...</p>
            </div>
            <?php else: ?>
            <div class="alert alert-warning">
                <i class="fa fa-exclamation-triangle"></i>
                <div>
                    <strong>No employees found for import.</strong>
                    <p>No employees were found in your unit. Please contact the administrator if you believe this is an error.</p>
                </div>
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button type="button" class="btn btn-secondary" onclick="if(window.SPA){window.SPA.loadPage('personnelresearcher.php',true)}else{window.location.href='personnelresearcher.php'}">
                    <i class="fa fa-arrow-left"></i> Back to Personnel List
                </button>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <!-- Coordinator with no units -->
            <div class="alert alert-warning">
                <i class="fa fa-exclamation-triangle"></i>
                <div>
                    <strong>No units available.</strong>
                    <p>No administrative units are assigned to your coordinator scope. Please contact the administrator.</p>
                </div>
            </div>
            
            <div class="form-actions" style="margin-top: 30px;">
                <button type="button" class="btn btn-secondary" onclick="if(window.SPA){window.SPA.loadPage('personnelresearcher.php',true)}else{window.location.href='personnelresearcher.php'}">
                    <i class="fa fa-arrow-left"></i> Back to Personnel List
                </button>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <!-- Admin Section -->
            <?php
            // Filter available employees (not already imported)
            $adminAvailableToImport = [];
            $selectedUnitIndex = isset($_GET['unit']) && $_GET['unit'] !== '' ? $_GET['unit'] : null;
            $selectAllUnits = ($selectedUnitIndex === 'all');
            $selectedUnitName = '';
            
            if ($selectAllUnits) {
                // Get all employees from all units
                $allUnitEmployees = [];
                foreach ($adminUnitsList as $unit) {
                    foreach ($unit['employees'] ?? [] as $emp) {
                        $allUnitEmployees[] = $emp;
                    }
                }
                $adminAvailableToImport = array_values(array_filter($allUnitEmployees, function($emp) use ($importedEmployeeIds) {
                    $id = $emp['id'] ?? '';
                    if (in_array(normalizeEmployeeId($id), $importedEmployeeIds)) return false;
                    return true;
                }));
                $selectedUnitName = 'All Units';
            } elseif ($selectedUnitIndex !== null && isset($adminUnitsList[(int)$selectedUnitIndex])) {
                $selectedUnit = $adminUnitsList[(int)$selectedUnitIndex];
                $unitEmployees = $selectedUnit['employees'] ?? [];
                $selectedUnitName = $selectedUnit['name'];
                
                $adminAvailableToImport = array_values(array_filter($unitEmployees, function($emp) use ($importedEmployeeIds) {
                    $id = $emp['id'] ?? '';
                    if (in_array(normalizeEmployeeId($id), $importedEmployeeIds)) return false;
                    return true;
                }));
            }
            ?>
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                <div>
                    <strong>HR Integration:</strong> Personnel data is fetched directly from the HR System.
                    <br><strong>Select Office/Unit:</strong> Choose an administrative unit from the dropdown below to view and import employees. Employees already added as personnel researchers are not shown.
                </div>
            </div>
            
            <!-- Unit Selection Dropdown -->
            <div class="search-section" style="margin-bottom: 30px;">
                <label for="unitSelect" style="display: block; font-weight: 600; margin-bottom: 10px; color: var(--gray-700);">
                    <i class="fa fa-building"></i> Select Office/Unit:
                </label>
                <?php if (!empty($adminUnitsList)): ?>
                <select id="unitSelect" class="search-input" style="cursor: pointer; padding-right: 40px;">
                    <option value="">-- Select a unit to view employees --</option>
                    <option value="all" <?= $selectAllUnits ? 'selected' : '' ?>>📋 All Units (<?= array_sum(array_column($adminUnitsList, 'total_employee_count')) ?> employees)</option>
                    <?php foreach ($adminUnitsList as $index => $unit): ?>
                        <option value="<?= $index ?>" <?= $selectedUnitIndex === (string)$index ? 'selected' : '' ?>>
                            <?= s($unit['name']) ?> (<?= $unit['total_employee_count'] ?> employee<?= $unit['total_employee_count'] !== 1 ? 's' : '' ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>No administrative units found.</strong>
                        <?php if (isset($debugInfo['admin_error'])): ?>
                            <p><?= s($debugInfo['admin_error']) ?></p>
                        <?php else: ?>
                            <p>Unable to fetch employees from HR System. Please try again later or contact the administrator.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($selectedUnitIndex !== null && ($selectAllUnits || isset($adminUnitsList[(int)$selectedUnitIndex]))): ?>
                <?php if (!empty($adminAvailableToImport)): ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>Found <?= count($adminAvailableToImport) ?> employee(s) from <?= s($selectedUnitName) ?> available to import.</strong>
                        <p>Select the employees you want to import as personnel researchers.</p>
                    </div>
                </div>
                
                <!-- Selection Controls -->
                <div class="selection-controls" style="margin-bottom: 20px; padding: 15px; background: var(--gray-50); border-radius: 8px;">
                    <button type="button" class="btn btn-secondary" onclick="selectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-check-square"></i> Select All
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="deselectAllEmployees()" style="margin-right: 10px;">
                        <i class="fa fa-square"></i> Deselect All
                    </button>
                    <span id="selectedCount" style="font-weight: 600; color: var(--primary);">
                        0 selected
                    </span>
                </div>
                
                <!-- Employee List Display -->
                <div class="employee-list-display">
                    <h3 style="margin-bottom: 15px; color: var(--gray-700);">
                        <i class="fa fa-users"></i> Available Employees (<?= count($adminAvailableToImport) ?>)
                    </h3>
                    <div class="employee-grid">
                        <?php 
                        foreach ($adminAvailableToImport as $index => $emp): 
                            $empId = $emp['id'] ?? 'N/A';
                            $name = $emp['name'] ?? [];
                            $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                            if (empty($fullName)) $fullName = 'N/A';
                            $position = $emp['position']['name'] ?? 'N/A';
                            $unit = $emp['unit']['name'] ?? 'N/A';
                            $email = $emp['contact']['email'] ?? 'N/A';
                            $sector = is_array($emp['sector'] ?? null) ? ($emp['sector']['name'] ?? '') : ($emp['sector'] ?? '');
                        ?>
                            <div class="employee-card selectable" data-employee-id="<?= s($empId) ?>">
                                <div class="employee-card-header">
                                    <label class="employee-checkbox">
                                        <input type="checkbox" class="employee-select" value="<?= s($empId) ?>" data-employee-index="<?= $index ?>">
                                        <span class="checkmark"></span>
                                    </label>
                                    <span class="employee-number">#<?= $index + 1 ?></span>
                                </div>
                                <div class="employee-card-body">
                                    <h4><?= s($fullName) ?></h4>
                                    <p class="employee-id"><strong>ID:</strong> <?= s($empId) ?></p>
                                    <p><strong>Position:</strong> <?= s($position) ?></p>
                                    <p><strong>Office:</strong> <?= s($unit) ?></p>
                                    <?php if (!empty($sector)): ?>
                                    <p><strong>Sector:</strong> <?= s($sector) ?></p>
                                    <?php endif; ?>
                                    <p><strong>Email:</strong> <?= s($email) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Import Button -->
                <div class="form-actions" style="margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='personnelresearcher.php'">
                        <i class="fa fa-arrow-left"></i> Back to Personnel List
                    </button>
                    <button type="button" class="btn btn-primary" id="importSelectedBtn" onclick="importSelectedEmployees()" disabled>
                        <i class="fa fa-download"></i> Import Selected (<span id="importCount">0</span>)
                    </button>
                </div>
                
                <!-- Progress Display (hidden initially) -->
                <div id="importProgress" class="import-progress" style="display: none; margin-top: 20px;">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    </div>
                    <p class="progress-text" id="progressText">Preparing to import...</p>
                </div>
                
                <?php else: ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>All employees from <?= s($selectedUnitName) ?> have already been imported.</strong>
                        <p>There are no additional employees available to import at this time.</p>
                    </div>
                </div>
                
                <div class="form-actions" style="margin-top: 30px;">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='personnelresearcher.php'">
                        <i class="fa fa-arrow-left"></i> Back to Personnel List
                    </button>
                </div>
                <?php endif; ?>
            <?php elseif (!empty($adminUnitsList)): ?>
            <!-- No unit selected yet -->
            <div class="empty-state">
                <i class="fa fa-building"></i>
                <h3>Select an Office/Unit</h3>
                <p>Choose an administrative unit from the dropdown above to view available employees.</p>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    </div>
</div>

<?php if ($userRole === 'coordinator' && $coordinatorShowDropdown): ?>
<script>
// Coordinator unit dropdown change handler
(function() {
    const coordUnitSelect = document.getElementById('coordUnitSelect');
    if (coordUnitSelect) {
        coordUnitSelect.addEventListener('change', function() {
            const unitIndex = this.value;
            const url = unitIndex ? 'personnelresearcherform.php?unit=' + unitIndex : 'personnelresearcherform.php';
            if (window.SPA && typeof window.SPA.loadPage === 'function') {
                window.SPA.loadPage(url, true);
            } else {
                window.location.href = url;
            }
        });
    }
})();
</script>
<?php endif; ?>

<?php if ($userRole === 'coordinator' && !empty($coordinatorAvailableToImport)): ?>
<script>
// Employee selection and import for coordinators
(function() {
    const employeesData = <?= json_encode($coordinatorAvailableToImport) ?>;
    const checkboxes = document.querySelectorAll('.employee-select');
    const selectedCountSpan = document.getElementById('selectedCount');
    const importCountSpan = document.getElementById('importCount');
    const importBtn = document.getElementById('importSelectedBtn');
    
    // Update selection count
    function updateSelectionCount() {
        const selected = document.querySelectorAll('.employee-select:checked:not(:disabled)');
        const count = selected.length;
        selectedCountSpan.textContent = count + ' selected';
        importCountSpan.textContent = count;
        importBtn.disabled = count === 0;
        
        // Update card visual state
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                const card = cb.closest('.employee-card');
                if (cb.checked) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            }
        });
    }
    
    // Add event listeners to checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectionCount);
        
        const card = checkbox.closest('.employee-card');
        card.addEventListener('click', function(e) {
            if (e.target.type !== 'checkbox' && !e.target.closest('.employee-checkbox') && !checkbox.disabled) {
                checkbox.checked = !checkbox.checked;
                updateSelectionCount();
            }
        });
    });
    
    // Select all function
    window.selectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = true;
            }
        });
        updateSelectionCount();
    };
    
    // Deselect all function
    window.deselectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = false;
            }
        });
        updateSelectionCount();
    };
    
    // Import selected employees
    window.importSelectedEmployees = async function() {
        const selected = Array.from(document.querySelectorAll('.employee-select:checked'));
        if (selected.length === 0) {
            alert('Please select at least one employee to import.');
            return;
        }
        
        if (!confirm(`Import ${selected.length} selected employee(s) as personnel researchers?`)) {
            return;
        }
        
        // Disable button and show progress
        importBtn.disabled = true;
        importBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Importing...';
        
        const progressDiv = document.getElementById('importProgress');
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        progressDiv.style.display = 'block';
        
        let importedCount = 0;
        let failedCount = 0;
        
        for (let i = 0; i < selected.length; i++) {
            const checkbox = selected[i];
            const empIndex = parseInt(checkbox.dataset.employeeIndex);
            const employee = employeesData[empIndex];
            
            progressText.textContent = `Importing ${i + 1} of ${selected.length}: ${employee.name?.full_name || 'Employee'}...`;
            progressFill.style.width = ((i + 1) / selected.length * 100) + '%';
            
            try {
                const formData = new FormData();
                formData.append('action', 'import_personnel');
                formData.append('employee_id', employee.id);
                
                const response = await fetch('fetch_employee.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                console.log('Import result for', employee.id, ':', result);
                
                if (result.success) {
                    importedCount++;
                    checkbox.closest('.employee-card').classList.add('imported');
                    checkbox.disabled = true;
                    checkbox.checked = false;
                } else {
                    failedCount++;
                    console.error('Import failed for', employee.id, ':', result.error);
                    // Show error in card
                    const card = checkbox.closest('.employee-card');
                    card.classList.add('error');
                    card.title = result.error || 'Import failed';
                }
            } catch (error) {
                failedCount++;
                console.error('Import error:', error);
            }
            
            if (i < selected.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        }
        
        progressText.textContent = `Complete! ${importedCount} imported, ${failedCount} failed`;
        
        setTimeout(() => {
            if (window.SPA && typeof window.SPA.loadPage === 'function') {
                window.SPA.loadPage('personnelresearcher.php', true);
            } else {
                window.location.href = 'personnelresearcher.php';
            }
        }, 2000);
    };
    
    // Initial count update
    updateSelectionCount();
})();
</script>
<?php endif; ?>

<?php if ($userRole === 'admin'): ?>
<script>
// Unit dropdown change handler
(function() {
    const unitSelect = document.getElementById('unitSelect');
    if (unitSelect) {
        unitSelect.addEventListener('change', function() {
            const unitIndex = this.value;
            const url = unitIndex ? 'personnelresearcherform.php?unit=' + unitIndex : 'personnelresearcherform.php';
            if (window.SPA && typeof window.SPA.loadPage === 'function') {
                window.SPA.loadPage(url, true);
            } else {
                window.location.href = url;
            }
        });
    }
})();
</script>

<?php if ($selectedUnitIndex !== null && ($selectAllUnits || isset($adminUnitsList[(int)$selectedUnitIndex])) && !empty($adminAvailableToImport)): ?>
<script>
// Employee selection and import
(function() {
    const employeesData = <?= json_encode($adminAvailableToImport) ?>;
    const checkboxes = document.querySelectorAll('.employee-select');
    const selectedCountSpan = document.getElementById('selectedCount');
    const importCountSpan = document.getElementById('importCount');
    const importBtn = document.getElementById('importSelectedBtn');
    
    // Update selection count
    function updateSelectionCount() {
        const selected = document.querySelectorAll('.employee-select:checked:not(:disabled)');
        const count = selected.length;
        selectedCountSpan.textContent = count + ' selected';
        importCountSpan.textContent = count;
        importBtn.disabled = count === 0;
        
        // Update card visual state
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                const card = cb.closest('.employee-card');
                if (cb.checked) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            }
        });
    }
    
    // Add event listeners to checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectionCount);
        
        // Also toggle on card click
        const card = checkbox.closest('.employee-card');
        card.addEventListener('click', function(e) {
            if (e.target.type !== 'checkbox' && !e.target.closest('.employee-checkbox') && !checkbox.disabled) {
                checkbox.checked = !checkbox.checked;
                updateSelectionCount();
            }
        });
    });
    
    // Select all function
    window.selectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = true;
            }
        });
        updateSelectionCount();
    };
    
    // Deselect all function
    window.deselectAllEmployees = function() {
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = false;
            }
        });
        updateSelectionCount();
    };
    
    // Import selected employees
    window.importSelectedEmployees = async function() {
        const selected = Array.from(document.querySelectorAll('.employee-select:checked'));
        if (selected.length === 0) {
            alert('Please select at least one employee to import.');
            return;
        }
        
        if (!confirm(`Import ${selected.length} selected employee(s) as personnel researchers?`)) {
            return;
        }
        
        // Disable button and show progress
        importBtn.disabled = true;
        document.getElementById('importProgress').style.display = 'block';
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        let importedCount = 0;
        let failedCount = 0;
        const total = selected.length;
        
        // Import each selected employee
        for (let i = 0; i < selected.length; i++) {
            const checkbox = selected[i];
            const employeeId = checkbox.value;
            const employeeIndex = parseInt(checkbox.dataset.employeeIndex);
            const employee = employeesData[employeeIndex];
            const card = checkbox.closest('.employee-card');
            
            // Update card to show importing
            card.classList.add('importing');
            card.classList.remove('selected', 'success', 'error');
            
            try {
                const formData = new FormData();
                formData.append('action', 'import_personnel');
                formData.append('employee_id', employeeId);
                
                const response = await fetch('fetch_employee.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    importedCount++;
                    card.classList.remove('importing');
                    card.classList.add('success');
                    checkbox.disabled = true;
                } else {
                    failedCount++;
                    card.classList.remove('importing');
                    card.classList.add('error');
                    
                    if (data.existing_id) {
                        // Already imported - not really an error
                        card.classList.add('success');
                        checkbox.disabled = true;
                    }
                }
            } catch (error) {
                failedCount++;
                card.classList.remove('importing');
                card.classList.add('error');
            }
            
            // Update progress
            const processed = i + 1;
            const percentage = Math.round((processed / total) * 100);
            progressFill.style.width = percentage + '%';
            progressText.textContent = `Importing... ${processed}/${total} (${importedCount} imported, ${failedCount} failed)`;
            
            // Small delay to avoid rate limiting
            if (i < selected.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        }
        
        // Final update
        progressText.textContent = `Complete! ${importedCount} imported, ${failedCount} failed`;
        
        // Redirect after 2 seconds (use SPA navigation if available)
        setTimeout(() => {
            if (window.SPA && typeof window.SPA.loadPage === 'function') {
                window.SPA.loadPage('personnelresearcher.php', true);
            } else {
                window.location.href = 'personnelresearcher.php';
            }
        }, 2000);
    };
    
    // Initial count update
    updateSelectionCount();
})();
</script>
<?php endif; ?>
<?php endif; ?>

<?php if (!$isSpa): ?>
</body>
</html>
<?php endif; ?>
