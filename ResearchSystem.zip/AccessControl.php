<?php
/**
 * AccessControl.php
 * Centralized access control for faculty and student records
 * 
 * PERMISSION MODEL:
 * A coordinator may perform an action only if ALL are true:
 * 1. User has research-coordinator role
 * 2. Coordinator type matches the target researcher category
 * 3. Target researcher's unit is within the assigned scope
 * 
 * SCOPE MODES:
 * - own_unit: Can only manage researchers in their HR unit
 * - specific_units: Can manage researchers in explicitly assigned units
 * - all_units: Full access (restricted to central Research Office)
 */

class AccessControl {
    private $conn;
    private $userId;
    private $userRole;
    private $coordinatorType;
    private $employeeId;
    private $coordinatorData = null;
    
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->coordinatorType = $_SESSION['coordinator_type'] ?? null;
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        
        // Load coordinator data once for efficiency
        $this->loadCoordinatorData();
    }
    
    /**
     * Load coordinator assignments and scopes from database
     */
    private function loadCoordinatorData() {
        if (!$this->userId || !$this->employeeId || $this->userRole !== 'coordinator') {
            return;
        }
        
        try {
            // Check if coordinator_assignments table has scope columns
            $hasScopeMode = $this->conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'scope_mode'")->num_rows > 0;
            
            $this->coordinatorData = [
                'types' => [],
                'scope_mode' => 'own_unit',
                'hr_unit_id' => null,
                'hr_unit_name' => null,
                'allowed_units' => []
            ];
            
            // Get coordinator assignments
            $query = $hasScopeMode 
                ? "SELECT coordinator_type, scope_mode, hr_unit_id, hr_unit_name FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'"
                : "SELECT coordinator_type FROM coordinator_assignments WHERE employee_id = ? AND status = 'active'";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $this->coordinatorData['types'][] = $row['coordinator_type'];
                if ($hasScopeMode) {
                    $this->coordinatorData['scope_mode'] = $row['scope_mode'] ?? 'own_unit';
                    $this->coordinatorData['hr_unit_id'] = $row['hr_unit_id'];
                    $this->coordinatorData['hr_unit_name'] = $row['hr_unit_name'];
                }
            }
            $stmt->close();
            
            // If specific_units mode, load allowed units from coordinator_scopes
            if ($this->coordinatorData['scope_mode'] === 'specific_units') {
                $tableExists = $this->conn->query("SHOW TABLES LIKE 'coordinator_scopes'")->num_rows > 0;
                if ($tableExists) {
                    $scopeStmt = $this->conn->prepare("SELECT unit_id, unit_name, unit_type FROM coordinator_scopes WHERE employee_id = ?");
                    $scopeStmt->bind_param("s", $this->employeeId);
                    $scopeStmt->execute();
                    $scopeResult = $scopeStmt->get_result();
                    
                    while ($scope = $scopeResult->fetch_assoc()) {
                        $this->coordinatorData['allowed_units'][] = [
                            'id' => $scope['unit_id'],
                            'name' => $scope['unit_name'],
                            'type' => $scope['unit_type']
                        ];
                    }
                    $scopeStmt->close();
                }
            }
            
        } catch (Exception $e) {
            errorLog("AccessControl - Failed to load coordinator data", ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * Check if coordinator has a specific type
     */
    public function hasCoordinatorType($type) {
        if ($this->userRole === 'admin') return true;
        if (!$this->coordinatorData) return false;
        return in_array($type, $this->coordinatorData['types']);
    }
    
    /**
     * Check if unit is within coordinator's scope
     */
    public function isUnitInScope($unitId, $unitName = null) {
        // Admin has access to all units
        if ($this->userRole === 'admin') {
            return true;
        }
        
        if (!$this->coordinatorData) {
            return false;
        }
        
        $scopeMode = $this->coordinatorData['scope_mode'];
        
        switch ($scopeMode) {
            case 'all_units':
                return true;
                
            case 'own_unit':
                // Check if unit matches coordinator's HR unit
                $hrUnitId = $this->coordinatorData['hr_unit_id'];
                if (!$hrUnitId) {
                    // Fallback: allow if user created the record (legacy behavior)
                    return true;
                }
                return $unitId == $hrUnitId;
                
            case 'specific_units':
                // Check if unit is in allowed list
                foreach ($this->coordinatorData['allowed_units'] as $allowedUnit) {
                    if ($allowedUnit['id'] == $unitId) {
                        return true;
                    }
                }
                return false;
                
            default:
                return false;
        }
    }
    
    /**
     * Check if user can access faculty researcher
     * Requires: faculty coordinator type + unit in scope
     */
    public function canAccessFaculty($facultyId) {
        if (!$this->userId) {
            return false;
        }
        
        // Admin can access all
        if ($this->userRole === 'admin') {
            return true;
        }
        
        // Must be a coordinator with faculty type
        if ($this->userRole !== 'coordinator' || !$this->hasCoordinatorType('faculty')) {
            return false;
        }
        
        // Get faculty's unit info
        $stmt = $this->conn->prepare("
            SELECT created_by, home_unit, department 
            FROM faculty_researchers 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $facultyId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        // Check scope
        // For now, if scope data isn't fully populated, fall back to created_by check
        if ($this->coordinatorData && $this->coordinatorData['scope_mode'] !== 'own_unit') {
            // Use scope-based check when we have full unit mapping
            // TODO: Map faculty home_unit to HR unit_id for proper scope check
            return $this->isUnitInScope($result['department'] ?? $result['home_unit']);
        }
        
        // Legacy behavior: check created_by
        return $result['created_by'] == $this->userId;
    }
    
    /**
     * Check if user can access student researcher
     * Requires: student coordinator type + unit in scope
     */
    public function canAccessStudent($studentId) {
        if (!$this->userId) {
            return false;
        }
        
        // Admin can access all
        if ($this->userRole === 'admin') {
            return true;
        }
        
        // Must be a coordinator with student type
        if ($this->userRole !== 'coordinator' || !$this->hasCoordinatorType('student')) {
            return false;
        }
        
        // Get student's unit info
        $stmt = $this->conn->prepare("
            SELECT created_by, department 
            FROM student_researchers 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        // Check scope (with legacy fallback)
        if ($this->coordinatorData && $this->coordinatorData['scope_mode'] !== 'own_unit') {
            return $this->isUnitInScope($result['department']);
        }
        
        // Legacy behavior: check created_by
        return $result['created_by'] == $this->userId;
    }
    
    /**
     * Check if user can access faculty project
     */
    public function canAccessFacultyProject($projectId) {
        if (!$this->userId) {
            return false;
        }
        
        // Get faculty_id from project
        $stmt = $this->conn->prepare("
            SELECT faculty_id 
            FROM faculty_projects 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        return $this->canAccessFaculty($result['faculty_id']);
    }
    
    /**
     * Check if user can access student research output
     */
    public function canAccessStudentResearch($researchId) {
        if (!$this->userId) {
            return false;
        }
        
        // Get student_id from research output
        $stmt = $this->conn->prepare("
            SELECT student_id 
            FROM research_outputs 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $researchId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$result) {
            return false;
        }
        
        return $this->canAccessStudent($result['student_id']);
    }
    
    /**
     * Require faculty access or die
     */
    public function requireFacultyAccess($facultyId) {
        if (!$this->canAccessFaculty($facultyId)) {
            $this->denyAccess('You do not have permission to access this faculty researcher.');
        }
    }
    
    /**
     * Require student access or die
     */
    public function requireStudentAccess($studentId) {
        if (!$this->canAccessStudent($studentId)) {
            $this->denyAccess('You do not have permission to access this student researcher.');
        }
    }
    
    /**
     * Require faculty project access or die
     */
    public function requireFacultyProjectAccess($projectId) {
        if (!$this->canAccessFacultyProject($projectId)) {
            $this->denyAccess('You do not have permission to access this research project.');
        }
    }
    
    /**
     * Require student research access or die
     */
    public function requireStudentResearchAccess($researchId) {
        if (!$this->canAccessStudentResearch($researchId)) {
            $this->denyAccess('You do not have permission to access this research output.');
        }
    }
    
    /**
     * Check if user can manage faculty (import/create)
     * Requires faculty coordinator type
     */
    public function canManageFaculty() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->userRole === 'admin' || 
               ($this->userRole === 'coordinator' && $this->hasCoordinatorType('faculty'));
    }
    
    /**
     * Check if user can manage students (import/create)
     * Requires student coordinator type
     */
    public function canManageStudents() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->userRole === 'admin' || 
               ($this->userRole === 'coordinator' && $this->hasCoordinatorType('student'));
    }
    
    /**
     * Check if user can manage personnel (non-academic researchers)
     * Requires personnel coordinator type
     */
    public function canManagePersonnel() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->userRole === 'admin' || 
               ($this->userRole === 'coordinator' && $this->hasCoordinatorType('personnel'));
    }
    
    /**
     * Get SQL WHERE clause for faculty filtering based on scope
     */
    public function getFacultyWhereClause($tableAlias = 'fr') {
        if ($this->userRole === 'admin') {
            return '';
        }
        
        if ($this->userRole !== 'coordinator' || !$this->hasCoordinatorType('faculty')) {
            return " AND 1=0"; // No access
        }
        
        $scopeMode = $this->coordinatorData['scope_mode'] ?? 'own_unit';
        
        switch ($scopeMode) {
            case 'all_units':
                return ''; // Full access
                
            case 'specific_units':
                if (empty($this->coordinatorData['allowed_units'])) {
                    return " AND 1=0"; // No units assigned = no access
                }
                // Build IN clause for allowed units
                $unitIds = array_map(function($u) { 
                    return "'" . $this->conn->real_escape_string($u['id']) . "'";
                }, $this->coordinatorData['allowed_units']);
                // Match against department or home_unit
                return " AND ({$tableAlias}.department IN (" . implode(',', $unitIds) . ") OR {$tableAlias}.home_unit IN (" . implode(',', $unitIds) . "))";
                
            case 'own_unit':
            default:
                // Legacy: filter by created_by
                return " AND {$tableAlias}.created_by = " . intval($this->userId);
        }
    }
    
    /**
     * Get SQL WHERE clause for student filtering based on scope
     */
    public function getStudentWhereClause($tableAlias = 'sr') {
        if ($this->userRole === 'admin') {
            return '';
        }
        
        if ($this->userRole !== 'coordinator' || !$this->hasCoordinatorType('student')) {
            return " AND 1=0"; // No access
        }
        
        $scopeMode = $this->coordinatorData['scope_mode'] ?? 'own_unit';
        
        switch ($scopeMode) {
            case 'all_units':
                return ''; // Full access
                
            case 'specific_units':
                if (empty($this->coordinatorData['allowed_units'])) {
                    return " AND 1=0"; // No units assigned = no access
                }
                // Build IN clause for allowed units
                $unitIds = array_map(function($u) { 
                    return "'" . $this->conn->real_escape_string($u['id']) . "'";
                }, $this->coordinatorData['allowed_units']);
                // Match against department
                return " AND {$tableAlias}.department IN (" . implode(',', $unitIds) . ")";
                
            case 'own_unit':
            default:
                // Legacy: filter by created_by
                return " AND {$tableAlias}.created_by = " . intval($this->userId);
        }
    }
    
    /**
     * Display access denied page and exit
     */
    private function denyAccess($message = 'Access Denied') {
        http_response_code(403);
        
        // Check if this is an AJAX request
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => $message
            ]);
            exit;
        }
        
        // HTML response
        echo "<!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Access Denied</title>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    background: linear-gradient(135deg, #f9fafb 0%, #e0e7ff 100%);
                    margin: 0; 
                    padding: 0; 
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                }
                .access-denied { 
                    max-width: 500px; 
                    background: white; 
                    padding: 40px; 
                    border-radius: 16px; 
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .access-denied i { 
                    font-size: 64px; 
                    margin-bottom: 20px; 
                    color: #ef4444;
                    display: block;
                }
                .access-denied h2 { 
                    color: #1f2937; 
                    margin-bottom: 15px;
                    font-size: 24px;
                }
                .access-denied p { 
                    color: #6b7280; 
                    margin-bottom: 30px;
                    line-height: 1.6;
                }
                .btn-back { 
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    padding: 12px 24px; 
                    background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);
                    color: white; 
                    text-decoration: none; 
                    border-radius: 8px;
                    transition: all 0.3s ease;
                    font-weight: 600;
                }
                .btn-back:hover { 
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(6, 78, 26, 0.3);
                }
            </style>
        </head>
        <body>
            <div class='access-denied'>
                <i class='fa fa-shield-alt'></i>
                <h2>Access Denied</h2>
                <p>" . htmlspecialchars($message) . "</p>
                <p style='font-size: 14px;'>Your access scope does not include this researcher. Contact your administrator if you need access.</p>
                <a href='javascript:history.back()' class='btn-back'>
                    <i class='fa fa-arrow-left'></i> Go Back
                </a>
            </div>
        </body>
        </html>";
        exit;
    }
    
    /**
     * Get user information including scope details
     */
    public function getUserInfo() {
        $info = [
            'user_id' => $this->userId,
            'user_role' => $this->userRole,
            'coordinator_type' => $this->coordinatorType,
            'can_manage_faculty' => $this->canManageFaculty(),
            'can_manage_students' => $this->canManageStudents(),
            'can_manage_personnel' => $this->canManagePersonnel()
        ];
        
        if ($this->coordinatorData) {
            $info['coordinator_types'] = $this->coordinatorData['types'];
            $info['scope_mode'] = $this->coordinatorData['scope_mode'];
            $info['hr_unit_name'] = $this->coordinatorData['hr_unit_name'];
            $info['allowed_units_count'] = count($this->coordinatorData['allowed_units']);
        }
        
        return $info;
    }
    
    /**
     * Get coordinator's scope mode
     */
    public function getScopeMode() {
        if ($this->userRole === 'admin') {
            return 'all_units';
        }
        return $this->coordinatorData['scope_mode'] ?? 'own_unit';
    }
    
    /**
     * Get list of allowed unit IDs for current coordinator
     */
    public function getAllowedUnitIds() {
        if ($this->userRole === 'admin') {
            return null; // null means all units
        }
        
        if (!$this->coordinatorData) {
            return [];
        }
        
        if ($this->coordinatorData['scope_mode'] === 'all_units') {
            return null;
        }
        
        if ($this->coordinatorData['scope_mode'] === 'own_unit') {
            $hrUnitId = $this->coordinatorData['hr_unit_id'];
            return $hrUnitId ? [$hrUnitId] : [];
        }
        
        // specific_units
        return array_map(function($u) { return $u['id']; }, $this->coordinatorData['allowed_units']);
    }
}
