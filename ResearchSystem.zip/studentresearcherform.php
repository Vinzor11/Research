<?php
/**
 * Student Researcher Form
 * Purpose: Add or Edit student researcher information
 * Features: Form validation, database operations, session management, access control
 */

// Start session to track logged-in user
session_start();

// Check if user is logged in, redirect to login if not
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
require 'db.php';

// Get current user information
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'admin';

/**
 * Security function to escape HTML output
 * Prevents XSS attacks by converting special characters
 */
function s($v){ 
    return htmlspecialchars($v ?? '', ENT_QUOTES); 
}

// Determine if we're editing an existing student or adding a new one
$editId = isset($_GET['id']) ? (int)$_GET['id'] : null;
$editing = !empty($editId);

// Initialize message variables
$success = $error = '';

// ============================================
// ACCESS CONTROL FOR EDIT MODE
// ============================================
if ($editing) {
    // Check if student exists and user has permission to edit
    $checkStmt = $conn->prepare("SELECT id, created_by FROM student_researchers WHERE id = ?");
    $checkStmt->bind_param("i", $editId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result()->fetch_assoc();
    
    if (!$checkResult) {
        die("Student not found");
    }
    
    // Authorization: coordinators can only edit their own students, admins can edit all
    if ($userRole !== 'admin' && $checkResult['created_by'] != $userId) {
        die("Unauthorized: You can only edit student researchers you created");
    }
    
    $checkStmt->close();
}

// ============================================
// FORM SUBMISSION HANDLER
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Retrieve and sanitize form inputs
    $student_number = trim($_POST['student_number']);
    $last_name = trim($_POST['last_name']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $home_address = trim($_POST['home_address']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $course_year_section = trim($_POST['course_year_section']);
    $research_adviser = trim($_POST['research_adviser']);
    $department = trim($_POST['department']);

    // Check if we're updating an existing record
    if ($editing) {
        // Additional authorization check before update
        if ($userRole !== 'admin') {
            $verifyStmt = $conn->prepare("SELECT created_by FROM student_researchers WHERE id = ?");
            $verifyStmt->bind_param("i", $editId);
            $verifyStmt->execute();
            $verifyResult = $verifyStmt->get_result()->fetch_assoc();
            
            if ($verifyResult['created_by'] != $userId) {
                die("Unauthorized: You can only edit student researchers you created");
            }
        }
        
        // Prepare UPDATE query to modify existing student
        $stmt = $conn->prepare("UPDATE student_researchers 
            SET student_number=?, last_name=?, first_name=?, middle_name=?, 
                home_address=?, email=?, mobile=?, course_year_section=?, 
                research_adviser=?, department=? 
            WHERE id=?");
        
        // Bind parameters (s=string, i=integer)
        $stmt->bind_param("ssssssssssi", 
            $student_number, $last_name, $first_name, $middle_name, 
            $home_address, $email, $mobile, $course_year_section, 
            $research_adviser, $department, $editId);
        
        // Execute and redirect on success
        if ($stmt->execute()) {
            header("Location: studentresearcherprofile.php?id=$editId");
            exit;
        } else {
            $error = "Error updating student: " . $stmt->error;
        }
    } else {
        // Prepare INSERT query to add new student with created_by field
        $stmt = $conn->prepare("INSERT INTO student_researchers 
            (student_number, last_name, first_name, middle_name, 
             home_address, email, mobile, course_year_section, 
             research_adviser, department, created_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        // Bind parameters including created_by
        $stmt->bind_param("ssssssssssi", 
            $student_number, $last_name, $first_name, $middle_name, 
            $home_address, $email, $mobile, $course_year_section, 
            $research_adviser, $department, $userId);
        
        // Execute and redirect to new profile on success
        if ($stmt->execute()) {
            $student_id = $conn->insert_id;
            header("Location: studentresearcherprofile.php?id=$student_id");
            exit;
        } else {
            $error = "Error adding student: " . $stmt->error;
        }
    }
    
    // Close prepared statement
    $stmt->close();
}

// ============================================
// LOAD EXISTING STUDENT DATA (For Edit Mode)
// ============================================
$student = [];
if ($editing) {
    // Fetch existing student data from database
    $stmt = $conn->prepare("SELECT * FROM student_researchers WHERE id=?");
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $editing ? 'Edit' : 'Add' ?> Student Researcher</title>
    
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <!-- External CSS file -->
    <link rel="stylesheet" href="studentresearcherformstyle.css">
</head>
<body>

<div class="container">
    <!-- Back navigation link -->
    <a href="studentresearcher.php" class="back-link">
        <i class="fa fa-arrow-left"></i> Back to Student List
    </a>

    <!-- Form header with title -->
    <div class="form-header">
        <h1><?= $editing ? 'Edit' : 'Add' ?> Student Researcher</h1>
        <div class="subtitle">RMIS Form: Student Researcher Information</div>
    </div>

    <!-- Display success or error messages -->
    <?php if ($success): ?>
        <div class="msg-success"><?= s($success) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="msg-error"><?= s($error) ?></div>
    <?php endif; ?>

    <!-- Main form -->
    <form method="POST" id="studentForm">
        <!-- Hidden field for edit mode -->
        <?php if ($editing): ?>
            <input type="hidden" name="id" value="<?= $student['id'] ?>">
        <?php endif; ?>

        <!-- ========================================== -->
        <!-- SECTION 1: STUDENT INFORMATION -->
        <!-- ========================================== -->
        <div class="section-title">
            <i class="fa fa-user"></i> 1. Student Information
        </div>

        <div class="row">
            <div class="col">
                <label>Student Number <span class="required">*</span></label>
                <input type="text" 
                       name="student_number" 
                       id="student_number"
                       value="<?= s($student['student_number'] ?? '') ?>" 
                       required
                       placeholder="e.g., 2021-00000">
            </div>
        </div>

        <div class="row">
            <div class="col">
                <label>Last Name <span class="required">*</span></label>
                <input type="text" 
                       name="last_name" 
                       id="last_name"
                       value="<?= s($student['last_name'] ?? '') ?>" 
                       required>
            </div>
            <div class="col">
                <label>First Name <span class="required">*</span></label>
                <input type="text" 
                       name="first_name" 
                       id="first_name"
                       value="<?= s($student['first_name'] ?? '') ?>" 
                       required>
            </div>
            <div class="col">
                <label>Middle Initial</label>
                <input type="text" 
                       name="middle_name" 
                       id="middle_name"
                       value="<?= s($student['middle_name'] ?? '') ?>" 
                       maxlength="10"
                       placeholder="Optional">
            </div>
        </div>

        <!-- ========================================== -->
        <!-- SECTION 2: CONTACT INFORMATION -->
        <!-- ========================================== -->
        <div class="section-title">
            <i class="fa fa-address-book"></i> 2. Contact Information
        </div>

        <div class="row">
            <div class="col-full">
                <label>Home Address <span class="required">*</span></label>
                <input type="text" 
                       name="home_address" 
                       id="home_address"
                       value="<?= s($student['home_address'] ?? '') ?>" 
                       placeholder="Street, Barangay, Municipality" 
                       required>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <label>Mobile Number <span class="required">*</span></label>
                <input type="tel" 
                       name="mobile" 
                       id="mobile"
                       value="<?= s($student['mobile'] ?? '') ?>" 
                       placeholder="09XX-XXX-XXXX" 
                       maxlength="13"
                       required>
                <div class="info-text">Format will auto-apply as you type</div>
            </div>
            <div class="col">
                <label>Email Address <span class="required">*</span></label>
                <input type="email" 
                       name="email" 
                       id="email"
                       value="<?= s($student['email'] ?? '') ?>" 
                       placeholder="student@essu.edu.ph" 
                       required>
            </div>
        </div>

        <!-- ========================================== -->
        <!-- SECTION 3: ACADEMIC INFORMATION -->
        <!-- ========================================== -->
        <div class="section-title">
            <i class="fa fa-graduation-cap"></i> 3. Academic Information
        </div>

        <div class="row">
            <div class="col">
                <label>Course, Year & Section <span class="required">*</span></label>
                <input type="text" 
                       name="course_year_section" 
                       id="course_year_section"
                       value="<?= s($student['course_year_section'] ?? '') ?>" 
                       placeholder="e.g., BSIT 4-A" 
                       required>
                <div class="info-text">Format: Course Year-Section</div>
            </div>
            <div class="col">
                <label>Department</label>
                <input type="text" 
                       name="department" 
                       id="department"
                       value="<?= s($student['department'] ?? '') ?>" 
                       placeholder="e.g., College of Engineering">
            </div>
        </div>

        <div class="row">
            <div class="col">
                <label>Research Adviser</label>
                <input type="text" 
                       name="research_adviser" 
                       id="research_adviser"
                       value="<?= s($student['research_adviser'] ?? '') ?>" 
                       placeholder="Last Name, First Name">
            </div>
        </div>

        <!-- ========================================== -->
        <!-- FORM ACTION BUTTONS -->
        <!-- ========================================== -->
        <div class="form-actions">
            <!-- Cancel button -->
            <a href="studentresearcher.php" class="btn btn-secondary">
                <i class="fa fa-times"></i> Cancel
            </a>
            
            <!-- Submit button -->
            <button type="submit" class="btn" id="submitBtn">
                <i class="fa fa-save"></i> <?= $editing ? 'Save Changes' : 'Save Student Researcher' ?>
            </button>
        </div>
    </form>
</div>

<!-- External JavaScript file -->
<script src="studentresearcherformscript.js"></script>

</body>
</html>
