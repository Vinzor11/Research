<?php
/**
 * Enhanced Logout with SSO Support
 * SSO users are sent to the auth provider's end-session URL; post_logout_redirect_uri
 * is the redirect_uri from SSO config (the URI the auth provider has provided/registered).
 */
session_start();

// Check if user authenticated via SSO
$isSSOUser = isset($_SESSION['auth_method']) && $_SESSION['auth_method'] === 'sso';
$currentUser = $_SESSION['username'] ?? 'Unknown user';

// Log the logout attempt if ActivityLogger exists
if (file_exists('ActivityLogger.php') && isset($_SESSION['user_id'])) {
    require 'db.php';
    require 'ActivityLogger.php';
    
    try {
        $logger = new ActivityLogger($conn, $_SESSION['user_id']);
        $logger->logLogout($currentUser);
    } catch (Exception $e) {
        error_log("Logout logging failed: " . $e->getMessage());
    }
}

// Clear local session
session_unset();
session_destroy();

// SSO logout: use provider URL and redirect_uri from OAuth config
if ($isSSOUser) {
    require_once __DIR__ . '/db.php';
    require_once __DIR__ . '/config.php';
    $ssoConfig = getOAuthConfig($conn);
    $providerUrl = isset($ssoConfig['provider_url']) ? rtrim($ssoConfig['provider_url'], '/') : '';
    $redirectUri = isset($ssoConfig['redirect_uri']) ? trim($ssoConfig['redirect_uri']) : '';

    if ($providerUrl !== '' && $redirectUri !== '') {
        // Redirect to auth provider's end-session; they will redirect back to the configured redirect_uri
        $postLogoutRedirect = urlencode($redirectUri);
        $logoutUrl = $providerUrl . '/oauth/end-session?post_logout_redirect_uri=' . $postLogoutRedirect;
        error_log("SSO logout initiated - User: $currentUser, redirect_uri: $redirectUri");
        header("Location: " . $logoutUrl);
        exit;
    }
}

// Direct logout or SSO config missing: redirect to login page
error_log("Direct logout initiated - User: $currentUser");
header("Location: login.php?message=" . urlencode("Logged out successfully"));
exit;