<?php
/**
 * Coordinator Review Queue
 * 
 * This page allows Coordinators (Faculty, Student, Personnel) to:
 * - View submissions assigned to them for review
 * - Validate submissions (completeness, unit, attachments)
 * - Return submissions for revision
 * - Endorse submissions to Research Office
 * 
 * IMPORTANT: Coordinators CANNOT approve or reject - only validate and endorse
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Access control - Coordinators only (Admins should use research_office_queue.php)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'coordinator') {
    if ($_SESSION['user_role'] === 'admin') {
        // Redirect admins to their proper queue (handle SPA and direct access)
        if (isSpaRequest()) {
            echo '<script>if(window.SPA){window.SPA.loadPage("research_office_queue.php",true);}else{window.location.href="research_office_queue.php";}</script>';
            exit;
        }
        header("Location: app.php?load=research_office_queue.php");
        exit;
    }
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$employeeId = $_SESSION['employee_id'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get coordinator types for current user
$coordinatorTypes = [];
if ($employeeId) {
    $stmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $coordinatorTypes[] = $row['coordinator_type'];
    }
    $stmt->close();
}

// Initialize services
$submissionService = new SubmissionService($conn);
$workflowEngine = $submissionService->getWorkflowEngine();

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$researcherTypeFilter = $_GET['researcher_type'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get submissions for coordinator queue
$filters = [
    'status' => $statusFilter ?: null,
    'researcher_type' => $researcherTypeFilter ?: null,
    'search' => $searchQuery ?: null
];
$submissions = $submissionService->getCoordinatorQueue($filters, $page, 15);

// Get queue statistics
$statsConditions = ["assigned_coordinator_id = ?"];
$statsParams = [$userId];
$statsTypes = "i";

if ($employeeId) {
    $statsConditions[] = "assigned_coordinator_employee_id COLLATE utf8mb4_general_ci = ?";
    $statsParams[] = $employeeId;
    $statsTypes .= "s";
}

if (!empty($coordinatorTypes)) {
    $typePlaceholders = implode(',', array_fill(0, count($coordinatorTypes), '?'));
    $statsConditions[] = "researcher_type IN ($typePlaceholders)";
    $statsParams = array_merge($statsParams, $coordinatorTypes);
    $statsTypes .= str_repeat('s', count($coordinatorTypes));
}

$statsWhere = implode(" OR ", $statsConditions);
$stmt = $conn->prepare("
    SELECT 
        SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'under_coordinator_review' THEN 1 ELSE 0 END) as reviewing
    FROM research_submissions 
    WHERE ($statsWhere) AND status IN ('submitted', 'under_coordinator_review')
");
$stmt->bind_param($statsTypes, ...$statsParams);
$stmt->execute();
$queueStats = $stmt->get_result()->fetch_assoc();
$stmt->close();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   WORK QUEUE - UNIFIED DESIGN SYSTEM
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.header-right {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i {
    font-size: 14px;
}

.role-badge.badge-faculty { background: #dbeafe; color: #1e40af; }
.role-badge.badge-student { background: #fef3c7; color: #92400e; }
.role-badge.badge-personnel { background: #e0e7ff; color: #5b21b6; }

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    transition: all 0.3s ease;
    cursor: default;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-proposals { background: linear-gradient(135deg, #dbeafe, #93c5fd); color: #1d4ed8; }
.stat-icon.icon-progress { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-extensions { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }
.stat-icon.icon-outputs { background: linear-gradient(135deg, #e0e7ff, #c7d2fe); color: #5b21b6; }
.stat-icon.icon-completions { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.filter-header i {
    color: #064e1a;
    font-size: 16px;
}

.filter-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #374151;
    margin: 0;
}

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

@media (max-width: 1200px) {
    .filter-grid {
        grid-template-columns: 1fr 1fr;
    }
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input[type="text"]:focus,
.filter-group input[type="date"]:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover {
    background: #e5e7eb;
    color: #374151;
}

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
    white-space: nowrap;
}

.queue-table th:nth-child(1) { width: 10%; text-align: center; }
.queue-table th:nth-child(2) { width: 32%; }
.queue-table th:nth-child(3) { width: 18%; text-align: center; }
.queue-table th:nth-child(4) { width: 12%; text-align: center; }
.queue-table th:nth-child(5) { width: 12%; text-align: center; }
.queue-table th:nth-child(6) { width: 16%; text-align: center; }

.queue-table td {
    padding: 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
}

.queue-table tr:hover {
    background: #f9fafb;
}

.queue-table tr.self-submission {
    background: linear-gradient(135deg, #fef2f2 0%, #fff 100%);
}

/* Type Badge Cell */
.type-cell {
    text-align: center;
}

.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.type-badge i { font-size: 12px; }

.type-proposal { background: #dbeafe; color: #1e40af; }
.type-progress { background: #fef3c7; color: #92400e; }
.type-output { background: #e0e7ff; color: #5b21b6; }
.type-extension { background: #fee2e2; color: #991b1b; }
.type-completion { background: #d1fae5; color: #065f46; }

/* Item Cell */
.item-cell {
    text-align: left;
}

.item-title {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.item-title:hover {
    color: #064e1a;
}

.item-meta {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 6px;
}

.item-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.ref-badge {
    font-size: 11px;
    color: #6b7280;
    font-family: monospace;
}

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
}

.researcher-type-badge.faculty { background: #dbeafe; color: #1e40af; }
.researcher-type-badge.student { background: #fef3c7; color: #92400e; }
.researcher-type-badge.personnel { background: #e0e7ff; color: #5b21b6; }

.researcher-name {
    font-size: 12px;
    color: #374151;
    display: flex;
    align-items: center;
    gap: 4px;
}

.researcher-name i { color: #9ca3af; font-size: 11px; }

/* Unit Cell */
.unit-cell {
    font-size: 13px;
    color: #374151;
    text-align: center;
}

/* Status Cell */
.status-cell {
    text-align: center;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

.status-submitted, .status-pending { background: #dbeafe; color: #1e40af; }
.status-under_coordinator_review, .status-reviewing { background: #fef3c7; color: #92400e; }
.status-endorsed { background: #e0e7ff; color: #5b21b6; }
.status-under_ro_review { background: #fef3c7; color: #92400e; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }

/* Date Cell */
.date-cell {
    font-size: 13px;
    color: #6b7280;
    text-align: center;
}

/* Action Cell */
.action-cell {
    text-align: center;
}

.btn-review {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-review:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

.btn-review i { font-size: 11px; }

.btn-view-only {
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #e5e7eb;
}

.btn-view-only:hover {
    background: #e5e7eb;
    transform: none;
}

.btn-start-review {
    background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
    cursor: pointer;
}

.btn-start-review:hover {
    background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);
}

/* Self-submission warning */
.self-warning {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    color: #dc2626;
    background: #fee2e2;
    padding: 4px 8px;
    border-radius: 4px;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #6b7280;
}

.empty-state i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.3;
    color: #064e1a;
}

.empty-state h3 {
    font-size: 18px;
    color: #374151;
    margin-bottom: 8px;
}

.empty-state p {
    font-size: 14px;
    color: #6b7280;
}

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info {
    font-size: 13px;
    color: #6b7280;
}

.pagination {
    display: flex;
    gap: 6px;
}

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a {
    background: white;
    color: #374151;
    border: 1px solid #e5e7eb;
}

.pagination a:hover { 
    background: #f3f4f6;
    border-color: #d1d5db;
}

.pagination .current {
    background: #064e1a;
    color: white;
    border: 1px solid #064e1a;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-content {
    transform: scale(1);
}

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 20px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.modal-footer .btn-cancel {
    padding: 10px 20px;
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 500;
}

.modal-footer .btn-save {
    padding: 10px 20px;
    background: #064e1a;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
}

.form-group {
    margin-bottom: 16px;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
    font-size: 14px;
}

.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    min-height: 100px;
    resize: vertical;
}

.form-group textarea:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa-solid fa-clipboard-check header-icon"></i>
                <div>
                    <h1>Work Queue</h1>
                    <p>Review and process pending submissions, reports, and requests</p>
                </div>
            </div>
            <div class="header-right" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #064e1a;">
                    <i class="fa fa-user-tie"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    <?php if (!empty($coordinatorTypes)): ?>
                        <?= implode(' / ', array_map(function($t) { return ucfirst($t); }, $coordinatorTypes)) ?> Coordinator
                    <?php else: ?>
                        Coordinator
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <?php
    // Get detailed stats by type
    $typeStats = ['proposals' => 0, 'progress' => 0, 'extensions' => 0, 'outputs' => 0, 'completions' => 0];
    $totalItems = ($queueStats['pending'] ?? 0) + ($queueStats['reviewing'] ?? 0);
    ?>
    <div class="stats-row">
        <div class="stat-card active">
            <div class="stat-icon icon-total">
                <i class="fa fa-layer-group"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $totalItems ?></div>
                <div class="stat-label">Total Items</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-proposals">
                <i class="fa fa-file-alt"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $queueStats['pending'] ?? 0 ?></div>
                <div class="stat-label">Proposals</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-progress">
                <i class="fa fa-chart-line"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $queueStats['reviewing'] ?? 0 ?></div>
                <div class="stat-label">Progress</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-extensions">
                <i class="fa fa-calendar-plus"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Extensions</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-outputs">
                <i class="fa fa-book"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Outputs</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-completions">
                <i class="fa fa-check-double"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Completions</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <i class="fa fa-filter"></i>
            <h3>Filter Queue</h3>
        </div>
        <form method="GET">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Item Type</label>
                    <select name="item_type">
                        <option value="">All Types</option>
                        <option value="proposal">Proposals</option>
                        <option value="progress">Progress Reports</option>
                        <option value="output">Outputs</option>
                        <option value="extension">Extensions</option>
                        <option value="completion">Completions</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="submitted" <?= $statusFilter === 'submitted' ? 'selected' : '' ?>>Pending Review</option>
                        <option value="under_coordinator_review" <?= $statusFilter === 'under_coordinator_review' ? 'selected' : '' ?>>Under Review</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?= s($_GET['date_from'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?= s($_GET['date_to'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by reference, title, or requester..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-group filter-actions">
                    <label>&nbsp;</label>
                    <?php if ($statusFilter || $searchQuery || !empty($_GET['date_from']) || !empty($_GET['date_to'])): ?>
                        <a href="coordinator_queue.php" class="clear-btn" title="Clear filters"><i class="fa fa-times"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Queue Table -->
    <div class="queue-table-container">
        <?php if (empty($submissions['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-inbox"></i>
                <h3>Queue is Empty</h3>
                <p>No submissions are currently awaiting your review.</p>
            </div>
        <?php else: ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Item</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions['data'] as $sub): 
                        $isSelfSubmission = (($sub['created_by'] ?? null) == $userId);
                        
                        // Determine item type for badge
                        $typeCode = strtolower($sub['type_code'] ?? 'proposal');
                        $typeIcon = 'fa-file-alt';
                        $typeLabel = 'PROPOSAL';
                        if (strpos($typeCode, 'progress') !== false || strpos($typeCode, 'ongoing') !== false) {
                            $typeIcon = 'fa-chart-line';
                            $typeLabel = 'PROGRESS';
                            $typeCode = 'progress';
                        } elseif (strpos($typeCode, 'output') !== false || strpos($typeCode, 'publication') !== false) {
                            $typeIcon = 'fa-book';
                            $typeLabel = 'OUTPUT';
                            $typeCode = 'output';
                        } elseif (strpos($typeCode, 'extension') !== false) {
                            $typeIcon = 'fa-calendar-plus';
                            $typeLabel = 'EXTENSION';
                            $typeCode = 'extension';
                        } elseif (strpos($typeCode, 'completion') !== false) {
                            $typeIcon = 'fa-check-double';
                            $typeLabel = 'COMPLETION';
                            $typeCode = 'completion';
                        } else {
                            $typeCode = 'proposal';
                        }
                    ?>
                    <tr class="<?= $isSelfSubmission ? 'self-submission' : '' ?>">
                        <!-- TYPE -->
                        <td class="type-cell">
                            <span class="type-badge type-<?= $typeCode ?>">
                                <i class="fa <?= $typeIcon ?>"></i> <?= $typeLabel ?>
                            </span>
                        </td>
                        
                        <!-- ITEM -->
                        <td class="item-cell">
                            <a href="submission_view.php?id=<?= $sub['id'] ?>" class="item-title"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                                <?= s($sub['title']) ?>
                            </a>
                            <div class="item-meta"><?= s($sub['type_name']) ?></div>
                            <div class="item-badges">
                                <span class="ref-badge"><?= s($sub['reference_number'] ?? 'RMS-' . str_pad($sub['id'], 5, '0', STR_PAD_LEFT)) ?></span>
                                <span class="researcher-type-badge <?= s($sub['researcher_type']) ?>">
                                    <?= s(strtoupper($sub['researcher_type'])) ?>
                                </span>
                                <span class="researcher-name">
                                    <i class="fa fa-user"></i> <?= s($sub['researcher_name'] ?? $sub['created_by_name'] ?? 'Unknown') ?>
                                </span>
                                <?php if ($isSelfSubmission): ?>
                                    <span class="self-warning"><i class="fa fa-ban"></i> Own</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        
                        <!-- UNIT -->
                        <td class="unit-cell">
                            <?= s($sub['researcher_unit_name'] ?? '—') ?>
                        </td>
                        
                        <!-- STATUS -->
                        <td class="status-cell">
                            <span class="status-badge status-<?= s($sub['status']) ?>">
                                <?= $sub['status'] === 'submitted' ? 'Pending Review' : 'Under Review' ?>
                            </span>
                        </td>
                        
                        <!-- SUBMITTED -->
                        <td class="date-cell">
                            <?= $sub['submitted_at'] ? date('M d, Y', strtotime($sub['submitted_at'])) : '—' ?>
                        </td>
                        
                        <!-- ACTION -->
                        <td class="action-cell">
                            <?php if ($isSelfSubmission): ?>
                                <a href="submission_view.php?id=<?= $sub['id'] ?>" class="btn-review btn-view-only"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                                    <i class="fa fa-eye"></i> View
                                </a>
                            <?php elseif ($sub['status'] === 'submitted'): ?>
                                <button class="btn-review btn-start-review" onclick="startReview(<?= $sub['id'] ?>)">
                                    <i class="fa fa-play"></i> Start Review
                                </button>
                            <?php else: ?>
                                <a href="submission_view.php?id=<?= $sub['id'] ?>" class="btn-review"
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                                    <i class="fa fa-eye"></i> Review
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <div class="pagination-container">
                <div class="pagination-info">
                    Showing <?= (($page - 1) * 15) + 1 ?> to <?= min($page * 15, $submissions['total']) ?> of <?= $submissions['total'] ?> submissions
                </div>
                <?php if ($submissions['total_pages'] > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                            <i class="fa fa-chevron-left"></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($submissions['total_pages'], $page + 2); $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $submissions['total_pages']): ?>
                        <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                            <i class="fa fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Return for Revision Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-undo" style="color: #dc2626;"></i> Return for Revision</h2>
            <button class="modal-close" onclick="closeReturnModal()">&times;</button>
        </div>
        <form id="returnForm" method="POST" onsubmit="submitReturn(event); return false;">
            <input type="hidden" name="submission_id" id="return_submission_id">
            <div class="modal-body">
                <p style="margin: 0 0 16px 0; color: #6b7280;">
                    Returning: <strong id="return_submission_title"></strong>
                </p>
                <div class="form-group">
                    <label for="return_reason">Reason for Revision <span style="color: #dc2626;">*</span></label>
                    <textarea id="return_reason" name="reason" required placeholder="Please specify what needs to be revised..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeReturnModal()">Cancel</button>
                <button type="submit" class="btn-save" style="background: #dc2626;">
                    <i class="fa fa-undo"></i> Return for Revision
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-check-double" style="color: #064e1a;"></i> Endorse to Research Office</h2>
            <button class="modal-close" onclick="closeEndorseModal()">&times;</button>
        </div>
        <form id="endorseForm" method="POST" onsubmit="submitEndorse(event); return false;">
            <input type="hidden" name="submission_id" id="endorse_submission_id">
            <div class="modal-body">
                <p style="margin: 0 0 16px 0; color: #6b7280;">
                    Endorsing: <strong id="endorse_submission_title"></strong>
                </p>
                
                <p style="color: #374151; margin-bottom: 12px; font-weight: 500;">Please complete all validation checks before endorsing:</p>
                
                <div class="checklist-group" style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px;">
                    <label class="checklist-item" style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: #f9fafb; border-radius: 8px; cursor: pointer; border: 1px solid #e5e7eb;">
                        <input type="checkbox" name="completeness_verified" id="chk_completeness" value="1" style="width: 18px; height: 18px; accent-color: #064e1a;">
                        <span style="font-size: 14px; color: #374151;">I have verified the submission is complete</span>
                    </label>
                    <label class="checklist-item" style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: #f9fafb; border-radius: 8px; cursor: pointer; border: 1px solid #e5e7eb;">
                        <input type="checkbox" name="unit_verified" id="chk_unit" value="1" style="width: 18px; height: 18px; accent-color: #064e1a;">
                        <span style="font-size: 14px; color: #374151;">I have verified the researcher's unit affiliation</span>
                    </label>
                    <label class="checklist-item" style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: #f9fafb; border-radius: 8px; cursor: pointer; border: 1px solid #e5e7eb;">
                        <input type="checkbox" name="category_verified" id="chk_category" value="1" style="width: 18px; height: 18px; accent-color: #064e1a;">
                        <span style="font-size: 14px; color: #374151;">I have verified the researcher category is correct</span>
                    </label>
                    <label class="checklist-item" style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: #f9fafb; border-radius: 8px; cursor: pointer; border: 1px solid #e5e7eb;">
                        <input type="checkbox" name="attachments_verified" id="chk_attachments" value="1" style="width: 18px; height: 18px; accent-color: #064e1a;">
                        <span style="font-size: 14px; color: #374151;">I have verified all required attachments are present</span>
                    </label>
                </div>
                
                <div class="form-group">
                    <label for="endorsement_notes">Endorsement Notes (Optional)</label>
                    <textarea id="endorsement_notes" name="notes" placeholder="Add any notes or recommendations for the Research Office..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeEndorseModal()">Cancel</button>
                <button type="submit" class="btn-save" id="endorseSubmitBtn" disabled style="opacity: 0.5; cursor: not-allowed;">
                    <i class="fa fa-check-double"></i> Endorse Submission
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Start Review
function startReview(submissionId) {
    if (!confirm('Start reviewing this submission? It will be marked as "Under Review".')) return;
    
    fetch('submission_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'start_review', submission_id: submissionId })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Failed to start review');
        }
    });
}

// Return Modal
function openReturnModal(id, title) {
    document.getElementById('return_submission_id').value = id;
    document.getElementById('return_submission_title').textContent = title;
    document.getElementById('returnModal').classList.add('active');
}

function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('active');
    document.getElementById('returnForm').reset();
}

function submitReturn(e) {
    e.preventDefault();
    const form = e.target;
    const data = {
        action: 'return_for_revision',
        submission_id: form.submission_id.value,
        reason: form.reason.value
    };
    
    fetch('submission_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            closeReturnModal();
            location.reload();
        } else {
            alert(data.error || 'Failed to return submission');
        }
    });
}

// Endorse Modal
function openEndorseModal(id, title) {
    document.getElementById('endorse_submission_id').value = id;
    document.getElementById('endorse_submission_title').textContent = title;
    document.getElementById('endorseModal').classList.add('active');
    updateEndorseButtonState();
}

function closeEndorseModal() {
    document.getElementById('endorseModal').classList.remove('active');
    document.getElementById('endorseForm').reset();
    updateEndorseButtonState();
}

function updateEndorseButtonState() {
    const checkboxes = document.querySelectorAll('#endorseForm input[type="checkbox"]');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    const btn = document.getElementById('endorseSubmitBtn');
    
    if (allChecked) {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    } else {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
    }
}

// Add event listeners to all endorsement checkboxes
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('#endorseForm input[type="checkbox"]');
    checkboxes.forEach(cb => {
        cb.addEventListener('change', updateEndorseButtonState);
    });
});

function submitEndorse(e) {
    e.preventDefault();
    const form = e.target;
    
    // Validate all checkboxes are checked
    const checkboxes = form.querySelectorAll('input[type="checkbox"]');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    
    if (!allChecked) {
        alert('Please complete all validation checks before endorsing.');
        return;
    }
    
    const data = {
        action: 'endorse',
        submission_id: form.submission_id.value,
        completeness_verified: form.completeness_verified.checked ? 1 : 0,
        unit_verified: form.unit_verified.checked ? 1 : 0,
        category_verified: form.category_verified.checked ? 1 : 0,
        attachments_verified: form.attachments_verified.checked ? 1 : 0,
        notes: form.notes.value
    };
    
    fetch('submission_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            closeEndorseModal();
            location.reload();
        } else {
            alert(data.error || 'Failed to endorse submission');
        }
    });
}
</script>
