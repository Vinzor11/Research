<?php
/**
 * Employee Fetch Endpoint - ON-DEMAND QUERIES ONLY
 * Handles: search, get by ID, import, sync
 */

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

require 'db.php';
require 'config.php';
require 'hr_api_helper.php';

$userRole = $_SESSION['user_role'] ?? null;
$userId = $_SESSION['user_id'];

if (!in_array($userRole, ['admin', 'coordinator'])) {
    echo json_encode(['success' => false, 'error' => 'Access denied']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    $hrAPI = new HRSystemAPI($conn, $userId);
    
    switch ($action) {
        case 'search':
            $query = trim($_GET['q'] ?? '');
            $page = (int)($_GET['page'] ?? 1);
            $perPage = 20;
            
            if (empty($query) || strlen($query) < 2) {
                echo json_encode([
                    'success' => true,
                    'data' => [],
                    'total' => 0,
                    'message' => 'Enter at least 2 characters to search'
                ]);
                exit;
            }
            
            // Coordinator: restrict search to employees in same parent unit (RESEARCH_OFFICE_API_GUIDE)
            if ($userRole === 'coordinator') {
                $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                if (!empty($unitEmployees)) {
                    $queryLower = mb_strtolower($query);
                    $filtered = [];
                    foreach ($unitEmployees as $emp) {
                        $name = $emp['name'] ?? [];
                        $contact = $emp['contact'] ?? [];
                        $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                        $email = $contact['email'] ?? '';
                        if (strpos(mb_strtolower($fullName), $queryLower) !== false ||
                            strpos(mb_strtolower($email), $queryLower) !== false) {
                            $filtered[] = $emp;
                        }
                    }
                    $total = count($filtered);
                    $offset = ($page - 1) * $perPage;
                    $paged = array_slice($filtered, $offset, $perPage);
                    $employees = [];
                    foreach ($paged as $emp) {
                        $name = $emp['name'] ?? [];
                        $contact = $emp['contact'] ?? [];
                        $department = $emp['department'] ?? $emp['unit'] ?? [];
                        $position = $emp['position'] ?? [];
                        $employees[] = [
                            'id' => $emp['id'],
                            'employee_id' => $emp['id'],
                            'full_name' => $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? '')),
                            'first_name' => $name['first_name'] ?? '',
                            'last_name' => $name['surname'] ?? '',
                            'middle_name' => $name['middle_name'] ?? '',
                            'email' => $contact['email'] ?? '',
                            'department' => is_array($department) ? ($department['name'] ?? 'N/A') : 'N/A',
                            'position' => $position['name'] ?? 'N/A'
                        ];
                    }
                    echo json_encode([
                        'success' => true,
                        'data' => $employees,
                        'total' => $total,
                        'current_page' => $page,
                        'last_page' => max(1, (int)ceil($total / $perPage))
                    ]);
                    exit;
                }
            }
            
            // Admin or fallback: use general search
            $result = $hrAPI->searchEmployees($query, $page, $perPage);
            
            if (isset($result['error'])) {
                echo json_encode(['success' => false, 'error' => $result['error']]);
                exit;
            }
            
            $employees = [];
            foreach ($result['data'] as $emp) {
                $name = $emp['name'] ?? [];
                $contact = $emp['contact'] ?? [];
                $department = $emp['department'] ?? $emp['unit'] ?? [];
                $position = $emp['position'] ?? [];
                
                $employees[] = [
                    'id' => $emp['id'],
                    'employee_id' => $emp['id'],
                    'full_name' => $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? '')),
                    'first_name' => $name['first_name'] ?? '',
                    'last_name' => $name['surname'] ?? '',
                    'middle_name' => $name['middle_name'] ?? '',
                    'email' => $contact['email'] ?? '',
                    'department' => is_array($department) ? ($department['name'] ?? 'N/A') : 'N/A',
                    'position' => $position['name'] ?? 'N/A'
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $employees,
                'total' => $result['total'],
                'current_page' => $result['current_page'],
                'last_page' => $result['last_page']
            ]);
            break;
        
        case 'sectors':
            $search = trim($_GET['search'] ?? '');
            $result = $hrAPI->getSectors($search ?: null);
            echo json_encode([
                'success' => true,
                'data' => $result['data'] ?? []
            ]);
            break;
        
        case 'units':
            $sectorId = !empty($_GET['sector_id']) ? (int)$_GET['sector_id'] : null;
            $unitType = trim($_GET['unit_type'] ?? '') ?: null;
            $search = trim($_GET['search'] ?? '') ?: null;
            $result = $hrAPI->getUnits($sectorId, $unitType, $search);
            echo json_encode([
                'success' => true,
                'data' => $result['data'] ?? []
            ]);
            break;
        
        case 'current-employee':
            $employee = $hrAPI->getCurrentEmployee();
            if ($employee) {
                echo json_encode(['success' => true, 'data' => $employee]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Current employee not found']);
            }
            break;
        
        case 'get':
            $employeeId = trim($_GET['id'] ?? '');
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Employee ID required']);
                exit;
            }
            
            $employee = $hrAPI->getEmployeeById($employeeId);
            
            if (empty($employee)) {
                echo json_encode([
                    'success' => false, 
                    'error' => "Employee '$employeeId' not found in HR System"
                ]);
                exit;
            }
            
            $mappedData = $hrAPI->mapEmployeeData($employee);
            
            if (empty($mappedData)) {
                echo json_encode([
                    'success' => false, 
                    'error' => 'Failed to process employee data'
                ]);
                exit;
            }
            
            echo json_encode([
                'success' => true,
                'data' => $mappedData,
                'raw' => $employee
            ]);
            break;
        
        case 'import':
            $employeeId = trim($_POST['employee_id'] ?? $_GET['employee_id'] ?? $_GET['id'] ?? '');
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Employee ID required']);
                exit;
            }
            
            $hrEmployeeId = $conn->real_escape_string($employeeId);
            $existing = $conn->query("SELECT id, CONCAT(first_name, ' ', last_name) as name, sync_status, created_by
                                      FROM faculty_researchers 
                                      WHERE hr_employee_id = '$hrEmployeeId' 
                                      LIMIT 1");
            
            $isReimport = false;
            $isClaim = false;
            $existingFacultyId = null;
            
            if ($existing && $existing->num_rows > 0) {
                $existingData = $existing->fetch_assoc();
                $existingFacultyId = $existingData['id'];
                
                // Allow re-import if sync_status is 'n/a' (employee was moved away but is back now)
                if (!empty($existingData['sync_status']) && $existingData['sync_status'] === 'n/a') {
                    // Employee exists but has n/a status - allow re-import to reactivate
                    // The syncEmployee function will update the existing record
                    $isReimport = true;
                    debugLog("Re-importing employee with n/a status", [
                        'faculty_id' => $existingData['id'],
                        'hr_employee_id' => $hrEmployeeId
                    ]);
                } else {
                    // Employee is already imported and active
                    // For coordinators: Allow "claiming" - update created_by to the coordinator
                    // This lets coordinators see employees in their list even if imported by someone else
                    if ($userRole === 'coordinator' && $existingData['created_by'] != $userId) {
                        $isClaim = true;
                        debugLog("Coordinator claiming existing employee", [
                            'faculty_id' => $existingData['id'],
                            'hr_employee_id' => $hrEmployeeId,
                            'previous_created_by' => $existingData['created_by'],
                            'new_created_by' => $userId
                        ]);
                    } elseif ($existingData['created_by'] == $userId) {
                        // Already owned by this user
                        echo json_encode([
                            'success' => false,
                            'error' => 'You have already imported this employee',
                            'existing_id' => $existingData['id'],
                            'existing_name' => $existingData['name']
                        ]);
                        exit;
                    } else {
                        // Admin trying to import already-imported employee - just return info
                        echo json_encode([
                            'success' => false,
                            'error' => 'This employee is already imported',
                            'existing_id' => $existingData['id'],
                            'existing_name' => $existingData['name']
                        ]);
                        exit;
                    }
                }
            }
            
            // Coordinator: verify employee is allowed based on their scope mode
            // - all_units: can import anyone
            // - specific_units: can import from assigned units (stored in coordinator_scopes)
            // - own_unit: can import from their parent unit only (use HR API unit-employees)
            if ($userRole === 'coordinator') {
                $skipVerification = false;
                
                // Get coordinator's scope mode and assigned units from database
                $coordStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
                $coordStmt->bind_param("i", $userId);
                $coordStmt->execute();
                $coordResult = $coordStmt->get_result()->fetch_assoc();
                $coordEmployeeId = $coordResult['employee_id'] ?? null;
                $coordStmt->close();
                
                $coordinatorScopeMode = 'own_unit';
                $coordinatorAssignedUnits = [];
                
                if ($coordEmployeeId) {
                    // Get scope mode from coordinator_assignments
                    $scopeModeStmt = $conn->prepare("SELECT scope_mode FROM coordinator_assignments WHERE employee_id = ? COLLATE utf8mb4_general_ci AND status = 'active' AND coordinator_type = 'faculty' LIMIT 1");
                    $scopeModeStmt->bind_param("s", $coordEmployeeId);
                    $scopeModeStmt->execute();
                    $scopeModeResult = $scopeModeStmt->get_result()->fetch_assoc();
                    $coordinatorScopeMode = $scopeModeResult['scope_mode'] ?? 'own_unit';
                    $scopeModeStmt->close();
                    
                    // If specific_units, get the assigned units
                    if ($coordinatorScopeMode === 'specific_units') {
                        $scopeStmt = $conn->prepare("SELECT unit_name FROM coordinator_scopes WHERE employee_id = ? COLLATE utf8mb4_general_ci");
                        $scopeStmt->bind_param("s", $coordEmployeeId);
                        $scopeStmt->execute();
                        $scopeResult = $scopeStmt->get_result();
                        while ($row = $scopeResult->fetch_assoc()) {
                            $coordinatorAssignedUnits[] = strtolower(trim($row['unit_name']));
                        }
                        $scopeStmt->close();
                    }
                }
                
                debugLog("Coordinator import verification - scope check", [
                    'scope_mode' => $coordinatorScopeMode,
                    'assigned_units_count' => count($coordinatorAssignedUnits),
                    'employee_to_import' => $employeeId
                ]);
                
                // Determine verification based on scope mode
                if ($coordinatorScopeMode === 'all_units') {
                    // Can import anyone - skip verification
                    $skipVerification = true;
                    debugLog("Coordinator verification SKIPPED - all_units scope");
                    
                } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorAssignedUnits)) {
                    // Verify based on employee's unit from HR data
                    // Fetch employee data from HR to check their department/unit
                    $hrEmployee = $hrAPI->getEmployeeById($employeeId);
                    
                    if ($hrEmployee) {
                        // Get department/unit info from HR employee data (handle various data structures)
                        $hrDepartment = '';
                        $hrUnit = '';
                        
                        // Extract department name (might be array or string)
                        if (isset($hrEmployee['department'])) {
                            if (is_array($hrEmployee['department'])) {
                                $hrDepartment = strtolower(trim($hrEmployee['department']['name'] ?? ''));
                            } elseif (is_string($hrEmployee['department'])) {
                                $hrDepartment = strtolower(trim($hrEmployee['department']));
                            }
                        }
                        
                        // Extract unit name (might be array or string)
                        if (isset($hrEmployee['unit'])) {
                            if (is_array($hrEmployee['unit'])) {
                                $hrUnit = strtolower(trim($hrEmployee['unit']['name'] ?? ''));
                            } elseif (is_string($hrEmployee['unit'])) {
                                $hrUnit = strtolower(trim($hrEmployee['unit']));
                            }
                        }
                        
                        debugLog("Checking employee against assigned units", [
                            'hr_department' => $hrDepartment,
                            'hr_unit' => $hrUnit,
                            'assigned_units_sample' => implode(',', array_slice($coordinatorAssignedUnits, 0, 5)),
                            'assigned_units_count' => count($coordinatorAssignedUnits)
                        ]);
                        
                        // Check if employee's department or unit matches any assigned unit
                        foreach ($coordinatorAssignedUnits as $assignedUnit) {
                            // Flexible matching: exact match, contains, or partial match
                            if ($hrDepartment === $assignedUnit || $hrUnit === $assignedUnit ||
                                (!empty($hrDepartment) && strpos($hrDepartment, $assignedUnit) !== false) ||
                                (!empty($hrUnit) && strpos($hrUnit, $assignedUnit) !== false) ||
                                (!empty($hrDepartment) && strpos($assignedUnit, $hrDepartment) !== false) ||
                                (!empty($hrUnit) && strpos($assignedUnit, $hrUnit) !== false)) {
                                $skipVerification = true;
                                debugLog("Coordinator verification PASSED - employee unit matches assigned unit", [
                                    'matched_unit' => $assignedUnit,
                                    'hr_department' => $hrDepartment,
                                    'hr_unit' => $hrUnit
                                ]);
                                break;
                            }
                        }
                        
                        if (!$skipVerification) {
                            debugLog("Coordinator verification FAILED - employee not in any assigned unit", [
                                'hr_department' => $hrDepartment,
                                'hr_unit' => $hrUnit,
                                'assigned_units_count' => count($coordinatorAssignedUnits)
                            ]);
                            echo json_encode([
                                'success' => false,
                                'error' => "This employee's unit ($hrDepartment / $hrUnit) is not in your assigned units. You can only import employees from your assigned units."
                            ]);
                            exit;
                        }
                    } else {
                        // Can't fetch HR data - allow import but log warning
                        $skipVerification = true;
                        debugLog("Coordinator verification SKIPPED - could not fetch HR data, allowing import");
                    }
                    
                } else {
                    // own_unit scope - use original HR API verification
                    $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                    $allowedIds = [];
                    foreach ($unitEmployees as $emp) {
                        $allowedIds[] = normalizeEmployeeId($emp['id'] ?? '');
                    }
                    $normalizedEmployeeId = normalizeEmployeeId($employeeId);
                    
                    debugLog("Coordinator unit verification (own_unit mode)", [
                        'employee_to_import' => $employeeId,
                        'normalized_employee_id' => $normalizedEmployeeId,
                        'allowed_ids_count' => count($allowedIds),
                        'allowed_ids' => implode(',', array_slice($allowedIds, 0, 10)),
                        'is_allowed' => in_array($normalizedEmployeeId, $allowedIds) ? 'YES' : 'NO'
                    ]);
                    
                    if (in_array($normalizedEmployeeId, $allowedIds)) {
                        $skipVerification = true;
                        debugLog("Coordinator verification PASSED (own_unit mode)");
                    } else {
                        if (empty($unitEmployees)) {
                            debugLog("Coordinator verification FAILED - no unit employees");
                            echo json_encode([
                                'success' => false,
                                'error' => 'Unable to verify unit employees. You can only import employees from your unit.'
                            ]);
                        } else {
                            debugLog("Coordinator verification FAILED - employee not in unit", [
                                'employee_id' => $normalizedEmployeeId,
                                'allowed_count' => count($allowedIds)
                            ]);
                            echo json_encode([
                                'success' => false,
                                'error' => 'You can only import employees from your unit. This employee is not in your assigned unit.'
                            ]);
                        }
                        exit;
                    }
                }
            }
            
            // Handle claim case: coordinator claiming an existing employee
            if ($isClaim && $existingFacultyId) {
                debugLog("CLAIM STARTING", [
                    'faculty_id' => $existingFacultyId,
                    'employee_id' => $employeeId,
                    'new_created_by' => $userId
                ]);
                
                // Update created_by to the coordinator and sync the data
                $claimStmt = $conn->prepare("UPDATE faculty_researchers SET created_by = ?, last_synced_at = NOW() WHERE id = ?");
                $claimStmt->bind_param("ii", $userId, $existingFacultyId);
                $claimSuccess = $claimStmt->execute();
                $claimStmt->close();
                
                if ($claimSuccess) {
                    // Also sync the employee data from HR
                    $syncResult = $hrAPI->syncEmployee($employeeId, $userId);
                    
                    debugLog("CLAIM COMPLETED", [
                        'faculty_id' => $existingFacultyId,
                        'created_by_updated_to' => $userId,
                        'sync_success' => $syncResult['success'] ? 'YES' : 'NO'
                    ]);
                    
                    if (file_exists('ActivityLogger.php')) {
                        require_once 'ActivityLogger.php';
                        $logger = new ActivityLogger($conn, $userId);
                        $logger->logUpdate('faculty_researchers', $existingFacultyId, 
                            "Claimed employee (HR ID: $employeeId) - ownership transferred to coordinator");
                    }
                    
                    echo json_encode([
                        'success' => true,
                        'message' => 'Employee claimed successfully! You can now manage this researcher.',
                        'faculty_id' => $existingFacultyId,
                        'is_claim' => true,
                        'redirect' => 'facultyresearcherprofile.php?id=' . $existingFacultyId
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'error' => 'Failed to claim employee: ' . $conn->error
                    ]);
                }
                exit;
            }
            
            debugLog("IMPORT STARTING", [
                'employee_id' => $employeeId,
                'user_id' => $userId,
                'user_role' => $userRole,
                'is_reimport' => $isReimport ? 'YES' : 'NO'
            ]);
            
            $result = $hrAPI->syncEmployee($employeeId, $userId);
            
            debugLog("IMPORT COMPLETED", [
                'success' => $result['success'] ? 'YES' : 'NO',
                'faculty_id' => $result['faculty_id'] ?? 'NULL',
                'error' => $result['error'] ?? 'none'
            ]);
            
            error_log("Import result - Success: " . ($result['success'] ? 'true' : 'false') . 
                      ", Faculty ID: " . ($result['faculty_id'] ?? 'NULL') . 
                      ", Error: " . ($result['error'] ?? 'none'));
            
            if ($result['success']) {
                // Verify the record was created with correct created_by
                $verifyStmt = $conn->prepare("SELECT id, created_by, department, home_unit FROM faculty_researchers WHERE id = ?");
                $verifyStmt->bind_param("i", $result['faculty_id']);
                $verifyStmt->execute();
                $verifyResult = $verifyStmt->get_result()->fetch_assoc();
                $verifyStmt->close();
                
                $createdByMatches = ($verifyResult['created_by'] == $userId);
                
                error_log("Import verification - Faculty ID: {$result['faculty_id']}, " .
                         "Created By: " . ($verifyResult['created_by'] ?? 'NULL') . ", " .
                         "Expected Created By: $userId, " .
                         "MATCH: " . ($createdByMatches ? 'YES' : 'NO') . ", " .
                         "Department: " . ($verifyResult['department'] ?? 'NULL') . ", " .
                         "Home Unit: " . ($verifyResult['home_unit'] ?? 'NULL'));
                
                // If created_by doesn't match, fix it immediately
                if (!$createdByMatches) {
                    error_log("CRITICAL: created_by mismatch! Fixing now...");
                    $fixStmt = $conn->prepare("UPDATE faculty_researchers SET created_by = ? WHERE id = ?");
                    $fixStmt->bind_param("ii", $userId, $result['faculty_id']);
                    $fixStmt->execute();
                    $fixStmt->close();
                    error_log("Fixed created_by for faculty_id: " . $result['faculty_id'] . " to user_id: " . $userId);
                }
                
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $facultyName = ($result['data']['first_name'] ?? '') . ' ' . ($result['data']['last_name'] ?? '');
                    if ($isReimport) {
                        $logger->logUpdate('faculty_researchers', $result['faculty_id'], 
                            "Re-imported from HR (reactivated): $facultyName (HR ID: $employeeId)");
                    } else {
                        $logger->logCreate('faculty_researchers', $result['faculty_id'], 
                            "Imported from HR: $facultyName (HR ID: $employeeId)");
                    }
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => $isReimport ? 'Employee re-imported and reactivated successfully' : 'Employee imported successfully',
                    'faculty_id' => $result['faculty_id'],
                    'is_reimport' => $isReimport,
                    'redirect' => 'facultyresearcherprofile.php?id=' . $result['faculty_id'],
                    'debug_created_by' => $verifyResult['created_by'] ?? null,
                    'debug_expected_created_by' => $userId,
                    'debug_created_by_match' => $createdByMatches,
                    'debug_department' => $verifyResult['department'] ?? null,
                    'debug_home_unit' => $verifyResult['home_unit'] ?? null
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to import employee'
                ]);
            }
            break;
        
        case 'import_personnel':
            $employeeId = trim($_POST['employee_id'] ?? $_GET['employee_id'] ?? $_GET['id'] ?? '');
            
            if (empty($employeeId)) {
                echo json_encode(['success' => false, 'error' => 'Employee ID required']);
                exit;
            }
            
            $hrEmployeeId = $conn->real_escape_string($employeeId);
            $existing = $conn->query("SELECT id, CONCAT(first_name, ' ', last_name) as name, sync_status, created_by
                                      FROM personnel_researchers 
                                      WHERE hr_employee_id = '$hrEmployeeId' 
                                      LIMIT 1");
            
            $isReimport = false;
            if ($existing && $existing->num_rows > 0) {
                $existingData = $existing->fetch_assoc();
                
                // Allow re-import if sync_status is 'n/a'
                if (!empty($existingData['sync_status']) && $existingData['sync_status'] === 'n/a') {
                    $isReimport = true;
                    debugLog("Re-importing personnel with n/a status", [
                        'personnel_id' => $existingData['id'],
                        'hr_employee_id' => $hrEmployeeId
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'error' => 'This employee is already imported as personnel',
                        'existing_id' => $existingData['id'],
                        'existing_name' => $existingData['name']
                    ]);
                    exit;
                }
            }
            
            // Coordinator: verify employee is allowed based on their scope mode
            if ($userRole === 'coordinator') {
                $skipVerification = false;
                
                // Get coordinator's scope mode and assigned units from database
                $coordStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
                $coordStmt->bind_param("i", $userId);
                $coordStmt->execute();
                $coordResult = $coordStmt->get_result()->fetch_assoc();
                $coordEmployeeId = $coordResult['employee_id'] ?? null;
                $coordStmt->close();
                
                $coordinatorScopeMode = 'own_unit';
                $coordinatorAssignedUnits = [];
                
                if ($coordEmployeeId) {
                    // Get scope mode from coordinator_assignments (check for personnel type)
                    $scopeModeStmt = $conn->prepare("SELECT scope_mode FROM coordinator_assignments WHERE employee_id = ? COLLATE utf8mb4_general_ci AND status = 'active' AND coordinator_type = 'personnel' LIMIT 1");
                    $scopeModeStmt->bind_param("s", $coordEmployeeId);
                    $scopeModeStmt->execute();
                    $scopeModeResult = $scopeModeStmt->get_result()->fetch_assoc();
                    $coordinatorScopeMode = $scopeModeResult['scope_mode'] ?? 'own_unit';
                    $scopeModeStmt->close();
                    
                    // If specific_units, get the assigned units
                    if ($coordinatorScopeMode === 'specific_units') {
                        $scopeStmt = $conn->prepare("SELECT unit_name FROM coordinator_scopes WHERE employee_id = ? COLLATE utf8mb4_general_ci");
                        $scopeStmt->bind_param("s", $coordEmployeeId);
                        $scopeStmt->execute();
                        $scopeResult = $scopeStmt->get_result();
                        while ($row = $scopeResult->fetch_assoc()) {
                            $coordinatorAssignedUnits[] = strtolower(trim($row['unit_name']));
                        }
                        $scopeStmt->close();
                    }
                }
                
                debugLog("Personnel import verification - scope check", [
                    'scope_mode' => $coordinatorScopeMode,
                    'assigned_units_count' => count($coordinatorAssignedUnits),
                    'employee_to_import' => $employeeId
                ]);
                
                // Determine verification based on scope mode
                if ($coordinatorScopeMode === 'all_units') {
                    $skipVerification = true;
                    debugLog("Personnel verification SKIPPED - all_units scope");
                    
                } elseif ($coordinatorScopeMode === 'specific_units' && !empty($coordinatorAssignedUnits)) {
                    // Verify based on employee's unit from HR data
                    $hrEmployee = $hrAPI->getEmployeeById($employeeId);
                    
                    if ($hrEmployee) {
                        // Get department/unit info from HR employee data (handle various data structures)
                        $hrDepartment = '';
                        $hrUnit = '';
                        
                        if (isset($hrEmployee['department'])) {
                            if (is_array($hrEmployee['department'])) {
                                $hrDepartment = strtolower(trim($hrEmployee['department']['name'] ?? ''));
                            } elseif (is_string($hrEmployee['department'])) {
                                $hrDepartment = strtolower(trim($hrEmployee['department']));
                            }
                        }
                        
                        if (isset($hrEmployee['unit'])) {
                            if (is_array($hrEmployee['unit'])) {
                                $hrUnit = strtolower(trim($hrEmployee['unit']['name'] ?? ''));
                            } elseif (is_string($hrEmployee['unit'])) {
                                $hrUnit = strtolower(trim($hrEmployee['unit']));
                            }
                        }
                        
                        debugLog("Checking personnel against assigned units", [
                            'hr_department' => $hrDepartment,
                            'hr_unit' => $hrUnit,
                            'assigned_units_count' => count($coordinatorAssignedUnits)
                        ]);
                        
                        foreach ($coordinatorAssignedUnits as $assignedUnit) {
                            if ($hrDepartment === $assignedUnit || $hrUnit === $assignedUnit ||
                                (!empty($hrDepartment) && strpos($hrDepartment, $assignedUnit) !== false) ||
                                (!empty($hrUnit) && strpos($hrUnit, $assignedUnit) !== false) ||
                                (!empty($hrDepartment) && strpos($assignedUnit, $hrDepartment) !== false) ||
                                (!empty($hrUnit) && strpos($assignedUnit, $hrUnit) !== false)) {
                                $skipVerification = true;
                                debugLog("Personnel verification PASSED - unit matches", [
                                    'matched_unit' => $assignedUnit
                                ]);
                                break;
                            }
                        }
                        
                        if (!$skipVerification) {
                            debugLog("Personnel verification FAILED - not in assigned units");
                            echo json_encode([
                                'success' => false,
                                'error' => "This employee's unit ($hrDepartment / $hrUnit) is not in your assigned units."
                            ]);
                            exit;
                        }
                    } else {
                        $skipVerification = true;
                        debugLog("Personnel verification SKIPPED - could not fetch HR data");
                    }
                    
                } else {
                    // own_unit scope - use HR API verification
                    $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                    $allowedIds = [];
                    foreach ($unitEmployees as $emp) {
                        $allowedIds[] = normalizeEmployeeId($emp['id'] ?? '');
                    }
                    $normalizedEmployeeId = normalizeEmployeeId($employeeId);
                    
                    if (in_array($normalizedEmployeeId, $allowedIds)) {
                        $skipVerification = true;
                    } else {
                        echo json_encode([
                            'success' => false,
                            'error' => 'You can only import employees from your unit.'
                        ]);
                        exit;
                    }
                }
            }
            
            // Import personnel using syncPersonnelEmployee
            $result = $hrAPI->syncPersonnelEmployee($employeeId, $userId);
            
            if ($result['success']) {
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $personnelName = ($result['data']['first_name'] ?? '') . ' ' . ($result['data']['last_name'] ?? '');
                    if ($isReimport) {
                        $logger->logUpdate('personnel_researchers', $result['personnel_id'], 
                            "Re-imported from HR (reactivated): $personnelName (HR ID: $employeeId)");
                    } else {
                        $logger->logCreate('personnel_researchers', $result['personnel_id'], 
                            "Imported from HR: $personnelName (HR ID: $employeeId)");
                    }
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => $isReimport ? 'Personnel re-imported and reactivated successfully' : 'Personnel imported successfully',
                    'personnel_id' => $result['personnel_id'],
                    'is_reimport' => $isReimport,
                    'redirect' => 'personnelresearcherprofile.php?id=' . $result['personnel_id']
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to import personnel'
                ]);
            }
            break;
        
        case 'sync_personnel':
            $personnelId = (int)($_POST['personnel_id'] ?? 0);
            
            if (empty($personnelId)) {
                echo json_encode(['success' => false, 'error' => 'Personnel ID required']);
                exit;
            }
            
            $personnel = $conn->query("SELECT hr_employee_id, CONCAT(first_name, ' ', last_name) as name 
                                     FROM personnel_researchers 
                                     WHERE id = $personnelId 
                                     LIMIT 1")->fetch_assoc();
            
            if (empty($personnel)) {
                echo json_encode(['success' => false, 'error' => 'Personnel not found']);
                exit;
            }
            
            if (empty($personnel['hr_employee_id'])) {
                echo json_encode([
                    'success' => false, 
                    'error' => 'This personnel was not imported from HR and cannot be synced'
                ]);
                exit;
            }
            
            // Check if employee still exists in HR
            $hrEmployee = $hrAPI->getEmployeeById($personnel['hr_employee_id']);
            if (empty($hrEmployee) || empty($hrEmployee['id'])) {
                $conn->query("
                    UPDATE personnel_researchers 
                    SET sync_status = 'n/a' 
                    WHERE id = $personnelId
                ");
                
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('personnel_researchers', $personnelId, 
                        "Sync status set to N/A: {$personnel['name']} not found in HR system");
                }
                
                echo json_encode([
                    'success' => false,
                    'error' => 'Employee not found in HR system. Sync status has been set to N/A.',
                    'sync_status_updated' => true
                ]);
                exit;
            }
            
            $result = $hrAPI->syncPersonnelEmployee($personnel['hr_employee_id'], $userId);
            
            if ($result['success']) {
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('personnel_researchers', $personnelId, 
                        "Synced with HR: {$personnel['name']}");
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Personnel data synced successfully',
                    'updated_at' => date('M d, Y h:i A')
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to sync personnel'
                ]);
            }
            break;
        
        case 'sync':
            $facultyId = (int)($_POST['faculty_id'] ?? 0);
            
            if (empty($facultyId)) {
                echo json_encode(['success' => false, 'error' => 'Faculty ID required']);
                exit;
            }
            
            $faculty = $conn->query("SELECT hr_employee_id, CONCAT(first_name, ' ', last_name) as name 
                                     FROM faculty_researchers 
                                     WHERE id = $facultyId 
                                     LIMIT 1")->fetch_assoc();
            
            if (empty($faculty)) {
                echo json_encode(['success' => false, 'error' => 'Faculty not found']);
                exit;
            }
            
            if (empty($faculty['hr_employee_id'])) {
                echo json_encode([
                    'success' => false, 
                    'error' => 'This faculty was not imported from HR and cannot be synced'
                ]);
                exit;
            }
            
            // For coordinators: Check if employee is in their assigned scope
            if ($userRole === 'coordinator') {
                // Get coordinator's employee_id
                $coordStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
                $coordStmt->bind_param("i", $userId);
                $coordStmt->execute();
                $coordResult = $coordStmt->get_result()->fetch_assoc();
                $coordEmployeeId = $coordResult['employee_id'] ?? null;
                $coordStmt->close();
                
                $isInScope = false;
                
                if ($coordEmployeeId) {
                    // Get coordinator's assigned units from coordinator_scopes
                    $scopeStmt = $conn->prepare("SELECT unit_name FROM coordinator_scopes WHERE employee_id = ? COLLATE utf8mb4_general_ci");
                    $scopeStmt->bind_param("s", $coordEmployeeId);
                    $scopeStmt->execute();
                    $scopeResult = $scopeStmt->get_result();
                    $assignedUnits = [];
                    while ($row = $scopeResult->fetch_assoc()) {
                        $assignedUnits[] = strtolower($row['unit_name']);
                    }
                    $scopeStmt->close();
                    
                    // Get employee's department/home_unit
                    $empStmt = $conn->prepare("SELECT department, home_unit FROM faculty_researchers WHERE id = ?");
                    $empStmt->bind_param("i", $facultyId);
                    $empStmt->execute();
                    $empData = $empStmt->get_result()->fetch_assoc();
                    $empStmt->close();
                    
                    $empDept = strtolower($empData['department'] ?? '');
                    $empUnit = strtolower($empData['home_unit'] ?? '');
                    
                    // Check if employee is in any of the assigned units (flexible matching)
                    foreach ($assignedUnits as $unit) {
                        if ($empDept === $unit || $empUnit === $unit ||
                            strpos($empDept, $unit) !== false || strpos($empUnit, $unit) !== false ||
                            strpos($unit, $empDept) !== false || strpos($unit, $empUnit) !== false) {
                            $isInScope = true;
                            break;
                        }
                    }
                }
                
                if (!$isInScope) {
                    // Employee not in coordinator's assigned scope
                    $conn->query("
                        UPDATE faculty_researchers 
                        SET sync_status = 'n/a' 
                        WHERE id = $facultyId
                    ");
                    
                    if (file_exists('ActivityLogger.php')) {
                        require_once 'ActivityLogger.php';
                        $logger = new ActivityLogger($conn, $userId);
                        $logger->logUpdate('faculty_researchers', $facultyId, 
                            "Sync status set to N/A: {$faculty['name']} not in coordinator's assigned scope");
                    }
                    
                    echo json_encode([
                        'success' => false,
                        'error' => 'Researcher not in your assigned units. Status set to N/A.'
                    ]);
                    exit;
                }
            }
            
            // Check if employee still exists in HR
            $hrEmployee = $hrAPI->getEmployeeById($faculty['hr_employee_id']);
            if (empty($hrEmployee) || empty($hrEmployee['id'])) {
                // Employee not found in HR - set sync_status to 'n/a'
                $conn->query("
                    UPDATE faculty_researchers 
                    SET sync_status = 'n/a' 
                    WHERE id = $facultyId
                ");
                
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('faculty_researchers', $facultyId, 
                        "Sync status set to N/A: {$faculty['name']} not found in HR system");
                }
                
                echo json_encode([
                    'success' => false,
                    'error' => 'Employee not found in HR system. Sync status has been set to N/A.',
                    'sync_status_updated' => true
                ]);
                exit;
            }
            
            $result = $hrAPI->syncEmployee($faculty['hr_employee_id'], $userId);
            
            if ($result['success']) {
                if (file_exists('ActivityLogger.php')) {
                    require 'ActivityLogger.php';
                    $logger = new ActivityLogger($conn, $userId);
                    $logger->logUpdate('faculty_researchers', $facultyId, 
                        "Synced with HR: {$faculty['name']}");
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Employee data synced successfully',
                    'updated_at' => date('M d, Y h:i A')
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => $result['error'] ?? 'Failed to sync employee'
                ]);
            }
            break;
        
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
    
} catch (Exception $e) {
    error_log("fetch_employee.php exception: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}