<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';
require_once 'spa_helper.php';

// Check if this is an SPA request
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Try to load ActivityLogger (optional)
if (file_exists('ActivityLogger.php')) {
    require 'ActivityLogger.php';
    try {
        $logger = new ActivityLogger($conn, $_SESSION['user_id']);
        $logger->logView('research_outputs', null, 'Accessed research management dashboard');
    } catch (Exception $e) {
        error_log("ActivityLogger error: " . $e->getMessage());
    }
}

// Access control
$userRole = $_SESSION['user_role'] ?? 'admin';
$coordinatorType = $_SESSION['coordinator_type'] ?? null;
$currentUserId = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'User';

// Redirect researchers to their dashboard
if ($userRole === 'researcher') {
    // Researchers should go to their dedicated dashboard
    header("Location: researcher_dashboard.php");
    exit;
}

// Check for researcher role and find Faculty Research Coordinators in their parent unit
$researcherMessage = null;
$facultyCoordinators = [];
$adminInfo = null;

if ($userRole === 'researcher') {
    // Get researcher's parent unit from database (stored on login)
    $researcherParentUnitName = null;
    $checkParentUnitColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'parent_unit'");
    $hasParentUnitColumn = $checkParentUnitColumn->num_rows > 0;
    
    if ($hasParentUnitColumn) {
        $stmt = $conn->prepare("SELECT parent_unit FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $currentUserId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $researcherParentUnitName = $row['parent_unit'];
        }
        $stmt->close();
    }
    
    // Fallback to session if not in database
    if (empty($researcherParentUnitName)) {
        $researcherParentUnitName = $_SESSION['unit_parent'] ?? $_SESSION['unit'] ?? $_SESSION['unit_name'] ?? null;
    }
    
    // Final fallback - if still not available, use a generic message
    if (empty($researcherParentUnitName)) {
        $researcherParentUnitName = 'your parent unit';
    }
    
    // Get all admin information except local admin account (username = 'admin')
    $adminQuery = $conn->query("SELECT id, username, fullname, email FROM users WHERE user_role = 'admin' AND username != 'admin' ORDER BY id");
    $adminInfo = [];
    if ($adminQuery) {
        while ($adminRow = $adminQuery->fetch_assoc()) {
            $adminInfo[] = $adminRow;
        }
    }
    
    // Get Faculty Research Coordinators with matching parent_unit from database
    // This is much simpler - just query by parent_unit match
    $facultyCoordinators = [];
    if ($hasParentUnitColumn && !empty($researcherParentUnitName) && $researcherParentUnitName !== 'your parent unit') {
        $coordinatorQuery = $conn->prepare("
            SELECT ca.employee_id, u.id as user_id, u.username, u.email, u.fullname, u.parent_unit
            FROM coordinator_assignments ca
            INNER JOIN users u ON ca.employee_id COLLATE utf8mb4_general_ci = u.employee_id COLLATE utf8mb4_general_ci
            WHERE ca.coordinator_type = 'faculty' 
            AND ca.status = 'active'
            AND u.user_role = 'coordinator'
            AND u.coordinator_type = 'faculty'
            AND u.parent_unit COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci
        ");
        
        if ($coordinatorQuery) {
            $coordinatorQuery->bind_param("s", $researcherParentUnitName);
            $coordinatorQuery->execute();
            $coordinatorResult = $coordinatorQuery->get_result();
            
            while ($coord = $coordinatorResult->fetch_assoc()) {
                $facultyCoordinators[] = [
                    'name' => !empty($coord['fullname']) ? $coord['fullname'] : $coord['username'],
                    'email' => $coord['email'] ?? '',
                    'username' => $coord['username']
                ];
            }
            
            $coordinatorQuery->close();
        }
    }
    
    // Set message based on findings
    if (!empty($facultyCoordinators)) {
        // Coordinator found - show contact message
        $coordinatorNames = array_map(function($c) {
            return htmlspecialchars($c['name']);
        }, $facultyCoordinators);
        $coordinatorList = implode(', ', $coordinatorNames);
        $coordinatorEmails = array_filter(array_map(function($c) {
            return !empty($c['email']) ? htmlspecialchars($c['email']) : null;
        }, $facultyCoordinators));
        
        $researcherMessage = [
            'type' => 'coordinator_found',
            'coordinators' => $facultyCoordinators,
            'coordinator_list' => $coordinatorList,
            'coordinator_emails' => $coordinatorEmails,
            'parent_unit' => $researcherParentUnitName
        ];
    } else {
        // No coordinator found - show admin contact message
        $researcherMessage = [
            'type' => 'no_coordinator',
            'admins' => $adminInfo,
            'parent_unit' => $researcherParentUnitName
        ];
    }
}

// Check if coordinator's HR position has changed (no longer Research Coordinator)
$coordinatorPositionChanged = false;
if ($userRole === 'coordinator') {
    $checkEmpCol = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'");
    if ($checkEmpCol && $checkEmpCol->num_rows > 0) {
        $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
        $empStmt->bind_param("i", $currentUserId);
        $empStmt->execute();
        $empResult = $empStmt->get_result()->fetch_assoc();
        $empStmt->close();
        
        if (!empty($empResult['employee_id'])) {
            $hrStmt = $conn->prepare("SELECT hr_status FROM synced_research_coordinators WHERE employee_id COLLATE utf8mb4_general_ci = ?");
            $hrStmt->bind_param("s", $empResult['employee_id']);
            $hrStmt->execute();
            $hrResult = $hrStmt->get_result()->fetch_assoc();
            $hrStmt->close();
            
            if ($hrResult && $hrResult['hr_status'] === 'position_changed') {
                $coordinatorPositionChanged = true;
                // Clear coordinator type from session since they can't access coordinator features
                $_SESSION['coordinator_type'] = null;
                $coordinatorType = null;
            }
        }
    }
}

// Coordinators with a type can now access the dashboard directly
// Previously they were redirected, but now they can see the dashboard with their data
// The dashboard shows their stats, charts, and recent researchers

// Refresh coordinator_type from DB for coordinators (e.g. admin just assigned a type)
if ($userRole === 'coordinator' && empty($coordinatorType)) {
    $checkColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'");
    if ($checkColumn && $checkColumn->num_rows > 0) {
        $stmt = $conn->prepare("SELECT coordinator_type FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $currentUserId);
        $stmt->execute();
        $stmt->bind_result($dbCoordType);
        $fetched = $stmt->fetch();
        $stmt->close();
        
        if ($fetched && !empty($dbCoordType)) {
            $_SESSION['coordinator_type'] = $dbCoordType;
            $coordinatorType = $dbCoordType;
            // Coordinator type updated - they can now see dashboard with their assigned permissions
        }
    }
}

// Get all coordinator types for the current user from coordinator_assignments table
$userCoordinatorTypes = [];
if ($userRole === 'coordinator') {
    // Get employee_id for current user
    $empStmt = $conn->prepare("SELECT employee_id FROM users WHERE id = ?");
    $empStmt->bind_param("i", $currentUserId);
    $empStmt->execute();
    $empResult = $empStmt->get_result();
    if ($empRow = $empResult->fetch_assoc()) {
        $employeeId = $empRow['employee_id'];
        if ($employeeId) {
            // Get all active coordinator types for this employee
            $typeStmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
            $typeStmt->bind_param("s", $employeeId);
            $typeStmt->execute();
            $typeResult = $typeStmt->get_result();
            while ($typeRow = $typeResult->fetch_assoc()) {
                $userCoordinatorTypes[] = $typeRow['coordinator_type'];
            }
            $typeStmt->close();
        }
    }
    $empStmt->close();
}

// Determine what data to show based on role and ALL assigned coordinator types
$isAdmin = ($userRole === 'admin');
$showFaculty = $isAdmin || in_array('faculty', $userCoordinatorTypes);
$showStudent = $isAdmin || in_array('student', $userCoordinatorTypes);
$showPersonnel = $isAdmin || in_array('personnel', $userCoordinatorTypes);

// Build WHERE clauses based on role
$facultyWhereClause = '';
$studentWhereClause = '';
$personnelWhereClause = '';

// For coordinators, we show ALL data in their scope (not just what they created)
// This is consistent with how the submission workflow works
// Admin sees everything (no WHERE clause needed)

// Initialize statistics
$stats = [
    'faculty' => ['total' => 0, 'totalOutputs' => 0, 'ongoing' => 0, 'completed' => 0, 'published' => 0],
    'student' => ['total' => 0, 'totalOutputs' => 0, 'ongoing' => 0, 'completed' => 0, 'published' => 0],
    'personnel' => ['total' => 0, 'totalOutputs' => 0, 'ongoing' => 0, 'completed' => 0, 'published' => 0]
];

// Get Faculty Statistics (if allowed)
if ($showFaculty) {
    // Total faculty researchers created by this user (or all if admin)
    $query = "SELECT COUNT(*) as c FROM faculty_researchers fr WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['total'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Total faculty projects (only for researchers created by this user)
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['totalOutputs'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Ongoing projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE (fp.project_status='on-going' OR fp.project_status='ongoing') 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['ongoing'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Completed projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE fp.project_status='completed' 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['completed'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Published projects
    $query = "SELECT COUNT(*) as c 
              FROM faculty_projects fp 
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id 
              WHERE fp.project_status='published' 
              $facultyWhereClause";
    $result = $conn->query($query);
    $stats['faculty']['published'] = $result ? $result->fetch_assoc()['c'] : 0;
}

// Get Student Statistics (if allowed)
if ($showStudent) {
    // Total student researchers created by this user (or all if admin)
    $query = "SELECT COUNT(*) as c FROM student_researchers sr WHERE 1=1 $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['total'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Total research outputs (only for students created by this user)
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE 1=1 $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['totalOutputs'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Ongoing research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='on-going' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['ongoing'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Completed research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='completed' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['completed'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Published research
    $query = "SELECT COUNT(*) as c 
              FROM research_outputs ro 
              INNER JOIN student_researchers sr ON ro.student_id = sr.id 
              WHERE ro.status='published' 
              $studentWhereClause";
    $result = $conn->query($query);
    $stats['student']['published'] = $result ? $result->fetch_assoc()['c'] : 0;
}

// Get Personnel Statistics (if allowed)
if ($showPersonnel) {
    // Total personnel researchers created by this user (or all if admin)
    $query = "SELECT COUNT(*) as c FROM personnel_researchers pr WHERE 1=1 $personnelWhereClause";
    $result = $conn->query($query);
    $stats['personnel']['total'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Total personnel projects (only for researchers created by this user)
    $query = "SELECT COUNT(*) as c 
              FROM personnel_projects pp 
              INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
              WHERE 1=1 $personnelWhereClause";
    $result = $conn->query($query);
    $stats['personnel']['totalOutputs'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Ongoing projects
    $query = "SELECT COUNT(*) as c 
              FROM personnel_projects pp 
              INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
              WHERE (pp.project_status='on-going' OR pp.project_status='ongoing') 
              $personnelWhereClause";
    $result = $conn->query($query);
    $stats['personnel']['ongoing'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Completed projects
    $query = "SELECT COUNT(*) as c 
              FROM personnel_projects pp 
              INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
              WHERE pp.project_status='completed' 
              $personnelWhereClause";
    $result = $conn->query($query);
    $stats['personnel']['completed'] = $result ? $result->fetch_assoc()['c'] : 0;
    
    // Published projects
    $query = "SELECT COUNT(*) as c 
              FROM personnel_projects pp 
              INNER JOIN personnel_researchers pr ON pp.personnel_id = pr.id 
              WHERE pp.project_status='published' 
              $personnelWhereClause";
    $result = $conn->query($query);
    $stats['personnel']['published'] = $result ? $result->fetch_assoc()['c'] : 0;
}

// ========================================
// NEW SUBMISSION WORKFLOW STATISTICS
// ========================================
// Get statistics from research_submissions table (the modern workflow)
$submissionStats = [
    'total_submissions' => 0,
    'pending_submissions' => 0,
    'approved_submissions' => 0,
    'active_projects' => 0,
    'on_going_projects' => 0,
    'completed_projects' => 0,
    'extended_projects' => 0,
    'overdue_projects' => 0
];

// Build WHERE clause for submissions based on role
$submissionWhereClause = '';
if ($userRole === 'coordinator' && !empty($userCoordinatorTypes)) {
    // Coordinators see submissions in their scope based on researcher_type
    $escapedTypes = array_map(function($type) use ($conn) {
        return "'" . $conn->real_escape_string($type) . "'";
    }, $userCoordinatorTypes);
    $typesIn = implode(',', $escapedTypes);
    $submissionWhereClause = " AND rs.researcher_type IN ($typesIn)";
}
// Admin sees everything (no WHERE clause needed)

try {
    // Total submissions
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE 1=1 $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['total_submissions'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Pending submissions (draft, submitted, under_review)
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status IN ('draft', 'submitted', 'under_review') $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['pending_submissions'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Approved submissions
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['approved_submissions'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Active projects (approved with on_going or extended status)
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' AND rs.project_status IN ('on_going', 'extended') $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['active_projects'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // On-going projects
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' AND rs.project_status = 'on_going' $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['on_going_projects'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Extended projects
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' AND rs.project_status = 'extended' $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['extended_projects'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Completed projects
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' AND rs.project_status = 'completed' $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['completed_projects'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
    // Overdue projects
    $query = "SELECT COUNT(*) as c FROM research_submissions rs WHERE rs.status = 'approved' AND rs.project_status IN ('on_going', 'extended') AND rs.current_end_date < CURDATE() $submissionWhereClause";
    $result = $conn->query($query);
    $submissionStats['overdue_projects'] = $result ? (int)$result->fetch_assoc()['c'] : 0;
    
} catch (Exception $e) {
    // Table may not exist yet - leave defaults
    error_log("Submission stats error: " . $e->getMessage());
}

// Check if we have any submission workflow data
$hasSubmissionData = ($submissionStats['total_submissions'] > 0);

// Check if we have any legacy data
$hasLegacyFacultyData = ($stats['faculty']['total'] > 0 || $stats['faculty']['totalOutputs'] > 0);
$hasLegacyStudentData = ($stats['student']['total'] > 0 || $stats['student']['totalOutputs'] > 0);
$hasLegacyPersonnelData = ($stats['personnel']['total'] > 0 || $stats['personnel']['totalOutputs'] > 0);
$hasAnyLegacyData = $hasLegacyFacultyData || $hasLegacyStudentData || $hasLegacyPersonnelData;

// Combined stats for admin
$totalOngoing = $stats['faculty']['ongoing'] + $stats['student']['ongoing'] + $stats['personnel']['ongoing'];
$totalCompleted = $stats['faculty']['completed'] + $stats['student']['completed'] + $stats['personnel']['completed'];
$totalPublished = $stats['faculty']['published'] + $stats['student']['published'] + $stats['personnel']['published'];
$totalRegistered = $stats['faculty']['total'] + $stats['student']['total'] + $stats['personnel']['total'];

// Get Research Outputs Status (Faculty)
$facultyOutputsStats = ['pending' => 0, 'accepted' => 0, 'needs_revision' => 0, 'rejected' => 0];
if ($showFaculty) {
    $query = "SELECT fro.output_status, COUNT(*) as count 
              FROM faculty_research_outputs fro
              INNER JOIN faculty_projects fp ON fro.project_id = fp.id
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE fro.is_latest_version = 1 
              $facultyWhereClause
              GROUP BY fro.output_status";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            if (isset($facultyOutputsStats[$row['output_status']])) {
                $facultyOutputsStats[$row['output_status']] = $row['count'];
            }
        }
    }
}

// Get Research Outputs Status (Student)
$studentOutputsStats = ['pending' => 0, 'accepted' => 0, 'needs_revision' => 0, 'rejected' => 0];
if ($showStudent) {
    $query = "SELECT sro.output_status, COUNT(*) as count 
              FROM student_research_outputs sro
              INNER JOIN research_outputs ro ON sro.research_id = ro.id
              INNER JOIN student_researchers sr ON ro.student_id = sr.id
              WHERE sro.is_latest_version = 1 
              $studentWhereClause
              GROUP BY sro.output_status";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            if (isset($studentOutputsStats[$row['output_status']])) {
                $studentOutputsStats[$row['output_status']] = $row['count'];
            }
        }
    }
}

// Get Funding Data (Faculty Only)
$fundingAllocated = ['institution' => 0, 'government' => 0, 'private' => 0, 'foreign' => 0, 'other' => 0];
$fundingTotal = 0;
if ($showFaculty) {
    $query = "SELECT 
                SUM(fpc.institution_fund) as institution,
                SUM(fpc.government_fund) as government,
                SUM(fpc.private_fund) as `private`,
                SUM(fpc.foreign_fund) as `foreign`,
                SUM(fpc.other_sources) as other
              FROM faculty_project_costs fpc
              INNER JOIN faculty_projects fp ON fpc.project_id = fp.id
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE 1=1 $facultyWhereClause";
    $result = $conn->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        $fundingAllocated['institution'] = (float)($row['institution'] ?? 0);
        $fundingAllocated['government'] = (float)($row['government'] ?? 0);
        $fundingAllocated['private'] = (float)($row['private'] ?? 0);
        $fundingAllocated['foreign'] = (float)($row['foreign'] ?? 0);
        $fundingAllocated['other'] = (float)($row['other'] ?? 0);
        $fundingTotal = array_sum($fundingAllocated);
    }
}

// Department-wise data
$facultyByDept = [];
$studentByDept = [];

if ($showFaculty) {
    $query = "SELECT fr.department, COUNT(*) as count 
              FROM faculty_researchers fr 
              WHERE fr.department IS NOT NULL AND fr.department != '' 
              $facultyWhereClause
              GROUP BY fr.department 
              ORDER BY count DESC 
              LIMIT 8";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $facultyByDept[] = $row;
    }
}

if ($showStudent) {
    $query = "SELECT sr.department, COUNT(*) as count 
              FROM student_researchers sr 
              WHERE sr.department IS NOT NULL AND sr.department != '' 
              $studentWhereClause
              GROUP BY sr.department 
              ORDER BY count DESC 
              LIMIT 8";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $studentByDept[] = $row;
    }
}

// Research Category Distribution (Classification)
$researchCategories = [];
if ($showFaculty) {
    $query = "SELECT fp.classification, COUNT(*) as count 
              FROM faculty_projects fp
              INNER JOIN faculty_researchers fr ON fp.faculty_id = fr.id
              WHERE fp.classification IS NOT NULL AND fp.classification != '' 
              $facultyWhereClause
              GROUP BY fp.classification 
              ORDER BY count DESC";
    $result = $conn->query($query);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $researchCategories[] = $row;
        }
    }
}

// Recent researchers (only those created by this user if coordinator)
$recentResearchers = [];
if ($showFaculty) {
    $query = "SELECT 'faculty' as type, fr.id, CONCAT(fr.first_name, ' ', fr.last_name) as name, 
              fr.department, fr.created_at 
              FROM faculty_researchers fr 
              WHERE 1=1 $facultyWhereClause
              ORDER BY fr.created_at DESC 
              LIMIT 5";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $recentResearchers[] = $row;
    }
}
if ($showStudent) {
    $query = "SELECT 'student' as type, sr.id, CONCAT(sr.first_name, ' ', sr.last_name) as name, 
              sr.department, sr.created_at 
              FROM student_researchers sr 
              WHERE 1=1 $studentWhereClause
              ORDER BY sr.created_at DESC 
              LIMIT 5";
    $result = $conn->query($query);
    while ($row = $result->fetch_assoc()) {
        $recentResearchers[] = $row;
    }
}
usort($recentResearchers, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
$recentResearchers = array_slice($recentResearchers, 0, 8);
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Research Dashboard - ESSU</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="researchStyle.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="essu.png" alt="logo">
        <h3>Research Management</h3>
    </div>
    <div class="sidebar-nav">
        <a href="research.php" class="active"><i class="fa fa-dashboard"></i> Dashboard</a>
        <?php if ($showFaculty): ?>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
        <?php endif; ?>
        <?php if ($showStudent): ?>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
        <?php endif; ?>
        <?php if ($showPersonnel): ?>
            <a href="personnelresearcher.php"><i class="fa fa-briefcase"></i> Personnel</a>
        <?php endif; ?>
        <?php if ($isAdmin): ?>
            <a href="users.php"><i class="fa fa-users-gear"></i> User Management</a>
            <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
        <?php endif; ?>
        <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
    </div>
</div>
<?php else: ?>
<!-- SPA Mode: Load required styles -->
<link rel="stylesheet" href="researchStyle.css">
<?php endif; ?>

<?php if (!$isSpa): ?>
<div class="main">
<?php else: ?>
<!-- Dashboard uses transparent background to show green gradient -->
<style>
    .main, .main-content { background: transparent !important; }
</style>
<?php endif; ?>
<link rel="stylesheet" href="page-common.css">

<!-- Pass PHP data to JavaScript -->
<script>
window.dashboardData = {
    showFaculty: <?= $showFaculty ? 'true' : 'false' ?>,
    showStudent: <?= $showStudent ? 'true' : 'false' ?>,
    showPersonnel: <?= $showPersonnel ? 'true' : 'false' ?>,
    hasLegacyData: <?= $hasAnyLegacyData ? 'true' : 'false' ?>,
    hasSubmissionData: <?= $hasSubmissionData ? 'true' : 'false' ?>,
    facultyOutputsStats: <?= json_encode($facultyOutputsStats) ?>,
    studentOutputsStats: <?= json_encode($studentOutputsStats) ?>,
    fundingAllocated: <?= json_encode($fundingAllocated) ?>,
    fundingTotal: <?= $fundingTotal ?>,
    researchCategories: <?= json_encode($researchCategories) ?>,
    totalOngoing: <?= $totalOngoing ?>,
    totalCompleted: <?= $totalCompleted ?>,
    totalPublished: <?= $totalPublished ?>,
    facultyStats: <?= json_encode($stats['faculty']) ?>,
    studentStats: <?= json_encode($stats['student']) ?>,
    personnelStats: <?= json_encode($stats['personnel']) ?>,
    submissionStats: <?= json_encode($submissionStats) ?>,
    facultyByDept: <?= json_encode($facultyByDept) ?>,
    studentByDept: <?= json_encode($studentByDept) ?>,
    userRole: '<?= $userRole ?>'
};
</script>

    <div class="content">
        <!-- Page Header Banner -->
        <div class="page-header-banner">
            <div class="header-content">
                <div class="header-left">
                    <i class="fa fa-chart-line header-icon"></i>
                    <div>
                        <h1>Research Dashboard</h1>
                        <p>Overview of research activities and statistics</p>
                    </div>
                </div>
                <div class="header-right">
                    <?php 
                    $roleBadgeText = 'User';
                    if ($userRole === 'admin') {
                        $roleBadgeText = 'Admin';
                    } elseif ($userRole === 'coordinator') {
                        if (!empty($userCoordinatorTypes)) {
                            $roleBadgeText = implode(' / ', array_map(function($t) { return ucfirst($t); }, $userCoordinatorTypes)) . ' Coordinator';
                        } else {
                            $roleBadgeText = 'Coordinator';
                        }
                    } elseif ($userRole === 'researcher') {
                        $roleBadgeText = 'Researcher';
                    } else {
                        $roleBadgeText = ucfirst($userRole ?? 'User');
                    }
                    ?>
                    <span class="role-badge-new">
                        <i class="fa fa-<?= $userRole === 'admin' ? 'shield-halved' : 'user-tie' ?>"></i>
                        <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                        <span style="opacity: 0.6; margin: 0 4px;">•</span>
                        <?= $roleBadgeText ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Coordinator position changed: access revoked -->
        <?php if ($coordinatorPositionChanged): ?>
        <div class="coordinator-type-alert" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(220, 38, 38, 0.3); display: flex; align-items: center; gap: 12px;">
            <i class="fa fa-user-times" style="font-size: 22px; flex-shrink: 0;"></i>
            <span><strong>Coordinator Access Revoked:</strong> Your coordinator privileges have been deactivated because you are no longer designated as Research Coordinator in the HR System. If you believe this is an error, please contact the administrator.</span>
        </div>
        <?php endif; ?>
        
        <!-- Coordinator without type: ask to contact admin -->
        <?php if ($userRole === 'coordinator' && empty($coordinatorType) && !$coordinatorPositionChanged): ?>
        <div class="coordinator-type-alert" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(217, 119, 6, 0.3); display: flex; align-items: center; gap: 12px;">
            <i class="fa fa-exclamation-triangle" style="font-size: 22px; flex-shrink: 0;"></i>
            <span><strong>Action required:</strong> You are set as a coordinator but do not have a coordinator type yet. Please contact the administrator to assign you a coordinator type (Faculty or Student) so you can access the full dashboard.</span>
        </div>
        <?php endif; ?>
        
        <!-- Researcher: Coordinator found message -->
        <?php if ($researcherMessage && $researcherMessage['type'] === 'coordinator_found'): ?>
        <div class="researcher-alert" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 20px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <i class="fa fa-info-circle" style="font-size: 24px; flex-shrink: 0; align-self: flex-start; margin-top: 0;"></i>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 600;">Access to Researcher Dashboard</h3>
                    <p style="margin: 0 0 15px 0; line-height: 1.6;">
                        To access more features or the full researcher dashboard, please contact your Faculty Research Coordinator<?= count($researcherMessage['coordinators']) > 1 ? 's' : '' ?>:
                    </p>
                    <div style="background: rgba(255, 255, 255, 0.15); padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa fa-user-tie" style="flex-shrink: 0;"></i> <span>Faculty Research Coordinator<?= count($researcherMessage['coordinators']) > 1 ? 's' : '' ?>:</span>
                        </div>
                        <?php foreach ($researcherMessage['coordinators'] as $coord): ?>
                        <div style="margin-bottom: 8px; padding-left: 20px;">
                            <strong><?= htmlspecialchars($coord['name']) ?></strong>
                            <?php if (!empty($coord['email'])): ?>
                                <br style="margin-top: 4px;"><span style="display: inline-flex; align-items: center; gap: 6px;"><i class="fa fa-envelope" style="flex-shrink: 0;"></i> <a href="mailto:<?= htmlspecialchars($coord['email']) ?>" style="color: #93c5fd; text-decoration: none;"><?= htmlspecialchars($coord['email']) ?></a></span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <p style="margin: 0; font-size: 14px; opacity: 0.9; display: flex; align-items: center; gap: 8px;">
                        <i class="fa fa-building" style="flex-shrink: 0;"></i> <span>Unit: <strong><?= htmlspecialchars($researcherMessage['parent_unit']) ?></strong></span>
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Researcher: No coordinator found message -->
        <?php if ($researcherMessage && $researcherMessage['type'] === 'no_coordinator'): ?>
        <div class="researcher-alert" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 20px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(217, 119, 6, 0.3);">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <i class="fa fa-exclamation-triangle" style="font-size: 24px; flex-shrink: 0; align-self: flex-start; margin-top: 0;"></i>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 600;">No Faculty Research Coordinator Available</h3>
                    <p style="margin: 0 0 15px 0; line-height: 1.6;">
                        There are currently no Faculty Research Coordinators assigned in <strong><?= htmlspecialchars($researcherMessage['parent_unit']) ?></strong>.
                    </p>
                    <?php if ($researcherMessage['parent_unit'] === 'your parent unit'): ?>
                    <p style="margin: 0 0 15px 0; font-size: 14px; opacity: 0.9; font-style: italic; display: flex; align-items: center; gap: 8px;">
                        <i class="fa fa-info-circle" style="flex-shrink: 0;"></i> <span>Note: Parent unit information is not available. Please contact the administrator to verify your unit assignment.</span>
                    </p>
                    <?php endif; ?>
                    <?php if (!empty($researcherMessage['admins'])): ?>
                    <div style="background: rgba(255, 255, 255, 0.15); padding: 15px; border-radius: 8px;">
                        <div style="font-weight: 600; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa fa-user-shield" style="flex-shrink: 0;"></i> <span>Please contact the Administrator<?= count($researcherMessage['admins']) > 1 ? 's' : '' ?>:</span>
                        </div>
                        <?php foreach ($researcherMessage['admins'] as $admin): ?>
                        <div style="padding-left: 20px; margin-bottom: 10px;">
                            <strong>
                                <?php 
                                $displayName = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : htmlspecialchars($admin['username']);
                                echo $displayName;
                                ?>
                            </strong>
                            <?php if (!empty($admin['email'])): ?>
                                <br style="margin-top: 4px;"><span style="display: inline-flex; align-items: center; gap: 6px;"><i class="fa fa-envelope" style="flex-shrink: 0;"></i> <a href="mailto:<?= htmlspecialchars($admin['email']) ?>" style="color: #fef3c7; text-decoration: none;"><?= htmlspecialchars($admin['email']) ?></a></span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p style="margin: 15px 0 0 0; font-size: 14px; opacity: 0.9;">
                        Please contact the system administrator for assistance.
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Data Scope Indicator (for coordinators with type) -->
        <?php if ($userRole === 'coordinator' && !empty($userCoordinatorTypes)): ?>
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);">
            <i class="fa fa-info-circle"></i> 
            <strong>Note:</strong> You are viewing <?= implode(' and ', array_map('ucfirst', $userCoordinatorTypes)) ?> research data in your coordinator scope.
        </div>
        <?php endif; ?>

        <!-- Research Submissions Overview (Primary Stats - shown for all users) -->
        <div class="section-title">
            <i class="fa fa-flask"></i>
            Research Projects Overview
        </div>
        <div class="stats-grid">
            <div class="stat-card" style="--delay: 0; --card-color: #2563eb; --card-color-fade: rgba(37, 99, 235, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['total_submissions'] ?></div>
                        <div class="label">Total Submissions</div>
                        <div class="subtitle">All research proposals</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);"><i class="fa fa-file-lines"></i></div>
                </div>
            </div>
            <div class="stat-card" style="--delay: 1; --card-color: #f59e0b; --card-color-fade: rgba(245, 158, 11, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['active_projects'] ?></div>
                        <div class="label">Active Projects</div>
                        <div class="subtitle">On-going + Extended</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);"><i class="fa fa-spinner fa-spin"></i></div>
                </div>
            </div>
            <div class="stat-card" style="--delay: 2; --card-color: #10b981; --card-color-fade: rgba(16, 185, 129, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['completed_projects'] ?></div>
                        <div class="label">Completed Projects</div>
                        <div class="subtitle">Successfully finished</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #10b981 0%, #34d399 100%);"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
            <div class="stat-card" style="--delay: 3; --card-color: #8b5cf6; --card-color-fade: rgba(139, 92, 246, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['pending_submissions'] ?></div>
                        <div class="label">Pending Review</div>
                        <div class="subtitle">Awaiting approval</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%);"><i class="fa fa-clock"></i></div>
                </div>
            </div>
        </div>

        <?php if ($submissionStats['overdue_projects'] > 0): ?>
        <!-- Overdue Alert -->
        <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(220, 38, 38, 0.3); display: flex; align-items: center; gap: 12px;">
            <i class="fa fa-exclamation-triangle" style="font-size: 22px; flex-shrink: 0;"></i>
            <span><strong><?= $submissionStats['overdue_projects'] ?> Overdue Project<?= $submissionStats['overdue_projects'] > 1 ? 's' : '' ?>:</strong> Some projects have passed their end date and may need extension or completion.</span>
        </div>
        <?php endif; ?>

        <!-- Project Status Breakdown -->
        <?php if ($submissionStats['approved_submissions'] > 0): ?>
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-tasks"></i>
            Project Status Breakdown
        </div>
        <div class="stats-grid">
            <div class="stat-card" style="--delay: 0; --card-color: #0ea5e9; --card-color-fade: rgba(14, 165, 233, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['on_going_projects'] ?></div>
                        <div class="label">On-Going</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #0ea5e9 0%, #38bdf8 100%);"><i class="fa fa-play-circle"></i></div>
                </div>
            </div>
            <div class="stat-card" style="--delay: 1; --card-color: #f97316; --card-color-fade: rgba(249, 115, 22, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['extended_projects'] ?></div>
                        <div class="label">Extended</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #f97316 0%, #fb923c 100%);"><i class="fa fa-calendar-plus"></i></div>
                </div>
            </div>
            <div class="stat-card" style="--delay: 2; --card-color: #22c55e; --card-color-fade: rgba(34, 197, 94, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['completed_projects'] ?></div>
                        <div class="label">Completed</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #22c55e 0%, #4ade80 100%);"><i class="fa fa-flag-checkered"></i></div>
                </div>
            </div>
            <?php if ($submissionStats['overdue_projects'] > 0): ?>
            <div class="stat-card" style="--delay: 3; --card-color: #ef4444; --card-color-fade: rgba(239, 68, 68, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $submissionStats['overdue_projects'] ?></div>
                        <div class="label">Overdue</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);"><i class="fa fa-exclamation-circle"></i></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Researcher Records Overview (Only show if there's data in legacy tables) -->
        <?php if ($hasAnyLegacyData): ?>
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-users"></i>
            Researcher Records
        </div>
        <div class="stats-grid">
            <?php if ($showFaculty && $hasLegacyFacultyData): ?>
            <div class="stat-card" style="--delay: 0; --card-color: #064e1a; --card-color-fade: rgba(6, 78, 26, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $stats['faculty']['total'] ?></div>
                        <div class="label">Faculty Researchers</div>
                        <div class="subtitle"><?= $stats['faculty']['totalOutputs'] ?> projects</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #064e1a 0%, #0b6a24 100%);"><i class="fa fa-chalkboard-teacher"></i></div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($showStudent && $hasLegacyStudentData): ?>
            <div class="stat-card" style="--delay: 1; --card-color: #8b5cf6; --card-color-fade: rgba(139, 92, 246, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $stats['student']['total'] ?></div>
                        <div class="label">Student Researchers</div>
                        <div class="subtitle"><?= $stats['student']['totalOutputs'] ?> outputs</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%);"><i class="fa fa-user-graduate"></i></div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($showPersonnel && $hasLegacyPersonnelData): ?>
            <div class="stat-card" style="--delay: 2; --card-color: #6366f1; --card-color-fade: rgba(99, 102, 241, 0.2);">
                <div class="stat-card-header">
                    <div>
                        <div class="number"><?= $stats['personnel']['total'] ?></div>
                        <div class="label">Personnel Researchers</div>
                        <div class="subtitle"><?= $stats['personnel']['totalOutputs'] ?> projects</div>
                    </div>
                    <div class="icon" style="background: linear-gradient(135deg, #6366f1 0%, #818cf8 100%);"><i class="fa fa-briefcase"></i></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Charts Section - Only show if there's any data to visualize -->
        <?php 
        $hasChartData = $hasSubmissionData || 
                        (array_sum($facultyOutputsStats) > 0) || 
                        (array_sum($studentOutputsStats) > 0) || 
                        ($fundingTotal > 0) || 
                        !empty($researchCategories) ||
                        !empty($facultyByDept) ||
                        !empty($studentByDept) ||
                        ($totalOngoing + $totalCompleted + $totalPublished > 0);
        ?>
        
        <?php if ($hasChartData): ?>
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-chart-bar"></i>
            Analytics & Insights
        </div>
        
        <div class="charts-grid">
            <!-- Overall Status Distribution (Admin only) -->
            <?php if ($userRole === 'admin'): ?>
            <div class="chart-card" style="--delay: 0;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Overall Status Distribution
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="overallStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Faculty Research Status -->
            <?php if ($showFaculty): ?>
            <div class="chart-card" style="--delay: 1;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Faculty Research Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Student Research Status -->
            <?php if ($showStudent): ?>
            <div class="chart-card" style="--delay: 2;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Student Research Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Project Status Distribution (from submissions) -->
            <?php if ($hasSubmissionData && $submissionStats['approved_submissions'] > 0): ?>
            <div class="chart-card" style="--delay: 3;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-chart-pie"></i>
                        Project Status Distribution
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="projectStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Submission Status -->
            <?php if ($hasSubmissionData): ?>
            <div class="chart-card" style="--delay: 4;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-file-lines"></i>
                        Submission Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="submissionStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Faculty Research Outputs Status -->
            <?php if ($showFaculty && (array_sum($facultyOutputsStats) > 0)): ?>
            <div class="chart-card" style="--delay: 5;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-file-alt"></i>
                        Faculty Research Outputs Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyOutputsChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Student Research Outputs Status -->
            <?php if ($showStudent && (array_sum($studentOutputsStats) > 0)): ?>
            <div class="chart-card" style="--delay: 6;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-file-alt"></i>
                        Student Research Outputs Status
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentOutputsChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Funding Distribution -->
            <?php if ($showFaculty && $fundingTotal > 0): ?>
            <div class="chart-card" style="--delay: 7;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-money-bill-wave"></i>
                        Funding Distribution (₱<?= number_format($fundingTotal, 2) ?>)
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="fundingChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Research Category Distribution -->
            <?php if ($showFaculty && !empty($researchCategories)): ?>
            <div class="chart-card" style="--delay: 8;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-layer-group"></i>
                        Research Category Distribution
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Faculty by Department -->
            <?php if ($showFaculty && !empty($facultyByDept)): ?>
            <div class="chart-card" style="--delay: 9;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-building"></i>
                        Faculty by Department
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="facultyDeptChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- Students by Department -->
            <?php if ($showStudent && !empty($studentByDept)): ?>
            <div class="chart-card" style="--delay: 10;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-building"></i>
                        Students by Department
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="studentDeptChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <!-- ENHANCED INTERACTIVE TREND CHART - only show if we have historical data -->
            <?php if (($showFaculty || $showStudent) && $hasAnyLegacyData): ?>
            <div class="chart-card full-width enhanced" style="--delay: 11;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-line-chart"></i>
                        Research Output Trends
                    </div>
                    <button class="chart-export-btn" onclick="exportTrendChart()">
                        <i class="fa fa-download"></i> Export
                    </button>
                </div>
                
                <!-- Time Range Filters -->
                <div class="time-range-filters">
                    <button class="time-filter-btn" data-range="24hours">
                        <i class="fa fa-clock"></i> Last 24 Hours
                    </button>
                    <button class="time-filter-btn" data-range="7days">
                        <i class="fa fa-calendar-week"></i> Last 7 Days
                    </button>
                    <button class="time-filter-btn active" data-range="30days">
                        <i class="fa fa-calendar-alt"></i> Last 30 Days
                    </button>
                </div>
                
                <!-- Statistics Summary -->
                <div class="trend-statistics">
                    <!-- Statistics will be dynamically populated -->
                </div>
                
                <!-- Loading Indicator -->
                <div class="chart-loading">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Loading data...</div>
                </div>
                
                <!-- Chart Container -->
                <div class="chart-container" style="height: 450px;">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <!-- No Data Message -->
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-chart-bar"></i>
            Analytics & Insights
        </div>
        <div style="background: white; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.08); margin-bottom: 25px;">
            <i class="fa fa-chart-line" style="font-size: 48px; color: #d1d5db; margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0; color: #374151;">No Data to Display</h3>
            <p style="margin: 0; color: #6b7280;">Charts will appear here once you have research submissions and projects.</p>
        </div>
        <?php endif; ?>

        <!-- Recent Researchers -->
        <?php if (!empty($recentResearchers)): ?>
        <div class="section-title" style="margin-top: 35px;">
            <i class="fa fa-clock"></i>
            Recently Added Researchers
        </div>
        <div class="activity-card">
            <div class="activity-list">
                <?php foreach ($recentResearchers as $researcher): ?>
                    <div class="activity-item">
                        <div class="activity-icon <?= $researcher['type'] ?>">
                            <i class="fa fa-<?= $researcher['type'] === 'faculty' ? 'chalkboard-teacher' : 'user-graduate' ?>"></i>
                        </div>
                        <div class="activity-details">
                            <div class="activity-name">
                                <?= htmlspecialchars($researcher['name']) ?>
                            </div>
                            <div class="activity-meta">
                                <i class="fa fa-building"></i>
                                <?= htmlspecialchars($researcher['department']) ?>
                                <span>•</span>
                                <i class="fa fa-clock"></i>
                                <?= date('M d, Y', strtotime($researcher['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php if (!$isSpa): ?>
</div>

<script src="researchScript.js"></script>
<script>
// Fallback initialization for non-SPA mode
if (typeof initializeDashboardCharts === 'function') {
    setTimeout(initializeDashboardCharts, 300);
}
</script>

</body>
</html>
<?php else: ?>
<script src="researchScript.js"></script>
<script>
// Explicit initialization for SPA mode
console.log('Research Dashboard: SPA mode - triggering initialization...');
(function() {
    function tryInit() {
        if (typeof window.initializeDashboardCharts === 'function' && typeof window.dashboardData !== 'undefined') {
            console.log('Research Dashboard: Calling initializeDashboardCharts');
            window.initializeDashboardCharts();
        } else {
            console.log('Research Dashboard: Waiting for scripts to load...', {
                initFunc: typeof window.initializeDashboardCharts,
                dashboardData: typeof window.dashboardData
            });
            setTimeout(tryInit, 100);
        }
    }
    setTimeout(tryInit, 100);
})();
</script>
<?php endif; ?>
