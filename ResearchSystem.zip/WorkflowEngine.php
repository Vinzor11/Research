<?php
/**
 * WorkflowEngine.php
 * Core workflow logic for OOM-Based Research Management System
 * 
 * Flow: Researcher → Coordinator → Research Office Admin
 * 
 * DESIGN PRINCIPLES:
 * - Least privilege by default
 * - No bypassing coordinator level
 * - Clear ownership per workflow stage
 * - System-driven routing (not user-driven)
 * - Strict return pattern: Admin → Coordinator → Researcher (no ping-pong)
 * 
 * @version 1.0
 */

require_once __DIR__ . '/WorkflowAuditLogger.php';

class WorkflowEngine {
    private $conn;
    private $auditLogger;
    private $userId;
    private $userRole;
    private $employeeId;
    private $coordinatorTypes = [];
    
    // Workflow Status Constants
    const STATUS_DRAFT = 'draft';
    const STATUS_SUBMITTED = 'submitted';
    const STATUS_UNDER_COORDINATOR_REVIEW = 'under_coordinator_review';
    const STATUS_RETURNED_FOR_REVISION = 'returned_for_revision';
    const STATUS_ENDORSED = 'endorsed';
    const STATUS_UNDER_RO_REVIEW = 'under_ro_review';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    
    // Handler Types
    const HANDLER_RESEARCHER = 'researcher';
    const HANDLER_COORDINATOR = 'coordinator';
    const HANDLER_RESEARCH_OFFICE = 'research_office';
    
    // Valid Status Transitions Matrix
    private $validTransitions = [
        self::STATUS_DRAFT => [self::STATUS_SUBMITTED],
        self::STATUS_SUBMITTED => [self::STATUS_UNDER_COORDINATOR_REVIEW],
        self::STATUS_UNDER_COORDINATOR_REVIEW => [
            self::STATUS_RETURNED_FOR_REVISION,
            self::STATUS_ENDORSED
        ],
        self::STATUS_RETURNED_FOR_REVISION => [self::STATUS_SUBMITTED],
        self::STATUS_ENDORSED => [self::STATUS_UNDER_RO_REVIEW],
        self::STATUS_UNDER_RO_REVIEW => [
            self::STATUS_APPROVED,
            self::STATUS_REJECTED,
            self::STATUS_ENDORSED  // Return to coordinator
        ],
        self::STATUS_APPROVED => [],  // Final state
        self::STATUS_REJECTED => []   // Final state
    ];
    
    // Status Ownership: Who can edit at each status
    private $statusOwnership = [
        self::STATUS_DRAFT => self::HANDLER_RESEARCHER,
        self::STATUS_SUBMITTED => self::HANDLER_COORDINATOR,
        self::STATUS_UNDER_COORDINATOR_REVIEW => self::HANDLER_COORDINATOR,
        self::STATUS_RETURNED_FOR_REVISION => self::HANDLER_RESEARCHER,
        self::STATUS_ENDORSED => self::HANDLER_RESEARCH_OFFICE,
        self::STATUS_UNDER_RO_REVIEW => self::HANDLER_RESEARCH_OFFICE,
        self::STATUS_APPROVED => self::HANDLER_RESEARCH_OFFICE,
        self::STATUS_REJECTED => self::HANDLER_RESEARCH_OFFICE
    ];
    
    /**
     * Constructor
     */
    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        $this->auditLogger = new WorkflowAuditLogger($dbConnection);
        
        if (!isset($_SESSION)) {
            session_start();
        }
        
        $this->userId = $_SESSION['user_id'] ?? null;
        $this->userRole = $_SESSION['user_role'] ?? null;
        $this->employeeId = $_SESSION['employee_id'] ?? null;
        
        $this->loadUserCoordinatorTypes();
    }
    
    /**
     * Load coordinator types for current user
     */
    private function loadUserCoordinatorTypes() {
        if (!$this->userId || !$this->employeeId || $this->userRole !== 'coordinator') {
            return;
        }
        
        try {
            $stmt = $this->conn->prepare("
                SELECT coordinator_type FROM coordinator_assignments 
                WHERE employee_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci AND status = 'active'
            ");
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $this->coordinatorTypes[] = $row['coordinator_type'];
            }
            $stmt->close();
        } catch (Exception $e) {
            error_log("WorkflowEngine: Failed to load coordinator types: " . $e->getMessage());
        }
    }
    
    // ========================================
    // SUBMISSION PHASE (Researcher)
    // ========================================
    
    /**
     * Submit a draft to coordinator (or Research Office if coordinator is submitting)
     * Status: draft → submitted (to coordinator) OR draft → under_ro_review (escalated)
     * 
     * COORDINATOR SUBMISSION HANDLING:
     * - Option 1 (Preferred): Route to peer coordinator in same unit/category
     * - Option 2 (Fallback): Escalate to Research Office if no peer coordinator available
     * 
     * Core Principle: No user may review, endorse, or approve a submission they personally created.
     */
    public function submit($submissionId) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        // Validate current status
        if ($submission['status'] !== self::STATUS_DRAFT && 
            $submission['status'] !== self::STATUS_RETURNED_FOR_REVISION) {
            return ['success' => false, 'error' => 'Submission cannot be submitted from current status'];
        }
        
        // Validate ownership - only researcher can submit
        if (!$this->isResearcherOwner($submission)) {
            return ['success' => false, 'error' => 'You are not authorized to submit this record'];
        }
        
        // Validate required fields
        $validation = $this->validateForSubmission($submission);
        if (!$validation['valid']) {
            return ['success' => false, 'error' => 'Validation failed', 'errors' => $validation['errors']];
        }
        
        // =====================================================
        // COORDINATOR SUBMISSION DETECTION & ROUTING
        // =====================================================
        $submitterCoordInfo = $this->isCurrentUserCoordinator();
        $isCoordinatorSubmission = ($submitterCoordInfo !== null);
        
        if ($isCoordinatorSubmission) {
            return $this->handleCoordinatorSubmission($submissionId, $submission, $submitterCoordInfo);
        }
        
        // =====================================================
        // STANDARD SUBMISSION FLOW (Non-Coordinator)
        // =====================================================
        return $this->handleStandardSubmission($submissionId, $submission);
    }
    
    /**
     * Handle standard submission (non-coordinator submitter)
     * Routes to assigned coordinator for review
     */
    private function handleStandardSubmission($submissionId, $submission) {
        // Auto-route to coordinator based on researcher type and unit
        $coordinator = $this->findCoordinator($submission);
        if (!$coordinator) {
            return ['success' => false, 'error' => 'No coordinator found for your unit. Please contact the Research Office.'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            $previousStatus = $submission['status'];
            $isRevision = $previousStatus === self::STATUS_RETURNED_FOR_REVISION;
            
            // Update submission
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    current_handler_type = ?,
                    current_handler_id = ?,
                    assigned_coordinator_id = ?,
                    assigned_coordinator_employee_id = ?,
                    submitted_at = IF(submitted_at IS NULL, NOW(), submitted_at),
                    revision_count = IF(? = 1, revision_count + 1, revision_count),
                    last_revision_at = IF(? = 1, NOW(), last_revision_at),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_SUBMITTED;
            $handlerType = self::HANDLER_COORDINATOR;
            $isRevisionInt = $isRevision ? 1 : 0;
            
            $stmt->bind_param(
                "ssissiii",
                $newStatus,
                $handlerType,
                $coordinator['user_id'],
                $coordinator['user_id'],
                $coordinator['employee_id'],
                $isRevisionInt,
                $isRevisionInt,
                $submissionId
            );
            $stmt->execute();
            $stmt->close();
            
            // Log the action
            $actionType = $isRevision ? 'revision_submitted' : 'submitted';
            $this->auditLogger->log($submissionId, $actionType, [
                'previous_status' => $previousStatus,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'researcher',
                'target_user_id' => $coordinator['user_id'],
                'target_role' => 'coordinator',
                'metadata' => [
                    'coordinator_name' => $coordinator['full_name'],
                    'coordinator_unit' => $coordinator['unit_name']
                ]
            ]);
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'message' => 'Submission sent to coordinator for review',
                'coordinator' => $coordinator['full_name']
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::handleStandardSubmission error: " . $e->getMessage());
            return ['success' => false, 'error' => 'Failed to submit: ' . $e->getMessage()];
        }
    }
    
    /**
     * Handle coordinator submission with segregation of duties
     * 
     * Two-Option Routing Model:
     * - Option 1: Route to peer coordinator (preferred)
     * - Option 2: Escalate to Research Office (fallback)
     * 
     * @param int $submissionId
     * @param array $submission
     * @param array $submitterCoordInfo Submitter's coordinator info
     * @return array Result with success/error
     */
    private function handleCoordinatorSubmission($submissionId, $submission, $submitterCoordInfo) {
        $previousStatus = $submission['status'];
        $isRevision = $previousStatus === self::STATUS_RETURNED_FOR_REVISION;
        
        // Find peer coordinators (excluding the submitter)
        $peerCoordinators = $this->findPeerCoordinators($submission, $submitterCoordInfo['employee_id']);
        
        try {
            $this->conn->begin_transaction();
            
            // Prepare routing audit data
            $routingData = [
                'submitter_user_id' => $this->userId,
                'submitter_employee_id' => $this->employeeId,
                'submitter_coordinator_type' => $submitterCoordInfo['coordinator_type'],
                'unit_id' => $submission['researcher_unit_id'],
                'unit_name' => $submission['researcher_unit_name'],
                'researcher_type' => $submission['researcher_type'],
                'excluded_ids' => [$this->employeeId],
                'available_peer_count' => count($peerCoordinators)
            ];
            
            if (!empty($peerCoordinators)) {
                // =====================================================
                // OPTION 1: Route to Peer Coordinator
                // =====================================================
                $peerCoordinator = $peerCoordinators[0]; // Take the first (best matched) peer
                
                $routingData['routing_decision'] = 'peer_coordinator';
                $routingData['assigned_peer_id'] = $peerCoordinator['user_id'];
                $routingData['assigned_peer_employee_id'] = $peerCoordinator['employee_id'];
                $routingData['escalation_reason'] = null;
                
                // Update submission with peer coordinator assignment
                $stmt = $this->conn->prepare("
                    UPDATE research_submissions SET
                        status = ?,
                        current_handler_type = ?,
                        current_handler_id = ?,
                        assigned_coordinator_id = ?,
                        assigned_coordinator_employee_id = ?,
                        submitted_by_coordinator = 1,
                        submitter_coordinator_id = ?,
                        submitter_coordinator_employee_id = ?,
                        coordinator_submission_routing = 'peer_coordinator',
                        excluded_coordinator_ids = ?,
                        submitted_at = IF(submitted_at IS NULL, NOW(), submitted_at),
                        revision_count = IF(? = 1, revision_count + 1, revision_count),
                        last_revision_at = IF(? = 1, NOW(), last_revision_at),
                        updated_at = NOW()
                    WHERE id = ?
                ");
                
                $newStatus = self::STATUS_SUBMITTED;
                $handlerType = self::HANDLER_COORDINATOR;
                $excludedJson = json_encode([$this->employeeId]);
                $isRevisionInt = $isRevision ? 1 : 0;
                
                $stmt->bind_param(
                    "ssississiii",
                    $newStatus,
                    $handlerType,
                    $peerCoordinator['user_id'],
                    $peerCoordinator['user_id'],
                    $peerCoordinator['employee_id'],
                    $this->userId,
                    $this->employeeId,
                    $excludedJson,
                    $isRevisionInt,
                    $isRevisionInt,
                    $submissionId
                );
                $stmt->execute();
                $stmt->close();
                
                // Log routing decision
                $this->logCoordinatorSubmissionRouting($submissionId, $routingData);
                
                // Log to workflow history
                $actionType = $isRevision ? 'revision_submitted' : 'coordinator_self_submit_routed';
                $this->auditLogger->log($submissionId, $actionType, [
                    'previous_status' => $previousStatus,
                    'new_status' => $newStatus,
                    'performed_by' => $this->userId,
                    'performed_by_role' => 'coordinator',
                    'target_user_id' => $peerCoordinator['user_id'],
                    'target_role' => 'coordinator',
                    'metadata' => [
                        'coordinator_submission' => true,
                        'routing_option' => 'peer_coordinator',
                        'peer_coordinator_name' => $peerCoordinator['full_name'],
                        'peer_coordinator_unit' => $peerCoordinator['unit_name'],
                        'submitter_excluded' => true,
                        'available_peers' => count($peerCoordinators)
                    ]
                ]);
                
                $this->conn->commit();
                
                return [
                    'success' => true,
                    'message' => 'Submission routed to peer coordinator for review (self-review prevented)',
                    'coordinator' => $peerCoordinator['full_name'],
                    'routing' => 'peer_coordinator',
                    'coordinator_submission' => true
                ];
                
            } else {
                // =====================================================
                // OPTION 2: Escalate to Research Office
                // =====================================================
                $escalationReason = "No peer coordinator available for {$submission['researcher_type']} category in unit: {$submission['researcher_unit_name']}";
                
                $routingData['routing_decision'] = 'escalated_to_ro';
                $routingData['assigned_peer_id'] = null;
                $routingData['assigned_peer_employee_id'] = null;
                $routingData['escalation_reason'] = $escalationReason;
                
                // Update submission - escalate directly to Research Office
                // This skips coordinator review since submitter IS the only coordinator
                $stmt = $this->conn->prepare("
                    UPDATE research_submissions SET
                        status = ?,
                        current_handler_type = ?,
                        current_handler_id = NULL,
                        assigned_coordinator_id = NULL,
                        assigned_coordinator_employee_id = NULL,
                        submitted_by_coordinator = 1,
                        submitter_coordinator_id = ?,
                        submitter_coordinator_employee_id = ?,
                        coordinator_submission_routing = 'escalated_to_ro',
                        peer_coordinator_unavailable_reason = ?,
                        excluded_coordinator_ids = ?,
                        submitted_at = IF(submitted_at IS NULL, NOW(), submitted_at),
                        ro_received_at = NOW(),
                        revision_count = IF(? = 1, revision_count + 1, revision_count),
                        last_revision_at = IF(? = 1, NOW(), last_revision_at),
                        updated_at = NOW()
                    WHERE id = ?
                ");
                
                // Escalated submissions go directly to RO review status
                $newStatus = self::STATUS_UNDER_RO_REVIEW;
                $handlerType = self::HANDLER_RESEARCH_OFFICE;
                $excludedJson = json_encode([$this->employeeId]);
                $isRevisionInt = $isRevision ? 1 : 0;
                
                $stmt->bind_param(
                    "ssisssiii",
                    $newStatus,
                    $handlerType,
                    $this->userId,
                    $this->employeeId,
                    $escalationReason,
                    $excludedJson,
                    $isRevisionInt,
                    $isRevisionInt,
                    $submissionId
                );
                $stmt->execute();
                $stmt->close();
                
                // Log routing decision
                $this->logCoordinatorSubmissionRouting($submissionId, $routingData);
                
                // Log to workflow history
                $actionType = 'coordinator_self_submit_escalated';
                $this->auditLogger->log($submissionId, $actionType, [
                    'previous_status' => $previousStatus,
                    'new_status' => $newStatus,
                    'performed_by' => $this->userId,
                    'performed_by_role' => 'coordinator',
                    'target_user_id' => null,
                    'target_role' => 'research_office',
                    'metadata' => [
                        'coordinator_submission' => true,
                        'routing_option' => 'escalated_to_ro',
                        'escalation_reason' => $escalationReason,
                        'submitter_excluded' => true,
                        'available_peers' => 0,
                        'note' => 'Coordinator review bypassed - RO will perform endorsement-equivalent validation'
                    ]
                ]);
                
                $this->conn->commit();
                
                return [
                    'success' => true,
                    'message' => 'Submission escalated to Research Office for review (no peer coordinator available)',
                    'routing' => 'escalated_to_ro',
                    'coordinator_submission' => true,
                    'escalation_reason' => $escalationReason
                ];
            }
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::handleCoordinatorSubmission error: " . $e->getMessage());
            return ['success' => false, 'error' => 'Failed to submit: ' . $e->getMessage()];
        }
    }
    
    // ========================================
    // COORDINATOR PHASE (Unit-Level Review)
    // ========================================
    
    /**
     * Start coordinator review
     * Status: submitted → under_coordinator_review
     * 
     * SECURITY: Self-review is prohibited (cannot review own submissions)
     */
    public function startCoordinatorReview($submissionId) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_SUBMITTED) {
            return ['success' => false, 'error' => 'Submission is not in submitted status'];
        }
        
        // CRITICAL: Check for self-review (segregation of duties)
        $endorseCheck = $this->canEndorseSubmission($submission);
        if (!$endorseCheck['can_endorse']) {
            // Log blocked self-review attempt
            if ($endorseCheck['is_self_submission'] ?? false) {
                $this->auditLogger->log($submissionId, 'self_endorsement_blocked', [
                    'attempted_by' => $this->userId,
                    'attempted_by_role' => $this->userRole,
                    'action_attempted' => 'start_review',
                    'reason' => $endorseCheck['reason'],
                    'metadata' => [
                        'security_rule' => 'No user may review a submission they personally created',
                        'blocked_at' => date('Y-m-d H:i:s')
                    ]
                ]);
            }
            return ['success' => false, 'error' => $endorseCheck['reason']];
        }
        
        if (!$this->isAssignedCoordinator($submission)) {
            return ['success' => false, 'error' => 'You are not the assigned coordinator for this submission'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    coordinator_received_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_UNDER_COORDINATOR_REVIEW;
            $stmt->bind_param("si", $newStatus, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($submissionId, 'coordinator_review_started', [
                'previous_status' => self::STATUS_SUBMITTED,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator'
            ]);
            
            return ['success' => true, 'message' => 'Review started'];
            
        } catch (Exception $e) {
            error_log("WorkflowEngine::startCoordinatorReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Coordinator returns submission for revision
     * Status: under_coordinator_review → returned_for_revision
     * MANDATORY: Must include comments/reason
     */
    public function returnForRevision($submissionId, $reason, $comments = null) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        // Can return from coordinator review or when RO returns to coordinator
        $allowedStatuses = [self::STATUS_UNDER_COORDINATOR_REVIEW];
        if (!in_array($submission['status'], $allowedStatuses)) {
            return ['success' => false, 'error' => 'Cannot return submission from current status'];
        }
        
        if (!$this->isAssignedCoordinator($submission)) {
            return ['success' => false, 'error' => 'You are not authorized to return this submission'];
        }
        
        // Reason is mandatory
        if (empty(trim($reason))) {
            return ['success' => false, 'error' => 'Return reason is required'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            $previousStatus = $submission['status'];
            
            // Update submission
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    current_handler_type = ?,
                    current_handler_id = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_RETURNED_FOR_REVISION;
            $handlerType = self::HANDLER_RESEARCHER;
            $researcherUserId = $submission['researcher_user_id'] ?? $submission['created_by'];
            
            $stmt->bind_param("ssii", $newStatus, $handlerType, $researcherUserId, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // Add comment
            $this->addComment($submissionId, 'revision_request', $reason, true, true, true);
            
            // Log action
            $this->auditLogger->log($submissionId, 'returned_for_revision', [
                'previous_status' => $previousStatus,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'target_user_id' => $researcherUserId,
                'target_role' => 'researcher',
                'return_reason' => $reason,
                'comments' => $comments
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Submission returned to researcher for revision'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::returnForRevision error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Coordinator endorses submission to Research Office
     * Status: under_coordinator_review → endorsed
     * 
     * SECURITY: Self-endorsement is strictly prohibited
     */
    public function endorseToResearchOffice($submissionId, $validationData, $notes = null) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_UNDER_COORDINATOR_REVIEW) {
            return ['success' => false, 'error' => 'Submission must be under coordinator review to endorse'];
        }
        
        // CRITICAL: Check for self-endorsement (segregation of duties)
        $endorseCheck = $this->canEndorseSubmission($submission);
        if (!$endorseCheck['can_endorse']) {
            // Log blocked self-endorsement attempt
            if ($endorseCheck['is_self_submission'] ?? false) {
                $this->auditLogger->log($submissionId, 'self_endorsement_blocked', [
                    'attempted_by' => $this->userId,
                    'attempted_by_role' => $this->userRole,
                    'reason' => $endorseCheck['reason'],
                    'metadata' => [
                        'security_rule' => 'No user may endorse a submission they personally created',
                        'blocked_at' => date('Y-m-d H:i:s')
                    ]
                ]);
            }
            return ['success' => false, 'error' => $endorseCheck['reason']];
        }
        
        if (!$this->isAssignedCoordinator($submission)) {
            return ['success' => false, 'error' => 'You are not authorized to endorse this submission'];
        }
        
        // Validate checklist if required
        $settings = $this->getWorkflowSettings();
        if ($settings['require_endorsement_checklist'] ?? true) {
            if (empty($validationData['completeness_verified']) || 
                empty($validationData['unit_verified']) || 
                empty($validationData['category_verified']) ||
                empty($validationData['attachments_verified'])) {
                return ['success' => false, 'error' => 'Please complete all validation checks before endorsing'];
            }
        }
        
        try {
            $this->conn->begin_transaction();
            
            // Update submission status
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    current_handler_type = ?,
                    current_handler_id = NULL,
                    coordinator_endorsed_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_ENDORSED;
            $handlerType = self::HANDLER_RESEARCH_OFFICE;
            $stmt->bind_param("ssi", $newStatus, $handlerType, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // Save endorsement summary
            $stmt = $this->conn->prepare("
                INSERT INTO coordinator_endorsement_summary 
                (submission_id, coordinator_id, coordinator_employee_id, 
                 completeness_verified, unit_verified, category_verified, attachments_verified,
                 endorsement_notes, endorsed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE
                    completeness_verified = VALUES(completeness_verified),
                    unit_verified = VALUES(unit_verified),
                    category_verified = VALUES(category_verified),
                    attachments_verified = VALUES(attachments_verified),
                    endorsement_notes = VALUES(endorsement_notes),
                    endorsed_at = NOW()
            ");
            
            $stmt->bind_param(
                "iisiiiis",
                $submissionId,
                $this->userId,
                $this->employeeId,
                $validationData['completeness_verified'],
                $validationData['unit_verified'],
                $validationData['category_verified'],
                $validationData['attachments_verified'],
                $notes
            );
            $stmt->execute();
            $stmt->close();
            
            // Add comment if notes provided
            if (!empty($notes)) {
                $this->addComment($submissionId, 'endorsement_note', $notes, true, true, true);
            }
            
            // Log action
            $this->auditLogger->log($submissionId, 'endorsed', [
                'previous_status' => self::STATUS_UNDER_COORDINATOR_REVIEW,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'coordinator',
                'metadata' => $validationData
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Submission endorsed to Research Office'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::endorseToResearchOffice error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // RESEARCH OFFICE PHASE (Final Decision)
    // ========================================
    
    /**
     * Research Office admin claims/starts review
     * Status: endorsed → under_ro_review
     */
    public function startROReview($submissionId) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_ENDORSED) {
            return ['success' => false, 'error' => 'Submission is not in endorsed status'];
        }
        
        if (!$this->isResearchOfficeAdmin()) {
            return ['success' => false, 'error' => 'Only Research Office administrators can review endorsed submissions'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    current_handler_id = ?,
                    assigned_ro_admin_id = ?,
                    ro_received_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_UNDER_RO_REVIEW;
            $stmt->bind_param("siii", $newStatus, $this->userId, $this->userId, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($submissionId, 'ro_review_started', [
                'previous_status' => self::STATUS_ENDORSED,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office'
            ]);
            
            return ['success' => true, 'message' => 'Review started'];
            
        } catch (Exception $e) {
            error_log("WorkflowEngine::startROReview error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Assign classification and metadata
     */
    public function assignClassification($submissionId, $data) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if (!$this->isResearchOfficeAdmin()) {
            return ['success' => false, 'error' => 'Only Research Office can assign classifications'];
        }
        
        try {
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    research_program = ?,
                    funding_source = ?,
                    fiscal_year = ?,
                    tags = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $tags = !empty($data['tags']) ? json_encode($data['tags']) : null;
            
            $stmt->bind_param(
                "ssssi",
                $data['research_program'],
                $data['funding_source'],
                $data['fiscal_year'],
                $tags,
                $submissionId
            );
            $stmt->execute();
            $stmt->close();
            
            $this->auditLogger->log($submissionId, 'classification_assigned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => $data
            ]);
            
            return ['success' => true, 'message' => 'Classification updated'];
            
        } catch (Exception $e) {
            error_log("WorkflowEngine::assignClassification error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Approve submission and AUTOMATICALLY elevate to On-Going Research Project
     * 
     * STATUS: under_ro_review → approved
     * PROJECT_STATUS: NULL → on_going
     * RMIS MAPPING: → Form D1 (On-Going Research Project)
     * 
     * MANDATORY POST-APPROVAL ACTIONS (per ESSU-RDSO-115 RMIS Forms):
     * 1. Generate Reference Number (immutable)
     * 2. Generate Project Code (immutable)
     * 3. Lock proposal fields (title, objectives, timeline, budget)
     * 4. Set project_status to 'on_going'
     * 5. Map to RMIS Form D1
     * 
     * IMPORTANT: Approval does NOT indicate completion.
     * Approval transitions the proposal into an official, on-going research project.
     */
    public function approve($submissionId, $notes = null) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_UNDER_RO_REVIEW) {
            return ['success' => false, 'error' => 'Submission must be under RO review to approve'];
        }
        
        if (!$this->isResearchOfficeAdmin(true)) { // true = require approval permission
            return ['success' => false, 'error' => 'You do not have permission to approve submissions'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            // ============================================================
            // 1. Generate Official Identifiers (IMMUTABLE)
            // ============================================================
            $referenceNumber = $this->generateReferenceNumber();
            $projectCode = $this->generateProjectCode($submission);
            
            // ============================================================
            // 2. Approve AND Elevate to On-Going Research Project
            // ============================================================
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    -- Workflow Status
                    status = ?,
                    reference_number = ?,
                    decision_at = NOW(),
                    
                    -- PROJECT ELEVATION (Automatic on Approval)
                    project_code = ?,
                    project_status = 'on_going',
                    elevated_to_project_at = NOW(),
                    
                    -- FIELD LOCKING (Mandatory after approval)
                    is_proposal_locked = 1,
                    
                    -- RMIS MAPPING (Form D1 = On-Going Research Project)
                    rmis_form_mapping = 'D1',
                    
                    -- Set current end date (can be extended later)
                    current_end_date = COALESCE(proposed_end_date, DATE_ADD(NOW(), INTERVAL 1 YEAR)),
                    
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_APPROVED;
            $stmt->bind_param("sssi", $newStatus, $referenceNumber, $projectCode, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // ============================================================
            // 3. Add Approval Notes (if provided)
            // ============================================================
            if (!empty($notes)) {
                $this->addComment($submissionId, 'approval_note', $notes, true, true, true);
            }
            
            // ============================================================
            // 4. AUDIT LOGGING (Immutable Trail)
            // ============================================================
            
            // Log approval action
            $this->auditLogger->log($submissionId, 'approved', [
                'previous_status' => self::STATUS_UNDER_RO_REVIEW,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'reference_number' => $referenceNumber,
                    'project_code' => $projectCode
                ]
            ]);
            
            // Log reference assignment
            $this->auditLogger->log($submissionId, 'reference_assigned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['reference_number' => $referenceNumber]
            ]);
            
            // Log project code assignment
            $this->auditLogger->log($submissionId, 'project_code_assigned', [
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => ['project_code' => $projectCode]
            ]);
            
            // Log elevation to on-going project (KEY AUDIT EVENT)
            $this->auditLogger->log($submissionId, 'elevated_to_project', [
                'previous_status' => 'proposal',
                'new_status' => 'on_going',
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'reference_number' => $referenceNumber,
                    'project_code' => $projectCode,
                    'rmis_form' => 'D1',
                    'fields_locked' => ['title', 'objectives', 'proposed_start_date', 'proposed_end_date', 'total_budget']
                ]
            ]);
            
            // ============================================================
            // 5. Log to Project Lifecycle Table
            // ============================================================
            $this->logProjectLifecycle($submissionId, null, 'on_going', null, 'D1', 
                'approved', 'approval', null);
            
            $this->conn->commit();
            
            return [
                'success' => true, 
                'message' => 'Proposal approved and elevated to On-Going Research Project',
                'reference_number' => $referenceNumber,
                'project_code' => $projectCode,
                'project_status' => 'on_going',
                'rmis_form' => 'D1'
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::approve error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Generate unique project code
     * Format: PRJ-{TYPE_PREFIX}-{YEAR}-{SEQ:4}
     * Example: PRJ-FAC-2026-0001
     */
    private function generateProjectCode($submission) {
        $year = date('Y');
        $typePrefix = 'RES'; // Default
        
        // Map researcher type to prefix
        switch ($submission['researcher_type'] ?? '') {
            case 'faculty':
                $typePrefix = 'FAC';
                break;
            case 'student':
                $typePrefix = 'STU';
                break;
            case 'personnel':
                $typePrefix = 'PER';
                break;
        }
        
        // Get next sequence number
        $pattern = "PRJ-$typePrefix-$year-%";
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) + 1 as next_seq 
            FROM research_submissions 
            WHERE project_code LIKE ?
        ");
        $stmt->bind_param("s", $pattern);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $seq = $result['next_seq'];
        $stmt->close();
        
        return "PRJ-$typePrefix-$year-" . str_pad($seq, 4, '0', STR_PAD_LEFT);
    }
    
    /**
     * Log project lifecycle state change
     */
    private function logProjectLifecycle($projectId, $prevStatus, $newStatus, $prevForm, $newForm, $trigger, $sourceType, $sourceId, $notes = null) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO project_lifecycle_log 
                (project_id, previous_project_status, new_project_status, previous_rmis_form, new_rmis_form,
                 trigger_action, trigger_source_type, trigger_source_id, performed_by, performed_by_role, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                "issssssisis",
                $projectId, $prevStatus, $newStatus, $prevForm, $newForm,
                $trigger, $sourceType, $sourceId, $this->userId, $this->userRole, $notes
            );
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            error_log("WorkflowEngine::logProjectLifecycle error: " . $e->getMessage());
        }
    }
    
    /**
     * Reject submission
     * Status: under_ro_review → rejected
     * MANDATORY: Must include rejection reason
     */
    public function reject($submissionId, $reason) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_UNDER_RO_REVIEW) {
            return ['success' => false, 'error' => 'Submission must be under RO review to reject'];
        }
        
        if (!$this->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'You do not have permission to reject submissions'];
        }
        
        if (empty(trim($reason))) {
            return ['success' => false, 'error' => 'Rejection reason is required'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    decision_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $newStatus = self::STATUS_REJECTED;
            $stmt->bind_param("si", $newStatus, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // Add rejection reason as comment
            $this->addComment($submissionId, 'rejection_reason', $reason, true, true, true);
            
            // Log action
            $this->auditLogger->log($submissionId, 'rejected', [
                'previous_status' => self::STATUS_UNDER_RO_REVIEW,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'return_reason' => $reason
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Submission rejected'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::reject error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Research Office returns to Coordinator (Pattern A - Mandatory)
     * Status: under_ro_review → endorsed (back to coordinator)
     * 
     * STRICT RULE: Admin can ONLY return to Coordinator, NOT directly to Researcher
     */
    public function returnToCoordinator($submissionId, $reason, $instructions = null) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Submission not found'];
        }
        
        if ($submission['status'] !== self::STATUS_UNDER_RO_REVIEW) {
            return ['success' => false, 'error' => 'Submission must be under RO review to return'];
        }
        
        if (!$this->isResearchOfficeAdmin()) {
            return ['success' => false, 'error' => 'Only Research Office can return submissions'];
        }
        
        if (empty(trim($reason))) {
            return ['success' => false, 'error' => 'Return reason is required'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            // Return to the coordinator who endorsed it
            $coordinatorId = $submission['assigned_coordinator_id'];
            
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    status = ?,
                    current_handler_type = ?,
                    current_handler_id = ?,
                    assigned_ro_admin_id = NULL,
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            // Go back to under_coordinator_review so coordinator can act
            $newStatus = self::STATUS_UNDER_COORDINATOR_REVIEW;
            $handlerType = self::HANDLER_COORDINATOR;
            
            $stmt->bind_param("ssii", $newStatus, $handlerType, $coordinatorId, $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // Add comment with instructions
            $commentText = "Returned by Research Office: " . $reason;
            if (!empty($instructions)) {
                $commentText .= "\n\nInstructions: " . $instructions;
            }
            $this->addComment($submissionId, 'revision_request', $commentText, true, true, true);
            
            // Log action
            $this->auditLogger->log($submissionId, 'returned_to_coordinator', [
                'previous_status' => self::STATUS_UNDER_RO_REVIEW,
                'new_status' => $newStatus,
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'target_user_id' => $coordinatorId,
                'target_role' => 'coordinator',
                'return_reason' => $reason,
                'comments' => $instructions
            ]);
            
            $this->conn->commit();
            
            return ['success' => true, 'message' => 'Submission returned to coordinator for review'];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::returnToCoordinator error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    // ========================================
    // ROUTING LOGIC
    // ========================================
    
    /**
     * Check if the current user is a coordinator (for submission routing purposes)
     * @return array|null Coordinator info if user is a coordinator, null otherwise
     */
    public function isCurrentUserCoordinator() {
        if ($this->userRole !== 'coordinator' || empty($this->employeeId)) {
            return null;
        }
        
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    ca.employee_id,
                    ca.coordinator_type,
                    ca.hr_unit_id,
                    ca.hr_unit_name,
                    ca.scope_mode,
                    u.id as user_id,
                    u.fullname as full_name
                FROM coordinator_assignments ca
                JOIN users u ON u.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci
                WHERE ca.employee_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci
                AND ca.status = 'active'
                LIMIT 1
            ");
            $stmt->bind_param("s", $this->employeeId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            return $result ?: null;
        } catch (Exception $e) {
            error_log("WorkflowEngine::isCurrentUserCoordinator error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Find peer coordinators (excluding specified coordinator) for the same unit/category
     * Used for routing coordinator-submitted proposals to another coordinator
     * 
     * @param array $submission The submission data
     * @param string $excludeEmployeeId Employee ID to exclude (the submitting coordinator)
     * @return array List of available peer coordinators
     */
    public function findPeerCoordinators($submission, $excludeEmployeeId) {
        $researcherType = $submission['researcher_type'];
        $unitId = $submission['researcher_unit_id'] ?? '';
        $unitName = $submission['researcher_unit_name'] ?? '';
        $coordinatorType = $researcherType; // faculty, student, personnel
        
        $sql = "
            SELECT 
                ca.employee_id,
                u.id as user_id,
                u.fullname as full_name,
                ca.hr_unit_name as unit_name,
                ca.coordinator_type,
                ca.scope_mode
            FROM coordinator_assignments ca
            JOIN users u ON u.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci
            WHERE ca.coordinator_type COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci
            AND ca.status = 'active'
            AND ca.employee_id COLLATE utf8mb4_general_ci != ? COLLATE utf8mb4_general_ci
            AND (
                (ca.scope_mode = 'all_units') OR
                (ca.scope_mode = 'own_unit' AND (
                    ca.hr_unit_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                    ca.hr_unit_name COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                    ca.hr_unit_name COLLATE utf8mb4_general_ci LIKE CONCAT('%', ? COLLATE utf8mb4_general_ci, '%')
                )) OR
                (ca.scope_mode = 'specific_units' AND EXISTS (
                    SELECT 1 FROM coordinator_scopes cs 
                    WHERE cs.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci 
                    AND (
                        cs.unit_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                        cs.unit_name COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                        cs.unit_name COLLATE utf8mb4_general_ci LIKE CONCAT('%', ? COLLATE utf8mb4_general_ci, '%')
                    )
                ))
            )
            ORDER BY 
                CASE ca.scope_mode
                    WHEN 'own_unit' THEN 1
                    WHEN 'specific_units' THEN 2
                    WHEN 'all_units' THEN 3
                END
        ";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssssss", $coordinatorType, $excludeEmployeeId, $unitId, $unitName, $unitName, $unitId, $unitName, $unitName);
        $stmt->execute();
        $result = $stmt->get_result();
        $coordinators = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        return $coordinators;
    }
    
    /**
     * Log coordinator submission routing decision to audit table
     * 
     * @param int $submissionId
     * @param array $routingData Routing decision details
     */
    private function logCoordinatorSubmissionRouting($submissionId, $routingData) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO coordinator_submission_routing_log (
                    submission_id,
                    submitter_user_id,
                    submitter_employee_id,
                    submitter_coordinator_type,
                    routing_decision,
                    assigned_peer_coordinator_id,
                    assigned_peer_coordinator_employee_id,
                    excluded_coordinator_ids,
                    escalation_reason,
                    available_peer_count,
                    submission_unit_id,
                    submission_unit_name,
                    researcher_type
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $excludedJson = json_encode($routingData['excluded_ids'] ?? [$this->employeeId]);
            
            $stmt->bind_param(
                "iisssisississs",
                $submissionId,
                $routingData['submitter_user_id'],
                $routingData['submitter_employee_id'],
                $routingData['submitter_coordinator_type'],
                $routingData['routing_decision'],
                $routingData['assigned_peer_id'],
                $routingData['assigned_peer_employee_id'],
                $excludedJson,
                $routingData['escalation_reason'],
                $routingData['available_peer_count'],
                $routingData['unit_id'],
                $routingData['unit_name'],
                $routingData['researcher_type']
            );
            $stmt->execute();
            $stmt->close();
            
            error_log("WorkflowEngine: Logged coordinator submission routing for submission $submissionId - Decision: {$routingData['routing_decision']}");
            
        } catch (Exception $e) {
            // Log error but don't fail the submission - audit is important but not blocking
            error_log("WorkflowEngine::logCoordinatorSubmissionRouting error: " . $e->getMessage());
        }
    }
    
    /**
     * Check if user can endorse a specific submission
     * SECURITY: Prevents self-endorsement
     * 
     * @param array $submission The submission record
     * @return array ['can_endorse' => bool, 'reason' => string]
     */
    public function canEndorseSubmission($submission) {
        // Must be coordinator or admin
        if ($this->userRole !== 'coordinator' && $this->userRole !== 'admin') {
            return ['can_endorse' => false, 'reason' => 'Only coordinators can endorse submissions'];
        }
        
        // CRITICAL: Check for self-endorsement
        if ($submission['submitted_by_coordinator'] == 1) {
            // Check if current user is the submitting coordinator
            if ($submission['submitter_coordinator_id'] == $this->userId) {
                return [
                    'can_endorse' => false, 
                    'reason' => 'Self-endorsement is not allowed. This submission was created by you.',
                    'is_self_submission' => true
                ];
            }
            
            // Also check by employee ID for extra security
            if (!empty($submission['submitter_coordinator_employee_id']) && 
                !empty($this->employeeId) && 
                $submission['submitter_coordinator_employee_id'] === $this->employeeId) {
                return [
                    'can_endorse' => false, 
                    'reason' => 'Self-endorsement is not allowed. This submission was created by you.',
                    'is_self_submission' => true
                ];
            }
        }
        
        // Check created_by as additional safeguard (even for non-coordinator submissions)
        if ($submission['created_by'] == $this->userId) {
            return [
                'can_endorse' => false, 
                'reason' => 'You cannot endorse a submission you created.',
                'is_self_submission' => true
            ];
        }
        
        // Check if this submission was escalated to RO (no coordinator endorsement needed)
        if ($submission['coordinator_submission_routing'] === 'escalated_to_ro') {
            return [
                'can_endorse' => false,
                'reason' => 'This submission was escalated directly to Research Office for review.',
                'is_escalated' => true
            ];
        }
        
        // Standard coordinator assignment check
        if (!$this->isAssignedCoordinator($submission)) {
            return ['can_endorse' => false, 'reason' => 'You are not assigned to review this submission'];
        }
        
        return ['can_endorse' => true, 'reason' => ''];
    }
    
    /**
     * Find the appropriate coordinator for a submission
     * Based on: researcher category (faculty/student/personnel) + unit
     */
    public function findCoordinator($submission) {
        $researcherType = $submission['researcher_type'];
        $unitId = $submission['researcher_unit_id'] ?? '';
        $unitName = $submission['researcher_unit_name'] ?? '';
        
        // Map researcher type to coordinator type
        $coordinatorType = $researcherType; // faculty, student, personnel
        
        // Using COLLATE to handle potential collation mismatches between tables
        // Try to find a coordinator with matching type and unit scope
        // Match by: unit ID, unit name, or coordinator scopes - also check 'all_units' scope
        $sql = "
            SELECT 
                ca.employee_id,
                u.id as user_id,
                u.fullname as full_name,
                ca.hr_unit_name as unit_name,
                ca.coordinator_type,
                ca.scope_mode
            FROM coordinator_assignments ca
            JOIN users u ON u.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci
            WHERE ca.coordinator_type COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci
            AND ca.status = 'active'
            AND (
                (ca.scope_mode = 'all_units') OR
                (ca.scope_mode = 'own_unit' AND (
                    ca.hr_unit_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                    ca.hr_unit_name COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                    ca.hr_unit_name COLLATE utf8mb4_general_ci LIKE CONCAT('%', ? COLLATE utf8mb4_general_ci, '%')
                )) OR
                (ca.scope_mode = 'specific_units' AND EXISTS (
                    SELECT 1 FROM coordinator_scopes cs 
                    WHERE cs.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci 
                    AND (
                        cs.unit_id COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                        cs.unit_name COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci OR
                        cs.unit_name COLLATE utf8mb4_general_ci LIKE CONCAT('%', ? COLLATE utf8mb4_general_ci, '%')
                    )
                ))
            )
            ORDER BY 
                CASE ca.scope_mode
                    WHEN 'own_unit' THEN 1
                    WHEN 'specific_units' THEN 2
                    WHEN 'all_units' THEN 3
                END
            LIMIT 1
        ";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssss", $coordinatorType, $unitId, $unitName, $unitName, $unitId, $unitName, $unitName);
        $stmt->execute();
        $result = $stmt->get_result();
        $coordinator = $result->fetch_assoc();
        $stmt->close();
        
        // If no match found by unit, try to find ANY active coordinator of this type
        // This is a fallback to ensure submissions aren't stuck
        if (!$coordinator) {
            $fallbackSql = "
                SELECT 
                    ca.employee_id,
                    u.id as user_id,
                    u.fullname as full_name,
                    ca.hr_unit_name as unit_name,
                    ca.coordinator_type,
                    ca.scope_mode
                FROM coordinator_assignments ca
                JOIN users u ON u.employee_id COLLATE utf8mb4_general_ci = ca.employee_id COLLATE utf8mb4_general_ci
                WHERE ca.coordinator_type COLLATE utf8mb4_general_ci = ? COLLATE utf8mb4_general_ci
                AND ca.status = 'active'
                ORDER BY 
                    CASE ca.scope_mode
                        WHEN 'all_units' THEN 1
                        ELSE 2
                    END
                LIMIT 1
            ";
            
            $stmt = $this->conn->prepare($fallbackSql);
            $stmt->bind_param("s", $coordinatorType);
            $stmt->execute();
            $result = $stmt->get_result();
            $coordinator = $result->fetch_assoc();
            $stmt->close();
        }
        
        return $coordinator ?: null;
    }
    
    // ========================================
    // HELPER METHODS
    // ========================================
    
    /**
     * Get submission by ID
     */
    public function getSubmission($submissionId) {
        $stmt = $this->conn->prepare("
            SELECT rs.*, rst.type_code, rst.type_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            WHERE rs.id = ?
        ");
        $stmt->bind_param("i", $submissionId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }
    
    /**
     * Check if current user is the researcher owner
     */
    private function isResearcherOwner($submission) {
        // User created it
        if ($submission['created_by'] == $this->userId) {
            return true;
        }
        
        // User is linked to the researcher record
        if ($submission['researcher_user_id'] == $this->userId) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Check if current user is the assigned coordinator
     */
    public function isAssignedCoordinator($submission) {
        if ($this->userRole === 'admin') {
            return true; // Admins can act as coordinators
        }
        
        if ($this->userRole !== 'coordinator') {
            return false;
        }
        
        // Check if directly assigned coordinator
        if ($submission['assigned_coordinator_id'] == $this->userId) {
            return true;
        }
        
        // Check by employee ID
        if (!empty($submission['assigned_coordinator_employee_id']) && 
            !empty($this->employeeId) &&
            $submission['assigned_coordinator_employee_id'] === $this->employeeId) {
            return true;
        }
        
        // Check if coordinator's type matches the researcher type
        // This allows coordinators to handle submissions of their assigned type
        if (!empty($this->employeeId) && !empty($submission['researcher_type'])) {
            $stmt = $this->conn->prepare("
                SELECT 1 FROM coordinator_assignments 
                WHERE employee_id COLLATE utf8mb4_general_ci = ? 
                AND coordinator_type COLLATE utf8mb4_general_ci = ? 
                AND status = 'active'
                LIMIT 1
            ");
            $stmt->bind_param("ss", $this->employeeId, $submission['researcher_type']);
            $stmt->execute();
            $result = $stmt->get_result();
            $isMatch = $result->num_rows > 0;
            $stmt->close();
            
            if ($isMatch) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if current user is Research Office admin
     */
    public function isResearchOfficeAdmin($requireApproval = false) {
        if ($this->userRole === 'admin') {
            return true; // System admin has full access
        }
        
        // Check research_office_admins table
        $sql = "SELECT * FROM research_office_admins WHERE user_id = ? AND status = 'active'";
        if ($requireApproval) {
            $sql .= " AND can_approve = 1";
        }
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return !empty($result);
    }
    
    /**
     * Validate submission has required fields before submitting
     */
    private function validateForSubmission($submission) {
        $errors = [];
        
        if (empty($submission['title'])) {
            $errors[] = 'Title is required';
        }
        
        // Check for required attachments based on type
        // TODO: Add attachment validation
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Add a comment to a submission
     */
    public function addComment($submissionId, $type, $text, $visibleResearcher = true, $visibleCoordinator = true, $visibleRO = true) {
        $stmt = $this->conn->prepare("
            INSERT INTO submission_comments 
            (submission_id, comment_type, comment_text, created_by, created_by_role, created_by_name,
             visible_to_researcher, visible_to_coordinator, visible_to_ro)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $userName = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'Unknown';
        $userRole = $this->userRole;
        
        $stmt->bind_param(
            "isssssiis",
            $submissionId,
            $type,
            $text,
            $this->userId,
            $userRole,
            $userName,
            $visibleResearcher,
            $visibleCoordinator,
            $visibleRO
        );
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * Generate reference number for approved submissions
     */
    private function generateReferenceNumber() {
        $settings = $this->getWorkflowSettings();
        $format = $settings['reference_number_format'] ?? 'RMS-{YEAR}-{SEQ:5}';
        
        $year = date('Y');
        
        // Get next sequence number for this year
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) + 1 as next_seq 
            FROM research_submissions 
            WHERE reference_number LIKE ? 
            AND YEAR(decision_at) = ?
        ");
        $pattern = "RMS-$year%";
        $stmt->bind_param("si", $pattern, $year);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $seq = $result['next_seq'];
        $stmt->close();
        
        // Generate reference number
        $refNum = str_replace('{YEAR}', $year, $format);
        $refNum = preg_replace_callback('/\{SEQ:(\d+)\}/', function($matches) use ($seq) {
            return str_pad($seq, (int)$matches[1], '0', STR_PAD_LEFT);
        }, $refNum);
        
        return $refNum;
    }
    
    /**
     * Get workflow settings
     */
    public function getWorkflowSettings() {
        $settings = [];
        $result = $this->conn->query("SELECT setting_key, setting_value, setting_type FROM workflow_settings");
        while ($row = $result->fetch_assoc()) {
            $value = $row['setting_value'];
            switch ($row['setting_type']) {
                case 'boolean':
                    $value = ($value === '1' || $value === 'true');
                    break;
                case 'integer':
                    $value = (int)$value;
                    break;
                case 'json':
                    $value = json_decode($value, true);
                    break;
            }
            $settings[$row['setting_key']] = $value;
        }
        return $settings;
    }
    
    /**
     * Get status label for display
     */
    public static function getStatusLabel($status) {
        $labels = [
            self::STATUS_DRAFT => 'Draft',
            self::STATUS_SUBMITTED => 'Submitted to Coordinator',
            self::STATUS_UNDER_COORDINATOR_REVIEW => 'Under Coordinator Review',
            self::STATUS_RETURNED_FOR_REVISION => 'Returned for Revision',
            self::STATUS_ENDORSED => 'Endorsed to Research Office',
            self::STATUS_UNDER_RO_REVIEW => 'Under Research Office Review',
            self::STATUS_APPROVED => 'Approved',
            self::STATUS_REJECTED => 'Rejected'
        ];
        return $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));
    }
    
    /**
     * Get status CSS class for styling
     */
    public static function getStatusClass($status) {
        $classes = [
            self::STATUS_DRAFT => 'status-draft',
            self::STATUS_SUBMITTED => 'status-submitted',
            self::STATUS_UNDER_COORDINATOR_REVIEW => 'status-review',
            self::STATUS_RETURNED_FOR_REVISION => 'status-revision',
            self::STATUS_ENDORSED => 'status-endorsed',
            self::STATUS_UNDER_RO_REVIEW => 'status-review',
            self::STATUS_APPROVED => 'status-approved',
            self::STATUS_REJECTED => 'status-rejected'
        ];
        return $classes[$status] ?? 'status-default';
    }
    
    /**
     * Check if current user can edit submission based on status ownership
     */
    public function canEdit($submission) {
        $requiredHandler = $this->statusOwnership[$submission['status']] ?? null;
        
        switch ($requiredHandler) {
            case self::HANDLER_RESEARCHER:
                return $this->isResearcherOwner($submission);
                
            case self::HANDLER_COORDINATOR:
                return $this->isAssignedCoordinator($submission);
                
            case self::HANDLER_RESEARCH_OFFICE:
                return $this->isResearchOfficeAdmin();
                
            default:
                return false;
        }
    }
    
    /**
     * Get allowed actions for current user on a submission
     */
    public function getAllowedActions($submission) {
        $actions = [];
        $status = $submission['status'];
        $projectStatus = $submission['project_status'] ?? null;
        
        // Researcher actions
        if ($this->isResearcherOwner($submission)) {
            if ($status === self::STATUS_DRAFT || $status === self::STATUS_RETURNED_FOR_REVISION) {
                $actions[] = 'edit';
                $actions[] = 'submit';
            }
            $actions[] = 'view';
            
            // POST-APPROVAL RESEARCHER ACTIONS
            if ($status === self::STATUS_APPROVED && $projectStatus === 'on_going') {
                $actions[] = 'submit_progress_report';
                $actions[] = 'request_extension';
                $actions[] = 'report_output';
                $actions[] = 'submit_completion';
            }
        }
        
        // Coordinator actions
        if ($this->isAssignedCoordinator($submission)) {
            $actions[] = 'view';
            if ($status === self::STATUS_SUBMITTED) {
                $actions[] = 'start_review';
            }
            if ($status === self::STATUS_UNDER_COORDINATOR_REVIEW) {
                $actions[] = 'validate';
                $actions[] = 'return';
                $actions[] = 'endorse';
            }
            
            // POST-APPROVAL COORDINATOR ACTIONS
            if ($status === self::STATUS_APPROVED) {
                $actions[] = 'review_progress_reports';
                $actions[] = 'review_extensions';
                $actions[] = 'review_completion';
            }
        }
        
        // Research Office actions
        if ($this->isResearchOfficeAdmin()) {
            $actions[] = 'view';
            if ($status === self::STATUS_ENDORSED) {
                $actions[] = 'start_review';
            }
            if ($status === self::STATUS_UNDER_RO_REVIEW) {
                $actions[] = 'classify';
                $actions[] = 'approve';
                $actions[] = 'reject';
                $actions[] = 'return_to_coordinator';
            }
            
            // POST-APPROVAL RO ACTIONS
            if ($status === self::STATUS_APPROVED) {
                $actions[] = 'monitor_project';
                $actions[] = 'approve_extensions';
                $actions[] = 'approve_completion';
                $actions[] = 'verify_outputs';
                $actions[] = 'generate_rmis_reports';
            }
        }
        
        return array_unique($actions);
    }
    
    // ========================================
    // POST-APPROVAL PROJECT LIFECYCLE METHODS
    // ========================================
    
    /**
     * Project Status Constants
     */
    const PROJECT_STATUS_NOT_STARTED = 'not_started';
    const PROJECT_STATUS_ON_GOING = 'on_going';
    const PROJECT_STATUS_EXTENDED = 'extended';
    const PROJECT_STATUS_COMPLETED = 'completed';
    const PROJECT_STATUS_TERMINATED = 'terminated';
    
    /**
     * RMIS Form Mapping Constants
     */
    const RMIS_FORM_D1 = 'D1';  // On-Going Research Project/Study
    const RMIS_FORM_D = 'D';     // Completed Research Project/Study
    
    /**
     * Get list of locked fields after approval
     * These fields require formal amendment request to change
     */
    public static function getLockedFields() {
        return [
            'title' => 'Research Title',
            'objectives' => 'Declared Objectives',
            'proposed_start_date' => 'Approved Start Date',
            'proposed_end_date' => 'Approved End Date',
            'total_budget' => 'Approved Budget'
        ];
    }
    
    /**
     * Check if a specific field is locked for a submission
     */
    public function isFieldLocked($submission, $fieldName) {
        // If not approved or not locked, field is editable
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return false;
        }
        
        if (empty($submission['is_proposal_locked'])) {
            return false;
        }
        
        // Check if this field is in the locked list
        $lockedFields = self::getLockedFields();
        return isset($lockedFields[$fieldName]);
    }
    
    /**
     * Check if user can submit progress report
     */
    /**
     * Check if user can submit progress report
     * RULE: Always enabled while project is on-going (primary action)
     */
    public function canSubmitProgressReport($submission) {
        $check = $this->checkProgressReportEligibility($submission);
        return $check['allowed'];
    }
    
    /**
     * Check progress report eligibility with detailed reason
     * Returns ['allowed' => bool, 'reason' => string]
     */
    public function checkProgressReportEligibility($submission) {
        if (!$this->isResearcherOwner($submission)) {
            return ['allowed' => false, 'reason' => 'Only the project owner can submit progress reports'];
        }
        
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return ['allowed' => false, 'reason' => 'Project must be approved first'];
        }
        
        $projectStatus = $submission['project_status'] ?? null;
        if (!in_array($projectStatus, [self::PROJECT_STATUS_ON_GOING, self::PROJECT_STATUS_EXTENDED])) {
            return ['allowed' => false, 'reason' => 'Project must be on-going to submit progress reports'];
        }
        
        return ['allowed' => true, 'reason' => null];
    }
    
    /**
     * Check if user can request extension
     * RULE: Only available when project is nearing end date, overdue, or explicitly allowed
     */
    public function canRequestExtension($submission) {
        $check = $this->checkExtensionEligibility($submission);
        return $check['allowed'];
    }
    
    /**
     * Check extension eligibility with detailed reason
     * Returns ['allowed' => bool, 'reason' => string, 'urgency' => string]
     */
    public function checkExtensionEligibility($submission) {
        if (!$this->isResearcherOwner($submission)) {
            return ['allowed' => false, 'reason' => 'Only the project owner can request extensions', 'urgency' => null];
        }
        
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return ['allowed' => false, 'reason' => 'Project must be approved first', 'urgency' => null];
        }
        
        $projectStatus = $submission['project_status'] ?? null;
        if (!in_array($projectStatus, [self::PROJECT_STATUS_ON_GOING, self::PROJECT_STATUS_EXTENDED])) {
            return ['allowed' => false, 'reason' => 'Project must be on-going to request extension', 'urgency' => null];
        }
        
        // Check if there's a pending extension request
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as pending FROM project_extensions 
            WHERE project_id = ? AND status NOT IN ('approved', 'rejected')
        ");
        $stmt->bind_param("i", $submission['id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result['pending'] > 0) {
            return ['allowed' => false, 'reason' => 'You already have a pending extension request', 'urgency' => null];
        }
        
        // Check if extension is explicitly allowed by admin
        $extensionAllowed = $submission['extension_allowed'] ?? false;
        if ($extensionAllowed) {
            return ['allowed' => true, 'reason' => null, 'urgency' => 'admin_allowed'];
        }
        
        // Check project timeline - extension should only be available when:
        // 1. Project is nearing end date (within 30 days)
        // 2. Project is overdue
        $currentEndDate = $submission['current_end_date'] ?? $submission['proposed_end_date'] ?? null;
        
        if (!$currentEndDate) {
            // No end date set - allow extension request
            return ['allowed' => true, 'reason' => null, 'urgency' => 'no_deadline'];
        }
        
        $endTimestamp = strtotime($currentEndDate);
        $now = time();
        $daysUntilEnd = floor(($endTimestamp - $now) / 86400);
        
        if ($daysUntilEnd < 0) {
            // Project is overdue
            return ['allowed' => true, 'reason' => null, 'urgency' => 'overdue'];
        } elseif ($daysUntilEnd <= 30) {
            // Project is nearing end date (within 30 days)
            return ['allowed' => true, 'reason' => null, 'urgency' => 'nearing_deadline'];
        } else {
            // Not yet time for extension
            return [
                'allowed' => false, 
                'reason' => "Extension requests are available when the project is within 30 days of the deadline. Your project ends in {$daysUntilEnd} days.",
                'urgency' => null
            ];
        }
    }
    
    /**
     * Check if user can submit completion report
     */
    /**
     * Check if user can submit completion report
     */
    public function canSubmitCompletion($submission) {
        $check = $this->checkCompletionEligibility($submission);
        return $check['allowed'];
    }
    
    /**
     * Check completion eligibility with detailed reason
     * RMIS-Compliant: Form D1 (On-Going) must precede Form D (Completed)
     * 
     * Hard Gate Rules:
     * A) Project has started (date check or started_at flag)
     * B) At least one progress report exists
     * C) Timeline validity (within timeline or has approved extension)
     * 
     * Returns ['allowed' => bool, 'reason' => string, 'missing' => array]
     */
    public function checkCompletionEligibility($submission) {
        $missing = [];
        
        // Basic ownership check
        if (!$this->isResearcherOwner($submission)) {
            return ['allowed' => false, 'reason' => 'Only the project owner can submit completion reports', 'missing' => ['ownership']];
        }
        
        // Must be approved
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return ['allowed' => false, 'reason' => 'Project must be approved first', 'missing' => ['approval']];
        }
        
        // Check project status
        $projectStatus = $submission['project_status'] ?? null;
        if (!in_array($projectStatus, [self::PROJECT_STATUS_ON_GOING, self::PROJECT_STATUS_EXTENDED])) {
            if ($projectStatus === self::PROJECT_STATUS_COMPLETED) {
                return ['allowed' => false, 'reason' => 'Project is already completed', 'missing' => []];
            }
            return ['allowed' => false, 'reason' => 'Project must be on-going to submit completion report', 'missing' => ['status']];
        }
        
        // Check if completion report doesn't already exist
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as existing FROM project_completion_reports 
            WHERE project_id = ?
        ");
        $stmt->bind_param("i", $submission['id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result['existing'] > 0) {
            return ['allowed' => false, 'reason' => 'A completion report has already been submitted', 'missing' => []];
        }
        
        // =====================================================
        // RULE A: Project must have started
        // =====================================================
        $hasStarted = false;
        $startDate = $submission['proposed_start_date'] ?? $submission['actual_start_date'] ?? null;
        $today = date('Y-m-d');
        
        // Check if current date is on/after start date
        if ($startDate && $today >= $startDate) {
            $hasStarted = true;
        }
        
        // Check for explicit started_at timestamp (if exists in project)
        if (!empty($submission['actual_start_date'])) {
            $hasStarted = true;
        }
        
        // Check if elevated_to_project_at exists and start date has passed
        if (!empty($submission['elevated_to_project_at'])) {
            $elevatedDate = date('Y-m-d', strtotime($submission['elevated_to_project_at']));
            if ($today >= $elevatedDate) {
                $hasStarted = true;
            }
        }
        
        if (!$hasStarted) {
            $missing[] = 'start';
        }
        
        // =====================================================
        // RULE B: At least one progress report must exist
        // =====================================================
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as count FROM project_progress_reports 
            WHERE project_id = ? AND status IN ('submitted', 'reviewed', 'accepted', 'endorsed', 'under_ro_review', 'approved')
        ");
        $stmt->bind_param("i", $submission['id']);
        $stmt->execute();
        $progressCount = $stmt->get_result()->fetch_assoc()['count'];
        $stmt->close();
        
        if ($progressCount == 0) {
            $missing[] = 'progress';
        }
        
        // =====================================================
        // RULE C: Timeline validity
        // If overdue without approved extension, completion blocked
        // =====================================================
        $endDate = $submission['current_end_date'] ?? $submission['proposed_end_date'] ?? null;
        $isOverdue = false;
        $hasApprovedExtension = false;
        
        if ($endDate && $today > $endDate) {
            $isOverdue = true;
            
            // Check for approved extension covering current date
            $stmt = $this->conn->prepare("
                SELECT COUNT(*) as count FROM project_extensions 
                WHERE project_id = ? AND status = 'approved' AND approved_end_date >= ?
            ");
            $stmt->bind_param("is", $submission['id'], $today);
            $stmt->execute();
            $extensionCount = $stmt->get_result()->fetch_assoc()['count'];
            $stmt->close();
            
            if ($extensionCount > 0) {
                $hasApprovedExtension = true;
            }
        }
        
        if ($isOverdue && !$hasApprovedExtension) {
            $missing[] = 'timeline';
        }
        
        // =====================================================
        // BUILD RESPONSE
        // =====================================================
        if (!empty($missing)) {
            $reasons = [];
            
            if (in_array('start', $missing)) {
                $reasons[] = 'project has not started yet';
            }
            if (in_array('progress', $missing)) {
                $reasons[] = 'at least one progress report is required';
            }
            if (in_array('timeline', $missing)) {
                $reasons[] = 'project is overdue - request an extension first';
            }
            
            $reasonText = 'Cannot complete: ' . implode('; ', $reasons);
            
            return [
                'allowed' => false, 
                'reason' => $reasonText,
                'missing' => $missing
            ];
        }
        
        return ['allowed' => true, 'reason' => null, 'missing' => []];
    }
    
    /**
     * Get all project action availability status with reasons
     * Used by frontend to display buttons with proper states and tooltips
     */
    public function getProjectActions($submission) {
        $progressCheck = $this->checkProgressReportEligibility($submission);
        $outputCheck = $this->checkOutputEligibility($submission);
        $extensionCheck = $this->checkExtensionEligibility($submission);
        $completionCheck = $this->checkCompletionEligibility($submission);
        
        return [
            'view' => [
                'allowed' => true,
                'reason' => null,
                'priority' => 4,
                'style' => 'neutral'
            ],
            'progress' => [
                'allowed' => $progressCheck['allowed'],
                'reason' => $progressCheck['reason'],
                'priority' => 1,
                'style' => 'primary'  // Primary action - always prominent
            ],
            'output' => [
                'allowed' => $outputCheck['allowed'],
                'reason' => $outputCheck['reason'],
                'priority' => 2,
                'style' => 'secondary'  // Secondary action
            ],
            'extension' => [
                'allowed' => $extensionCheck['allowed'],
                'reason' => $extensionCheck['reason'],
                'urgency' => $extensionCheck['urgency'] ?? null,
                'priority' => 3,
                'style' => ($extensionCheck['urgency'] === 'overdue') ? 'danger' : 'warning'  // Exception action
            ],
            'completion' => [
                'allowed' => $completionCheck['allowed'],
                'reason' => $completionCheck['reason'],
                'missing' => $completionCheck['missing'] ?? [],
                'priority' => 5,
                'style' => 'success'
            ]
        ];
    }
    /**
     * Check if user can report output
     * RULE: Allowed only if at least one progress report exists OR project start date has passed
     */
    public function canReportOutput($submission) {
        $check = $this->checkOutputEligibility($submission);
        return $check['allowed'];
    }
    
    /**
     * Check output eligibility with detailed reason
     * Returns ['allowed' => bool, 'reason' => string]
     */
    public function checkOutputEligibility($submission) {
        if (!$this->isResearcherOwner($submission)) {
            return ['allowed' => false, 'reason' => 'Only the project owner can report outputs'];
        }
        
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return ['allowed' => false, 'reason' => 'Project must be approved first'];
        }
        
        $projectStatus = $submission['project_status'] ?? null;
        // Allow outputs for on-going, extended, or even completed projects
        if (!in_array($projectStatus, [self::PROJECT_STATUS_ON_GOING, self::PROJECT_STATUS_EXTENDED, self::PROJECT_STATUS_COMPLETED])) {
            return ['allowed' => false, 'reason' => 'Project must be active or completed to report outputs'];
        }
        
        // Check if at least one progress report exists
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as count FROM project_progress_reports 
            WHERE project_id = ?
        ");
        $stmt->bind_param("i", $submission['id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($result['count'] > 0) {
            // Has progress reports - output reporting is allowed
            return ['allowed' => true, 'reason' => null];
        }
        
        // Check if project start date has passed
        $startDate = $submission['proposed_start_date'] ?? null;
        if ($startDate) {
            $startTimestamp = strtotime($startDate);
            $now = time();
            
            if ($now >= $startTimestamp) {
                // Start date has passed - output reporting is allowed
                return ['allowed' => true, 'reason' => null];
            } else {
                $daysUntilStart = ceil(($startTimestamp - $now) / 86400);
                return [
                    'allowed' => false, 
                    'reason' => "Output reporting is available after the project starts or after submitting a progress report. Your project starts in {$daysUntilStart} days."
                ];
            }
        }
        
        // No start date and no progress reports - need at least one progress report
        return [
            'allowed' => false, 
            'reason' => 'Submit at least one progress report before reporting outputs'
        ];
    }
    
    /**
     * Get project status label
     */
    public static function getProjectStatusLabel($projectStatus) {
        $labels = [
            self::PROJECT_STATUS_NOT_STARTED => 'Not Yet Started',
            self::PROJECT_STATUS_ON_GOING => 'On-Going',
            self::PROJECT_STATUS_EXTENDED => 'Extended',
            self::PROJECT_STATUS_COMPLETED => 'Completed',
            self::PROJECT_STATUS_TERMINATED => 'Terminated'
        ];
        return $labels[$projectStatus] ?? ucfirst(str_replace('_', ' ', $projectStatus));
    }
    
    /**
     * Get project status CSS class
     */
    public static function getProjectStatusClass($projectStatus) {
        $classes = [
            self::PROJECT_STATUS_NOT_STARTED => 'project-not-started',
            self::PROJECT_STATUS_ON_GOING => 'project-ongoing',
            self::PROJECT_STATUS_EXTENDED => 'project-extended',
            self::PROJECT_STATUS_COMPLETED => 'project-completed',
            self::PROJECT_STATUS_TERMINATED => 'project-terminated'
        ];
        return $classes[$projectStatus] ?? 'project-default';
    }
    
    /**
     * Mark project as completed (RO action after completion report approval)
     */
    public function markProjectCompleted($submissionId, $completionReportId, $notes = null) {
        $submission = $this->getSubmission($submissionId);
        
        if (!$submission) {
            return ['success' => false, 'error' => 'Project not found'];
        }
        
        if ($submission['status'] !== self::STATUS_APPROVED) {
            return ['success' => false, 'error' => 'Only approved projects can be marked as completed'];
        }
        
        if (!$this->isResearchOfficeAdmin(true)) {
            return ['success' => false, 'error' => 'Only Research Office can mark projects as completed'];
        }
        
        try {
            $this->conn->begin_transaction();
            
            $prevProjectStatus = $submission['project_status'];
            
            // Update project status and RMIS mapping
            $stmt = $this->conn->prepare("
                UPDATE research_submissions SET
                    project_status = 'completed',
                    completed_at = NOW(),
                    rmis_form_mapping = 'D',
                    actual_end_date = CURDATE(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("i", $submissionId);
            $stmt->execute();
            $stmt->close();
            
            // Log the completion
            $this->auditLogger->log($submissionId, 'project_completed', [
                'previous_status' => $prevProjectStatus,
                'new_status' => self::PROJECT_STATUS_COMPLETED,
                'performed_by' => $this->userId,
                'performed_by_role' => 'research_office',
                'metadata' => [
                    'completion_report_id' => $completionReportId,
                    'rmis_form' => 'D'
                ]
            ]);
            
            // Log lifecycle change
            $this->logProjectLifecycle($submissionId, $prevProjectStatus, 'completed', 'D1', 'D',
                'completion_approved', 'completion_report', $completionReportId, $notes);
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'message' => 'Project marked as completed and mapped to RMIS Form D'
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("WorkflowEngine::markProjectCompleted error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Get all approved projects (on-going) for monitoring
     */
    public function getActiveProjects($filters = [], $page = 1, $perPage = 20) {
        $where = ["rs.status = 'approved'", "rs.project_status IN ('on_going', 'extended')"];
        $params = [];
        $types = "";
        
        if (!empty($filters['researcher_type'])) {
            $where[] = "rs.researcher_type = ?";
            $params[] = $filters['researcher_type'];
            $types .= 's';
        }
        
        if (!empty($filters['unit'])) {
            $where[] = "(rs.researcher_unit_id = ? OR rs.researcher_unit_name LIKE ?)";
            $params[] = $filters['unit'];
            $params[] = '%' . $filters['unit'] . '%';
            $types .= 'ss';
        }
        
        if (!empty($filters['search'])) {
            $where[] = "(rs.title LIKE ? OR rs.reference_number LIKE ? OR rs.project_code LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
            $types .= 'sss';
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $where);
        $offset = ($page - 1) * $perPage;
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM research_submissions rs $whereClause";
        $countStmt = $this->conn->prepare($countSql);
        if (!empty($params)) {
            $countStmt->bind_param($types, ...$params);
        }
        $countStmt->execute();
        $total = $countStmt->get_result()->fetch_assoc()['total'];
        $countStmt->close();
        
        // Get data
        $sql = "
            SELECT 
                rs.id,
                rs.reference_number,
                rs.project_code,
                rs.title,
                rs.researcher_type,
                rs.researcher_unit_name,
                rs.project_status,
                rs.rmis_form_mapping,
                rs.proposed_start_date,
                rs.current_end_date,
                rs.total_budget,
                rs.elevated_to_project_at,
                rs.extension_count,
                rst.type_name
            FROM research_submissions rs
            JOIN research_submission_types rst ON rs.submission_type_id = rst.id
            $whereClause
            ORDER BY rs.elevated_to_project_at DESC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($sql);
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Add calculated fields
        foreach ($data as &$row) {
            $row['project_status_label'] = self::getProjectStatusLabel($row['project_status']);
            $row['project_status_class'] = self::getProjectStatusClass($row['project_status']);
            
            // Calculate progress/timeline
            if ($row['proposed_start_date'] && $row['current_end_date']) {
                $start = strtotime($row['proposed_start_date']);
                $end = strtotime($row['current_end_date']);
                $now = time();
                
                if ($now >= $end) {
                    $row['timeline_status'] = 'overdue';
                    $row['days_overdue'] = floor(($now - $end) / 86400);
                } elseif ($now <= $start) {
                    $row['timeline_status'] = 'not_started';
                } else {
                    $row['timeline_status'] = 'in_progress';
                    $total = $end - $start;
                    $elapsed = $now - $start;
                    $row['progress_percent'] = min(100, round(($elapsed / $total) * 100));
                }
            }
        }
        
        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ];
    }
    
    /**
     * Get project summary statistics
     */
    public function getProjectStatistics($scope = 'all') {
        $where = '';
        $params = [];
        $types = '';
        
        if ($scope === 'researcher' && $this->userId) {
            $where = 'WHERE (created_by = ? OR researcher_user_id = ?)';
            $params = [$this->userId, $this->userId];
            $types = 'ii';
        }
        
        $sql = "
            SELECT 
                COUNT(CASE WHEN status = 'approved' AND project_status = 'on_going' THEN 1 END) as on_going,
                COUNT(CASE WHEN status = 'approved' AND project_status = 'extended' THEN 1 END) as extended,
                COUNT(CASE WHEN status = 'approved' AND project_status = 'completed' THEN 1 END) as completed,
                COUNT(CASE WHEN status = 'approved' AND project_status IN ('on_going', 'extended') 
                      AND current_end_date < CURDATE() THEN 1 END) as overdue,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as total_approved
            FROM research_submissions
            $where
        ";
        
        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }
}
