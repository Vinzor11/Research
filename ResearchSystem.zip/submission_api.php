<?php
/**
 * Research Submission API
 * 
 * Handles all AJAX operations for the research submission workflow:
 * - Create/Update submissions
 * - Workflow actions (submit, return, endorse, approve, reject)
 * - Attachment management
 * - Comment operations
 * 
 * All actions enforce role-based permissions via WorkflowEngine.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');

require_once 'db.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required']);
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? '';

$service = new SubmissionService($conn);
$workflow = $service->getWorkflowEngine();

// Determine request method and action
$method = $_SERVER['REQUEST_METHOD'];

// Handle JSON body for POST requests
if ($method === 'POST' && strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $jsonBody = json_decode(file_get_contents('php://input'), true);
    if ($jsonBody) {
        $_POST = array_merge($_POST, $jsonBody);
    }
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Normalize 'id' to 'submission_id' for consistency
if (isset($_POST['id']) && !isset($_POST['submission_id'])) {
    $_POST['submission_id'] = $_POST['id'];
}

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($action, $service, $workflow);
            break;
        case 'POST':
            handlePostRequest($action, $service, $workflow);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    error_log("Submission API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'An error occurred: ' . $e->getMessage()]);
}

/**
 * Handle GET requests
 */
function handleGetRequest($action, $service, $workflow) {
    switch ($action) {
        case 'get':
            $id = intval($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $submission = $service->getById($id);
            if (!$submission) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Submission not found']);
                return;
            }
            echo json_encode(['success' => true, 'data' => $submission]);
            break;
            
        case 'list':
            $scope = $_GET['scope'] ?? 'researcher';
            $filters = [
                'status' => $_GET['status'] ?? null,
                'type_id' => $_GET['type_id'] ?? null,
                'search' => $_GET['search'] ?? null,
                'researcher_type' => $_GET['researcher_type'] ?? null
            ];
            $page = intval($_GET['page'] ?? 1);
            $perPage = intval($_GET['per_page'] ?? 20);
            
            switch ($scope) {
                case 'coordinator':
                    $result = $service->getCoordinatorQueue($filters, $page, $perPage);
                    break;
                case 'research_office':
                    $result = $service->getResearchOfficeQueue($filters, $page, $perPage);
                    break;
                case 'admin':
                    $result = $service->getAllSubmissions($filters, $page, $perPage);
                    break;
                default:
                    $result = $service->getResearcherSubmissions($filters, $page, $perPage);
            }
            echo json_encode(['success' => true, 'data' => $result]);
            break;
            
        case 'types':
            $types = $service->getSubmissionTypes();
            echo json_encode(['success' => true, 'data' => $types]);
            break;
            
        case 'history':
            $id = intval($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $history = $service->getHistory($id);
            echo json_encode(['success' => true, 'data' => $history]);
            break;
            
        case 'comments':
            $id = intval($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $comments = $service->getComments($id);
            echo json_encode(['success' => true, 'data' => $comments]);
            break;
            
        case 'statistics':
            $scope = $_GET['scope'] ?? 'all';
            $stats = $service->getStatistics($scope);
            echo json_encode(['success' => true, 'data' => $stats]);
            break;
            
        case 'endorsement':
            $id = intval($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $endorsement = $service->getEndorsementSummary($id);
            echo json_encode(['success' => true, 'data' => $endorsement]);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

/**
 * Handle POST requests
 */
function handlePostRequest($action, $service, $workflow) {
    global $userId;
    
    switch ($action) {
        // ========================================
        // SUBMISSION CRUD
        // ========================================
        case 'create':
            $data = [
                'submission_type_id' => intval($_POST['submission_type_id'] ?? 0),
                'researcher_type' => $_POST['researcher_type'] ?? '',
                'researcher_id' => intval($_POST['researcher_id'] ?? 0),
                'title' => trim($_POST['title'] ?? ''),
                'abstract' => trim($_POST['abstract'] ?? ''),
                'objectives' => trim($_POST['objectives'] ?? ''),
                'methodology' => trim($_POST['methodology'] ?? ''),
                'expected_outcomes' => trim($_POST['expected_outcomes'] ?? ''),
                'proposed_start_date' => $_POST['proposed_start_date'] ?: null,
                'proposed_end_date' => $_POST['proposed_end_date'] ?: null,
                'total_budget' => floatval($_POST['total_budget'] ?? 0)
            ];
            
            $result = $service->create($data);
            
            if ($result['success']) {
                // Handle file uploads
                if (!empty($_FILES['attachments'])) {
                    handleFileUploads($service, $result['submission_id'], $_FILES['attachments']);
                }
                
                // Auto-submit if requested
                if (isset($_POST['submit_action']) && $_POST['submit_action'] === 'submit') {
                    $submitResult = $workflow->submit($result['submission_id']);
                    if (!$submitResult['success']) {
                        // Still created as draft, but submission failed
                        $result['warning'] = 'Submission saved as draft. ' . $submitResult['error'];
                    } else {
                        $result['submitted'] = true;
                        $result['coordinator'] = $submitResult['coordinator'] ?? null;
                    }
                }
            }
            
            echo json_encode($result);
            break;
            
        case 'update':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            
            $data = [];
            $fields = ['title', 'abstract', 'objectives', 'methodology', 'expected_outcomes', 
                       'proposed_start_date', 'proposed_end_date', 'total_budget'];
            
            foreach ($fields as $field) {
                if (isset($_POST[$field])) {
                    $data[$field] = $_POST[$field];
                }
            }
            
            $result = $service->update($id, $data);
            
            if ($result['success']) {
                // Handle file uploads
                if (!empty($_FILES['attachments'])) {
                    handleFileUploads($service, $id, $_FILES['attachments']);
                }
                
                // Auto-submit if requested
                if (isset($_POST['submit_action']) && $_POST['submit_action'] === 'submit') {
                    $submitResult = $workflow->submit($id);
                    if (!$submitResult['success']) {
                        $result['warning'] = $submitResult['error'];
                    } else {
                        $result['submitted'] = true;
                        $result['coordinator'] = $submitResult['coordinator'] ?? null;
                    }
                }
            }
            
            echo json_encode($result);
            break;
            
        // ========================================
        // RESEARCHER ACTIONS
        // ========================================
        case 'submit':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $result = $workflow->submit($id);
            echo json_encode($result);
            break;
            
        // ========================================
        // COORDINATOR ACTIONS
        // ========================================
        case 'start_coordinator_review':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $result = $workflow->startCoordinatorReview($id);
            echo json_encode($result);
            break;
            
        case 'start_review':
            // Generic start review - determines which type based on submission status
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $submission = $service->getById($id);
            if (!$submission) {
                echo json_encode(['success' => false, 'error' => 'Submission not found']);
                return;
            }
            
            if ($submission['status'] === 'submitted') {
                $result = $workflow->startCoordinatorReview($id);
            } elseif ($submission['status'] === 'endorsed') {
                $result = $workflow->startROReview($id);
            } else {
                $result = ['success' => false, 'error' => 'Cannot start review from current status'];
            }
            echo json_encode($result);
            break;
            
        case 'return_for_revision':
        case 'return':
            $id = intval($_POST['submission_id'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');
            $comments = trim($_POST['comments'] ?? '');
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason is required']);
                return;
            }
            
            $result = $workflow->returnForRevision($id, $reason, $comments);
            echo json_encode($result);
            break;
            
        case 'endorse':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            
            $validationData = [
                'completeness_verified' => !empty($_POST['completeness_verified']) ? 1 : 0,
                'unit_verified' => !empty($_POST['unit_verified']) ? 1 : 0,
                'category_verified' => !empty($_POST['category_verified']) ? 1 : 0,
                'attachments_verified' => !empty($_POST['attachments_verified']) ? 1 : 0
            ];
            $notes = trim($_POST['notes'] ?? '');
            
            $result = $workflow->endorseToResearchOffice($id, $validationData, $notes);
            echo json_encode($result);
            break;
            
        // ========================================
        // RESEARCH OFFICE ACTIONS
        // ========================================
        case 'start_ro_review':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            $result = $workflow->startROReview($id);
            echo json_encode($result);
            break;
            
        case 'assign_classification':
        case 'classify':
            $id = intval($_POST['submission_id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            
            // Handle tags - can be array or comma-separated string
            $tags = [];
            if (isset($_POST['tags'])) {
                if (is_array($_POST['tags'])) {
                    $tags = $_POST['tags'];
                } else {
                    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'])));
                }
            }
            
            $data = [
                'research_program' => trim($_POST['research_program'] ?? ''),
                'funding_source' => trim($_POST['funding_source'] ?? ''),
                'fiscal_year' => trim($_POST['fiscal_year'] ?? ''),
                'tags' => $tags
            ];
            
            $result = $workflow->assignClassification($id, $data);
            echo json_encode($result);
            break;
            
        case 'approve':
            $id = intval($_POST['submission_id'] ?? 0);
            $notes = trim($_POST['notes'] ?? '');
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            
            $result = $workflow->approve($id, $notes);
            echo json_encode($result);
            break;
            
        case 'reject':
            $id = intval($_POST['submission_id'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Rejection reason is required']);
                return;
            }
            
            $result = $workflow->reject($id, $reason);
            echo json_encode($result);
            break;
            
        case 'return_to_coordinator':
            $id = intval($_POST['submission_id'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');
            $instructions = trim($_POST['instructions'] ?? '');
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason is required']);
                return;
            }
            
            $result = $workflow->returnToCoordinator($id, $reason, $instructions);
            echo json_encode($result);
            break;
            
        // ========================================
        // ATTACHMENT ACTIONS
        // ========================================
        case 'add_attachment':
            $id = intval($_POST['submission_id'] ?? 0);
            $type = $_POST['attachment_type'] ?? 'supporting_document';
            $description = trim($_POST['description'] ?? '');
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Submission ID required']);
                return;
            }
            if (empty($_FILES['file'])) {
                echo json_encode(['success' => false, 'error' => 'No file uploaded']);
                return;
            }
            
            $result = $service->addAttachment($id, $_FILES['file'], $type, $description);
            echo json_encode($result);
            break;
            
        case 'remove_attachment':
            $attachmentId = intval($_POST['attachment_id'] ?? 0);
            if (!$attachmentId) {
                echo json_encode(['success' => false, 'error' => 'Attachment ID required']);
                return;
            }
            $result = $service->removeAttachment($attachmentId);
            echo json_encode($result);
            break;
            
        // ========================================
        // COMMENT ACTIONS
        // ========================================
        case 'add_comment':
            $id = intval($_POST['submission_id'] ?? 0);
            $text = trim($_POST['comment'] ?? '');
            $type = $_POST['comment_type'] ?? 'general';
            
            if (!$id || !$text) {
                echo json_encode(['success' => false, 'error' => 'Submission ID and comment text required']);
                return;
            }
            
            $workflow->addComment($id, $type, $text);
            echo json_encode(['success' => true, 'message' => 'Comment added']);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

/**
 * Handle file uploads
 */
function handleFileUploads($service, $submissionId, $files) {
    // Handle both single and multiple file uploads
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;
    
    for ($i = 0; $i < $fileCount; $i++) {
        $file = [
            'name' => is_array($files['name']) ? $files['name'][$i] : $files['name'],
            'type' => is_array($files['type']) ? $files['type'][$i] : $files['type'],
            'tmp_name' => is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'],
            'error' => is_array($files['error']) ? $files['error'][$i] : $files['error'],
            'size' => is_array($files['size']) ? $files['size'][$i] : $files['size']
        ];
        
        if ($file['error'] === UPLOAD_ERR_OK) {
            $service->addAttachment($submissionId, $file, 'supporting_document');
        }
    }
}

$conn->close();
?>
