-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2026 at 05:32 AM
-- Server version: 11.7.2-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `research_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` enum('create','update','delete','view','export','login','logout') NOT NULL,
  `table_affected` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `collaboration_audit_log`
--

CREATE TABLE `collaboration_audit_log` (
  `id` int(11) NOT NULL,
  `collaboration_id` int(11) NOT NULL,
  `action_type` enum('created','updated','submitted','assigned_coordinator','coordinator_review_started','returned_for_revision','revision_submitted','endorsed','assigned_ro_admin','ro_review_started','approved','rejected','returned_to_coordinator','reference_assigned','document_uploaded','document_removed','status_changed','record_logged','record_updated','record_completed','comment_added') NOT NULL,
  `previous_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `performed_by` int(11) NOT NULL,
  `performed_by_role` varchar(50) NOT NULL,
  `performed_by_name` varchar(255) DEFAULT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `target_role` varchar(50) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Immutable collaboration audit trail';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `collaboration_comments`
--

CREATE TABLE `collaboration_comments` (
  `id` int(11) NOT NULL,
  `collaboration_id` int(11) NOT NULL,
  `comment_type` enum('general','validation_note','revision_request','endorsement_note','approval_note','rejection_reason','internal_note') NOT NULL DEFAULT 'general',
  `comment_text` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0 COMMENT '1 if only visible to coordinators/admins',
  `created_by` int(11) NOT NULL,
  `created_by_role` varchar(50) NOT NULL,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `visible_to_researcher` tinyint(1) DEFAULT 1,
  `visible_to_coordinator` tinyint(1) DEFAULT 1,
  `visible_to_ro` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Comments on collaborations';

-- --------------------------------------------------------

--
-- Table structure for table `collaboration_endorsement_summary`
--

CREATE TABLE `collaboration_endorsement_summary` (
  `id` int(11) NOT NULL,
  `collaboration_id` int(11) NOT NULL,
  `coordinator_id` int(11) NOT NULL,
  `coordinator_employee_id` varchar(100) DEFAULT NULL,
  `partner_verified` tinyint(1) DEFAULT 0 COMMENT 'Partner legitimacy verified',
  `documents_verified` tinyint(1) DEFAULT 0 COMMENT 'Required documents present',
  `scope_verified` tinyint(1) DEFAULT 0 COMMENT 'Scope/purpose is clear',
  `compliance_verified` tinyint(1) DEFAULT 0 COMMENT 'Complies with policies',
  `endorsement_notes` text DEFAULT NULL,
  `endorsed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Coordinator validation for endorsed collaborations';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `collaboration_types`
--

CREATE TABLE `collaboration_types` (
  `id` int(11) NOT NULL,
  `type_code` varchar(50) NOT NULL,
  `type_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `category` enum('request','record') NOT NULL DEFAULT 'record' COMMENT 'request = requires approval (queue), record = informational only',
  `requires_coordinator_review` tinyint(1) DEFAULT 1 COMMENT 'Must go through coordinator',
  `requires_ro_approval` tinyint(1) DEFAULT 1 COMMENT 'Must be approved by Research Office',
  `requires_moa_document` tinyint(1) DEFAULT 0 COMMENT 'Requires MOA/MOU document upload',
  `icon_class` varchar(50) DEFAULT 'fa-handshake' COMMENT 'Font Awesome icon class',
  `color_class` varchar(50) DEFAULT 'collab-default' COMMENT 'CSS color class',
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Collaboration type definitions';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `coordinator_assignments`
--

CREATE TABLE `coordinator_assignments` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `coordinator_type` enum('faculty','student','personnel') NOT NULL,
  `scope_mode` enum('own_unit','specific_units','all_units') DEFAULT 'own_unit',
  `hr_unit_id` varchar(100) DEFAULT NULL,
  `hr_unit_name` varchar(255) DEFAULT NULL,
  `assigned_by` int(11) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `coordinator_assignment_logs`
--

CREATE TABLE `coordinator_assignment_logs` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `coordinator_type` varchar(20) DEFAULT NULL,
  `scope_mode` varchar(20) DEFAULT NULL,
  `unit_id` varchar(100) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `performed_by` int(11) NOT NULL,
  `performed_at` timestamp NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `coordinator_endorsement_summary`
--

CREATE TABLE `coordinator_endorsement_summary` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `coordinator_id` int(11) NOT NULL,
  `coordinator_employee_id` varchar(100) DEFAULT NULL,
  `completeness_verified` tinyint(1) DEFAULT 0,
  `unit_verified` tinyint(1) DEFAULT 0,
  `category_verified` tinyint(1) DEFAULT 0,
  `attachments_verified` tinyint(1) DEFAULT 0,
  `endorsement_notes` text DEFAULT NULL,
  `endorsed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Coordinator validation summary for endorsed submissions';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `coordinator_scopes`
--

CREATE TABLE `coordinator_scopes` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `unit_id` varchar(100) NOT NULL,
  `unit_name` varchar(255) DEFAULT '',
  `unit_type` varchar(50) DEFAULT '',
  `assigned_by` int(11) NOT NULL,
  `assigned_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `coordinator_submission_flag`
--

CREATE TABLE `coordinator_submission_flag` (
  `id` int(11) NOT NULL,
  `item_type` enum('proposal','progress','extension','output','completion','collaboration') NOT NULL,
  `source_id` int(11) NOT NULL,
  `submitter_user_id` int(11) NOT NULL,
  `submitter_employee_id` varchar(100) NOT NULL,
  `submitter_coordinator_type` varchar(50) NOT NULL,
  `escalation_type` enum('peer_coordinator','research_office') NOT NULL,
  `escalation_reason` text DEFAULT NULL,
  `peer_coordinator_id` int(11) DEFAULT NULL,
  `peer_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Tracks coordinator-submitted items';

-- --------------------------------------------------------

--
-- Table structure for table `coordinator_submission_routing_log`
--

CREATE TABLE `coordinator_submission_routing_log` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `submitter_user_id` int(11) NOT NULL COMMENT 'User ID of the coordinator who submitted',
  `submitter_employee_id` varchar(100) DEFAULT NULL COMMENT 'HR Employee ID',
  `submitter_coordinator_type` varchar(50) NOT NULL COMMENT 'faculty/student/personnel',
  `routing_decision` enum('peer_coordinator','escalated_to_ro') NOT NULL,
  `assigned_peer_coordinator_id` int(11) DEFAULT NULL COMMENT 'User ID of peer coordinator assigned',
  `assigned_peer_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `excluded_coordinator_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Coordinators excluded from review (including submitter)' CHECK (json_valid(`excluded_coordinator_ids`)),
  `escalation_reason` text DEFAULT NULL COMMENT 'Why escalated to RO instead of peer coordinator',
  `available_peer_count` int(11) DEFAULT 0 COMMENT 'Number of available peer coordinators at time of submission',
  `submission_unit_id` varchar(100) DEFAULT NULL,
  `submission_unit_name` varchar(255) DEFAULT NULL,
  `researcher_type` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Audit log for coordinator submission routing decisions';

-- --------------------------------------------------------

--
-- Table structure for table `faculty_education`
--

CREATE TABLE `faculty_education` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `degree_program` varchar(255) DEFAULT NULL,
  `college_university` varchar(255) DEFAULT NULL,
  `has_thesis` enum('Yes','No') DEFAULT 'No',
  `year_graduated` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_projects`
--

CREATE TABLE `faculty_projects` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `project_status` enum('on-going','completed','published') DEFAULT 'on-going',
  `classification` varchar(100) DEFAULT NULL,
  `funding_source` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `parent_project_id` int(11) DEFAULT NULL,
  `is_project_leader` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_costs`
--

CREATE TABLE `faculty_project_costs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_project_team`
--

CREATE TABLE `faculty_project_team` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` varchar(50) DEFAULT NULL,
  `highest_attainment` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_researchers`
--

CREATE TABLE `faculty_researchers` (
  `id` int(11) NOT NULL,
  `hr_employee_id` varchar(50) DEFAULT NULL,
  `faculty_number` varchar(50) DEFAULT NULL,
  `last_name` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `faculty_rank` varchar(100) DEFAULT NULL,
  `employment_status` enum('Full-Time','Part-Time') DEFAULT 'Full-Time',
  `home_unit` varchar(150) DEFAULT NULL,
  `department` varchar(150) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `user_id` int(11) DEFAULT NULL COMMENT 'References users.id for imported researchers',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_synced_at` datetime DEFAULT NULL,
  `is_synced` tinyint(1) DEFAULT 0,
  `sync_status` enum('synced','needs-sync','not-synced','n/a') DEFAULT 'not-synced' COMMENT 'n/a when employee deleted or not in same unit',
  `hr_data_json` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `faculty_research_outputs`
--

CREATE TABLE `faculty_research_outputs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL,
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hr_sync_history`
--

CREATE TABLE `hr_sync_history` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `action_type` enum('import','update') NOT NULL,
  `hr_employee_id` varchar(100) DEFAULT NULL,
  `synced_by` int(11) NOT NULL,
  `synced_at` timestamp NULL DEFAULT current_timestamp(),
  `data_snapshot` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_settings`
--

CREATE TABLE `oauth_settings` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `is_secret` tinyint(1) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `oauth_tokens`
--

CREATE TABLE `oauth_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `access_token` text NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `token_type` varchar(50) DEFAULT 'Bearer',
  `expires_at` datetime NOT NULL,
  `scope` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `personnel_education`
--

CREATE TABLE `personnel_education` (
  `id` int(11) NOT NULL,
  `personnel_id` int(11) NOT NULL,
  `degree_program` varchar(255) DEFAULT NULL,
  `college_university` varchar(255) DEFAULT NULL,
  `has_thesis` enum('Yes','No') DEFAULT 'No',
  `year_graduated` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personnel_projects`
--

CREATE TABLE `personnel_projects` (
  `id` int(11) NOT NULL,
  `personnel_id` int(11) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `project_status` enum('on-going','completed','published') DEFAULT 'on-going',
  `classification` varchar(100) DEFAULT NULL,
  `funding_source` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `parent_project_id` int(11) DEFAULT NULL,
  `is_project_leader` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personnel_project_costs`
--

CREATE TABLE `personnel_project_costs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personnel_project_team`
--

CREATE TABLE `personnel_project_team` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `employment_status` varchar(50) DEFAULT NULL,
  `highest_attainment` varchar(255) DEFAULT NULL,
  `nature_of_involvement` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personnel_researchers`
--

CREATE TABLE `personnel_researchers` (
  `id` int(11) NOT NULL,
  `hr_employee_id` varchar(50) DEFAULT NULL COMMENT 'HR System employee ID',
  `employee_number` varchar(50) DEFAULT NULL COMMENT 'Local employee number',
  `last_name` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `position` varchar(150) DEFAULT NULL COMMENT 'Job position/title',
  `employment_status` enum('Full-Time','Part-Time','Contractual','Casual') DEFAULT 'Full-Time',
  `office_unit` varchar(150) DEFAULT NULL COMMENT 'Office/administrative unit',
  `department` varchar(150) DEFAULT NULL,
  `sector` varchar(150) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `user_id` int(11) DEFAULT NULL COMMENT 'References users.id for imported researchers',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_synced_at` datetime DEFAULT NULL,
  `is_synced` tinyint(1) DEFAULT 0,
  `sync_status` enum('synced','needs-sync','not-synced','n/a') DEFAULT 'not-synced',
  `hr_data_json` text DEFAULT NULL COMMENT 'Full HR API response cached'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Non-academic/personnel researchers';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `personnel_research_outputs`
--

CREATE TABLE `personnel_research_outputs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL,
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_action_logs`
--

CREATE TABLE `project_action_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL COMMENT 'ID of user who attempted the action',
  `user_role` varchar(50) DEFAULT NULL COMMENT 'Role of user at time of action',
  `username` varchar(100) DEFAULT NULL COMMENT 'Username for quick reference',
  `project_id` int(11) DEFAULT NULL COMMENT 'Project the action was attempted on',
  `project_status` varchar(50) DEFAULT NULL COMMENT 'Project status at time of action',
  `action` varchar(100) NOT NULL COMMENT 'Action attempted (create_progress_report, create_extension, report_output, create_completion)',
  `status` enum('success','blocked','error') NOT NULL DEFAULT 'success' COMMENT 'Result of the action attempt',
  `reason` text DEFAULT NULL COMMENT 'Reason for blocking or error message',
  `metadata` text DEFAULT NULL COMMENT 'Additional context data in JSON format',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP address of the request',
  `created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'When the action was attempted'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Audit log for project action attempts';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `project_collaborations`
--

CREATE TABLE `project_collaborations` (
  `id` int(11) NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL COMMENT 'Reference number for collaboration requests',
  `project_id` int(11) DEFAULT NULL COMMENT 'FK to research_submissions if project-linked',
  `researcher_type` enum('faculty','student','personnel') NOT NULL,
  `researcher_id` int(11) NOT NULL COMMENT 'ID in respective researcher table',
  `researcher_user_id` int(11) DEFAULT NULL COMMENT 'User ID if researcher has login',
  `researcher_unit_id` varchar(100) DEFAULT NULL COMMENT 'HR unit ID for routing',
  `researcher_unit_name` varchar(255) DEFAULT NULL COMMENT 'Cached unit name',
  `collaboration_type_id` int(11) NOT NULL COMMENT 'FK to collaboration_types',
  `collaboration_category` enum('request','record') NOT NULL COMMENT 'request = needs approval, record = informational only',
  `partner_name` varchar(500) NOT NULL COMMENT 'Name of collaborating institution/individual',
  `partner_type` enum('academic','government','industry','ngo','international','individual','other') NOT NULL,
  `partner_country` varchar(100) DEFAULT 'Philippines',
  `partner_address` text DEFAULT NULL,
  `partner_contact_person` varchar(255) DEFAULT NULL,
  `partner_contact_email` varchar(255) DEFAULT NULL,
  `partner_contact_phone` varchar(50) DEFAULT NULL,
  `title` varchar(500) NOT NULL COMMENT 'Title/description of collaboration',
  `purpose` text NOT NULL COMMENT 'Purpose and objectives of collaboration',
  `scope_of_work` text DEFAULT NULL COMMENT 'Detailed scope of collaboration',
  `expected_outcomes` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_ongoing` tinyint(1) DEFAULT 0 COMMENT '1 if no defined end date',
  `has_financial_component` tinyint(1) DEFAULT 0,
  `financial_details` text DEFAULT NULL,
  `amount_involved` decimal(15,2) DEFAULT NULL,
  `moa_document_path` varchar(500) DEFAULT NULL COMMENT 'Path to MOA/MOU document',
  `supporting_documents` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Array of supporting document paths' CHECK (json_valid(`supporting_documents`)),
  `status` enum('draft','submitted','under_coordinator_review','returned_for_revision','endorsed','under_ro_review','approved','rejected') NOT NULL DEFAULT 'draft',
  `record_status` enum('active','inactive','completed') DEFAULT 'active' COMMENT 'Status for informational records',
  `is_queue_item` tinyint(1) DEFAULT 0 COMMENT '1 if currently in work queue (only for requests)',
  `current_handler_type` enum('researcher','coordinator','research_office') DEFAULT 'researcher',
  `current_handler_id` int(11) DEFAULT NULL,
  `assigned_coordinator_id` int(11) DEFAULT NULL,
  `assigned_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `assigned_ro_admin_id` int(11) DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `coordinator_received_at` datetime DEFAULT NULL,
  `coordinator_endorsed_at` datetime DEFAULT NULL,
  `ro_received_at` datetime DEFAULT NULL,
  `decision_at` datetime DEFAULT NULL,
  `revision_count` int(11) DEFAULT 0,
  `last_revision_at` datetime DEFAULT NULL,
  `approval_remarks` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `endorsed_by` int(11) DEFAULT NULL,
  `endorsed_at` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `return_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Collaboration requests and records';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `project_completion_reports`
--

CREATE TABLE `project_completion_reports` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK to research_submissions (one completion per project)',
  `actual_completion_date` date NOT NULL,
  `executive_summary` text NOT NULL COMMENT 'Executive summary of completed research',
  `objectives_achieved` text NOT NULL COMMENT 'Assessment of objectives achievement',
  `objectives_achievement_rate` int(11) DEFAULT NULL COMMENT 'Percentage of objectives achieved',
  `key_findings` text NOT NULL,
  `conclusions` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `deliverables_produced` text NOT NULL COMMENT 'List of deliverables produced',
  `publications` text DEFAULT NULL COMMENT 'Publications resulting from research',
  `patents_filed` text DEFAULT NULL COMMENT 'Patents or IPs filed',
  `technologies_developed` text DEFAULT NULL COMMENT 'Technologies or products developed',
  `beneficiaries` text DEFAULT NULL COMMENT 'Who benefited from the research',
  `social_impact` text DEFAULT NULL,
  `economic_impact` text DEFAULT NULL,
  `policy_contributions` text DEFAULT NULL,
  `total_budget_utilized` decimal(15,2) DEFAULT NULL,
  `budget_variance` decimal(15,2) DEFAULT NULL,
  `financial_remarks` text DEFAULT NULL,
  `lessons_learned` text DEFAULT NULL,
  `future_research_directions` text DEFAULT NULL,
  `status` enum('draft','submitted','under_coordinator_review','returned_for_revision','endorsed','under_ro_review','approved','rejected','returned') DEFAULT 'draft',
  `coordinator_reviewed_by` int(11) DEFAULT NULL,
  `coordinator_reviewed_at` datetime DEFAULT NULL,
  `coordinator_remarks` text DEFAULT NULL,
  `ro_reviewed_by` int(11) DEFAULT NULL,
  `ro_reviewed_at` datetime DEFAULT NULL,
  `ro_remarks` text DEFAULT NULL,
  `decision_at` datetime DEFAULT NULL,
  `submitted_by` int(11) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `assigned_coordinator_id` int(11) DEFAULT NULL,
  `assigned_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `coordinator_endorsed_at` datetime DEFAULT NULL,
  `ro_received_at` datetime DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `revision_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Completion reports for finished research projects';

-- --------------------------------------------------------

--
-- Table structure for table `project_extensions`
--

CREATE TABLE `project_extensions` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK to research_submissions (approved project)',
  `extension_type` enum('timeline','budget','scope','timeline_budget') NOT NULL,
  `original_end_date` date DEFAULT NULL,
  `original_budget` decimal(15,2) DEFAULT NULL,
  `requested_end_date` date DEFAULT NULL COMMENT 'New requested end date',
  `requested_additional_budget` decimal(15,2) DEFAULT NULL,
  `scope_changes` text DEFAULT NULL COMMENT 'Description of scope changes',
  `justification` text NOT NULL COMMENT 'Detailed justification for extension',
  `supporting_documents` text DEFAULT NULL COMMENT 'List of supporting document attachments',
  `status` enum('draft','submitted','under_coordinator_review','returned_for_revision','endorsed','under_ro_review','approved','rejected') DEFAULT 'draft',
  `coordinator_reviewed_by` int(11) DEFAULT NULL,
  `coordinator_reviewed_at` datetime DEFAULT NULL,
  `coordinator_remarks` text DEFAULT NULL,
  `coordinator_recommendation` enum('endorse','return','reject') DEFAULT NULL,
  `ro_reviewed_by` int(11) DEFAULT NULL,
  `ro_reviewed_at` datetime DEFAULT NULL,
  `ro_remarks` text DEFAULT NULL,
  `decision_at` datetime DEFAULT NULL,
  `approved_end_date` date DEFAULT NULL COMMENT 'Approved new end date',
  `approved_additional_budget` decimal(15,2) DEFAULT NULL,
  `approval_conditions` text DEFAULT NULL,
  `requested_by` int(11) NOT NULL,
  `requested_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `assigned_coordinator_id` int(11) DEFAULT NULL,
  `assigned_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `coordinator_endorsed_at` datetime DEFAULT NULL,
  `ro_received_at` datetime DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `revision_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Extension and amendment requests for approved projects';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `project_field_change_requests`
--

CREATE TABLE `project_field_change_requests` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `field_name` enum('title','objectives','methodology','expected_outcomes') NOT NULL,
  `current_value` text NOT NULL,
  `requested_value` text NOT NULL,
  `change_reason` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_remarks` text DEFAULT NULL,
  `requested_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Requests to modify locked proposal fields';

-- --------------------------------------------------------

--
-- Table structure for table `project_lifecycle_log`
--

CREATE TABLE `project_lifecycle_log` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `previous_project_status` varchar(50) DEFAULT NULL,
  `new_project_status` varchar(50) NOT NULL,
  `previous_rmis_form` varchar(10) DEFAULT NULL,
  `new_rmis_form` varchar(10) DEFAULT NULL,
  `trigger_action` varchar(100) NOT NULL COMMENT 'What triggered this state change',
  `trigger_source_type` varchar(50) DEFAULT NULL COMMENT 'e.g., approval, extension, completion',
  `trigger_source_id` int(11) DEFAULT NULL,
  `performed_by` int(11) NOT NULL,
  `performed_by_role` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Immutable log of project lifecycle state changes';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `project_outputs`
--

CREATE TABLE `project_outputs` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK to research_submissions (approved project)',
  `output_type` enum('journal_article','conference_paper','book_chapter','book','patent','utility_model','technology','product','policy_brief','manual','training_module','other') NOT NULL,
  `title` varchar(500) NOT NULL,
  `authors` text NOT NULL COMMENT 'List of authors',
  `publication_venue` varchar(500) DEFAULT NULL COMMENT 'Journal name, conference, publisher',
  `publication_date` date DEFAULT NULL,
  `indexing_status` enum('scopus','wos','asean','ched_recognized','peer_reviewed','non_indexed','pending') DEFAULT 'pending',
  `doi` varchar(255) DEFAULT NULL,
  `isbn_issn` varchar(50) DEFAULT NULL,
  `award_received` varchar(255) DEFAULT NULL,
  `award_date` date DEFAULT NULL,
  `awarding_body` varchar(255) DEFAULT NULL,
  `status` enum('draft','submitted','under_review','endorsed','verified','rejected','returned') DEFAULT 'draft',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verification_remarks` text DEFAULT NULL,
  `proof_document_path` varchar(500) DEFAULT NULL,
  `reported_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `submitted_at` datetime DEFAULT NULL,
  `submitted_by` int(11) DEFAULT NULL,
  `coordinator_verified_by` int(11) DEFAULT NULL,
  `coordinator_verified_at` datetime DEFAULT NULL,
  `coordinator_remarks` text DEFAULT NULL,
  `endorsed_at` datetime DEFAULT NULL,
  `ro_verified_by` int(11) DEFAULT NULL COMMENT 'Alias for verified_by',
  `return_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Research outputs and publications from approved projects';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `project_progress_reports`
--

CREATE TABLE `project_progress_reports` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK to research_submissions (approved project)',
  `report_period` varchar(50) NOT NULL COMMENT 'e.g., Q1 2026, Semi-Annual 2026',
  `period_start_date` date NOT NULL,
  `period_end_date` date NOT NULL,
  `activities_conducted` text NOT NULL COMMENT 'Activities conducted during period',
  `accomplishments` text DEFAULT NULL COMMENT 'Key accomplishments',
  `milestones_achieved` text DEFAULT NULL COMMENT 'Milestones reached',
  `challenges_encountered` text DEFAULT NULL COMMENT 'Challenges and issues',
  `remedial_actions` text DEFAULT NULL COMMENT 'Actions taken to address challenges',
  `completion_percentage` int(11) DEFAULT 0 COMMENT '0-100 progress percentage',
  `is_on_track` tinyint(1) DEFAULT 1 COMMENT '1 if project is on track',
  `deviation_remarks` text DEFAULT NULL COMMENT 'Remarks if not on track',
  `budget_utilized` decimal(15,2) DEFAULT NULL,
  `budget_remaining` decimal(15,2) DEFAULT NULL,
  `financial_remarks` text DEFAULT NULL,
  `next_period_plans` text DEFAULT NULL,
  `assistance_needed` text DEFAULT NULL,
  `status` enum('draft','submitted','under_coordinator_review','returned_for_revision','endorsed','under_ro_review','approved','rejected','reviewed','accepted','returned') DEFAULT 'draft',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `submitted_by` int(11) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `coordinator_reviewed_by` int(11) DEFAULT NULL COMMENT 'Coordinator who reviewed',
  `coordinator_reviewed_at` datetime DEFAULT NULL,
  `coordinator_remarks` text DEFAULT NULL,
  `endorsed_at` datetime DEFAULT NULL,
  `ro_reviewed_by` int(11) DEFAULT NULL COMMENT 'RO admin who made final decision',
  `ro_reviewed_at` datetime DEFAULT NULL,
  `ro_remarks` text DEFAULT NULL,
  `return_reason` text DEFAULT NULL COMMENT 'Reason for return to researcher',
  `revision_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Progress reports for on-going research projects';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `researcher_profile_access_logs`
--

CREATE TABLE `researcher_profile_access_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `employee_id` varchar(100) DEFAULT NULL,
  `researcher_category` enum('faculty','student','personnel') NOT NULL,
  `researcher_id` int(11) NOT NULL,
  `access_granted` tinyint(1) NOT NULL,
  `access_level` varchar(50) DEFAULT NULL,
  `error_code` varchar(50) DEFAULT NULL,
  `scope_context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`scope_context`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `accessed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Immutable audit log for researcher profile access';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `research_office_admins`
--

CREATE TABLE `research_office_admins` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `employee_id` varchar(100) DEFAULT NULL,
  `admin_role` enum('director','assistant_director','admin') NOT NULL DEFAULT 'admin',
  `can_approve` tinyint(1) DEFAULT 1 COMMENT '1 if can make final decisions',
  `can_assign_references` tinyint(1) DEFAULT 1 COMMENT '1 if can assign control numbers',
  `can_generate_reports` tinyint(1) DEFAULT 1,
  `assigned_by` int(11) NOT NULL,
  `assigned_at` timestamp NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Research Office administrative roles';

-- --------------------------------------------------------

--
-- Table structure for table `research_outputs`
--

CREATE TABLE `research_outputs` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `project_leader` varchar(150) DEFAULT NULL,
  `project_start` date DEFAULT NULL,
  `project_end` date DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `status` enum('on-going','completed','published') DEFAULT 'on-going',
  `parent_project_id` int(11) DEFAULT NULL COMMENT 'References parent research',
  `is_project_leader` tinyint(1) DEFAULT 1 COMMENT '1 = leader, 0 = member',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `research_submissions`
--

CREATE TABLE `research_submissions` (
  `id` int(11) NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL COMMENT 'Official reference number assigned by RO',
  `project_code` varchar(100) DEFAULT NULL COMMENT 'Immutable project code for RMIS tracking',
  `submission_type_id` int(11) NOT NULL,
  `parent_project_id` int(11) DEFAULT NULL COMMENT 'References the parent approved project for project-based submissions',
  `researcher_type` enum('faculty','student','personnel') NOT NULL,
  `researcher_id` int(11) NOT NULL COMMENT 'ID in faculty_researchers, student_researchers, or personnel_researchers',
  `researcher_user_id` int(11) DEFAULT NULL COMMENT 'User ID if researcher has login',
  `researcher_unit_id` varchar(100) DEFAULT NULL COMMENT 'HR unit ID for routing',
  `researcher_unit_name` varchar(255) DEFAULT NULL COMMENT 'Cached unit name',
  `title` varchar(500) NOT NULL,
  `abstract` text DEFAULT NULL,
  `objectives` text DEFAULT NULL,
  `methodology` text DEFAULT NULL,
  `expected_outcomes` text DEFAULT NULL,
  `proposed_start_date` date DEFAULT NULL,
  `proposed_end_date` date DEFAULT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `current_end_date` date DEFAULT NULL COMMENT 'Current end date (updated after extensions)',
  `total_budget` decimal(15,2) DEFAULT NULL,
  `budget_breakdown` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Detailed budget items as JSON' CHECK (json_valid(`budget_breakdown`)),
  `research_program` varchar(255) DEFAULT NULL,
  `funding_source` varchar(255) DEFAULT NULL,
  `fiscal_year` varchar(20) DEFAULT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Category tags as JSON array' CHECK (json_valid(`tags`)),
  `status` enum('draft','submitted','under_coordinator_review','returned_for_revision','endorsed','under_ro_review','approved','rejected') NOT NULL DEFAULT 'draft',
  `project_status` enum('not_started','on_going','extended','completed','terminated') DEFAULT NULL COMMENT 'Project lifecycle status after approval',
  `current_handler_type` enum('researcher','coordinator','research_office') DEFAULT 'researcher',
  `current_handler_id` int(11) DEFAULT NULL COMMENT 'User ID of current handler',
  `assigned_coordinator_id` int(11) DEFAULT NULL COMMENT 'Coordinator assigned to review',
  `assigned_coordinator_employee_id` varchar(100) DEFAULT NULL,
  `assigned_ro_admin_id` int(11) DEFAULT NULL COMMENT 'RO Admin handling the submission',
  `submitted_at` datetime DEFAULT NULL,
  `coordinator_received_at` datetime DEFAULT NULL,
  `coordinator_endorsed_at` datetime DEFAULT NULL,
  `ro_received_at` datetime DEFAULT NULL,
  `decision_at` datetime DEFAULT NULL,
  `elevated_to_project_at` datetime DEFAULT NULL COMMENT 'Timestamp when proposal was elevated to active project',
  `completed_at` datetime DEFAULT NULL COMMENT 'Timestamp when project was marked as completed',
  `is_proposal_locked` tinyint(1) DEFAULT 0 COMMENT '1 if core proposal fields are locked after approval',
  `rmis_form_mapping` enum('D1','D') DEFAULT NULL COMMENT 'RMIS Form mapping: D1=On-Going, D=Completed',
  `extension_count` int(11) DEFAULT 0 COMMENT 'Number of approved extensions',
  `revision_count` int(11) DEFAULT 0,
  `last_revision_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `submitted_by_coordinator` tinyint(1) DEFAULT 0 COMMENT 'Flag: 1 if submitted by a coordinator',
  `submitter_coordinator_id` int(11) DEFAULT NULL COMMENT 'User ID of coordinator who submitted (if applicable)',
  `submitter_coordinator_employee_id` varchar(100) DEFAULT NULL COMMENT 'Employee ID of submitting coordinator',
  `coordinator_submission_routing` enum('peer_coordinator','escalated_to_ro') DEFAULT NULL COMMENT 'Routing decision for coordinator submissions',
  `peer_coordinator_unavailable_reason` varchar(500) DEFAULT NULL COMMENT 'Reason if escalated to RO (e.g., no peer coordinator in unit)',
  `excluded_coordinator_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Coordinator IDs excluded from review (the submitter)' CHECK (json_valid(`excluded_coordinator_ids`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Main research submissions with workflow status';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `research_submission_types`
--

CREATE TABLE `research_submission_types` (
  `id` int(11) NOT NULL,
  `type_code` varchar(50) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `requires_ethics_clearance` tinyint(1) DEFAULT 0,
  `requires_budget` tinyint(1) DEFAULT 0,
  `requires_timeline` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Types of research submissions';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `rmis_report_generations`
--

CREATE TABLE `rmis_report_generations` (
  `id` int(11) NOT NULL,
  `report_type` varchar(20) NOT NULL COMMENT 'Form type: A, B, C, D, D1, E',
  `fiscal_year` varchar(20) NOT NULL,
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Filter parameters used' CHECK (json_valid(`parameters`)),
  `record_count` int(11) DEFAULT 0,
  `generated_by` int(11) NOT NULL,
  `generated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='RMIS report generation history';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `student_researchers`
--

CREATE TABLE `student_researchers` (
  `id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `research_adviser` varchar(150) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL COMMENT 'References users.id',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `student_research_costs`
--

CREATE TABLE `student_research_costs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `item_of_expenditure` varchar(255) NOT NULL,
  `institution_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund` decimal(15,2) DEFAULT 0.00,
  `government_fund_source` varchar(255) DEFAULT NULL,
  `private_fund` decimal(15,2) DEFAULT 0.00,
  `private_fund_source` varchar(255) DEFAULT NULL,
  `foreign_fund` decimal(15,2) DEFAULT 0.00,
  `foreign_fund_source` varchar(255) DEFAULT NULL,
  `other_sources` decimal(15,2) DEFAULT 0.00,
  `other_sources_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_outputs`
--

CREATE TABLE `student_research_outputs` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `output_title` varchar(500) NOT NULL,
  `output_type` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `output_status` enum('pending','accepted','needs_revision','rejected') DEFAULT 'pending',
  `version` int(11) DEFAULT 1,
  `is_latest_version` tinyint(1) DEFAULT 1,
  `uploaded_by` int(11) NOT NULL COMMENT 'References student_researchers.id',
  `upload_date` datetime DEFAULT current_timestamp(),
  `reviewer_id` int(11) DEFAULT NULL,
  `review_date` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `parent_output_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_research_team`
--

CREATE TABLE `student_research_team` (
  `id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `course_year_section` varchar(50) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL COMMENT 'e.g., Co-Researcher, Research Assistant',
  `department` varchar(150) DEFAULT NULL,
  `contribution` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `submission_attachments`
--

CREATE TABLE `submission_attachments` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `attachment_type` enum('proposal_document','ethics_clearance','budget_plan','timeline_gantt','endorsement_letter','progress_report','final_report','publication','supporting_document','other') NOT NULL DEFAULT 'supporting_document',
  `description` text DEFAULT NULL,
  `uploaded_by` int(11) NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT current_timestamp(),
  `is_required` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='File attachments for submissions';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `submission_comments`
--

CREATE TABLE `submission_comments` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `comment_type` enum('general','validation_note','revision_request','endorsement_note','approval_note','rejection_reason','internal_note') NOT NULL DEFAULT 'general',
  `comment_text` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0 COMMENT '1 if only visible to coordinators/admins',
  `created_by` int(11) NOT NULL,
  `created_by_role` varchar(50) NOT NULL,
  `created_by_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `visible_to_researcher` tinyint(1) DEFAULT 1,
  `visible_to_coordinator` tinyint(1) DEFAULT 1,
  `visible_to_ro` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Comments and notes on submissions';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `synced_research_coordinators`
--

CREATE TABLE `synced_research_coordinators` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `full_name` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `position_name` varchar(255) DEFAULT '',
  `unit_name` varchar(255) DEFAULT '',
  `unit_type` varchar(50) DEFAULT '',
  `sector_name` varchar(255) DEFAULT '',
  `hr_status` enum('active','position_changed','inactive') DEFAULT 'active',
  `synced_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
--


-- --------------------------------------------------------

--
-- Table structure for table `unified_queue_audit_log`
--

CREATE TABLE `unified_queue_audit_log` (
  `id` int(11) NOT NULL,
  `item_type` enum('proposal','progress','extension','output','completion','collaboration') NOT NULL,
  `source_table` varchar(100) NOT NULL,
  `source_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `previous_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) NOT NULL,
  `action_type` enum('submitted','coordinator_review_started','returned_for_revision','revision_submitted','endorsed','ro_review_started','approved','rejected','returned_to_coordinator') NOT NULL,
  `performed_by` int(11) NOT NULL,
  `performed_by_role` enum('researcher','coordinator','research_office','admin') NOT NULL,
  `performed_by_name` varchar(255) DEFAULT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `target_role` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `validation_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`validation_data`)),
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Unified audit log for Work Queue workflow actions';

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fullname` varchar(155) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `oauth_sub` varchar(255) DEFAULT NULL,
  `oauth_client_role` varchar(20) DEFAULT NULL,
  `last_oauth_login_at` timestamp NULL DEFAULT NULL,
  `user_role` varchar(50) DEFAULT NULL,
  `coordinator_type` enum('faculty','student','personnel') DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `employee_id` varchar(100) DEFAULT NULL,
  `parent_unit` varchar(255) DEFAULT NULL,
  `imported` tinyint(1) DEFAULT 0 COMMENT '1 if imported as researcher, 0 otherwise',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_research_office` tinyint(1) DEFAULT 0 COMMENT '1 if user is Research Office staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Default admin user (username: admin, password: admin)
--

INSERT INTO `users` (`id`, `username`, `fullname`, `email`, `password`, `user_role`, `created_at`) VALUES
(1, 'admin', 'System Administrator', 'admin@localhost', '$2y$10$HfzIhGCCaxqyaIdGgjARSuOKAcm1Uy82YfLuNaajn6JrjLWy9Sj/W', 'admin', CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_history`
--

CREATE TABLE `workflow_history` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `action_type` enum('created','submitted','assigned_coordinator','coordinator_review_started','validated','returned_for_revision','revision_submitted','endorsed','assigned_ro_admin','ro_review_started','classification_assigned','approved','rejected','returned_to_coordinator','reference_assigned','comment_added','attachment_added','attachment_removed','elevated_to_project','project_code_assigned','progress_report_submitted','progress_report_reviewed','progress_report_endorsed','progress_report_approved','progress_report_rejected','progress_report_returned','progress_report_resubmitted','progress_report_review_started','extension_requested','extension_approved','extension_rejected','extension_review_started','extension_endorsed','extension_returned','extension_resubmitted','extension_ro_review_started','extension_returned_to_coordinator','completion_submitted','completion_approved','completion_rejected','completion_review_started','completion_endorsed','completion_returned','completion_resubmitted','completion_report_created','completion_report_endorsed','completion_report_returned','completion_report_rejected','completion_report_resubmitted','project_completed','output_reported','output_verified','output_rejected','output_endorsed','output_returned','output_submitted','field_change_requested','field_change_approved','field_change_rejected','collaboration_created','collaboration_submitted','collaboration_endorsed','collaboration_approved','collaboration_rejected','collaboration_record_logged','collaboration_review_started','collaboration_returned') NOT NULL,
  `previous_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `performed_by` int(11) NOT NULL COMMENT 'User ID who performed action',
  `performed_by_role` varchar(50) NOT NULL COMMENT 'Role at time of action',
  `performed_by_name` varchar(255) DEFAULT NULL COMMENT 'Cached name for display',
  `target_user_id` int(11) DEFAULT NULL,
  `target_role` varchar(50) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `return_reason` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Additional action-specific data' CHECK (json_valid(`metadata`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Immutable workflow audit trail';

--
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_settings`
--

CREATE TABLE `workflow_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','integer','boolean','json') DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Workflow configuration settings';

--
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_table_affected` (`table_affected`);

--
-- Indexes for table `collaboration_audit_log`
--
ALTER TABLE `collaboration_audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_collaboration` (`collaboration_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_performed_by` (`performed_by`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `collaboration_comments`
--
ALTER TABLE `collaboration_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_collaboration` (`collaboration_id`),
  ADD KEY `idx_type` (`comment_type`),
  ADD KEY `idx_created_by` (`created_by`);

--
-- Indexes for table `collaboration_endorsement_summary`
--
ALTER TABLE `collaboration_endorsement_summary`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `collaboration_id` (`collaboration_id`),
  ADD KEY `idx_coordinator` (`coordinator_id`);

--
-- Indexes for table `collaboration_types`
--
ALTER TABLE `collaboration_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type_code` (`type_code`),
  ADD KEY `idx_category` (`category`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_employee_coordinator` (`employee_id`,`coordinator_type`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_coordinator_type` (`coordinator_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `fk_coordinator_assigned_by` (`assigned_by`),
  ADD KEY `idx_ca_employee` (`employee_id`),
  ADD KEY `idx_ca_status` (`status`),
  ADD KEY `idx_ca_type_status` (`coordinator_type`,`status`);

--
-- Indexes for table `coordinator_assignment_logs`
--
ALTER TABLE `coordinator_assignment_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_performed_at` (`performed_at`);

--
-- Indexes for table `coordinator_endorsement_summary`
--
ALTER TABLE `coordinator_endorsement_summary`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `submission_id` (`submission_id`),
  ADD KEY `idx_coordinator` (`coordinator_id`);

--
-- Indexes for table `coordinator_scopes`
--
ALTER TABLE `coordinator_scopes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_employee_unit` (`employee_id`,`unit_id`),
  ADD KEY `idx_employee_id` (`employee_id`);

--
-- Indexes for table `coordinator_submission_flag`
--
ALTER TABLE `coordinator_submission_flag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_item` (`item_type`,`source_id`),
  ADD KEY `idx_submitter` (`submitter_user_id`);

--
-- Indexes for table `coordinator_submission_routing_log`
--
ALTER TABLE `coordinator_submission_routing_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_submission` (`submission_id`),
  ADD KEY `idx_submitter` (`submitter_user_id`),
  ADD KEY `idx_routing` (`routing_decision`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_faculty_education` (`faculty_id`);

--
-- Indexes for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_faculty_projects` (`faculty_id`),
  ADD KEY `idx_fp_faculty_id` (`faculty_id`),
  ADD KEY `idx_fp_status` (`project_status`),
  ADD KEY `idx_fp_title` (`title`(191));
ALTER TABLE `faculty_projects` ADD FULLTEXT KEY `ft_fp_title` (`title`);

--
-- Indexes for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_costs` (`project_id`);

--
-- Indexes for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_team` (`project_id`);

--
-- Indexes for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faculty_number` (`faculty_number`),
  ADD UNIQUE KEY `unique_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_is_synced` (`is_synced`),
  ADD KEY `idx_last_synced` (`last_synced_at`),
  ADD KEY `idx_fr_faculty_number` (`faculty_number`),
  ADD KEY `idx_fr_last_name` (`last_name`),
  ADD KEY `idx_fr_email` (`email`),
  ADD KEY `idx_fr_hr_employee_id` (`hr_employee_id`),
  ADD KEY `idx_fr_home_unit` (`home_unit`),
  ADD KEY `idx_fr_department` (`department`),
  ADD KEY `idx_fr_created_by` (`created_by`),
  ADD KEY `idx_fr_name` (`last_name`,`first_name`);
ALTER TABLE `faculty_researchers` ADD FULLTEXT KEY `ft_fr_names` (`first_name`,`last_name`,`middle_name`);
ALTER TABLE `faculty_researchers` ADD FULLTEXT KEY `ft_fr_search` (`first_name`,`last_name`,`faculty_rank`,`home_unit`,`email`);

--
-- Indexes for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_latest` (`project_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_faculty_output_uploader` (`uploaded_by`),
  ADD KEY `fk_faculty_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_faculty_output_parent` (`parent_output_id`);

--
-- Indexes for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_faculty` (`faculty_id`),
  ADD KEY `idx_synced_at` (`synced_at`);

--
-- Indexes for table `oauth_settings`
--
ALTER TABLE `oauth_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_token` (`user_id`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `personnel_education`
--
ALTER TABLE `personnel_education`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_personnel_id` (`personnel_id`);

--
-- Indexes for table `personnel_projects`
--
ALTER TABLE `personnel_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_personnel_id` (`personnel_id`),
  ADD KEY `idx_parent_project` (`parent_project_id`);

--
-- Indexes for table `personnel_project_costs`
--
ALTER TABLE `personnel_project_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_id` (`project_id`);

--
-- Indexes for table `personnel_project_team`
--
ALTER TABLE `personnel_project_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_id` (`project_id`);

--
-- Indexes for table `personnel_researchers`
--
ALTER TABLE `personnel_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_hr_employee_id` (`hr_employee_id`),
  ADD UNIQUE KEY `uk_employee_number` (`employee_number`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_office_unit` (`office_unit`),
  ADD KEY `idx_department` (`department`),
  ADD KEY `idx_is_synced` (`is_synced`);

--
-- Indexes for table `personnel_research_outputs`
--
ALTER TABLE `personnel_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project_latest` (`project_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `reviewer_id` (`reviewer_id`),
  ADD KEY `parent_output_id` (`parent_output_id`);

--
-- Indexes for table `project_action_logs`
--
ALTER TABLE `project_action_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_project_id` (`project_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_user_project` (`user_id`,`project_id`);

--
-- Indexes for table `project_collaborations`
--
ALTER TABLE `project_collaborations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_researcher` (`researcher_type`,`researcher_id`),
  ADD KEY `idx_researcher_user` (`researcher_user_id`),
  ADD KEY `idx_type` (`collaboration_type_id`),
  ADD KEY `idx_category` (`collaboration_category`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_record_status` (`record_status`),
  ADD KEY `idx_queue_item` (`is_queue_item`),
  ADD KEY `idx_current_handler` (`current_handler_type`,`current_handler_id`),
  ADD KEY `idx_partner_type` (`partner_type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_researcher_unit` (`researcher_unit_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `assigned_coordinator_id` (`assigned_coordinator_id`),
  ADD KEY `assigned_ro_admin_id` (`assigned_ro_admin_id`);

--
-- Indexes for table `project_completion_reports`
--
ALTER TABLE `project_completion_reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_id` (`project_id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_submitted_by` (`submitted_by`),
  ADD KEY `coordinator_reviewed_by` (`coordinator_reviewed_by`),
  ADD KEY `ro_reviewed_by` (`ro_reviewed_by`),
  ADD KEY `idx_comp_queue` (`status`,`submitted_at`);

--
-- Indexes for table `project_extensions`
--
ALTER TABLE `project_extensions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_type` (`extension_type`),
  ADD KEY `idx_requested_by` (`requested_by`),
  ADD KEY `coordinator_reviewed_by` (`coordinator_reviewed_by`),
  ADD KEY `ro_reviewed_by` (`ro_reviewed_by`),
  ADD KEY `idx_ext_queue` (`status`,`requested_at`);

--
-- Indexes for table `project_field_change_requests`
--
ALTER TABLE `project_field_change_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `requested_by` (`requested_by`),
  ADD KEY `reviewed_by` (`reviewed_by`);

--
-- Indexes for table `project_lifecycle_log`
--
ALTER TABLE `project_lifecycle_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_status` (`new_project_status`);

--
-- Indexes for table `project_outputs`
--
ALTER TABLE `project_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_type` (`output_type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_indexing` (`indexing_status`),
  ADD KEY `reported_by` (`reported_by`),
  ADD KEY `verified_by` (`verified_by`),
  ADD KEY `idx_output_queue` (`status`,`submitted_at`);

--
-- Indexes for table `project_progress_reports`
--
ALTER TABLE `project_progress_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_period` (`report_period`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_submitted_by` (`submitted_by`),
  ADD KEY `reviewed_by` (`reviewed_by`),
  ADD KEY `idx_ppr_queue` (`status`,`submitted_at`);

--
-- Indexes for table `researcher_profile_access_logs`
--
ALTER TABLE `researcher_profile_access_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_researcher` (`researcher_category`,`researcher_id`),
  ADD KEY `idx_accessed_at` (`accessed_at`),
  ADD KEY `idx_access_granted` (`access_granted`);

--
-- Indexes for table `research_office_admins`
--
ALTER TABLE `research_office_admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_user_admin` (`user_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `assigned_by` (`assigned_by`);

--
-- Indexes for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `fk_student_research` (`student_id`),
  ADD KEY `idx_ro_student_id` (`student_id`),
  ADD KEY `idx_ro_status` (`status`);

--
-- Indexes for table `research_submissions`
--
ALTER TABLE `research_submissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`),
  ADD UNIQUE KEY `project_code` (`project_code`),
  ADD KEY `idx_submission_type` (`submission_type_id`),
  ADD KEY `idx_researcher` (`researcher_type`,`researcher_id`),
  ADD KEY `idx_researcher_user` (`researcher_user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_current_handler` (`current_handler_type`,`current_handler_id`),
  ADD KEY `idx_assigned_coordinator` (`assigned_coordinator_id`),
  ADD KEY `idx_assigned_ro` (`assigned_ro_admin_id`),
  ADD KEY `idx_researcher_unit` (`researcher_unit_id`),
  ADD KEY `idx_fiscal_year` (`fiscal_year`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_project_status` (`project_status`),
  ADD KEY `idx_rmis_form` (`rmis_form_mapping`),
  ADD KEY `idx_rs_status` (`status`),
  ADD KEY `idx_rs_researcher` (`researcher_type`,`researcher_id`),
  ADD KEY `idx_rs_reference` (`reference_number`),
  ADD KEY `idx_rs_title` (`title`(191)),
  ADD KEY `idx_parent_project` (`parent_project_id`),
  ADD KEY `idx_submitted_by_coord` (`submitted_by_coordinator`),
  ADD KEY `idx_coord_routing` (`coordinator_submission_routing`),
  ADD KEY `idx_submitter_coord` (`submitter_coordinator_id`);
ALTER TABLE `research_submissions` ADD FULLTEXT KEY `ft_rs_title` (`title`);

--
-- Indexes for table `research_submission_types`
--
ALTER TABLE `research_submission_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type_code` (`type_code`);

--
-- Indexes for table `rmis_report_generations`
--
ALTER TABLE `rmis_report_generations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_report_type` (`report_type`),
  ADD KEY `idx_fiscal_year` (`fiscal_year`),
  ADD KEY `idx_generated_by` (`generated_by`),
  ADD KEY `idx_generated_at` (`generated_at`);

--
-- Indexes for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_student_created_by` (`created_by`),
  ADD KEY `idx_sr_student_number` (`student_number`),
  ADD KEY `idx_sr_last_name` (`last_name`),
  ADD KEY `idx_sr_department` (`department`),
  ADD KEY `idx_sr_created_by` (`created_by`),
  ADD KEY `idx_sr_name` (`last_name`,`first_name`);
ALTER TABLE `student_researchers` ADD FULLTEXT KEY `ft_sr_names` (`first_name`,`last_name`,`middle_name`);
ALTER TABLE `student_researchers` ADD FULLTEXT KEY `ft_sr_search` (`first_name`,`last_name`,`course_year_section`,`department`);

--
-- Indexes for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_costs` (`research_id`);

--
-- Indexes for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_latest` (`research_id`,`is_latest_version`),
  ADD KEY `idx_status` (`output_status`),
  ADD KEY `idx_version` (`version`),
  ADD KEY `fk_student_output_uploader` (`uploaded_by`),
  ADD KEY `fk_student_output_reviewer` (`reviewer_id`),
  ADD KEY `fk_student_output_parent` (`parent_output_id`);

--
-- Indexes for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_research_id` (`research_id`);

--
-- Indexes for table `submission_attachments`
--
ALTER TABLE `submission_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_submission` (`submission_id`),
  ADD KEY `idx_type` (`attachment_type`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `submission_comments`
--
ALTER TABLE `submission_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_submission` (`submission_id`),
  ADD KEY `idx_type` (`comment_type`),
  ADD KEY `idx_created_by` (`created_by`);

--
-- Indexes for table `synced_research_coordinators`
--
ALTER TABLE `synced_research_coordinators`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_employee_id` (`employee_id`);

--
-- Indexes for table `unified_queue_audit_log`
--
ALTER TABLE `unified_queue_audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_item` (`item_type`,`source_id`),
  ADD KEY `idx_project` (`project_id`),
  ADD KEY `idx_action` (`action_type`),
  ADD KEY `idx_status` (`new_status`),
  ADD KEY `idx_performed_by` (`performed_by`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_employee_id` (`employee_id`),
  ADD KEY `idx_users_oauth_sub` (`oauth_sub`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_parent_unit` (`parent_unit`),
  ADD KEY `idx_is_research_office` (`is_research_office`);

--
-- Indexes for table `workflow_history`
--
ALTER TABLE `workflow_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_submission` (`submission_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_performed_by` (`performed_by`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_status_change` (`previous_status`,`new_status`);

--
-- Indexes for table `workflow_settings`
--
ALTER TABLE `workflow_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`),
  ADD KEY `updated_by` (`updated_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1136;

--
-- AUTO_INCREMENT for table `collaboration_audit_log`
--
ALTER TABLE `collaboration_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `collaboration_comments`
--
ALTER TABLE `collaboration_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `collaboration_endorsement_summary`
--
ALTER TABLE `collaboration_endorsement_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `collaboration_types`
--
ALTER TABLE `collaboration_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `coordinator_assignment_logs`
--
ALTER TABLE `coordinator_assignment_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `coordinator_endorsement_summary`
--
ALTER TABLE `coordinator_endorsement_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `coordinator_scopes`
--
ALTER TABLE `coordinator_scopes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=503;

--
-- AUTO_INCREMENT for table `coordinator_submission_flag`
--
ALTER TABLE `coordinator_submission_flag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coordinator_submission_routing_log`
--
ALTER TABLE `coordinator_submission_routing_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faculty_education`
--
ALTER TABLE `faculty_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `oauth_settings`
--
ALTER TABLE `oauth_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `personnel_education`
--
ALTER TABLE `personnel_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personnel_projects`
--
ALTER TABLE `personnel_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personnel_project_costs`
--
ALTER TABLE `personnel_project_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personnel_project_team`
--
ALTER TABLE `personnel_project_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personnel_researchers`
--
ALTER TABLE `personnel_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `personnel_research_outputs`
--
ALTER TABLE `personnel_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_action_logs`
--
ALTER TABLE `project_action_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `project_collaborations`
--
ALTER TABLE `project_collaborations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `project_completion_reports`
--
ALTER TABLE `project_completion_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_extensions`
--
ALTER TABLE `project_extensions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `project_field_change_requests`
--
ALTER TABLE `project_field_change_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_lifecycle_log`
--
ALTER TABLE `project_lifecycle_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `project_outputs`
--
ALTER TABLE `project_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `project_progress_reports`
--
ALTER TABLE `project_progress_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `researcher_profile_access_logs`
--
ALTER TABLE `researcher_profile_access_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `research_office_admins`
--
ALTER TABLE `research_office_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `research_outputs`
--
ALTER TABLE `research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `research_submissions`
--
ALTER TABLE `research_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `research_submission_types`
--
ALTER TABLE `research_submission_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rmis_report_generations`
--
ALTER TABLE `rmis_report_generations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_researchers`
--
ALTER TABLE `student_researchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_research_team`
--
ALTER TABLE `student_research_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `submission_attachments`
--
ALTER TABLE `submission_attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `submission_comments`
--
ALTER TABLE `submission_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `synced_research_coordinators`
--
ALTER TABLE `synced_research_coordinators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `unified_queue_audit_log`
--
ALTER TABLE `unified_queue_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `workflow_history`
--
ALTER TABLE `workflow_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `workflow_settings`
--
ALTER TABLE `workflow_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `collaboration_audit_log`
--
ALTER TABLE `collaboration_audit_log`
  ADD CONSTRAINT `collaboration_audit_log_ibfk_1` FOREIGN KEY (`collaboration_id`) REFERENCES `project_collaborations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `collaboration_comments`
--
ALTER TABLE `collaboration_comments`
  ADD CONSTRAINT `collaboration_comments_ibfk_1` FOREIGN KEY (`collaboration_id`) REFERENCES `project_collaborations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `collaboration_comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `collaboration_endorsement_summary`
--
ALTER TABLE `collaboration_endorsement_summary`
  ADD CONSTRAINT `collaboration_endorsement_summary_ibfk_1` FOREIGN KEY (`collaboration_id`) REFERENCES `project_collaborations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `collaboration_endorsement_summary_ibfk_2` FOREIGN KEY (`coordinator_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `coordinator_assignments`
--
ALTER TABLE `coordinator_assignments`
  ADD CONSTRAINT `fk_coordinator_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `coordinator_endorsement_summary`
--
ALTER TABLE `coordinator_endorsement_summary`
  ADD CONSTRAINT `coordinator_endorsement_summary_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `coordinator_endorsement_summary_ibfk_2` FOREIGN KEY (`coordinator_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `coordinator_submission_routing_log`
--
ALTER TABLE `coordinator_submission_routing_log`
  ADD CONSTRAINT `coordinator_submission_routing_log_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `coordinator_submission_routing_log_ibfk_2` FOREIGN KEY (`submitter_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_education`
--
ALTER TABLE `faculty_education`
  ADD CONSTRAINT `fk_faculty_education` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_projects`
--
ALTER TABLE `faculty_projects`
  ADD CONSTRAINT `fk_faculty_projects` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_costs`
--
ALTER TABLE `faculty_project_costs`
  ADD CONSTRAINT `fk_project_costs` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_project_team`
--
ALTER TABLE `faculty_project_team`
  ADD CONSTRAINT `fk_project_team` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_researchers`
--
ALTER TABLE `faculty_researchers`
  ADD CONSTRAINT `fk_faculty_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculty_research_outputs`
--
ALTER TABLE `faculty_research_outputs`
  ADD CONSTRAINT `fk_faculty_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `faculty_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_faculty_output_project` FOREIGN KEY (`project_id`) REFERENCES `faculty_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_faculty_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_faculty_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `faculty_researchers` (`id`);

--
-- Constraints for table `hr_sync_history`
--
ALTER TABLE `hr_sync_history`
  ADD CONSTRAINT `hr_sync_history_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `oauth_tokens`
--
ALTER TABLE `oauth_tokens`
  ADD CONSTRAINT `oauth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personnel_education`
--
ALTER TABLE `personnel_education`
  ADD CONSTRAINT `personnel_education_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personnel_projects`
--
ALTER TABLE `personnel_projects`
  ADD CONSTRAINT `personnel_projects_ibfk_1` FOREIGN KEY (`personnel_id`) REFERENCES `personnel_researchers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `personnel_projects_ibfk_2` FOREIGN KEY (`parent_project_id`) REFERENCES `personnel_projects` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `personnel_project_costs`
--
ALTER TABLE `personnel_project_costs`
  ADD CONSTRAINT `personnel_project_costs_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `personnel_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personnel_project_team`
--
ALTER TABLE `personnel_project_team`
  ADD CONSTRAINT `personnel_project_team_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `personnel_projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personnel_researchers`
--
ALTER TABLE `personnel_researchers`
  ADD CONSTRAINT `personnel_researchers_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personnel_research_outputs`
--
ALTER TABLE `personnel_research_outputs`
  ADD CONSTRAINT `personnel_research_outputs_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `personnel_projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `personnel_research_outputs_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `personnel_researchers` (`id`),
  ADD CONSTRAINT `personnel_research_outputs_ibfk_3` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `personnel_research_outputs_ibfk_4` FOREIGN KEY (`parent_output_id`) REFERENCES `personnel_research_outputs` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_collaborations`
--
ALTER TABLE `project_collaborations`
  ADD CONSTRAINT `project_collaborations_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `project_collaborations_ibfk_2` FOREIGN KEY (`collaboration_type_id`) REFERENCES `collaboration_types` (`id`),
  ADD CONSTRAINT `project_collaborations_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_collaborations_ibfk_4` FOREIGN KEY (`assigned_coordinator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `project_collaborations_ibfk_5` FOREIGN KEY (`assigned_ro_admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_completion_reports`
--
ALTER TABLE `project_completion_reports`
  ADD CONSTRAINT `project_completion_reports_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_completion_reports_ibfk_2` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_completion_reports_ibfk_3` FOREIGN KEY (`coordinator_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `project_completion_reports_ibfk_4` FOREIGN KEY (`ro_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_extensions`
--
ALTER TABLE `project_extensions`
  ADD CONSTRAINT `project_extensions_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_extensions_ibfk_2` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_extensions_ibfk_3` FOREIGN KEY (`coordinator_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `project_extensions_ibfk_4` FOREIGN KEY (`ro_reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_field_change_requests`
--
ALTER TABLE `project_field_change_requests`
  ADD CONSTRAINT `project_field_change_requests_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_field_change_requests_ibfk_2` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_field_change_requests_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_lifecycle_log`
--
ALTER TABLE `project_lifecycle_log`
  ADD CONSTRAINT `project_lifecycle_log_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_outputs`
--
ALTER TABLE `project_outputs`
  ADD CONSTRAINT `project_outputs_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_outputs_ibfk_2` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_outputs_ibfk_3` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `project_progress_reports`
--
ALTER TABLE `project_progress_reports`
  ADD CONSTRAINT `project_progress_reports_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `project_progress_reports_ibfk_2` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_progress_reports_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `research_office_admins`
--
ALTER TABLE `research_office_admins`
  ADD CONSTRAINT `research_office_admins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `research_office_admins_ibfk_2` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `research_outputs`
--
ALTER TABLE `research_outputs`
  ADD CONSTRAINT `fk_parent_research` FOREIGN KEY (`parent_project_id`) REFERENCES `research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_research` FOREIGN KEY (`student_id`) REFERENCES `student_researchers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `research_submissions`
--
ALTER TABLE `research_submissions`
  ADD CONSTRAINT `research_submissions_ibfk_1` FOREIGN KEY (`submission_type_id`) REFERENCES `research_submission_types` (`id`),
  ADD CONSTRAINT `research_submissions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rmis_report_generations`
--
ALTER TABLE `rmis_report_generations`
  ADD CONSTRAINT `rmis_report_generations_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_researchers`
--
ALTER TABLE `student_researchers`
  ADD CONSTRAINT `fk_student_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_costs`
--
ALTER TABLE `student_research_costs`
  ADD CONSTRAINT `fk_research_costs` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_research_outputs`
--
ALTER TABLE `student_research_outputs`
  ADD CONSTRAINT `fk_student_output_parent` FOREIGN KEY (`parent_output_id`) REFERENCES `student_research_outputs` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_student_output_research` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_student_output_reviewer` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_student_output_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `student_researchers` (`id`);

--
-- Constraints for table `student_research_team`
--
ALTER TABLE `student_research_team`
  ADD CONSTRAINT `fk_research_team` FOREIGN KEY (`research_id`) REFERENCES `research_outputs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `submission_attachments`
--
ALTER TABLE `submission_attachments`
  ADD CONSTRAINT `submission_attachments_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submission_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `submission_comments`
--
ALTER TABLE `submission_comments`
  ADD CONSTRAINT `submission_comments_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `submission_comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `workflow_history`
--
ALTER TABLE `workflow_history`
  ADD CONSTRAINT `workflow_history_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `research_submissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `workflow_settings`
--
ALTER TABLE `workflow_settings`
  ADD CONSTRAINT `workflow_settings_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
