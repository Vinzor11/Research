<?php
/**
 * Project API
 * 
 * Handles all post-approval project operations:
 * - Progress reports
 * - Extension requests
 * - Completion reports
 * - Research outputs
 * - Field change requests
 * 
 * All operations require authentication.
 * 
 * AUDIT & COMPLIANCE:
 * All action attempts are logged including:
 * - User role
 * - Project status
 * - Timestamp
 * - Action taken or blocked
 * - Reason for blocking (if applicable)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

require_once 'db.php';
require_once 'ProjectService.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

// Initialize service
$projectService = new ProjectService($conn);
$workflowEngine = $projectService->getWorkflowEngine();

/**
 * Log project action attempt for audit & compliance
 * 
 * @param mysqli $conn Database connection
 * @param string $action The action attempted
 * @param int|null $projectId Project ID (if applicable)
 * @param string $status 'success', 'blocked', 'error'
 * @param string|null $reason Reason for blocking or error message
 * @param array|null $metadata Additional context data
 */
function logProjectAction($conn, $action, $projectId = null, $status = 'success', $reason = null, $metadata = null) {
    $userId = $_SESSION['user_id'] ?? null;
    $userRole = $_SESSION['user_role'] ?? null;
    $username = $_SESSION['username'] ?? null;
    
    // Get project status if project ID provided
    $projectStatus = null;
    if ($projectId) {
        $stmt = $conn->prepare("SELECT project_status, title FROM research_submissions WHERE id = ?");
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $projectStatus = $row['project_status'];
            if (!$metadata) $metadata = [];
            $metadata['project_title'] = $row['title'];
        }
        $stmt->close();
    }
    
    // Prepare metadata JSON
    $metadataJson = $metadata ? json_encode($metadata) : null;
    
    // Insert audit log
    $sql = "INSERT INTO project_action_logs 
            (user_id, user_role, username, project_id, project_status, action, status, reason, metadata, created_at, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
    
    $stmt = $conn->prepare($sql);
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
    $stmt->bind_param("issisissss", 
        $userId, 
        $userRole, 
        $username,
        $projectId, 
        $projectStatus, 
        $action, 
        $status, 
        $reason, 
        $metadataJson,
        $ipAddress
    );
    
    // Execute silently - don't fail the main operation if logging fails
    try {
        $stmt->execute();
    } catch (Exception $e) {
        error_log("Audit log failed: " . $e->getMessage());
    }
    $stmt->close();
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST;
}

$action = $input['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        // ========================================
        // PROJECT RETRIEVAL
        // ========================================
        
        case 'get_project':
            $projectId = $input['id'] ?? $_GET['id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $project = $projectService->getProject($projectId);
            if ($project) {
                echo json_encode(['success' => true, 'data' => $project]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Project not found']);
            }
            break;
            
        case 'get_projects':
            $filters = [
                'project_status' => $input['project_status'] ?? null,
                'search' => $input['search'] ?? null
            ];
            $page = $input['page'] ?? 1;
            $perPage = $input['per_page'] ?? 15;
            $projects = $projectService->getResearcherProjects($filters, $page, $perPage);
            echo json_encode(['success' => true, 'data' => $projects]);
            break;
            
        // ========================================
        // PROGRESS REPORTS
        // ========================================
        
        case 'create_progress_report':
            $projectId = $input['project_id'] ?? null;
            if (!$projectId) {
                logProjectAction($conn, 'create_progress_report', null, 'error', 'Project ID required');
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            
            // Check eligibility before attempting
            $project = $projectService->getProject($projectId);
            if ($project) {
                $eligibility = $workflowEngine->checkProgressReportEligibility($project);
                if (!$eligibility['allowed']) {
                    logProjectAction($conn, 'create_progress_report', $projectId, 'blocked', $eligibility['reason']);
                    echo json_encode(['success' => false, 'error' => $eligibility['reason']]);
                    exit;
                }
            }
            
            $result = $projectService->createProgressReport($projectId, $input);
            
            // Log success or failure
            if ($result['success']) {
                logProjectAction($conn, 'create_progress_report', $projectId, 'success', null, [
                    'report_id' => $result['report_id'] ?? null,
                    'report_period' => $input['report_period'] ?? null
                ]);
            } else {
                logProjectAction($conn, 'create_progress_report', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'update_progress_report':
            // TODO: Implement update for draft reports
            echo json_encode(['success' => false, 'error' => 'Not implemented']);
            break;
            
        case 'submit_progress_report':
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->submitProgressReport($reportId);
            echo json_encode($result);
            break;
            
        case 'review_progress_report':
            $reportId = $input['report_id'] ?? null;
            $decision = $input['decision'] ?? null;
            $comments = $input['comments'] ?? null;
            
            if (!$reportId || !$decision) {
                logProjectAction($conn, 'review_progress_report', null, 'error', 'Report ID and decision required');
                echo json_encode(['success' => false, 'error' => 'Report ID and decision required']);
                exit;
            }
            
            // Get project ID from report for logging
            $reportData = $projectService->getProgressReport($reportId);
            $projectId = $reportData['submission_id'] ?? null;
            
            $result = $projectService->reviewProgressReport($reportId, $decision, $comments);
            
            // Log the review action
            if ($result['success']) {
                logProjectAction($conn, 'review_progress_report', $projectId, 'success', null, [
                    'report_id' => $reportId,
                    'decision' => $decision
                ]);
            } else {
                logProjectAction($conn, 'review_progress_report', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'get_progress_reports':
            $projectId = $input['project_id'] ?? $_GET['project_id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $status = $input['status'] ?? $_GET['status'] ?? null;
            $reports = $projectService->getProgressReports($projectId, $status);
            echo json_encode(['success' => true, 'data' => $reports]);
            break;
            
        case 'get_progress_report':
            $reportId = $input['report_id'] ?? $_GET['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $report = $projectService->getProgressReport($reportId);
            if ($report) {
                echo json_encode(['success' => true, 'data' => $report]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Report not found']);
            }
            break;
            
        // ========================================
        // EXTENSION REQUESTS
        // ========================================
        
        case 'create_extension':
            $projectId = $input['project_id'] ?? null;
            if (!$projectId) {
                logProjectAction($conn, 'create_extension', null, 'error', 'Project ID required');
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            
            // Check eligibility before attempting
            $project = $projectService->getProject($projectId);
            if ($project) {
                $eligibility = $workflowEngine->checkExtensionEligibility($project);
                if (!$eligibility['allowed']) {
                    logProjectAction($conn, 'create_extension', $projectId, 'blocked', $eligibility['reason'], [
                        'extension_type' => $input['extension_type'] ?? null
                    ]);
                    echo json_encode(['success' => false, 'error' => $eligibility['reason']]);
                    exit;
                }
            }
            
            $result = $projectService->createExtensionRequest($projectId, $input);
            
            // Log success or failure
            if ($result['success']) {
                logProjectAction($conn, 'create_extension', $projectId, 'success', null, [
                    'extension_id' => $result['extension_id'] ?? null,
                    'extension_type' => $input['extension_type'] ?? null,
                    'requested_end_date' => $input['requested_end_date'] ?? null,
                    'urgency' => $eligibility['urgency'] ?? null
                ]);
                
                // Auto-submit if requested (frontend sends submit: true)
                if (!empty($input['submit']) && !empty($result['extension_id'])) {
                    $submitResult = $projectService->submitExtensionRequest($result['extension_id']);
                    if ($submitResult['success']) {
                        $result['message'] = 'Extension request submitted successfully';
                        $result['status'] = 'submitted';
                    } else {
                        // Extension created but submission failed - include both results
                        $result['submit_error'] = $submitResult['error'] ?? 'Failed to submit';
                    }
                }
            } else {
                logProjectAction($conn, 'create_extension', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'submit_extension':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $result = $projectService->submitExtensionRequest($extensionId);
            echo json_encode($result);
            break;
            
        case 'approve_extension':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                logProjectAction($conn, 'approve_extension', null, 'error', 'Extension ID required');
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            
            // Get project ID from extension for logging
            $extensionData = $projectService->getExtensionRequest($extensionId);
            $projectId = $extensionData['project_id'] ?? null;
            
            // Support both old format (direct fields) and new format (approval_data object)
            $approvalData = $input['approval_data'] ?? [
                'approved_end_date' => $input['approved_end_date'] ?? null,
                'approved_additional_budget' => $input['approved_additional_budget'] ?? null,
                'conditions' => $input['conditions'] ?? null
            ];
            $remarks = $input['remarks'] ?? $input['notes'] ?? null;
            $result = $projectService->approveExtensionRequest($extensionId, $approvalData, $remarks);
            
            // Log the approval action
            if ($result['success']) {
                logProjectAction($conn, 'approve_extension', $projectId, 'success', null, [
                    'extension_id' => $extensionId,
                    'approved_end_date' => $approvalData['approved_end_date'] ?? null,
                    'approved_budget' => $approvalData['approved_additional_budget'] ?? null
                ]);
            } else {
                logProjectAction($conn, 'approve_extension', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'reject_extension':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $reason = $input['reason'] ?? null;
            $result = $projectService->rejectExtensionRequest($extensionId, $reason);
            
            if ($result['success']) {
                $extensionData = $projectService->getExtensionRequest($extensionId);
                logProjectAction($conn, 'reject_extension', $extensionData['project_id'] ?? null, 'success', null, [
                    'extension_id' => $extensionId,
                    'reason' => $reason
                ]);
            }
            
            echo json_encode($result);
            break;
        
        // ========================================
        // PROGRESS REPORT COORDINATOR WORKFLOW
        // ========================================
        
        case 'start_progress_review':
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->startProgressReportReview($reportId);
            echo json_encode($result);
            break;
        
        case 'endorse_progress_report':
            // Coordinator endorses and forwards to Research Office
            $reportId = $input['report_id'] ?? null;
            $validationData = $input['validation_data'] ?? [];
            $remarks = $input['remarks'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->endorseProgressReport($reportId, $validationData, $remarks);
            echo json_encode($result);
            break;
        
        case 'return_progress_report':
            // Coordinator returns to researcher for revision
            $reportId = $input['report_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason required']);
                exit;
            }
            $result = $projectService->returnProgressReport($reportId, $reason);
            echo json_encode($result);
            break;
        
        case 'start_ro_progress_review':
            // RO starts reviewing (endorsed → under_ro_review)
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->startROProgressReview($reportId);
            echo json_encode($result);
            break;
        
        case 'approve_progress_report':
            // RO approves progress report
            $reportId = $input['report_id'] ?? null;
            $remarks = $input['remarks'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->approveProgressReport($reportId, $remarks);
            echo json_encode($result);
            break;
        
        case 'reject_progress_report':
            // RO rejects progress report
            $reportId = $input['report_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Rejection reason required']);
                exit;
            }
            $result = $projectService->rejectProgressReport($reportId, $reason);
            echo json_encode($result);
            break;
        
        case 'start_completion_review':
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->startCompletionReview($reportId);
            echo json_encode($result);
            break;
        
        // ========================================
        // EXTENSION COORDINATOR WORKFLOW
        // ========================================
        
        case 'start_extension_review':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $result = $projectService->startExtensionReview($extensionId);
            echo json_encode($result);
            break;
        
        case 'return_extension':
            $extensionId = $input['extension_id'] ?? null;
            $reason = $input['reason'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason required']);
                exit;
            }
            $result = $projectService->returnExtensionForRevision($extensionId, $reason);
            echo json_encode($result);
            break;
        
        case 'endorse_extension':
            $extensionId = $input['extension_id'] ?? null;
            $validationData = $input['validation_data'] ?? [];
            $remarks = $input['remarks'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $result = $projectService->endorseExtension($extensionId, $validationData, $remarks);
            echo json_encode($result);
            break;
        
        // ========================================
        // EXTENSION RO WORKFLOW
        // ========================================
        
        case 'start_ro_extension_review':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $result = $projectService->startROExtensionReview($extensionId);
            echo json_encode($result);
            break;
        
        case 'return_extension_to_coordinator':
            $extensionId = $input['extension_id'] ?? null;
            $reason = $input['reason'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason required']);
                exit;
            }
            $result = $projectService->returnExtensionToCoordinator($extensionId, $reason);
            echo json_encode($result);
            break;
        
        case 'resubmit_extension':
            $extensionId = $input['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $updatedData = [
                'justification' => $input['justification'] ?? null,
                'requested_end_date' => $input['requested_end_date'] ?? null,
                'requested_additional_budget' => $input['requested_additional_budget'] ?? null
            ];
            $result = $projectService->resubmitExtension($extensionId, $updatedData);
            echo json_encode($result);
            break;
            
        case 'get_extensions':
            $projectId = $input['project_id'] ?? $_GET['project_id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $extensions = $projectService->getExtensions($projectId);
            echo json_encode(['success' => true, 'data' => $extensions]);
            break;
            
        case 'get_extension':
            $extensionId = $input['extension_id'] ?? $_GET['extension_id'] ?? null;
            if (!$extensionId) {
                echo json_encode(['success' => false, 'error' => 'Extension ID required']);
                exit;
            }
            $extension = $projectService->getExtensionRequest($extensionId);
            if ($extension) {
                echo json_encode(['success' => true, 'data' => $extension]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Extension not found']);
            }
            break;
            
        // ========================================
        // COMPLETION REPORTS
        // ========================================
        
        case 'create_completion':
        case 'create_completion_report':
            $projectId = $input['project_id'] ?? null;
            if (!$projectId) {
                logProjectAction($conn, 'create_completion', null, 'error', 'Project ID required');
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            
            // Check eligibility before attempting
            $project = $projectService->getProject($projectId);
            if ($project) {
                $eligibility = $workflowEngine->checkCompletionEligibility($project);
                if (!$eligibility['allowed']) {
                    logProjectAction($conn, 'create_completion', $projectId, 'blocked', $eligibility['reason']);
                    echo json_encode(['success' => false, 'error' => $eligibility['reason']]);
                    exit;
                }
            }
            
            $result = $projectService->createCompletionReport($projectId, $input);
            
            // Log success or failure
            if ($result['success']) {
                logProjectAction($conn, 'create_completion', $projectId, 'success', null, [
                    'report_id' => $result['report_id'] ?? null,
                    'completion_date' => $input['actual_completion_date'] ?? null
                ]);
            } else {
                logProjectAction($conn, 'create_completion', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'submit_completion':
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->submitCompletionReport($reportId);
            echo json_encode($result);
            break;
        
        // ========================================
        // COMPLETION REPORT COORDINATOR WORKFLOW
        // ========================================
        
        case 'start_completion_review':
            // Coordinator starts reviewing (submitted → under_coordinator_review)
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->startCompletionReview($reportId);
            echo json_encode($result);
            break;
        
        case 'endorse_completion':
            // Coordinator endorses and forwards to Research Office
            $reportId = $input['report_id'] ?? null;
            $validationData = $input['validation_data'] ?? [];
            $remarks = $input['remarks'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->endorseCompletionReport($reportId, $validationData, $remarks);
            echo json_encode($result);
            break;
        
        case 'return_completion':
            // Coordinator returns to researcher for revision
            $reportId = $input['report_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason required']);
                exit;
            }
            $result = $projectService->returnCompletionReport($reportId, $reason);
            echo json_encode($result);
            break;
        
        // ========================================
        // COMPLETION REPORT RO WORKFLOW
        // ========================================
        
        case 'start_ro_completion_review':
            // RO starts reviewing (endorsed → under_ro_review)
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->startROCompletionReview($reportId);
            echo json_encode($result);
            break;
        
        case 'reject_completion':
            // RO rejects completion report
            $reportId = $input['report_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Rejection reason required']);
                exit;
            }
            $result = $projectService->rejectCompletionReport($reportId, $reason);
            echo json_encode($result);
            break;
        
        case 'resubmit_completion':
            // Researcher resubmits after revision
            $reportId = $input['report_id'] ?? null;
            $updatedData = $input['updated_data'] ?? [];
            
            if (!$reportId) {
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            $result = $projectService->resubmitCompletionReport($reportId, $updatedData);
            echo json_encode($result);
            break;
            
        case 'approve_completion':
            $reportId = $input['report_id'] ?? null;
            if (!$reportId) {
                logProjectAction($conn, 'approve_completion', null, 'error', 'Report ID required');
                echo json_encode(['success' => false, 'error' => 'Report ID required']);
                exit;
            }
            
            // Get project ID from completion report for logging
            $stmt = $conn->prepare("SELECT project_id FROM project_completion_reports WHERE id = ?");
            $stmt->bind_param("i", $reportId);
            $stmt->execute();
            $stmt->bind_result($projectId);
            $stmt->fetch();
            $stmt->close();
            
            $notes = $input['notes'] ?? null;
            $result = $projectService->approveCompletionReport($reportId, $notes);
            
            // Log the approval action
            if ($result['success']) {
                logProjectAction($conn, 'approve_completion', $projectId, 'success', null, [
                    'report_id' => $reportId,
                    'notes' => $notes
                ]);
            } else {
                logProjectAction($conn, 'approve_completion', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'get_completion':
            $projectId = $input['project_id'] ?? $_GET['project_id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $report = $projectService->getProjectCompletionReport($projectId);
            echo json_encode(['success' => true, 'data' => $report]);
            break;
            
        // ========================================
        // RESEARCH OUTPUTS
        // ========================================
        
        case 'report_output':
            $projectId = $input['project_id'] ?? null;
            if (!$projectId) {
                logProjectAction($conn, 'report_output', null, 'error', 'Project ID required');
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            
            // Check eligibility before attempting
            $project = $projectService->getProject($projectId);
            if ($project) {
                $eligibility = $workflowEngine->checkOutputEligibility($project);
                if (!$eligibility['allowed']) {
                    logProjectAction($conn, 'report_output', $projectId, 'blocked', $eligibility['reason'], [
                        'output_type' => $input['output_type'] ?? null,
                        'output_title' => $input['title'] ?? null
                    ]);
                    echo json_encode(['success' => false, 'error' => $eligibility['reason']]);
                    exit;
                }
            }
            
            $result = $projectService->reportOutput($projectId, $input);
            
            // Log success or failure
            if ($result['success']) {
                logProjectAction($conn, 'report_output', $projectId, 'success', null, [
                    'output_id' => $result['output_id'] ?? null,
                    'output_type' => $input['output_type'] ?? null,
                    'output_title' => $input['title'] ?? null
                ]);
            } else {
                logProjectAction($conn, 'report_output', $projectId, 'error', $result['error'] ?? 'Unknown error');
            }
            
            echo json_encode($result);
            break;
            
        case 'verify_output':
            $outputId = $input['output_id'] ?? null;
            $verified = isset($input['verified']) ? (bool)$input['verified'] : null;
            $remarks = $input['remarks'] ?? null;
            
            if (!$outputId || $verified === null) {
                echo json_encode(['success' => false, 'error' => 'Output ID and verification decision required']);
                exit;
            }
            $result = $projectService->verifyOutput($outputId, $verified, $remarks);
            echo json_encode($result);
            break;
        
        case 'review_output':
            // Simplified output review action for work queue
            $outputId = $input['output_id'] ?? null;
            $decision = $input['decision'] ?? null; // 'verified' or 'rejected'
            $remarks = $input['remarks'] ?? null;
            
            if (!$outputId || !$decision) {
                echo json_encode(['success' => false, 'error' => 'Output ID and decision required']);
                exit;
            }
            
            $verified = ($decision === 'verified');
            $result = $projectService->verifyOutput($outputId, $verified, $remarks);
            echo json_encode($result);
            break;
        
        case 'submit_output':
            // Submit output for verification
            $outputId = $input['output_id'] ?? null;
            if (!$outputId) {
                echo json_encode(['success' => false, 'error' => 'Output ID required']);
                exit;
            }
            $result = $projectService->submitOutput($outputId);
            echo json_encode($result);
            break;
        
        case 'endorse_output':
            // Coordinator endorses output
            $outputId = $input['output_id'] ?? null;
            $remarks = $input['remarks'] ?? null;
            
            if (!$outputId) {
                echo json_encode(['success' => false, 'error' => 'Output ID required']);
                exit;
            }
            $result = $projectService->endorseOutput($outputId, $remarks);
            echo json_encode($result);
            break;
        
        case 'return_output':
            // Coordinator/RO returns output for revision
            $outputId = $input['output_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$outputId) {
                echo json_encode(['success' => false, 'error' => 'Output ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Return reason required']);
                exit;
            }
            $result = $projectService->returnOutput($outputId, $reason);
            echo json_encode($result);
            break;
        
        case 'reject_output':
            // RO rejects output
            $outputId = $input['output_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$outputId) {
                echo json_encode(['success' => false, 'error' => 'Output ID required']);
                exit;
            }
            if (!$reason) {
                echo json_encode(['success' => false, 'error' => 'Rejection reason required']);
                exit;
            }
            $result = $projectService->rejectOutput($outputId, $reason);
            echo json_encode($result);
            break;
            
        case 'get_outputs':
            $projectId = $input['project_id'] ?? $_GET['project_id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $outputs = $projectService->getOutputs($projectId);
            echo json_encode(['success' => true, 'data' => $outputs]);
            break;
            
        // ========================================
        // FIELD CHANGE REQUESTS
        // ========================================
        
        case 'request_field_change':
            $projectId = $input['project_id'] ?? null;
            $fieldName = $input['field_name'] ?? null;
            $currentValue = $input['current_value'] ?? '';
            $requestedValue = $input['requested_value'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$projectId || !$fieldName || !$requestedValue || !$reason) {
                echo json_encode(['success' => false, 'error' => 'Project ID, field name, requested value, and reason are required']);
                exit;
            }
            $result = $projectService->requestFieldChange($projectId, $fieldName, $currentValue, $requestedValue, $reason);
            echo json_encode($result);
            break;
            
        case 'approve_field_change':
            $requestId = $input['request_id'] ?? null;
            $approved = isset($input['approved']) ? (bool)$input['approved'] : null;
            $remarks = $input['remarks'] ?? null;
            
            if (!$requestId || $approved === null) {
                echo json_encode(['success' => false, 'error' => 'Request ID and approval decision required']);
                exit;
            }
            $result = $projectService->approveFieldChange($requestId, $approved, $remarks);
            echo json_encode($result);
            break;
            
        case 'get_pending_field_changes':
            $projectId = $input['project_id'] ?? $_GET['project_id'] ?? null;
            if (!$projectId) {
                echo json_encode(['success' => false, 'error' => 'Project ID required']);
                exit;
            }
            $changes = $projectService->getPendingFieldChanges($projectId);
            echo json_encode(['success' => true, 'data' => $changes]);
            break;
            
        // ========================================
        // PROJECT STATISTICS
        // ========================================
        
        case 'get_statistics':
            $scope = $input['scope'] ?? 'researcher';
            $stats = $workflowEngine->getProjectStatistics($scope);
            echo json_encode(['success' => true, 'data' => $stats]);
            break;
            
        case 'get_active_projects':
            if (!$workflowEngine->isResearchOfficeAdmin()) {
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                exit;
            }
            $filters = [
                'researcher_type' => $input['researcher_type'] ?? null,
                'unit' => $input['unit'] ?? null,
                'search' => $input['search'] ?? null
            ];
            $page = $input['page'] ?? 1;
            $perPage = $input['per_page'] ?? 20;
            $projects = $workflowEngine->getActiveProjects($filters, $page, $perPage);
            echo json_encode(['success' => true, 'data' => $projects]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
    }
    
} catch (Exception $e) {
    error_log("project_api.php error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred: ' . $e->getMessage()]);
}

$conn->close();
