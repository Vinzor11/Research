<?php
/**
 * Research Office Review Queue
 * 
 * This page allows Research Office Admins (Director, Assistant Director, Admin) to:
 * - View endorsed submissions from coordinators
 * - Perform final compliance validation
 * - Assign classifications (program, funding, fiscal year)
 * - Approve or Reject submissions
 * - Assign official reference numbers
 * - Return submissions to coordinator (NOT directly to researcher - Pattern A)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';
require_once 'WorkflowEngine.php';

// Access control - Admin or Research Office only
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Initialize services
$submissionService = new SubmissionService($conn);
$workflowEngine = $submissionService->getWorkflowEngine();

// Check if user is Research Office admin
$isROAdmin = $workflowEngine->isResearchOfficeAdmin();
$canApprove = $workflowEngine->isResearchOfficeAdmin(true);

if (!$isROAdmin && $userRole !== 'admin') {
    header("Location: research.php");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get RO admin details
$roAdminRole = 'admin';
if ($userRole !== 'admin') {
    $stmt = $conn->prepare("SELECT admin_role FROM research_office_admins WHERE user_id = ? AND status = 'active'");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $roResult = $stmt->get_result()->fetch_assoc();
    $roAdminRole = $roResult['admin_role'] ?? 'admin';
    $stmt->close();
}

// Get filter parameters
$statusFilter = $_GET['status'] ?? '';
$researcherTypeFilter = $_GET['researcher_type'] ?? '';
$assignedToMe = isset($_GET['assigned_to_me']);
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get submissions for RO queue
$filters = [
    'status' => $statusFilter ?: null,
    'researcher_type' => $researcherTypeFilter ?: null,
    'search' => $searchQuery ?: null,
    'assigned_to_me' => $assignedToMe
];
$submissions = $submissionService->getResearchOfficeQueue($filters, $page, 15);

// Get queue statistics
$stats = [
    'endorsed' => 0,
    'reviewing' => 0,
    'approved_today' => 0,
    'rejected_today' => 0
];

$stmt = $conn->prepare("
    SELECT 
        SUM(CASE WHEN status = 'endorsed' THEN 1 ELSE 0 END) as endorsed,
        SUM(CASE WHEN status = 'under_ro_review' THEN 1 ELSE 0 END) as reviewing,
        SUM(CASE WHEN status = 'approved' AND DATE(decision_at) = CURDATE() THEN 1 ELSE 0 END) as approved_today,
        SUM(CASE WHEN status = 'rejected' AND DATE(decision_at) = CURDATE() THEN 1 ELSE 0 END) as rejected_today
    FROM research_submissions
");
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
$stmt->close();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   WORK QUEUE - UNIFIED DESIGN SYSTEM (RO)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.header-right {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    transition: all 0.3s ease;
    cursor: default;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-proposals { background: linear-gradient(135deg, #dbeafe, #93c5fd); color: #1d4ed8; }
.stat-icon.icon-progress { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-extensions { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }
.stat-icon.icon-outputs { background: linear-gradient(135deg, #e0e7ff, #c7d2fe); color: #5b21b6; }
.stat-icon.icon-completions { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.filter-header i { color: #064e1a; font-size: 16px; }
.filter-header h3 { font-size: 15px; font-weight: 600; color: #374151; margin: 0; }

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
    white-space: nowrap;
}

.queue-table th:nth-child(1) { width: 10%; text-align: center; }
.queue-table th:nth-child(2) { width: 32%; }
.queue-table th:nth-child(3) { width: 18%; text-align: center; }
.queue-table th:nth-child(4) { width: 12%; text-align: center; }
.queue-table th:nth-child(5) { width: 12%; text-align: center; }
.queue-table th:nth-child(6) { width: 16%; text-align: center; }

.queue-table td {
    padding: 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
}

.queue-table tr:hover { background: #f9fafb; }

/* Type Badge Cell */
.type-cell { text-align: center; }

.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.type-badge i { font-size: 12px; }
.type-proposal { background: #dbeafe; color: #1e40af; }
.type-progress { background: #fef3c7; color: #92400e; }
.type-output { background: #e0e7ff; color: #5b21b6; }
.type-extension { background: #fee2e2; color: #991b1b; }
.type-completion { background: #d1fae5; color: #065f46; }

/* Item Cell */
.item-cell { text-align: left; }

.item-title {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.item-title:hover { color: #064e1a; }

.item-meta {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 6px;
}

.item-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.ref-badge { font-size: 11px; color: #6b7280; font-family: monospace; }

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
}

.researcher-type-badge.faculty { background: #dbeafe; color: #1e40af; }
.researcher-type-badge.student { background: #fef3c7; color: #92400e; }
.researcher-type-badge.personnel { background: #e0e7ff; color: #5b21b6; }

.researcher-name {
    font-size: 12px;
    color: #374151;
    display: flex;
    align-items: center;
    gap: 4px;
}

.researcher-name i { color: #9ca3af; font-size: 11px; }

/* Unit/Status/Date Cells */
.unit-cell { font-size: 13px; color: #374151; text-align: center; }
.status-cell { text-align: center; }
.date-cell { font-size: 13px; color: #6b7280; text-align: center; }
.action-cell { text-align: center; }

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

.status-submitted, .status-pending { background: #dbeafe; color: #1e40af; }
.status-under_coordinator_review, .status-reviewing { background: #fef3c7; color: #92400e; }
.status-endorsed { background: #e0e7ff; color: #5b21b6; }
.status-under_ro_review { background: #fef3c7; color: #92400e; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }

/* Review Button */
.btn-review {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-review:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

.btn-review i { font-size: 11px; }

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #6b7280;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }

.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; border-color: #d1d5db; }
.pagination .current { background: #064e1a; color: white; border: 1px solid #064e1a; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-content {
    transform: scale(1);
}

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
}

.form-group input, .form-group select, .form-group textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
}

.form-group textarea {
    min-height: 100px;
    resize: vertical;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

/* Alert Boxes */
.alert-box {
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-warning {
    background: #fef3c7;
    color: #92400e;
    border: 1px solid #fde68a;
}

.alert-danger {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
}

.alert-success {
    background: #d1fae5;
    color: #065f46;
    border: 1px solid #6ee7b7;
}

/* Modal Buttons */
.modal-footer .btn {
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
}

.btn-primary {
    background: #064e1a;
    color: white;
}

.btn-primary:hover {
    background: #053615;
}

.btn-secondary {
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
}

.btn-secondary:hover {
    background: #e5e7eb;
}

.btn-success {
    background: #059669;
    color: white;
}

.btn-success:hover {
    background: #047857;
}

.btn-warning {
    background: #f59e0b;
    color: white;
}

.btn-warning:hover {
    background: #d97706;
}

.btn-danger {
    background: #dc2626;
    color: white;
}

.btn-danger:hover {
    background: #b91c1c;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #6b7280;
}

.empty-state i {
    font-size: 64px;
    margin-bottom: 20px;
    opacity: 0.5;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 30px;
}

.pagination a, .pagination span {
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 14px;
    text-decoration: none;
}

.pagination a {
    background: white;
    color: #374151;
    border: 1px solid #e5e7eb;
}

.pagination a:hover { background: #f3f4f6; }

.pagination .current {
    background: #064e1a;
    color: white;
    border: 1px solid #064e1a;
}
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa-solid fa-building-columns header-icon"></i>
                <div>
                    <h1>Work Queue</h1>
                    <p>Review and process pending submissions, reports, and requests</p>
                </div>
            </div>
            <div class="header-right" style="display: flex; align-items: center; gap: 12px;">
                <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #065f46;">
                    <i class="fa fa-shield-alt"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    Admin
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <?php $totalItems = ($stats['endorsed'] ?? 0) + ($stats['reviewing'] ?? 0); ?>
    <div class="stats-row">
        <div class="stat-card active">
            <div class="stat-icon icon-total">
                <i class="fa fa-layer-group"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $totalItems ?></div>
                <div class="stat-label">Total Items</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-proposals">
                <i class="fa fa-file-alt"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['endorsed'] ?? 0 ?></div>
                <div class="stat-label">Proposals</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-progress">
                <i class="fa fa-chart-line"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['reviewing'] ?? 0 ?></div>
                <div class="stat-label">Progress</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-extensions">
                <i class="fa fa-calendar-plus"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Extensions</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-outputs">
                <i class="fa fa-book"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Outputs</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-completions">
                <i class="fa fa-check-double"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number">0</div>
                <div class="stat-label">Completions</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <i class="fa fa-filter"></i>
            <h3>Filter Queue</h3>
        </div>
        <form method="GET">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Item Type</label>
                    <select name="item_type">
                        <option value="">All Types</option>
                        <option value="proposal">Proposals</option>
                        <option value="progress">Progress Reports</option>
                        <option value="output">Outputs</option>
                        <option value="extension">Extensions</option>
                        <option value="completion">Completions</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="endorsed" <?= $statusFilter === 'endorsed' ? 'selected' : '' ?>>Endorsed</option>
                        <option value="under_ro_review" <?= $statusFilter === 'under_ro_review' ? 'selected' : '' ?>>Under Review</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?= s($_GET['date_from'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?= s($_GET['date_to'] ?? '') ?>">
                </div>
                
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="q" placeholder="Search by reference, title, or requester..." value="<?= s($searchQuery) ?>">
                </div>
                
                <div class="filter-group filter-actions">
                    <label>&nbsp;</label>
                    <?php if ($statusFilter || $searchQuery || !empty($_GET['date_from']) || !empty($_GET['date_to'])): ?>
                        <a href="research_office_queue.php" class="clear-btn" title="Clear filters"><i class="fa fa-times"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Queue Table -->
    <div class="queue-table-container">
        <?php if (empty($submissions['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-inbox"></i>
                <h3>Queue is Empty</h3>
                <p>No submissions are currently awaiting your review.</p>
            </div>
        <?php else: ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Item</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions['data'] as $sub): 
                        // Determine item type for badge
                        $typeCode = strtolower($sub['type_code'] ?? 'proposal');
                        $typeIcon = 'fa-file-alt';
                        $typeLabel = 'PROPOSAL';
                        if (strpos($typeCode, 'progress') !== false || strpos($typeCode, 'ongoing') !== false) {
                            $typeIcon = 'fa-chart-line';
                            $typeLabel = 'PROGRESS';
                            $typeCode = 'progress';
                        } elseif (strpos($typeCode, 'output') !== false || strpos($typeCode, 'publication') !== false) {
                            $typeIcon = 'fa-book';
                            $typeLabel = 'OUTPUT';
                            $typeCode = 'output';
                        } elseif (strpos($typeCode, 'extension') !== false) {
                            $typeIcon = 'fa-calendar-plus';
                            $typeLabel = 'EXTENSION';
                            $typeCode = 'extension';
                        } elseif (strpos($typeCode, 'completion') !== false) {
                            $typeIcon = 'fa-check-double';
                            $typeLabel = 'COMPLETION';
                            $typeCode = 'completion';
                        } else {
                            $typeCode = 'proposal';
                        }
                    ?>
                    <tr>
                        <!-- TYPE -->
                        <td class="type-cell">
                            <span class="type-badge type-<?= $typeCode ?>">
                                <i class="fa <?= $typeIcon ?>"></i> <?= $typeLabel ?>
                            </span>
                        </td>
                        
                        <!-- ITEM -->
                        <td class="item-cell">
                            <a href="submission_view.php?id=<?= $sub['id'] ?>" class="item-title"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                                <?= s($sub['title']) ?>
                            </a>
                            <div class="item-meta"><?= s($sub['type_name']) ?></div>
                            <div class="item-badges">
                                <span class="ref-badge"><?= s($sub['reference_number'] ?? 'RMS-' . str_pad($sub['id'], 5, '0', STR_PAD_LEFT)) ?></span>
                                <span class="researcher-type-badge <?= s($sub['researcher_type']) ?>">
                                    <?= s(strtoupper($sub['researcher_type'])) ?>
                                </span>
                                <span class="researcher-name">
                                    <i class="fa fa-user"></i> <?= s($sub['researcher_name'] ?? $sub['created_by_name'] ?? 'Unknown') ?>
                                </span>
                            </div>
                        </td>
                        
                        <!-- UNIT -->
                        <td class="unit-cell">
                            <?= s($sub['researcher_unit_name'] ?? '—') ?>
                        </td>
                        
                        <!-- STATUS -->
                        <td class="status-cell">
                            <span class="status-badge status-<?= s($sub['status']) ?>">
                                <?php 
                                    $statusLabels = [
                                        'endorsed' => 'Endorsed',
                                        'under_ro_review' => 'Under Review',
                                        'approved' => 'Approved',
                                        'rejected' => 'Rejected'
                                    ];
                                    echo $statusLabels[$sub['status']] ?? ucfirst($sub['status']);
                                ?>
                            </span>
                        </td>
                        
                        <!-- SUBMITTED -->
                        <td class="date-cell">
                            <?= $sub['submitted_at'] ? date('M d, Y', strtotime($sub['submitted_at'])) : '—' ?>
                        </td>
                        
                        <!-- ACTION -->
                        <td class="action-cell">
                            <a href="submission_view.php?id=<?= $sub['id'] ?>" class="btn-review"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_view.php?id=<?= $sub['id'] ?>',true)}">
                                <i class="fa fa-eye"></i> Review
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Remove old filter and card markup below, keep only modals -->
<?php /* Old filter and cards section removed - table format above */ ?>

<!-- Modals for actions -->
<select name="researcher_type" style="display:none;">
            <option value="">All Researcher Types</option>
            <option value="faculty" <?= $researcherTypeFilter === 'faculty' ? 'selected' : '' ?>>Faculty</option>
            <option value="student" <?= $researcherTypeFilter === 'student' ? 'selected' : '' ?>>Student</option>
            <option value="personnel" <?= $researcherTypeFilter === 'personnel' ? 'selected' : '' ?>>Personnel</option>
        </select>
        <label style="display: flex; align-items: center; gap: 6px; font-size: 14px;">
            <input type="checkbox" name="assigned_to_me" <?= $assignedToMe ? 'checked' : '' ?>>
            Assigned to me
        </label>
        <input type="text" name="q" placeholder="Search by title..." value="<?= s($searchQuery) ?>">
        <button type="submit" class="filter-btn"><i class="fa fa-search"></i> Filter</button>
        <?php if ($statusFilter || $researcherTypeFilter || $assignedToMe || $searchQuery): ?>
            <a href="research_office_queue.php" class="clear-filters">Clear</a>
        <?php endif; ?>
    </form>

    <!-- Submissions Queue -->
    <div class="submissions-list">
        <?php if (empty($submissions['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-check-circle"></i>
                <h3>Queue is Empty</h3>
                <p>No submissions are currently awaiting Research Office review.</p>
            </div>
        <?php else: ?>
            <?php foreach ($submissions['data'] as $sub): ?>
                <?php
                // Get endorsement summary
                $endorsement = $submissionService->getEndorsementSummary($sub['id']);
                ?>
                <div class="submission-card status-<?= s($sub['status']) ?>">
                    <div class="submission-header">
                        <div>
                            <h3 class="submission-title"><?= s($sub['title']) ?></h3>
                            <div class="submission-meta">
                                <span><i class="fa fa-tag"></i> <?= s($sub['type_name']) ?></span>
                                <span><i class="fa fa-calendar"></i> Endorsed: <?= $sub['coordinator_endorsed_at'] ? date('M d, Y', strtotime($sub['coordinator_endorsed_at'])) : 'N/A' ?></span>
                                <span class="researcher-type-badge type-<?= s($sub['researcher_type']) ?>">
                                    <?= s(ucfirst($sub['researcher_type'])) ?>
                                </span>
                            </div>
                        </div>
                        <span class="status-badge status-<?= s($sub['status']) ?>">
                            <?= $sub['status'] === 'endorsed' ? 'Endorsed - Pending Review' : 'Under RO Review' ?>
                        </span>
                    </div>
                    
                    <!-- Endorsement Info -->
                    <?php if ($endorsement): ?>
                    <div class="endorsement-info">
                        <h4><i class="fa fa-user-check"></i> Coordinator Endorsement</h4>
                        <div class="endorsement-checklist">
                            <span class="checklist-item <?= $endorsement['completeness_verified'] ? 'verified' : '' ?>">
                                <i class="fa <?= $endorsement['completeness_verified'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                                Completeness
                            </span>
                            <span class="checklist-item <?= $endorsement['unit_verified'] ? 'verified' : '' ?>">
                                <i class="fa <?= $endorsement['unit_verified'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                                Unit
                            </span>
                            <span class="checklist-item <?= $endorsement['category_verified'] ? 'verified' : '' ?>">
                                <i class="fa <?= $endorsement['category_verified'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                                Category
                            </span>
                            <span class="checklist-item <?= $endorsement['attachments_verified'] ? 'verified' : '' ?>">
                                <i class="fa <?= $endorsement['attachments_verified'] ? 'fa-check-circle' : 'fa-circle' ?>"></i>
                                Attachments
                            </span>
                        </div>
                        <?php if (!empty($endorsement['endorsement_notes'])): ?>
                            <p style="margin: 10px 0 0 0; font-size: 13px; color: #4b5563;">
                                <strong>Notes:</strong> <?= s($endorsement['endorsement_notes']) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="submission-actions">
                        <?php if ($sub['status'] === 'endorsed'): ?>
                            <button class="btn btn-review" onclick="startROReview(<?= $sub['id'] ?>)">
                                <i class="fa fa-play"></i> Start Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($sub['status'] === 'under_ro_review'): ?>
                            <a href="submission_view.php?id=<?= $sub['id'] ?>" class="btn btn-view">
                                <i class="fa fa-eye"></i> View Details
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($sub['status'] === 'under_ro_review'): ?>
                            <button class="btn btn-classify" onclick="openClassifyModal(<?= $sub['id'] ?>, '<?= s(addslashes($sub['title'])) ?>')">
                                <i class="fa fa-tags"></i> Classify
                            </button>
                            <button class="btn btn-return" onclick="openReturnModal(<?= $sub['id'] ?>, '<?= s(addslashes($sub['title'])) ?>')">
                                <i class="fa fa-undo"></i> Return to Coordinator
                            </button>
                            <?php if ($canApprove): ?>
                                <button class="btn btn-reject" onclick="openRejectModal(<?= $sub['id'] ?>, '<?= s(addslashes($sub['title'])) ?>')">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <button class="btn btn-approve" onclick="openApproveModal(<?= $sub['id'] ?>, '<?= s(addslashes($sub['title'])) ?>')">
                                    <i class="fa fa-check"></i> Approve
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($submissions['total_pages'] > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                    <i class="fa fa-chevron-left"></i> Previous
                </a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($submissions['total_pages'], $page + 2); $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $submissions['total_pages']): ?>
                <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                    Next <i class="fa fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Classify Modal -->
<div id="classifyModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-tags" style="color: #3b82f6;"></i> Assign Classification</h2>
            <button class="modal-close" onclick="closeClassifyModal()">&times;</button>
        </div>
        <form id="classifyForm" method="POST" onsubmit="submitClassify(event); return false;">
            <input type="hidden" name="submission_id" id="classify_submission_id">
            <div class="modal-body">
                <p style="margin-bottom: 20px; color: #4b5563;">
                    Assigning classification for "<span id="classify_title" style="font-weight: 600;"></span>"
                </p>
                
                <div class="form-group">
                    <label>Research Program</label>
                    <select name="research_program">
                        <option value="">Select program...</option>
                        <option value="Basic Research">Basic Research</option>
                        <option value="Applied Research">Applied Research</option>
                        <option value="Development Research">Development Research</option>
                        <option value="Action Research">Action Research</option>
                        <option value="Institutional Research">Institutional Research</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Funding Source</label>
                    <select name="funding_source">
                        <option value="">Select source...</option>
                        <option value="Institutional">Institutional</option>
                        <option value="CHED">CHED</option>
                        <option value="DOST">DOST</option>
                        <option value="DA">DA</option>
                        <option value="DENR">DENR</option>
                        <option value="Private">Private</option>
                        <option value="Foreign Grant">Foreign Grant</option>
                        <option value="Self-funded">Self-funded</option>
                        <option value="Other Government">Other Government</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Fiscal Year</label>
                    <select name="fiscal_year">
                        <option value="">Select year...</option>
                        <?php for ($y = date('Y') + 1; $y >= date('Y') - 5; $y--): ?>
                            <option value="FY <?= $y ?>" <?= $y == date('Y') ? 'selected' : '' ?>>FY <?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Tags (comma-separated)</label>
                    <input type="text" name="tags" placeholder="e.g., COVID-19, Agriculture, Education">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeClassifyModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Save Classification
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return to Coordinator Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-undo" style="color: #f59e0b;"></i> Return to Coordinator</h2>
            <button class="modal-close" onclick="closeReturnModal()">&times;</button>
        </div>
        <form id="returnForm" method="POST" onsubmit="submitReturn(event); return false;">
            <input type="hidden" name="submission_id" id="return_submission_id">
            <div class="modal-body">
                <div class="alert-box alert-warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <div>
                        <strong>Pattern A (Mandatory):</strong> Submissions can only be returned to the Coordinator, not directly to the Researcher. 
                        The Coordinator will review and forward to the Researcher if needed.
                    </div>
                </div>
                
                <p style="margin-bottom: 20px; color: #4b5563;">
                    Returning "<span id="return_title" style="font-weight: 600;"></span>" to coordinator for further review.
                </p>
                
                <div class="form-group">
                    <label>Reason for Return (Required) *</label>
                    <textarea name="reason" required placeholder="Explain why this submission needs to be returned to the coordinator..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Instructions for Coordinator (Optional)</label>
                    <textarea name="instructions" placeholder="Any specific instructions or guidance for the coordinator..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeReturnModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-warning">
                    <i class="fa fa-undo"></i> Return to Coordinator
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-check-circle" style="color: #10b981;"></i> Approve & Elevate to Project</h2>
            <button class="modal-close" onclick="closeApproveModal()">&times;</button>
        </div>
        <form id="approveForm" method="POST" onsubmit="submitApprove(event); return false;">
            <input type="hidden" name="submission_id" id="approve_submission_id">
            <div class="modal-body">
                <div class="alert-box alert-success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>Approving:</strong> "<span id="approve_title" style="font-weight: 600;"></span>"
                    </div>
                </div>
                
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 15px; margin: 15px 0;">
                    <h4 style="margin: 0 0 10px 0; color: #166534; font-size: 14px;">
                        <i class="fa fa-info-circle"></i> What happens on approval:
                    </h4>
                    <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #4b5563; line-height: 1.8;">
                        <li><strong>Reference Number</strong> will be assigned (immutable)</li>
                        <li><strong>Project Code</strong> will be generated (immutable)</li>
                        <li>Proposal becomes an <strong>On-Going Research Project</strong></li>
                        <li>Core fields (title, objectives, timeline, budget) become <strong>read-only</strong></li>
                        <li>Mapped to <strong>RMIS Form D1</strong> (On-Going Research Project)</li>
                    </ul>
                </div>
                
                <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 15px; margin: 15px 0;">
                    <h4 style="margin: 0 0 10px 0; color: #1e40af; font-size: 14px;">
                        <i class="fa fa-user-graduate"></i> Researcher can now:
                    </h4>
                    <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #4b5563; line-height: 1.8;">
                        <li>Submit progress reports</li>
                        <li>Request timeline/budget extensions</li>
                        <li>Report research outputs and publications</li>
                        <li>Submit completion report when finished</li>
                    </ul>
                </div>
                
                <div class="form-group">
                    <label>Approval Notes (Optional)</label>
                    <textarea name="notes" placeholder="Any notes or remarks for the approval..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeApproveModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Approve & Elevate to Project
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fa fa-times-circle" style="color: #dc2626;"></i> Reject Submission</h2>
            <button class="modal-close" onclick="closeRejectModal()">&times;</button>
        </div>
        <form id="rejectForm" method="POST" onsubmit="submitReject(event); return false;">
            <input type="hidden" name="submission_id" id="reject_submission_id">
            <div class="modal-body">
                <div class="alert-box alert-danger">
                    <i class="fa fa-exclamation-circle"></i>
                    <div>
                        <strong>Warning:</strong> Rejecting "<span id="reject_title" style="font-weight: 600;"></span>" is a final decision. 
                        This action cannot be undone.
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Rejection Reason (Required) *</label>
                    <textarea name="reason" required placeholder="Please provide a clear reason for rejection..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="btn btn-danger">
                    <i class="fa fa-times-circle"></i> Reject Submission
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Start RO Review
async function startROReview(submissionId) {
    if (!confirm('Start reviewing this submission? It will be assigned to you.')) {
        return;
    }
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'start_review', id: submissionId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to start review'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Classify Modal
function openClassifyModal(submissionId, title) {
    document.getElementById('classify_submission_id').value = submissionId;
    document.getElementById('classify_title').textContent = title;
    document.getElementById('classifyModal').classList.add('active');
}

function closeClassifyModal() {
    document.getElementById('classifyModal').classList.remove('active');
    document.getElementById('classifyForm').reset();
}

async function submitClassify(event) {
    event.preventDefault();
    
    const form = event.target;
    const tagsInput = form.tags.value;
    const tags = tagsInput ? tagsInput.split(',').map(t => t.trim()).filter(t => t) : [];
    
    const data = {
        action: 'classify',
        id: form.submission_id.value,
        research_program: form.research_program.value,
        funding_source: form.funding_source.value,
        fiscal_year: form.fiscal_year.value,
        tags: tags
    };
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Classification saved!');
            closeClassifyModal();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to save classification'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Return to Coordinator Modal
function openReturnModal(submissionId, title) {
    document.getElementById('return_submission_id').value = submissionId;
    document.getElementById('return_title').textContent = title;
    document.getElementById('returnModal').classList.add('active');
}

function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('active');
    document.getElementById('returnForm').reset();
}

async function submitReturn(event) {
    event.preventDefault();
    
    const form = event.target;
    const data = {
        action: 'return_to_coordinator',
        id: form.submission_id.value,
        reason: form.reason.value,
        instructions: form.instructions.value
    };
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Submission returned to coordinator');
            closeReturnModal();
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to return submission'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Approve Modal
function openApproveModal(submissionId, title) {
    document.getElementById('approve_submission_id').value = submissionId;
    document.getElementById('approve_title').textContent = title;
    document.getElementById('approveModal').classList.add('active');
}

function closeApproveModal() {
    document.getElementById('approveModal').classList.remove('active');
    document.getElementById('approveForm').reset();
}

async function submitApprove(event) {
    event.preventDefault();
    
    if (!confirm('Are you sure you want to approve this submission?\n\nThis will:\n• Assign an official reference number\n• Generate a project code\n• Elevate the proposal to an On-Going Research Project\n• Lock core proposal fields\n• Map to RMIS Form D1')) {
        return;
    }
    
    const form = event.target;
    const data = {
        action: 'approve',
        id: form.submission_id.value,
        notes: form.notes.value
    };
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Enhanced approval message showing project elevation
            let message = '✅ Proposal Approved & Elevated to On-Going Research Project!\n\n';
            message += '📋 Reference Number: ' + (result.reference_number || 'N/A') + '\n';
            message += '📁 Project Code: ' + (result.project_code || 'N/A') + '\n';
            message += '📊 Project Status: ' + (result.project_status || 'on_going').replace('_', '-').toUpperCase() + '\n';
            message += '📄 RMIS Form: Form ' + (result.rmis_form || 'D1') + ' (On-Going Research Project)\n\n';
            message += 'The researcher can now:\n';
            message += '• Submit progress reports\n';
            message += '• Request extensions\n';
            message += '• Report research outputs\n';
            message += '• Submit completion report';
            
            alert(message);
            closeApproveModal();
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to approve submission'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Reject Modal
function openRejectModal(submissionId, title) {
    document.getElementById('reject_submission_id').value = submissionId;
    document.getElementById('reject_title').textContent = title;
    document.getElementById('rejectModal').classList.add('active');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.remove('active');
    document.getElementById('rejectForm').reset();
}

async function submitReject(event) {
    event.preventDefault();
    
    if (!confirm('Are you sure you want to REJECT this submission? This is a FINAL decision and cannot be undone.')) {
        return;
    }
    
    const form = event.target;
    const data = {
        action: 'reject',
        id: form.submission_id.value,
        reason: form.reason.value
    };
    
    try {
        const response = await fetch('submission_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Submission has been rejected.');
            closeRejectModal();
            window.location.reload();
        } else {
            alert('❌ Error: ' + (result.error || 'Failed to reject submission'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('❌ An error occurred');
    }
}

// Close modals on outside click
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
});

// Close modals on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
    }
});
</script>
