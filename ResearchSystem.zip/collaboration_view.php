<?php
/**
 * collaboration_view.php
 * 
 * Unified collaboration view page for:
 * - Researchers: View their collaboration details, edit drafts, submit requests
 * - Coordinators: Review, endorse, or return for revision
 * - Admins: Final approval/rejection
 * 
 * Displays:
 * - Collaboration details
 * - Partner information
 * - Workflow status and timeline
 * - Available actions based on role and status
 * - Comments and audit history
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'CollaborationService.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? 'researcher';
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$employeeId = $_SESSION['employee_id'] ?? null;
$isSpa = isSpaRequest();

// Get collaboration ID
$collaborationId = (int)($_GET['id'] ?? 0);
if (!$collaborationId) {
    if ($isSpa) {
        echo '<div class="alert alert-danger">Collaboration ID required</div>';
        exit;
    }
    header("Location: researcher_collaborations.php");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Initialize service
$collaborationService = new CollaborationService($conn);
$collaboration = $collaborationService->getCollaboration($collaborationId);

if (!$collaboration) {
    echo '<div class="alert alert-danger">Collaboration not found</div>';
    exit;
}

// Access verification
$canView = false;
if ($collaboration['created_by'] == $userId) {
    $canView = true; // Owner
} elseif ($userRole === 'admin') {
    $canView = true; // Admin sees all
} elseif ($userRole === 'coordinator') {
    // Coordinator sees items in their scope
    $canView = in_array($collaboration['status'], ['submitted', 'under_coordinator_review', 'endorsed', 'approved', 'rejected']);
}

if (!$canView) {
    echo '<div class="alert alert-danger">You are not authorized to view this collaboration</div>';
    exit;
}

// Get comments and audit log
$comments = $collaborationService->getComments($collaborationId);
$auditLog = $collaborationService->getAuditLog($collaborationId);

// Determine available actions
$actions = $collaboration['available_actions'] ?? [];
$isRequest = $collaboration['collaboration_category'] === 'request';
$isRecord = $collaboration['collaboration_category'] === 'record';

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Status timeline configuration
$statusTimeline = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'color' => '#6b7280'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'color' => '#3b82f6'],
    'under_coordinator_review' => ['label' => 'Coordinator Review', 'icon' => 'fa-user-tie', 'color' => '#f59e0b'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'color' => '#8b5cf6'],
    'under_ro_review' => ['label' => 'RO Review', 'icon' => 'fa-building', 'color' => '#ec4899'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-thumbs-up', 'color' => '#10b981'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'color' => '#ef4444'],
    'returned_for_revision' => ['label' => 'Returned', 'icon' => 'fa-undo', 'color' => '#f97316']
];

$currentStatusConfig = $statusTimeline[$collaboration['status']] ?? ['label' => 'Unknown', 'icon' => 'fa-question', 'color' => '#6b7280'];
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   COLLABORATION VIEW - UNIFIED DESIGN
   ============================================ */

.collab-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.collab-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.collab-header-left {
    flex: 1;
}

.collab-header-left h1 {
    font-size: 24px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.3;
}

.collab-header-left .ref-number {
    font-family: 'Consolas', monospace;
    font-size: 13px;
    color: rgba(255,255,255,0.9);
    background: rgba(255,255,255,0.15);
    padding: 4px 10px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 12px;
}

.collab-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.collab-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.badge-category-request { background: #dbeafe; color: #1e40af; }
.badge-category-record { background: #d1fae5; color: #065f46; }
.badge-partner-type { background: rgba(255,255,255,0.2); color: white; }

.collab-header-right {
    text-align: right;
}

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted, .status-pending { color: #2563eb; }
.status-reviewing, .status-under_coordinator_review, .status-under_ro_review { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-rejected { color: #dc2626; }
.status-returned, .status-returned_for_revision { color: #ea580c; }

/* Content Layout */
.collab-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.collab-main { display: flex; flex-direction: column; gap: 24px; }
.collab-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: #064e1a; }

.section-body { padding: 20px; }

/* Detail Rows */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.5;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

.detail-value.text-muted { color: #9ca3af; }

/* Prevent layout break from long text */
.section-card {
    min-width: 0;
    overflow: hidden;
}

.section-body {
    overflow-wrap: break-word;
    word-break: break-word;
}

.collab-main, .collab-sidebar {
    min-width: 0;
}

/* Status Timeline */
.status-timeline {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 16px 20px;
    background: #f9fafb;
    border-radius: 8px;
    overflow-x: auto;
}

.timeline-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    min-width: 80px;
    flex: 1;
    position: relative;
}

.timeline-step::after {
    content: '';
    position: absolute;
    top: 16px;
    right: -50%;
    width: 100%;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
}

.timeline-step:last-child::after { display: none; }

.timeline-step.completed::after { background: #10b981; }
.timeline-step.current::after { background: linear-gradient(90deg, #10b981 50%, #e5e7eb 50%); }

.timeline-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    color: #9ca3af;
    font-size: 12px;
    position: relative;
    z-index: 1;
}

.timeline-step.completed .timeline-icon { background: #d1fae5; color: #059669; }
.timeline-step.current .timeline-icon { background: #dbeafe; color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2); }
.timeline-step.rejected .timeline-icon { background: #fee2e2; color: #dc2626; }

.timeline-label {
    font-size: 10px;
    color: #6b7280;
    text-align: center;
    white-space: nowrap;
}

.timeline-step.current .timeline-label { color: #1f2937; font-weight: 600; }

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.action-btn i { font-size: 14px; }

.btn-primary-action {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
}
.btn-primary-action:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

.btn-submit { background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); color: white; }
.btn-submit:hover { background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); }

.btn-endorse { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%); color: white; }
.btn-endorse:hover { background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%); }

.btn-approve { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-approve:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-return { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.btn-return:hover { background: #fde68a; }

.btn-reject { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.btn-reject:hover { background: #fecaca; }

.btn-edit { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }
.btn-edit:hover { background: #e5e7eb; }

/* Comments Section */
.comments-list {
    max-height: 400px;
    overflow-y: auto;
}

.comment-item {
    padding: 14px;
    border-bottom: 1px solid #f3f4f6;
}

.comment-item:last-child { border-bottom: none; }

.comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.comment-author {
    font-weight: 600;
    font-size: 13px;
    color: #1f2937;
}

.comment-date {
    font-size: 11px;
    color: #9ca3af;
}

.comment-text {
    font-size: 13px;
    color: #4b5563;
    line-height: 1.5;
}

.comment-type {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    margin-left: 8px;
}

.type-revision_request { background: #fee2e2; color: #991b1b; }
.type-endorsement_note { background: #ede9fe; color: #5b21b6; }
.type-approval_note { background: #d1fae5; color: #065f46; }
.type-rejection_reason { background: #fee2e2; color: #991b1b; }
.type-internal_note { background: #fef3c7; color: #92400e; }

/* Audit Log */
.audit-list {
    max-height: 300px;
    overflow-y: auto;
}

.audit-item {
    display: flex;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #f3f4f6;
}

.audit-item:last-child { border-bottom: none; }

.audit-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    color: #6b7280;
    font-size: 12px;
    flex-shrink: 0;
}

.audit-content { flex: 1; }

.audit-action {
    font-size: 13px;
    color: #1f2937;
    font-weight: 500;
}

.audit-meta {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 2px;
}

/* Add Comment Form */
.comment-form {
    padding: 16px;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.comment-form textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    resize: vertical;
    min-height: 80px;
}

.comment-form textarea:focus {
    outline: none;
    border-color: #064e1a;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.comment-form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 10px;
}

/* Document List */
.document-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #f9fafb;
    border-radius: 8px;
    margin-bottom: 8px;
}

.document-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fee2e2;
    color: #dc2626;
    font-size: 18px;
}

.document-info { flex: 1; }
.document-name { font-size: 13px; font-weight: 600; color: #1f2937; }
.document-meta { font-size: 11px; color: #9ca3af; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 18px;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.modal-body { padding: 24px; }
.modal-footer {
    padding: 16px 24px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

/* Modal Buttons */
.modal-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s ease;
}

.modal-btn i { font-size: 13px; }

.modal-btn-secondary {
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
}
.modal-btn-secondary:hover {
    background: #e5e7eb;
    border-color: #9ca3af;
}

.modal-btn-primary {
    background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(124, 58, 237, 0.3);
}
.modal-btn-primary:hover {
    background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4);
}

.modal-btn-success {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(5, 150, 105, 0.3);
}
.modal-btn-success:hover {
    background: linear-gradient(135deg, #047857 0%, #059669 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(5, 150, 105, 0.4);
}

.modal-btn-warning {
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(217, 119, 6, 0.3);
}
.modal-btn-warning:hover {
    background: linear-gradient(135deg, #b45309 0%, #d97706 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(217, 119, 6, 0.4);
}

.modal-btn-danger {
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(220, 38, 38, 0.3);
}
.modal-btn-danger:hover {
    background: linear-gradient(135deg, #b91c1c 0%, #dc2626 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
}

/* Responsive */
@media (max-width: 1024px) {
    .collab-content {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .collab-header-content {
        flex-direction: column;
    }
    
    .collab-header-right {
        text-align: left;
    }
    
    .detail-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="content">
    <!-- Header Banner -->
    <div class="collab-header-banner">
        <div class="collab-header-content">
            <div class="collab-header-left">
                <?php if ($collaboration['reference_number']): ?>
                    <span class="ref-number"><?= s($collaboration['reference_number']) ?></span>
                <?php endif; ?>
                <h1><?= s($collaboration['title']) ?></h1>
                <div class="collab-header-badges">
                    <span class="collab-badge badge-category-<?= $isRequest ? 'request' : 'record' ?>">
                        <i class="fa <?= $isRequest ? 'fa-file-contract' : 'fa-clipboard-list' ?>"></i>
                        <?= $isRequest ? 'Collaboration Request' : 'Collaboration Record' ?>
                    </span>
                    <span class="collab-badge badge-partner-type">
                        <i class="fa fa-<?= $collaboration['partner_type'] === 'international' ? 'globe' : ($collaboration['partner_type'] === 'academic' ? 'university' : 'building') ?>"></i>
                        <?= ucfirst($collaboration['partner_type']) ?>
                    </span>
                    <span class="collab-badge badge-partner-type">
                        <i class="fa fa-handshake"></i>
                        <?= s($collaboration['type_name']) ?>
                    </span>
                </div>
            </div>
            <div class="collab-header-right">
                <span class="status-badge-large status-<?= s($collaboration['status']) ?>">
                    <i class="fa <?= $currentStatusConfig['icon'] ?>"></i>
                    <?= s($collaboration['status_label']) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Status Timeline (for requests only) -->
    <?php if ($isRequest): ?>
    <div class="section-card" style="margin-bottom: 24px;">
        <div class="status-timeline">
            <?php
            $workflowSteps = [
                'draft' => 'Draft',
                'submitted' => 'Submitted',
                'under_coordinator_review' => 'Coord. Review',
                'endorsed' => 'Endorsed',
                'under_ro_review' => 'RO Review',
                'approved' => 'Approved'
            ];
            
            $currentFound = false;
            $isRejected = $collaboration['status'] === 'rejected';
            $isReturned = $collaboration['status'] === 'returned_for_revision';
            
            foreach ($workflowSteps as $stepKey => $stepLabel):
                $stepClass = '';
                if ($isRejected && $stepKey === 'approved') {
                    $stepClass = 'rejected';
                    $stepLabel = 'Rejected';
                } elseif (!$currentFound) {
                    if ($stepKey === $collaboration['status']) {
                        $stepClass = 'current';
                        $currentFound = true;
                    } elseif ($isReturned && $stepKey === 'draft') {
                        $stepClass = 'current';
                        $currentFound = true;
                        $stepLabel = 'Returned';
                    } else {
                        $stepClass = 'completed';
                    }
                }
            ?>
            <div class="timeline-step <?= $stepClass ?>">
                <div class="timeline-icon">
                    <i class="fa <?= $stepClass === 'completed' ? 'fa-check' : ($stepClass === 'rejected' ? 'fa-times' : ($statusTimeline[$stepKey]['icon'] ?? 'fa-circle')) ?>"></i>
                </div>
                <span class="timeline-label"><?= $stepLabel ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="collab-content">
        <!-- Main Content -->
        <div class="collab-main">
            <!-- Partner Information -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-building"></i> Partner Information</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row full-width">
                            <span class="detail-label">Partner / Institution Name</span>
                            <span class="detail-value"><?= s($collaboration['partner_name']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Partner Type</span>
                            <span class="detail-value"><?= ucfirst(s($collaboration['partner_type'])) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Country</span>
                            <span class="detail-value"><?= s($collaboration['partner_country'] ?? 'Philippines') ?></span>
                        </div>
                        <?php if ($collaboration['partner_address']): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Address</span>
                            <span class="detail-value"><?= s($collaboration['partner_address']) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($collaboration['partner_contact_person']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Contact Person</span>
                            <span class="detail-value"><?= s($collaboration['partner_contact_person']) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($collaboration['partner_contact_email']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Email</span>
                            <span class="detail-value"><?= s($collaboration['partner_contact_email']) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Collaboration Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-info-circle"></i> Collaboration Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row full-width">
                            <span class="detail-label">Purpose / Objectives</span>
                            <span class="detail-value"><?= nl2br(s($collaboration['purpose'])) ?></span>
                        </div>
                        <?php if ($collaboration['scope_of_work']): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Scope of Work</span>
                            <span class="detail-value"><?= nl2br(s($collaboration['scope_of_work'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($collaboration['expected_outcomes']): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Expected Outcomes</span>
                            <span class="detail-value"><?= nl2br(s($collaboration['expected_outcomes'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="detail-row">
                            <span class="detail-label">Start Date</span>
                            <span class="detail-value"><?= $collaboration['start_date'] ? date('F d, Y', strtotime($collaboration['start_date'])) : 'Not specified' ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">End Date</span>
                            <span class="detail-value">
                                <?php if ($collaboration['is_ongoing']): ?>
                                    <span style="color: #059669;"><i class="fa fa-infinity"></i> On-going</span>
                                <?php else: ?>
                                    <?= $collaboration['end_date'] ? date('F d, Y', strtotime($collaboration['end_date'])) : 'Not specified' ?>
                                <?php endif; ?>
                            </span>
                        </div>
                        <?php if ($collaboration['has_financial_component']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Financial Component</span>
                            <span class="detail-value" style="color: #059669;"><i class="fa fa-check-circle"></i> Yes</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Amount Involved</span>
                            <span class="detail-value"><?= $collaboration['amount_involved'] ? '₱ ' . number_format($collaboration['amount_involved'], 2) : 'Not specified' ?></span>
                        </div>
                        <?php if ($collaboration['financial_details']): ?>
                        <div class="detail-row full-width">
                            <span class="detail-label">Financial Details</span>
                            <span class="detail-value"><?= nl2br(s($collaboration['financial_details'])) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Linked Project -->
            <?php if ($collaboration['project_id']): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-link"></i> Linked Project</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <div class="detail-row full-width">
                            <span class="detail-label">Project Title</span>
                            <span class="detail-value">
                                <a href="project_view.php?id=<?= $collaboration['project_id'] ?>" 
                                   onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $collaboration['project_id'] ?>',true)}">
                                    <?= s($collaboration['project_title']) ?>
                                </a>
                            </span>
                        </div>
                        <?php if ($collaboration['project_reference']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Reference</span>
                            <span class="detail-value"><?= s($collaboration['project_reference']) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Documents -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-file-alt"></i> Documents</h3>
                    <?php if ($collaboration['can_edit']): ?>
                        <button class="action-btn btn-edit" style="width: auto; padding: 6px 12px; font-size: 12px;" onclick="openUploadModal()">
                            <i class="fa fa-upload"></i> Upload
                        </button>
                    <?php endif; ?>
                </div>
                <div class="section-body">
                    <?php if ($collaboration['moa_document_path']): ?>
                        <div class="document-item">
                            <div class="document-icon"><i class="fa fa-file-pdf"></i></div>
                            <div class="document-info">
                                <div class="document-name">MOA/MOU Document</div>
                                <div class="document-meta">Required agreement document</div>
                            </div>
                            <a href="<?= s($collaboration['moa_document_path']) ?>" target="_blank" class="action-btn btn-edit" style="width: auto; padding: 6px 12px; font-size: 12px;">
                                <i class="fa fa-download"></i> View
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <?php 
                    $supportingDocs = json_decode($collaboration['supporting_documents'] ?? '[]', true);
                    if (!empty($supportingDocs)):
                        foreach ($supportingDocs as $doc):
                    ?>
                        <div class="document-item">
                            <div class="document-icon" style="background: #dbeafe; color: #1e40af;"><i class="fa fa-file"></i></div>
                            <div class="document-info">
                                <div class="document-name"><?= s($doc['name']) ?></div>
                                <div class="document-meta">Uploaded <?= date('M d, Y', strtotime($doc['uploaded_at'])) ?></div>
                            </div>
                            <a href="<?= s($doc['path']) ?>" target="_blank" class="action-btn btn-edit" style="width: auto; padding: 6px 12px; font-size: 12px;">
                                <i class="fa fa-download"></i> View
                            </a>
                        </div>
                    <?php 
                        endforeach;
                    endif;
                    
                    if (!$collaboration['moa_document_path'] && empty($supportingDocs)):
                    ?>
                        <p style="color: #9ca3af; font-style: italic; text-align: center; padding: 20px;">No documents uploaded yet</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Comments & Discussion -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-comments"></i> Comments & Discussion</h3>
                </div>
                <div class="comments-list">
                    <?php if (empty($comments)): ?>
                        <p style="color: #9ca3af; font-style: italic; text-align: center; padding: 30px;">No comments yet</p>
                    <?php else: ?>
                        <?php foreach ($comments as $comment): ?>
                            <div class="comment-item">
                                <div class="comment-header">
                                    <span class="comment-author">
                                        <?= s($comment['created_by_name']) ?>
                                        <span class="comment-type type-<?= s($comment['comment_type']) ?>">
                                            <?= ucfirst(str_replace('_', ' ', $comment['comment_type'])) ?>
                                        </span>
                                    </span>
                                    <span class="comment-date"><?= date('M d, Y g:i A', strtotime($comment['created_at'])) ?></span>
                                </div>
                                <div class="comment-text"><?= nl2br(s($comment['comment_text'])) ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <form class="comment-form" method="POST" onsubmit="submitComment(event); return false;">
                    <textarea name="comment" placeholder="Add a comment..." required></textarea>
                    <div class="comment-form-actions">
                        <?php if (in_array($userRole, ['coordinator', 'admin'])): ?>
                            <label style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #6b7280;">
                                <input type="checkbox" name="is_internal" value="1"> Internal note (not visible to researcher)
                            </label>
                        <?php endif; ?>
                        <button type="submit" class="action-btn btn-primary-action" style="width: auto; padding: 8px 16px;">
                            <i class="fa fa-paper-plane"></i> Add Comment
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="collab-sidebar">
            <!-- Actions Panel -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if (in_array('edit', $actions)): ?>
                            <a href="researcher_collaborations.php?edit=<?= $collaborationId ?>" 
                               class="action-btn btn-edit"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_collaborations.php?edit=<?= $collaborationId ?>',true)}">
                                <i class="fa fa-edit"></i> Edit Collaboration
                            </a>
                        <?php endif; ?>
                        
                        <?php if (in_array('submit', $actions)): ?>
                            <button class="action-btn btn-submit" onclick="submitCollaboration()">
                                <i class="fa fa-paper-plane"></i> Submit for Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('start_review', $actions)): ?>
                            <button class="action-btn btn-submit" onclick="startReview()">
                                <i class="fa fa-play"></i> Start Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('endorse', $actions)): ?>
                            <button class="action-btn btn-endorse" onclick="openEndorseModal()">
                                <i class="fa fa-check-double"></i> Endorse to Research Office
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('return', $actions)): ?>
                            <button class="action-btn btn-return" onclick="openReturnModal()">
                                <i class="fa fa-undo"></i> Return for Revision
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('start_ro_review', $actions)): ?>
                            <button class="action-btn btn-submit" onclick="startROReview()">
                                <i class="fa fa-play"></i> Start RO Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('approve', $actions)): ?>
                            <button class="action-btn btn-approve" onclick="openApproveModal()">
                                <i class="fa fa-thumbs-up"></i> Approve Collaboration
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('reject', $actions)): ?>
                            <button class="action-btn btn-reject" onclick="openRejectModal()">
                                <i class="fa fa-times"></i> Reject
                            </button>
                        <?php endif; ?>
                        
                        <?php if (in_array('delete', $actions)): ?>
                            <button class="action-btn btn-reject" onclick="deleteCollaboration()">
                                <i class="fa fa-trash"></i> Delete Draft
                            </button>
                        <?php endif; ?>
                        
                        <?php if (empty($actions)): ?>
                            <p style="color: #9ca3af; font-size: 13px; text-align: center;">
                                No actions available at this time
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Researcher Information -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-user"></i> Requester</h3>
                </div>
                <div class="section-body">
                    <div class="detail-row" style="margin-bottom: 12px;">
                        <span class="detail-label">Researcher Type</span>
                        <span class="detail-value">
                            <span style="background: #dbeafe; color: #1e40af; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">
                                <?= strtoupper(s($collaboration['researcher_type'])) ?>
                            </span>
                        </span>
                    </div>
                    <div class="detail-row" style="margin-bottom: 12px;">
                        <span class="detail-label">Unit / Department</span>
                        <span class="detail-value"><?= s($collaboration['researcher_unit_name'] ?? 'Not specified') ?></span>
                    </div>
                </div>
            </div>

            <!-- Timestamps -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline</h3>
                </div>
                <div class="section-body">
                    <div class="detail-row" style="margin-bottom: 12px;">
                        <span class="detail-label">Created</span>
                        <span class="detail-value"><?= date('M d, Y g:i A', strtotime($collaboration['created_at'])) ?></span>
                    </div>
                    <?php if ($collaboration['submitted_at']): ?>
                    <div class="detail-row" style="margin-bottom: 12px;">
                        <span class="detail-label">Submitted</span>
                        <span class="detail-value"><?= date('M d, Y g:i A', strtotime($collaboration['submitted_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($collaboration['coordinator_endorsed_at']): ?>
                    <div class="detail-row" style="margin-bottom: 12px;">
                        <span class="detail-label">Endorsed</span>
                        <span class="detail-value"><?= date('M d, Y g:i A', strtotime($collaboration['coordinator_endorsed_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($collaboration['decision_at']): ?>
                    <div class="detail-row">
                        <span class="detail-label">Decision</span>
                        <span class="detail-value"><?= date('M d, Y g:i A', strtotime($collaboration['decision_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Audit Log -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-history"></i> Activity Log</h3>
                </div>
                <div class="section-body audit-list">
                    <?php if (empty($auditLog)): ?>
                        <p style="color: #9ca3af; font-style: italic; text-align: center;">No activity recorded</p>
                    <?php else: ?>
                        <?php foreach ($auditLog as $log): ?>
                            <div class="audit-item">
                                <div class="audit-icon">
                                    <i class="fa fa-<?= strpos($log['action_type'], 'approv') !== false ? 'check' : (strpos($log['action_type'], 'reject') !== false ? 'times' : 'circle') ?>"></i>
                                </div>
                                <div class="audit-content">
                                    <div class="audit-action"><?= ucfirst(str_replace('_', ' ', s($log['action_type']))) ?></div>
                                    <div class="audit-meta">
                                        <?= s($log['performed_by_name']) ?> • <?= date('M d, Y g:i A', strtotime($log['created_at'])) ?>
                                    </div>
                                    <?php if ($log['comments']): ?>
                                        <div style="font-size: 12px; color: #6b7280; margin-top: 4px;"><?= s($log['comments']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-check-double" style="color: #7c3aed;"></i> Endorse Collaboration</h3>
            <button class="modal-close" onclick="closeModal('endorseModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="endorseCollaboration(event); return false;">
            <div class="modal-body">
                <p style="color: #6b7280; margin-bottom: 20px;">Please verify the following before endorsing:</p>
                
                <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="partner_verified" value="1">
                        <span>Partner legitimacy has been verified</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="documents_verified" value="1">
                        <span>Required documents are present and valid</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="scope_verified" value="1">
                        <span>Scope and purpose are clear and appropriate</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="compliance_verified" value="1">
                        <span>Complies with institutional policies</span>
                    </label>
                </div>
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 6px; font-weight: 500;">Endorsement Notes (Optional)</label>
                    <textarea name="endorsement_notes" rows="3" placeholder="Any notes for the Research Office..." 
                              style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px;"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('endorseModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-primary">
                    <i class="fa fa-check-double"></i> Endorse
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-undo" style="color: #f59e0b;"></i> Return for Revision</h3>
            <button class="modal-close" onclick="closeModal('returnModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="returnForRevision(event); return false;">
            <div class="modal-body">
                <div class="form-group">
                    <label style="display: block; margin-bottom: 6px; font-weight: 500;">Reason for Return <span style="color: #dc2626;">*</span></label>
                    <textarea name="reason" rows="4" required placeholder="Explain what needs to be revised..."
                              style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px;"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('returnModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-warning">
                    <i class="fa fa-undo"></i> Return
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-thumbs-up" style="color: #059669;"></i> Approve Collaboration</h3>
            <button class="modal-close" onclick="closeModal('approveModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="approveCollaboration(event); return false;">
            <div class="modal-body">
                <p style="color: #6b7280; margin-bottom: 20px;">
                    You are about to approve this collaboration request. This action is final.
                </p>
                <div class="form-group">
                    <label style="display: block; margin-bottom: 6px; font-weight: 500;">Approval Remarks (Optional)</label>
                    <textarea name="remarks" rows="3" placeholder="Any remarks or conditions..."
                              style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px;"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('approveModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-success">
                    <i class="fa fa-thumbs-up"></i> Approve
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-times-circle" style="color: #dc2626;"></i> Reject Collaboration</h3>
            <button class="modal-close" onclick="closeModal('rejectModal')">&times;</button>
        </div>
        <form method="POST" onsubmit="rejectCollaboration(event); return false;">
            <div class="modal-body">
                <p style="color: #dc2626; margin-bottom: 20px;">
                    <i class="fa fa-exclamation-triangle"></i> This action is final and cannot be undone.
                </p>
                <div class="form-group">
                    <label style="display: block; margin-bottom: 6px; font-weight: 500;">Rejection Reason <span style="color: #dc2626;">*</span></label>
                    <textarea name="reason" rows="4" required placeholder="Explain why this collaboration is being rejected..."
                              style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px;"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal('rejectModal')">
                    <i class="fa fa-times"></i> Cancel
                </button>
                <button type="submit" class="modal-btn modal-btn-danger">
                    <i class="fa fa-times-circle"></i> Reject
                </button>
            </div>
        </form>
    </div>
</div>

<script>
const collaborationId = <?= $collaborationId ?>;

// Modal functions
function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    const form = document.getElementById(id).querySelector('form');
    if (form) form.reset();
}

function openEndorseModal() { openModal('endorseModal'); }
function openReturnModal() { openModal('returnModal'); }
function openApproveModal() { openModal('approveModal'); }
function openRejectModal() { openModal('rejectModal'); }

// Close modals on outside click
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) closeModal(this.id);
    });
});

// API helper
async function apiCall(action, data = {}) {
    const response = await fetch('collaboration_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, id: collaborationId, ...data })
    });
    return response.json();
}

// Submit collaboration
async function submitCollaboration() {
    if (!confirm('Submit this collaboration for review? You will not be able to edit it until reviewed.')) return;
    
    try {
        const result = await apiCall('submit');
        if (result.success) {
            alert('Collaboration submitted successfully!');
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to submit'));
        }
    } catch (e) {
        alert('An error occurred');
        console.error(e);
    }
}

// Start Review (Coordinator)
async function startReview() {
    if (!confirm('Start reviewing this collaboration?')) return;
    
    try {
        const result = await apiCall('start_review');
        if (result.success) {
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to start review'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Start RO Review (Admin)
async function startROReview() {
    if (!confirm('Start Research Office review?')) return;
    
    try {
        const result = await apiCall('start_ro_review');
        if (result.success) {
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to start RO review'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Endorse
async function endorseCollaboration(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    try {
        const result = await apiCall('endorse', {
            partner_verified: formData.get('partner_verified') ? 1 : 0,
            documents_verified: formData.get('documents_verified') ? 1 : 0,
            scope_verified: formData.get('scope_verified') ? 1 : 0,
            compliance_verified: formData.get('compliance_verified') ? 1 : 0,
            endorsement_notes: formData.get('endorsement_notes')
        });
        
        if (result.success) {
            alert('Collaboration endorsed and forwarded to Research Office!');
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to endorse'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Return for revision
async function returnForRevision(event) {
    event.preventDefault();
    const form = event.target;
    const reason = form.querySelector('textarea[name="reason"]').value;
    
    try {
        const result = await apiCall('return_for_revision', { reason });
        if (result.success) {
            alert('Collaboration returned for revision');
            closeModal('returnModal');
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to return'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Approve
async function approveCollaboration(event) {
    event.preventDefault();
    const form = event.target;
    const remarks = form.querySelector('textarea[name="remarks"]').value;
    
    try {
        const result = await apiCall('approve', { remarks });
        if (result.success) {
            alert('Collaboration approved!');
            closeModal('approveModal');
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to approve'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Reject
async function rejectCollaboration(event) {
    event.preventDefault();
    const form = event.target;
    const reason = form.querySelector('textarea[name="reason"]').value;
    
    try {
        const result = await apiCall('reject', { reason });
        if (result.success) {
            alert('Collaboration rejected');
            closeModal('rejectModal');
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to reject'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Delete draft
async function deleteCollaboration() {
    if (!confirm('Are you sure you want to delete this draft? This cannot be undone.')) return;
    
    try {
        const result = await apiCall('delete');
        if (result.success) {
            alert('Draft deleted');
            if (window.SPA) {
                window.SPA.loadPage('researcher_collaborations.php', true);
            } else {
                location.href = 'researcher_collaborations.php';
            }
        } else {
            alert('Error: ' + (result.error || 'Failed to delete'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}

// Add comment
async function submitComment(event) {
    event.preventDefault();
    const form = event.target;
    const comment = form.querySelector('textarea[name="comment"]').value;
    const isInternal = form.querySelector('input[name="is_internal"]')?.checked || false;
    
    try {
        const result = await apiCall('add_comment', { comment, is_internal: isInternal });
        if (result.success) {
            location.reload();
        } else {
            alert('Error: ' + (result.error || 'Failed to add comment'));
        }
    } catch (e) {
        alert('An error occurred');
    }
}
</script>
