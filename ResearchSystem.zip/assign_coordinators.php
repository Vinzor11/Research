<?php
/**
 * Assign Coordinators Page
 * Shows employees with Research Coordinator position and allows assignment
 */

session_start();
require 'db.php';
require 'config.php';
require 'hr_api_helper.php';
require_once 'spa_helper.php';

// Admin only access
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? null) !== 'admin') {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'] ?? 'Admin';
$isSpa = isSpaRequest();

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$error = '';
$success = '';
$employees = [];
$assignedCoordinators = [];

// Ensure coordinator_assignments table has 'personnel' type
try {
    $conn->query("ALTER TABLE coordinator_assignments MODIFY COLUMN coordinator_type ENUM('faculty','student','personnel') NOT NULL");
} catch (Exception $e) {
    // Column might already be correct, ignore
}

// Ensure users table has 'personnel' type
try {
    $conn->query("ALTER TABLE users MODIFY COLUMN coordinator_type ENUM('faculty','student','personnel') DEFAULT NULL");
} catch (Exception $e) {
    // Column might already be correct, ignore
}

// Ensure table for persisting synced coordinators exists
try {
    $conn->query("CREATE TABLE IF NOT EXISTS synced_research_coordinators (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(100) NOT NULL,
        full_name VARCHAR(255) DEFAULT '',
        email VARCHAR(255) DEFAULT '',
        position_name VARCHAR(255) DEFAULT '',
        unit_name VARCHAR(255) DEFAULT '',
        unit_type VARCHAR(50) DEFAULT '',
        sector_name VARCHAR(255) DEFAULT '',
        hr_status ENUM('active', 'position_changed', 'inactive') DEFAULT 'active',
        synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uk_employee_id (employee_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    // Add unit_type column if it doesn't exist (check first to avoid errors)
    $checkUnitType = $conn->query("SHOW COLUMNS FROM synced_research_coordinators LIKE 'unit_type'");
    if ($checkUnitType && $checkUnitType->num_rows === 0) {
        $conn->query("ALTER TABLE synced_research_coordinators ADD COLUMN unit_type VARCHAR(50) DEFAULT '' AFTER unit_name");
    }
    
    // Add hr_status column if it doesn't exist (check first to avoid errors)
    $checkHrStatus = $conn->query("SHOW COLUMNS FROM synced_research_coordinators LIKE 'hr_status'");
    if ($checkHrStatus && $checkHrStatus->num_rows === 0) {
        $conn->query("ALTER TABLE synced_research_coordinators ADD COLUMN hr_status ENUM('active', 'position_changed', 'inactive') DEFAULT 'active' AFTER sector_name");
    }
} catch (Exception $e) {
    // Log error for debugging
    errorLog("Error ensuring synced_research_coordinators table schema", ['error' => $e->getMessage()]);
}

// Ensure coordinator_assignments has scope columns
try {
    $checkScopeMode = $conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'scope_mode'");
    if ($checkScopeMode && $checkScopeMode->num_rows === 0) {
        $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN scope_mode ENUM('own_unit', 'specific_units', 'all_units') DEFAULT 'own_unit' AFTER coordinator_type");
    }
    $checkHrUnit = $conn->query("SHOW COLUMNS FROM coordinator_assignments LIKE 'hr_unit_id'");
    if ($checkHrUnit && $checkHrUnit->num_rows === 0) {
        $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN hr_unit_id VARCHAR(100) DEFAULT NULL AFTER scope_mode");
        $conn->query("ALTER TABLE coordinator_assignments ADD COLUMN hr_unit_name VARCHAR(255) DEFAULT NULL AFTER hr_unit_id");
    }
} catch (Exception $e) {
    // Ignore
}

// Create coordinator_scopes table if not exists
try {
    $conn->query("CREATE TABLE IF NOT EXISTS coordinator_scopes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(100) NOT NULL,
        unit_id VARCHAR(100) NOT NULL,
        unit_name VARCHAR(255) DEFAULT '',
        unit_type VARCHAR(50) DEFAULT '',
        assigned_by INT NOT NULL,
        assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_employee_unit (employee_id, unit_id),
        INDEX idx_employee_id (employee_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {
    // Ignore
}

// Get ALL assigned coordinators from database (grouped by employee) with scope info
try {
    $result = $conn->query("
        SELECT ca.id, ca.employee_id, ca.coordinator_type, ca.scope_mode, 
               ca.hr_unit_id, ca.hr_unit_name, ca.assigned_at, ca.status,
               u.username as assigned_by_username
        FROM coordinator_assignments ca
        LEFT JOIN users u ON ca.assigned_by = u.id
        WHERE ca.status = 'active'
        ORDER BY ca.assigned_at DESC
    ");
    while ($row = $result->fetch_assoc()) {
        $empId = $row['employee_id'];
        if (!isset($assignedCoordinators[$empId])) {
            $assignedCoordinators[$empId] = [
                'types' => [],
                'scope_mode' => $row['scope_mode'] ?? 'own_unit',
                'hr_unit_id' => $row['hr_unit_id'],
                'hr_unit_name' => $row['hr_unit_name'],
                'scopes' => []
            ];
        }
        $assignedCoordinators[$empId]['types'][] = $row['coordinator_type'];
        // Use the scope_mode from first assignment (they should all be the same for an employee)
        if (empty($assignedCoordinators[$empId]['scope_mode'])) {
            $assignedCoordinators[$empId]['scope_mode'] = $row['scope_mode'] ?? 'own_unit';
        }
    }
    
    // Load specific unit scopes for employees with specific_units mode
    $scopeResult = $conn->query("SELECT employee_id, unit_id, unit_name, unit_type FROM coordinator_scopes");
    if ($scopeResult) {
        while ($scope = $scopeResult->fetch_assoc()) {
            $empId = $scope['employee_id'];
            if (isset($assignedCoordinators[$empId])) {
                $assignedCoordinators[$empId]['scopes'][] = [
                    'id' => $scope['unit_id'],
                    'name' => $scope['unit_name'],
                    'type' => $scope['unit_type']
                ];
            }
        }
    }
} catch (Exception $e) {
    $error = "Error loading assigned coordinators: " . $e->getMessage();
}

// Helper: check if employee has Research Coordinator position (name or code per RESEARCH_OFFICE_API_GUIDE)
function isResearchCoordinatorPosition($employee) {
    $position = $employee['position'] ?? [];
    $positionName = strtolower(trim($position['name'] ?? ''));
    $positionCode = strtoupper(trim($position['code'] ?? ''));
    $matches = (
        $positionCode === 'RES_COORD' ||
        strpos($positionName, 'research coordinator') !== false ||
        strpos($positionName, 'researchcoordinator') !== false ||
        strpos($positionName, 'research coord') !== false ||
        strpos($positionName, 'res coord') !== false
    );
    return $matches;
}

// Helper: check if employee is from an office unit (for personnel coordinator filtering)
function isOfficeUnit($employee) {
    $unit = $employee['unit'] ?? [];
    $unitType = strtolower(trim($unit['unit_type'] ?? $unit['type'] ?? ''));
    return in_array($unitType, ['office', 'administrative', 'admin']);
}

// Fetch employees only when user clicks Sync (RESEARCH_OFFICE_API_GUIDE)
$syncRequested = isset($_GET['sync']) && $_GET['sync'] === '1';
$syncDiagnostic = '';
if ($syncRequested && isHRIntegrationAvailable()) {
    try {
        $hrAPI = new HRSystemAPI($conn, $userId);
        
        // Try Research Office API first: GET /api/research/coordinators (RESEARCH_OFFICE_API_GUIDE)
        debugLog("Assign Coordinators - Trying Research Office API /api/research/coordinators");
        $employees = $hrAPI->fetchAllResearchCoordinators('active');
        
        // Fallback 2: Try Designations API GET /api/designations?position_code=RES_COORD (RESEARCH_OFFICE_API_GUIDE)
        if (empty($employees)) {
            debugLog("Assign Coordinators - Trying Designations API /api/designations?position_code=RES_COORD");
            $employees = $hrAPI->fetchCoordinatorsFromDesignations();
        }
        
        // Fallback 3: fetch all employees and filter by position if Research Office / Designations APIs not available
        if (empty($employees)) {
            debugLog("Assign Coordinators - APIs not available, falling back to fetchAllEmployees + filter");
            $firstPage = $hrAPI->getAllEmployees(1, 50, 'active');
            if (!empty($firstPage['error'])) {
                throw new Exception($firstPage['error']);
            }
            $allEmployees = $firstPage['data'] ?? [];
            $lastPage = $firstPage['meta']['last_page'] ?? 1;
            for ($page = 2; $page <= $lastPage; $page++) {
                sleep(1);
                $nextPage = $hrAPI->getAllEmployees($page, 50, 'active');
                if (!empty($nextPage['error'])) {
                    throw new Exception($nextPage['error']);
                }
                $allEmployees = array_merge($allEmployees, $nextPage['data'] ?? []);
            }
            $syncDiagnostic = "Fetched " . count($allEmployees) . " total employee(s) from HR; ";
            foreach ($allEmployees as $employee) {
                if (isResearchCoordinatorPosition($employee)) {
                    $employees[] = $employee;
                }
            }
            $syncDiagnostic .= count($employees) . " had Research Coordinator position.";
        }
        
        debugLog("Assign Coordinators - Found " . count($employees) . " employees with Research Coordinator position");
        
        if (empty($employees)) {
            $error = "No employees with Research Coordinator position found in HR System.";
            if ($syncDiagnostic) {
                $error .= " (" . $syncDiagnostic . ")";
            } else {
                $error .= " The Research Office API may not be available on your HR system, or no employees have the Research Coordinator (RES_COORD) position.";
            }
        } else {
            // Count how many were previously active and are now position_changed
            $previouslyActive = $conn->query("SELECT COUNT(*) as cnt FROM synced_research_coordinators WHERE hr_status = 'active'")->fetch_assoc()['cnt'] ?? 0;
            
            syncCoordinatorsToUsers($conn, $employees);
            saveSyncedCoordinators($conn, $employees);
            
            // Count position changes
            $positionChanged = $conn->query("SELECT COUNT(*) as cnt FROM synced_research_coordinators WHERE hr_status = 'position_changed'")->fetch_assoc()['cnt'] ?? 0;
            
            $success = "Synced " . count($employees) . " employee(s) with Research Coordinator position from HR System. User accounts have been created or updated.";
            if ($positionChanged > 0) {
                $success .= " Note: " . $positionChanged . " coordinator(s) are no longer in Research Coordinator position and have been marked as inactive.";
            }
            
            // After sync, reload from database to include ALL coordinators (including position_changed)
            $employees = loadSyncedCoordinators($conn);
        }
        
    } catch (Exception $e) {
        $error = "Error fetching employees from HR System: " . $e->getMessage();
        errorLog("Assign Coordinators - HR API Error", ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
    }
} elseif ($syncRequested && !isHRIntegrationAvailable()) {
    $error = "HR System integration is not available. Please configure OAuth credentials.";
} elseif (!isHRIntegrationAvailable()) {
    $error = "HR System integration is not available. Please configure OAuth credentials.";
}

// When not syncing, load coordinators from last saved snapshot so the table persists across page visits
if (empty($employees)) {
    $employees = loadSyncedCoordinators($conn);
}

// Last sync time for indicator
$lastSyncedAt = null;
try {
    $r = $conn->query("SELECT MAX(synced_at) AS last_synced FROM synced_research_coordinators");
    if ($r && ($row = $r->fetch_assoc()) && !empty($row['last_synced'])) {
        $lastSyncedAt = $row['last_synced'];
    }
} catch (Exception $e) {
    // ignore
}

/**
 * Save synced research coordinators to database so the list persists when leaving the page.
 * Now tracks position changes - coordinators who are no longer in Research Coordinator position
 * are marked as 'position_changed' instead of being deleted.
 */
function saveSyncedCoordinators($conn, $employees) {
    try {
        // Get all current employee IDs from the sync
        $currentEmployeeIds = [];
        foreach ($employees as $emp) {
            $id = $emp['id'] ?? '';
            if (!empty($id)) {
                $currentEmployeeIds[] = $id;
            }
        }
        
        // Mark all existing coordinators as 'position_changed' first
        // Those still in Research Coordinator position will be updated back to 'active'
        $conn->query("UPDATE synced_research_coordinators SET hr_status = 'position_changed' WHERE hr_status = 'active'");
        
        // Also deactivate their coordinator access in users table
        $deactivateResult = $conn->query("SELECT employee_id FROM synced_research_coordinators WHERE hr_status = 'position_changed'");
        if ($deactivateResult) {
            while ($row = $deactivateResult->fetch_assoc()) {
                $empId = $row['employee_id'];
                // Check if this employee is NOT in the current sync
                if (!in_array($empId, $currentEmployeeIds)) {
                    // Deactivate their coordinator assignments
                    deactivateCoordinatorAccess($conn, $empId);
                }
            }
        }
        
        // Now upsert the current employees
        $stmt = $conn->prepare("
            INSERT INTO synced_research_coordinators 
                (employee_id, full_name, email, position_name, unit_name, unit_type, sector_name, hr_status, synced_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
            ON DUPLICATE KEY UPDATE 
                full_name = VALUES(full_name),
                email = VALUES(email),
                position_name = VALUES(position_name),
                unit_name = VALUES(unit_name),
                unit_type = VALUES(unit_type),
                sector_name = VALUES(sector_name),
                hr_status = 'active',
                synced_at = NOW()
        ");
        
        foreach ($employees as $emp) {
            $id = $emp['id'] ?? '';
            if (empty($id)) continue;
            
            $name = $emp['name'] ?? [];
            $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
            $email = $emp['contact']['email'] ?? '';
            $positionName = $emp['position']['name'] ?? '';
            $unitName = $emp['unit']['name'] ?? '';
            $unitType = $emp['unit']['unit_type'] ?? $emp['unit']['type'] ?? '';
            $sectorName = is_array($emp['sector'] ?? null) ? ($emp['sector']['name'] ?? '') : '';
            $stmt->bind_param("sssssss", $id, $fullName, $email, $positionName, $unitName, $unitType, $sectorName);
            $stmt->execute();
        }
        $stmt->close();
        
        debugLog("saveSyncedCoordinators", [
            'current_employees' => count($employees),
            'employee_ids' => $currentEmployeeIds
        ]);
        
    } catch (Exception $e) {
        errorLog("saveSyncedCoordinators", ['error' => $e->getMessage()]);
    }
}

/**
 * Deactivate coordinator access for an employee who is no longer in Research Coordinator position.
 * This removes their coordinator_type and deactivates their coordinator assignments.
 */
function deactivateCoordinatorAccess($conn, $employeeId) {
    try {
        $normalizedId = normalizeEmployeeId($employeeId);
        
        // Deactivate all coordinator assignments for this employee
        $stmt = $conn->prepare("UPDATE coordinator_assignments SET status = 'inactive' WHERE employee_id = ?");
        $stmt->bind_param("s", $employeeId);
        $stmt->execute();
        $stmt->close();
        
        // Also try with normalized ID
        $stmt = $conn->prepare("UPDATE coordinator_assignments SET status = 'inactive' WHERE employee_id = ?");
        $stmt->bind_param("s", $normalizedId);
        $stmt->execute();
        $stmt->close();
        
        // Clear coordinator_type in users table (they can no longer login as coordinator)
        $hasCoordType = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'")->num_rows > 0;
        $hasEmployeeId = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'")->num_rows > 0;
        
        if ($hasCoordType && $hasEmployeeId) {
            // Set coordinator_type to NULL - they're no longer a coordinator
            $stmt = $conn->prepare("UPDATE users SET coordinator_type = NULL WHERE employee_id = ? OR employee_id = ?");
            $stmt->bind_param("ss", $employeeId, $normalizedId);
            $stmt->execute();
            $stmt->close();
        }
        
        debugLog("deactivateCoordinatorAccess", ['employee_id' => $employeeId, 'normalized_id' => $normalizedId]);
        
    } catch (Exception $e) {
        errorLog("deactivateCoordinatorAccess", ['employee_id' => $employeeId, 'error' => $e->getMessage()]);
    }
}

/**
 * Load synced research coordinators from database (same structure as HR API response for display).
 * Includes hr_status to show which coordinators are still active vs position_changed.
 */
function loadSyncedCoordinators($conn) {
    $employees = [];
    try {
        // Order by hr_status (active first) then by full_name
        $result = $conn->query("SELECT employee_id, full_name, email, position_name, unit_name, unit_type, sector_name, hr_status FROM synced_research_coordinators ORDER BY FIELD(hr_status, 'active', 'position_changed', 'inactive'), full_name");
        if (!$result) return $employees;
        while ($row = $result->fetch_assoc()) {
            $employees[] = [
                'id' => $row['employee_id'],
                'name' => ['full_name' => $row['full_name']],
                'contact' => ['email' => $row['email'] ?? ''],
                'position' => ['name' => $row['position_name'] ?? 'N/A'],
                'unit' => [
                    'name' => $row['unit_name'] ?? 'N/A',
                    'unit_type' => $row['unit_type'] ?? ''
                ],
                'sector' => ['name' => $row['sector_name'] ?? ''],
                'hr_status' => $row['hr_status'] ?? 'active',
            ];
        }
    } catch (Exception $e) {
        errorLog("loadSyncedCoordinators", ['error' => $e->getMessage()]);
    }
    return $employees;
}

/**
 * Sync research coordinator employees to users table (create or update).
 * Called after successful sync from HR so users exist when admin assigns coordinator type.
 */
function syncCoordinatorsToUsers($conn, $employees) {
    if (empty($employees)) return;
    $hasEmployeeId = $conn->query("SHOW COLUMNS FROM users LIKE 'employee_id'")->num_rows > 0;
    $hasUserRole = $conn->query("SHOW COLUMNS FROM users LIKE 'user_role'")->num_rows > 0;
    $hasCoordType = $conn->query("SHOW COLUMNS FROM users LIKE 'coordinator_type'")->num_rows > 0;
    $hasEmail = $conn->query("SHOW COLUMNS FROM users LIKE 'email'")->num_rows > 0;
    $hasFullname = $conn->query("SHOW COLUMNS FROM users LIKE 'fullname'")->num_rows > 0;
    if (!$hasEmployeeId || !$hasUserRole) return;
    $created = 0;
    $updated = 0;
    foreach ($employees as $emp) {
        $employeeId = $emp['id'] ?? '';
        $contact = $emp['contact'] ?? [];
        $email = trim($contact['email'] ?? '');
        $name = $emp['name'] ?? [];
        $fullName = $name['full_name'] ?? trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
        $fullName = trim($fullName) ?: 'Unknown';
        $username = $email ?: $employeeId;
        if (empty($employeeId)) continue;
        $normalizedId = normalizeEmployeeId($employeeId);
        $existing = null;
        if ($hasEmployeeId) {
            $stmt = $conn->prepare("SELECT id, username, user_role, coordinator_type, fullname FROM users WHERE employee_id = ? LIMIT 1");
            $stmt->bind_param("s", $normalizedId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
        if (!$existing && $hasEmail && $email) {
            $stmt = $conn->prepare("SELECT id, username, user_role, coordinator_type, fullname FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
        if ($existing) {
            $updates = ["user_role = 'coordinator'"];
            $params = [];
            $types = '';
            if ($hasEmail && $email && ($existing['email'] ?? '') !== $email) {
                $updates[] = "email = ?";
                $params[] = $email;
                $types .= 's';
            }
            if ($hasEmployeeId && ($existing['employee_id'] ?? '') !== $normalizedId) {
                $updates[] = "employee_id = ?";
                $params[] = $normalizedId;
                $types .= 's';
            }
            if ($hasFullname && $fullName && (empty($existing['fullname']) || $existing['fullname'] === 'Unknown')) {
                $updates[] = "fullname = ?";
                $params[] = $fullName;
                $types .= 's';
            }
            $params[] = $existing['id'];
            $types .= 'i';
            $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $stmt->close();
            $updated++;
        } else {
            $randomPassword = bin2hex(random_bytes(16));
            $passwordHash = password_hash($randomPassword, PASSWORD_DEFAULT);
            $cols = ['username', 'password', 'user_role'];
            $vals = [$username, $passwordHash, 'coordinator'];
            $types = 'sss';
            if ($hasFullname) { $cols[] = 'fullname'; $vals[] = $fullName; $types .= 's'; }
            if ($hasEmail) { $cols[] = 'email'; $vals[] = $email ?: ''; $types .= 's'; }
            if ($hasEmployeeId) { $cols[] = 'employee_id'; $vals[] = $normalizedId; $types .= 's'; }
            $placeholders = implode(',', array_fill(0, count($vals), '?'));
            $sql = "INSERT INTO users (" . implode(', ', $cols) . ") VALUES ($placeholders)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$vals);
            $stmt->execute();
            $stmt->close();
            $created++;
        }
    }
    debugLog("Sync coordinators to users", ['created' => $created, 'updated' => $updated]);
}

function s($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<?php if (!$isSpa): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Coordinators - Research Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<?php endif; ?>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Note: Sidebar styles are in researchStyle.css (loaded by app.php) */
        
        .header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header-title i {
            font-size: 24px;
            color: #064e1a;
        }
        
        .header-title h1 {
            font-size: 24px;
            font-weight: 600;
        }
        
        .content {
            padding: 30px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #dc2626;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #064e1a;
            color: white;
        }
        
        .btn-primary:hover {
            background: #0b6a24;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-assign {
            background: #3b82f6;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .btn-assign:hover {
            background: #2563eb;
        }
        
        .btn-remove {
            background: #ef4444;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .btn-remove:hover {
            background: #dc2626;
        }
        
        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f9fafb;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        tr:hover {
            background: #f9fafb;
        }
        
        .badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-assigned {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-unassigned {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .badge-type {
            margin-right: 5px;
            margin-bottom: 3px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .badge-faculty {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-student {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-personnel {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .badge-office {
            background: #f3e8ff;
            color: #6b21a8;
            font-size: 11px;
            padding: 2px 8px;
        }
        
        .badge-hr-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-hr-position-changed {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-hr-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .row-position-changed {
            background: #fffbeb !important;
            opacity: 0.85;
        }
        
        .row-position-changed:hover {
            background: #fef3c7 !important;
        }
        
        .position-changed-note {
            font-size: 11px;
            color: #92400e;
            margin-top: 4px;
        }
        
        /* Scope Badge Styles */
        .badge-scope {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 11px;
            padding: 3px 8px;
        }
        
        .badge-scope-own {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-scope-specific {
            background: #d1fae5;
            color: #065f46;
        }
        
        .scope-detail {
            font-size: 11px;
            color: #6b7280;
            margin-top: 4px;
            max-width: 180px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .scope-more {
            color: #3b82f6;
            font-weight: 500;
        }
        
        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal {
            background: white;
            border-radius: 16px;
            width: 95%;
            max-width: 800px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            animation: modalSlideIn 0.3s ease;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: #9ca3af;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }
        
        .modal-close:hover {
            color: #6b7280;
        }
        
        .modal-body {
            padding: 25px;
        }
        
        .modal-employee-info {
            background: #f9fafb;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .modal-employee-info p {
            margin: 0;
            color: #6b7280;
            font-size: 14px;
        }
        
        .modal-employee-info strong {
            color: #1f2937;
            font-size: 16px;
        }
        
        .checkbox-group {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 12px;
        }
        
        .checkbox-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 15px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s;
            min-height: 90px;
        }
        
        .checkbox-item:hover {
            border-color: #064e1a;
            background: #f0fdf4;
        }
        
        .checkbox-item.selected {
            border-color: #064e1a;
            background: #f0fdf4;
        }
        
        .checkbox-item.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #f3f4f6;
        }
        
        .checkbox-item.disabled:hover {
            border-color: #e5e7eb;
            background: #f3f4f6;
        }
        
        .checkbox-item.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #f3f4f6;
        }
        
        .checkbox-item.disabled:hover {
            border-color: #e5e7eb;
            background: #f3f4f6;
        }
        
        .checkbox-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
            margin-top: 2px;
            accent-color: #064e1a;
        }
        
        .checkbox-item-content {
            flex: 1;
        }
        
        .checkbox-item-content label {
            font-weight: 600;
            color: #1f2937;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .checkbox-item-content p {
            margin: 5px 0 0;
            font-size: 13px;
            color: #6b7280;
        }
        
        .checkbox-item-content .restriction-note {
            color: #dc2626;
            font-size: 12px;
            margin-top: 5px;
        }
        
        .modal-footer {
            padding: 20px 25px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .btn-cancel {
            background: #f3f4f6;
            color: #374151;
        }
        
        .btn-cancel:hover {
            background: #e5e7eb;
        }
        
        .btn-save {
            background: #064e1a;
            color: white;
        }
        
        .btn-save:hover {
            background: #0b6a24;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #d1d5db;
        }
    </style>
</style>
<link rel="stylesheet" href="page-common.css">
<?php if (!$isSpa): ?>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="essu.png" alt="ESSU Logo">
            <h3>Research Management</h3>
        </div>
        <div class="sidebar-nav">
            <a href="research.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            <a href="facultyresearcher.php"><i class="fa fa-chalkboard-teacher"></i> Faculty</a>
            <a href="studentresearcher.php"><i class="fa fa-user-graduate"></i> Students</a>
            <a href="users.php"><i class="fa fa-users-gear"></i> User Management</a>
            <a href="oauth_settings.php"><i class="fa fa-key"></i> SSO Settings</a>
            <a href="assign_coordinators.php" class="active"><i class="fa fa-user-tie"></i> Assign Coordinators</a>
            <a href="activity_logs.php"><i class="fa fa-history"></i> Activity Logs</a>
            <a href="index.php"><i class="fa fa-home"></i> Homepage</a>
        </div>
    </div>
    
    <div class="main">
<?php endif; ?>
        
        <div class="content">
            <!-- Page Header Banner -->
            <div class="page-header-banner">
                <div class="header-content">
                    <div class="header-left">
                        <i class="fa fa-user-tie header-icon"></i>
                        <div>
                            <h1>Assign Coordinators</h1>
                            <p>Manage research coordinator assignments from HR System</p>
                        </div>
                    </div>
                    <div class="header-right">
                        <?php if (isHRIntegrationAvailable()): ?>
                        <a href="assign_coordinators.php?sync=1" class="btn-add-new">
                            <i class="fa fa-sync-alt"></i> Sync from HR
                        </a>
                        <?php endif; ?>
                        <span class="role-badge-new" style="background: rgba(255,255,255,0.95); color: #065f46;">
                            <i class="fa fa-shield-halved"></i>
                            <span style="font-weight: 600;"><?= htmlspecialchars($fullname) ?></span>
                            <span style="opacity: 0.6; margin: 0 4px;">•</span>
                            Admin
                        </span>
                    </div>
                </div>
            </div>
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fa fa-exclamation-circle"></i>
                    <span><?= s($error) ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fa fa-check-circle"></i>
                    <span><?= s($success) ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Info Bar -->
            <div style="background: white; border-radius: 12px; padding: 16px 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); border: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div>
                    <p style="color: #374151; font-size: 14px; margin: 0;">
                        Employees with "Research Coordinator" position from HR System.
                    </p>
                    <?php if (!empty($employees)): 
                        $activeCount = 0;
                        $positionChangedCount = 0;
                        foreach ($employees as $emp) {
                            if (($emp['hr_status'] ?? 'active') === 'active') {
                                $activeCount++;
                            } else {
                                $positionChangedCount++;
                            }
                        }
                    ?>
                        <p style="color: #059669; margin: 6px 0 0 0; font-weight: 600; font-size: 13px;">
                            <i class="fa fa-check-circle"></i> <?= $activeCount ?> active
                            <?php if ($positionChangedCount > 0): ?>
                                <span style="color: #92400e; margin-left: 10px;">
                                    <i class="fa fa-exclamation-triangle"></i> <?= $positionChangedCount ?> position changed
                                </span>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div style="font-size: 12px; color: #6b7280;">
                    <?php if ($lastSyncedAt): ?>
                        <i class="fa fa-clock"></i> Last synced: <?= date('M j, Y g:i A', strtotime($lastSyncedAt)) ?>
                    <?php else: ?>
                        <i class="fa fa-clock"></i> Last synced: Never
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="table-container">
                <?php if (empty($employees) && empty($error)): ?>
                    <div class="empty-state">
                        <i class="fa fa-cloud-download-alt" style="font-size: 48px; color: #064e1a;"></i>
                        <p>Click <strong>Sync from HR</strong> to fetch employees with Research Coordinator position.</p>
                    </div>
                <?php elseif (empty($employees) && !empty($error)): ?>
                    <div class="empty-state">
                        <i class="fa fa-exclamation-triangle" style="color: #dc2626;"></i>
                        <p style="color: #dc2626;"><?= s($error) ?></p>
                        <?php if (!isHRIntegrationAvailable()): ?>
                            <p style="margin-top: 10px; color: #dc2626;">HR System integration is not configured. Please check your OAuth credentials in config.php</p>
                        <?php else: ?>
                            <div style="margin-top: 15px; padding: 15px; background: #fef3c7; border-radius: 8px; text-align: left; max-width: 540px;">
                                <p style="font-weight: 600; color: #92400e; margin-bottom: 8px;">Troubleshooting:</p>
                                <ul style="margin: 0; padding-left: 20px; color: #78350f; font-size: 14px; line-height: 1.6;">
                                    <li><strong>Different HR provider?</strong> Go to <a href="oauth_settings.php">SSO Settings</a> and set your correct <strong>OAuth Provider URL</strong> (e.g. <code>https://your-hr-system.edu</code>).</li>
                                    <li><strong>Token expired?</strong> Log out and log in again via SSO.</li>
                                    <li><strong>HR API not reachable?</strong> Verify that <code>/api/research/coordinators</code>, <code>/api/designations</code>, or <code>/api/employees</code> is accessible at your HR URL.</li>
                                    <li><strong>No coordinators in HR?</strong> Ensure employees have position "Research Coordinator" or code <code>RES_COORD</code> in your HR system.</li>
                                </ul>
                                <?php 
                                $hrConfig = getOAuthConfig($conn);
                                $currentUrl = rtrim($hrConfig['provider_url'] ?? '', '/');
                                if (!empty($currentUrl)): ?>
                                <p style="margin-top: 10px; font-size: 13px; color: #92400e;"><strong>Current HR URL:</strong> <code><?= htmlspecialchars($currentUrl) ?></code></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Unit</th>
                                <th>Email</th>
                                <th>HR Status</th>
                                <th>Assigned Types</th>
                                <th>Management Scope</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employees as $emp): 
                                $empId = $emp['id'] ?? '';
                                $assignedData = $assignedCoordinators[$empId] ?? [];
                                $assignedTypes = $assignedData['types'] ?? [];
                                $isAssigned = !empty($assignedTypes);
                                $scopeMode = $assignedData['scope_mode'] ?? 'own_unit';
                                $assignedScopes = $assignedData['scopes'] ?? [];
                                $hrUnitId = $emp['unit']['id'] ?? $assignedData['hr_unit_id'] ?? '';
                                $hrUnitName = $emp['unit']['name'] ?? $assignedData['hr_unit_name'] ?? '';
                                $unitType = strtolower(trim($emp['unit']['unit_type'] ?? $emp['unit']['type'] ?? ''));
                                $isOffice = in_array($unitType, ['office', 'administrative', 'admin']);
                                $hrStatus = $emp['hr_status'] ?? 'active';
                                $isPositionChanged = ($hrStatus === 'position_changed');
                                $name = $emp['name'] ?? [];
                                // Use full_name if available, otherwise construct from parts
                                $fullName = $name['full_name'] ?? '';
                                if (empty($fullName)) {
                                    $fullName = trim(($name['first_name'] ?? '') . ' ' . ($name['middle_name'] ?? '') . ' ' . ($name['surname'] ?? ''));
                                }
                                if (empty($fullName)) {
                                    $fullName = 'N/A';
                                }
                            ?>
                                <tr class="<?= $isPositionChanged ? 'row-position-changed' : '' ?>">
                                    <td><strong><?= s($empId) ?></strong></td>
                                    <td>
                                        <?= s($fullName) ?>
                                        <?php if ($isPositionChanged): ?>
                                            <div class="position-changed-note">
                                                <i class="fa fa-exclamation-triangle"></i> No longer Research Coordinator
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= s($emp['position']['name'] ?? 'N/A') ?></td>
                                    <td>
                                        <?= s($emp['unit']['name'] ?? ($emp['sector']['name'] ?? 'N/A')) ?>
                                        <?php if ($isOffice): ?>
                                            <span class="badge badge-office" style="margin-left: 5px;"><i class="fa fa-building"></i> Office</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= s($emp['contact']['email'] ?? 'N/A') ?></td>
                                    <td>
                                        <?php if ($hrStatus === 'active'): ?>
                                            <span class="badge badge-hr-active">
                                                <i class="fa fa-check-circle"></i> Active
                                            </span>
                                        <?php elseif ($hrStatus === 'position_changed'): ?>
                                            <span class="badge badge-hr-position-changed">
                                                <i class="fa fa-exchange-alt"></i> Position Changed
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-hr-inactive">
                                                <i class="fa fa-times-circle"></i> Inactive
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($isAssigned && !$isPositionChanged): ?>
                                            <?php foreach ($assignedTypes as $type): ?>
                                                <span class="badge badge-type badge-<?= $type ?>">
                                                    <?php if ($type === 'faculty'): ?>
                                                        <i class="fa fa-chalkboard-user"></i>
                                                    <?php elseif ($type === 'student'): ?>
                                                        <i class="fa fa-user-graduate"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-building"></i>
                                                    <?php endif; ?>
                                                    <?= ucfirst($type) ?>
                                                </span>
                                            <?php endforeach; ?>
                                        <?php elseif ($isPositionChanged): ?>
                                            <span class="badge badge-unassigned" style="background: #fef3c7; color: #92400e;">
                                                <i class="fa fa-ban"></i> Deactivated
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-unassigned">
                                                <i class="fa fa-times"></i> Not Assigned
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($isAssigned && !$isPositionChanged): ?>
                                            <?php if ($scopeMode === 'own_unit'): ?>
                                                <span class="badge badge-scope badge-scope-own">
                                                    <i class="fa fa-home"></i> Own Unit
                                                </span>
                                                <div class="scope-detail"><?= s($hrUnitName ?: 'HR Unit') ?></div>
                                            <?php elseif ($scopeMode === 'specific_units'): ?>
                                                <span class="badge badge-scope badge-scope-specific">
                                                    <i class="fa fa-list-check"></i> Specific Units
                                                </span>
                                                <?php if (!empty($assignedScopes)): ?>
                                                    <div class="scope-detail">
                                                        <?php 
                                                        $scopeNames = array_map(function($s) { return $s['name']; }, $assignedScopes);
                                                        $displayCount = min(2, count($scopeNames));
                                                        echo s(implode(', ', array_slice($scopeNames, 0, $displayCount)));
                                                        if (count($scopeNames) > $displayCount) {
                                                            echo ' <span class="scope-more">+' . (count($scopeNames) - $displayCount) . ' more</span>';
                                                        }
                                                        ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php elseif ($isPositionChanged): ?>
                                            <span style="color: #9ca3af;">—</span>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">Not assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!$isPositionChanged): ?>
                                            <button class="btn btn-assign" onclick="openAssignModal(<?= htmlspecialchars(json_encode([
                                                'employeeId' => $empId,
                                                'employeeName' => $fullName,
                                                'assignedTypes' => $assignedTypes,
                                                'isOffice' => $isOffice,
                                                'scopeMode' => $scopeMode,
                                                'assignedScopes' => $assignedScopes,
                                                'hrUnitId' => $hrUnitId,
                                                'hrUnitName' => $hrUnitName,
                                                'unitType' => $unitType
                                            ])) ?>)">
                                                <i class="fa fa-<?= $isAssigned ? 'edit' : 'plus' ?>"></i> <?= $isAssigned ? 'Edit' : 'Assign' ?>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: #9ca3af; font-size: 13px;">
                                                <i class="fa fa-lock"></i> Locked
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Assign Coordinator Modal -->
    <div class="modal-overlay" id="assignModal">
        <div class="modal">
            <div class="modal-header">
                <h3><i class="fa fa-user-tie"></i> Assign Coordinator</h3>
                <button class="modal-close" onclick="closeAssignModal()">&times;</button>
            </div>
            <div class="modal-body" style="max-height: 75vh; overflow-y: auto;">
                <div class="modal-employee-info" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <p style="margin-bottom: 4px;">Employee:</p>
                        <strong id="modalEmployeeName" style="font-size: 18px;">-</strong>
                        <span id="modalEmployeeUnit" style="display: block; font-size: 13px; color: #6b7280; margin-top: 4px;"></span>
                    </div>
                    <input type="hidden" id="modalEmployeeId" value="">
                    <input type="hidden" id="modalIsOffice" value="false">
                    <input type="hidden" id="modalHrUnitId" value="">
                    <input type="hidden" id="modalHrUnitName" value="">
                </div>
                
                <!-- Section 1: Coordinator Types -->
                <div class="modal-section">
                    <h4 style="margin-bottom: 12px; color: #374151; font-size: 14px; font-weight: 600;">
                        <i class="fa fa-user-tag" style="color: #6b7280;"></i> 1. Coordinator Type(s)
                        <span style="font-weight: 400; font-size: 12px; color: #6b7280;">— Who they can manage</span>
                    </h4>
                    
                    <div class="checkbox-group">
                        <div class="checkbox-item" id="facultyItem" onclick="toggleCheckbox('faculty')">
                            <input type="checkbox" id="chkFaculty" name="coordinator_types[]" value="faculty">
                            <div class="checkbox-item-content">
                                <label for="chkFaculty">
                                    <i class="fa fa-chalkboard-user" style="color: #1e40af;"></i>
                                    Faculty Research Coordinator
                                </label>
                                <p>Can manage faculty researchers and their research outputs</p>
                            </div>
                        </div>
                        
                        <div class="checkbox-item" id="studentItem" onclick="toggleCheckbox('student')">
                            <input type="checkbox" id="chkStudent" name="coordinator_types[]" value="student">
                            <div class="checkbox-item-content">
                                <label for="chkStudent">
                                    <i class="fa fa-user-graduate" style="color: #92400e;"></i>
                                    Student Research Coordinator
                                </label>
                                <p>Can manage student researchers and their research outputs</p>
                            </div>
                        </div>
                        
                        <div class="checkbox-item" id="personnelItem" onclick="toggleCheckbox('personnel')">
                            <input type="checkbox" id="chkPersonnel" name="coordinator_types[]" value="personnel">
                            <div class="checkbox-item-content">
                                <label for="chkPersonnel">
                                    <i class="fa fa-building" style="color: #3730a3;"></i>
                                    Personnel Research Coordinator
                                </label>
                                <p>Can manage non-academic / personnel researchers</p>
                                <p class="restriction-note" id="personnelRestriction" style="display: none;">
                                    <i class="fa fa-exclamation-triangle"></i> Personnel coordinators are typically assigned to employees from office/administrative units.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Section 2: Management Scope -->
                <div class="modal-section" id="scopeSection" style="margin-top: 20px; display: none;">
                    <h4 style="margin-bottom: 12px; color: #374151; font-size: 14px; font-weight: 600;">
                        <i class="fa fa-sitemap" style="color: #6b7280;"></i> 2. Management Scope
                        <span style="font-weight: 400; font-size: 12px; color: #6b7280;">— Where they can manage researchers</span>
                    </h4>
                    
                    <div class="scope-options">
                        <!-- Own Unit (Default) -->
                        <div class="scope-option selected" id="scopeOwnUnit" onclick="selectScopeMode('own_unit')">
                            <input type="radio" name="scope_mode" value="own_unit" id="radioOwnUnit" checked>
                            <div class="scope-option-content">
                                <label for="radioOwnUnit">
                                    <i class="fa fa-home" style="color: #1e40af;"></i>
                                    Own Unit Only
                                    <span class="scope-badge-default">Default</span>
                                </label>
                                <p>Manage researchers within their HR unit only</p>
                                <div class="scope-unit-display" id="ownUnitDisplay">
                                    <i class="fa fa-building"></i> <span id="ownUnitName">-</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Specific Units -->
                        <div class="scope-option" id="scopeSpecificUnits" onclick="selectScopeMode('specific_units')">
                            <input type="radio" name="scope_mode" value="specific_units" id="radioSpecificUnits">
                            <div class="scope-option-content">
                                <label for="radioSpecificUnits">
                                    <i class="fa fa-list-check" style="color: #065f46;"></i>
                                    Specific Units
                                </label>
                                <p>Choose specific units to manage</p>
                            </div>
                        </div>
                        
                    </div>
                    
                    <!-- Unit Selector (shown when Specific Units is selected) -->
                    <div class="unit-selector" id="unitSelector" style="display: none; margin-top: 15px; padding: 15px; background: #f9fafb; border-radius: 10px; border: 1px solid #e5e7eb;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 10px;">
                            <h5 style="margin: 0; font-size: 14px; font-weight: 600; color: #374151;">
                                <i class="fa fa-list-check" style="color: #065f46;"></i> Select Units
                            </h5>
                            <div style="display: flex; gap: 8px;">
                                <button type="button" class="btn btn-sm btn-outline" onclick="selectAllVisibleUnits()">
                                    <i class="fa fa-check-square"></i> Select All
                                </button>
                                <button type="button" class="btn btn-sm btn-outline" onclick="deselectAllUnits()">
                                    <i class="fa fa-square"></i> Deselect All
                                </button>
                            </div>
                        </div>
                        <div class="unit-search" style="margin-bottom: 10px;">
                            <input type="text" id="unitSearchInput" placeholder="Search units by name..." oninput="filterUnits()" style="width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                        </div>
                        <div class="unit-type-filter" id="unitTypeFilter" style="margin-bottom: 10px;">
                            <span id="filterCollegesWrapper" style="display: inline-flex; align-items: center; gap: 5px; margin-right: 15px; font-size: 13px;">
                                <label style="display: inline-flex; align-items: center; gap: 5px; cursor: pointer;"><input type="checkbox" id="filterColleges" checked onchange="filterUnits()"> Colleges</label>
                            </span>
                            <span id="filterProgramsWrapper" style="display: inline-flex; align-items: center; gap: 5px; margin-right: 15px; font-size: 13px;">
                                <label style="display: inline-flex; align-items: center; gap: 5px; cursor: pointer;"><input type="checkbox" id="filterPrograms" checked onchange="filterUnits()"> Programs</label>
                            </span>
                            <span id="filterOfficesWrapper" style="display: inline-flex; align-items: center; gap: 5px; font-size: 13px;">
                                <label style="display: inline-flex; align-items: center; gap: 5px; cursor: pointer;"><input type="checkbox" id="filterOffices" checked onchange="filterUnits()"> Offices</label>
                            </span>
                            <button type="button" class="btn btn-sm" onclick="loadUnits()" style="margin-left: 15px;">
                                <i class="fa fa-sync"></i> Refresh Units
                            </button>
                            <span id="unitTypeFilterNote" style="display: none; margin-left: 10px; font-size: 12px; color: #6b7280; font-style: italic;"></span>
                        </div>
                        <div class="unit-list" id="unitList">
                            <div class="unit-list-empty">
                                <i class="fa fa-info-circle"></i> Click "Refresh Units" to fetch available units from HR System
                            </div>
                        </div>
                        <div class="selected-units" id="selectedUnitsContainer" style="margin-top: 10px; padding: 12px; background: white; border-radius: 6px; border: 1px solid #e5e7eb;">
                            <strong style="font-size: 13px; color: #374151;">Selected Units (<span id="selectedUnitsCount">0</span>):</strong>
                            <div id="selectedUnitsList" style="margin-top: 8px; font-size: 13px; color: #6b7280;">None selected</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-cancel" onclick="closeAssignModal()">Cancel</button>
                <button class="btn btn-save" onclick="saveCoordinatorAssignment()" id="btnSave">
                    <i class="fa fa-save"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
    
    <style>
        /* Additional Modal Styles for Scope Selection */
        .modal-section {
            border-top: 1px solid #e5e7eb;
            padding-top: 20px;
        }
        
        .scope-options {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        
        @media (max-width: 768px) {
            .scope-options {
                grid-template-columns: 1fr;
            }
        }
        
        .scope-option {
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            flex-direction: column;
        }
        
        .scope-option:hover {
            border-color: #3b82f6;
            background: #f8fafc;
        }
        
        .scope-option.selected {
            border-color: #3b82f6;
            background: #eff6ff;
        }
        
        .scope-option input[type="radio"] {
            margin-top: 3px;
            width: 18px;
            height: 18px;
            accent-color: #3b82f6;
        }
        
        .scope-option-content {
            flex: 1;
            width: 100%;
        }
        
        .scope-option-content label {
            font-weight: 600;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            flex-wrap: wrap;
        }
        
        .scope-option-content p {
            font-size: 13px;
            color: #6b7280;
            margin: 6px 0 0 0;
        }
        
        .scope-badge-default {
            background: #dbeafe;
            color: #1e40af;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: 600;
        }
        
        
        .scope-unit-display {
            margin-top: 10px;
            padding: 8px 12px;
            background: white;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
            font-size: 13px;
            color: #374151;
        }
        
        
        .unit-selector {
            margin-top: 12px;
            padding: 12px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .unit-search {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .unit-search input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 13px;
        }
        
        .unit-type-filter {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
            font-size: 13px;
        }
        
        .unit-type-filter label {
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }
        
        .unit-list {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            margin-bottom: 10px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1px;
            background: #e5e7eb;
        }
        
        .unit-list-empty {
            padding: 30px;
            text-align: center;
            color: #6b7280;
            font-size: 13px;
            grid-column: 1 / -1;
            background: white;
        }
        
        .unit-list-item {
            padding: 12px 14px;
            background: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: background 0.15s ease;
        }
        
        .unit-list-item:hover {
            background: #f9fafb;
        }
        
        .unit-list-item.selected {
            background: #eff6ff;
        }
        
        .unit-list-item input[type="checkbox"] {
            width: 16px;
            height: 16px;
            accent-color: #3b82f6;
            flex-shrink: 0;
        }
        
        .unit-list-item-info {
            flex: 1;
            min-width: 0;
        }
        
        .unit-list-item-name {
            font-weight: 500;
            color: #1f2937;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .unit-list-item-type {
            font-size: 11px;
            color: #6b7280;
            margin-top: 2px;
        }
        
        .selected-units {
            padding: 10px;
            background: #f9fafb;
            border-radius: 6px;
        }
        
        .selected-units strong {
            font-size: 12px;
            color: #374151;
        }
        
        #selectedUnitsList {
            margin-top: 8px;
            font-size: 13px;
            color: #6b7280;
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
        }
        
        .selected-unit-tag {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #dbeafe;
            color: #1e40af;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 12px;
            margin: 3px;
        }
        
        .selected-unit-tag .remove-unit {
            cursor: pointer;
            color: #3b82f6;
            font-weight: bold;
        }
        
        .selected-unit-tag .remove-unit:hover {
            color: #1d4ed8;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }
        
        .btn-outline {
            background: white;
            border: 1px solid #d1d5db;
            color: #374151;
        }
        
        .btn-outline:hover {
            background: #f3f4f6;
            border-color: #9ca3af;
        }
        
        .loading-spinner {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 2px solid #e5e7eb;
            border-top-color: #3b82f6;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
    
    <script>
        // =========================================================================
        // STATE MANAGEMENT (SPA-compatible: use var to allow redeclaration)
        // =========================================================================
        var currentEmployeeData = null;
        var originalTypes = [];
        var originalScopeMode = 'own_unit';
        var originalScopes = [];
        var selectedUnits = [];
        var allUnits = [];
        var unitsLoaded = false;
        
        // =========================================================================
        // MODAL FUNCTIONS
        // =========================================================================
        
        function openAssignModal(data) {
            // Handle both old format (separate params) and new format (object)
            if (typeof data === 'string') {
                // Legacy format - convert to object
                data = {
                    employeeId: arguments[0],
                    employeeName: arguments[1],
                    assignedTypes: arguments[2] || [],
                    isOffice: arguments[3] || false,
                    scopeMode: 'own_unit',
                    assignedScopes: [],
                    hrUnitId: '',
                    hrUnitName: ''
                };
            }
            
            currentEmployeeData = data;
            originalTypes = data.assignedTypes || [];
            originalScopeMode = data.scopeMode || 'own_unit';
            originalScopes = data.assignedScopes || [];
            selectedUnits = [...originalScopes];
            
            // Set modal fields
            document.getElementById('modalEmployeeId').value = data.employeeId;
            document.getElementById('modalEmployeeName').textContent = data.employeeName;
            document.getElementById('modalEmployeeUnit').textContent = data.hrUnitName ? `Unit: ${data.hrUnitName}` : '';
            document.getElementById('modalIsOffice').value = data.isOffice;
            document.getElementById('modalHrUnitId').value = data.hrUnitId || '';
            document.getElementById('modalHrUnitName').value = data.hrUnitName || '';
            document.getElementById('ownUnitName').textContent = data.hrUnitName || 'Employee\'s HR Unit';
            
            // Reset checkboxes
            ['faculty', 'student', 'personnel'].forEach(type => {
                const checkbox = document.getElementById('chk' + type.charAt(0).toUpperCase() + type.slice(1));
                const item = document.getElementById(type + 'Item');
                if (checkbox && item) {
                    checkbox.checked = false;
                    item.classList.remove('selected', 'disabled');
                }
            });
            
            // Set checkboxes based on assigned types
            originalTypes.forEach(type => {
                const checkbox = document.getElementById('chk' + type.charAt(0).toUpperCase() + type.slice(1));
                const item = document.getElementById(type + 'Item');
                if (checkbox && item) {
                    checkbox.checked = true;
                    item.classList.add('selected');
                }
            });
            
            // Handle personnel restriction
            const personnelItem = document.getElementById('personnelItem');
            const personnelRestriction = document.getElementById('personnelRestriction');
            const chkPersonnel = document.getElementById('chkPersonnel');
            
            if (!data.isOffice) {
                personnelRestriction.style.display = 'block';
            } else {
                personnelRestriction.style.display = 'none';
            }
            
            // Show/hide scope section based on whether any types are selected
            updateScopeSection();
            
            // Set scope mode
            selectScopeMode(originalScopeMode, false);
            
            // Update selected units display
            updateSelectedUnitsDisplay();
            
            document.getElementById('assignModal').classList.add('active');
        }
        
        function closeAssignModal() {
            document.getElementById('assignModal').classList.remove('active');
            currentEmployeeData = null;
        }
        
        function toggleCheckbox(type) {
            const item = document.getElementById(type + 'Item');
            const checkbox = document.getElementById('chk' + type.charAt(0).toUpperCase() + type.slice(1));
            
            if (item.classList.contains('disabled')) {
                return;
            }
            
            checkbox.checked = !checkbox.checked;
            item.classList.toggle('selected', checkbox.checked);
            
            // Update scope section visibility
            updateScopeSection();
        }
        
        function updateScopeSection() {
            const facultyChecked = document.getElementById('chkFaculty').checked;
            const studentChecked = document.getElementById('chkStudent').checked;
            const personnelChecked = document.getElementById('chkPersonnel').checked;
            
            const hasTypeSelected = facultyChecked || studentChecked || personnelChecked;
            
            const scopeSection = document.getElementById('scopeSection');
            scopeSection.style.display = hasTypeSelected ? 'block' : 'none';
            
            // Update unit type filters based on selected coordinator types
            updateUnitTypeFilters(facultyChecked, studentChecked, personnelChecked);
        }
        
        function updateUnitTypeFilters(facultyChecked, studentChecked, personnelChecked) {
            const collegesWrapper = document.getElementById('filterCollegesWrapper');
            const programsWrapper = document.getElementById('filterProgramsWrapper');
            const officesWrapper = document.getElementById('filterOfficesWrapper');
            const filterNote = document.getElementById('unitTypeFilterNote');
            
            const filterColleges = document.getElementById('filterColleges');
            const filterPrograms = document.getElementById('filterPrograms');
            const filterOffices = document.getElementById('filterOffices');
            
            // Determine which unit types should be available
            // Faculty/Student coordinators → Colleges and Programs
            // Personnel coordinators → Offices only
            
            const hasAcademic = facultyChecked || studentChecked;
            const hasPersonnel = personnelChecked;
            
            // Show/hide and check/uncheck filters based on coordinator types
            if (hasAcademic && !hasPersonnel) {
                // Only Faculty/Student selected - show only Colleges and Programs
                collegesWrapper.style.display = 'inline-flex';
                programsWrapper.style.display = 'inline-flex';
                officesWrapper.style.display = 'none';
                
                filterColleges.checked = true;
                filterPrograms.checked = true;
                filterOffices.checked = false;
                
                filterNote.style.display = 'inline';
                filterNote.textContent = '(Academic units only for Faculty/Student coordinators)';
            } else if (hasPersonnel && !hasAcademic) {
                // Only Personnel selected - show only Offices
                collegesWrapper.style.display = 'none';
                programsWrapper.style.display = 'none';
                officesWrapper.style.display = 'inline-flex';
                
                filterColleges.checked = false;
                filterPrograms.checked = false;
                filterOffices.checked = true;
                
                filterNote.style.display = 'inline';
                filterNote.textContent = '(Office units only for Personnel coordinators)';
            } else if (hasAcademic && hasPersonnel) {
                // Both academic and personnel selected - show all
                collegesWrapper.style.display = 'inline-flex';
                programsWrapper.style.display = 'inline-flex';
                officesWrapper.style.display = 'inline-flex';
                
                filterColleges.checked = true;
                filterPrograms.checked = true;
                filterOffices.checked = true;
                
                filterNote.style.display = 'none';
                filterNote.textContent = '';
            } else {
                // Nothing selected - show all (default state)
                collegesWrapper.style.display = 'inline-flex';
                programsWrapper.style.display = 'inline-flex';
                officesWrapper.style.display = 'inline-flex';
                
                filterColleges.checked = true;
                filterPrograms.checked = true;
                filterOffices.checked = true;
                
                filterNote.style.display = 'none';
                filterNote.textContent = '';
            }
            
            // Clear selected units that don't match the new filter criteria
            if (selectedUnits.length > 0) {
                const validSelectedUnits = selectedUnits.filter(unit => {
                    const unitType = (unit.type || '').toLowerCase();
                    const isCollege = unitType.includes('college') || unitType === 'unit';
                    const isProgram = unitType.includes('program') || unitType.includes('department');
                    const isOffice = unitType.includes('office') || unitType.includes('admin');
                    
                    if (hasAcademic && !hasPersonnel) {
                        return isCollege || isProgram;
                    } else if (hasPersonnel && !hasAcademic) {
                        return isOffice;
                    }
                    return true; // Keep all if both or neither selected
                });
                
                if (validSelectedUnits.length !== selectedUnits.length) {
                    selectedUnits = validSelectedUnits;
                    updateSelectedUnitsDisplay();
                }
            }
            
            // Re-render unit list if already loaded
            if (unitsLoaded) {
                renderUnitList();
            }
        }
        
        // =========================================================================
        // SCOPE FUNCTIONS
        // =========================================================================
        
        function selectScopeMode(mode, triggerUnitSelector = true) {
            // Update radio buttons and styling
            document.querySelectorAll('.scope-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            const scopeOpt = document.getElementById('scope' + mode.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''));
            if (scopeOpt) {
                scopeOpt.classList.add('selected');
            }
            
            // Update radio button
            const radio = document.querySelector(`input[name="scope_mode"][value="${mode}"]`);
            if (radio) {
                radio.checked = true;
            }
            
            // Show/hide unit selector
            const unitSelector = document.getElementById('unitSelector');
            if (mode === 'specific_units') {
                unitSelector.style.display = 'block';
                if (triggerUnitSelector && !unitsLoaded) {
                    loadUnits();
                }
            } else {
                unitSelector.style.display = 'none';
            }
        }
        
        async function loadUnits() {
            const unitList = document.getElementById('unitList');
            unitList.innerHTML = '<div class="unit-list-empty"><span class="loading-spinner"></span> Loading units...</div>';
            
            try {
                // Pass current employee ID to exclude units assigned to OTHER coordinators
                const currentEmployeeId = currentEmployeeData?.employeeId || '';
                const response = await fetch('assign_coordinator_api.php?action=get_units&for_employee_id=' + encodeURIComponent(currentEmployeeId));
                
                // Check if response is OK
                if (!response.ok) {
                    throw new Error('Server returned ' + response.status);
                }
                
                const text = await response.text();
                
                // Try to parse as JSON
                let result;
                try {
                    result = JSON.parse(text);
                } catch (e) {
                    console.error('Invalid JSON response:', text.substring(0, 200));
                    throw new Error('Server returned invalid response. Check if HR integration is configured.');
                }
                
                if (!result.success) {
                    throw new Error(result.error || 'Failed to load units');
                }
                
                allUnits = result.data || [];
                unitsLoaded = true;
                
                // Track excluded units info for display
                const excludedCount = result.excluded_units || 0;
                const excludedDetails = result.excluded_details || {};
                
                if (allUnits.length === 0 && excludedCount === 0) {
                    unitList.innerHTML = '<div class="unit-list-empty"><i class="fa fa-info-circle"></i> No units found. Add researchers first or configure HR integration.</div>';
                    return;
                }
                
                if (allUnits.length === 0 && excludedCount > 0) {
                    unitList.innerHTML = '<div class="unit-list-empty" style="color: #92400e;"><i class="fa fa-exclamation-triangle"></i> All available units are already assigned to other coordinators.</div>';
                    return;
                }
                
                // Show source info and excluded units notice
                let sourceInfo = '';
                if (result.source === 'local') {
                    sourceInfo += '<div style="font-size: 11px; color: #6b7280; margin-bottom: 8px; padding: 5px; background: #fef3c7; border-radius: 4px;"><i class="fa fa-info-circle"></i> Showing units from local data (HR API unavailable)</div>';
                }
                if (excludedCount > 0) {
                    sourceInfo += '<div style="font-size: 11px; color: #92400e; margin-bottom: 8px; padding: 8px; background: #fef3c7; border-radius: 4px; border-left: 3px solid #f59e0b;"><i class="fa fa-lock"></i> <strong>' + excludedCount + ' unit(s)</strong> already assigned to other coordinators are hidden. Each unit can only be managed by one coordinator.</div>';
                }
                
                renderUnitList(sourceInfo);
                
            } catch (error) {
                console.error('Load units error:', error);
                unitList.innerHTML = `<div class="unit-list-empty" style="color: #ef4444;"><i class="fa fa-exclamation-circle"></i> ${error.message}</div>`;
            }
        }
        
        let unitSourceInfo = '';
        
        function renderUnitList(sourceInfo = null) {
            if (sourceInfo !== null) {
                unitSourceInfo = sourceInfo;
            }
            
            const unitList = document.getElementById('unitList');
            const searchTerm = (document.getElementById('unitSearchInput').value || '').toLowerCase();
            const showColleges = document.getElementById('filterColleges').checked;
            const showPrograms = document.getElementById('filterPrograms').checked;
            const showOffices = document.getElementById('filterOffices').checked;
            
            const filteredUnits = allUnits.filter(unit => {
                // Search filter
                const matchesSearch = !searchTerm || 
                    (unit.name || '').toLowerCase().includes(searchTerm) ||
                    (unit.code || '').toLowerCase().includes(searchTerm);
                
                // Type filter - be more lenient
                const unitType = (unit.type || '').toLowerCase();
                const matchesType = 
                    (showColleges && (unitType.includes('college') || unitType === 'unit')) ||
                    (showPrograms && (unitType.includes('program') || unitType.includes('department'))) ||
                    (showOffices && (unitType.includes('office') || unitType.includes('admin'))) ||
                    (!unitType) || // Show units without type
                    (showColleges && showPrograms && showOffices); // Show all if all filters checked
                
                return matchesSearch && matchesType;
            });
            
            if (filteredUnits.length === 0) {
                unitList.innerHTML = unitSourceInfo + '<div class="unit-list-empty"><i class="fa fa-search"></i> No units match your filters</div>';
                return;
            }
            
            unitList.innerHTML = unitSourceInfo + filteredUnits.map(unit => {
                const isSelected = selectedUnits.some(s => s.id === unit.id);
                return `
                    <div class="unit-list-item ${isSelected ? 'selected' : ''}" onclick="toggleUnit('${unit.id}', '${escapeHtml(unit.name)}', '${escapeHtml(unit.type || '')}')">
                        <input type="checkbox" ${isSelected ? 'checked' : ''} onclick="event.stopPropagation(); toggleUnit('${unit.id}', '${escapeHtml(unit.name)}', '${escapeHtml(unit.type || '')}')">
                        <div class="unit-list-item-info">
                            <div class="unit-list-item-name">${escapeHtml(unit.name)}</div>
                            <div class="unit-list-item-type">${escapeHtml(unit.type || 'Unit')} ${unit.code ? '(' + unit.code + ')' : ''}</div>
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        function filterUnits() {
            if (unitsLoaded) {
                renderUnitList();
            }
        }
        
        function selectAllVisibleUnits() {
            if (!unitsLoaded || allUnits.length === 0) {
                alert('Please load units first by clicking "Load Units"');
                return;
            }
            
            const searchTerm = document.getElementById('unitSearchInput').value.toLowerCase();
            const showColleges = document.getElementById('filterColleges').checked;
            const showPrograms = document.getElementById('filterPrograms').checked;
            const showOffices = document.getElementById('filterOffices').checked;
            
            // Get visible/filtered units
            const visibleUnits = allUnits.filter(unit => {
                const unitType = (unit.type || '').toLowerCase();
                const matchesType = (showColleges && unitType === 'college') ||
                                   (showPrograms && unitType === 'program') ||
                                   (showOffices && (unitType === 'office' || unitType === 'administrative'));
                const matchesSearch = !searchTerm || 
                                     (unit.name || '').toLowerCase().includes(searchTerm) ||
                                     (unit.code || '').toLowerCase().includes(searchTerm);
                return matchesType && matchesSearch;
            });
            
            // Add all visible units that aren't already selected
            visibleUnits.forEach(unit => {
                const exists = selectedUnits.some(u => u.id === unit.id);
                if (!exists) {
                    selectedUnits.push({ id: unit.id, name: unit.name, type: unit.type || '' });
                }
            });
            
            renderUnitList();
            updateSelectedUnitsDisplay();
        }
        
        function deselectAllUnits() {
            selectedUnits = [];
            renderUnitList();
            updateSelectedUnitsDisplay();
        }
        
        function toggleUnit(unitId, unitName, unitType) {
            const index = selectedUnits.findIndex(u => u.id === unitId);
            
            if (index > -1) {
                selectedUnits.splice(index, 1);
            } else {
                selectedUnits.push({ id: unitId, name: unitName, type: unitType });
            }
            
            renderUnitList();
            updateSelectedUnitsDisplay();
        }
        
        function removeUnit(unitId) {
            selectedUnits = selectedUnits.filter(u => u.id !== unitId);
            renderUnitList();
            updateSelectedUnitsDisplay();
        }
        
        function updateSelectedUnitsDisplay() {
            const container = document.getElementById('selectedUnitsList');
            const countEl = document.getElementById('selectedUnitsCount');
            
            // Update count
            if (countEl) {
                countEl.textContent = selectedUnits.length;
            }
            
            if (selectedUnits.length === 0) {
                container.innerHTML = '<span style="color: #9ca3af;">None selected</span>';
                return;
            }
            
            container.innerHTML = selectedUnits.map(unit => `
                <span class="selected-unit-tag">
                    ${escapeHtml(unit.name)}
                    <span class="remove-unit" onclick="removeUnit('${unit.id}')">&times;</span>
                </span>
            `).join('');
        }
        
        function escapeHtml(str) {
            if (!str) return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }
        
        // =========================================================================
        // SAVE FUNCTION
        // =========================================================================
        
        async function saveCoordinatorAssignment() {
            const selectedTypes = [];
            if (document.getElementById('chkFaculty').checked) selectedTypes.push('faculty');
            if (document.getElementById('chkStudent').checked) selectedTypes.push('student');
            if (document.getElementById('chkPersonnel').checked) selectedTypes.push('personnel');
            
            const scopeMode = document.querySelector('input[name="scope_mode"]:checked')?.value || 'own_unit';
            
            // Validate
            if (selectedTypes.length === 0) {
                // If no types selected, remove all assignments
                if (originalTypes.length === 0) {
                    closeAssignModal();
                    return;
                }
            }
            
            // Validate scope for specific_units
            if (selectedTypes.length > 0 && scopeMode === 'specific_units' && selectedUnits.length === 0) {
                alert('Please select at least one unit for the "Specific Units" scope mode.');
                return;
            }
            
            const btnSave = document.getElementById('btnSave');
            const originalBtnText = btnSave.innerHTML;
            btnSave.innerHTML = '<span class="loading-spinner"></span> Saving...';
            btnSave.disabled = true;
            
            try {
                const formData = new FormData();
                formData.append('action', 'bulk_update');
                formData.append('employee_id', currentEmployeeData.employeeId);
                formData.append('types', JSON.stringify(selectedTypes));
                formData.append('scope_mode', scopeMode);
                formData.append('scope_units', JSON.stringify(selectedUnits));
                formData.append('hr_unit_id', currentEmployeeData.hrUnitId || '');
                formData.append('hr_unit_name', currentEmployeeData.hrUnitName || '');
                
                const response = await fetch('assign_coordinator_api.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (!result.success) {
                    throw new Error(result.error || 'Failed to save assignment');
                }
                
                // Show success message with saved types
                console.log('Coordinator assignment saved:', result);
                
                // Display detailed info if available
                if (result.data && result.data.saved_types) {
                    const savedTypes = result.data.saved_types;
                    const typesStr = savedTypes.map(t => t.charAt(0).toUpperCase() + t.slice(1)).join(', ');
                    console.log('Saved coordinator types:', typesStr);
                }
                
                // Success - reload page
                location.reload();
                
            } catch (error) {
                alert('Error: ' + error.message);
                btnSave.innerHTML = originalBtnText;
                btnSave.disabled = false;
            }
        }
        
        // =========================================================================
        // EVENT LISTENERS
        // =========================================================================
        
        // Close modal when clicking outside
        document.getElementById('assignModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeAssignModal();
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeAssignModal();
            }
        });
    </script>
<?php if (!$isSpa): ?>
</div><!-- close .main -->
</body>
</html>
<?php endif; ?>
