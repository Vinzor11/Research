/**
 * ============================================
 * STUDENT RESEARCHER FORM - JAVASCRIPT
 * ============================================
 * File: studentresearcherformscript.js
 * Purpose: Client-side validation and UI enhancements
 * 
 * Features:
 * - Auto-format mobile numbers (09XX-XXX-XXXX)
 * - Validate email addresses
 * - Validate Philippine mobile numbers
 * - Real-time form validation
 * - Prevent double form submission
 * - Auto-capitalize name fields
 * - Display inline error messages
 * - Warn about unsaved changes
 * 
 * Dependencies: None (vanilla JavaScript)
 * Compatible with: Modern browsers (ES6+)
 * ============================================
 */

// Wait for DOM to fully load before executing scripts
document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // GET FORM ELEMENTS
    // ============================================
    const form = document.getElementById('studentForm');
    const submitBtn = document.getElementById('submitBtn');
    const mobileInput = document.getElementById('mobile');
    const emailInput = document.getElementById('email');
    const studentNumberInput = document.getElementById('student_number');
    
    // ============================================
    // MOBILE NUMBER AUTO-FORMATTING
    // ============================================
    if (mobileInput) {
        mobileInput.addEventListener('input', function(e) {
            // Remove all non-numeric characters
            let value = e.target.value.replace(/\D/g, '');
            
            // Limit to 11 digits (Philippine mobile number format)
            if (value.length > 11) {
                value = value.slice(0, 11);
            }
            
            // Format as 09XX-XXX-XXXX
            let formatted = '';
            if (value.length > 0) {
                formatted = value.slice(0, 4); // First 4 digits
                
                if (value.length > 4) {
                    formatted += '-' + value.slice(4, 7); // Next 3 digits
                }
                
                if (value.length > 7) {
                    formatted += '-' + value.slice(7, 11); // Last 4 digits
                }
            }
            
            // Update input value with formatted number
            e.target.value = formatted;
        });
        
        // Validate mobile number format on blur (when user leaves the field)
        mobileInput.addEventListener('blur', function(e) {
            const value = e.target.value.replace(/\D/g, '');
            
            // Check if it's a valid Philippine mobile number (starts with 09 and has 11 digits)
            if (value.length > 0 && (value.length !== 11 || !value.startsWith('09'))) {
                e.target.style.borderColor = '#b00020';
                showValidationMessage(e.target, 'Please enter a valid Philippine mobile number (09XX-XXX-XXXX)');
            } else {
                e.target.style.borderColor = '#ccc';
                hideValidationMessage(e.target);
            }
        });
    }
    
    // ============================================
    // EMAIL VALIDATION
    // ============================================
    if (emailInput) {
        emailInput.addEventListener('blur', function(e) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (e.target.value && !emailPattern.test(e.target.value)) {
                e.target.style.borderColor = '#b00020';
                showValidationMessage(e.target, 'Please enter a valid email address');
            } else {
                e.target.style.borderColor = '#ccc';
                hideValidationMessage(e.target);
            }
        });
    }
    
    // ============================================
    // STUDENT NUMBER FORMAT HELPER
    // ============================================
    if (studentNumberInput) {
        // Add placeholder text on focus
        studentNumberInput.addEventListener('focus', function(e) {
            if (!e.target.value) {
                e.target.placeholder = 'e.g., 2021-00000';
            }
        });
    }
    
    // ============================================
    // FORM SUBMISSION VALIDATION
    // ============================================
    if (form) {
        form.addEventListener('submit', function(e) {
            // Get all required fields
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            let firstInvalidField = null;
            
            // Check each required field
            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#b00020';
                    
                    // Store first invalid field to focus on it
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                } else {
                    field.style.borderColor = '#ccc';
                }
            });
            
            // If form is invalid, prevent submission and focus on first invalid field
            if (!isValid) {
                e.preventDefault();
                if (firstInvalidField) {
                    firstInvalidField.focus();
                    showValidationMessage(firstInvalidField, 'This field is required');
                }
                
                // Show alert message
                alert('Please fill in all required fields marked with *');
                return false;
            }
            
            // Validate mobile number format before submission
            if (mobileInput) {
                const mobileValue = mobileInput.value.replace(/\D/g, '');
                if (mobileValue.length !== 11 || !mobileValue.startsWith('09')) {
                    e.preventDefault();
                    mobileInput.focus();
                    mobileInput.style.borderColor = '#b00020';
                    showValidationMessage(mobileInput, 'Please enter a valid Philippine mobile number');
                    return false;
                }
            }
            
            // Disable submit button to prevent double submission
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
            }
            
            // Form is valid, allow submission
            return true;
        });
    }
    
    // ============================================
    // AUTO-CAPITALIZE NAME FIELDS
    // ============================================
    const nameFields = ['last_name', 'first_name', 'middle_name'];
    nameFields.forEach(function(fieldId) {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', function(e) {
                // Capitalize first letter of each word
                e.target.value = e.target.value
                    .split(' ')
                    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                    .join(' ');
            });
        }
    });
    
    // ============================================
    // CLEAR VALIDATION ERRORS ON INPUT
    // ============================================
    const allInputs = form.querySelectorAll('input');
    allInputs.forEach(function(input) {
        input.addEventListener('input', function(e) {
            if (e.target.value.trim()) {
                e.target.style.borderColor = '#ccc';
                hideValidationMessage(e.target);
            }
        });
    });
    
    // ============================================
    // HELPER FUNCTIONS
    // ============================================
    
    /**
     * Show validation error message below an input field
     * @param {HTMLElement} element - The input element
     * @param {string} message - The error message to display
     */
    function showValidationMessage(element, message) {
        // Remove existing message if any
        hideValidationMessage(element);
        
        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'validation-error';
        errorDiv.style.color = '#b00020';
        errorDiv.style.fontSize = '12px';
        errorDiv.style.marginTop = '4px';
        errorDiv.textContent = message;
        
        // Insert after the input field
        element.parentNode.insertBefore(errorDiv, element.nextSibling);
    }
    
    /**
     * Hide validation error message
     * @param {HTMLElement} element - The input element
     */
    function hideValidationMessage(element) {
        const errorDiv = element.nextSibling;
        if (errorDiv && errorDiv.className === 'validation-error') {
            errorDiv.remove();
        }
    }
    
    // ============================================
    // UNSAVED CHANGES WARNING
    // ============================================
    let formChanged = false;
    
    // Track if form has been modified
    if (form) {
        form.addEventListener('change', function() {
            formChanged = true;
        });
        
        // Warn user if they try to leave with unsaved changes
        window.addEventListener('beforeunload', function(e) {
            if (formChanged) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
                return e.returnValue;
            }
        });
        
        // Don't show warning when form is submitted
        form.addEventListener('submit', function() {
            formChanged = false;
        });
    }
    
    console.log('Student Researcher Form - JavaScript loaded successfully');
});
