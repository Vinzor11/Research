// ============================================
// FILE UPLOAD FUNCTIONS
// ============================================

/**
 * Display file information when a file is selected
 * Shows file name, size, and validates against 50MB limit
 * @param {HTMLInputElement} input - The file input element
 */
function displayFileInfo(input) {
    const fileInfo = document.getElementById('fileInfo');
    
    // Check if a file has been selected
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
        fileInfo.textContent = `Selected: ${file.name} (${sizeMB} MB)`;
        
        // Validate file size (50MB maximum)
        if (file.size > 50 * 1024 * 1024) {
            fileInfo.style.color = 'var(--danger)';
            fileInfo.textContent += ' - WARNING: Exceeds 50MB limit!';
        } else {
            fileInfo.style.color = 'var(--success)';
        }
    } else {
        // Clear info if no file selected
        fileInfo.textContent = '';
    }
}

// ============================================
// MODAL FUNCTIONS
// ============================================

/**
 * Open the upload modal for new output or revision
 * @param {number|null} parentOutputId - ID of parent output if this is a revision, null for new upload
 */
function openUploadModal(parentOutputId = null) {
    // Set parent output ID (for revisions)
    document.getElementById('parent_output_id').value = parentOutputId || '';
    
    // Reset form fields
    document.getElementById('output_title').value = '';
    document.getElementById('output_file').value = '';
    document.getElementById('fileInfo').textContent = '';
    
    // Update modal title based on whether this is a new upload or revision
    if (parentOutputId) {
        document.getElementById('uploadModalTitle').textContent = 'Upload Revised Output';
    } else {
        document.getElementById('uploadModalTitle').textContent = 'Upload Research Output';
    }
    
    // Show the modal
    document.getElementById('uploadModal').style.display = 'block';
}

/**
 * Open the review modal for reviewing a research output
 * @param {number} outputId - ID of the output to review
 * @param {string} outputTitle - Title of the output being reviewed
 */
function openReviewModal(outputId, outputTitle) {
    // Set the output ID and title in the form
    document.getElementById('review_output_id').value = outputId;
    document.getElementById('review_output_title').textContent = outputTitle;
    
    // Show the modal
    document.getElementById('reviewModal').style.display = 'block';
}

/**
 * View version history for a research output
 * Fetches all versions via AJAX and displays them in a modal
 * @param {number} outputId - ID of the output to view history for
 */
function viewVersionHistory(outputId) {
    const modal = document.getElementById('versionHistoryModal');
    const content = document.getElementById('versionHistoryContent');
    
    // Show loading indicator
    content.innerHTML = '<p style="text-align:center; padding:40px;"><i class="fa fa-spinner fa-spin fa-2x"></i><br><br>Loading version history...</p>';
    modal.style.display = 'block';
    
    // Get project_id from current page URL
    const urlParams = new URLSearchParams(window.location.search);
    const projectId = urlParams.get('project_id');
    
    // Fetch version history from server
    fetch(`get_version_history.php?output_id=${outputId}&project_id=${projectId}`)
        .then(response => response.json())
        .then(data => {
            // Check if versions were returned
            if (data.success && data.versions.length > 0) {
                let html = '<div style="max-height: 500px; overflow-y: auto; padding: 10px;">';
                
                // Loop through each version and build HTML
                data.versions.forEach(version => {
                    const statusClass = 'status-' + version.output_status;
                    const statusText = version.output_status.replace('_', ' ').toUpperCase();
                    
                    // Mark current/latest version
                    const isCurrent = version.is_latest_version == 1 ? 
                        '<span style="background:var(--success);color:white;padding:4px 12px;border-radius:20px;font-size:11px;margin-left:10px;font-weight:700;">CURRENT</span>' : '';
                    
                    // Build version card HTML
                    html += `
                        <div style="border: 2px solid #e2e8f0; border-radius: 12px; padding: 25px; margin-bottom: 20px; background: white; box-shadow: var(--shadow);">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px;">
                                <div>
                                    <strong style="font-size: 20px; color: var(--primary);">Version ${version.version}</strong> ${isCurrent}
                                    <div style="color: var(--gray); font-size: 14px; margin-top: 8px; font-weight: 600;">
                                        ${version.output_title}
                                    </div>
                                </div>
                                <span class="status-badge ${statusClass}">${statusText}</span>
                            </div>
                            <div style="font-size: 13px; color: var(--gray); margin-bottom: 15px; line-height: 2;">
                                <div><i class="fa fa-file"></i> <strong>${version.file_name}</strong> (${(version.file_size / 1024).toFixed(2)} KB)</div>
                                <div><i class="fa fa-clock"></i> Uploaded: ${new Date(version.upload_date).toLocaleString()}</div>
                                <div><i class="fa fa-user"></i> By: ${version.uploader_name}</div>
                            </div>
                            ${version.review_comments ? `
                                <div style="background: var(--gray-light); padding: 15px; border-radius: 10px; margin-top: 15px; border-left: 4px solid var(--primary);">
                                    <strong style="color: var(--dark);"><i class="fa fa-comment"></i> Review Comments:</strong>
                                    <p style="margin: 10px 0 0 0; color: var(--dark);">${version.review_comments}</p>
                                </div>
                            ` : ''}
                            <button class="btn btn-secondary btn-sm" onclick="downloadOutput('${version.file_path}', '${version.file_name}')" style="margin-top: 15px;">
                                <i class="fa fa-download"></i> Download v${version.version}
                            </button>
                        </div>
                    `;
                });
                html += '</div>';
                content.innerHTML = html;
            } else {
                // No versions found
                content.innerHTML = '<div class="no-data"><i class="fa fa-inbox"></i><p>No version history available.</p></div>';
            }
        })
        .catch(error => {
            // Error fetching version history
            content.innerHTML = '<div class="no-data" style="color: var(--danger);"><i class="fa fa-exclamation-triangle"></i><p>Error loading version history.</p></div>';
            console.error('Error:', error);
        });
}

/**
 * Close a modal by ID
 * @param {string} modalId - The ID of the modal to close
 */
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

/**
 * Download a research output file
 * Creates a temporary link and triggers download
 * @param {string} filePath - Path to the file
 * @param {string} fileName - Name of the file
 */
function downloadOutput(filePath, fileName) {
    const link = document.createElement('a');
    link.href = filePath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// ============================================
// EVENT LISTENERS
// ============================================

/**
 * Close modal when clicking outside of it (on the backdrop)
 */
window.onclick = function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
}

// ============================================
// FORM SUBMISSION HANDLERS
// ============================================

/**
 * Initialize form submission handlers when DOM is ready
 */
document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // UPLOAD FORM SUBMISSION
    // ============================================
    document.getElementById('uploadForm').onsubmit = function(e) {
        e.preventDefault();
        
        // Get form values
        const title = document.getElementById('output_title').value.trim();
        const fileInput = document.getElementById('output_file');
        const file = fileInput.files[0];
        
        // Validate title
        if (!title) {
            alert('Please enter an output title.');
            return false;
        }
        
        // Validate file selection
        if (!file) {
            alert('Please select a file to upload.');
            return false;
        }
        
        // Validate file size (50MB maximum)
        if (file.size > 50 * 1024 * 1024) {
            alert('File size exceeds 50MB limit. Please select a smaller file.');
            return false;
        }
        
        // Update button to show loading state
        const btn = document.getElementById('uploadBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Uploading...';
        btn.disabled = true;
        
        // Prepare form data for submission
        const formData = new FormData(this);
        
        // Log upload details for debugging
        console.log('Uploading file:', file.name, 'Size:', file.size, 'bytes');
        
        // Submit form via AJAX
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(text => {
            console.log('Server response:', text);
            
            try {
                // Parse JSON response
                const data = JSON.parse(text);
                
                // Restore button state
                btn.innerHTML = originalText;
                btn.disabled = false;
                
                // Handle response
                if (data.success) {
                    alert(data.message + '\nVersion: ' + data.version);
                    location.reload(); // Reload page to show new upload
                } else {
                    alert('Error: ' + (data.error || 'Unknown error occurred'));
                }
            } catch (e) {
                // JSON parsing failed - server returned invalid response
                console.error('JSON parse error:', e);
                console.error('Response text:', text);
                btn.innerHTML = originalText;
                btn.disabled = false;
                alert('Error: Server returned invalid response. Check console for details.');
            }
        })
        .catch(error => {
            // Network or other error occurred
            console.error('Upload error:', error);
            btn.innerHTML = originalText;
            btn.disabled = false;
            alert('Error: ' + error.message);
        });
        
        return false;
    };

    // ============================================
    // REVIEW FORM SUBMISSION
    // ============================================
    document.getElementById('reviewForm').onsubmit = function(e) {
        e.preventDefault();
        
        // Validate status selection
        const status = this.status.value;
        if (!status) {
            alert('Please select a review status.');
            return false;
        }
        
        // Update button to show loading state
        const btn = e.target.querySelector('button[type="submit"]');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Submitting...';
        btn.disabled = true;
        
        // Prepare form data
        const formData = new FormData(this);
        
        // Submit review via AJAX
        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Restore button state
            btn.innerHTML = originalText;
            btn.disabled = false;
            
            // Handle response
            if (data.success) {
                alert(data.message);
                location.reload(); // Reload page to show updated status
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            // Error occurred
            console.error('Error:', error);
            btn.innerHTML = originalText;
            btn.disabled = false;
            alert('Error: ' + error.message);
        });
        
        return false;
    };
});

// ============================================
// DELETE FUNCTION
// ============================================

/**
 * Delete a research output
 * Shows confirmation dialog before deletion
 * @param {number} outputId - ID of the output to delete
 */
function deleteOutput(outputId) {
    // Confirm deletion
    if (confirm('Are you sure you want to delete this research output?\n\nThis action cannot be undone.')) {
        // Prepare form data
        const formData = new FormData();
        formData.append('action', 'delete_output');
        formData.append('output_id', outputId);
        
        // Submit delete request via AJAX
        fetch(window.location.href, { 
            method: 'POST', 
            body: formData 
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Research output deleted successfully!');
                location.reload(); // Reload page to update list
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error: ' + error.message);
        });
    }
}
