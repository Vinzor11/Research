/**
 * Faculty Researcher Profile Script
 * Handles profile interactions, projects, team, costs, and HR System sync
 */

// ========================================
// HR System Sync Functions
// ========================================

/**
 * Sync faculty profile data with HR System
 * Global function accessible from onclick handlers
 */
async function syncFacultyProfile() {
    if (!confirm('Refresh this faculty data from HR System? This will update their information with the latest data.')) {
        return;
    }
    
    const btn = event.target;
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Syncing...';
    
    try {
        // Get faculty ID from page (it's set in the PHP)
        const facultyIdElement = document.querySelector('[data-faculty-id]');
        const facultyId = facultyIdElement ? facultyIdElement.dataset.facultyId : null;
        
        if (!facultyId) {
            throw new Error('Faculty ID not found');
        }
        
        const formData = new FormData();
        formData.append('action', 'sync');
        formData.append('faculty_id', facultyId);
        
        const response = await fetch('fetch_employee.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        // Check if response is JSON before parsing
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            // Check if it's an HTML error page
            if (text.includes('<html') || text.includes('<!DOCTYPE') || text.includes('<br')) {
                // Try to extract error message from HTML
                const errorMatch = text.match(/<b>([^<]+)<\/b>/i) || text.match(/Fatal error:([^<]+)/i);
                const errorMsg = errorMatch ? errorMatch[1].trim() : 'Server returned an error page';
                throw new Error(`Server error: ${errorMsg}`);
            }
            throw new Error('Server returned invalid response format');
        }
        
        const data = await response.json();
        
        if (data.success) {
            showSyncSuccess('Faculty data synced successfully! Reloading...');
            // Reload page to show updated data
            setTimeout(() => location.reload(), 1500);
        } else {
            showSyncError(data.error || 'Failed to sync faculty data');
            btn.disabled = false;
            btn.innerHTML = originalHTML;
        }
    } catch (error) {
        console.error('Sync error:', error);
        showSyncError('Failed to sync with HR System: ' + error.message);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    }
}

/**
 * Show sync success message
 */
function showSyncSuccess(message) {
    showNotification('success', message);
}

/**
 * Show sync error message
 */
function showSyncError(message) {
    showNotification('error', message);
}

/**
 * Show notification
 */
function showNotification(type, message) {
    // Remove existing notifications
    const existingNotif = document.querySelector('.notification-toast');
    if (existingNotif) {
        existingNotif.remove();
    }
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification-toast notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fa ${icons[type] || icons.info}"></i>
        <span>${escapeHtml(message)}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Trigger animation
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// ========================================
// Tab Switching
// ========================================

function switchTab(event, tabId) {
    event.preventDefault();
    
    // Get all tabs and content
    const tabs = document.querySelectorAll('.tab');
    const contents = document.querySelectorAll('.tab-content');
    
    // Remove active class from all
    tabs.forEach(tab => tab.classList.remove('active'));
    contents.forEach(content => content.classList.remove('active'));
    
    // Add active class to clicked tab
    event.currentTarget.classList.add('active');
    
    // Show corresponding content
    const content = document.getElementById(tabId);
    if (content) {
        content.classList.add('active');
    }
}

// ========================================
// Project Management
// ========================================

function openAddProjectModal() {
    document.getElementById('addProjectModal').style.display = 'block';
}

function openEditProjectModal(project) {
    const modal = document.getElementById('editProjectModal');
    const form = document.getElementById('editProjectForm');
    
    // Populate form fields
    form.elements['id'].value = project.id;
    form.elements['title'].value = project.title || '';
    form.elements['project_status'].value = project.project_status || '';
    form.elements['classification'].value = project.classification || '';
    form.elements['funding_source'].value = project.funding_source || '';
    form.elements['nature_of_involvement'].value = project.nature_of_involvement || '';
    form.elements['start_date'].value = project.start_date || '';
    form.elements['end_date'].value = project.end_date || '';
    
    modal.style.display = 'block';
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

// ========================================
// Cost Management
// ========================================

function addProjectCostRow() {
    const tbody = document.getElementById('addProjectCostsTableBody');
    const row = createCostRow();
    tbody.appendChild(row);
}

function addCostRow() {
    const tbody = document.getElementById('costsTableBody');
    const row = createCostRow();
    tbody.appendChild(row);
}

function createCostRow() {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" name="expenditure[]" placeholder="e.g., Laboratory Equipment" style="width:100%;padding:8px;"></td>
        <td><input type="number" name="institution_fund[]" placeholder="0.00" step="0.01" style="width:100%;padding:8px;"></td>
        <td>
            <input type="number" name="government_fund[]" placeholder="0.00" step="0.01" style="width:100%;padding:8px;">
            <input type="text" name="government_fund_source[]" placeholder="Source (e.g., DOST)" style="width:100%;padding:8px;margin-top:4px;">
        </td>
        <td>
            <input type="number" name="private_fund[]" placeholder="0.00" step="0.01" style="width:100%;padding:8px;">
            <input type="text" name="private_fund_source[]" placeholder="Source" style="width:100%;padding:8px;margin-top:4px;">
        </td>
        <td>
            <input type="number" name="foreign_fund[]" placeholder="0.00" step="0.01" style="width:100%;padding:8px;">
            <input type="text" name="foreign_fund_source[]" placeholder="Source" style="width:100%;padding:8px;margin-top:4px;">
        </td>
        <td>
            <input type="number" name="other_sources[]" placeholder="0.00" step="0.01" style="width:100%;padding:8px;">
            <input type="text" name="other_sources_name[]" placeholder="Source" style="width:100%;padding:8px;margin-top:4px;">
        </td>
        <td><button type="button" onclick="this.closest('tr').remove()" style="padding:8px 12px;background:#ef4444;color:white;border:none;border-radius:4px;cursor:pointer;"><i class="fa fa-trash"></i></button></td>
    `;
    return tr;
}

function openCostsModal(projectId, existingCosts) {
    document.getElementById('costsModal').style.display = 'block';
    document.getElementById('costs_project_id').value = projectId;
    
    const tbody = document.getElementById('costsTableBody');
    tbody.innerHTML = '';
    
    if (existingCosts && existingCosts.length > 0) {
        existingCosts.forEach(cost => {
            const tr = createCostRow();
            const inputs = tr.querySelectorAll('input');
            inputs[0].value = cost.item_of_expenditure || '';
            inputs[1].value = cost.institution_fund || '';
            inputs[2].value = cost.government_fund || '';
            inputs[3].value = cost.government_fund_source || '';
            inputs[4].value = cost.private_fund || '';
            inputs[5].value = cost.private_fund_source || '';
            inputs[6].value = cost.foreign_fund || '';
            inputs[7].value = cost.foreign_fund_source || '';
            inputs[8].value = cost.other_sources || '';
            inputs[9].value = cost.other_sources_name || '';
            tbody.appendChild(tr);
        });
    } else {
        addCostRow();
    }
}

// ========================================
// Team Management
// ========================================

function openTeamModal(projectId) {
    document.getElementById('teamModal').style.display = 'block';
    document.getElementById('team_project_id').value = projectId;
}

function deleteTeam(teamId, projectId) {
    if (!confirm('Remove this team member? This will also remove their linked research project.')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_team');
    formData.append('id', teamId);
    formData.append('project_id', projectId);
    
    fetch('facultyresearcherprofile.php?id=' + new URLSearchParams(window.location.search).get('id'), {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Failed to delete team member'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to delete team member');
    });
}

function deleteProject(projectId) {
    if (!confirm('Delete this research project? This will also delete all associated team members and cost data.')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_project');
    formData.append('id', projectId);
    
    fetch('facultyresearcherprofile.php?id=' + new URLSearchParams(window.location.search).get('id'), {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error: ' + (data.error || 'Failed to delete project'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to delete project');
    });
}

// ========================================
// Form Submissions
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    // Add Project Form
    const addProjectForm = document.getElementById('addProjectForm');
    if (addProjectForm) {
        addProjectForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to add project'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add project');
            });
        });
    }
    
    // Edit Project Form
    const editProjectForm = document.getElementById('editProjectForm');
    if (editProjectForm) {
        editProjectForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to update project'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to update project');
            });
        });
    }
    
    // Team Form
    const teamForm = document.getElementById('teamForm');
    if (teamForm) {
        teamForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to add team member'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to add team member');
            });
        });
    }
    
    // Costs Form
    const costsForm = document.getElementById('costsForm');
    if (costsForm) {
        costsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error: ' + (data.error || 'Failed to save costs'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to save costs');
            });
        });
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    };
    
    // Add notification styles
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification-toast {
                position: fixed;
                top: 20px;
                right: 20px;
                min-width: 300px;
                padding: 16px 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
                display: flex;
                align-items: center;
                gap: 12px;
                font-size: 14px;
                font-weight: 500;
                z-index: 10000;
                transform: translateX(400px);
                opacity: 0;
                transition: all 0.3s ease;
            }
            
            .notification-toast.show {
                transform: translateX(0);
                opacity: 1;
            }
            
            .notification-toast i {
                font-size: 20px;
            }
            
            .notification-success {
                border-left: 4px solid #10b981;
                color: #065f46;
            }
            
            .notification-success i {
                color: #10b981;
            }
            
            .notification-error {
                border-left: 4px solid #ef4444;
                color: #991b1b;
            }
            
            .notification-error i {
                color: #ef4444;
            }
        `;
        document.head.appendChild(style);
    }
});

// ========================================
// Utility Functions
// ========================================

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}