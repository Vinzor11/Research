<?php
/**
 * Script to check if imported employees still exist in HR and belong to same unit
 * Updates sync_status to 'n/a' if employee is deleted or not in same unit
 * Run this periodically (e.g., via cron) or call it when viewing faculty list
 */

require 'db.php';
require 'config.php';
require 'hr_api_helper.php';

session_start();

// Only allow admin or coordinator to run this
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'coordinator'])) {
    die(json_encode(['success' => false, 'error' => 'Unauthorized']));
}

$userId = $_SESSION['user_id'];
$updatedCount = 0;
$errors = [];

try {
    $hrAPI = new HRSystemAPI($conn, $userId);
    
    // Get all imported faculty researchers with hr_employee_id
    $faculties = $conn->query("
        SELECT id, hr_employee_id, created_by, sync_status, home_unit 
        FROM faculty_researchers 
        WHERE hr_employee_id IS NOT NULL AND hr_employee_id != ''
        ORDER BY id
    ")->fetch_all(MYSQLI_ASSOC);
    
    foreach ($faculties as $faculty) {
        $facultyId = $faculty['id'];
        $hrEmployeeId = $faculty['hr_employee_id'];
        $createdBy = $faculty['created_by'];
        
        try {
            // Try to get employee from HR
            $hrEmployee = $hrAPI->getEmployeeById($hrEmployeeId);
            
            if (empty($hrEmployee) || empty($hrEmployee['id'])) {
                // Employee not found in HR - set sync_status to 'n/a'
                $conn->query("
                    UPDATE faculty_researchers 
                    SET sync_status = 'n/a' 
                    WHERE id = $facultyId
                ");
                $updatedCount++;
                debugLog("Employee not found in HR", ['faculty_id' => $facultyId, 'hr_employee_id' => $hrEmployeeId]);
                continue;
            }
            
            // Check if employee belongs to same unit (for coordinators)
            if ($_SESSION['user_role'] === 'coordinator') {
                // Get coordinator's unit employees
                $unitEmployees = $hrAPI->fetchAllUnitEmployees();
                $allowedIds = [];
                foreach ($unitEmployees as $emp) {
                    $allowedIds[] = normalizeEmployeeId($emp['id'] ?? '');
                }
                
                $normalizedEmployeeId = normalizeEmployeeId($hrEmployeeId);
                if (!in_array($normalizedEmployeeId, $allowedIds)) {
                    // Employee not in coordinator's unit - set sync_status to 'n/a'
                    $conn->query("
                        UPDATE faculty_researchers 
                        SET sync_status = 'n/a' 
                        WHERE id = $facultyId
                    ");
                    $updatedCount++;
                    debugLog("Employee not in coordinator's unit", [
                        'faculty_id' => $facultyId, 
                        'hr_employee_id' => $hrEmployeeId,
                        'coordinator_id' => $userId
                    ]);
                    continue;
                }
            }
            
            // Employee exists and is in correct unit - update sync_status if it was 'n/a'
            if ($faculty['sync_status'] === 'n/a') {
                // Reset to appropriate status based on last_synced_at
                $lastSynced = $conn->query("SELECT last_synced_at FROM faculty_researchers WHERE id = $facultyId")->fetch_assoc()['last_synced_at'];
                $newStatus = 'not-synced';
                if ($lastSynced) {
                    $newStatus = needsHRSync($lastSynced) ? 'needs-sync' : 'synced';
                }
                $conn->query("
                    UPDATE faculty_researchers 
                    SET sync_status = '$newStatus' 
                    WHERE id = $facultyId
                ");
                $updatedCount++;
            }
            
        } catch (Exception $e) {
            $errors[] = "Error checking faculty ID $facultyId: " . $e->getMessage();
            errorLog("Error checking employee status", [
                'faculty_id' => $facultyId,
                'hr_employee_id' => $hrEmployeeId,
                'error' => $e->getMessage()
            ]);
        }
    }
    
    echo json_encode([
        'success' => true,
        'updated' => $updatedCount,
        'total_checked' => count($faculties),
        'errors' => $errors
    ]);
    
} catch (Exception $e) {
    errorLog("check_employee_status.php exception: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
