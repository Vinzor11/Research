<?php
/**
 * Submission View Page
 * Unified design matching collaboration_view.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
require_once 'auth_check.php';
require_once 'spa_helper.php';
require_once 'SubmissionService.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Redirect to SPA shell if accessed directly
$isSpa = isSpaRequest();
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'] ?? '';
$employeeId = $_SESSION['employee_id'] ?? '';

$submissionId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$submissionId) {
    echo '<div class="error-state"><h3>Invalid Submission ID</h3><p>No submission ID provided.</p></div>';
    exit;
}

$service = new SubmissionService($conn);
$workflow = $service->getWorkflowEngine();
$submission = $service->getById($submissionId);

if (!$submission) {
    echo '<div class="error-state"><h3>Submission Not Found</h3><p>The requested submission could not be found.</p></div>';
    exit;
}

// Get additional data
$comments = $service->getComments($submissionId);
$history = $service->getHistory($submissionId);
$endorsement = $service->getEndorsementSummary($submissionId);
$attachments = $submission['attachments'] ?? [];
$allowedActions = $submission['allowed_actions'] ?? [];

// Coordinator submission detection
$isCoordinatorSubmission = ($submission['submitted_by_coordinator'] ?? 0) == 1;
$coordinatorSubmissionRouting = $submission['coordinator_submission_routing'] ?? null;
$submitterCoordinatorId = $submission['submitter_coordinator_id'] ?? null;
$isEscalatedToRO = ($coordinatorSubmissionRouting === 'escalated_to_ro');
$isSelfSubmission = false;
$selfEndorseBlockReason = '';

// Check self-endorsement prevention
if ($userRole === 'coordinator' && $isCoordinatorSubmission) {
    if ($submitterCoordinatorId == $userId) {
        $isSelfSubmission = true;
        $selfEndorseBlockReason = 'You cannot endorse this submission because you created it.';
    }
    if (!empty($submission['submitter_coordinator_employee_id']) && 
        !empty($employeeId) && 
        $submission['submitter_coordinator_employee_id'] === $employeeId) {
        $isSelfSubmission = true;
        $selfEndorseBlockReason = 'You cannot endorse this submission because you created it.';
    }
}

if ($userRole === 'coordinator' && $submission['created_by'] == $userId) {
    $isSelfSubmission = true;
    $selfEndorseBlockReason = 'You cannot endorse a submission you created.';
}

if ($isSelfSubmission) {
    $allowedActions = array_diff($allowedActions, ['endorse', 'start_review', 'return_for_revision']);
}

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }

// Check if reviewer/admin
$isAdmin = ($userRole === 'admin');
$isCoordinator = ($userRole === 'coordinator');
$isOwner = ($submission['created_by'] == $userId);

// Status configuration
$statusConfig = [
    'draft' => ['label' => 'Draft', 'icon' => 'fa-pencil-alt', 'class' => 'status-draft'],
    'submitted' => ['label' => 'Submitted', 'icon' => 'fa-paper-plane', 'class' => 'status-submitted'],
    'reviewed' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_review' => ['label' => 'Under Review', 'icon' => 'fa-user-clock', 'class' => 'status-reviewing'],
    'under_coordinator_review' => ['label' => 'Under Review', 'icon' => 'fa-user-tie', 'class' => 'status-reviewing'],
    'returned_for_revision' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned'],
    'returned' => ['label' => 'Returned', 'icon' => 'fa-undo', 'class' => 'status-returned'],
    'endorsed' => ['label' => 'Endorsed', 'icon' => 'fa-check-circle', 'class' => 'status-endorsed'],
    'under_ro_review' => ['label' => 'RO Review', 'icon' => 'fa-building', 'class' => 'status-reviewing'],
    'approved' => ['label' => 'Approved', 'icon' => 'fa-thumbs-up', 'class' => 'status-approved'],
    'rejected' => ['label' => 'Rejected', 'icon' => 'fa-times-circle', 'class' => 'status-rejected']
];
$currentStatus = $statusConfig[$submission['status']] ?? ['label' => ucfirst(str_replace('_', ' ', $submission['status'])), 'icon' => 'fa-info-circle', 'class' => 'status-draft'];
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   SUBMISSION VIEW - UNIFIED DESIGN
   ============================================ */

.sub-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.sub-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.sub-header-left { flex: 1; }

.sub-header-left h1 {
    font-size: 22px;
    font-weight: 700;
    color: white;
    margin: 0 0 8px 0;
    line-height: 1.4;
}

.sub-header-left .ref-number {
    font-family: 'Consolas', monospace;
    font-size: 13px;
    color: rgba(255,255,255,0.9);
    background: rgba(255,255,255,0.15);
    padding: 4px 10px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 12px;
}

.sub-header-badges {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.sub-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: rgba(255,255,255,0.2);
    color: white;
}

.badge-type { background: #dbeafe; color: #1e40af; }
.badge-researcher { background: rgba(255,255,255,0.2); color: white; }

.sub-header-right { text-align: right; }

.status-badge-large {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    background: rgba(255,255,255,0.95);
}

.status-draft { color: #6b7280; }
.status-submitted { color: #2563eb; }
.status-reviewing { color: #d97706; }
.status-endorsed { color: #7c3aed; }
.status-approved { color: #059669; }
.status-rejected { color: #dc2626; }
.status-returned { color: #ea580c; }

/* Status Timeline */
.status-timeline {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 16px 20px;
    background: #f9fafb;
    border-radius: 8px;
    overflow-x: auto;
}

.timeline-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    min-width: 80px;
    flex: 1;
    position: relative;
}

.timeline-step::after {
    content: '';
    position: absolute;
    top: 16px;
    right: -50%;
    width: 100%;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
}

.timeline-step:last-child::after { display: none; }
.timeline-step.completed::after { background: #10b981; }
.timeline-step.current::after { background: linear-gradient(90deg, #10b981 50%, #e5e7eb 50%); }

.timeline-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    color: #9ca3af;
    font-size: 12px;
    position: relative;
    z-index: 1;
}

.timeline-step.completed .timeline-icon { background: #d1fae5; color: #059669; }
.timeline-step.current .timeline-icon { background: #dbeafe; color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2); }
.timeline-step.rejected .timeline-icon { background: #fee2e2; color: #dc2626; }

.timeline-label {
    font-size: 10px;
    color: #6b7280;
    text-align: center;
    white-space: nowrap;
}

.timeline-step.current .timeline-label { color: #1f2937; font-weight: 600; }

/* Content Layout */
.sub-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
}

.sub-main { display: flex; flex-direction: column; gap: 24px; }
.sub-sidebar { display: flex; flex-direction: column; gap: 24px; }

/* Section Cards */
.section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.section-header {
    padding: 16px 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.section-header h3 {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h3 i { color: #064e1a; }

.section-body { padding: 20px; }

/* Detail Grid */
.detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.detail-row {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.detail-row.full-width { grid-column: 1 / -1; }

.detail-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.detail-value {
    font-size: 14px;
    color: #1f2937;
    line-height: 1.6;
    word-wrap: break-word;
    overflow-wrap: break-word;
    word-break: break-word;
}

/* Prevent layout break from long text */
.section-card {
    min-width: 0;
    overflow: hidden;
}

.section-body {
    overflow-wrap: break-word;
    word-break: break-word;
}

.sub-main, .sub-sidebar {
    min-width: 0;
}

.detail-value.money { color: #059669; font-weight: 600; }
.detail-value.code { font-family: monospace; color: #166534; font-weight: 600; }

/* Actions Panel */
.actions-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: all 0.2s;
    text-decoration: none;
    width: 100%;
}

.btn-primary-action { background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%); color: white; }
.btn-primary-action:hover { background: linear-gradient(135deg, #053615 0%, #096b24 100%); }

.btn-submit { background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); color: white; }
.btn-submit:hover { background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); }

.btn-endorse { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%); color: white; }
.btn-endorse:hover { background: linear-gradient(135deg, #6d28d9 0%, #7c3aed 100%); }

.btn-approve { background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; }
.btn-approve:hover { background: linear-gradient(135deg, #047857 0%, #059669 100%); }

.btn-return { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }
.btn-return:hover { background: #fde68a; }

.btn-reject { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
.btn-reject:hover { background: #fecaca; }

.btn-edit { background: #f3f4f6; color: #374151; border: 1px solid #e5e7eb; }
.btn-edit:hover { background: #e5e7eb; }

/* Info List */
.info-list { display: flex; flex-direction: column; gap: 12px; }
.info-item { display: flex; flex-direction: column; gap: 2px; }
.info-label { font-size: 11px; color: #6b7280; text-transform: uppercase; }
.info-value { font-size: 14px; color: #1f2937; font-weight: 500; }

.researcher-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    background: #dbeafe;
    color: #1e40af;
}

/* Attachments */
.attachment-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #f9fafb;
    border-radius: 8px;
    margin-bottom: 8px;
}

.attachment-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fee2e2;
    color: #dc2626;
    font-size: 18px;
}

.attachment-info { flex: 1; }
.attachment-name { font-size: 13px; font-weight: 600; color: #1f2937; }
.attachment-meta { font-size: 11px; color: #9ca3af; }

/* Comments */
.comment-item {
    padding: 14px;
    border-bottom: 1px solid #f3f4f6;
    border-left: 4px solid #064e1a;
    margin-bottom: 10px;
    border-radius: 0 8px 8px 0;
    background: #f9fafb;
}

.comment-item:last-child { margin-bottom: 0; }
.comment-item.revision { border-left-color: #f59e0b; }
.comment-item.approval { border-left-color: #10b981; }

.comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.comment-author { font-weight: 600; font-size: 13px; color: #1f2937; }
.comment-date { font-size: 11px; color: #9ca3af; }
.comment-text { font-size: 13px; color: #4b5563; line-height: 1.5; }

.comment-type-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    background: #f3f4f6;
    color: #6b7280;
    margin-top: 8px;
}

/* History Timeline */
.history-timeline { padding-left: 24px; position: relative; }

.history-timeline::before {
    content: '';
    position: absolute;
    left: 8px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #e5e7eb;
}

.history-item {
    position: relative;
    padding-bottom: 20px;
}

.history-item:last-child { padding-bottom: 0; }

.history-marker {
    position: absolute;
    left: -20px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #064e1a;
    border: 2px solid white;
    box-shadow: 0 0 0 2px #064e1a;
}

.history-marker.success { background: #10b981; box-shadow: 0 0 0 2px #10b981; }
.history-marker.warning { background: #f59e0b; box-shadow: 0 0 0 2px #f59e0b; }
.history-marker.danger { background: #ef4444; box-shadow: 0 0 0 2px #ef4444; }

.history-content {
    background: white;
    padding: 12px 16px;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.history-action { font-weight: 600; color: #1f2937; font-size: 13px; }
.history-meta { font-size: 12px; color: #6b7280; margin-top: 4px; }
.history-note { font-size: 13px; color: #4b5563; margin-top: 8px; padding: 8px; background: #f9fafb; border-radius: 4px; }

/* Endorsement Card */
.endorsement-card {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
    border: 1px solid #93c5fd;
}

.endorsement-card .section-header {
    background: transparent;
    border-bottom-color: rgba(59, 130, 246, 0.3);
}

.endorsement-card .section-header h3 i { color: #2563eb !important; }

.checklist-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(59, 130, 246, 0.2);
}

.checklist-item:last-child { border-bottom: none; }

.check-icon { font-size: 16px; }
.check-icon.success { color: #10b981; }
.check-icon.fail { color: #ef4444; }

/* Alert Notices */
.notice-card {
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 16px;
}

.notice-card.warning {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 1px solid #fbbf24;
}

.notice-card.danger {
    background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
    border: 1px solid #fca5a5;
}

.notice-card.info {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
    border: 1px solid #93c5fd;
}

.notice-content {
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.notice-content i { font-size: 18px; margin-top: 2px; }
.notice-card.warning .notice-content i { color: #d97706; }
.notice-card.danger .notice-content i { color: #dc2626; }
.notice-card.info .notice-content i { color: #2563eb; }

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active { opacity: 1; visibility: visible; }

.modal-box {
    background: white;
    border-radius: 16px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.modal-overlay.active .modal-box { transform: scale(1); }

.modal-header {
    padding: 20px 24px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 { font-size: 18px; color: #1f2937; margin: 0; display: flex; align-items: center; gap: 10px; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #6b7280; }
.modal-body { padding: 24px; }
.modal-footer { padding: 16px 24px; border-top: 1px solid #e5e7eb; display: flex; justify-content: flex-end; gap: 12px; }

.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 6px; }
.form-group input, .form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
}
.form-group textarea { min-height: 100px; resize: vertical; }

.modal-checklist-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 0;
    border-bottom: 1px solid #f3f4f6;
}

.modal-checklist-item:last-child { border-bottom: none; }

.alert-box {
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 16px;
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.alert-box.success { background: #d1fae5; color: #065f46; }
.alert-box.warning { background: #fef3c7; color: #92400e; }
.alert-box.danger { background: #fee2e2; color: #991b1b; }
.alert-box.info { background: #dbeafe; color: #1e40af; }

/* Responsive */
@media (max-width: 1024px) {
    .sub-content { grid-template-columns: 1fr; }
    .sub-sidebar { order: -1; }
}

@media (max-width: 768px) {
    .sub-header-content { flex-direction: column; }
    .sub-header-right { text-align: left; }
    .detail-grid { grid-template-columns: 1fr; }
}
</style>

<div class="content">
    <!-- Header Banner -->
    <div class="sub-header-banner">
        <div class="sub-header-content">
            <div class="sub-header-left">
                <?php if (!empty($submission['reference_number'])): ?>
                    <span class="ref-number"><?= s($submission['reference_number']) ?></span>
                <?php elseif (!empty($submission['project_code'])): ?>
                    <span class="ref-number"><?= s($submission['project_code']) ?></span>
                <?php endif; ?>
                <h1><?= s($submission['title']) ?></h1>
                <div class="sub-header-badges">
                    <span class="sub-badge badge-type">
                        <i class="fa fa-file-alt"></i>
                        <?= s($submission['type_name']) ?>
                    </span>
                    <span class="sub-badge badge-researcher">
                        <i class="fa fa-user"></i>
                        <?= ucfirst($submission['researcher_type']) ?>
                    </span>
                    <?php if (!empty($submission['project_status'])): ?>
                    <span class="sub-badge" style="background: <?= $submission['project_status'] === 'completed' ? '#d1fae5' : '#dbeafe' ?>; color: <?= $submission['project_status'] === 'completed' ? '#065f46' : '#1e40af' ?>;">
                        <i class="fa fa-folder"></i>
                        <?= ucwords(str_replace('_', ' ', $submission['project_status'])) ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="sub-header-right">
                <span class="status-badge-large <?= $currentStatus['class'] ?>">
                    <i class="fa <?= $currentStatus['icon'] ?>"></i>
                    <?= $submission['status_label'] ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Status Timeline -->
    <div class="section-card" style="margin-bottom: 24px;">
        <div class="status-timeline">
            <?php
            $workflowSteps = [
                'draft' => 'Draft',
                'submitted' => 'Submitted',
                'under_coordinator_review' => 'Coord. Review',
                'endorsed' => 'Endorsed',
                'under_ro_review' => 'RO Review',
                'approved' => 'Approved'
            ];
            
            $currentFound = false;
            $isRejected = $submission['status'] === 'rejected';
            $isReturned = $submission['status'] === 'returned_for_revision';
            
            foreach ($workflowSteps as $stepKey => $stepLabel):
                $stepClass = '';
                if ($isRejected && $stepKey === 'approved') {
                    $stepClass = 'rejected';
                    $stepLabel = 'Rejected';
                } elseif (!$currentFound) {
                    if ($stepKey === $submission['status']) {
                        $stepClass = 'current';
                        $currentFound = true;
                    } elseif ($isReturned && $stepKey === 'draft') {
                        $stepClass = 'current';
                        $currentFound = true;
                        $stepLabel = 'Returned';
                    } else {
                        $stepClass = 'completed';
                    }
                }
            ?>
            <div class="timeline-step <?= $stepClass ?>">
                <div class="timeline-icon">
                    <i class="fa <?= $stepClass === 'completed' ? 'fa-check' : ($stepClass === 'rejected' ? 'fa-times' : 'fa-circle') ?>"></i>
                </div>
                <span class="timeline-label"><?= $stepLabel ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="sub-content">
        <!-- Main Content -->
        <div class="sub-main">
            <!-- Submission Details -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-file-alt"></i> Submission Details</h3>
                </div>
                <div class="section-body">
                    <div class="detail-grid">
                        <?php if (!empty($submission['reference_number'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Reference Number</span>
                            <span class="detail-value code"><?= s($submission['reference_number']) ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($submission['project_code'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Project Code</span>
                            <span class="detail-value code"><?= s($submission['project_code']) ?></span>
                        </div>
                        <?php endif; ?>

                        <div class="detail-row">
                            <span class="detail-label">Submission Type</span>
                            <span class="detail-value"><?= s($submission['type_name']) ?></span>
                        </div>

                        <div class="detail-row">
                            <span class="detail-label">Researcher</span>
                            <span class="detail-value"><?= s($submission['researcher']['full_name'] ?? 'Unknown') ?></span>
                        </div>

                        <?php if (!empty($submission['researcher_unit_name'])): ?>
                        <div class="detail-row">
                            <span class="detail-label">Unit/College</span>
                            <span class="detail-value"><?= s($submission['researcher_unit_name']) ?></span>
                        </div>
                        <?php endif; ?>

                        <?php if ($submission['proposed_start_date'] && $submission['proposed_end_date']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Timeline</span>
                            <span class="detail-value"><?= date('M d, Y', strtotime($submission['proposed_start_date'])) ?> - <?= date('M d, Y', strtotime($submission['proposed_end_date'])) ?></span>
                        </div>
                        <?php endif; ?>

                        <?php if ($submission['total_budget']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Total Budget</span>
                            <span class="detail-value money">₱<?= number_format($submission['total_budget'], 2) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Abstract -->
            <?php if (!empty($submission['abstract'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-align-left"></i> Abstract</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($submission['abstract'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Objectives -->
            <?php if (!empty($submission['objectives'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bullseye"></i> Research Objectives</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($submission['objectives'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Methodology -->
            <?php if (!empty($submission['methodology'])): ?>
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-project-diagram"></i> Methodology</h3>
                </div>
                <div class="section-body">
                    <div class="detail-value"><?= nl2br(s($submission['methodology'])) ?></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Attachments -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-paperclip"></i> Attachments (<?= count($attachments) ?>)</h3>
                </div>
                <div class="section-body">
                    <?php if (empty($attachments)): ?>
                        <p style="color: #6b7280; margin: 0;">No attachments uploaded.</p>
                    <?php else: ?>
                        <?php foreach ($attachments as $att): ?>
                        <div class="attachment-item">
                            <div class="attachment-icon"><i class="fa fa-file-pdf"></i></div>
                            <div class="attachment-info">
                                <div class="attachment-name"><?= s($att['original_name']) ?></div>
                                <div class="attachment-meta"><?= number_format($att['file_size']/1024, 2) ?> KB</div>
                            </div>
                            <a href="<?= s($att['file_path']) ?>" target="_blank" class="action-btn btn-edit" style="width: auto; padding: 6px 12px; font-size: 12px;">
                                <i class="fa fa-download"></i>
                            </a>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Comments -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-comments"></i> Comments & Notes</h3>
                </div>
                <div class="section-body">
                    <?php if (empty($comments)): ?>
                        <p style="color: #6b7280; margin: 0;">No comments yet.</p>
                    <?php else: ?>
                        <?php foreach ($comments as $comment): 
                            $commentClass = '';
                            if (strpos($comment['comment_type'], 'revision') !== false) $commentClass = 'revision';
                            if (strpos($comment['comment_type'], 'approval') !== false) $commentClass = 'approval';
                        ?>
                        <div class="comment-item <?= $commentClass ?>">
                            <div class="comment-header">
                                <span class="comment-author"><?= s($comment['created_by_name']) ?></span>
                                <span class="comment-date"><?= date('M d, Y H:i', strtotime($comment['created_at'])) ?></span>
                            </div>
                            <div class="comment-text"><?= nl2br(s($comment['comment_text'])) ?></div>
                            <span class="comment-type-badge"><?= ucfirst(str_replace('_', ' ', $comment['comment_type'])) ?></span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Workflow History -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-history"></i> Workflow History</h3>
                </div>
                <div class="section-body">
                    <div class="history-timeline">
                        <?php foreach ($history as $event): 
                            $markerClass = '';
                            if (strpos($event['action_type'], 'approved') !== false) $markerClass = 'success';
                            if (strpos($event['action_type'], 'reject') !== false || strpos($event['action_type'], 'return') !== false) $markerClass = 'danger';
                            if (strpos($event['action_type'], 'submit') !== false || strpos($event['action_type'], 'endorse') !== false) $markerClass = 'warning';
                        ?>
                        <div class="history-item">
                            <div class="history-marker <?= $markerClass ?>"></div>
                            <div class="history-content">
                                <div class="history-action"><?= ucwords(str_replace('_', ' ', $event['action_type'])) ?></div>
                                <div class="history-meta">
                                    <i class="fa fa-user"></i> <?= s($event['actor_name'] ?? 'System') ?>
                                    &bull;
                                    <i class="fa fa-clock"></i> <?= date('M d, Y H:i', strtotime($event['created_at'])) ?>
                                </div>
                                <?php if ($event['comments'] || $event['return_reason']): ?>
                                <div class="history-note"><?= nl2br(s($event['comments'] ?? $event['return_reason'])) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="sub-sidebar">
            <!-- Coordinator Submission Notice -->
            <?php if ($isCoordinatorSubmission): ?>
            <div class="notice-card <?= $isEscalatedToRO ? 'warning' : 'info' ?>">
                <div class="notice-content">
                    <i class="fa fa-shield-alt"></i>
                    <div>
                        <strong style="font-size: 13px;">Submitted by Coordinator</strong>
                        <p style="font-size: 12px; margin: 4px 0 0 0;">
                            <?php if ($isEscalatedToRO): ?>
                            <i class="fa fa-arrow-up"></i> Escalated to Research Office
                            <?php else: ?>
                            <i class="fa fa-users"></i> Routed to peer coordinator
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Self-Endorsement Block -->
            <?php if ($isSelfSubmission && $userRole === 'coordinator'): ?>
            <div class="notice-card danger">
                <div class="notice-content">
                    <i class="fa fa-ban"></i>
                    <div>
                        <strong style="font-size: 13px;">Self-Endorsement Blocked</strong>
                        <p style="font-size: 12px; margin: 4px 0 0 0;"><?= s($selfEndorseBlockReason) ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Actions -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-bolt"></i> Actions</h3>
                </div>
                <div class="section-body">
                    <div class="actions-panel">
                        <?php if (!empty($submission['project_status']) && $submission['status'] === 'approved'): ?>
                        <a href="project_view.php?id=<?= $submissionId ?>" class="action-btn btn-primary-action"
                           onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $submissionId ?>',true)}">
                            <i class="fa fa-folder-open"></i> View Project Dashboard
                        </a>
                        <?php endif; ?>

                        <?php if (in_array('edit', $allowedActions)): ?>
                        <a href="submission_create.php?id=<?= $submissionId ?>" class="action-btn btn-edit"
                           onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('submission_create.php?id=<?= $submissionId ?>',true)}">
                            <i class="fa fa-pencil-alt"></i> Edit Submission
                        </a>
                        <?php endif; ?>

                        <?php if (in_array('submit', $allowedActions)): ?>
                        <button onclick="submitToCoordinator()" class="action-btn btn-submit">
                            <i class="fa fa-paper-plane"></i> Submit to Coordinator
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('start_review', $allowedActions) && $submission['status'] === 'submitted'): ?>
                        <button onclick="startCoordinatorReview()" class="action-btn btn-submit">
                            <i class="fa fa-play"></i> Start Review
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('endorse', $allowedActions)): ?>
                        <button onclick="openModal('endorseModal')" class="action-btn btn-endorse">
                            <i class="fa fa-check-double"></i> Endorse to Research Office
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('return', $allowedActions)): ?>
                        <button onclick="openModal('returnModal')" class="action-btn btn-return">
                            <i class="fa fa-undo"></i> Return for Revision
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('start_review', $allowedActions) && $submission['status'] === 'endorsed'): ?>
                        <button onclick="startROReview()" class="action-btn btn-submit">
                            <i class="fa fa-play"></i> Start RO Review
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('approve', $allowedActions)): ?>
                        <button onclick="openModal('approveModal')" class="action-btn btn-approve">
                            <i class="fa fa-check"></i> Approve
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('reject', $allowedActions)): ?>
                        <button onclick="openModal('rejectModal')" class="action-btn btn-reject">
                            <i class="fa fa-times"></i> Reject
                        </button>
                        <?php endif; ?>

                        <?php if (in_array('return_to_coordinator', $allowedActions)): ?>
                        <button onclick="openModal('returnToCoordinatorModal')" class="action-btn btn-return">
                            <i class="fa fa-undo"></i> Return to Coordinator
                        </button>
                        <?php endif; ?>

                        <?php if (empty($allowedActions) || (count($allowedActions) == 1 && in_array('view', $allowedActions))): ?>
                        <p style="color: #6b7280; text-align: center; margin: 0; font-size: 13px;">
                            <i class="fa fa-info-circle"></i> No actions available at this status.
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Endorsement Summary -->
            <?php if ($endorsement): ?>
            <div class="section-card endorsement-card">
                <div class="section-header">
                    <h3><i class="fa fa-clipboard-check"></i> Coordinator Endorsement</h3>
                </div>
                <div class="section-body">
                    <div class="info-list" style="margin-bottom: 16px;">
                        <div class="info-item">
                            <span class="info-label">Endorsed By</span>
                            <span class="info-value"><?= s($endorsement['coordinator_name']) ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Date</span>
                            <span class="info-value"><?= date('M d, Y H:i', strtotime($endorsement['endorsed_at'])) ?></span>
                        </div>
                    </div>
                    <div style="border-top: 1px solid rgba(59, 130, 246, 0.3); padding-top: 12px;">
                        <span class="detail-label" style="margin-bottom: 8px; display: block;">Validation Checklist</span>
                        <div class="checklist-item">
                            <i class="fa <?= $endorsement['completeness_verified'] ? 'fa-check-circle success' : 'fa-times-circle fail' ?> check-icon"></i>
                            <span>Completeness Verified</span>
                        </div>
                        <div class="checklist-item">
                            <i class="fa <?= $endorsement['unit_verified'] ? 'fa-check-circle success' : 'fa-times-circle fail' ?> check-icon"></i>
                            <span>Unit Affiliation Verified</span>
                        </div>
                        <div class="checklist-item">
                            <i class="fa <?= $endorsement['category_verified'] ? 'fa-check-circle success' : 'fa-times-circle fail' ?> check-icon"></i>
                            <span>Category Verified</span>
                        </div>
                        <div class="checklist-item">
                            <i class="fa <?= $endorsement['attachments_verified'] ? 'fa-check-circle success' : 'fa-times-circle fail' ?> check-icon"></i>
                            <span>Attachments Verified</span>
                        </div>
                    </div>
                    <?php if ($endorsement['endorsement_notes']): ?>
                    <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(59, 130, 246, 0.3);">
                        <span class="detail-label">Notes</span>
                        <p style="font-size: 13px; margin: 4px 0 0 0;"><?= nl2br(s($endorsement['endorsement_notes'])) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Requester Info -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-user"></i> Researcher</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Researcher Type</span>
                            <span class="researcher-badge"><?= strtoupper($submission['researcher_type']) ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Name</span>
                            <span class="info-value"><?= s($submission['researcher']['full_name'] ?? 'Unknown') ?></span>
                        </div>
                        <?php if (!empty($submission['researcher_unit_name'])): ?>
                        <div class="info-item">
                            <span class="info-label">Unit / Department</span>
                            <span class="info-value"><?= s($submission['researcher_unit_name']) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <div class="section-card">
                <div class="section-header">
                    <h3><i class="fa fa-clock"></i> Timeline</h3>
                </div>
                <div class="section-body">
                    <div class="info-list">
                        <div class="info-item">
                            <span class="info-label">Created</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($submission['created_at'])) ?></span>
                        </div>
                        <?php if ($submission['submitted_at']): ?>
                        <div class="info-item">
                            <span class="info-label">Submitted</span>
                            <span class="info-value"><?= date('M d, Y g:i A', strtotime($submission['submitted_at'])) ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Back Button -->
            <div class="section-card">
                <div class="section-body" style="padding: 12px 20px;">
                    <?php if ($isCoordinator || $isAdmin): ?>
                    <a href="work_queue.php" class="action-btn btn-edit"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('work_queue.php',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Work Queue
                    </a>
                    <?php else: ?>
                    <a href="researcher_dashboard.php" class="action-btn btn-edit"
                       onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('researcher_dashboard.php',true)}">
                        <i class="fa fa-arrow-left"></i> Back to Dashboard
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->

<!-- Endorse Modal -->
<div id="endorseModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-check-double" style="color: #059669;"></i> Endorse to Research Office</h3>
            <button class="modal-close" onclick="closeModal('endorseModal')">&times;</button>
        </div>
        <form id="endorseForm" method="POST" onsubmit="submitEndorse(event); return false;">
            <input type="hidden" name="submission_id" value="<?= $submissionId ?>">
            <div class="modal-body">
                <p style="color: #6b7280; margin-bottom: 16px;">Complete the validation checklist before endorsing.</p>
                
                <div class="modal-checklist-item">
                    <input type="checkbox" id="chk_complete" name="completeness_verified" value="1" required>
                    <label for="chk_complete">I have verified the submission is complete</label>
                </div>
                <div class="modal-checklist-item">
                    <input type="checkbox" id="chk_unit" name="unit_verified" value="1" required>
                    <label for="chk_unit">I have verified the researcher's unit affiliation</label>
                </div>
                <div class="modal-checklist-item">
                    <input type="checkbox" id="chk_category" name="category_verified" value="1" required>
                    <label for="chk_category">I have verified the researcher category is correct</label>
                </div>
                <div class="modal-checklist-item">
                    <input type="checkbox" id="chk_attach" name="attachments_verified" value="1" required>
                    <label for="chk_attach">I have verified all required attachments are present</label>
                </div>
                
                <div class="form-group" style="margin-top: 16px;">
                    <label>Endorsement Notes (optional)</label>
                    <textarea name="notes" placeholder="Any notes for the Research Office..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn btn-edit" style="width: auto;" onclick="closeModal('endorseModal')">Cancel</button>
                <button type="submit" class="action-btn btn-endorse" style="width: auto;" id="endorseSubmitBtn" disabled>
                    <i class="fa fa-check-double"></i> Endorse
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return for Revision Modal -->
<div id="returnModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-undo" style="color: #f59e0b;"></i> Return for Revision</h3>
            <button class="modal-close" onclick="closeModal('returnModal')">&times;</button>
        </div>
        <form id="returnForm" method="POST" onsubmit="submitReturn(event); return false;">
            <input type="hidden" name="submission_id" value="<?= $submissionId ?>">
            <div class="modal-body">
                <div class="alert-box warning">
                    <i class="fa fa-exclamation-triangle"></i>
                    <span>This will return the submission to the researcher for revision.</span>
                </div>
                <div class="form-group">
                    <label>Reason for Return *</label>
                    <textarea name="reason" required placeholder="Explain what needs to be revised..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn btn-edit" style="width: auto;" onclick="closeModal('returnModal')">Cancel</button>
                <button type="submit" class="action-btn btn-return" style="width: auto;">
                    <i class="fa fa-undo"></i> Return
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header" style="background: #059669; color: white; border-radius: 16px 16px 0 0;">
            <h3 style="color: white;"><i class="fa fa-check"></i> Approve & Elevate to Project</h3>
            <button class="modal-close" style="color: white;" onclick="closeModal('approveModal')">&times;</button>
        </div>
        <form id="approveForm" method="POST" onsubmit="submitApprove(event); return false;">
            <input type="hidden" name="submission_id" value="<?= $submissionId ?>">
            <div class="modal-body">
                <div class="alert-box success">
                    <i class="fa fa-check-circle"></i>
                    <div>
                        <strong>Approving this proposal will:</strong>
                        <ul style="margin: 8px 0 0 0; padding-left: 18px; font-size: 13px;">
                            <li>Assign an official Reference Number</li>
                            <li>Generate a unique Project Code</li>
                            <li>Elevate to On-Going Research Project</li>
                            <li>Map to RMIS Form D1</li>
                        </ul>
                    </div>
                </div>
                <div class="form-group">
                    <label>Approval Notes (optional)</label>
                    <textarea name="notes" placeholder="Any notes for the approval..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn btn-edit" style="width: auto;" onclick="closeModal('approveModal')">Cancel</button>
                <button type="submit" class="action-btn btn-approve" style="width: auto;">
                    <i class="fa fa-check"></i> Approve & Elevate
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header" style="background: #dc2626; color: white; border-radius: 16px 16px 0 0;">
            <h3 style="color: white;"><i class="fa fa-times"></i> Reject Submission</h3>
            <button class="modal-close" style="color: white;" onclick="closeModal('rejectModal')">&times;</button>
        </div>
        <form id="rejectForm" method="POST" onsubmit="submitReject(event); return false;">
            <input type="hidden" name="submission_id" value="<?= $submissionId ?>">
            <div class="modal-body">
                <div class="alert-box danger">
                    <i class="fa fa-exclamation-circle"></i>
                    <span>This action is final. The submission cannot be resubmitted once rejected.</span>
                </div>
                <div class="form-group">
                    <label>Rejection Reason *</label>
                    <textarea name="reason" required placeholder="Explain the reason for rejection..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn btn-edit" style="width: auto;" onclick="closeModal('rejectModal')">Cancel</button>
                <button type="submit" class="action-btn btn-reject" style="width: auto;">
                    <i class="fa fa-times"></i> Reject
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return to Coordinator Modal -->
<div id="returnToCoordinatorModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fa fa-undo" style="color: #f59e0b;"></i> Return to Coordinator</h3>
            <button class="modal-close" onclick="closeModal('returnToCoordinatorModal')">&times;</button>
        </div>
        <form id="returnToCoordinatorForm" method="POST" onsubmit="submitReturnToCoordinator(event); return false;">
            <input type="hidden" name="submission_id" value="<?= $submissionId ?>">
            <div class="modal-body">
                <div class="alert-box info">
                    <i class="fa fa-info-circle"></i>
                    <span>The coordinator will handle communication with the researcher.</span>
                </div>
                <div class="form-group">
                    <label>Reason for Return *</label>
                    <textarea name="reason" required placeholder="Explain what needs attention..."></textarea>
                </div>
                <div class="form-group">
                    <label>Instructions for Coordinator (optional)</label>
                    <textarea name="instructions" placeholder="Any specific instructions..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn btn-edit" style="width: auto;" onclick="closeModal('returnToCoordinatorModal')">Cancel</button>
                <button type="submit" class="action-btn btn-return" style="width: auto;">
                    <i class="fa fa-undo"></i> Return to Coordinator
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('active');
    const form = modal.querySelector('form');
    if (form) form.reset();
    updateEndorseButtonState();
}

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('active');
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => modal.classList.remove('active'));
    }
});

// Endorse button state
function updateEndorseButtonState() {
    const chkComplete = document.getElementById('chk_complete');
    const chkUnit = document.getElementById('chk_unit');
    const chkCategory = document.getElementById('chk_category');
    const chkAttach = document.getElementById('chk_attach');
    const btn = document.getElementById('endorseSubmitBtn');
    
    if (!chkComplete || !btn) return;
    
    const allChecked = chkComplete.checked && chkUnit.checked && chkCategory.checked && chkAttach.checked;
    btn.disabled = !allChecked;
    btn.style.opacity = allChecked ? '1' : '0.5';
}

['chk_complete', 'chk_unit', 'chk_category', 'chk_attach'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', updateEndorseButtonState);
});

// API helper
async function apiCall(data) {
    const formData = new FormData();
    for (const key in data) formData.append(key, data[key]);
    const response = await fetch('submission_api.php', { method: 'POST', body: formData });
    return response.json();
}

// Workflow actions
async function submitToCoordinator() {
    if (!confirm('Submit this record to your coordinator for review?')) return;
    try {
        const result = await apiCall({ action: 'submit', submission_id: <?= $submissionId ?> });
        if (result.success) { alert('Submission sent to coordinator!'); location.reload(); }
        else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function startCoordinatorReview() {
    try {
        const result = await apiCall({ action: 'start_coordinator_review', submission_id: <?= $submissionId ?> });
        if (result.success) location.reload();
        else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function startROReview() {
    try {
        const result = await apiCall({ action: 'start_ro_review', submission_id: <?= $submissionId ?> });
        if (result.success) location.reload();
        else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function submitEndorse(event) {
    event.preventDefault();
    const form = event.target;
    try {
        const result = await apiCall({
            action: 'endorse',
            submission_id: form.submission_id.value,
            completeness_verified: form.completeness_verified.checked ? 1 : 0,
            unit_verified: form.unit_verified.checked ? 1 : 0,
            category_verified: form.category_verified.checked ? 1 : 0,
            attachments_verified: form.attachments_verified.checked ? 1 : 0,
            notes: form.notes.value
        });
        if (result.success) {
            alert('Submission endorsed!');
            closeModal('endorseModal');
            if (window.SPA) window.SPA.loadPage('work_queue.php', true);
            else location.reload();
        } else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function submitReturn(event) {
    event.preventDefault();
    const form = event.target;
    try {
        const result = await apiCall({
            action: 'return_for_revision',
            submission_id: form.submission_id.value,
            reason: form.reason.value
        });
        if (result.success) {
            alert('Submission returned for revision.');
            closeModal('returnModal');
            if (window.SPA) window.SPA.loadPage('work_queue.php', true);
            else location.reload();
        } else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function submitApprove(event) {
    event.preventDefault();
    const form = event.target;
    try {
        const result = await apiCall({
            action: 'approve',
            submission_id: form.submission_id.value,
            notes: form.notes.value
        });
        if (result.success) {
            alert('Proposal approved & elevated to project!');
            closeModal('approveModal');
            if (window.SPA) window.SPA.loadPage('work_queue.php', true);
            else location.reload();
        } else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function submitReject(event) {
    event.preventDefault();
    const form = event.target;
    try {
        const result = await apiCall({
            action: 'reject',
            submission_id: form.submission_id.value,
            reason: form.reason.value
        });
        if (result.success) {
            alert('Submission rejected.');
            closeModal('rejectModal');
            if (window.SPA) window.SPA.loadPage('work_queue.php', true);
            else location.reload();
        } else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}

async function submitReturnToCoordinator(event) {
    event.preventDefault();
    const form = event.target;
    try {
        const result = await apiCall({
            action: 'return_to_coordinator',
            submission_id: form.submission_id.value,
            reason: form.reason.value,
            instructions: form.instructions ? form.instructions.value : ''
        });
        if (result.success) {
            alert('Submission returned to coordinator.');
            closeModal('returnToCoordinatorModal');
            if (window.SPA) window.SPA.loadPage('work_queue.php', true);
            else location.reload();
        } else alert('Error: ' + result.error);
    } catch (error) { alert('Error: ' + error.message); }
}
</script>
