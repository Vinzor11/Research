<?php
// Database Configuration Template
// Copy this file to db.php and update with your database credentials

$host = 'localhost';
$user = 'root';
$pass = 'umasa10112';
$db   = 'research_management_system';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
