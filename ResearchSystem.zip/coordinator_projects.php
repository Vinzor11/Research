<?php
/**
 * Coordinator Projects View ("Projects in My Scope")
 * 
 * Purpose:
 * Allow coordinators to monitor, validate, and endorse research activities
 * within their assigned scope.
 * 
 * @version 1.0
 * @date 2026-02-05
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'config.php';
require_once 'spa_helper.php';
require_once 'ProjectService.php';

// Access control
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$userRole = $_SESSION['user_role'];
$employeeId = $_SESSION['employee_id'] ?? null;
$fullname = $_SESSION['fullname'] ?? $_SESSION['username'];
$isSpa = isSpaRequest();

// Must be coordinator or admin
if (!in_array($userRole, ['admin', 'coordinator'])) {
    header("Location: research.php");
    exit;
}

// Redirect to SPA shell if accessed directly
if (!$isSpa) {
    $currentFile = basename($_SERVER['PHP_SELF']);
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header("Location: app.php?load=" . urlencode($currentFile . $queryString));
    exit;
}

// Get coordinator types for current user
$coordinatorTypes = [];
if ($employeeId) {
    $stmt = $conn->prepare("SELECT coordinator_type FROM coordinator_assignments WHERE employee_id COLLATE utf8mb4_general_ci = ? AND status = 'active'");
    $stmt->bind_param("s", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $coordinatorTypes[] = $row['coordinator_type'];
    }
    $stmt->close();
}

// Initialize services
$projectService = new ProjectService($conn);
$workflowEngine = $projectService->getWorkflowEngine();

// Get filters and pagination
$statusFilter = $_GET['status'] ?? '';
$researcherTypeFilter = $_GET['researcher_type'] ?? '';
$unitFilter = $_GET['unit'] ?? '';
$searchQuery = $_GET['q'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));

// Get coordinator's projects
$filters = [
    'project_status' => $statusFilter ?: null,
    'researcher_type' => $researcherTypeFilter ?: null,
    'unit' => $unitFilter ?: null,
    'search' => $searchQuery ?: null
];
$projects = $projectService->getCoordinatorProjects($filters, $page, 15);

// Get statistics
$stats = $projectService->getCoordinatorProjectStatistics();

// Get distinct units for filter
$units = $projectService->getProjectUnits();

function s($v) { return htmlspecialchars($v ?? '', ENT_QUOTES); }
?>

<link rel="stylesheet" href="facultyresearcherstyle.css">
<style>
/* ============================================
   UNIT PROJECTS - UNIFIED DESIGN (Work Queue Style)
   ============================================ */

/* Page Header Banner */
.page-header-banner {
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 50%, #10a83a 100%);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(6, 78, 26, 0.3);
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.header-left i.header-icon {
    font-size: 32px;
    color: rgba(255, 255, 255, 0.9);
}

.header-left h1 {
    font-size: 26px;
    font-weight: 700;
    color: white;
    margin: 0 0 4px 0;
}

.header-left p {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    margin: 0;
}

.role-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    background: rgba(255, 255, 255, 0.95);
    color: #064e1a;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.role-badge i { font-size: 14px; }
.role-badge.badge-faculty { background: #dbeafe; color: #1e40af; }
.role-badge.badge-student { background: #fef3c7; color: #92400e; }
.role-badge.badge-personnel { background: #e0e7ff; color: #5b21b6; }

/* Statistics Cards Row */
.stats-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
    min-width: 140px;
    flex: 1;
    transition: all 0.3s ease;
    cursor: default;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.stat-card:hover .stat-icon {
    transform: rotate(-10deg) scale(1.1);
}

.stat-card.active {
    border: 2px solid #064e1a;
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.stat-icon.icon-total { background: linear-gradient(135deg, #dbeafe, #bfdbfe); color: #1e40af; }
.stat-icon.icon-ongoing { background: linear-gradient(135deg, #fef3c7, #fde68a); color: #92400e; }
.stat-icon.icon-extended { background: linear-gradient(135deg, #fee2e2, #fecaca); color: #991b1b; }
.stat-icon.icon-completed { background: linear-gradient(135deg, #d1fae5, #a7f3d0); color: #065f46; }
.stat-icon.icon-overdue { background: linear-gradient(135deg, #fecaca, #fca5a5); color: #7f1d1d; }

.stat-info .stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.stat-info .stat-label {
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
    font-weight: 500;
}

/* Filter Container */
.filter-container {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.filter-header i { color: #064e1a; font-size: 18px; }
.filter-header h3 { font-size: 14px; font-weight: 600; color: #374151; margin: 0; }

.filter-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 140px 140px 2fr auto;
    gap: 16px;
    align-items: flex-end;
}

@media (max-width: 1200px) {
    .filter-grid { grid-template-columns: 1fr 1fr; }
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.filter-group select,
.filter-group input[type="text"],
.filter-group input[type="date"] {
    padding: 10px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 13px;
    background: #f9fafb;
    color: #374151;
    transition: all 0.2s;
    width: 100%;
}

.filter-group select:focus,
.filter-group input:focus {
    outline: none;
    border-color: #064e1a;
    background: white;
    box-shadow: 0 0 0 3px rgba(6, 78, 26, 0.1);
}

.filter-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

/* Search Wrapper with Clear Button */
.search-wrapper {
    position: relative;
    display: flex;
    align-items: center;
}

.search-wrapper input {
    padding-right: 36px;
}

.search-clear {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e5e7eb;
    border: none;
    border-radius: 4px;
    color: #6b7280;
    cursor: pointer;
    font-size: 11px;
    transition: all 0.2s;
}

.search-clear:hover {
    background: #d1d5db;
    color: #374151;
}

.clear-btn {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f3f4f6;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
}

.clear-btn:hover { background: #e5e7eb; color: #374151; }

/* Queue Table */
.queue-table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
}

.queue-table th {
    background: #f9fafb;
    padding: 14px 16px;
    text-align: left;
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e5e7eb;
}

/* Column widths: Project | Researcher | Status | Timeline | Classification | Action */
.queue-table th:nth-child(1) { width: 22%; } /* Project */
.queue-table th:nth-child(2) { width: 18%; } /* Researcher */
.queue-table th:nth-child(3) { width: 12%; text-align: center; } /* Status */
.queue-table th:nth-child(4) { width: 18%; text-align: center; } /* Timeline */
.queue-table th:nth-child(5) { width: 20%; } /* Classification */
.queue-table th:nth-child(6) { width: 10%; text-align: center; } /* Action */

.queue-table td {
    padding: 14px 16px;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
}

.queue-table td:nth-child(3),
.queue-table td:nth-child(4),
.queue-table td:nth-child(6) {
    vertical-align: middle;
}

.queue-table tr:hover { background: #f9fafb; }

/* Type Badge Cell */
.type-cell { text-align: center; }

.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.type-badge i { font-size: 12px; }
.type-badge.type-on_going { background: #fef3c7; color: #92400e; }
.type-badge.type-extended { background: #fee2e2; color: #991b1b; }
.type-badge.type-completed { background: #d1fae5; color: #065f46; }
.type-badge.type-overdue { background: #fecaca; color: #7f1d1d; }

/* Item Cell */
.item-cell { text-align: left; }

.item-title {
    font-weight: 600;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 4px;
    line-height: 1.4;
}

.item-title:hover { color: #064e1a; }

.item-meta { font-size: 12px; color: #6b7280; margin-bottom: 6px; }

.item-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.ref-badge { font-size: 11px; color: #6b7280; font-family: monospace; }

.researcher-type-badge {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
}

.researcher-type-badge.faculty { background: #dbeafe; color: #1e40af; }
.researcher-type-badge.student { background: #fef3c7; color: #92400e; }
.researcher-type-badge.personnel { background: #e0e7ff; color: #5b21b6; }

.researcher-name {
    font-size: 12px;
    color: #374151;
    display: flex;
    align-items: center;
    gap: 4px;
}

.researcher-name i { color: #9ca3af; font-size: 11px; }

/* Other cells */
.unit-cell { font-size: 13px; color: #374151; text-align: center; }
.status-cell { text-align: center; }
.date-cell { font-size: 13px; color: #6b7280; text-align: center; }
.action-cell { text-align: center; }

/* Project Title Cell */
.project-title-cell { text-align: left; }
.project-title-link {
    font-weight: 600;
    font-size: 14px;
    color: #1f2937;
    text-decoration: none;
    display: block;
    margin-bottom: 6px;
    line-height: 1.4;
}
.project-title-link:hover { color: #064e1a; }
.project-code-cell {
    font-size: 11px;
    color: #9ca3af;
    font-family: 'Consolas', monospace;
    display: inline-block;
    background: #f3f4f6;
    padding: 3px 8px;
    border-radius: 4px;
}

/* Researcher Cell */
.researcher-cell {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
}
.researcher-cell .researcher-name {
    font-weight: 600;
    color: #1f2937;
    font-size: 13px;
}
.researcher-unit {
    font-size: 11px;
    color: #6b7280;
    line-height: 1.3;
}
.type-badge.type-faculty { background: #dbeafe; color: #1e40af; }
.type-badge.type-student { background: #fef3c7; color: #92400e; }
.type-badge.type-personnel { background: #e0e7ff; color: #5b21b6; }

/* Status Cell */
.status-cell-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}
.form-mapping {
    font-size: 10px;
    color: #166534;
    font-weight: 500;
}

/* Timeline Cell */
.timeline-cell { 
    text-align: center;
}
.timeline-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}
.timeline-dates {
    font-size: 12px;
    color: #374151;
    font-weight: 500;
    white-space: nowrap;
}
.mini-progress {
    width: 100%;
    max-width: 100px;
    height: 5px;
    background: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
}
.mini-progress-bar {
    height: 100%;
    border-radius: 3px;
    transition: width 0.3s;
}
.mini-progress-bar.on-track { background: linear-gradient(90deg, #10b981, #34d399); }
.mini-progress-bar.near-due { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
.mini-progress-bar.overdue { background: linear-gradient(90deg, #ef4444, #f87171); }
.mini-progress-bar.completed { background: linear-gradient(90deg, #10b981, #34d399); }
.timeline-status {
    font-size: 11px;
    font-weight: 500;
}
.timeline-status.in_progress, .timeline-status.on-track { color: #10b981; }
.timeline-status.near_due { color: #f59e0b; }
.timeline-status.overdue { color: #ef4444; }
.timeline-status.not_started { color: #6b7280; }
.completed-status {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
}
.completed-status .completed-badge {
    font-size: 12px;
    color: #10b981;
    font-weight: 600;
}
.completed-status .completed-date {
    font-size: 10px;
    color: #6b7280;
}

/* Classification Cell */
.classification-cell {
    font-size: 12px;
    color: #374151;
    text-align: left;
    line-height: 1.5;
}
.classification-item {
    display: flex;
    gap: 4px;
    margin-bottom: 3px;
}
.classification-item strong { 
    font-weight: 600;
    color: #6b7280;
    font-size: 11px;
}
.classification-item span {
    color: #1f2937;
}
.classification-fy {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 2px;
}
.not-classified {
    color: #d97706;
    font-size: 11px;
    display: flex;
    align-items: center;
    gap: 4px;
}

/* Action Cell */
.action-cell {
    text-align: center;
}

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-badge.on_going { background: #fef3c7; color: #92400e; }
.status-badge.extended { background: #e0e7ff; color: #5b21b6; }
.status-badge.completed { background: #d1fae5; color: #065f46; }
.status-badge.overdue { background: #fee2e2; color: #991b1b; }

/* Review Button */
.btn-review {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: linear-gradient(135deg, #064e1a 0%, #0b7a2b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-review:hover {
    background: linear-gradient(135deg, #053615 0%, #096b24 100%);
    transform: translateY(-1px);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i { font-size: 64px; margin-bottom: 20px; opacity: 0.3; color: #064e1a; }
.empty-state h3 { font-size: 18px; color: #374151; margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: #6b7280; }

/* Pagination */
.pagination-container {
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
}

.pagination-info { font-size: 13px; color: #6b7280; }
.pagination { display: flex; gap: 6px; }

.pagination a, .pagination span {
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    text-decoration: none;
}

.pagination a { background: white; color: #374151; border: 1px solid #e5e7eb; }
.pagination a:hover { background: #f3f4f6; }
.pagination .current { background: #064e1a; color: white; }
</style>

<div class="content">
    <!-- Page Header Banner -->
    <div class="page-header-banner">
        <div class="header-content">
            <div class="header-left">
                <i class="fa fa-folder-tree header-icon"></i>
                <div>
                    <h1>Unit Projects</h1>
                    <p>Monitor and review research projects within your assigned scope</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <span class="role-badge" style="background: rgba(255,255,255,0.95); color: #064e1a;">
                    <i class="fa fa-user-tie"></i>
                    <span style="font-weight: 600;"><?= s($fullname) ?></span>
                    <span style="opacity: 0.6; margin: 0 4px;">•</span>
                    <?php if (!empty($coordinatorTypes)): ?>
                        <?= implode(' / ', array_map(function($t) { return ucfirst($t); }, $coordinatorTypes)) ?> Coordinator
                    <?php else: ?>
                        Coordinator
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Statistics Row -->
    <?php $totalProjects = ($stats['on_going'] ?? 0) + ($stats['extended'] ?? 0) + ($stats['completed'] ?? 0) + ($stats['overdue'] ?? 0); ?>
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon icon-total">
                <i class="fa fa-layer-group"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $totalProjects ?></div>
                <div class="stat-label">Total Projects</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-ongoing">
                <i class="fa fa-spinner"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['on_going'] ?? 0 ?></div>
                <div class="stat-label">On-Going</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-extended">
                <i class="fa fa-calendar-plus"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['extended'] ?? 0 ?></div>
                <div class="stat-label">Extended</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-completed">
                <i class="fa fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['completed'] ?? 0 ?></div>
                <div class="stat-label">Completed</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-overdue">
                <i class="fa fa-exclamation-triangle"></i>
            </div>
            <div class="stat-info">
                <div class="stat-number"><?= $stats['overdue'] ?? 0 ?></div>
                <div class="stat-label">Overdue</div>
            </div>
        </div>
    </div>

    <!-- Filter Container -->
    <div class="filter-container">
        <div class="filter-header">
            <i class="fa fa-filter" style="color: #064e1a;"></i>
            <h3>Filter Projects</h3>
        </div>
        <form method="GET" id="filterForm">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status" onchange="this.form.submit()">
                        <option value="">All Statuses</option>
                        <option value="on_going" <?= $statusFilter === 'on_going' ? 'selected' : '' ?>>On-Going</option>
                        <option value="extended" <?= $statusFilter === 'extended' ? 'selected' : '' ?>>Extended</option>
                        <option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Researcher Type</label>
                    <select name="researcher_type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <option value="faculty" <?= $researcherTypeFilter === 'faculty' ? 'selected' : '' ?>>Faculty</option>
                        <option value="student" <?= $researcherTypeFilter === 'student' ? 'selected' : '' ?>>Student</option>
                        <option value="personnel" <?= $researcherTypeFilter === 'personnel' ? 'selected' : '' ?>>Personnel</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?= s($_GET['date_from'] ?? '') ?>" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?= s($_GET['date_to'] ?? '') ?>" onchange="this.form.submit()">
                </div>
                
                <div class="filter-group" style="flex: 2;">
                    <label>Search</label>
                    <div class="search-wrapper">
                        <input type="text" name="q" id="searchInput" placeholder="Search by reference, title, or requester..." value="<?= s($searchQuery) ?>">
                        <?php if ($searchQuery): ?>
                            <button type="button" class="search-clear" onclick="clearSearch()" title="Clear search"><i class="fa fa-times"></i></button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="filter-group filter-actions">
                    <label>&nbsp;</label>
                    <?php if ($statusFilter || $researcherTypeFilter || !empty($_GET['date_from']) || !empty($_GET['date_to'])): ?>
                        <a href="coordinator_projects.php" class="clear-btn" title="Clear all filters"><i class="fa fa-times"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Projects Table -->
    <div class="queue-table-container">
        <?php if (empty($projects['data'])): ?>
            <div class="empty-state">
                <i class="fa fa-folder-open"></i>
                <h3>No Projects Found</h3>
                <p>No approved research projects match your filter criteria.</p>
            </div>
        <?php else: ?>
            <table class="queue-table">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Researcher</th>
                        <th>Status</th>
                        <th>Timeline</th>
                        <th>Classification</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects['data'] as $project): 
                        $timelineClass = $project['timeline_status'] ?? 'in_progress';
                        $progressPercent = $project['progress_percent'] ?? 0;
                        
                        // Determine progress bar class
                        $barClass = 'on-track';
                        if ($timelineClass === 'overdue') $barClass = 'overdue';
                        elseif ($timelineClass === 'near_due') $barClass = 'near-due';
                        elseif ($project['project_status'] === 'completed') $barClass = 'completed';
                    ?>
                    <tr>
                        <!-- PROJECT -->
                        <td class="project-title-cell">
                            <a href="project_view.php?id=<?= $project['id'] ?>" class="project-title-link"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $project['id'] ?>',true)}">
                                <?= s($project['title']) ?>
                            </a>
                            <span class="project-code-cell">
                                <?= s($project['project_code'] ?: $project['reference_number'] ?: 'N/A') ?>
                            </span>
                        </td>
                        
                        <!-- RESEARCHER -->
                        <td>
                            <div class="researcher-cell">
                                <span class="researcher-name"><?= s($project['researcher_name'] ?: 'Unknown') ?></span>
                                <span class="researcher-unit"><?= s($project['researcher_unit_name'] ?: '—') ?></span>
                                <span class="type-badge type-<?= s($project['researcher_type']) ?>">
                                    <?= s(strtoupper($project['researcher_type'])) ?>
                                </span>
                            </div>
                        </td>
                        
                        <!-- STATUS -->
                        <td>
                            <div class="status-cell-content">
                                <span class="status-badge <?= s($project['project_status']) ?> <?= $timelineClass === 'overdue' ? 'status-overdue' : '' ?>">
                                    <?= s($project['project_status_label'] ?? ucfirst(str_replace('_', ' ', $project['project_status']))) ?>
                                </span>
                                <?php if (!empty($project['rmis_form_mapping'])): ?>
                                <span class="form-mapping">Form <?= s($project['rmis_form_mapping']) ?></span>
                                <?php endif; ?>
                            </div>
                        </td>
                        
                        <!-- TIMELINE -->
                        <td class="timeline-cell">
                            <?php if ($project['project_status'] !== 'completed'): ?>
                            <div class="timeline-content">
                                <div class="timeline-dates">
                                    <?= !empty($project['proposed_start_date']) ? date('M d', strtotime($project['proposed_start_date'])) : '—' ?> – 
                                    <?= !empty($project['current_end_date']) ? date('M d, Y', strtotime($project['current_end_date'])) : '—' ?>
                                </div>
                                <div class="mini-progress">
                                    <div class="mini-progress-bar <?= $barClass ?>" style="width: <?= $progressPercent ?>%"></div>
                                </div>
                                <div class="timeline-status <?= $timelineClass ?>">
                                    <?= $project['days_info'] ?? '' ?>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="completed-status">
                                <span class="completed-badge"><i class="fa fa-check-circle"></i> Completed</span>
                                <?php if (!empty($project['completed_at'])): ?>
                                <span class="completed-date"><?= date('M d, Y', strtotime($project['completed_at'])) ?></span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        
                        <!-- CLASSIFICATION -->
                        <td class="classification-cell">
                            <?php if (!empty($project['research_program'])): ?>
                            <div class="classification-item">
                                <strong>Program:</strong>
                                <span><?= s($project['research_program']) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($project['funding_source'])): ?>
                            <div class="classification-item">
                                <strong>Funding:</strong>
                                <span><?= s($project['funding_source']) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($project['fiscal_year'])): ?>
                            <div class="classification-fy"><?= s($project['fiscal_year']) ?></div>
                            <?php endif; ?>
                            <?php if (empty($project['research_program']) && empty($project['funding_source'])): ?>
                            <span class="not-classified"><i class="fa fa-exclamation-circle"></i> Not classified</span>
                            <?php endif; ?>
                        </td>
                        
                        <!-- ACTION -->
                        <td class="action-cell">
                            <a href="project_view.php?id=<?= $project['id'] ?>" class="btn-review"
                               onclick="if(window.SPA){event.preventDefault();window.SPA.loadPage('project_view.php?id=<?= $project['id'] ?>',true)}">
                                <i class="fa fa-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <div class="pagination-container">
                <div class="pagination-info">
                    Showing <?= (($page - 1) * 15) + 1 ?> to <?= min($page * 15, $projects['total']) ?> of <?= $projects['total'] ?> projects
                </div>
                <?php if ($projects['total_pages'] > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                            <i class="fa fa-chevron-left"></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($projects['total_pages'], $page + 2); $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?page=<?= $i ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $projects['total_pages']): ?>
                        <a href="?page=<?= $page + 1 ?>&status=<?= s($statusFilter) ?>&researcher_type=<?= s($researcherTypeFilter) ?>&q=<?= s($searchQuery) ?>">
                            <i class="fa fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
(function() {
    // Search field - submit on Enter key
    const searchInput = document.querySelector('input[name="q"]');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                this.form.submit();
            }
        });
        
        // Optional: auto-submit after typing stops (debounced)
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 3 || this.value.length === 0) {
                    this.form.submit();
                }
            }, 800);
        });
    }
    
    // Handle SPA form submission
    const filterForm = document.getElementById('filterForm');
    if (filterForm && window.SPA) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const params = new URLSearchParams(formData).toString();
            const url = 'coordinator_projects.php' + (params ? '?' + params : '');
            window.SPA.loadPage(url, true);
        });
    }
})();

// Clear search function
function clearSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
        searchInput.form.submit();
    }
}
</script>
